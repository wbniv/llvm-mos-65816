; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/control.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/control.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@n = dso_local global i16 100, align 1
@sel = dso_local global i8 3, align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  %0 = load volatile i16, ptr @n, align 1, !tbaa !7
  %cmp.not26 = icmp eq i16 %0, 0
  br i1 %cmp.not26, label %for.end, label %for.body

for.body:                                         ; preds = %entry, %for.body
  %i.028 = phi i16 [ %inc, %for.body ], [ 1, %entry ]
  %r.027 = phi i16 [ %add, %for.body ], [ 0, %entry ]
  %add = add i16 %i.028, %r.027
  %inc = add i16 %i.028, 1
  %1 = load volatile i16, ptr @n, align 1, !tbaa !7
  %cmp.not = icmp ugt i16 %inc, %1
  br i1 %cmp.not, label %for.end, label %for.body, !llvm.loop !8

for.end:                                          ; preds = %for.body, %entry
  %r.0.lcssa = phi i16 [ 0, %entry ], [ %add, %for.body ]
  %2 = load volatile i16, ptr @n, align 1, !tbaa !7
  %cmp1.not29 = icmp eq i16 %2, 0
  br i1 %cmp1.not29, label %while.end, label %while.body

while.body:                                       ; preds = %for.end, %if.end
  %ev.031 = phi i16 [ %ev.1, %if.end ], [ 0, %for.end ]
  %w.030 = phi i16 [ %dec, %if.end ], [ %2, %for.end ]
  %and = and i16 %w.030, 1
  %cmp2 = icmp eq i16 %and, 0
  br i1 %cmp2, label %if.then, label %if.end

if.then:                                          ; preds = %while.body
  %add3 = add i16 %ev.031, %w.030
  br label %if.end

if.end:                                           ; preds = %if.then, %while.body
  %ev.1 = phi i16 [ %add3, %if.then ], [ %ev.031, %while.body ]
  %dec = add i16 %w.030, -1
  %cmp1.not = icmp eq i16 %dec, 0
  br i1 %cmp1.not, label %while.end, label %while.body, !llvm.loop !10

while.end:                                        ; preds = %if.end, %for.end
  %ev.0.lcssa = phi i16 [ 0, %for.end ], [ %ev.1, %if.end ]
  %add4 = add i16 %ev.0.lcssa, %r.0.lcssa
  %add8 = add i16 %add4, 45
  %3 = load volatile i8, ptr @sel, align 1, !tbaa !11
  %switch.tableidx = add i8 %3, -1
  %4 = icmp ult i8 %switch.tableidx, 3
  br i1 %4, label %switch.lookup, label %sw.epilog

switch.lookup:                                    ; preds = %while.end
  %narrow = mul nuw nsw i8 %switch.tableidx, 10
  %narrow33 = add nuw nsw i8 %narrow, 10
  %switch.offset = zext nneg i8 %narrow33 to i16
  br label %sw.epilog

sw.epilog:                                        ; preds = %while.end, %switch.lookup
  %s.0 = phi i16 [ %switch.offset, %switch.lookup ], [ 0, %while.end ]
  %add11 = add i16 %add8, %s.0
  store volatile i16 %add11, ptr @corpus_result, align 1, !tbaa !7
  br label %for.cond12

for.cond12:                                       ; preds = %for.cond12, %sw.epilog
  tail call void asm sideeffect "", ""() #1, !srcloc !12
  br label %for.cond12
}

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos65c02" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 155e209c4cee8eeac01397aac3542e76841a9856)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!4, !4, i64 0}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = distinct !{!10, !9}
!11 = !{!5, !5, i64 0}
!12 = !{i64 1146}
