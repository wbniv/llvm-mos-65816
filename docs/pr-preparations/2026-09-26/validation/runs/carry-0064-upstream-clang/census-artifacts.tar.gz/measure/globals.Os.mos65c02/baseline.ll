; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/globals.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/globals.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@data_vals = dso_local local_unnamed_addr global [4 x i16] [i16 4369, i16 8738, i16 13107, i16 17476], align 1
@data_byte = dso_local local_unnamed_addr global i8 -85, align 1
@one = dso_local global i8 1, align 1
@bss_vals = dso_local local_unnamed_addr global [8 x i16] zeroinitializer, align 1
@bss_byte = dso_local local_unnamed_addr global i8 0, align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  br label %for.body

for.body:                                         ; preds = %entry, %for.body
  %mos-indexiv.iv = phi i8 [ 0, %entry ], [ %mos-indexiv.iv.next, %for.body ]
  %i.035 = phi i8 [ 0, %entry ], [ %inc, %for.body ]
  %r.034 = phi i16 [ 0, %entry ], [ %add, %for.body ]
  %0 = zext nneg i8 %mos-indexiv.iv to i16
  %uglygep = getelementptr i8, ptr @data_vals, i16 %0
  %1 = load i16, ptr %uglygep, align 1, !tbaa !7
  %2 = load volatile i8, ptr @one, align 1, !tbaa !8
  %conv2 = zext i8 %2 to i16
  %mul = mul i16 %1, %conv2
  %add = add i16 %mul, %r.034
  %inc = add nuw nsw i8 %i.035, 1
  %exitcond.not = icmp eq i8 %inc, 4
  %mos-indexiv.iv.next = add nuw nsw i8 %mos-indexiv.iv, 2
  br i1 %exitcond.not, label %for.end, label %for.body, !llvm.loop !9

for.end:                                          ; preds = %for.body
  %3 = load i8, ptr @data_byte, align 1, !tbaa !8
  %4 = load volatile i8, ptr @one, align 1, !tbaa !8
  br label %for.body11

for.body11:                                       ; preds = %for.end, %for.body11
  %mos-indexiv.iv39 = phi i8 [ 0, %for.end ], [ %mos-indexiv.iv.next40, %for.body11 ]
  %bsssum.037 = phi i16 [ 0, %for.end ], [ %add14, %for.body11 ]
  %i.136 = phi i8 [ 0, %for.end ], [ %inc16, %for.body11 ]
  %5 = zext nneg i8 %mos-indexiv.iv39 to i16
  %uglygep41 = getelementptr i8, ptr @bss_vals, i16 %5
  %6 = load i16, ptr %uglygep41, align 1, !tbaa !7
  %add14 = add i16 %6, %bsssum.037
  %inc16 = add nuw nsw i8 %i.136, 1
  %exitcond38.not = icmp eq i8 %inc16, 8
  %mos-indexiv.iv.next40 = add nuw nsw i8 %mos-indexiv.iv39, 2
  br i1 %exitcond38.not, label %for.end17, label %for.body11, !llvm.loop !11

for.end17:                                        ; preds = %for.body11
  %conv3 = zext i8 %3 to i16
  %conv4 = zext i8 %4 to i16
  %mul5 = mul nuw nsw i16 %conv4, %conv3
  %add6 = add i16 %mul5, %add
  %7 = load i8, ptr @bss_byte, align 1, !tbaa !8
  %conv18 = zext i8 %7 to i16
  %add19 = sub nsw i16 0, %conv18
  %cmp20.not = icmp eq i16 %add14, %add19
  br i1 %cmp20.not, label %if.end, label %if.then

if.then:                                          ; preds = %for.end17
  %add22 = add i16 %add6, -4096
  br label %if.end

if.end:                                           ; preds = %if.then, %for.end17
  %r.1 = phi i16 [ %add22, %if.then ], [ %add6, %for.end17 ]
  store volatile i16 %r.1, ptr @corpus_result, align 1, !tbaa !7
  br label %for.cond23

for.cond23:                                       ; preds = %for.cond23, %if.end
  tail call void asm sideeffect "", ""() #1, !srcloc !12
  br label %for.cond23
}

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos65c02" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 7bd67c0ae4e8bb65a3f980912bf201df22131e34)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!4, !4, i64 0}
!8 = !{!5, !5, i64 0}
!9 = distinct !{!9, !10}
!10 = !{!"llvm.loop.mustprogress"}
!11 = distinct !{!11, !10}
!12 = !{i64 1376}
