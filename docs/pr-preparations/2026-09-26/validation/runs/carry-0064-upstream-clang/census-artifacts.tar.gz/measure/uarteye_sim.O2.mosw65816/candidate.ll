; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/uarteye_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/uarteye_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  br label %for.body.i

for.body.i:                                       ; preds = %for.body.i, %entry
  %h.025.i = phi i16 [ 0, %entry ], [ %xor.i22.i, %for.body.i ]
  %seed.024.i = phi i16 [ 21930, %entry ], [ %add.i, %for.body.i ]
  %i.023.i = phi i16 [ 0, %entry ], [ %inc.i, %for.body.i ]
  %mul.i = mul i16 %seed.024.i, 25173
  %add.i = add i16 %mul.i, 13849
  %shr.i = lshr i16 %add.i, 7
  %conv1.i = and i16 %shr.i, 255
  %or.i.i = tail call i16 @llvm.fshl.i16(i16 %h.025.i, i16 %h.025.i, i16 1)
  %xor.i.i = xor i16 %conv1.i, %or.i.i
  %conv.i.i = shl nuw nsw i16 %shr.i, 1
  %or.i20.i = or i16 %conv.i.i, 512
  %or.i21.i = tail call i16 @llvm.fshl.i16(i16 %xor.i.i, i16 %xor.i.i, i16 2)
  %xor.i22.i = xor i16 %or.i21.i, %or.i20.i
  %inc.i = add nuw nsw i16 %i.023.i, 1
  %exitcond.not.i = icmp eq i16 %inc.i, 128
  br i1 %exitcond.not.i, label %uarteye_gate_crc.exit, label %for.body.i, !llvm.loop !7

uarteye_gate_crc.exit:                            ; preds = %for.body.i
  store volatile i16 %xor.i22.i, ptr @corpus_result, align 1, !tbaa !9
  br label %for.cond

for.cond:                                         ; preds = %for.cond, %uarteye_gate_crc.exit
  tail call void asm sideeffect "", ""() #2, !srcloc !10
  br label %for.cond
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #1

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 155e209c4cee8eeac01397aac3542e76841a9856)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!4, !4, i64 0}
!10 = !{i64 657}
