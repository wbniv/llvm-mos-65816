; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/ovmatrix_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/ovmatrix_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1
@ov_fire = internal unnamed_addr global [18 x i16] zeroinitializer, align 1
@ov_clean = internal unnamed_addr global [18 x i16] zeroinitializer, align 1
@ov_res = internal unnamed_addr global [18 x i32] zeroinitializer, align 1
@ov_u16 = internal unnamed_addr global i16 0, align 1
@ov_i16 = internal unnamed_addr global i16 0, align 1
@ov_u32 = internal unnamed_addr global i32 0, align 1
@ov_i32 = internal unnamed_addr global i32 0, align 1
@ov_u64 = internal unnamed_addr global i64 0, align 8
@ov_i64 = internal unnamed_addr global i64 0, align 8

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  br label %for.cond.i.i.i

for.cond.i.i.i:                                   ; preds = %for.body.i.i.i, %entry
  %mos-indexiv.iv11.i.i.i = phi i8 [ %mos-indexiv.iv.next12.i.i.i, %for.body.i.i.i ], [ 0, %entry ]
  %mos-indexiv.iv.i.i.i = phi i8 [ %mos-indexiv.iv.next.i.i.i, %for.body.i.i.i ], [ 0, %entry ]
  %c.0.i.i.i = phi i8 [ %inc.i.i.i, %for.body.i.i.i ], [ 0, %entry ]
  %exitcond.not.i.i.i = icmp eq i8 %c.0.i.i.i, 18
  br i1 %exitcond.not.i.i.i, label %ov_reset.exit.i.i, label %for.body.i.i.i

for.body.i.i.i:                                   ; preds = %for.cond.i.i.i
  %0 = zext nneg i8 %mos-indexiv.iv.i.i.i to i16
  %uglygep = getelementptr i8, ptr @ov_fire, i16 %0
  store i16 0, ptr %uglygep, align 1, !tbaa !7
  %uglygep1 = getelementptr i8, ptr @ov_clean, i16 %0
  store i16 0, ptr %uglygep1, align 1, !tbaa !7
  %1 = zext nneg i8 %mos-indexiv.iv11.i.i.i to i16
  %uglygep2 = getelementptr i8, ptr @ov_res, i16 %1
  store i32 0, ptr %uglygep2, align 1, !tbaa !8
  %inc.i.i.i = add nuw nsw i8 %c.0.i.i.i, 1
  %mos-indexiv.iv.next.i.i.i = add nuw nsw i8 %mos-indexiv.iv.i.i.i, 2
  %mos-indexiv.iv.next12.i.i.i = add nuw nsw i8 %mos-indexiv.iv11.i.i.i, 4
  br label %for.cond.i.i.i, !llvm.loop !10

ov_reset.exit.i.i:                                ; preds = %for.cond.i.i.i
  store i16 4951, ptr @ov_u16, align 1, !tbaa !7
  store i16 9320, ptr @ov_i16, align 1, !tbaa !7
  store i32 -1985229329, ptr @ov_u32, align 1, !tbaa !8
  store i32 305419896, ptr @ov_i32, align 1, !tbaa !8
  store i64 81985529216486895, ptr @ov_u64, align 8, !tbaa !12
  store i64 1147797409030816545, ptr @ov_i64, align 8, !tbaa !12
  br label %for.cond.i.i

for.cond.i.i:                                     ; preds = %for.body.i.i, %ov_reset.exit.i.i
  %s.0.i.i = phi i16 [ -25029, %ov_reset.exit.i.i ], [ %add.i.i, %for.body.i.i ]
  %i.0.i.i = phi i16 [ 0, %ov_reset.exit.i.i ], [ %inc.i.i, %for.body.i.i ]
  %exitcond.not.i.i = icmp eq i16 %i.0.i.i, 96
  br i1 %exitcond.not.i.i, label %for.cond.i, label %for.body.i.i

for.body.i.i:                                     ; preds = %for.cond.i.i
  %mul.i.i.i = mul i16 %s.0.i.i, 25173
  %add.i.i = add i16 %mul.i.i.i, 13849
  tail call fastcc void @ov_kernel(i16 noundef %add.i.i) #5
  %inc.i.i = add nuw nsw i16 %i.0.i.i, 1
  br label %for.cond.i.i, !llvm.loop !14

for.cond.i:                                       ; preds = %for.cond.i.i, %for.body.i
  %mos-indexiv.iv45.i = phi i8 [ %mos-indexiv.iv.next46.i, %for.body.i ], [ 0, %for.cond.i.i ]
  %mos-indexiv.iv.i = phi i8 [ %mos-indexiv.iv.next.i, %for.body.i ], [ 0, %for.cond.i.i ]
  %h.0.i = phi i16 [ %call7.i, %for.body.i ], [ 31822, %for.cond.i.i ]
  %c.0.i = phi i8 [ %inc.i, %for.body.i ], [ 0, %for.cond.i.i ]
  %exitcond.not.i = icmp eq i8 %c.0.i, 18
  br i1 %exitcond.not.i, label %ovmatrix_gate_crc.exit, label %for.body.i

for.body.i:                                       ; preds = %for.cond.i
  %2 = zext nneg i8 %mos-indexiv.iv.i to i16
  %uglygep3 = getelementptr i8, ptr @ov_fire, i16 %2
  %3 = load i16, ptr %uglygep3, align 1, !tbaa !7
  %xor.i33.i = xor i16 %3, %h.0.i
  %or.i34.i = tail call i16 @llvm.fshl.i16(i16 %xor.i33.i, i16 %xor.i33.i, i16 1)
  %mul.i.i35.i = mul i16 %or.i34.i, 25173
  %add.i36.i = add i16 %mul.i.i35.i, 13849
  %uglygep4 = getelementptr i8, ptr @ov_clean, i16 %2
  %4 = load i16, ptr %uglygep4, align 1, !tbaa !7
  %xor.i37.i = xor i16 %add.i36.i, %4
  %or.i38.i = tail call i16 @llvm.fshl.i16(i16 %xor.i37.i, i16 %xor.i37.i, i16 1)
  %mul.i.i39.i = mul i16 %or.i38.i, 25173
  %add.i40.i = add i16 %mul.i.i39.i, 13849
  %5 = zext nneg i8 %mos-indexiv.iv45.i to i16
  %uglygep5 = getelementptr i8, ptr @ov_res, i16 %5
  %6 = load i32, ptr %uglygep5, align 1, !tbaa !8
  %call7.i = tail call fastcc i16 @ov_mix32(i16 noundef %add.i40.i, i32 noundef %6) #5
  %inc.i = add nuw nsw i8 %c.0.i, 1
  %mos-indexiv.iv.next.i = add nuw nsw i8 %mos-indexiv.iv.i, 2
  %mos-indexiv.iv.next46.i = add nuw nsw i8 %mos-indexiv.iv45.i, 4
  br label %for.cond.i, !llvm.loop !15

ovmatrix_gate_crc.exit:                           ; preds = %for.cond.i
  %7 = load i16, ptr @ov_u16, align 1, !tbaa !7
  %xor.i.i = xor i16 %7, %h.0.i
  %or.i.i = tail call i16 @llvm.fshl.i16(i16 %xor.i.i, i16 %xor.i.i, i16 1)
  %mul.i.i27.i = mul i16 %or.i.i, 25173
  %add.i28.i = add i16 %mul.i.i27.i, 13849
  %8 = load i16, ptr @ov_i16, align 1, !tbaa !7
  %xor.i29.i = xor i16 %add.i28.i, %8
  %or.i30.i = tail call i16 @llvm.fshl.i16(i16 %xor.i29.i, i16 %xor.i29.i, i16 1)
  %mul.i.i31.i = mul i16 %or.i30.i, 25173
  %add.i32.i = add i16 %mul.i.i31.i, 13849
  %9 = load i32, ptr @ov_u32, align 1, !tbaa !8
  %call10.i = tail call fastcc i16 @ov_mix32(i16 noundef %add.i32.i, i32 noundef %9) #5
  %10 = load i32, ptr @ov_i32, align 1, !tbaa !8
  %call11.i = tail call fastcc i16 @ov_mix32(i16 noundef %call10.i, i32 noundef %10) #5
  %11 = load i64, ptr @ov_u64, align 8, !tbaa !12
  %call12.i = tail call fastcc i16 @ov_mix64(i16 noundef %call11.i, i64 noundef %11) #5
  %12 = load i64, ptr @ov_i64, align 8, !tbaa !12
  %call13.i = tail call fastcc i16 @ov_mix64(i16 noundef %call12.i, i64 noundef %12) #5
  store volatile i16 %call13.i, ptr @corpus_result, align 1, !tbaa !7
  br label %for.cond

for.cond:                                         ; preds = %for.cond, %ovmatrix_gate_crc.exit
  tail call void asm sideeffect "", ""() #6, !srcloc !16
  br label %for.cond
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define internal fastcc i16 @ov_mix32(i16 noundef %h, i32 noundef %v) unnamed_addr #1 {
entry:
  %conv = trunc i32 %v to i16
  %xor.i = xor i16 %h, %conv
  %or.i = tail call i16 @llvm.fshl.i16(i16 %xor.i, i16 %xor.i, i16 1)
  %mul.i.i = mul i16 %or.i, 25173
  %add.i = add i16 %mul.i.i, 13849
  %shr = lshr i32 %v, 16
  %conv2 = trunc nuw i32 %shr to i16
  %xor.i6 = xor i16 %add.i, %conv2
  %or.i7 = tail call i16 @llvm.fshl.i16(i16 %xor.i6, i16 %xor.i6, i16 1)
  %mul.i.i8 = mul i16 %or.i7, 25173
  %add.i9 = add i16 %mul.i.i8, 13849
  ret i16 %add.i9
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define internal fastcc i16 @ov_mix64(i16 noundef %h, i64 noundef %v) unnamed_addr #1 {
entry:
  %conv = trunc i64 %v to i32
  %call = tail call fastcc i16 @ov_mix32(i16 noundef %h, i32 noundef %conv) #5
  %shr = lshr i64 %v, 32
  %conv2 = trunc nuw i64 %shr to i32
  %call3 = tail call fastcc i16 @ov_mix32(i16 noundef %call, i32 noundef %conv2) #5
  ret i16 %call3
}

; Function Attrs: minsize mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @ov_kernel(i16 noundef %s) unnamed_addr #2 {
entry:
  %and = and i16 %s, 511
  %add = add nuw nsw i16 %and, 1
  %shr = lshr i16 %s, 5
  %and1 = and i16 %shr, 1023
  %0 = load i16, ptr @ov_u16, align 1, !tbaa !7
  %mul = shl nuw i16 %and1, 6
  %sub = xor i16 %mul, -1
  %1 = tail call { i16, i1 } @llvm.uadd.with.overflow.i16(i16 %0, i16 %sub)
  %2 = extractvalue { i16, i1 } %1, 1
  %3 = extractvalue { i16, i1 } %1, 0
  %ov_fire.ov_clean = select i1 %2, ptr @ov_fire, ptr @ov_clean
  %4 = load i16, ptr %ov_fire.ov_clean, align 1, !tbaa !7
  %add3 = add i16 %4, 1
  store i16 %add3, ptr %ov_fire.ov_clean, align 1, !tbaa !7
  %5 = load i32, ptr @ov_res, align 1, !tbaa !8
  %mul4 = mul i32 %5, 3
  %conv6 = zext i16 %3 to i32
  %add7 = add i32 %mul4, %conv6
  store i32 %add7, ptr @ov_res, align 1, !tbaa !8
  store i16 %3, ptr @ov_u16, align 1, !tbaa !7
  %6 = load i16, ptr @ov_i16, align 1, !tbaa !7
  %or = or i16 %6, 1
  %sub11 = xor i16 %and1, 32767
  %7 = tail call { i16, i1 } @llvm.sadd.with.overflow.i16(i16 %or, i16 %sub11)
  %8 = extractvalue { i16, i1 } %7, 1
  %9 = extractvalue { i16, i1 } %7, 0
  br i1 %8, label %if.then13, label %if.else15

if.then13:                                        ; preds = %entry
  %10 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 2), align 1, !tbaa !7
  %add14 = add i16 %10, 1
  store i16 %add14, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 2), align 1, !tbaa !7
  br label %if.end17

if.else15:                                        ; preds = %entry
  %11 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 2), align 1, !tbaa !7
  %add16 = add i16 %11, 1
  store i16 %add16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 2), align 1, !tbaa !7
  br label %if.end17

if.end17:                                         ; preds = %if.else15, %if.then13
  %12 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 4), align 1, !tbaa !8
  %mul18 = mul i32 %12, 3
  %conv19 = sext i16 %9 to i32
  %add22 = add i32 %mul18, %conv19
  store i32 %add22, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 4), align 1, !tbaa !8
  store i16 %9, ptr @ov_i16, align 1, !tbaa !7
  %13 = load i32, ptr @ov_u32, align 1, !tbaa !8
  %conv28 = zext nneg i16 %and1 to i32
  %mul29 = shl nuw i32 %conv28, 22
  %sub30 = xor i32 %mul29, -1
  %14 = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %13, i32 %sub30)
  %15 = extractvalue { i32, i1 } %14, 1
  %16 = extractvalue { i32, i1 } %14, 0
  br i1 %15, label %if.then32, label %if.else34

if.then32:                                        ; preds = %if.end17
  %17 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 4), align 1, !tbaa !7
  %add33 = add i16 %17, 1
  store i16 %add33, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 4), align 1, !tbaa !7
  br label %if.end36

if.else34:                                        ; preds = %if.end17
  %18 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 4), align 1, !tbaa !7
  %add35 = add i16 %18, 1
  store i16 %add35, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 4), align 1, !tbaa !7
  br label %if.end36

if.end36:                                         ; preds = %if.else34, %if.then32
  %19 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 8), align 1, !tbaa !8
  %mul37 = mul i32 %19, 3
  %add41 = add i32 %mul37, %16
  store i32 %add41, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 8), align 1, !tbaa !8
  store i32 %16, ptr @ov_u32, align 1, !tbaa !8
  %20 = load i32, ptr @ov_i32, align 1, !tbaa !8
  %or46 = or i32 %20, 1
  %mul49 = shl nuw nsw i32 %conv28, 16
  %sub50 = xor i32 %mul49, 2147483647
  %21 = tail call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %or46, i32 %sub50)
  %22 = extractvalue { i32, i1 } %21, 1
  %23 = extractvalue { i32, i1 } %21, 0
  br i1 %22, label %if.then52, label %if.else54

if.then52:                                        ; preds = %if.end36
  %24 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 6), align 1, !tbaa !7
  %add53 = add i16 %24, 1
  store i16 %add53, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 6), align 1, !tbaa !7
  br label %if.end56

if.else54:                                        ; preds = %if.end36
  %25 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 6), align 1, !tbaa !7
  %add55 = add i16 %25, 1
  store i16 %add55, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 6), align 1, !tbaa !7
  br label %if.end56

if.end56:                                         ; preds = %if.else54, %if.then52
  %26 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 12), align 1, !tbaa !8
  %mul57 = mul i32 %26, 3
  %add61 = add i32 %mul57, %23
  store i32 %add61, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 12), align 1, !tbaa !8
  store i32 %23, ptr @ov_i32, align 1, !tbaa !8
  %27 = load i64, ptr @ov_u64, align 8, !tbaa !12
  %conv67 = zext nneg i16 %and1 to i64
  %mul68 = shl nuw i64 %conv67, 54
  %sub69 = xor i64 %mul68, -1
  %28 = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %27, i64 %sub69)
  %29 = extractvalue { i64, i1 } %28, 1
  %30 = extractvalue { i64, i1 } %28, 0
  br i1 %29, label %if.then71, label %if.else73

if.then71:                                        ; preds = %if.end56
  %31 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 8), align 1, !tbaa !7
  %add72 = add i16 %31, 1
  store i16 %add72, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 8), align 1, !tbaa !7
  br label %if.end75

if.else73:                                        ; preds = %if.end56
  %32 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 8), align 1, !tbaa !7
  %add74 = add i16 %32, 1
  store i16 %add74, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 8), align 1, !tbaa !7
  br label %if.end75

if.end75:                                         ; preds = %if.else73, %if.then71
  %33 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 16), align 1, !tbaa !8
  %mul76 = mul i32 %33, 3
  %conv78 = trunc i64 %30 to i32
  %add79 = add i32 %mul76, %conv78
  store i32 %add79, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 16), align 1, !tbaa !8
  store i64 %30, ptr @ov_u64, align 8, !tbaa !12
  %34 = load i64, ptr @ov_i64, align 8, !tbaa !12
  %or84 = or i64 %34, 1
  %mul87 = shl nuw nsw i64 %conv67, 48
  %sub88 = xor i64 %mul87, 9223372036854775807
  %35 = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %or84, i64 %sub88)
  %36 = extractvalue { i64, i1 } %35, 1
  %37 = extractvalue { i64, i1 } %35, 0
  br i1 %36, label %if.then90, label %if.else92

if.then90:                                        ; preds = %if.end75
  %38 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 10), align 1, !tbaa !7
  %add91 = add i16 %38, 1
  store i16 %add91, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 10), align 1, !tbaa !7
  br label %if.end94

if.else92:                                        ; preds = %if.end75
  %39 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 10), align 1, !tbaa !7
  %add93 = add i16 %39, 1
  store i16 %add93, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 10), align 1, !tbaa !7
  br label %if.end94

if.end94:                                         ; preds = %if.else92, %if.then90
  %40 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 20), align 1, !tbaa !8
  %mul95 = mul i32 %40, 3
  %conv97 = trunc i64 %37 to i32
  %add98 = add i32 %mul95, %conv97
  store i32 %add98, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 20), align 1, !tbaa !8
  store i64 %37, ptr @ov_i64, align 8, !tbaa !12
  %xor = xor i16 %3, %add
  %41 = tail call { i16, i1 } @llvm.usub.with.overflow.i16(i16 %xor, i16 %mul)
  %42 = extractvalue { i16, i1 } %41, 1
  %43 = extractvalue { i16, i1 } %41, 0
  br i1 %42, label %if.then106, label %if.else108

if.then106:                                       ; preds = %if.end94
  %44 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 12), align 1, !tbaa !7
  %add107 = add i16 %44, 1
  store i16 %add107, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 12), align 1, !tbaa !7
  br label %if.end110

if.else108:                                       ; preds = %if.end94
  %45 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 12), align 1, !tbaa !7
  %add109 = add i16 %45, 1
  store i16 %add109, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 12), align 1, !tbaa !7
  br label %if.end110

if.end110:                                        ; preds = %if.else108, %if.then106
  %46 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 24), align 1, !tbaa !8
  %mul111 = mul i32 %46, 3
  %conv114 = zext i16 %43 to i32
  %add115 = add i32 %mul111, %conv114
  store i32 %add115, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 24), align 1, !tbaa !8
  store i16 %43, ptr @ov_u16, align 1, !tbaa !7
  %or120 = or i16 %9, 1
  %47 = or disjoint i16 %and1, -32768
  %48 = tail call { i16, i1 } @llvm.ssub.with.overflow.i16(i16 %or120, i16 %47)
  %49 = extractvalue { i16, i1 } %48, 1
  %50 = extractvalue { i16, i1 } %48, 0
  br i1 %49, label %if.then126, label %if.else128

if.then126:                                       ; preds = %if.end110
  %51 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 14), align 1, !tbaa !7
  %add127 = add i16 %51, 1
  store i16 %add127, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 14), align 1, !tbaa !7
  br label %if.end130

if.else128:                                       ; preds = %if.end110
  %52 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 14), align 1, !tbaa !7
  %add129 = add i16 %52, 1
  store i16 %add129, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 14), align 1, !tbaa !7
  br label %if.end130

if.end130:                                        ; preds = %if.else128, %if.then126
  %53 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 28), align 1, !tbaa !8
  %mul131 = mul i32 %53, 3
  %conv132 = sext i16 %50 to i32
  %add135 = add i32 %mul131, %conv132
  store i32 %add135, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 28), align 1, !tbaa !8
  store i16 %50, ptr @ov_i16, align 1, !tbaa !7
  %conv140 = zext nneg i16 %add to i32
  %xor141 = xor i32 %16, %conv140
  %54 = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %xor141, i32 %mul29)
  %55 = extractvalue { i32, i1 } %54, 1
  %56 = extractvalue { i32, i1 } %54, 0
  br i1 %55, label %if.then146, label %if.else148

if.then146:                                       ; preds = %if.end130
  %57 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 16), align 1, !tbaa !7
  %add147 = add i16 %57, 1
  store i16 %add147, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 16), align 1, !tbaa !7
  br label %if.end150

if.else148:                                       ; preds = %if.end130
  %58 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 16), align 1, !tbaa !7
  %add149 = add i16 %58, 1
  store i16 %add149, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 16), align 1, !tbaa !7
  br label %if.end150

if.end150:                                        ; preds = %if.else148, %if.then146
  %59 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 32), align 1, !tbaa !8
  %mul151 = mul i32 %59, 3
  %add155 = add i32 %mul151, %56
  store i32 %add155, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 32), align 1, !tbaa !8
  store i32 %56, ptr @ov_u32, align 1, !tbaa !8
  %or160 = or disjoint i32 %23, 1
  %add164 = or disjoint i32 %mul49, -2147483648
  %60 = tail call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %or160, i32 %add164)
  %61 = extractvalue { i32, i1 } %60, 1
  %62 = extractvalue { i32, i1 } %60, 0
  br i1 %61, label %if.then166, label %if.else168

if.then166:                                       ; preds = %if.end150
  %63 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 18), align 1, !tbaa !7
  %add167 = add i16 %63, 1
  store i16 %add167, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 18), align 1, !tbaa !7
  br label %if.end170

if.else168:                                       ; preds = %if.end150
  %64 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 18), align 1, !tbaa !7
  %add169 = add i16 %64, 1
  store i16 %add169, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 18), align 1, !tbaa !7
  br label %if.end170

if.end170:                                        ; preds = %if.else168, %if.then166
  %65 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 36), align 1, !tbaa !8
  %mul171 = mul i32 %65, 3
  %add175 = add i32 %mul171, %62
  store i32 %add175, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 36), align 1, !tbaa !8
  store i32 %62, ptr @ov_i32, align 1, !tbaa !8
  %conv180 = zext nneg i16 %add to i64
  %xor181 = xor i64 %30, %conv180
  %66 = tail call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %xor181, i64 %mul68)
  %67 = extractvalue { i64, i1 } %66, 1
  %68 = extractvalue { i64, i1 } %66, 0
  br i1 %67, label %if.then186, label %if.else188

if.then186:                                       ; preds = %if.end170
  %69 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 20), align 1, !tbaa !7
  %add187 = add i16 %69, 1
  store i16 %add187, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 20), align 1, !tbaa !7
  br label %if.end190

if.else188:                                       ; preds = %if.end170
  %70 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 20), align 1, !tbaa !7
  %add189 = add i16 %70, 1
  store i16 %add189, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 20), align 1, !tbaa !7
  br label %if.end190

if.end190:                                        ; preds = %if.else188, %if.then186
  %71 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 40), align 1, !tbaa !8
  %mul191 = mul i32 %71, 3
  %conv193 = trunc i64 %68 to i32
  %add194 = add i32 %mul191, %conv193
  store i32 %add194, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 40), align 1, !tbaa !8
  store i64 %68, ptr @ov_u64, align 8, !tbaa !12
  %or199 = or disjoint i64 %37, 1
  %add203 = or disjoint i64 %mul87, -9223372036854775808
  %72 = tail call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %or199, i64 %add203)
  %73 = extractvalue { i64, i1 } %72, 1
  %74 = extractvalue { i64, i1 } %72, 0
  br i1 %73, label %if.then205, label %if.else207

if.then205:                                       ; preds = %if.end190
  %75 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 22), align 1, !tbaa !7
  %add206 = add i16 %75, 1
  store i16 %add206, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 22), align 1, !tbaa !7
  br label %if.end209

if.else207:                                       ; preds = %if.end190
  %76 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 22), align 1, !tbaa !7
  %add208 = add i16 %76, 1
  store i16 %add208, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 22), align 1, !tbaa !7
  br label %if.end209

if.end209:                                        ; preds = %if.else207, %if.then205
  %77 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 44), align 1, !tbaa !8
  %mul210 = mul i32 %77, 3
  %conv212 = trunc i64 %74 to i32
  %add213 = add i32 %mul210, %conv212
  store i32 %add213, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 44), align 1, !tbaa !8
  store i64 %74, ptr @ov_i64, align 8, !tbaa !12
  %and218 = and i16 %43, 1022
  %or219 = or disjoint i16 %and218, 1
  %or221 = or i16 %add, 1
  %78 = tail call { i16, i1 } @llvm.umul.with.overflow.i16(i16 %or219, i16 %or221)
  %79 = extractvalue { i16, i1 } %78, 1
  %80 = extractvalue { i16, i1 } %78, 0
  br i1 %79, label %if.then223, label %if.else225

if.then223:                                       ; preds = %if.end209
  %81 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 24), align 1, !tbaa !7
  %add224 = add i16 %81, 1
  store i16 %add224, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 24), align 1, !tbaa !7
  br label %if.end227

if.else225:                                       ; preds = %if.end209
  %82 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 24), align 1, !tbaa !7
  %add226 = add i16 %82, 1
  store i16 %add226, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 24), align 1, !tbaa !7
  br label %if.end227

if.end227:                                        ; preds = %if.else225, %if.then223
  %83 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 48), align 1, !tbaa !8
  %mul228 = mul i32 %83, 3
  %conv231 = zext i16 %80 to i32
  %add232 = add i32 %mul228, %conv231
  store i32 %add232, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 48), align 1, !tbaa !8
  store i16 %80, ptr @ov_u16, align 1, !tbaa !7
  %and237 = and i16 %50, 1022
  %or238 = or disjoint i16 %and237, 1
  %sub241 = add nsw i16 %or221, -256
  %84 = tail call { i16, i1 } @llvm.smul.with.overflow.i16(i16 %or238, i16 %sub241)
  %85 = extractvalue { i16, i1 } %84, 1
  %86 = extractvalue { i16, i1 } %84, 0
  br i1 %85, label %if.then243, label %if.else245

if.then243:                                       ; preds = %if.end227
  %87 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 26), align 1, !tbaa !7
  %add244 = add i16 %87, 1
  store i16 %add244, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 26), align 1, !tbaa !7
  br label %if.end247

if.else245:                                       ; preds = %if.end227
  %88 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 26), align 1, !tbaa !7
  %add246 = add i16 %88, 1
  store i16 %add246, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 26), align 1, !tbaa !7
  br label %if.end247

if.end247:                                        ; preds = %if.else245, %if.then243
  %89 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 52), align 1, !tbaa !8
  %mul248 = mul i32 %89, 3
  %conv249 = sext i16 %86 to i32
  %add252 = add i32 %mul248, %conv249
  store i32 %add252, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 52), align 1, !tbaa !8
  store i16 %86, ptr @ov_i16, align 1, !tbaa !7
  %and257 = and i32 %56, 67108862
  %or258 = or disjoint i32 %and257, 1
  %conv261 = zext nneg i16 %or221 to i32
  %90 = tail call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %or258, i32 %conv261)
  %91 = extractvalue { i32, i1 } %90, 1
  %92 = extractvalue { i32, i1 } %90, 0
  br i1 %91, label %if.then263, label %if.else265

if.then263:                                       ; preds = %if.end247
  %93 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 28), align 1, !tbaa !7
  %add264 = add i16 %93, 1
  store i16 %add264, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 28), align 1, !tbaa !7
  br label %if.end267

if.else265:                                       ; preds = %if.end247
  %94 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 28), align 1, !tbaa !7
  %add266 = add i16 %94, 1
  store i16 %add266, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 28), align 1, !tbaa !7
  br label %if.end267

if.end267:                                        ; preds = %if.else265, %if.then263
  %95 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 56), align 1, !tbaa !8
  %mul268 = mul i32 %95, 3
  %add272 = add i32 %mul268, %92
  store i32 %add272, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 56), align 1, !tbaa !8
  store i32 %92, ptr @ov_u32, align 1, !tbaa !8
  %or278 = and i32 %62, 67108863
  %sub282 = add nsw i32 %conv261, -256
  %96 = tail call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %or278, i32 %sub282)
  %97 = extractvalue { i32, i1 } %96, 1
  %98 = extractvalue { i32, i1 } %96, 0
  br i1 %97, label %if.then284, label %if.else286

if.then284:                                       ; preds = %if.end267
  %99 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 30), align 1, !tbaa !7
  %add285 = add i16 %99, 1
  store i16 %add285, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 30), align 1, !tbaa !7
  br label %if.end288

if.else286:                                       ; preds = %if.end267
  %100 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 30), align 1, !tbaa !7
  %add287 = add i16 %100, 1
  store i16 %add287, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 30), align 1, !tbaa !7
  br label %if.end288

if.end288:                                        ; preds = %if.else286, %if.then284
  %101 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 60), align 1, !tbaa !8
  %mul289 = mul i32 %101, 3
  %add293 = add i32 %mul289, %98
  store i32 %add293, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 60), align 1, !tbaa !8
  store i32 %98, ptr @ov_i32, align 1, !tbaa !8
  %and298 = and i64 %68, 288230376151711742
  %or299 = or disjoint i64 %and298, 1
  %conv302 = zext nneg i16 %or221 to i64
  %102 = tail call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %or299, i64 %conv302)
  %103 = extractvalue { i64, i1 } %102, 1
  %104 = extractvalue { i64, i1 } %102, 0
  br i1 %103, label %if.then304, label %if.else306

if.then304:                                       ; preds = %if.end288
  %105 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 32), align 1, !tbaa !7
  %add305 = add i16 %105, 1
  store i16 %add305, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 32), align 1, !tbaa !7
  br label %if.end308

if.else306:                                       ; preds = %if.end288
  %106 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 32), align 1, !tbaa !7
  %add307 = add i16 %106, 1
  store i16 %add307, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 32), align 1, !tbaa !7
  br label %if.end308

if.end308:                                        ; preds = %if.else306, %if.then304
  %107 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 64), align 1, !tbaa !8
  %mul309 = mul i32 %107, 3
  %conv311 = trunc i64 %104 to i32
  %add312 = add i32 %mul309, %conv311
  store i32 %add312, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 64), align 1, !tbaa !8
  store i64 %104, ptr @ov_u64, align 8, !tbaa !12
  %or318 = and i64 %74, 288230376151711743
  %conv323 = sext i32 %sub282 to i64
  %108 = tail call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %or318, i64 %conv323)
  %109 = extractvalue { i64, i1 } %108, 1
  br i1 %109, label %if.then325, label %if.else327

if.then325:                                       ; preds = %if.end308
  %110 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 34), align 1, !tbaa !7
  %add326 = add i16 %110, 1
  store i16 %add326, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 34), align 1, !tbaa !7
  br label %if.end329

if.else327:                                       ; preds = %if.end308
  %111 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 34), align 1, !tbaa !7
  %add328 = add i16 %111, 1
  store i16 %add328, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 34), align 1, !tbaa !7
  br label %if.end329

if.end329:                                        ; preds = %if.else327, %if.then325
  %112 = extractvalue { i64, i1 } %108, 0
  %113 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 68), align 1, !tbaa !8
  %mul330 = mul i32 %113, 3
  %conv332 = trunc i64 %112 to i32
  %add333 = add i32 %mul330, %conv332
  store i32 %add333, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 68), align 1, !tbaa !8
  store i64 %112, ptr @ov_i64, align 8, !tbaa !12
  ret void
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.uadd.with.overflow.i16(i16, i16) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.sadd.with.overflow.i16(i16, i16) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.uadd.with.overflow.i32(i32, i32) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.usub.with.overflow.i16(i16, i16) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.ssub.with.overflow.i16(i16, i16) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.usub.with.overflow.i32(i32, i32) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.usub.with.overflow.i64(i64, i64) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.umul.with.overflow.i16(i16, i16) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.smul.with.overflow.i16(i16, i16) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #4

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #2 = { minsize mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #3 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { minsize optsize }
attributes #6 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 155e209c4cee8eeac01397aac3542e76841a9856)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!4, !4, i64 0}
!8 = !{!9, !9, i64 0}
!9 = !{!"long", !5, i64 0}
!10 = distinct !{!10, !11}
!11 = !{!"llvm.loop.mustprogress"}
!12 = !{!13, !13, i64 0}
!13 = !{!"long long", !5, i64 0}
!14 = distinct !{!14, !11}
!15 = distinct !{!15, !11}
!16 = !{i64 1246}
