# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/structs.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/structs.c" 2
# 12 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/structs.c"
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 1 3
# 100 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef long long int int64_t;

typedef long long unsigned int uint64_t;
# 122 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int64_t int_least64_t;
typedef uint64_t uint_least64_t;
typedef int64_t int_fast64_t;
typedef uint64_t uint_fast64_t;
# 197 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef long int int32_t;




typedef long unsigned int uint32_t;
# 220 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int32_t int_least32_t;
typedef uint32_t uint_least32_t;
typedef int32_t int_fast32_t;
typedef uint32_t uint_fast32_t;
# 245 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int int16_t;

typedef unsigned int uint16_t;
# 259 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int16_t int_least16_t;
typedef uint16_t uint_least16_t;
typedef int16_t int_fast16_t;
typedef uint16_t uint_fast16_t;





typedef signed char int8_t;

typedef unsigned char uint8_t;







typedef int8_t int_least8_t;
typedef uint8_t uint_least8_t;
typedef int8_t int_fast8_t;
typedef uint8_t uint_fast8_t;
# 295 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int intptr_t;






typedef unsigned int uintptr_t;





typedef long long int intmax_t;
typedef long long unsigned int uintmax_t;
# 13 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/structs.c" 2

struct point { uint8_t x; uint16_t y; uint8_t tag; };

static volatile struct point pts[3] = { {1, 100, 7}, {2, 200, 8}, {3, 300, 9} };
volatile uint8_t bump = 2;
volatile uint16_t corpus_result;

int main(void) {
  uint16_t r = 0;
  uint8_t i;

  volatile struct point *p = pts;
  for (i = 0; i < 3; i++) {
    r += p->x;
    r += p->y;
    r += p->tag;
    p++;
  }

  pts[1].y = (uint16_t)(pts[1].y + bump);
  r += pts[1].y;

  corpus_result = r;
  for (;;) __asm__ volatile("");
}
