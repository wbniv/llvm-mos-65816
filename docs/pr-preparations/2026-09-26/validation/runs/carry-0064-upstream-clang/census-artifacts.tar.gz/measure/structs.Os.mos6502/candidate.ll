; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/structs.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/structs.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.point = type { i8, i16, i8 }

@bump = dso_local global i8 2, align 1
@pts = internal global [3 x %struct.point] [%struct.point { i8 1, i16 100, i8 7 }, %struct.point { i8 2, i16 200, i8 8 }, %struct.point { i8 3, i16 300, i8 9 }], align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  br label %for.body

for.body:                                         ; preds = %entry, %for.body
  %mos-indexiv.iv = phi i8 [ 0, %entry ], [ %mos-indexiv.iv.next, %for.body ]
  %p.020 = phi ptr [ @pts, %entry ], [ %uglygep22, %for.body ]
  %i.019 = phi i8 [ 0, %entry ], [ %inc, %for.body ]
  %r.018 = phi i16 [ 0, %entry ], [ %add5, %for.body ]
  %0 = load volatile i8, ptr %p.020, align 1, !tbaa !7
  %conv2 = zext i8 %0 to i16
  %add = add i16 %r.018, %conv2
  %1 = zext nneg i8 %mos-indexiv.iv to i16
  %uglygep = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 1), i16 %1
  %2 = load volatile i16, ptr %uglygep, align 1, !tbaa !9
  %add3 = add i16 %add, %2
  %uglygep21 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 3), i16 %1
  %3 = load volatile i8, ptr %uglygep21, align 1, !tbaa !10
  %conv4 = zext i8 %3 to i16
  %add5 = add i16 %add3, %conv4
  %uglygep22 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 4), i16 %1
  %inc = add nuw nsw i8 %i.019, 1
  %exitcond.not = icmp eq i8 %inc, 3
  %mos-indexiv.iv.next = add nuw nsw i8 %mos-indexiv.iv, 4
  br i1 %exitcond.not, label %for.end, label %for.body, !llvm.loop !11

for.end:                                          ; preds = %for.body
  %4 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !9
  %5 = load volatile i8, ptr @bump, align 1, !tbaa !13
  %conv6 = zext i8 %5 to i16
  %add7 = add i16 %4, %conv6
  store volatile i16 %add7, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !9
  %6 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !9
  %add8 = add i16 %6, %add5
  store volatile i16 %add8, ptr @corpus_result, align 1, !tbaa !14
  br label %for.cond9

for.cond9:                                        ; preds = %for.cond9, %for.end
  tail call void asm sideeffect "", ""() #1, !srcloc !15
  br label %for.cond9
}

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 155e209c4cee8eeac01397aac3542e76841a9856)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!8, !5, i64 0}
!8 = !{!"point", !5, i64 0, !4, i64 1, !5, i64 3}
!9 = !{!8, !4, i64 1}
!10 = !{!8, !5, i64 3}
!11 = distinct !{!11, !12}
!12 = !{!"llvm.loop.mustprogress"}
!13 = !{!5, !5, i64 0}
!14 = !{!4, !4, i64 0}
!15 = !{i64 1177}
