# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/bitweave_sim.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 368 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/bitweave_sim.c" 2






# 1 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/bitweave.h" 1
# 22 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/bitweave.h"
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 1 3
# 100 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef long long int int64_t;

typedef long long unsigned int uint64_t;
# 122 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int64_t int_least64_t;
typedef uint64_t uint_least64_t;
typedef int64_t int_fast64_t;
typedef uint64_t uint_fast64_t;
# 197 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef long int int32_t;




typedef long unsigned int uint32_t;
# 220 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int32_t int_least32_t;
typedef uint32_t uint_least32_t;
typedef int32_t int_fast32_t;
typedef uint32_t uint_fast32_t;
# 245 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int int16_t;

typedef unsigned int uint16_t;
# 259 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int16_t int_least16_t;
typedef uint16_t uint_least16_t;
typedef int16_t int_fast16_t;
typedef uint16_t uint_fast16_t;





typedef signed char int8_t;

typedef unsigned char uint8_t;







typedef int8_t int_least8_t;
typedef uint8_t uint_least8_t;
typedef int8_t int_fast8_t;
typedef uint8_t uint_fast8_t;
# 295 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int intptr_t;






typedef unsigned int uintptr_t;





typedef long long int intmax_t;
typedef long long unsigned int uintmax_t;
# 23 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/bitweave.h" 2


static inline uint8_t bw_rev8(uint8_t v) {
    uint8_t rev = (uint8_t)0u;
    for (uint8_t i = (uint8_t)0u; i < (uint8_t)8u; i++) {
        rev = (uint8_t)((uint8_t)(rev << 1) | (uint8_t)(v & (uint8_t)1u));
        v = (uint8_t)(v >> 1);
    }
    return rev;
}


static inline uint16_t bw_rev16(uint16_t v) {
    uint16_t rev = (uint16_t)0u;
    for (uint8_t i = (uint8_t)0u; i < (uint8_t)16u; i++) {
        rev = (uint16_t)((uint16_t)(rev << 1) | (uint16_t)(v & (uint16_t)1u));
        v = (uint16_t)(v >> 1);
    }
    return rev;
}



__attribute__((noinline))
static void bw_weave(uint8_t *a8, uint16_t *a16) {
    uint8_t v8 = *a8, r8 = (uint8_t)0u;
    uint16_t v16 = *a16, r16 = (uint16_t)0u;
    for (uint8_t i = (uint8_t)0u; i < (uint8_t)16u; i++) {
        if (i < (uint8_t)8u) {
            r8 = (uint8_t)((uint8_t)(r8 << 1) | (uint8_t)(v8 & (uint8_t)1u));
            v8 = (uint8_t)(v8 >> 1);
        }
        r16 = (uint16_t)((uint16_t)(r16 << 1) | (uint16_t)(v16 & (uint16_t)1u));
        v16 = (uint16_t)(v16 >> 1);
    }
    *a8 = r8; *a16 = r16;
}

static inline uint16_t bw_fold(uint16_t h, uint16_t v) {
    return (uint16_t)((((uint16_t)(h << 1)) | (uint16_t)((h >> 15) & 1u)) ^ v);
}
# 73 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/bitweave.h"
static uint16_t bitweave_gate_crc(void) {
    uint16_t h = (uint16_t)0u;
    uint16_t seed = (uint16_t)0xACE1u;
    for (uint16_t i = (uint16_t)0u; i < (uint16_t)128u; i++) {
        seed = (uint16_t)(seed * 25173u + 13849u);
        uint8_t a8 = (uint8_t)(seed >> 5);
        uint16_t a16 = seed;
        uint8_t o8 = a8;
        uint16_t o16 = a16;
        bw_weave(&a8, &a16);
        h = bw_fold(h, (uint16_t)a8);
        h = bw_fold(h, a16);
        bw_weave(&a8, &a16);
        h = bw_fold(h, (uint16_t)((uint16_t)(a8 ^ o8)));
        h = bw_fold(h, (uint16_t)(a16 ^ o16));
    }
    return h;
}
# 8 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/bitweave_sim.c" 2
volatile uint16_t corpus_result;
int main(void){ corpus_result = bitweave_gate_crc(); for (;;) __asm__ volatile(""); return 0; }
