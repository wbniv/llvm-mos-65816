; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/control.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/control.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@n = dso_local global i16 100, align 1
@sel = dso_local global i8 3, align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  br label %for.cond

for.cond:                                         ; preds = %for.body, %entry
  %r.0 = phi i16 [ 0, %entry ], [ %add, %for.body ]
  %i.0 = phi i16 [ 1, %entry ], [ %inc, %for.body ]
  %0 = load volatile i16, ptr @n, align 1, !tbaa !7
  %cmp.not = icmp ugt i16 %i.0, %0
  br i1 %cmp.not, label %for.end, label %for.body

for.body:                                         ; preds = %for.cond
  %add = add i16 %i.0, %r.0
  %inc = add i16 %i.0, 1
  br label %for.cond, !llvm.loop !8

for.end:                                          ; preds = %for.cond
  %1 = load volatile i16, ptr @n, align 1, !tbaa !7
  br label %while.cond

while.cond:                                       ; preds = %if.end, %for.end
  %w.0 = phi i16 [ %1, %for.end ], [ %dec, %if.end ]
  %ev.0 = phi i16 [ 0, %for.end ], [ %ev.1, %if.end ]
  %cmp1.not = icmp eq i16 %w.0, 0
  br i1 %cmp1.not, label %while.end, label %while.body

while.body:                                       ; preds = %while.cond
  %and = and i16 %w.0, 1
  %cmp2 = icmp eq i16 %and, 0
  br i1 %cmp2, label %if.then, label %if.end

if.then:                                          ; preds = %while.body
  %add3 = add i16 %ev.0, %w.0
  br label %if.end

if.end:                                           ; preds = %if.then, %while.body
  %ev.1 = phi i16 [ %add3, %if.then ], [ %ev.0, %while.body ]
  %dec = add i16 %w.0, -1
  br label %while.cond, !llvm.loop !10

while.end:                                        ; preds = %while.cond
  %add4 = add i16 %ev.0, %r.0
  %add8 = add i16 %add4, 45
  %2 = load volatile i8, ptr @sel, align 1, !tbaa !11
  %switch.tableidx = add i8 %2, -1
  %3 = icmp ult i8 %switch.tableidx, 3
  br i1 %3, label %switch.lookup, label %sw.epilog

switch.lookup:                                    ; preds = %while.end
  %narrow = mul nuw nsw i8 %switch.tableidx, 10
  %narrow26 = add nuw nsw i8 %narrow, 10
  %switch.offset = zext nneg i8 %narrow26 to i16
  br label %sw.epilog

sw.epilog:                                        ; preds = %while.end, %switch.lookup
  %s.0 = phi i16 [ %switch.offset, %switch.lookup ], [ 0, %while.end ]
  %add11 = add i16 %add8, %s.0
  store volatile i16 %add11, ptr @corpus_result, align 1, !tbaa !7
  br label %for.cond12

for.cond12:                                       ; preds = %for.cond12, %sw.epilog
  tail call void asm sideeffect "", ""() #1, !srcloc !12
  br label %for.cond12
}

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 7bd67c0ae4e8bb65a3f980912bf201df22131e34)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!4, !4, i64 0}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = distinct !{!10, !9}
!11 = !{!5, !5, i64 0}
!12 = !{i64 1146}
