# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/bitshuffle_sim.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 368 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/bitshuffle_sim.c" 2




# 1 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/bitshuffle.h" 1
# 20 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/bitshuffle.h"
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 1 3
# 100 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef long long int int64_t;

typedef long long unsigned int uint64_t;
# 122 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int64_t int_least64_t;
typedef uint64_t uint_least64_t;
typedef int64_t int_fast64_t;
typedef uint64_t uint_fast64_t;
# 197 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef long int int32_t;




typedef long unsigned int uint32_t;
# 220 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int32_t int_least32_t;
typedef uint32_t uint_least32_t;
typedef int32_t int_fast32_t;
typedef uint32_t uint_fast32_t;
# 245 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int int16_t;

typedef unsigned int uint16_t;
# 259 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int16_t int_least16_t;
typedef uint16_t uint_least16_t;
typedef int16_t int_fast16_t;
typedef uint16_t uint_fast16_t;





typedef signed char int8_t;

typedef unsigned char uint8_t;







typedef int8_t int_least8_t;
typedef uint8_t uint_least8_t;
typedef int8_t int_fast8_t;
typedef uint8_t uint_fast8_t;
# 295 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int intptr_t;






typedef unsigned int uintptr_t;





typedef long long int intmax_t;
typedef long long unsigned int uintmax_t;
# 21 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/bitshuffle.h" 2
# 31 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/bitshuffle.h"
static inline uint32_t bitshuffle_bitrev32(uint32_t v) {

    return __builtin_bitreverse32(v);







}



static inline uint16_t bitshuffle_perm(uint16_t i) {
    uint32_t r = bitshuffle_bitrev32((uint32_t)i);
    return (uint16_t)(r >> (32u - 8u));
}


static inline uint32_t bitshuffle_bswap(uint32_t t) {
    return __builtin_bswap32(t);
}


static inline uint8_t bitshuffle_color(uint16_t x, uint16_t y, uint16_t t, uint8_t ncol) {
    uint32_t tok = ((uint32_t)(x & 0xFFu) << 24) | ((uint32_t)(y & 0xFFu) << 16)
                 | ((uint32_t)(t & 0xFFu) << 8) | 0xA5u;
    uint32_t s = __builtin_bswap32(tok);
    return (uint8_t)(((s >> 5) ^ (s >> 17)) % ncol);
}




static inline uint16_t bitshuffle_fold(uint16_t h, uint16_t x) {
    return (uint16_t)((((uint16_t)(h << 1)) | (uint16_t)((h >> 15) & 1u)) ^ x);
}
# 79 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/bitshuffle.h"
static uint16_t bitshuffle_gate_crc(void) {
    uint16_t h = 0;
    for (uint16_t i = 0; i < (uint16_t)256u; i++) {
        uint32_t base = ((uint32_t)i << 17) ^ ((uint32_t)i << 6) ^ (uint32_t)(i * 5u) ^ 0x9E3779B9u;
        uint32_t vr = bitshuffle_bitrev32(base);
        uint32_t vs = bitshuffle_bswap(base ^ 0x55AA33CCu);
        uint16_t p = bitshuffle_perm(i);
        uint16_t pp = bitshuffle_perm(p);
        h = bitshuffle_fold(h, (uint16_t)vr);
        h = bitshuffle_fold(h, (uint16_t)(vr >> 16));
        h = bitshuffle_fold(h, (uint16_t)vs);
        h = bitshuffle_fold(h, (uint16_t)(vs >> 16));
        h = bitshuffle_fold(h, (uint16_t)(p ^ (uint16_t)(pp << 8)));
    }
    return h;
}
# 6 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/bitshuffle_sim.c" 2

volatile uint16_t corpus_result;

int main(void) {
    corpus_result = bitshuffle_gate_crc();
    for (;;) __asm__ volatile("");
    return 0;
}
