; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/cordic_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/cordic_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  %call = tail call fastcc i16 @cordic_gate_crc()
  store volatile i16 %call, ptr @corpus_result, align 1, !tbaa !7
  br label %for.cond

for.cond:                                         ; preds = %for.cond, %entry
  tail call void asm sideeffect "", ""() #5, !srcloc !8
  br label %for.cond
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(none)
define internal fastcc i16 @cordic_gate_crc() unnamed_addr #1 {
entry:
  %s0.i = alloca i16, align 1
  %c0.i = alloca i16, align 1
  %base_s = alloca i16, align 1
  %base_c = alloca i16, align 1
  br label %for.body

for.cond.cleanup:                                 ; preds = %cordic16_atan2.exit
  ret i16 %xor.i12

for.body:                                         ; preds = %entry, %cordic16_atan2.exit
  %k.019 = phi i16 [ 0, %entry ], [ %inc, %cordic16_atan2.exit ]
  %h.018 = phi i16 [ 0, %entry ], [ %xor.i12, %cordic16_atan2.exit ]
  %o.sroa.0.017 = phi i16 [ 0, %entry ], [ %o.sroa.0.1, %cordic16_atan2.exit ]
  %o.sroa.8.016 = phi i8 [ 0, %entry ], [ %o.sroa.8.1, %cordic16_atan2.exit ]
  call void @llvm.lifetime.start.p0(ptr nonnull %base_s) #5
  call void @llvm.lifetime.start.p0(ptr nonnull %base_c) #5
  call fastcc void @cordic16_sincos(i16 noundef %o.sroa.0.017, ptr noundef %base_s, ptr noundef %base_c)
  call void @llvm.lifetime.start.p0(ptr nonnull %s0.i) #5
  call void @llvm.lifetime.start.p0(ptr nonnull %c0.i) #5
  call fastcc void @cordic16_sincos(i16 noundef %o.sroa.0.017, ptr noundef %s0.i, ptr noundef %c0.i)
  %0 = and i8 %o.sroa.8.016, 3
  switch i8 %0, label %default.unreachable [
    i8 0, label %sw.bb.i
    i8 1, label %sw.bb1.i
    i8 2, label %sw.bb2.i
    i8 3, label %sw.default.i
  ]

sw.bb.i:                                          ; preds = %for.body
  %1 = load i16, ptr %c0.i, align 1, !tbaa !7
  %2 = load i16, ptr %s0.i, align 1, !tbaa !7
  br label %sw.epilog.i

sw.bb1.i:                                         ; preds = %for.body
  %3 = load i16, ptr %s0.i, align 1, !tbaa !7
  %sub.i = sub nsw i16 0, %3
  %4 = load i16, ptr %c0.i, align 1, !tbaa !7
  br label %sw.epilog.i

sw.bb2.i:                                         ; preds = %for.body
  %5 = load i16, ptr %c0.i, align 1, !tbaa !7
  %sub3.i = sub nsw i16 0, %5
  %6 = load i16, ptr %s0.i, align 1, !tbaa !7
  %sub4.i = sub nsw i16 0, %6
  br label %sw.epilog.i

default.unreachable:                              ; preds = %for.body
  unreachable

sw.default.i:                                     ; preds = %for.body
  %7 = load i16, ptr %s0.i, align 1, !tbaa !7
  %8 = load i16, ptr %c0.i, align 1, !tbaa !7
  %sub5.i = sub nsw i16 0, %8
  br label %sw.epilog.i

sw.epilog.i:                                      ; preds = %sw.default.i, %sw.bb2.i, %sw.bb1.i, %sw.bb.i
  %c.0 = phi i16 [ %1, %sw.bb.i ], [ %sub.i, %sw.bb1.i ], [ %sub3.i, %sw.bb2.i ], [ %7, %sw.default.i ]
  %sub5.sink.i = phi i16 [ %2, %sw.bb.i ], [ %4, %sw.bb1.i ], [ %sub4.i, %sw.bb2.i ], [ %sub5.i, %sw.default.i ]
  %add.i = add nsw i16 %o.sroa.0.017, 1072
  %cmp.i = icmp sgt i16 %o.sroa.0.017, 24663
  br i1 %cmp.i, label %if.then.i, label %rotor_sincos.exit

if.then.i:                                        ; preds = %sw.epilog.i
  %sub11.i = add nsw i16 %o.sroa.0.017, -24664
  %add15.i = add i8 %o.sroa.8.016, 1
  br label %rotor_sincos.exit

rotor_sincos.exit:                                ; preds = %sw.epilog.i, %if.then.i
  %o.sroa.8.1 = phi i8 [ %add15.i, %if.then.i ], [ %o.sroa.8.016, %sw.epilog.i ]
  %o.sroa.0.1 = phi i16 [ %sub11.i, %if.then.i ], [ %add.i, %sw.epilog.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %c0.i) #5
  call void @llvm.lifetime.end.p0(ptr nonnull %s0.i) #5
  %or.i = tail call i16 @llvm.fshl.i16(i16 %h.018, i16 %h.018, i16 1)
  %xor.i = xor i16 %sub5.sink.i, %or.i
  %or.i9 = tail call i16 @llvm.fshl.i16(i16 %xor.i, i16 %xor.i, i16 1)
  %xor.i10 = xor i16 %or.i9, %c.0
  %9 = load i16, ptr %base_s, align 1, !tbaa !7
  %10 = load i16, ptr %base_c, align 1, !tbaa !7
  %shr.i = ashr i16 %10, 1
  %shr1.i = ashr i16 %9, 1
  %cmp.i.i = icmp slt i16 %shr1.i, 0
  br i1 %cmp.i.i, label %if.then.i.i, label %if.else.i.i

if.then.i.i:                                      ; preds = %rotor_sincos.exit
  %sub.i.i = sub nsw i16 %shr.i, %shr1.i
  %add.i.i = add nsw i16 %shr.i, %shr1.i
  br label %if.end.i.i

if.else.i.i:                                      ; preds = %rotor_sincos.exit
  %add3.i.i = add nsw i16 %shr.i, %shr1.i
  %sub4.i.i = sub nsw i16 %shr1.i, %shr.i
  br label %if.end.i.i

if.end.i.i:                                       ; preds = %if.else.i.i, %if.then.i.i
  %x.addr.0.i.i = phi i16 [ %sub.i.i, %if.then.i.i ], [ %add3.i.i, %if.else.i.i ]
  %y.addr.0.i.i = phi i16 [ %add.i.i, %if.then.i.i ], [ %sub4.i.i, %if.else.i.i ]
  %z.0.i.i = phi i16 [ -12868, %if.then.i.i ], [ 12868, %if.else.i.i ]
  %shr8.i.i = ashr i16 %x.addr.0.i.i, 1
  %shr10.i.i = ashr i16 %y.addr.0.i.i, 1
  %cmp11.i.i = icmp slt i16 %y.addr.0.i.i, 0
  br i1 %cmp11.i.i, label %if.then12.i.i, label %if.else16.i.i

if.then12.i.i:                                    ; preds = %if.end.i.i
  %sub13.i.i = sub nsw i16 %x.addr.0.i.i, %shr10.i.i
  %add14.i.i = add nsw i16 %y.addr.0.i.i, %shr8.i.i
  br label %if.end20.i.i

if.else16.i.i:                                    ; preds = %if.end.i.i
  %add17.i.i = add nsw i16 %shr10.i.i, %x.addr.0.i.i
  %sub18.i.i = sub nsw i16 %y.addr.0.i.i, %shr8.i.i
  br label %if.end20.i.i

if.end20.i.i:                                     ; preds = %if.else16.i.i, %if.then12.i.i
  %.sink.i.i = phi i16 [ 7596, %if.else16.i.i ], [ -7596, %if.then12.i.i ]
  %x.addr.1.i.i = phi i16 [ %add17.i.i, %if.else16.i.i ], [ %sub13.i.i, %if.then12.i.i ]
  %y.addr.1.i.i = phi i16 [ %sub18.i.i, %if.else16.i.i ], [ %add14.i.i, %if.then12.i.i ]
  %shr25.i.i = ashr i16 %x.addr.1.i.i, 2
  %shr27.i.i = ashr i16 %y.addr.1.i.i, 2
  %cmp28.i.i = icmp slt i16 %y.addr.1.i.i, 0
  br i1 %cmp28.i.i, label %if.then29.i.i, label %if.else33.i.i

if.then29.i.i:                                    ; preds = %if.end20.i.i
  %sub30.i.i = sub nsw i16 %x.addr.1.i.i, %shr27.i.i
  %add31.i.i = add nsw i16 %y.addr.1.i.i, %shr25.i.i
  br label %if.end37.i.i

if.else33.i.i:                                    ; preds = %if.end20.i.i
  %add34.i.i = add nsw i16 %shr27.i.i, %x.addr.1.i.i
  %sub35.i.i = sub nsw i16 %y.addr.1.i.i, %shr25.i.i
  br label %if.end37.i.i

if.end37.i.i:                                     ; preds = %if.else33.i.i, %if.then29.i.i
  %.sink407.i.i = phi i16 [ 4014, %if.else33.i.i ], [ -4014, %if.then29.i.i ]
  %x.addr.2.i.i = phi i16 [ %add34.i.i, %if.else33.i.i ], [ %sub30.i.i, %if.then29.i.i ]
  %y.addr.2.i.i = phi i16 [ %sub35.i.i, %if.else33.i.i ], [ %add31.i.i, %if.then29.i.i ]
  %shr42.i.i = ashr i16 %x.addr.2.i.i, 3
  %shr44.i.i = ashr i16 %y.addr.2.i.i, 3
  %cmp45.i.i = icmp slt i16 %y.addr.2.i.i, 0
  br i1 %cmp45.i.i, label %if.then46.i.i, label %if.else50.i.i

if.then46.i.i:                                    ; preds = %if.end37.i.i
  %sub47.i.i = sub nsw i16 %x.addr.2.i.i, %shr44.i.i
  %add48.i.i = add nsw i16 %y.addr.2.i.i, %shr42.i.i
  br label %if.end54.i.i

if.else50.i.i:                                    ; preds = %if.end37.i.i
  %add51.i.i = add nsw i16 %shr44.i.i, %x.addr.2.i.i
  %sub52.i.i = sub nsw i16 %y.addr.2.i.i, %shr42.i.i
  br label %if.end54.i.i

if.end54.i.i:                                     ; preds = %if.else50.i.i, %if.then46.i.i
  %.sink408.i.i = phi i16 [ 2037, %if.else50.i.i ], [ -2037, %if.then46.i.i ]
  %x.addr.3.i.i = phi i16 [ %add51.i.i, %if.else50.i.i ], [ %sub47.i.i, %if.then46.i.i ]
  %y.addr.3.i.i = phi i16 [ %sub52.i.i, %if.else50.i.i ], [ %add48.i.i, %if.then46.i.i ]
  %shr59.i.i = ashr i16 %x.addr.3.i.i, 4
  %shr61.i.i = ashr i16 %y.addr.3.i.i, 4
  %cmp62.i.i = icmp slt i16 %y.addr.3.i.i, 0
  br i1 %cmp62.i.i, label %if.then63.i.i, label %if.else67.i.i

if.then63.i.i:                                    ; preds = %if.end54.i.i
  %sub64.i.i = sub nsw i16 %x.addr.3.i.i, %shr61.i.i
  %add65.i.i = add nsw i16 %y.addr.3.i.i, %shr59.i.i
  br label %if.end71.i.i

if.else67.i.i:                                    ; preds = %if.end54.i.i
  %add68.i.i = add nsw i16 %shr61.i.i, %x.addr.3.i.i
  %sub69.i.i = sub nsw i16 %y.addr.3.i.i, %shr59.i.i
  br label %if.end71.i.i

if.end71.i.i:                                     ; preds = %if.else67.i.i, %if.then63.i.i
  %.sink409.i.i = phi i16 [ 1023, %if.else67.i.i ], [ -1023, %if.then63.i.i ]
  %x.addr.4.i.i = phi i16 [ %add68.i.i, %if.else67.i.i ], [ %sub64.i.i, %if.then63.i.i ]
  %y.addr.4.i.i = phi i16 [ %sub69.i.i, %if.else67.i.i ], [ %add65.i.i, %if.then63.i.i ]
  %shr76.i.i = ashr i16 %x.addr.4.i.i, 5
  %shr78.i.i = ashr i16 %y.addr.4.i.i, 5
  %cmp79.i.i = icmp slt i16 %y.addr.4.i.i, 0
  br i1 %cmp79.i.i, label %if.then80.i.i, label %if.else84.i.i

if.then80.i.i:                                    ; preds = %if.end71.i.i
  %sub81.i.i = sub nsw i16 %x.addr.4.i.i, %shr78.i.i
  %add82.i.i = add nsw i16 %y.addr.4.i.i, %shr76.i.i
  br label %if.end88.i.i

if.else84.i.i:                                    ; preds = %if.end71.i.i
  %add85.i.i = add nsw i16 %shr78.i.i, %x.addr.4.i.i
  %sub86.i.i = sub nsw i16 %y.addr.4.i.i, %shr76.i.i
  br label %if.end88.i.i

if.end88.i.i:                                     ; preds = %if.else84.i.i, %if.then80.i.i
  %.sink410.i.i = phi i16 [ 512, %if.else84.i.i ], [ -512, %if.then80.i.i ]
  %x.addr.5.i.i = phi i16 [ %add85.i.i, %if.else84.i.i ], [ %sub81.i.i, %if.then80.i.i ]
  %y.addr.5.i.i = phi i16 [ %sub86.i.i, %if.else84.i.i ], [ %add82.i.i, %if.then80.i.i ]
  %shr93.i.i = ashr i16 %x.addr.5.i.i, 6
  %shr95.i.i = ashr i16 %y.addr.5.i.i, 6
  %cmp96.i.i = icmp slt i16 %y.addr.5.i.i, 0
  br i1 %cmp96.i.i, label %if.then97.i.i, label %if.else101.i.i

if.then97.i.i:                                    ; preds = %if.end88.i.i
  %sub98.i.i = sub nsw i16 %x.addr.5.i.i, %shr95.i.i
  %add99.i.i = add nsw i16 %y.addr.5.i.i, %shr93.i.i
  br label %if.end105.i.i

if.else101.i.i:                                   ; preds = %if.end88.i.i
  %add102.i.i = add nsw i16 %shr95.i.i, %x.addr.5.i.i
  %sub103.i.i = sub nsw i16 %y.addr.5.i.i, %shr93.i.i
  br label %if.end105.i.i

if.end105.i.i:                                    ; preds = %if.else101.i.i, %if.then97.i.i
  %.sink411.i.i = phi i16 [ 256, %if.else101.i.i ], [ -256, %if.then97.i.i ]
  %x.addr.6.i.i = phi i16 [ %add102.i.i, %if.else101.i.i ], [ %sub98.i.i, %if.then97.i.i ]
  %y.addr.6.i.i = phi i16 [ %sub103.i.i, %if.else101.i.i ], [ %add99.i.i, %if.then97.i.i ]
  %shr110.i.i = ashr i16 %x.addr.6.i.i, 7
  %shr112.i.i = ashr i16 %y.addr.6.i.i, 7
  %cmp113.i.i = icmp slt i16 %y.addr.6.i.i, 0
  br i1 %cmp113.i.i, label %if.then114.i.i, label %if.else118.i.i

if.then114.i.i:                                   ; preds = %if.end105.i.i
  %sub115.i.i = sub nsw i16 %x.addr.6.i.i, %shr112.i.i
  %add116.i.i = add nsw i16 %y.addr.6.i.i, %shr110.i.i
  br label %if.end122.i.i

if.else118.i.i:                                   ; preds = %if.end105.i.i
  %add119.i.i = add nsw i16 %shr112.i.i, %x.addr.6.i.i
  %sub120.i.i = sub nsw i16 %y.addr.6.i.i, %shr110.i.i
  br label %if.end122.i.i

if.end122.i.i:                                    ; preds = %if.else118.i.i, %if.then114.i.i
  %.sink412.i.i = phi i16 [ 128, %if.else118.i.i ], [ -128, %if.then114.i.i ]
  %x.addr.7.i.i = phi i16 [ %add119.i.i, %if.else118.i.i ], [ %sub115.i.i, %if.then114.i.i ]
  %y.addr.7.i.i = phi i16 [ %sub120.i.i, %if.else118.i.i ], [ %add116.i.i, %if.then114.i.i ]
  %shr127.i.i = ashr i16 %x.addr.7.i.i, 8
  %shr129.i.i = ashr i16 %y.addr.7.i.i, 8
  %cmp130.i.i = icmp slt i16 %y.addr.7.i.i, 0
  br i1 %cmp130.i.i, label %if.then131.i.i, label %if.else135.i.i

if.then131.i.i:                                   ; preds = %if.end122.i.i
  %sub132.i.i = sub nsw i16 %x.addr.7.i.i, %shr129.i.i
  %add133.i.i = add nsw i16 %y.addr.7.i.i, %shr127.i.i
  br label %if.end139.i.i

if.else135.i.i:                                   ; preds = %if.end122.i.i
  %add136.i.i = add nsw i16 %shr129.i.i, %x.addr.7.i.i
  %sub137.i.i = sub nsw i16 %y.addr.7.i.i, %shr127.i.i
  br label %if.end139.i.i

if.end139.i.i:                                    ; preds = %if.else135.i.i, %if.then131.i.i
  %.sink413.i.i = phi i16 [ 64, %if.else135.i.i ], [ -64, %if.then131.i.i ]
  %x.addr.8.i.i = phi i16 [ %add136.i.i, %if.else135.i.i ], [ %sub132.i.i, %if.then131.i.i ]
  %y.addr.8.i.i = phi i16 [ %sub137.i.i, %if.else135.i.i ], [ %add133.i.i, %if.then131.i.i ]
  %shr144.i.i = ashr i16 %x.addr.8.i.i, 9
  %shr146.i.i = ashr i16 %y.addr.8.i.i, 9
  %cmp147.i.i = icmp slt i16 %y.addr.8.i.i, 0
  br i1 %cmp147.i.i, label %if.then148.i.i, label %if.else152.i.i

if.then148.i.i:                                   ; preds = %if.end139.i.i
  %sub149.i.i = sub nsw i16 %x.addr.8.i.i, %shr146.i.i
  %add150.i.i = add nsw i16 %y.addr.8.i.i, %shr144.i.i
  br label %if.end156.i.i

if.else152.i.i:                                   ; preds = %if.end139.i.i
  %add153.i.i = add nsw i16 %shr146.i.i, %x.addr.8.i.i
  %sub154.i.i = sub nsw i16 %y.addr.8.i.i, %shr144.i.i
  br label %if.end156.i.i

if.end156.i.i:                                    ; preds = %if.else152.i.i, %if.then148.i.i
  %.sink414.i.i = phi i16 [ 32, %if.else152.i.i ], [ -32, %if.then148.i.i ]
  %x.addr.9.i.i = phi i16 [ %add153.i.i, %if.else152.i.i ], [ %sub149.i.i, %if.then148.i.i ]
  %y.addr.9.i.i = phi i16 [ %sub154.i.i, %if.else152.i.i ], [ %add150.i.i, %if.then148.i.i ]
  %shr161.i.i = ashr i16 %x.addr.9.i.i, 10
  %shr163.i.i = ashr i16 %y.addr.9.i.i, 10
  %cmp164.i.i = icmp slt i16 %y.addr.9.i.i, 0
  br i1 %cmp164.i.i, label %if.then165.i.i, label %if.else169.i.i

if.then165.i.i:                                   ; preds = %if.end156.i.i
  %sub166.i.i = sub nsw i16 %x.addr.9.i.i, %shr163.i.i
  %add167.i.i = add nsw i16 %y.addr.9.i.i, %shr161.i.i
  br label %if.end173.i.i

if.else169.i.i:                                   ; preds = %if.end156.i.i
  %add170.i.i = add nsw i16 %shr163.i.i, %x.addr.9.i.i
  %sub171.i.i = sub nsw i16 %y.addr.9.i.i, %shr161.i.i
  br label %if.end173.i.i

if.end173.i.i:                                    ; preds = %if.else169.i.i, %if.then165.i.i
  %.sink415.i.i = phi i16 [ 16, %if.else169.i.i ], [ -16, %if.then165.i.i ]
  %x.addr.10.i.i = phi i16 [ %add170.i.i, %if.else169.i.i ], [ %sub166.i.i, %if.then165.i.i ]
  %y.addr.10.i.i = phi i16 [ %sub171.i.i, %if.else169.i.i ], [ %add167.i.i, %if.then165.i.i ]
  %shr178.i.i = ashr i16 %x.addr.10.i.i, 11
  %shr180.i.i = ashr i16 %y.addr.10.i.i, 11
  %cmp181.i.i = icmp slt i16 %y.addr.10.i.i, 0
  br i1 %cmp181.i.i, label %if.then182.i.i, label %if.else186.i.i

if.then182.i.i:                                   ; preds = %if.end173.i.i
  %sub183.i.i = sub nsw i16 %x.addr.10.i.i, %shr180.i.i
  %add184.i.i = add nsw i16 %y.addr.10.i.i, %shr178.i.i
  br label %if.end190.i.i

if.else186.i.i:                                   ; preds = %if.end173.i.i
  %add187.i.i = add nsw i16 %shr180.i.i, %x.addr.10.i.i
  %sub188.i.i = sub nsw i16 %y.addr.10.i.i, %shr178.i.i
  br label %if.end190.i.i

if.end190.i.i:                                    ; preds = %if.else186.i.i, %if.then182.i.i
  %.sink416.i.i = phi i16 [ 8, %if.else186.i.i ], [ -8, %if.then182.i.i ]
  %x.addr.11.i.i = phi i16 [ %add187.i.i, %if.else186.i.i ], [ %sub183.i.i, %if.then182.i.i ]
  %y.addr.11.i.i = phi i16 [ %sub188.i.i, %if.else186.i.i ], [ %add184.i.i, %if.then182.i.i ]
  %shr195.i.i = ashr i16 %x.addr.11.i.i, 12
  %shr197.i.i = ashr i16 %y.addr.11.i.i, 12
  %cmp198.i.i = icmp slt i16 %y.addr.11.i.i, 0
  br i1 %cmp198.i.i, label %if.then199.i.i, label %if.else203.i.i

if.then199.i.i:                                   ; preds = %if.end190.i.i
  %sub200.i.i = sub nsw i16 %x.addr.11.i.i, %shr197.i.i
  %add201.i.i = add nsw i16 %y.addr.11.i.i, %shr195.i.i
  br label %if.end207.i.i

if.else203.i.i:                                   ; preds = %if.end190.i.i
  %add204.i.i = add nsw i16 %shr197.i.i, %x.addr.11.i.i
  %sub205.i.i = sub nsw i16 %y.addr.11.i.i, %shr195.i.i
  br label %if.end207.i.i

if.end207.i.i:                                    ; preds = %if.else203.i.i, %if.then199.i.i
  %.sink417.i.i = phi i16 [ 4, %if.else203.i.i ], [ -4, %if.then199.i.i ]
  %x.addr.12.i.i = phi i16 [ %add204.i.i, %if.else203.i.i ], [ %sub200.i.i, %if.then199.i.i ]
  %y.addr.12.i.i = phi i16 [ %sub205.i.i, %if.else203.i.i ], [ %add201.i.i, %if.then199.i.i ]
  %shr212.i.i = ashr i16 %x.addr.12.i.i, 13
  %cmp215.i.i = icmp slt i16 %y.addr.12.i.i, 0
  br i1 %cmp215.i.i, label %if.then216.i.i, label %if.else220.i.i

if.then216.i.i:                                   ; preds = %if.end207.i.i
  %add218.i.i = add nsw i16 %y.addr.12.i.i, %shr212.i.i
  br label %cordic16_atan2.exit

if.else220.i.i:                                   ; preds = %if.end207.i.i
  %sub222.i.i = sub nsw i16 %y.addr.12.i.i, %shr212.i.i
  br label %cordic16_atan2.exit

cordic16_atan2.exit:                              ; preds = %if.then216.i.i, %if.else220.i.i
  %.sink418.i.i = phi i16 [ 2, %if.else220.i.i ], [ -2, %if.then216.i.i ]
  %y.addr.13.i.i = phi i16 [ %sub222.i.i, %if.else220.i.i ], [ %add218.i.i, %if.then216.i.i ]
  %add19.i.i = add nsw i16 %.sink.i.i, %z.0.i.i
  %add36.i.i = add nsw i16 %add19.i.i, %.sink407.i.i
  %add53.i.i = add nsw i16 %add36.i.i, %.sink408.i.i
  %add70.i.i = add nsw i16 %add53.i.i, %.sink409.i.i
  %add87.i.i = add nsw i16 %add70.i.i, %.sink410.i.i
  %add104.i.i = add nsw i16 %add87.i.i, %.sink411.i.i
  %add121.i.i = add nsw i16 %add104.i.i, %.sink412.i.i
  %add138.i.i = add nsw i16 %add121.i.i, %.sink413.i.i
  %add155.i.i = add nsw i16 %add138.i.i, %.sink414.i.i
  %add172.i.i = add nsw i16 %add155.i.i, %.sink415.i.i
  %add189.i.i = add nsw i16 %add172.i.i, %.sink416.i.i
  %add206.i.i = add nsw i16 %add189.i.i, %.sink417.i.i
  %add223.i.i = add nsw i16 %add206.i.i, %.sink418.i.i
  %cmp232.inv.i.i = icmp sgt i16 %y.addr.13.i.i, -1
  %..i.i = select i1 %cmp232.inv.i.i, i16 1, i16 -1
  %add240.i.i = add nsw i16 %add223.i.i, %..i.i
  %or.i11 = tail call i16 @llvm.fshl.i16(i16 %xor.i10, i16 %xor.i10, i16 1)
  %xor.i12 = xor i16 %add240.i.i, %or.i11
  call void @llvm.lifetime.end.p0(ptr nonnull %base_c) #5
  call void @llvm.lifetime.end.p0(ptr nonnull %base_s) #5
  %inc = add nuw nsw i16 %k.019, 1
  %exitcond.not = icmp eq i16 %inc, 96
  br i1 %exitcond.not, label %for.cond.cleanup, label %for.body, !llvm.loop !9
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #2

; Function Attrs: inlinehint mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define internal fastcc void @cordic16_sincos(i16 noundef %angle, ptr nofree noundef nonnull writeonly captures(none) initializes((0, 2)) %sin_out, ptr nofree noundef nonnull writeonly captures(none) initializes((0, 2)) %cos_out) unnamed_addr #3 {
entry:
  %cmp = icmp sgt i16 %angle, -1
  %. = select i1 %cmp, i16 -12868, i16 12868
  %.422 = select i1 %cmp, i16 9949, i16 -9949
  %add5 = add nsw i16 %angle, %.
  %shr10 = ashr i16 %.422, 1
  %cmp11 = icmp sgt i16 %add5, -1
  br i1 %cmp11, label %if.then12, label %if.else16

if.then12:                                        ; preds = %entry
  %sub13 = sub nsw i16 9949, %shr10
  br label %if.end20

if.else16:                                        ; preds = %entry
  %add17 = add nsw i16 %shr10, 9949
  br label %if.end20

if.end20:                                         ; preds = %if.else16, %if.then12
  %.sink409 = phi i16 [ -4974, %if.else16 ], [ 4974, %if.then12 ]
  %.sink408 = phi i16 [ 7596, %if.else16 ], [ -7596, %if.then12 ]
  %x.1 = phi i16 [ %add17, %if.else16 ], [ %sub13, %if.then12 ]
  %sub18 = add nsw i16 %.422, %.sink409
  %add19 = add nsw i16 %add5, %.sink408
  %shr25 = lshr i16 %x.1, 2
  %shr27 = ashr i16 %sub18, 2
  %cmp28 = icmp sgt i16 %add19, -1
  br i1 %cmp28, label %if.then29, label %if.else33

if.then29:                                        ; preds = %if.end20
  %sub30 = sub nsw i16 %x.1, %shr27
  %add31 = add nsw i16 %sub18, %shr25
  br label %if.end37

if.else33:                                        ; preds = %if.end20
  %add34 = add nsw i16 %shr27, %x.1
  %sub35 = sub nsw i16 %sub18, %shr25
  br label %if.end37

if.end37:                                         ; preds = %if.else33, %if.then29
  %.sink410 = phi i16 [ 4014, %if.else33 ], [ -4014, %if.then29 ]
  %x.2 = phi i16 [ %add34, %if.else33 ], [ %sub30, %if.then29 ]
  %y.2 = phi i16 [ %sub35, %if.else33 ], [ %add31, %if.then29 ]
  %add36 = add nsw i16 %add19, %.sink410
  %shr42 = lshr i16 %x.2, 3
  %shr44 = ashr i16 %y.2, 3
  %cmp45 = icmp sgt i16 %add36, -1
  br i1 %cmp45, label %if.then46, label %if.else50

if.then46:                                        ; preds = %if.end37
  %sub47 = sub nsw i16 %x.2, %shr44
  %add48 = add nsw i16 %y.2, %shr42
  br label %if.end54

if.else50:                                        ; preds = %if.end37
  %add51 = add nsw i16 %shr44, %x.2
  %sub52 = sub nsw i16 %y.2, %shr42
  br label %if.end54

if.end54:                                         ; preds = %if.else50, %if.then46
  %.sink411 = phi i16 [ 2037, %if.else50 ], [ -2037, %if.then46 ]
  %x.3 = phi i16 [ %add51, %if.else50 ], [ %sub47, %if.then46 ]
  %y.3 = phi i16 [ %sub52, %if.else50 ], [ %add48, %if.then46 ]
  %add53 = add nsw i16 %add36, %.sink411
  %shr59 = ashr i16 %x.3, 4
  %shr61 = ashr i16 %y.3, 4
  %cmp62 = icmp sgt i16 %add53, -1
  br i1 %cmp62, label %if.then63, label %if.else67

if.then63:                                        ; preds = %if.end54
  %sub64 = sub nsw i16 %x.3, %shr61
  %add65 = add nsw i16 %y.3, %shr59
  br label %if.end71

if.else67:                                        ; preds = %if.end54
  %add68 = add nsw i16 %shr61, %x.3
  %sub69 = sub nsw i16 %y.3, %shr59
  br label %if.end71

if.end71:                                         ; preds = %if.else67, %if.then63
  %.sink412 = phi i16 [ 1023, %if.else67 ], [ -1023, %if.then63 ]
  %x.4 = phi i16 [ %add68, %if.else67 ], [ %sub64, %if.then63 ]
  %y.4 = phi i16 [ %sub69, %if.else67 ], [ %add65, %if.then63 ]
  %add70 = add nsw i16 %add53, %.sink412
  %shr76 = ashr i16 %x.4, 5
  %shr78 = ashr i16 %y.4, 5
  %cmp79 = icmp sgt i16 %add70, -1
  br i1 %cmp79, label %if.then80, label %if.else84

if.then80:                                        ; preds = %if.end71
  %sub81 = sub nsw i16 %x.4, %shr78
  %add82 = add nsw i16 %y.4, %shr76
  br label %if.end88

if.else84:                                        ; preds = %if.end71
  %add85 = add nsw i16 %shr78, %x.4
  %sub86 = sub nsw i16 %y.4, %shr76
  br label %if.end88

if.end88:                                         ; preds = %if.else84, %if.then80
  %.sink413 = phi i16 [ 512, %if.else84 ], [ -512, %if.then80 ]
  %x.5 = phi i16 [ %add85, %if.else84 ], [ %sub81, %if.then80 ]
  %y.5 = phi i16 [ %sub86, %if.else84 ], [ %add82, %if.then80 ]
  %add87 = add nsw i16 %add70, %.sink413
  %shr93 = ashr i16 %x.5, 6
  %shr95 = ashr i16 %y.5, 6
  %cmp96 = icmp sgt i16 %add87, -1
  br i1 %cmp96, label %if.then97, label %if.else101

if.then97:                                        ; preds = %if.end88
  %sub98 = sub nsw i16 %x.5, %shr95
  %add99 = add nsw i16 %y.5, %shr93
  br label %if.end105

if.else101:                                       ; preds = %if.end88
  %add102 = add nsw i16 %shr95, %x.5
  %sub103 = sub nsw i16 %y.5, %shr93
  br label %if.end105

if.end105:                                        ; preds = %if.else101, %if.then97
  %.sink414 = phi i16 [ 256, %if.else101 ], [ -256, %if.then97 ]
  %x.6 = phi i16 [ %add102, %if.else101 ], [ %sub98, %if.then97 ]
  %y.6 = phi i16 [ %sub103, %if.else101 ], [ %add99, %if.then97 ]
  %add104 = add nsw i16 %add87, %.sink414
  %shr110 = ashr i16 %x.6, 7
  %shr112 = ashr i16 %y.6, 7
  %cmp113 = icmp sgt i16 %add104, -1
  br i1 %cmp113, label %if.then114, label %if.else118

if.then114:                                       ; preds = %if.end105
  %sub115 = sub nsw i16 %x.6, %shr112
  %add116 = add nsw i16 %y.6, %shr110
  br label %if.end122

if.else118:                                       ; preds = %if.end105
  %add119 = add nsw i16 %shr112, %x.6
  %sub120 = sub nsw i16 %y.6, %shr110
  br label %if.end122

if.end122:                                        ; preds = %if.else118, %if.then114
  %.sink415 = phi i16 [ 128, %if.else118 ], [ -128, %if.then114 ]
  %x.7 = phi i16 [ %add119, %if.else118 ], [ %sub115, %if.then114 ]
  %y.7 = phi i16 [ %sub120, %if.else118 ], [ %add116, %if.then114 ]
  %add121 = add nsw i16 %add104, %.sink415
  %shr127 = ashr i16 %x.7, 8
  %shr129 = ashr i16 %y.7, 8
  %cmp130 = icmp sgt i16 %add121, -1
  br i1 %cmp130, label %if.then131, label %if.else135

if.then131:                                       ; preds = %if.end122
  %sub132 = sub nsw i16 %x.7, %shr129
  %add133 = add nsw i16 %y.7, %shr127
  br label %if.end139

if.else135:                                       ; preds = %if.end122
  %add136 = add nsw i16 %shr129, %x.7
  %sub137 = sub nsw i16 %y.7, %shr127
  br label %if.end139

if.end139:                                        ; preds = %if.else135, %if.then131
  %.sink416 = phi i16 [ 64, %if.else135 ], [ -64, %if.then131 ]
  %x.8 = phi i16 [ %add136, %if.else135 ], [ %sub132, %if.then131 ]
  %y.8 = phi i16 [ %sub137, %if.else135 ], [ %add133, %if.then131 ]
  %add138 = add nsw i16 %add121, %.sink416
  %shr144 = ashr i16 %x.8, 9
  %shr146 = ashr i16 %y.8, 9
  %cmp147 = icmp sgt i16 %add138, -1
  br i1 %cmp147, label %if.then148, label %if.else152

if.then148:                                       ; preds = %if.end139
  %sub149 = sub nsw i16 %x.8, %shr146
  %add150 = add nsw i16 %y.8, %shr144
  br label %if.end156

if.else152:                                       ; preds = %if.end139
  %add153 = add nsw i16 %shr146, %x.8
  %sub154 = sub nsw i16 %y.8, %shr144
  br label %if.end156

if.end156:                                        ; preds = %if.else152, %if.then148
  %.sink417 = phi i16 [ 32, %if.else152 ], [ -32, %if.then148 ]
  %x.9 = phi i16 [ %add153, %if.else152 ], [ %sub149, %if.then148 ]
  %y.9 = phi i16 [ %sub154, %if.else152 ], [ %add150, %if.then148 ]
  %add155 = add nsw i16 %add138, %.sink417
  %shr161 = ashr i16 %x.9, 10
  %shr163 = ashr i16 %y.9, 10
  %cmp164 = icmp sgt i16 %add155, -1
  br i1 %cmp164, label %if.then165, label %if.else169

if.then165:                                       ; preds = %if.end156
  %sub166 = sub nsw i16 %x.9, %shr163
  %add167 = add nsw i16 %y.9, %shr161
  br label %if.end173

if.else169:                                       ; preds = %if.end156
  %add170 = add nsw i16 %shr163, %x.9
  %sub171 = sub nsw i16 %y.9, %shr161
  br label %if.end173

if.end173:                                        ; preds = %if.else169, %if.then165
  %.sink418 = phi i16 [ 16, %if.else169 ], [ -16, %if.then165 ]
  %x.10 = phi i16 [ %add170, %if.else169 ], [ %sub166, %if.then165 ]
  %y.10 = phi i16 [ %sub171, %if.else169 ], [ %add167, %if.then165 ]
  %add172 = add nsw i16 %add155, %.sink418
  %shr178 = ashr i16 %x.10, 11
  %shr180 = ashr i16 %y.10, 11
  %cmp181 = icmp sgt i16 %add172, -1
  br i1 %cmp181, label %if.then182, label %if.else186

if.then182:                                       ; preds = %if.end173
  %sub183 = sub nsw i16 %x.10, %shr180
  %add184 = add nsw i16 %y.10, %shr178
  br label %if.end190

if.else186:                                       ; preds = %if.end173
  %add187 = add nsw i16 %shr180, %x.10
  %sub188 = sub nsw i16 %y.10, %shr178
  br label %if.end190

if.end190:                                        ; preds = %if.else186, %if.then182
  %.sink419 = phi i16 [ 8, %if.else186 ], [ -8, %if.then182 ]
  %x.11 = phi i16 [ %add187, %if.else186 ], [ %sub183, %if.then182 ]
  %y.11 = phi i16 [ %sub188, %if.else186 ], [ %add184, %if.then182 ]
  %add189 = add nsw i16 %add172, %.sink419
  %shr195 = ashr i16 %x.11, 12
  %shr197 = ashr i16 %y.11, 12
  %cmp198 = icmp sgt i16 %add189, -1
  br i1 %cmp198, label %if.then199, label %if.else203

if.then199:                                       ; preds = %if.end190
  %sub200 = sub nsw i16 %x.11, %shr197
  %add201 = add nsw i16 %y.11, %shr195
  br label %if.end207

if.else203:                                       ; preds = %if.end190
  %add204 = add nsw i16 %shr197, %x.11
  %sub205 = sub nsw i16 %y.11, %shr195
  br label %if.end207

if.end207:                                        ; preds = %if.else203, %if.then199
  %.sink420 = phi i16 [ 4, %if.else203 ], [ -4, %if.then199 ]
  %x.12 = phi i16 [ %add204, %if.else203 ], [ %sub200, %if.then199 ]
  %y.12 = phi i16 [ %sub205, %if.else203 ], [ %add201, %if.then199 ]
  %add206 = add nsw i16 %add189, %.sink420
  %shr212 = ashr i16 %x.12, 13
  %shr214 = ashr i16 %y.12, 13
  %cmp215 = icmp sgt i16 %add206, -1
  br i1 %cmp215, label %if.then216, label %if.else220

if.then216:                                       ; preds = %if.end207
  %sub217 = sub nsw i16 %x.12, %shr214
  %add218 = add nsw i16 %y.12, %shr212
  br label %if.end224

if.else220:                                       ; preds = %if.end207
  %add221 = add nsw i16 %shr214, %x.12
  %sub222 = sub nsw i16 %y.12, %shr212
  br label %if.end224

if.end224:                                        ; preds = %if.else220, %if.then216
  %.sink421 = phi i16 [ 2, %if.else220 ], [ -2, %if.then216 ]
  %x.13 = phi i16 [ %add221, %if.else220 ], [ %sub217, %if.then216 ]
  %y.13 = phi i16 [ %sub222, %if.else220 ], [ %add218, %if.then216 ]
  %add223 = add nsw i16 %add206, %.sink421
  %shr229 = ashr i16 %x.13, 14
  %shr231 = ashr i16 %y.13, 14
  %cmp232 = icmp sgt i16 %add223, -1
  br i1 %cmp232, label %if.then233, label %if.else237

if.then233:                                       ; preds = %if.end224
  %sub234 = sub nsw i16 %x.13, %shr231
  %add235 = add nsw i16 %y.13, %shr229
  br label %if.end241

if.else237:                                       ; preds = %if.end224
  %add238 = add nsw i16 %shr231, %x.13
  %sub239 = sub nsw i16 %y.13, %shr229
  br label %if.end241

if.end241:                                        ; preds = %if.else237, %if.then233
  %x.14 = phi i16 [ %sub234, %if.then233 ], [ %add238, %if.else237 ]
  %y.14 = phi i16 [ %add235, %if.then233 ], [ %sub239, %if.else237 ]
  store i16 %x.14, ptr %cos_out, align 1, !tbaa !7
  store i16 %y.14, ptr %sin_out, align 1, !tbaa !7
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #4

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { nofree noinline norecurse nosync nounwind memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { inlinehint mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 7bd67c0ae4e8bb65a3f980912bf201df22131e34)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!4, !4, i64 0}
!8 = !{i64 900}
!9 = distinct !{!9, !10}
!10 = !{!"llvm.loop.mustprogress"}
