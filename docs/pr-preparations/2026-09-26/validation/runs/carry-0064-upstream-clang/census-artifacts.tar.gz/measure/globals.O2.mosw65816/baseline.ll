; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/globals.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/globals.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@data_vals = dso_local local_unnamed_addr global [4 x i16] [i16 4369, i16 8738, i16 13107, i16 17476], align 1
@data_byte = dso_local local_unnamed_addr global i8 -85, align 1
@one = dso_local global i8 1, align 1
@bss_vals = dso_local local_unnamed_addr global [8 x i16] zeroinitializer, align 1
@bss_byte = dso_local local_unnamed_addr global i8 0, align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  %0 = load i16, ptr @data_vals, align 1, !tbaa !7
  %1 = load volatile i8, ptr @one, align 1, !tbaa !8
  %2 = load i16, ptr getelementptr inbounds nuw (i8, ptr @data_vals, i16 2), align 1, !tbaa !7
  %3 = load volatile i8, ptr @one, align 1, !tbaa !8
  %4 = load i16, ptr getelementptr inbounds nuw (i8, ptr @data_vals, i16 4), align 1, !tbaa !7
  %5 = load volatile i8, ptr @one, align 1, !tbaa !8
  %6 = load i16, ptr getelementptr inbounds nuw (i8, ptr @data_vals, i16 6), align 1, !tbaa !7
  %7 = load volatile i8, ptr @one, align 1, !tbaa !8
  %8 = load i8, ptr @data_byte, align 1, !tbaa !8
  %9 = load volatile i8, ptr @one, align 1, !tbaa !8
  %10 = load i16, ptr @bss_vals, align 1, !tbaa !7
  %11 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bss_vals, i16 2), align 1, !tbaa !7
  %add14.1 = add i16 %11, %10
  %12 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bss_vals, i16 4), align 1, !tbaa !7
  %add14.2 = add i16 %12, %add14.1
  %13 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bss_vals, i16 6), align 1, !tbaa !7
  %add14.3 = add i16 %13, %add14.2
  %14 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bss_vals, i16 8), align 1, !tbaa !7
  %add14.4 = add i16 %14, %add14.3
  %15 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bss_vals, i16 10), align 1, !tbaa !7
  %add14.5 = add i16 %15, %add14.4
  %16 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bss_vals, i16 12), align 1, !tbaa !7
  %add14.6 = add i16 %16, %add14.5
  %17 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bss_vals, i16 14), align 1, !tbaa !7
  %add14.7 = add i16 %17, %add14.6
  %conv2 = zext i8 %1 to i16
  %mul = mul i16 %0, %conv2
  %conv2.1 = zext i8 %3 to i16
  %mul.1 = mul i16 %2, %conv2.1
  %add.1 = add i16 %mul.1, %mul
  %conv2.2 = zext i8 %5 to i16
  %mul.2 = mul i16 %4, %conv2.2
  %add.2 = add i16 %mul.2, %add.1
  %conv2.3 = zext i8 %7 to i16
  %mul.3 = mul i16 %6, %conv2.3
  %add.3 = add i16 %mul.3, %add.2
  %conv3 = zext i8 %8 to i16
  %conv4 = zext i8 %9 to i16
  %mul5 = mul nuw nsw i16 %conv4, %conv3
  %add6 = add i16 %mul5, %add.3
  %18 = load i8, ptr @bss_byte, align 1, !tbaa !8
  %conv18 = zext i8 %18 to i16
  %add19 = sub nsw i16 0, %conv18
  %cmp20.not = icmp eq i16 %add14.7, %add19
  br i1 %cmp20.not, label %if.end, label %if.then

if.then:                                          ; preds = %entry
  %add22 = add i16 %add6, -4096
  br label %if.end

if.end:                                           ; preds = %if.then, %entry
  %r.1 = phi i16 [ %add22, %if.then ], [ %add6, %entry ]
  store volatile i16 %r.1, ptr @corpus_result, align 1, !tbaa !7
  br label %for.cond23

for.cond23:                                       ; preds = %for.cond23, %if.end
  tail call void asm sideeffect "", ""() #1, !srcloc !9
  br label %for.cond23
}

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 7bd67c0ae4e8bb65a3f980912bf201df22131e34)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!4, !4, i64 0}
!8 = !{!5, !5, i64 0}
!9 = !{i64 1376}
