; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/funcs.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/funcs.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@fn = dso_local global i8 12, align 1
@a = dso_local global i16 30, align 1
@b = dso_local global i16 12, align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  %0 = load volatile i8, ptr @fn, align 1, !tbaa !7
  %call = tail call fastcc i16 @fib(i8 noundef zeroext %0) #2
  %1 = load volatile i16, ptr @a, align 1, !tbaa !8
  %2 = load volatile i16, ptr @b, align 1, !tbaa !8
  %add.i = add i16 %call, 100
  %add1.i = add i16 %add.i, %1
  %add2 = add i16 %add1.i, %2
  store volatile i16 %add2, ptr @corpus_result, align 1, !tbaa !8
  br label %for.cond

for.cond:                                         ; preds = %for.cond, %entry
  tail call void asm sideeffect "", ""() #3, !srcloc !9
  br label %for.cond
}

; Function Attrs: minsize nofree nosync nounwind optsize memory(none)
define internal fastcc i16 @fib(i8 noundef zeroext %n) unnamed_addr #1 {
entry:
  br label %tailrecurse

tailrecurse:                                      ; preds = %if.end, %entry
  %accumulator.tr = phi i16 [ 0, %entry ], [ %add, %if.end ]
  %n.tr = phi i8 [ %n, %entry ], [ %sub6, %if.end ]
  %cmp = icmp ult i8 %n.tr, 2
  br i1 %cmp, label %if.then, label %if.end

if.then:                                          ; preds = %tailrecurse
  %conv = zext nneg i8 %n.tr to i16
  %accumulator.ret.tr = add i16 %accumulator.tr, %conv
  ret i16 %accumulator.ret.tr

if.end:                                           ; preds = %tailrecurse
  %sub = add i8 %n.tr, -1
  %call = tail call fastcc i16 @fib(i8 noundef zeroext %sub) #2
  %sub6 = add i8 %n.tr, -2
  %add = add i16 %call, %accumulator.tr
  br label %tailrecurse
}

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos65c02" }
attributes #1 = { minsize nofree nosync nounwind optsize memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos65c02" }
attributes #2 = { minsize optsize }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 155e209c4cee8eeac01397aac3542e76841a9856)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!5, !5, i64 0}
!8 = !{!4, !4, i64 0}
!9 = !{i64 902}
