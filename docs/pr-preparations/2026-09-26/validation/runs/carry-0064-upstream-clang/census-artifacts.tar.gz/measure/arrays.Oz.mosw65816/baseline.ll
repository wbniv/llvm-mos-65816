; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/arrays.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/arrays.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@idx = dso_local global i8 5, align 1
@lut = internal unnamed_addr constant [8 x i8] c"\03\01\04\01\05\09\02\06", align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  %ram = alloca [8 x i8], align 1
  %0 = load volatile i8, ptr @idx, align 1, !tbaa !7
  %idxprom3 = zext i8 %0 to i16
  %arrayidx4 = getelementptr inbounds nuw i8, ptr @lut, i16 %idxprom3
  %1 = load i8, ptr %arrayidx4, align 1, !tbaa !7
  call void @llvm.lifetime.start.p0(ptr nonnull %ram) #2
  br label %for.cond7

for.cond7:                                        ; preds = %for.body11, %entry
  %i.1 = phi i8 [ 0, %entry ], [ %inc20, %for.body11 ]
  %exitcond.not = icmp eq i8 %i.1, 8
  br i1 %exitcond.not, label %for.cond22.preheader, label %for.body11

for.cond22.preheader:                             ; preds = %for.cond7
  %conv5 = zext i8 %1 to i16
  %mul = mul nuw nsw i16 %conv5, 100
  %add6 = add nuw nsw i16 %mul, 31
  br label %for.cond22

for.body11:                                       ; preds = %for.cond7
  %2 = zext nneg i8 %i.1 to i16
  %uglygep = getelementptr i8, ptr @lut, i16 %2
  %3 = load i8, ptr %uglygep, align 1, !tbaa !7
  %mul15 = shl i8 %3, 1
  %uglygep47 = getelementptr i8, ptr %ram, i16 %2
  store i8 %mul15, ptr %uglygep47, align 1, !tbaa !7
  %inc20 = add nuw nsw i8 %i.1, 1
  br label %for.cond7, !llvm.loop !8

for.cond22:                                       ; preds = %for.cond22.preheader, %for.body26
  %r.1 = phi i16 [ %add30, %for.body26 ], [ %add6, %for.cond22.preheader ]
  %i.2 = phi i8 [ %inc32, %for.body26 ], [ 0, %for.cond22.preheader ]
  %exitcond48.not = icmp eq i8 %i.2, 8
  br i1 %exitcond48.not, label %for.end33, label %for.body26

for.body26:                                       ; preds = %for.cond22
  %4 = zext nneg i8 %i.2 to i16
  %uglygep49 = getelementptr i8, ptr %ram, i16 %4
  %5 = load i8, ptr %uglygep49, align 1, !tbaa !7
  %conv29 = zext i8 %5 to i16
  %add30 = add i16 %r.1, %conv29
  %inc32 = add nuw nsw i8 %i.2, 1
  br label %for.cond22, !llvm.loop !10

for.end33:                                        ; preds = %for.cond22
  store volatile i16 %r.1, ptr @corpus_result, align 1, !tbaa !11
  br label %for.cond34

for.cond34:                                       ; preds = %for.cond34, %for.end33
  tail call void asm sideeffect "", ""() #2, !srcloc !12
  br label %for.cond34
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 7bd67c0ae4e8bb65a3f980912bf201df22131e34)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!5, !5, i64 0}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = distinct !{!10, !9}
!11 = !{!4, !4, i64 0}
!12 = !{i64 983}
