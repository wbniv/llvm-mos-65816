# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/cordic_sim.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 368 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/cordic_sim.c" 2
# 10 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/cordic_sim.c"
# 1 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/cordic.h" 1
# 21 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/cordic.h"
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 1 3
# 100 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef long long int int64_t;

typedef long long unsigned int uint64_t;
# 122 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int64_t int_least64_t;
typedef uint64_t uint_least64_t;
typedef int64_t int_fast64_t;
typedef uint64_t uint_fast64_t;
# 197 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef long int int32_t;




typedef long unsigned int uint32_t;
# 220 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int32_t int_least32_t;
typedef uint32_t uint_least32_t;
typedef int32_t int_fast32_t;
typedef uint32_t uint_fast32_t;
# 245 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int int16_t;

typedef unsigned int uint16_t;
# 259 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int16_t int_least16_t;
typedef uint16_t uint_least16_t;
typedef int16_t int_fast16_t;
typedef uint16_t uint_fast16_t;





typedef signed char int8_t;

typedef unsigned char uint8_t;







typedef int8_t int_least8_t;
typedef uint8_t uint_least8_t;
typedef int8_t int_fast8_t;
typedef uint8_t uint_fast8_t;
# 295 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int intptr_t;






typedef unsigned int uintptr_t;





typedef long long int intmax_t;
typedef long long unsigned int uintmax_t;
# 22 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/cordic.h" 2
# 1 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/cordic16.h" 1
# 29 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/cordic16.h"
# 1 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/cordic16_tables.h" 1
# 20 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/cordic16_tables.h"
static const int16_t cordic16_atan_tbl[15] = {
   12868,
    7596,
    4014,
    2037,
    1023,
     512,
     256,
     128,
      64,
      32,
      16,
       8,
       4,
       2,
       1,
};
# 49 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/cordic16_tables.h"
static const uint8_t cordic16_hsched[16] = { 1, 2, 3, 4, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 13, 14 };
static const int16_t cordic16_atanh_tbl[16] = {
    9000,
    4185,
    2059,
    1025,
    1025,
     512,
     256,
     128,
      64,
      32,
      16,
       8,
       4,
       2,
       2,
       1,
};
# 30 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/cordic16.h" 2
# 43 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/cordic16.h"
static inline void cordic16_sincos(int16_t angle, int16_t *sin_out, int16_t *cos_out) {
  int16_t x = 9949;
  int16_t y = 0;
  int16_t z = angle;
  do { int16_t dx = (int16_t)(x >> (0)); int16_t dy = (int16_t)(y >> (0)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[0]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[0]); } } while (0); do { int16_t dx = (int16_t)(x >> (1)); int16_t dy = (int16_t)(y >> (1)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[1]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[1]); } } while (0); do { int16_t dx = (int16_t)(x >> (2)); int16_t dy = (int16_t)(y >> (2)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[2]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[2]); } } while (0); do { int16_t dx = (int16_t)(x >> (3)); int16_t dy = (int16_t)(y >> (3)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[3]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[3]); } } while (0);
  do { int16_t dx = (int16_t)(x >> (4)); int16_t dy = (int16_t)(y >> (4)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[4]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[4]); } } while (0); do { int16_t dx = (int16_t)(x >> (5)); int16_t dy = (int16_t)(y >> (5)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[5]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[5]); } } while (0); do { int16_t dx = (int16_t)(x >> (6)); int16_t dy = (int16_t)(y >> (6)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[6]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[6]); } } while (0); do { int16_t dx = (int16_t)(x >> (7)); int16_t dy = (int16_t)(y >> (7)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[7]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[7]); } } while (0);
  do { int16_t dx = (int16_t)(x >> (8)); int16_t dy = (int16_t)(y >> (8)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[8]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[8]); } } while (0); do { int16_t dx = (int16_t)(x >> (9)); int16_t dy = (int16_t)(y >> (9)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[9]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[9]); } } while (0); do { int16_t dx = (int16_t)(x >> (10)); int16_t dy = (int16_t)(y >> (10)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[10]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[10]); } } while (0); do { int16_t dx = (int16_t)(x >> (11)); int16_t dy = (int16_t)(y >> (11)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[11]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[11]); } } while (0);
  do { int16_t dx = (int16_t)(x >> (12)); int16_t dy = (int16_t)(y >> (12)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[12]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[12]); } } while (0); do { int16_t dx = (int16_t)(x >> (13)); int16_t dy = (int16_t)(y >> (13)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[13]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[13]); } } while (0); do { int16_t dx = (int16_t)(x >> (14)); int16_t dy = (int16_t)(y >> (14)); if (z >= 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[14]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[14]); } } while (0);
  *cos_out = x;
  *sin_out = y;
}

static inline int16_t cordic16_sin(int16_t angle) {
  int16_t s, c;
  cordic16_sincos(angle, &s, &c);
  return s;
}
static inline int16_t cordic16_cos(int16_t angle) {
  int16_t s, c;
  cordic16_sincos(angle, &s, &c);
  return c;
}
# 77 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/cordic16.h"
static inline int16_t cordic16_vector_angle(int16_t x, int16_t y) {
  int16_t z = 0;
  do { int16_t dx = (int16_t)(x >> (0)); int16_t dy = (int16_t)(y >> (0)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[0]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[0]); } } while (0); do { int16_t dx = (int16_t)(x >> (1)); int16_t dy = (int16_t)(y >> (1)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[1]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[1]); } } while (0); do { int16_t dx = (int16_t)(x >> (2)); int16_t dy = (int16_t)(y >> (2)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[2]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[2]); } } while (0); do { int16_t dx = (int16_t)(x >> (3)); int16_t dy = (int16_t)(y >> (3)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[3]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[3]); } } while (0);
  do { int16_t dx = (int16_t)(x >> (4)); int16_t dy = (int16_t)(y >> (4)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[4]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[4]); } } while (0); do { int16_t dx = (int16_t)(x >> (5)); int16_t dy = (int16_t)(y >> (5)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[5]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[5]); } } while (0); do { int16_t dx = (int16_t)(x >> (6)); int16_t dy = (int16_t)(y >> (6)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[6]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[6]); } } while (0); do { int16_t dx = (int16_t)(x >> (7)); int16_t dy = (int16_t)(y >> (7)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[7]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[7]); } } while (0);
  do { int16_t dx = (int16_t)(x >> (8)); int16_t dy = (int16_t)(y >> (8)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[8]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[8]); } } while (0); do { int16_t dx = (int16_t)(x >> (9)); int16_t dy = (int16_t)(y >> (9)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[9]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[9]); } } while (0); do { int16_t dx = (int16_t)(x >> (10)); int16_t dy = (int16_t)(y >> (10)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[10]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[10]); } } while (0); do { int16_t dx = (int16_t)(x >> (11)); int16_t dy = (int16_t)(y >> (11)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[11]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[11]); } } while (0);
  do { int16_t dx = (int16_t)(x >> (12)); int16_t dy = (int16_t)(y >> (12)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[12]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[12]); } } while (0); do { int16_t dx = (int16_t)(x >> (13)); int16_t dy = (int16_t)(y >> (13)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[13]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[13]); } } while (0); do { int16_t dx = (int16_t)(x >> (14)); int16_t dy = (int16_t)(y >> (14)); if (y < 0) { x = (int16_t)(x - dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atan_tbl[14]); } else { x = (int16_t)(x + dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atan_tbl[14]); } } while (0);
  return z;
}



static inline int16_t cordic16_atan2(int16_t y, int16_t x) {
  return cordic16_vector_angle((int16_t)(x >> 1), (int16_t)(y >> 1));
}


static inline int16_t cordic16_atan(int16_t x) {
  return cordic16_atan2(x, 16384);
}
# 108 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/cordic16.h"
static inline int16_t cordic16_q214_div(int16_t a, int16_t b) {
  return (int16_t)(((int32_t)a << 14) / (int32_t)b);
}



static inline int16_t cordic16_q214_sqrt(int16_t v) {
  if (v <= 0) return 0;
  uint32_t r = (uint32_t)v << 14;
  uint32_t res = 0, bit = 1UL << 26;
  while (bit > r) bit >>= 2;
  while (bit) {
    if (r >= res + bit) { r -= res + bit; res = (res >> 1) + bit; }
    else res >>= 1;
    bit >>= 2;
  }
  return (int16_t)res;
}


static inline int16_t cordic16_tan(int16_t angle) {
  int16_t s, c;
  cordic16_sincos(angle, &s, &c);
  return cordic16_q214_div(s, c);
}


static inline int16_t cordic16_asin(int16_t x) {
  int16_t x2 = (int16_t)(((int32_t)x * (int32_t)x) >> 14);
  int16_t c = cordic16_q214_sqrt((int16_t)(16384 - x2));
  return cordic16_atan2(x, c);
}


static inline int16_t cordic16_acos(int16_t x) {
  int16_t x2 = (int16_t)(((int32_t)x * (int32_t)x) >> 14);
  int16_t s = cordic16_q214_sqrt((int16_t)(16384 - x2));
  return cordic16_atan2(s, x);
}
# 162 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/cordic16.h"
static inline void cordic16_sinhcosh(int16_t angle, int16_t *sinh_out, int16_t *cosh_out) {
  int16_t x = 16384;
  int16_t y = 0;
  int16_t z = angle;
  do { int16_t dx = (int16_t)(x >> (1)); int16_t dy = (int16_t)(y >> (1)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[0]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[0]); } } while (0); do { int16_t dx = (int16_t)(x >> (2)); int16_t dy = (int16_t)(y >> (2)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[1]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[1]); } } while (0); do { int16_t dx = (int16_t)(x >> (3)); int16_t dy = (int16_t)(y >> (3)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[2]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[2]); } } while (0); do { int16_t dx = (int16_t)(x >> (4)); int16_t dy = (int16_t)(y >> (4)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[3]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[3]); } } while (0);
  do { int16_t dx = (int16_t)(x >> (4)); int16_t dy = (int16_t)(y >> (4)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[4]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[4]); } } while (0); do { int16_t dx = (int16_t)(x >> (5)); int16_t dy = (int16_t)(y >> (5)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[5]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[5]); } } while (0); do { int16_t dx = (int16_t)(x >> (6)); int16_t dy = (int16_t)(y >> (6)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[6]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[6]); } } while (0); do { int16_t dx = (int16_t)(x >> (7)); int16_t dy = (int16_t)(y >> (7)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[7]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[7]); } } while (0);
  do { int16_t dx = (int16_t)(x >> (8)); int16_t dy = (int16_t)(y >> (8)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[8]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[8]); } } while (0); do { int16_t dx = (int16_t)(x >> (9)); int16_t dy = (int16_t)(y >> (9)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[9]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[9]); } } while (0); do { int16_t dx = (int16_t)(x >> (10)); int16_t dy = (int16_t)(y >> (10)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[10]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[10]); } } while (0); do { int16_t dx = (int16_t)(x >> (11)); int16_t dy = (int16_t)(y >> (11)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[11]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[11]); } } while (0);
  do { int16_t dx = (int16_t)(x >> (12)); int16_t dy = (int16_t)(y >> (12)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[12]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[12]); } } while (0); do { int16_t dx = (int16_t)(x >> (13)); int16_t dy = (int16_t)(y >> (13)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[13]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[13]); } } while (0); do { int16_t dx = (int16_t)(x >> (13)); int16_t dy = (int16_t)(y >> (13)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[14]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[14]); } } while (0); do { int16_t dx = (int16_t)(x >> (14)); int16_t dy = (int16_t)(y >> (14)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[15]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[15]); } } while (0);
  *cosh_out = (int16_t)(((int32_t)x * 19784) >> 14);
  *sinh_out = (int16_t)(((int32_t)y * 19784) >> 14);
}

static inline int16_t cordic16_sinh(int16_t angle) {
  int16_t s, c;
  cordic16_sinhcosh(angle, &s, &c);
  return s;
}
static inline int16_t cordic16_cosh(int16_t angle) {
  int16_t s, c;
  cordic16_sinhcosh(angle, &s, &c);
  return c;
}


static inline int16_t cordic16_tanh(int16_t angle) {
  int16_t x = 16384;
  int16_t y = 0;
  int16_t z = angle;
  do { int16_t dx = (int16_t)(x >> (1)); int16_t dy = (int16_t)(y >> (1)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[0]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[0]); } } while (0); do { int16_t dx = (int16_t)(x >> (2)); int16_t dy = (int16_t)(y >> (2)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[1]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[1]); } } while (0); do { int16_t dx = (int16_t)(x >> (3)); int16_t dy = (int16_t)(y >> (3)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[2]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[2]); } } while (0); do { int16_t dx = (int16_t)(x >> (4)); int16_t dy = (int16_t)(y >> (4)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[3]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[3]); } } while (0);
  do { int16_t dx = (int16_t)(x >> (4)); int16_t dy = (int16_t)(y >> (4)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[4]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[4]); } } while (0); do { int16_t dx = (int16_t)(x >> (5)); int16_t dy = (int16_t)(y >> (5)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[5]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[5]); } } while (0); do { int16_t dx = (int16_t)(x >> (6)); int16_t dy = (int16_t)(y >> (6)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[6]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[6]); } } while (0); do { int16_t dx = (int16_t)(x >> (7)); int16_t dy = (int16_t)(y >> (7)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[7]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[7]); } } while (0);
  do { int16_t dx = (int16_t)(x >> (8)); int16_t dy = (int16_t)(y >> (8)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[8]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[8]); } } while (0); do { int16_t dx = (int16_t)(x >> (9)); int16_t dy = (int16_t)(y >> (9)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[9]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[9]); } } while (0); do { int16_t dx = (int16_t)(x >> (10)); int16_t dy = (int16_t)(y >> (10)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[10]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[10]); } } while (0); do { int16_t dx = (int16_t)(x >> (11)); int16_t dy = (int16_t)(y >> (11)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[11]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[11]); } } while (0);
  do { int16_t dx = (int16_t)(x >> (12)); int16_t dy = (int16_t)(y >> (12)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[12]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[12]); } } while (0); do { int16_t dx = (int16_t)(x >> (13)); int16_t dy = (int16_t)(y >> (13)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[13]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[13]); } } while (0); do { int16_t dx = (int16_t)(x >> (13)); int16_t dy = (int16_t)(y >> (13)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[14]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[14]); } } while (0); do { int16_t dx = (int16_t)(x >> (14)); int16_t dy = (int16_t)(y >> (14)); if (z >= 0) { x = (int16_t)(x + dy); y = (int16_t)(y + dx); z = (int16_t)(z - cordic16_atanh_tbl[15]); } else { x = (int16_t)(x - dy); y = (int16_t)(y - dx); z = (int16_t)(z + cordic16_atanh_tbl[15]); } } while (0);
  return cordic16_q214_div(y, x);
}
# 23 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/cordic.h" 2







typedef struct { int16_t r; uint8_t qd; } rotor;

static inline void rotor_init(rotor *o) { o->r = 0; o->qd = 0; }


static inline uint16_t cordic_fold(uint16_t h, uint16_t v) {
  return (uint16_t)(((h << 1) | (h >> 15)) ^ v);
}



static inline void rotor_sincos(rotor *o, int16_t *sin_out, int16_t *cos_out) {
  int16_t s0, c0;
  cordic16_sincos(o->r, &s0, &c0);
  switch (o->qd & 3u) {
    case 0: *cos_out = c0; *sin_out = s0; break;
    case 1: *cos_out = (int16_t)-s0; *sin_out = c0; break;
    case 2: *cos_out = (int16_t)-c0; *sin_out = (int16_t)-s0; break;
    default: *cos_out = s0; *sin_out = (int16_t)-c0; break;
  }
  o->r = (int16_t)(o->r + (25736 / 24));
  if (o->r >= 25736) { o->r = (int16_t)(o->r - 25736); o->qd = (uint8_t)(o->qd + 1u); }
}






__attribute__((noinline))
static uint16_t cordic_gate_crc(void) {
  uint16_t h = 0;
  rotor o; rotor_init(&o);
  for (uint16_t k = 0; k < 96u; k++) {
    int16_t base_s, base_c;
    cordic16_sincos(o.r, &base_s, &base_c);
    int16_t s, c; rotor_sincos(&o, &s, &c);
    h = cordic_fold(h, (uint16_t)s);
    h = cordic_fold(h, (uint16_t)c);
    h = cordic_fold(h, (uint16_t)cordic16_atan2(base_s, base_c));
  }
  return h;
}
# 11 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/cordic_sim.c" 2

volatile uint16_t corpus_result;

int main(void) {
    corpus_result = cordic_gate_crc();
    for (;;) __asm__ volatile("");
    return 0;
}
