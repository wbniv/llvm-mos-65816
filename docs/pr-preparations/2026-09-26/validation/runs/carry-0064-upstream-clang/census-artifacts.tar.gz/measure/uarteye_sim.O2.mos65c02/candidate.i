# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/uarteye_sim.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/uarteye_sim.c" 2






# 1 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/uarteye.h" 1
# 20 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/uarteye.h"
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 1 3
# 100 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef long long int int64_t;

typedef long long unsigned int uint64_t;
# 122 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int64_t int_least64_t;
typedef uint64_t uint_least64_t;
typedef int64_t int_fast64_t;
typedef uint64_t uint_fast64_t;
# 197 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef long int int32_t;




typedef long unsigned int uint32_t;
# 220 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int32_t int_least32_t;
typedef uint32_t uint_least32_t;
typedef int32_t int_fast32_t;
typedef uint32_t uint_fast32_t;
# 245 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int int16_t;

typedef unsigned int uint16_t;
# 259 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int16_t int_least16_t;
typedef uint16_t uint_least16_t;
typedef int16_t int_fast16_t;
typedef uint16_t uint_fast16_t;





typedef signed char int8_t;

typedef unsigned char uint8_t;







typedef int8_t int_least8_t;
typedef uint8_t uint_least8_t;
typedef int8_t int_fast8_t;
typedef uint8_t uint_fast8_t;
# 295 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int intptr_t;






typedef unsigned int uintptr_t;





typedef long long int intmax_t;
typedef long long unsigned int uintmax_t;
# 21 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/uarteye.h" 2


static inline uint16_t uart_frame(uint8_t b) {
    return (uint16_t)(((uint16_t)1u << 9) | ((uint16_t)b << 1));
}




__attribute__((noinline))
static uint8_t uart_roundtrip(uint8_t b) {
    uint16_t tx = uart_frame(b);
    uint16_t rx = (uint16_t)0u;
    for (uint8_t i = (uint8_t)0u; i < (uint8_t)10u; i++) {
        uint8_t bit = (uint8_t)(tx & (uint16_t)1u);
        tx = (uint16_t)(tx >> 1);
        rx = (uint16_t)((uint16_t)(rx >> 1) | (uint16_t)((uint16_t)bit << 9));
    }
    return (uint8_t)((uint16_t)(rx >> 1) & (uint16_t)0xFFu);
}




static inline uint8_t uart_level(uint8_t b, uint8_t bit_index) {
    uint16_t frame = uart_frame(b);
    return (uint8_t)((frame >> bit_index) & (uint16_t)1u);
}

static inline uint16_t ue_fold(uint16_t h, uint16_t v) {
    return (uint16_t)((((uint16_t)(h << 1)) | (uint16_t)((h >> 15) & 1u)) ^ v);
}
# 62 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/uarteye.h"
static uint16_t uarteye_gate_crc(void) {
    uint16_t h = (uint16_t)0u;
    uint16_t seed = (uint16_t)0x55AAu;
    for (uint16_t i = (uint16_t)0u; i < (uint16_t)128u; i++) {
        seed = (uint16_t)(seed * 25173u + 13849u);
        uint8_t b = (uint8_t)(seed >> 7);
        uint8_t r = uart_roundtrip(b);
        h = ue_fold(h, (uint16_t)r);
        h = ue_fold(h, (uint16_t)((uint16_t)(uint8_t)(r ^ b)));
        h = ue_fold(h, uart_frame(b));
    }
    return h;
}
# 8 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/uarteye_sim.c" 2
volatile uint16_t corpus_result;
int main(void){ corpus_result = uarteye_gate_crc(); for (;;) __asm__ volatile(""); return 0; }
