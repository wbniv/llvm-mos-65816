; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/bitshuffle_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/bitshuffle_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  br label %for.cond.i

for.cond.i:                                       ; preds = %for.body.i, %entry
  %i.0.i = phi i16 [ 0, %entry ], [ %inc.i, %for.body.i ]
  %h.0.i = phi i16 [ 0, %entry ], [ %xor.i46.i, %for.body.i ]
  %exitcond.not.i = icmp eq i16 %i.0.i, 256
  br i1 %exitcond.not.i, label %bitshuffle_gate_crc.exit, label %for.body.i

for.body.i:                                       ; preds = %for.cond.i
  %conv.i = zext nneg i16 %i.0.i to i32
  %xor.i = mul nuw nsw i32 %conv.i, 131136
  %mul.i = mul nuw nsw i16 %i.0.i, 5
  %conv3.i = zext nneg i16 %mul.i to i32
  %xor4.i = xor i32 %xor.i, %conv3.i
  %xor5.i = xor i32 %xor4.i, -1640531527
  %0 = tail call noundef i32 @llvm.bitreverse.i32(i32 range(i32 -1644167168, 256) %xor5.i)
  %xor6.i = xor i32 %xor4.i, -878884235
  %1 = tail call noundef i32 @llvm.bswap.i32(i32 range(i32 -905969664, -872415232) %xor6.i)
  %2 = tail call noundef i32 @llvm.bitreverse.i32(i32 range(i32 -1644167168, 256) %conv.i)
  %shr.i.i = lshr exact i32 %2, 24
  %3 = tail call noundef i32 @llvm.bitreverse.i32(i32 range(i32 -1644167168, 256) %shr.i.i)
  %conv10.i = trunc i32 %0 to i16
  %or.i.i = tail call i16 @llvm.fshl.i16(i16 %h.0.i, i16 %h.0.i, i16 1)
  %xor.i.i = xor i16 %or.i.i, %conv10.i
  %shr.i = lshr i32 %0, 16
  %conv12.i = trunc nuw i32 %shr.i to i16
  %or.i39.i = tail call i16 @llvm.fshl.i16(i16 %xor.i.i, i16 %xor.i.i, i16 1)
  %xor.i40.i = xor i16 %or.i39.i, %conv12.i
  %conv14.i = trunc i32 %1 to i16
  %or.i41.i = tail call i16 @llvm.fshl.i16(i16 %xor.i40.i, i16 %xor.i40.i, i16 1)
  %xor.i42.i = xor i16 %or.i41.i, %conv14.i
  %shr16.i = lshr i32 %1, 16
  %conv17.i = trunc nuw i32 %shr16.i to i16
  %or.i43.i = tail call i16 @llvm.fshl.i16(i16 %xor.i42.i, i16 %xor.i42.i, i16 1)
  %xor.i44.i = xor i16 %or.i43.i, %conv17.i
  %sh.diff.i = lshr exact i32 %3, 16
  %xor2047.i = or disjoint i32 %sh.diff.i, %shr.i.i
  %xor20.i = trunc nuw i32 %xor2047.i to i16
  %or.i45.i = tail call i16 @llvm.fshl.i16(i16 %xor.i44.i, i16 %xor.i44.i, i16 1)
  %xor.i46.i = xor i16 %or.i45.i, %xor20.i
  %inc.i = add nuw nsw i16 %i.0.i, 1
  br label %for.cond.i, !llvm.loop !7

bitshuffle_gate_crc.exit:                         ; preds = %for.cond.i
  store volatile i16 %h.0.i, ptr @corpus_result, align 1, !tbaa !9
  br label %for.cond

for.cond:                                         ; preds = %for.cond, %bitshuffle_gate_crc.exit
  tail call void asm sideeffect "", ""() #3, !srcloc !10
  br label %for.cond
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bitreverse.i32(i32) #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #2

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 7bd67c0ae4e8bb65a3f980912bf201df22131e34)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!4, !4, i64 0}
!10 = !{i64 466}
