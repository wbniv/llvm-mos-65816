; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/lsystem_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/lsystem_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.LTurtle = type { i32, i32, i8, i8 }

@corpus_result = dso_local global i16 0, align 1
@ls_buf = internal unnamed_addr global [2400 x i8] zeroinitializer, align 1
@.str = private unnamed_addr constant [19 x i8] c"F-[[X]+X]+F[+FX]-X\00", align 1
@.str.1 = private unnamed_addr constant [3 x i8] c"FF\00", align 1
@SINCOS = internal unnamed_addr constant [256 x i16] [i16 0, i16 6, i16 13, i16 19, i16 25, i16 31, i16 38, i16 44, i16 50, i16 56, i16 62, i16 68, i16 74, i16 80, i16 86, i16 92, i16 98, i16 104, i16 109, i16 115, i16 121, i16 126, i16 132, i16 137, i16 142, i16 147, i16 152, i16 157, i16 162, i16 167, i16 172, i16 177, i16 181, i16 185, i16 190, i16 194, i16 198, i16 202, i16 206, i16 209, i16 213, i16 216, i16 220, i16 223, i16 226, i16 229, i16 231, i16 234, i16 237, i16 239, i16 241, i16 243, i16 245, i16 247, i16 248, i16 250, i16 251, i16 252, i16 253, i16 254, i16 255, i16 255, i16 256, i16 256, i16 256, i16 256, i16 256, i16 255, i16 255, i16 254, i16 253, i16 252, i16 251, i16 250, i16 248, i16 247, i16 245, i16 243, i16 241, i16 239, i16 237, i16 234, i16 231, i16 229, i16 226, i16 223, i16 220, i16 216, i16 213, i16 209, i16 206, i16 202, i16 198, i16 194, i16 190, i16 185, i16 181, i16 177, i16 172, i16 167, i16 162, i16 157, i16 152, i16 147, i16 142, i16 137, i16 132, i16 126, i16 121, i16 115, i16 109, i16 104, i16 98, i16 92, i16 86, i16 80, i16 74, i16 68, i16 62, i16 56, i16 50, i16 44, i16 38, i16 31, i16 25, i16 19, i16 13, i16 6, i16 0, i16 -6, i16 -13, i16 -19, i16 -25, i16 -31, i16 -38, i16 -44, i16 -50, i16 -56, i16 -62, i16 -68, i16 -74, i16 -80, i16 -86, i16 -92, i16 -98, i16 -104, i16 -109, i16 -115, i16 -121, i16 -126, i16 -132, i16 -137, i16 -142, i16 -147, i16 -152, i16 -157, i16 -162, i16 -167, i16 -172, i16 -177, i16 -181, i16 -185, i16 -190, i16 -194, i16 -198, i16 -202, i16 -206, i16 -209, i16 -213, i16 -216, i16 -220, i16 -223, i16 -226, i16 -229, i16 -231, i16 -234, i16 -237, i16 -239, i16 -241, i16 -243, i16 -245, i16 -247, i16 -248, i16 -250, i16 -251, i16 -252, i16 -253, i16 -254, i16 -255, i16 -255, i16 -256, i16 -256, i16 -256, i16 -256, i16 -256, i16 -255, i16 -255, i16 -254, i16 -253, i16 -252, i16 -251, i16 -250, i16 -248, i16 -247, i16 -245, i16 -243, i16 -241, i16 -239, i16 -237, i16 -234, i16 -231, i16 -229, i16 -226, i16 -223, i16 -220, i16 -216, i16 -213, i16 -209, i16 -206, i16 -202, i16 -198, i16 -194, i16 -190, i16 -185, i16 -181, i16 -177, i16 -172, i16 -167, i16 -162, i16 -157, i16 -152, i16 -147, i16 -142, i16 -137, i16 -132, i16 -126, i16 -121, i16 -115, i16 -109, i16 -104, i16 -98, i16 -92, i16 -86, i16 -80, i16 -74, i16 -68, i16 -62, i16 -56, i16 -50, i16 -44, i16 -38, i16 -31, i16 -25, i16 -19, i16 -13, i16 -6], align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  %stk.i.i = alloca [24 x %struct.LTurtle], align 1
  store i8 88, ptr @ls_buf, align 1, !tbaa !7
  br label %for.cond.i.i

for.cond.i.i:                                     ; preds = %for.inc.i.i, %entry
  %len.0.i.i = phi i16 [ 1, %entry ], [ %len.1.i.i.ph, %for.inc.i.i ]
  %g.0.i.i = phi i8 [ 0, %entry ], [ %inc23.i.i, %for.inc.i.i ]
  %exitcond.not.i.i = icmp eq i8 %g.0.i.i, 6
  br i1 %exitcond.not.i.i, label %lsystem_build.exit.i, label %while.cond.i.i.outer

while.cond.i.i.outer:                             ; preds = %for.cond.i.i, %if.end8.i.i
  %len.1.i.i.ph = phi i16 [ %add.i.i, %if.end8.i.i ], [ %len.0.i.i, %for.cond.i.i ]
  %i.0.i.i.ph = phi i16 [ %add9.i.i, %if.end8.i.i ], [ 0, %for.cond.i.i ]
  br label %while.cond.i.i

while.cond.i.i:                                   ; preds = %while.cond.i.i.outer, %if.then.i.i
  %i.0.i.i = phi i16 [ %inc.i.i, %if.then.i.i ], [ %i.0.i.i.ph, %while.cond.i.i.outer ]
  %cmp2.i.i = icmp ult i16 %i.0.i.i, %len.1.i.i.ph
  br i1 %cmp2.i.i, label %while.body.i.i, label %for.inc.i.i

while.body.i.i:                                   ; preds = %while.cond.i.i
  %arrayidx.i.i = getelementptr inbounds nuw i8, ptr @ls_buf, i16 %i.0.i.i
  %0 = load i8, ptr %arrayidx.i.i, align 1, !tbaa !7
  %switch.selectcmp.i.i.i = icmp eq i8 %0, 70
  %switch.select.i.i.i = select i1 %switch.selectcmp.i.i.i, ptr @.str.1, ptr null
  %switch.selectcmp2.i.i.i = icmp eq i8 %0, 88
  %switch.select3.i.i.i = select i1 %switch.selectcmp2.i.i.i, ptr @.str, ptr %switch.select.i.i.i
  %tobool.not.i.i = icmp eq ptr %switch.select3.i.i.i, null
  br i1 %tobool.not.i.i, label %if.then.i.i, label %if.end.i.i

if.then.i.i:                                      ; preds = %while.body.i.i
  %inc.i.i = add nuw nsw i16 %i.0.i.i, 1
  br label %while.cond.i.i, !llvm.loop !8

if.end.i.i:                                       ; preds = %while.body.i.i
  %call4.i.i = tail call i16 @strlen(ptr noundef nonnull dereferenceable(1) %switch.select3.i.i.i) #4
  %sub.i.i = add nsw i16 %len.1.i.i.ph, -1
  %add.i.i = add i16 %sub.i.i, %call4.i.i
  %cmp5.i.i = icmp ugt i16 %add.i.i, 2399
  br i1 %cmp5.i.i, label %lsystem_build.exit.i, label %if.end8.i.i

if.end8.i.i:                                      ; preds = %if.end.i.i
  %add9.i.i = add i16 %call4.i.i, %i.0.i.i
  %arrayidx10.i.i = getelementptr inbounds nuw i8, ptr @ls_buf, i16 %add9.i.i
  %add11.i.i = add nuw nsw i16 %i.0.i.i, 1
  %arrayidx12.i.i = getelementptr inbounds nuw i8, ptr @ls_buf, i16 %add11.i.i
  %sub14.i.i = sub nuw nsw i16 %len.1.i.i.ph, %add11.i.i
  tail call void @llvm.memmove.p0.p0.i16(ptr nonnull align 1 %arrayidx10.i.i, ptr nonnull align 1 %arrayidx12.i.i, i16 %sub14.i.i, i1 false)
  tail call void @llvm.memcpy.p0.p0.i16(ptr nonnull align 1 %arrayidx.i.i, ptr nonnull align 1 %switch.select3.i.i.i, i16 %call4.i.i, i1 false)
  br label %while.cond.i.i.outer

for.inc.i.i:                                      ; preds = %while.cond.i.i
  %inc23.i.i = add nuw nsw i8 %g.0.i.i, 1
  br label %for.cond.i.i, !llvm.loop !10

lsystem_build.exit.i:                             ; preds = %for.cond.i.i, %if.end.i.i
  %len.5.i.i = phi i16 [ %len.1.i.i.ph, %if.end.i.i ], [ %len.0.i.i, %for.cond.i.i ]
  call void @llvm.lifetime.start.p0(ptr nonnull %stk.i.i) #5
  br label %for.cond.i2.i

for.cond.i2.i:                                    ; preds = %if.end108.i.i, %lsystem_build.exit.i
  %t.sroa.19.0.i.i = phi i8 [ 0, %lsystem_build.exit.i ], [ %t.sroa.19.1.i.i, %if.end108.i.i ]
  %t.sroa.12.0.i.i = phi i8 [ -64, %lsystem_build.exit.i ], [ %t.sroa.12.1.i.i, %if.end108.i.i ]
  %t.sroa.8.0.i.i = phi i32 [ 31744, %lsystem_build.exit.i ], [ %t.sroa.8.1.i.i, %if.end108.i.i ]
  %t.sroa.0.0.i.i = phi i32 [ 17920, %lsystem_build.exit.i ], [ %t.sroa.0.1.i.i, %if.end108.i.i ]
  %sp.0.i.i = phi i8 [ 0, %lsystem_build.exit.i ], [ %sp.2.i.i, %if.end108.i.i ]
  %crc.0.i.i = phi i16 [ -1, %lsystem_build.exit.i ], [ %crc.1.i.i, %if.end108.i.i ]
  %i.0.i3.i = phi i16 [ 0, %lsystem_build.exit.i ], [ %inc109.i.i, %if.end108.i.i ]
  %exitcond.not.i4.i = icmp eq i16 %i.0.i3.i, %len.5.i.i
  br i1 %exitcond.not.i4.i, label %lsystem_gate_crc.exit, label %for.body.i.i

for.body.i.i:                                     ; preds = %for.cond.i2.i
  %arrayidx.i5.i = getelementptr inbounds nuw i8, ptr @ls_buf, i16 %i.0.i3.i
  %1 = load i8, ptr %arrayidx.i5.i, align 1, !tbaa !7
  switch i8 %1, label %if.end108.i.i [
    i8 70, label %if.then.i8.i
    i8 43, label %if.then57.i.i
    i8 45, label %if.then66.i.i
    i8 91, label %if.then76.i.i
    i8 93, label %if.then96.i.i
  ]

if.then.i8.i:                                     ; preds = %for.body.i.i
  %conv5.i.i = zext i8 %t.sroa.12.0.i.i to i16
  %add.i9.i = add i8 %t.sroa.12.0.i.i, 64
  %idxprom.i.i = zext i8 %add.i9.i to i16
  %arrayidx7.i.i = getelementptr inbounds nuw [2 x i8], ptr @SINCOS, i16 %idxprom.i.i
  %2 = load i16, ptr %arrayidx7.i.i, align 1, !tbaa !11
  %conv8.i.i = sext i16 %2 to i32
  %mul.i.i = mul nsw i32 %conv8.i.i, 38
  %shr.i.i = ashr i32 %mul.i.i, 4
  %add9.i10.i = add nsw i32 %shr.i.i, %t.sroa.0.0.i.i
  %arrayidx13.i.i = getelementptr inbounds nuw [2 x i8], ptr @SINCOS, i16 %conv5.i.i
  %3 = load i16, ptr %arrayidx13.i.i, align 1, !tbaa !11
  %conv14.i.i = sext i16 %3 to i32
  %mul15.i.i = mul nsw i32 %conv14.i.i, 38
  %shr16.i.i = ashr i32 %mul15.i.i, 4
  %add17.i.i = add nsw i32 %shr16.i.i, %t.sroa.8.0.i.i
  %shr.i.i.i = ashr i32 %t.sroa.0.0.i.i, 8
  %cmp.i.i.i = icmp slt i32 %shr.i.i.i, 0
  br i1 %cmp.i.i.i, label %ls_px.exit.i.i, label %if.else.i.i.i

if.else.i.i.i:                                    ; preds = %if.then.i8.i
  %cmp1.i.i.i = icmp samesign ugt i32 %shr.i.i.i, 127
  %extract.t.i.i.i = trunc nuw nsw i32 %shr.i.i.i to i8
  br i1 %cmp1.i.i.i, label %if.then2.i.i.i, label %ls_px.exit.i.i

if.then2.i.i.i:                                   ; preds = %if.else.i.i.i
  br label %ls_px.exit.i.i

ls_px.exit.i.i:                                   ; preds = %if.then2.i.i.i, %if.else.i.i.i, %if.then.i8.i
  %p.0.off0.i.i.i = phi i8 [ %extract.t.i.i.i, %if.else.i.i.i ], [ 127, %if.then2.i.i.i ], [ 0, %if.then.i8.i ]
  %shr.i145.i.i = ashr i32 %t.sroa.8.0.i.i, 8
  %cmp.i146.i.i = icmp slt i32 %shr.i145.i.i, 0
  br i1 %cmp.i146.i.i, label %ls_px.exit152.i.i, label %if.else.i147.i.i

if.else.i147.i.i:                                 ; preds = %ls_px.exit.i.i
  %cmp1.i148.i.i = icmp samesign ugt i32 %shr.i145.i.i, 127
  %extract.t.i149.i.i = trunc nuw nsw i32 %shr.i145.i.i to i8
  br i1 %cmp1.i148.i.i, label %if.then2.i151.i.i, label %ls_px.exit152.i.i

if.then2.i151.i.i:                                ; preds = %if.else.i147.i.i
  br label %ls_px.exit152.i.i

ls_px.exit152.i.i:                                ; preds = %if.then2.i151.i.i, %if.else.i147.i.i, %ls_px.exit.i.i
  %p.0.off0.i150.i.i = phi i8 [ %extract.t.i149.i.i, %if.else.i147.i.i ], [ 127, %if.then2.i151.i.i ], [ 0, %ls_px.exit.i.i ]
  %shr.i153.i.i = ashr i32 %add9.i10.i, 8
  %cmp.i154.i.i = icmp slt i32 %shr.i153.i.i, 0
  br i1 %cmp.i154.i.i, label %ls_px.exit160.i.i, label %if.else.i155.i.i

if.else.i155.i.i:                                 ; preds = %ls_px.exit152.i.i
  %cmp1.i156.i.i = icmp samesign ugt i32 %shr.i153.i.i, 127
  %extract.t.i157.i.i = trunc nuw nsw i32 %shr.i153.i.i to i8
  br i1 %cmp1.i156.i.i, label %if.then2.i159.i.i, label %ls_px.exit160.i.i

if.then2.i159.i.i:                                ; preds = %if.else.i155.i.i
  br label %ls_px.exit160.i.i

ls_px.exit160.i.i:                                ; preds = %if.then2.i159.i.i, %if.else.i155.i.i, %ls_px.exit152.i.i
  %p.0.off0.i158.i.i = phi i8 [ %extract.t.i157.i.i, %if.else.i155.i.i ], [ 127, %if.then2.i159.i.i ], [ 0, %ls_px.exit152.i.i ]
  %shr.i161.i.i = ashr i32 %add17.i.i, 8
  %cmp.i162.i.i = icmp slt i32 %shr.i161.i.i, 0
  br i1 %cmp.i162.i.i, label %ls_px.exit168.i.i, label %if.else.i163.i.i

if.else.i163.i.i:                                 ; preds = %ls_px.exit160.i.i
  %cmp1.i164.i.i = icmp samesign ugt i32 %shr.i161.i.i, 127
  %extract.t.i165.i.i = trunc nuw nsw i32 %shr.i161.i.i to i8
  br i1 %cmp1.i164.i.i, label %if.then2.i167.i.i, label %ls_px.exit168.i.i

if.then2.i167.i.i:                                ; preds = %if.else.i163.i.i
  br label %ls_px.exit168.i.i

ls_px.exit168.i.i:                                ; preds = %if.then2.i167.i.i, %if.else.i163.i.i, %ls_px.exit160.i.i
  %p.0.off0.i166.i.i = phi i8 [ %extract.t.i165.i.i, %if.else.i163.i.i ], [ 127, %if.then2.i167.i.i ], [ 0, %ls_px.exit160.i.i ]
  %cmp25.i.i = icmp eq i8 %t.sroa.19.0.i.i, 0
  br i1 %cmp25.i.i, label %if.end.i11.i, label %cond.false.i.i

cond.false.i.i:                                   ; preds = %ls_px.exit168.i.i
  %cmp29.i.i = icmp ult i8 %t.sroa.19.0.i.i, 3
  %extract.t.i.i = select i1 %cmp29.i.i, i8 2, i8 3
  br label %if.end.i11.i

if.end.i11.i:                                     ; preds = %cond.false.i.i, %ls_px.exit168.i.i
  %cond31.off0.i.i = phi i8 [ %extract.t.i.i, %cond.false.i.i ], [ 1, %ls_px.exit168.i.i ]
  %or.i.i = tail call i16 @llvm.fshl.i16(i16 %crc.0.i.i, i16 %crc.0.i.i, i16 1)
  %conv34.i.i = zext nneg i8 %p.0.off0.i.i.i to i16
  %shl35.i.i = shl nuw nsw i16 %conv34.i.i, 8
  %conv36.i.i = zext nneg i8 %p.0.off0.i150.i.i to i16
  %or37.i.i = or disjoint i16 %shl35.i.i, %conv36.i.i
  %xor.i.i = xor i16 %or37.i.i, %or.i.i
  %or40.i.i = tail call i16 @llvm.fshl.i16(i16 %xor.i.i, i16 %xor.i.i, i16 1)
  %conv41.i.i = zext nneg i8 %p.0.off0.i158.i.i to i16
  %shl42.i.i = shl nuw nsw i16 %conv41.i.i, 8
  %conv43.i.i = zext nneg i8 %p.0.off0.i166.i.i to i16
  %or44.i.i = or disjoint i16 %shl42.i.i, %conv43.i.i
  %xor45.i.i = xor i16 %or44.i.i, %or40.i.i
  %or48.i.i = tail call i16 @llvm.fshl.i16(i16 %xor45.i.i, i16 %xor45.i.i, i16 1)
  %conv49.i.i = zext nneg i8 %cond31.off0.i.i to i16
  %xor50.i.i = xor i16 %or48.i.i, %conv49.i.i
  br label %if.end108.i.i

if.then57.i.i:                                    ; preds = %for.body.i.i
  %sub.i7.i = add i8 %t.sroa.12.0.i.i, -18
  br label %if.end108.i.i

if.then66.i.i:                                    ; preds = %for.body.i.i
  %add69.i.i = add i8 %t.sroa.12.0.i.i, 18
  br label %if.end108.i.i

if.then76.i.i:                                    ; preds = %for.body.i.i
  %cmp78.i.i = icmp ult i8 %sp.0.i.i, 24
  br i1 %cmp78.i.i, label %if.then80.i.i, label %if.end83.i.i

if.then80.i.i:                                    ; preds = %if.then76.i.i
  %conv77.i.i = zext nneg i8 %sp.0.i.i to i16
  %inc.i6.i = add nuw nsw i8 %sp.0.i.i, 1
  %arrayidx82.i.i = getelementptr inbounds nuw [10 x i8], ptr %stk.i.i, i16 %conv77.i.i
  store i32 %t.sroa.0.0.i.i, ptr %arrayidx82.i.i, align 1, !tbaa !12
  %t.sroa.8.0.arrayidx82.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %arrayidx82.i.i, i16 4
  store i32 %t.sroa.8.0.i.i, ptr %t.sroa.8.0.arrayidx82.sroa_idx.i.i, align 1, !tbaa !12
  %t.sroa.12.0.arrayidx82.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %arrayidx82.i.i, i16 8
  store i8 %t.sroa.12.0.i.i, ptr %t.sroa.12.0.arrayidx82.sroa_idx.i.i, align 1, !tbaa !7
  %t.sroa.19.0.arrayidx82.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %arrayidx82.i.i, i16 9
  store i8 %t.sroa.19.0.i.i, ptr %t.sroa.19.0.arrayidx82.sroa_idx.i.i, align 1, !tbaa !7
  br label %if.end83.i.i

if.end83.i.i:                                     ; preds = %if.then80.i.i, %if.then76.i.i
  %sp.1.i.i = phi i8 [ %inc.i6.i, %if.then80.i.i ], [ %sp.0.i.i, %if.then76.i.i ]
  %cmp86.not.i.i = icmp eq i8 %t.sroa.19.0.i.i, -1
  br i1 %cmp86.not.i.i, label %if.end108.i.i, label %if.then88.i.i

if.then88.i.i:                                    ; preds = %if.end83.i.i
  %inc90.i.i = add nuw i8 %t.sroa.19.0.i.i, 1
  br label %if.end108.i.i

if.then96.i.i:                                    ; preds = %for.body.i.i
  %cmp98.not.i.i = icmp eq i8 %sp.0.i.i, 0
  br i1 %cmp98.not.i.i, label %if.end108.i.i, label %if.then100.i.i

if.then100.i.i:                                   ; preds = %if.then96.i.i
  %dec.i.i = add i8 %sp.0.i.i, -1
  %idxprom101.i.i = zext i8 %dec.i.i to i16
  %arrayidx102.i.i = getelementptr inbounds nuw [10 x i8], ptr %stk.i.i, i16 %idxprom101.i.i
  %t.sroa.0.0.copyload133.i.i = load i32, ptr %arrayidx102.i.i, align 1, !tbaa !12
  %t.sroa.8.0.arrayidx102.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %arrayidx102.i.i, i16 4
  %t.sroa.8.0.copyload134.i.i = load i32, ptr %t.sroa.8.0.arrayidx102.sroa_idx.i.i, align 1, !tbaa !12
  %t.sroa.12.0.arrayidx102.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %arrayidx102.i.i, i16 8
  %t.sroa.12.0.copyload136.i.i = load i8, ptr %t.sroa.12.0.arrayidx102.sroa_idx.i.i, align 1, !tbaa !7
  %t.sroa.19.0.arrayidx102.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %arrayidx102.i.i, i16 9
  %t.sroa.19.0.copyload140.i.i = load i8, ptr %t.sroa.19.0.arrayidx102.sroa_idx.i.i, align 1, !tbaa !7
  br label %if.end108.i.i

if.end108.i.i:                                    ; preds = %if.then100.i.i, %if.then96.i.i, %if.then88.i.i, %if.end83.i.i, %if.then66.i.i, %if.then57.i.i, %if.end.i11.i, %for.body.i.i
  %t.sroa.19.1.i.i = phi i8 [ %t.sroa.19.0.i.i, %if.end.i11.i ], [ %t.sroa.19.0.i.i, %if.then57.i.i ], [ %t.sroa.19.0.i.i, %if.then66.i.i ], [ %inc90.i.i, %if.then88.i.i ], [ -1, %if.end83.i.i ], [ %t.sroa.19.0.copyload140.i.i, %if.then100.i.i ], [ %t.sroa.19.0.i.i, %if.then96.i.i ], [ %t.sroa.19.0.i.i, %for.body.i.i ]
  %t.sroa.12.1.i.i = phi i8 [ %t.sroa.12.0.i.i, %if.end.i11.i ], [ %sub.i7.i, %if.then57.i.i ], [ %add69.i.i, %if.then66.i.i ], [ %t.sroa.12.0.i.i, %if.then88.i.i ], [ %t.sroa.12.0.i.i, %if.end83.i.i ], [ %t.sroa.12.0.copyload136.i.i, %if.then100.i.i ], [ %t.sroa.12.0.i.i, %if.then96.i.i ], [ %t.sroa.12.0.i.i, %for.body.i.i ]
  %t.sroa.8.1.i.i = phi i32 [ %add17.i.i, %if.end.i11.i ], [ %t.sroa.8.0.i.i, %if.then57.i.i ], [ %t.sroa.8.0.i.i, %if.then66.i.i ], [ %t.sroa.8.0.i.i, %if.then88.i.i ], [ %t.sroa.8.0.i.i, %if.end83.i.i ], [ %t.sroa.8.0.copyload134.i.i, %if.then100.i.i ], [ %t.sroa.8.0.i.i, %if.then96.i.i ], [ %t.sroa.8.0.i.i, %for.body.i.i ]
  %t.sroa.0.1.i.i = phi i32 [ %add9.i10.i, %if.end.i11.i ], [ %t.sroa.0.0.i.i, %if.then57.i.i ], [ %t.sroa.0.0.i.i, %if.then66.i.i ], [ %t.sroa.0.0.i.i, %if.then88.i.i ], [ %t.sroa.0.0.i.i, %if.end83.i.i ], [ %t.sroa.0.0.copyload133.i.i, %if.then100.i.i ], [ %t.sroa.0.0.i.i, %if.then96.i.i ], [ %t.sroa.0.0.i.i, %for.body.i.i ]
  %sp.2.i.i = phi i8 [ %sp.0.i.i, %if.end.i11.i ], [ %sp.0.i.i, %if.then57.i.i ], [ %sp.0.i.i, %if.then66.i.i ], [ %sp.1.i.i, %if.then88.i.i ], [ %sp.1.i.i, %if.end83.i.i ], [ %dec.i.i, %if.then100.i.i ], [ 0, %if.then96.i.i ], [ %sp.0.i.i, %for.body.i.i ]
  %crc.1.i.i = phi i16 [ %xor50.i.i, %if.end.i11.i ], [ %crc.0.i.i, %if.then57.i.i ], [ %crc.0.i.i, %if.then66.i.i ], [ %crc.0.i.i, %if.then88.i.i ], [ %crc.0.i.i, %if.end83.i.i ], [ %crc.0.i.i, %if.then100.i.i ], [ %crc.0.i.i, %if.then96.i.i ], [ %crc.0.i.i, %for.body.i.i ]
  %inc109.i.i = add i16 %i.0.i3.i, 1
  br label %for.cond.i2.i, !llvm.loop !14

lsystem_gate_crc.exit:                            ; preds = %for.cond.i2.i
  call void @llvm.lifetime.end.p0(ptr nonnull %stk.i.i) #5
  store volatile i16 %crc.0.i.i, ptr @corpus_result, align 1, !tbaa !11
  br label %for.cond

for.cond:                                         ; preds = %for.cond, %lsystem_gate_crc.exit
  tail call void asm sideeffect "", ""() #5, !srcloc !15
  br label %for.cond
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: minsize mustprogress nocallback nofree nosync nounwind optsize willreturn memory(argmem: read)
declare dso_local i16 @strlen(ptr noundef captures(none)) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i16(ptr writeonly captures(none), ptr readonly captures(none), i16, i1 immarg) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #3

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { minsize mustprogress nocallback nofree nosync nounwind optsize willreturn memory(argmem: read) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { minsize nounwind optsize }
attributes #5 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 7bd67c0ae4e8bb65a3f980912bf201df22131e34)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!5, !5, i64 0}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = distinct !{!10, !9}
!11 = !{!4, !4, i64 0}
!12 = !{!13, !13, i64 0}
!13 = !{!"long", !5, i64 0}
!14 = distinct !{!14, !9}
!15 = !{i64 945}
