# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/ovmatrix_sim.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/ovmatrix_sim.c" 2
# 14 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/ovmatrix_sim.c"
# 1 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/ovmatrix.h" 1
# 41 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/ovmatrix.h"
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 1 3
# 100 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef long long int int64_t;

typedef long long unsigned int uint64_t;
# 122 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int64_t int_least64_t;
typedef uint64_t uint_least64_t;
typedef int64_t int_fast64_t;
typedef uint64_t uint_fast64_t;
# 197 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef long int int32_t;




typedef long unsigned int uint32_t;
# 220 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int32_t int_least32_t;
typedef uint32_t uint_least32_t;
typedef int32_t int_fast32_t;
typedef uint32_t uint_fast32_t;
# 245 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int int16_t;

typedef unsigned int uint16_t;
# 259 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int16_t int_least16_t;
typedef uint16_t uint_least16_t;
typedef int16_t int_fast16_t;
typedef uint16_t uint_fast16_t;





typedef signed char int8_t;

typedef unsigned char uint8_t;







typedef int8_t int_least8_t;
typedef uint8_t uint_least8_t;
typedef int8_t int_fast8_t;
typedef uint8_t uint_fast8_t;
# 295 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int intptr_t;






typedef unsigned int uintptr_t;





typedef long long int intmax_t;
typedef long long unsigned int uintmax_t;
# 42 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/ovmatrix.h" 2








static uint16_t ov_fire[18u];
static uint16_t ov_clean[18u];
static uint32_t ov_res[18u];



static uint16_t ov_u16;
static int16_t ov_i16;
static uint32_t ov_u32;
static int32_t ov_i32;
static uint64_t ov_u64;
static int64_t ov_i64;

static uint16_t ov_mul16(uint16_t a, uint16_t b) {
    return (uint16_t)((uint32_t)a * (uint32_t)b);
}
# 88 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/ovmatrix.h"
__attribute__((noinline))
static void ov_kernel(uint16_t s) {



    uint16_t small = (uint16_t)((s & 0x1FFu) + 1u);
    uint16_t gap = (uint16_t)((s >> 5) & 0x3FFu);


    do { uint16_t ov_a = (uint16_t)(ov_u16); uint16_t ov_b = (uint16_t)((uint16_t)(0xFFFFu - (uint16_t)(gap * 64u))); uint16_t ov_r; if (__builtin_add_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((0u) * 6u + (0u) * 2u + (0u)))] = (uint16_t)(ov_fire[((uint8_t)((0u) * 6u + (0u) * 2u + (0u)))] + 1u); else ov_clean[((uint8_t)((0u) * 6u + (0u) * 2u + (0u)))] = (uint16_t)(ov_clean[((uint8_t)((0u) * 6u + (0u) * 2u + (0u)))] + 1u); ov_res[((uint8_t)((0u) * 6u + (0u) * 2u + (0u)))] = (uint32_t)(ov_res[((uint8_t)((0u) * 6u + (0u) * 2u + (0u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_u16) = ov_r; } while (0);

    do { int16_t ov_a = (int16_t)((int16_t)(ov_i16 | 1)); int16_t ov_b = (int16_t)((int16_t)(32767 - (int16_t)gap)); int16_t ov_r; if (__builtin_add_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((0u) * 6u + (0u) * 2u + (1u)))] = (uint16_t)(ov_fire[((uint8_t)((0u) * 6u + (0u) * 2u + (1u)))] + 1u); else ov_clean[((uint8_t)((0u) * 6u + (0u) * 2u + (1u)))] = (uint16_t)(ov_clean[((uint8_t)((0u) * 6u + (0u) * 2u + (1u)))] + 1u); ov_res[((uint8_t)((0u) * 6u + (0u) * 2u + (1u)))] = (uint32_t)(ov_res[((uint8_t)((0u) * 6u + (0u) * 2u + (1u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_i16) = ov_r; } while (0);

    do { uint32_t ov_a = (uint32_t)(ov_u32); uint32_t ov_b = (uint32_t)((uint32_t)(0xFFFFFFFFu - (uint32_t)gap * 4194304u)); uint32_t ov_r; if (__builtin_add_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((0u) * 6u + (1u) * 2u + (0u)))] = (uint16_t)(ov_fire[((uint8_t)((0u) * 6u + (1u) * 2u + (0u)))] + 1u); else ov_clean[((uint8_t)((0u) * 6u + (1u) * 2u + (0u)))] = (uint16_t)(ov_clean[((uint8_t)((0u) * 6u + (1u) * 2u + (0u)))] + 1u); ov_res[((uint8_t)((0u) * 6u + (1u) * 2u + (0u)))] = (uint32_t)(ov_res[((uint8_t)((0u) * 6u + (1u) * 2u + (0u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_u32) = ov_r; } while (0);

    do { int32_t ov_a = (int32_t)((int32_t)(ov_i32 | 1)); int32_t ov_b = (int32_t)((int32_t)(2147483647 - (int32_t)gap * 65536)); int32_t ov_r; if (__builtin_add_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((0u) * 6u + (1u) * 2u + (1u)))] = (uint16_t)(ov_fire[((uint8_t)((0u) * 6u + (1u) * 2u + (1u)))] + 1u); else ov_clean[((uint8_t)((0u) * 6u + (1u) * 2u + (1u)))] = (uint16_t)(ov_clean[((uint8_t)((0u) * 6u + (1u) * 2u + (1u)))] + 1u); ov_res[((uint8_t)((0u) * 6u + (1u) * 2u + (1u)))] = (uint32_t)(ov_res[((uint8_t)((0u) * 6u + (1u) * 2u + (1u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_i32) = ov_r; } while (0);

    do { uint64_t ov_a = (uint64_t)(ov_u64); uint64_t ov_b = (uint64_t)((uint64_t)(0xFFFFFFFFFFFFFFFFull - (uint64_t)gap * 18014398509481984ull)); uint64_t ov_r; if (__builtin_add_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((0u) * 6u + (2u) * 2u + (0u)))] = (uint16_t)(ov_fire[((uint8_t)((0u) * 6u + (2u) * 2u + (0u)))] + 1u); else ov_clean[((uint8_t)((0u) * 6u + (2u) * 2u + (0u)))] = (uint16_t)(ov_clean[((uint8_t)((0u) * 6u + (2u) * 2u + (0u)))] + 1u); ov_res[((uint8_t)((0u) * 6u + (2u) * 2u + (0u)))] = (uint32_t)(ov_res[((uint8_t)((0u) * 6u + (2u) * 2u + (0u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_u64) = ov_r; } while (0);


    do { int64_t ov_a = (int64_t)((int64_t)(ov_i64 | 1)); int64_t ov_b = (int64_t)((int64_t)(9223372036854775807ll - (int64_t)gap * 281474976710656ll)); int64_t ov_r; if (__builtin_add_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((0u) * 6u + (2u) * 2u + (1u)))] = (uint16_t)(ov_fire[((uint8_t)((0u) * 6u + (2u) * 2u + (1u)))] + 1u); else ov_clean[((uint8_t)((0u) * 6u + (2u) * 2u + (1u)))] = (uint16_t)(ov_clean[((uint8_t)((0u) * 6u + (2u) * 2u + (1u)))] + 1u); ov_res[((uint8_t)((0u) * 6u + (2u) * 2u + (1u)))] = (uint32_t)(ov_res[((uint8_t)((0u) * 6u + (2u) * 2u + (1u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_i64) = ov_r; } while (0);




    do { uint16_t ov_a = (uint16_t)((uint16_t)(ov_u16 ^ small)); uint16_t ov_b = (uint16_t)((uint16_t)(gap * 64u)); uint16_t ov_r; if (__builtin_sub_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((1u) * 6u + (0u) * 2u + (0u)))] = (uint16_t)(ov_fire[((uint8_t)((1u) * 6u + (0u) * 2u + (0u)))] + 1u); else ov_clean[((uint8_t)((1u) * 6u + (0u) * 2u + (0u)))] = (uint16_t)(ov_clean[((uint8_t)((1u) * 6u + (0u) * 2u + (0u)))] + 1u); ov_res[((uint8_t)((1u) * 6u + (0u) * 2u + (0u)))] = (uint32_t)(ov_res[((uint8_t)((1u) * 6u + (0u) * 2u + (0u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_u16) = ov_r; } while (0);

    do { int16_t ov_a = (int16_t)((int16_t)(ov_i16 | 1)); int16_t ov_b = (int16_t)((int16_t)(-32768 + (int16_t)gap)); int16_t ov_r; if (__builtin_sub_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((1u) * 6u + (0u) * 2u + (1u)))] = (uint16_t)(ov_fire[((uint8_t)((1u) * 6u + (0u) * 2u + (1u)))] + 1u); else ov_clean[((uint8_t)((1u) * 6u + (0u) * 2u + (1u)))] = (uint16_t)(ov_clean[((uint8_t)((1u) * 6u + (0u) * 2u + (1u)))] + 1u); ov_res[((uint8_t)((1u) * 6u + (0u) * 2u + (1u)))] = (uint32_t)(ov_res[((uint8_t)((1u) * 6u + (0u) * 2u + (1u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_i16) = ov_r; } while (0);

    do { uint32_t ov_a = (uint32_t)((uint32_t)(ov_u32 ^ (uint32_t)small)); uint32_t ov_b = (uint32_t)((uint32_t)gap * 4194304u); uint32_t ov_r; if (__builtin_sub_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((1u) * 6u + (1u) * 2u + (0u)))] = (uint16_t)(ov_fire[((uint8_t)((1u) * 6u + (1u) * 2u + (0u)))] + 1u); else ov_clean[((uint8_t)((1u) * 6u + (1u) * 2u + (0u)))] = (uint16_t)(ov_clean[((uint8_t)((1u) * 6u + (1u) * 2u + (0u)))] + 1u); ov_res[((uint8_t)((1u) * 6u + (1u) * 2u + (0u)))] = (uint32_t)(ov_res[((uint8_t)((1u) * 6u + (1u) * 2u + (0u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_u32) = ov_r; } while (0);

    do { int32_t ov_a = (int32_t)((int32_t)(ov_i32 | 1)); int32_t ov_b = (int32_t)((int32_t)(-2147483647 - 1 + (int32_t)gap * 65536)); int32_t ov_r; if (__builtin_sub_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((1u) * 6u + (1u) * 2u + (1u)))] = (uint16_t)(ov_fire[((uint8_t)((1u) * 6u + (1u) * 2u + (1u)))] + 1u); else ov_clean[((uint8_t)((1u) * 6u + (1u) * 2u + (1u)))] = (uint16_t)(ov_clean[((uint8_t)((1u) * 6u + (1u) * 2u + (1u)))] + 1u); ov_res[((uint8_t)((1u) * 6u + (1u) * 2u + (1u)))] = (uint32_t)(ov_res[((uint8_t)((1u) * 6u + (1u) * 2u + (1u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_i32) = ov_r; } while (0);

    do { uint64_t ov_a = (uint64_t)((uint64_t)(ov_u64 ^ (uint64_t)small)); uint64_t ov_b = (uint64_t)((uint64_t)gap * 18014398509481984ull); uint64_t ov_r; if (__builtin_sub_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((1u) * 6u + (2u) * 2u + (0u)))] = (uint16_t)(ov_fire[((uint8_t)((1u) * 6u + (2u) * 2u + (0u)))] + 1u); else ov_clean[((uint8_t)((1u) * 6u + (2u) * 2u + (0u)))] = (uint16_t)(ov_clean[((uint8_t)((1u) * 6u + (2u) * 2u + (0u)))] + 1u); ov_res[((uint8_t)((1u) * 6u + (2u) * 2u + (0u)))] = (uint32_t)(ov_res[((uint8_t)((1u) * 6u + (2u) * 2u + (0u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_u64) = ov_r; } while (0);


    do { int64_t ov_a = (int64_t)((int64_t)(ov_i64 | 1)); int64_t ov_b = (int64_t)((int64_t)(-9223372036854775807ll - 1 + (int64_t)gap * 281474976710656ll)); int64_t ov_r; if (__builtin_sub_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((1u) * 6u + (2u) * 2u + (1u)))] = (uint16_t)(ov_fire[((uint8_t)((1u) * 6u + (2u) * 2u + (1u)))] + 1u); else ov_clean[((uint8_t)((1u) * 6u + (2u) * 2u + (1u)))] = (uint16_t)(ov_clean[((uint8_t)((1u) * 6u + (2u) * 2u + (1u)))] + 1u); ov_res[((uint8_t)((1u) * 6u + (2u) * 2u + (1u)))] = (uint32_t)(ov_res[((uint8_t)((1u) * 6u + (2u) * 2u + (1u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_i64) = ov_r; } while (0);




    do { uint16_t ov_a = (uint16_t)((uint16_t)((ov_u16 & 0x3FFu) | 1u)); uint16_t ov_b = (uint16_t)((uint16_t)(small | 1u)); uint16_t ov_r; if (__builtin_mul_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((2u) * 6u + (0u) * 2u + (0u)))] = (uint16_t)(ov_fire[((uint8_t)((2u) * 6u + (0u) * 2u + (0u)))] + 1u); else ov_clean[((uint8_t)((2u) * 6u + (0u) * 2u + (0u)))] = (uint16_t)(ov_clean[((uint8_t)((2u) * 6u + (0u) * 2u + (0u)))] + 1u); ov_res[((uint8_t)((2u) * 6u + (0u) * 2u + (0u)))] = (uint32_t)(ov_res[((uint8_t)((2u) * 6u + (0u) * 2u + (0u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_u16) = ov_r; } while (0);

    do { int16_t ov_a = (int16_t)((int16_t)((ov_i16 & 0x3FF) | 1)); int16_t ov_b = (int16_t)((int16_t)((int16_t)(small | 1u) - 256)); int16_t ov_r; if (__builtin_mul_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((2u) * 6u + (0u) * 2u + (1u)))] = (uint16_t)(ov_fire[((uint8_t)((2u) * 6u + (0u) * 2u + (1u)))] + 1u); else ov_clean[((uint8_t)((2u) * 6u + (0u) * 2u + (1u)))] = (uint16_t)(ov_clean[((uint8_t)((2u) * 6u + (0u) * 2u + (1u)))] + 1u); ov_res[((uint8_t)((2u) * 6u + (0u) * 2u + (1u)))] = (uint32_t)(ov_res[((uint8_t)((2u) * 6u + (0u) * 2u + (1u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_i16) = ov_r; } while (0);

    do { uint32_t ov_a = (uint32_t)((uint32_t)((ov_u32 & 0x03FFFFFFu) | 1u)); uint32_t ov_b = (uint32_t)((uint32_t)(small | 1u)); uint32_t ov_r; if (__builtin_mul_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((2u) * 6u + (1u) * 2u + (0u)))] = (uint16_t)(ov_fire[((uint8_t)((2u) * 6u + (1u) * 2u + (0u)))] + 1u); else ov_clean[((uint8_t)((2u) * 6u + (1u) * 2u + (0u)))] = (uint16_t)(ov_clean[((uint8_t)((2u) * 6u + (1u) * 2u + (0u)))] + 1u); ov_res[((uint8_t)((2u) * 6u + (1u) * 2u + (0u)))] = (uint32_t)(ov_res[((uint8_t)((2u) * 6u + (1u) * 2u + (0u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_u32) = ov_r; } while (0);

    do { int32_t ov_a = (int32_t)((int32_t)((ov_i32 & 0x03FFFFFF) | 1)); int32_t ov_b = (int32_t)((int32_t)((int32_t)(small | 1u) - 256)); int32_t ov_r; if (__builtin_mul_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((2u) * 6u + (1u) * 2u + (1u)))] = (uint16_t)(ov_fire[((uint8_t)((2u) * 6u + (1u) * 2u + (1u)))] + 1u); else ov_clean[((uint8_t)((2u) * 6u + (1u) * 2u + (1u)))] = (uint16_t)(ov_clean[((uint8_t)((2u) * 6u + (1u) * 2u + (1u)))] + 1u); ov_res[((uint8_t)((2u) * 6u + (1u) * 2u + (1u)))] = (uint32_t)(ov_res[((uint8_t)((2u) * 6u + (1u) * 2u + (1u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_i32) = ov_r; } while (0);

    do { uint64_t ov_a = (uint64_t)((uint64_t)((ov_u64 & 0x03FFFFFFFFFFFFFFull) | 1ull)); uint64_t ov_b = (uint64_t)((uint64_t)(small | 1u)); uint64_t ov_r; if (__builtin_mul_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((2u) * 6u + (2u) * 2u + (0u)))] = (uint16_t)(ov_fire[((uint8_t)((2u) * 6u + (2u) * 2u + (0u)))] + 1u); else ov_clean[((uint8_t)((2u) * 6u + (2u) * 2u + (0u)))] = (uint16_t)(ov_clean[((uint8_t)((2u) * 6u + (2u) * 2u + (0u)))] + 1u); ov_res[((uint8_t)((2u) * 6u + (2u) * 2u + (0u)))] = (uint32_t)(ov_res[((uint8_t)((2u) * 6u + (2u) * 2u + (0u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_u64) = ov_r; } while (0);

    do { int64_t ov_a = (int64_t)((int64_t)((ov_i64 & 0x03FFFFFFFFFFFFFFll) | 1ll)); int64_t ov_b = (int64_t)((int64_t)((int32_t)(small | 1u) - 256)); int64_t ov_r; if (__builtin_mul_overflow(ov_a, ov_b, &ov_r)) ov_fire[((uint8_t)((2u) * 6u + (2u) * 2u + (1u)))] = (uint16_t)(ov_fire[((uint8_t)((2u) * 6u + (2u) * 2u + (1u)))] + 1u); else ov_clean[((uint8_t)((2u) * 6u + (2u) * 2u + (1u)))] = (uint16_t)(ov_clean[((uint8_t)((2u) * 6u + (2u) * 2u + (1u)))] + 1u); ov_res[((uint8_t)((2u) * 6u + (2u) * 2u + (1u)))] = (uint32_t)(ov_res[((uint8_t)((2u) * 6u + (2u) * 2u + (1u)))] * 3u + (uint32_t)((uint64_t)(ov_r) & 0xFFFFFFFFu)); (ov_i64) = ov_r; } while (0);


}

static void ov_reset(void) {
    for (uint8_t c = (uint8_t)0u; c < (uint8_t)18u; c++) {
        ov_fire[c] = (uint16_t)0u;
        ov_clean[c] = (uint16_t)0u;
        ov_res[c] = (uint32_t)0u;
    }
    ov_u16 = (uint16_t)0x1357u;
    ov_i16 = (int16_t)0x2468;
    ov_u32 = (uint32_t)0x89ABCDEFu;
    ov_i32 = (int32_t)0x12345678;
    ov_u64 = (uint64_t)0x0123456789ABCDEFull;
    ov_i64 = (int64_t)0x0FEDCBA987654321ll;
}

static void ov_run(void) {
    uint16_t s = (uint16_t)0x9E3Bu;
    ov_reset();
    for (uint16_t i = (uint16_t)0u; i < (uint16_t)96u; i++) {
        s = (uint16_t)(ov_mul16(s, (uint16_t)25173u) + (uint16_t)13849u);
        ov_kernel(s);
    }
}

static uint16_t ov_mix(uint16_t h, uint16_t v) {
    h = (uint16_t)(h ^ v);
    h = (uint16_t)((uint16_t)(h << 1) | (uint16_t)(h >> 15));
    return (uint16_t)(ov_mul16(h, (uint16_t)25173u) + (uint16_t)13849u);
}
static uint16_t ov_mix32(uint16_t h, uint32_t v) {
    h = ov_mix(h, (uint16_t)(v & 0xFFFFu));
    return ov_mix(h, (uint16_t)((v >> 16) & 0xFFFFu));
}
static uint16_t ov_mix64(uint16_t h, uint64_t v) {
    h = ov_mix32(h, (uint32_t)(v & 0xFFFFFFFFu));
    return ov_mix32(h, (uint32_t)((v >> 32) & 0xFFFFFFFFu));
}




static uint16_t ovmatrix_gate_crc(void) {
    uint16_t h = (uint16_t)0x7C4Eu;
    ov_run();
    for (uint8_t c = (uint8_t)0u; c < (uint8_t)18u; c++) {
        h = ov_mix(h, ov_fire[c]);
        h = ov_mix(h, ov_clean[c]);
        h = ov_mix32(h, ov_res[c]);
    }
    h = ov_mix(h, ov_u16);
    h = ov_mix(h, (uint16_t)ov_i16);
    h = ov_mix32(h, ov_u32);
    h = ov_mix32(h, (uint32_t)ov_i32);
    h = ov_mix64(h, ov_u64);
    h = ov_mix64(h, (uint64_t)ov_i64);
    return h;
}




static uint8_t ov_two_sided_cells(void) {
    uint8_t n = (uint8_t)0u;
    for (uint8_t c = (uint8_t)0u; c < (uint8_t)18u; c++)
        if (ov_fire[c] > (uint16_t)0u && ov_clean[c] > (uint16_t)0u) n = (uint8_t)(n + 1u);
    return n;
}
# 15 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/ovmatrix_sim.c" 2

volatile uint16_t corpus_result;

int main(void) {
    corpus_result = ovmatrix_gate_crc();
    for (;;) __asm__ volatile("");
    return 0;
}
