# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/rotkal_sim.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 369 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/rotkal_sim.c" 2






# 1 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/rotkal.h" 1
# 29 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/rotkal.h"
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 1 3
# 100 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef long long int int64_t;

typedef long long unsigned int uint64_t;
# 122 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int64_t int_least64_t;
typedef uint64_t uint_least64_t;
typedef int64_t int_fast64_t;
typedef uint64_t uint_fast64_t;
# 197 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef long int int32_t;




typedef long unsigned int uint32_t;
# 220 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int32_t int_least32_t;
typedef uint32_t uint_least32_t;
typedef int32_t int_fast32_t;
typedef uint32_t uint_fast32_t;
# 245 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int int16_t;

typedef unsigned int uint16_t;
# 259 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int16_t int_least16_t;
typedef uint16_t uint_least16_t;
typedef int16_t int_fast16_t;
typedef uint16_t uint_fast16_t;





typedef signed char int8_t;

typedef unsigned char uint8_t;







typedef int8_t int_least8_t;
typedef uint8_t uint_least8_t;
typedef int8_t int_fast8_t;
typedef uint8_t uint_fast8_t;
# 295 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/baseline/lib/clang/24/include/stdint.h" 3
typedef int intptr_t;






typedef unsigned int uintptr_t;





typedef long long int intmax_t;
typedef long long unsigned int uintmax_t;
# 30 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/rotkal.h" 2
# 62 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/rotkal.h"
typedef struct {
    uint8_t ring[8];
    uint16_t outer;
} RKState;

static inline void rk_init(RKState *s) {

    s->ring[0] = (uint8_t)0xA3u;
    s->ring[1] = (uint8_t)0x5Cu;
    s->ring[2] = (uint8_t)0xE1u;
    s->ring[3] = (uint8_t)0x78u;
    s->ring[4] = (uint8_t)0x2Fu;
    s->ring[5] = (uint8_t)0x94u;
    s->ring[6] = (uint8_t)0xB7u;
    s->ring[7] = (uint8_t)0x1Du;
    s->outer = (uint16_t)0xABCDu;
}





__attribute__((noinline))
static void rk_step(RKState *s, uint16_t k) {


    s->ring[0] = __builtin_rotateleft8((uint8_t)(s->ring[0]), (unsigned char)(1));
    s->ring[1] = __builtin_rotateleft8((uint8_t)(s->ring[1]), (unsigned char)(2));
    s->ring[2] = __builtin_rotateleft8((uint8_t)(s->ring[2]), (unsigned char)(3));
    s->ring[3] = __builtin_rotateleft8((uint8_t)(s->ring[3]), (unsigned char)(1));

    s->ring[4] = __builtin_rotateright8((uint8_t)(s->ring[4]), (unsigned char)(1));
    s->ring[5] = __builtin_rotateright8((uint8_t)(s->ring[5]), (unsigned char)(2));
    s->ring[6] = __builtin_rotateright8((uint8_t)(s->ring[6]), (unsigned char)(3));
    s->ring[7] = __builtin_rotateright8((uint8_t)(s->ring[7]), (unsigned char)(1));

    s->outer = __builtin_rotateleft16((uint16_t)(s->outer), (unsigned short)((unsigned short)k));
}



static inline uint8_t rk_cell(const RKState *s, uint16_t tx, uint16_t ty) {

    int16_t dx = (int16_t)((int16_t)((uint16_t)(tx * (uint16_t)8u + (uint16_t)4u)) - (int16_t)64);
    int16_t dy = (int16_t)((int16_t)((uint16_t)(ty * (uint16_t)8u + (uint16_t)4u)) - (int16_t)64);

    uint16_t ax = (uint16_t)(dx < (int16_t)0 ? (uint16_t)(-(int16_t)dx) : (uint16_t)dx);
    uint16_t ay = (uint16_t)(dy < (int16_t)0 ? (uint16_t)(-(int16_t)dy) : (uint16_t)dy);
    uint16_t ox = (ax < ay) ? ax : ay;
    uint16_t oy = (ax < ay) ? ay : ax;


    uint16_t ring_idx = (uint16_t)(oy >> (uint16_t)3u);
    if (ring_idx > (uint16_t)7u) ring_idx = (uint16_t)7u;


    uint16_t bit_pos = (uint16_t)(ox & (uint16_t)7u);
    uint16_t ring_val = (uint16_t)((uint16_t)((uint16_t)s->ring[ring_idx] >> bit_pos) & (uint16_t)3u);


    uint16_t outer_bits = (uint16_t)((uint16_t)(s->outer >> (uint16_t)14u) & (uint16_t)3u);
    return (uint8_t)((ring_val ^ outer_bits) & (uint16_t)3u);
}


static inline uint16_t rk_fold(uint16_t h, uint16_t v) {
    return (uint16_t)((uint16_t)((uint16_t)(h << 1) | (uint16_t)((h >> 15) & (uint16_t)1u)) ^ v);
}
# 141 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/rotkal.h"
static uint16_t rotkal_gate_crc(void) {
    RKState s;
    rk_init(&s);
    uint16_t h = (uint16_t)0u;
    for (uint16_t i = (uint16_t)0u; i < (uint16_t)100u; i++) {
        uint16_t k = (uint16_t)((uint16_t)(i & (uint16_t)14u) + (uint16_t)1u);
        rk_step(&s, k);
        uint16_t r;
        for (r = (uint16_t)0u; r < (uint16_t)8u; r++) {
            h = rk_fold(h, (uint16_t)s.ring[r]);
        }
        h = rk_fold(h, s.outer);
    }
    return h;
}
# 8 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/rotkal_sim.c" 2

volatile uint16_t corpus_result;

int main(void) {
    corpus_result = rotkal_gate_crc();
    for (;;) __asm__ volatile("");
    return 0;
}
