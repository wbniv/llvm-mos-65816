; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/arrays.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/arrays.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@idx = dso_local global i8 5, align 1
@lut = internal unnamed_addr constant [8 x i8] c"\03\01\04\01\05\09\02\06", align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  %ram = alloca [8 x i8], align 1
  %0 = load volatile i8, ptr @idx, align 1, !tbaa !7
  %idxprom3 = zext i8 %0 to i16
  %arrayidx4 = getelementptr inbounds nuw i8, ptr @lut, i16 %idxprom3
  %1 = load i8, ptr %arrayidx4, align 1, !tbaa !7
  call void @llvm.lifetime.start.p0(ptr nonnull %ram) #2
  store i8 6, ptr %ram, align 1, !tbaa !7
  %uglygep52.1 = getelementptr inbounds nuw i8, ptr %ram, i16 1
  store i8 2, ptr %uglygep52.1, align 1, !tbaa !7
  %uglygep52.2 = getelementptr inbounds nuw i8, ptr %ram, i16 2
  store i8 8, ptr %uglygep52.2, align 1, !tbaa !7
  %uglygep52.3 = getelementptr inbounds nuw i8, ptr %ram, i16 3
  store i8 2, ptr %uglygep52.3, align 1, !tbaa !7
  %uglygep52.4 = getelementptr inbounds nuw i8, ptr %ram, i16 4
  store i8 10, ptr %uglygep52.4, align 1, !tbaa !7
  %uglygep52.5 = getelementptr inbounds nuw i8, ptr %ram, i16 5
  store i8 18, ptr %uglygep52.5, align 1, !tbaa !7
  %uglygep52.6 = getelementptr inbounds nuw i8, ptr %ram, i16 6
  store i8 4, ptr %uglygep52.6, align 1, !tbaa !7
  %uglygep52.7 = getelementptr inbounds nuw i8, ptr %ram, i16 7
  store i8 12, ptr %uglygep52.7, align 1, !tbaa !7
  %conv5 = zext i8 %1 to i16
  %mul = mul nuw nsw i16 %conv5, 100
  %add6 = add nuw nsw i16 %mul, 31
  br label %for.body26

for.body26:                                       ; preds = %entry, %for.body26
  %i.251 = phi i8 [ %inc32, %for.body26 ], [ 0, %entry ]
  %r.150 = phi i16 [ %add30, %for.body26 ], [ %add6, %entry ]
  %2 = zext nneg i8 %i.251 to i16
  %uglygep = getelementptr i8, ptr %ram, i16 %2
  %3 = load i8, ptr %uglygep, align 1, !tbaa !7
  %conv29 = zext i8 %3 to i16
  %add30 = add i16 %r.150, %conv29
  %inc32 = add nuw nsw i8 %i.251, 1
  %exitcond.not = icmp eq i8 %inc32, 8
  br i1 %exitcond.not, label %for.end33, label %for.body26, !llvm.loop !8

for.end33:                                        ; preds = %for.body26
  store volatile i16 %add30, ptr @corpus_result, align 1, !tbaa !10
  br label %for.cond34

for.cond34:                                       ; preds = %for.cond34, %for.end33
  tail call void asm sideeffect "", ""() #2, !srcloc !11
  br label %for.cond34
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos65c02" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 7bd67c0ae4e8bb65a3f980912bf201df22131e34)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!5, !5, i64 0}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = !{!4, !4, i64 0}
!11 = !{i64 983}
