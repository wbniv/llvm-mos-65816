# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/globals.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 370 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/globals.c" 2
# 11 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/globals.c"
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 1 3
# 100 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef long long int int64_t;

typedef long long unsigned int uint64_t;
# 122 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int64_t int_least64_t;
typedef uint64_t uint_least64_t;
typedef int64_t int_fast64_t;
typedef uint64_t uint_fast64_t;
# 197 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef long int int32_t;




typedef long unsigned int uint32_t;
# 220 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int32_t int_least32_t;
typedef uint32_t uint_least32_t;
typedef int32_t int_fast32_t;
typedef uint32_t uint_fast32_t;
# 245 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int int16_t;

typedef unsigned int uint16_t;
# 259 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int16_t int_least16_t;
typedef uint16_t uint_least16_t;
typedef int16_t int_fast16_t;
typedef uint16_t uint_fast16_t;





typedef signed char int8_t;

typedef unsigned char uint8_t;







typedef int8_t int_least8_t;
typedef uint8_t uint_least8_t;
typedef int8_t int_fast8_t;
typedef uint8_t uint_fast8_t;
# 295 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int intptr_t;






typedef unsigned int uintptr_t;





typedef long long int intmax_t;
typedef long long unsigned int uintmax_t;
# 12 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/globals.c" 2

uint16_t data_vals[4] = { 0x1111, 0x2222, 0x3333, 0x4444 };
uint8_t data_byte = 0xAB;
uint16_t bss_vals[8];
uint8_t bss_byte;
volatile uint8_t one = 1;
volatile uint16_t corpus_result;

int main(void) {
  uint16_t r = 0;
  uint8_t i;

  for (i = 0; i < 4; i++) r += (uint16_t)(data_vals[i] * one);
  r += (uint16_t)(data_byte * one);

  uint16_t bsssum = 0;
  for (i = 0; i < 8; i++) bsssum += bss_vals[i];
  bsssum += bss_byte;
  if (bsssum != 0) r += 0xF000;

  corpus_result = r;
  for (;;) __asm__ volatile("");
}
