; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/structs.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/structs.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.point = type { i8, i16, i8 }

@bump = dso_local global i8 2, align 1
@pts = internal global [3 x %struct.point] [%struct.point { i8 1, i16 100, i8 7 }, %struct.point { i8 2, i16 200, i8 8 }, %struct.point { i8 3, i16 300, i8 9 }], align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  %0 = load volatile i8, ptr @pts, align 1, !tbaa !7
  %conv2 = zext i8 %0 to i16
  %1 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 1), align 1, !tbaa !9
  %add3 = add i16 %1, %conv2
  %2 = load volatile i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 3), align 1, !tbaa !10
  %conv4 = zext i8 %2 to i16
  %add5 = add i16 %add3, %conv4
  %3 = load volatile i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 4), align 1, !tbaa !7
  %conv2.1 = zext i8 %3 to i16
  %add.1 = add i16 %add5, %conv2.1
  %4 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !9
  %add3.1 = add i16 %add.1, %4
  %5 = load volatile i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 7), align 1, !tbaa !10
  %conv4.1 = zext i8 %5 to i16
  %add5.1 = add i16 %add3.1, %conv4.1
  %6 = load volatile i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 8), align 1, !tbaa !7
  %conv2.2 = zext i8 %6 to i16
  %add.2 = add i16 %add5.1, %conv2.2
  %7 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 9), align 1, !tbaa !9
  %add3.2 = add i16 %add.2, %7
  %8 = load volatile i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 11), align 1, !tbaa !10
  %conv4.2 = zext i8 %8 to i16
  %add5.2 = add i16 %add3.2, %conv4.2
  %9 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !9
  %10 = load volatile i8, ptr @bump, align 1, !tbaa !11
  %conv6 = zext i8 %10 to i16
  %add7 = add i16 %9, %conv6
  store volatile i16 %add7, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !9
  %11 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !9
  %add8 = add i16 %11, %add5.2
  store volatile i16 %add8, ptr @corpus_result, align 1, !tbaa !12
  br label %for.cond9

for.cond9:                                        ; preds = %for.cond9, %entry
  tail call void asm sideeffect "", ""() #1, !srcloc !13
  br label %for.cond9
}

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 7bd67c0ae4e8bb65a3f980912bf201df22131e34)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!8, !5, i64 0}
!8 = !{!"point", !5, i64 0, !4, i64 1, !5, i64 3}
!9 = !{!8, !4, i64 1}
!10 = !{!8, !5, i64 3}
!11 = !{!5, !5, i64 0}
!12 = !{!4, !4, i64 0}
!13 = !{i64 1177}
