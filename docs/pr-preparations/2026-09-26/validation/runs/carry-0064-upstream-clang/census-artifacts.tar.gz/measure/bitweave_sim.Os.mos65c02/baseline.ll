; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/bitweave_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/bitweave_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  %a8.i = alloca i8, align 1
  %a16.i = alloca i16, align 1
  br label %for.body.i

for.body.i:                                       ; preds = %for.body.i, %entry
  %h.023.i = phi i16 [ 0, %entry ], [ %xor.i20.i, %for.body.i ]
  %seed.022.i = phi i16 [ -21279, %entry ], [ %add.i, %for.body.i ]
  %i.021.i = phi i16 [ 0, %entry ], [ %inc.i, %for.body.i ]
  %mul.i = mul i16 %seed.022.i, 25173
  %add.i = add i16 %mul.i, 13849
  call void @llvm.lifetime.start.p0(ptr nonnull %a8.i) #4
  %shr.i = lshr i16 %add.i, 5
  %conv.i = trunc i16 %shr.i to i8
  store i8 %conv.i, ptr %a8.i, align 1, !tbaa !7
  call void @llvm.lifetime.start.p0(ptr nonnull %a16.i) #4
  store i16 %add.i, ptr %a16.i, align 1, !tbaa !8
  call fastcc void @bw_weave(ptr noundef %a8.i, ptr noundef %a16.i) #5
  %0 = load i8, ptr %a8.i, align 1, !tbaa !7
  %conv1.i = zext i8 %0 to i16
  %or.i.i = tail call i16 @llvm.fshl.i16(i16 %h.023.i, i16 %h.023.i, i16 1)
  %xor.i.i = xor i16 %or.i.i, %conv1.i
  %1 = load i16, ptr %a16.i, align 1, !tbaa !8
  %or.i15.i = tail call i16 @llvm.fshl.i16(i16 %xor.i.i, i16 %xor.i.i, i16 1)
  %xor.i16.i = xor i16 %or.i15.i, %1
  call fastcc void @bw_weave(ptr noundef %a8.i, ptr noundef %a16.i) #5
  %2 = load i8, ptr %a8.i, align 1, !tbaa !7
  %conv3.i = zext i8 %2 to i16
  %conv4.i = and i16 %shr.i, 255
  %xor.i = xor i16 %conv4.i, %conv3.i
  %or.i17.i = tail call i16 @llvm.fshl.i16(i16 %xor.i16.i, i16 %xor.i16.i, i16 1)
  %xor.i18.i = xor i16 %xor.i, %or.i17.i
  %3 = load i16, ptr %a16.i, align 1, !tbaa !8
  %or.i19.i = tail call i16 @llvm.fshl.i16(i16 %xor.i18.i, i16 %xor.i18.i, i16 1)
  %4 = xor i16 %3, %or.i19.i
  %xor.i20.i = xor i16 %4, %add.i
  call void @llvm.lifetime.end.p0(ptr nonnull %a16.i) #4
  call void @llvm.lifetime.end.p0(ptr nonnull %a8.i) #4
  %inc.i = add nuw nsw i16 %i.021.i, 1
  %exitcond.not.i = icmp eq i16 %inc.i, 128
  br i1 %exitcond.not.i, label %bitweave_gate_crc.exit, label %for.body.i, !llvm.loop !9

bitweave_gate_crc.exit:                           ; preds = %for.body.i
  store volatile i16 %xor.i20.i, ptr @corpus_result, align 1, !tbaa !8
  br label %for.cond

for.cond:                                         ; preds = %for.cond, %bitweave_gate_crc.exit
  tail call void asm sideeffect "", ""() #4, !srcloc !11
  br label %for.cond
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(argmem: readwrite)
define internal fastcc void @bw_weave(ptr nofree noundef nonnull captures(none) %a8, ptr nofree noundef nonnull captures(none) %a16) unnamed_addr #2 {
entry:
  %0 = load i8, ptr %a8, align 1, !tbaa !7
  %1 = load i16, ptr %a16, align 1, !tbaa !8
  br label %for.body

for.cond.cleanup:                                 ; preds = %if.end
  store i8 %r8.1, ptr %a8, align 1, !tbaa !7
  store i16 %or16, ptr %a16, align 1, !tbaa !8
  ret void

for.body:                                         ; preds = %entry, %if.end
  %i.031 = phi i8 [ 0, %entry ], [ %inc, %if.end ]
  %r16.030 = phi i16 [ 0, %entry ], [ %or16, %if.end ]
  %v16.029 = phi i16 [ %1, %entry ], [ %shr17, %if.end ]
  %r8.028 = phi i8 [ 0, %entry ], [ %r8.1, %if.end ]
  %v8.027 = phi i8 [ %0, %entry ], [ %v8.1, %if.end ]
  %cmp3 = icmp samesign ult i8 %i.031, 8
  br i1 %cmp3, label %if.then, label %if.end

if.then:                                          ; preds = %for.body
  %shl = shl i8 %r8.028, 1
  %and = and i8 %v8.027, 1
  %or26 = or disjoint i8 %shl, %and
  %2 = lshr i8 %v8.027, 1
  br label %if.end

if.end:                                           ; preds = %if.then, %for.body
  %v8.1 = phi i8 [ %2, %if.then ], [ %v8.027, %for.body ]
  %r8.1 = phi i8 [ %or26, %if.then ], [ %r8.028, %for.body ]
  %shl14 = shl i16 %r16.030, 1
  %and15 = and i16 %v16.029, 1
  %or16 = or disjoint i16 %shl14, %and15
  %shr17 = lshr i16 %v16.029, 1
  %inc = add nuw nsw i8 %i.031, 1
  %exitcond.not = icmp eq i8 %inc, 16
  br i1 %exitcond.not, label %for.cond.cleanup, label %for.body, !llvm.loop !12
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #3

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos65c02" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree noinline norecurse nosync nounwind optsize memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos65c02" }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind }
attributes #5 = { optsize }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 7bd67c0ae4e8bb65a3f980912bf201df22131e34)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!5, !5, i64 0}
!8 = !{!4, !4, i64 0}
!9 = distinct !{!9, !10}
!10 = !{!"llvm.loop.mustprogress"}
!11 = !{i64 642}
!12 = distinct !{!12, !10}
