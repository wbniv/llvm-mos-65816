; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/rotkal_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/rotkal_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.RKState = type { [8 x i8], i16 }

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  %s.i = alloca %struct.RKState, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %s.i) #4
  store i8 -93, ptr %s.i, align 1, !tbaa !7
  %arrayidx2.i.i = getelementptr inbounds nuw i8, ptr %s.i, i16 1
  store i8 92, ptr %arrayidx2.i.i, align 1, !tbaa !7
  %arrayidx4.i.i = getelementptr inbounds nuw i8, ptr %s.i, i16 2
  store i8 -31, ptr %arrayidx4.i.i, align 1, !tbaa !7
  %arrayidx6.i.i = getelementptr inbounds nuw i8, ptr %s.i, i16 3
  store i8 120, ptr %arrayidx6.i.i, align 1, !tbaa !7
  %arrayidx8.i.i = getelementptr inbounds nuw i8, ptr %s.i, i16 4
  store i8 47, ptr %arrayidx8.i.i, align 1, !tbaa !7
  %arrayidx10.i.i = getelementptr inbounds nuw i8, ptr %s.i, i16 5
  store i8 -108, ptr %arrayidx10.i.i, align 1, !tbaa !7
  %arrayidx12.i.i = getelementptr inbounds nuw i8, ptr %s.i, i16 6
  store i8 -73, ptr %arrayidx12.i.i, align 1, !tbaa !7
  %arrayidx14.i.i = getelementptr inbounds nuw i8, ptr %s.i, i16 7
  store i8 29, ptr %arrayidx14.i.i, align 1, !tbaa !7
  %outer.i.i = getelementptr inbounds nuw i8, ptr %s.i, i16 8
  store i16 -21555, ptr %outer.i.i, align 1, !tbaa !8
  br label %for.body.i

for.body.i:                                       ; preds = %for.body.i, %entry
  %i.019.i = phi i16 [ 0, %entry ], [ %inc6.i, %for.body.i ]
  %h.018.i = phi i16 [ 0, %entry ], [ %xor.i15.i, %for.body.i ]
  %and.i = and i16 %i.019.i, 14
  %add.i = or disjoint i16 %and.i, 1
  call fastcc void @rk_step(ptr noundef %s.i, i16 noundef %add.i)
  %0 = load i8, ptr %s.i, align 1, !tbaa !7
  %conv.i = zext i8 %0 to i16
  %or.i.i = tail call i16 @llvm.fshl.i16(i16 %h.018.i, i16 %h.018.i, i16 1)
  %xor.i.i = xor i16 %or.i.i, %conv.i
  %1 = load i8, ptr %arrayidx2.i.i, align 1, !tbaa !7
  %conv.1.i = zext i8 %1 to i16
  %or.i.1.i = tail call i16 @llvm.fshl.i16(i16 %xor.i.i, i16 %xor.i.i, i16 1)
  %xor.i.1.i = xor i16 %or.i.1.i, %conv.1.i
  %2 = load i8, ptr %arrayidx4.i.i, align 1, !tbaa !7
  %conv.2.i = zext i8 %2 to i16
  %or.i.2.i = tail call i16 @llvm.fshl.i16(i16 %xor.i.1.i, i16 %xor.i.1.i, i16 1)
  %xor.i.2.i = xor i16 %or.i.2.i, %conv.2.i
  %3 = load i8, ptr %arrayidx6.i.i, align 1, !tbaa !7
  %conv.3.i = zext i8 %3 to i16
  %or.i.3.i = tail call i16 @llvm.fshl.i16(i16 %xor.i.2.i, i16 %xor.i.2.i, i16 1)
  %xor.i.3.i = xor i16 %or.i.3.i, %conv.3.i
  %4 = load i8, ptr %arrayidx8.i.i, align 1, !tbaa !7
  %conv.4.i = zext i8 %4 to i16
  %or.i.4.i = tail call i16 @llvm.fshl.i16(i16 %xor.i.3.i, i16 %xor.i.3.i, i16 1)
  %xor.i.4.i = xor i16 %or.i.4.i, %conv.4.i
  %5 = load i8, ptr %arrayidx10.i.i, align 1, !tbaa !7
  %conv.5.i = zext i8 %5 to i16
  %or.i.5.i = tail call i16 @llvm.fshl.i16(i16 %xor.i.4.i, i16 %xor.i.4.i, i16 1)
  %xor.i.5.i = xor i16 %or.i.5.i, %conv.5.i
  %6 = load i8, ptr %arrayidx12.i.i, align 1, !tbaa !7
  %conv.6.i = zext i8 %6 to i16
  %or.i.6.i = tail call i16 @llvm.fshl.i16(i16 %xor.i.5.i, i16 %xor.i.5.i, i16 1)
  %xor.i.6.i = xor i16 %or.i.6.i, %conv.6.i
  %7 = load i8, ptr %arrayidx14.i.i, align 1, !tbaa !7
  %conv.7.i = zext i8 %7 to i16
  %or.i.7.i = tail call i16 @llvm.fshl.i16(i16 %xor.i.6.i, i16 %xor.i.6.i, i16 1)
  %xor.i.7.i = xor i16 %or.i.7.i, %conv.7.i
  %8 = load i16, ptr %outer.i.i, align 1, !tbaa !8
  %or.i14.i = tail call i16 @llvm.fshl.i16(i16 %xor.i.7.i, i16 %xor.i.7.i, i16 1)
  %xor.i15.i = xor i16 %or.i14.i, %8
  %inc6.i = add nuw nsw i16 %i.019.i, 1
  %exitcond.not.i = icmp eq i16 %inc6.i, 100
  br i1 %exitcond.not.i, label %rotkal_gate_crc.exit, label %for.body.i, !llvm.loop !10

rotkal_gate_crc.exit:                             ; preds = %for.body.i
  call void @llvm.lifetime.end.p0(ptr nonnull %s.i) #4
  store volatile i16 %xor.i15.i, ptr @corpus_result, align 1, !tbaa !12
  br label %for.cond

for.cond:                                         ; preds = %for.cond, %rotkal_gate_crc.exit
  tail call void asm sideeffect "", ""() #4, !srcloc !13
  br label %for.cond
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite)
define internal fastcc void @rk_step(ptr nofree noundef nonnull captures(none) %s, i16 noundef range(i16 1, 16) %k) unnamed_addr #2 {
entry:
  %0 = load i8, ptr %s, align 1, !tbaa !7
  %1 = tail call i8 @llvm.fshl.i8(i8 %0, i8 %0, i8 1)
  store i8 %1, ptr %s, align 1, !tbaa !7
  %arrayidx4 = getelementptr inbounds nuw i8, ptr %s, i16 1
  %2 = load i8, ptr %arrayidx4, align 1, !tbaa !7
  %3 = tail call i8 @llvm.fshl.i8(i8 %2, i8 %2, i8 2)
  store i8 %3, ptr %arrayidx4, align 1, !tbaa !7
  %arrayidx8 = getelementptr inbounds nuw i8, ptr %s, i16 2
  %4 = load i8, ptr %arrayidx8, align 1, !tbaa !7
  %5 = tail call i8 @llvm.fshl.i8(i8 %4, i8 %4, i8 3)
  store i8 %5, ptr %arrayidx8, align 1, !tbaa !7
  %arrayidx12 = getelementptr inbounds nuw i8, ptr %s, i16 3
  %6 = load i8, ptr %arrayidx12, align 1, !tbaa !7
  %7 = tail call i8 @llvm.fshl.i8(i8 %6, i8 %6, i8 1)
  store i8 %7, ptr %arrayidx12, align 1, !tbaa !7
  %arrayidx16 = getelementptr inbounds nuw i8, ptr %s, i16 4
  %8 = load i8, ptr %arrayidx16, align 1, !tbaa !7
  %9 = tail call i8 @llvm.fshl.i8(i8 %8, i8 %8, i8 7)
  store i8 %9, ptr %arrayidx16, align 1, !tbaa !7
  %arrayidx20 = getelementptr inbounds nuw i8, ptr %s, i16 5
  %10 = load i8, ptr %arrayidx20, align 1, !tbaa !7
  %11 = tail call i8 @llvm.fshl.i8(i8 %10, i8 %10, i8 6)
  store i8 %11, ptr %arrayidx20, align 1, !tbaa !7
  %arrayidx24 = getelementptr inbounds nuw i8, ptr %s, i16 6
  %12 = load i8, ptr %arrayidx24, align 1, !tbaa !7
  %13 = tail call i8 @llvm.fshl.i8(i8 %12, i8 %12, i8 5)
  store i8 %13, ptr %arrayidx24, align 1, !tbaa !7
  %arrayidx28 = getelementptr inbounds nuw i8, ptr %s, i16 7
  %14 = load i8, ptr %arrayidx28, align 1, !tbaa !7
  %15 = tail call i8 @llvm.fshl.i8(i8 %14, i8 %14, i8 7)
  store i8 %15, ptr %arrayidx28, align 1, !tbaa !7
  %outer = getelementptr inbounds nuw i8, ptr %s, i16 8
  %16 = load i16, ptr %outer, align 1, !tbaa !8
  %17 = tail call i16 @llvm.fshl.i16(i16 %16, i16 %16, i16 %k)
  store i16 %17, ptr %outer, align 1, !tbaa !8
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fshl.i8(i8, i8, i8) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #3

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #3 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 155e209c4cee8eeac01397aac3542e76841a9856)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!5, !5, i64 0}
!8 = !{!9, !4, i64 8}
!9 = !{!"", !5, i64 0, !4, i64 8}
!10 = distinct !{!10, !11}
!11 = !{!"llvm.loop.mustprogress"}
!12 = !{!4, !4, i64 0}
!13 = !{i64 560}
