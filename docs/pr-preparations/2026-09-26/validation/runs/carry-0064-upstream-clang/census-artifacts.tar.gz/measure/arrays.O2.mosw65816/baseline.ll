; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/arrays.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/arrays.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@idx = dso_local global i8 5, align 1
@lut = internal unnamed_addr constant [8 x i8] c"\03\01\04\01\05\09\02\06", align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
entry:
  %0 = load volatile i8, ptr @idx, align 1, !tbaa !7
  %idxprom3 = zext i8 %0 to i16
  %arrayidx4 = getelementptr inbounds nuw i8, ptr @lut, i16 %idxprom3
  %1 = load i8, ptr %arrayidx4, align 1, !tbaa !7
  %conv5 = zext i8 %1 to i16
  %mul = mul nuw nsw i16 %conv5, 100
  %add30.7 = add nuw nsw i16 %mul, 93
  store volatile i16 %add30.7, ptr @corpus_result, align 1, !tbaa !8
  br label %for.cond34

for.cond34:                                       ; preds = %for.cond34, %entry
  tail call void asm sideeffect "", ""() #1, !srcloc !9
  br label %for.cond34
}

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 24.0.0git (git@github.com:wbniv/llvm-mos.git 7bd67c0ae4e8bb65a3f980912bf201df22131e34)"}
!2 = !{!3, !4, i64 0}
!3 = !{!"__libc_errno", !4, i64 0}
!4 = !{!"int", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!5, !5, i64 0}
!8 = !{!4, !4, i64 0}
!9 = !{i64 983}
