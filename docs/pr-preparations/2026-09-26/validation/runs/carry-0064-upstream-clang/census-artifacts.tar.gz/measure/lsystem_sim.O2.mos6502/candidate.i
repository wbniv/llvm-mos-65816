# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/lsystem_sim.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 366 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/lsystem_sim.c" 2
# 11 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/lsystem_sim.c"
# 1 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/lsystem.h" 1
# 25 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/lsystem.h"
# 1 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 1 3
# 100 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef long long int int64_t;

typedef long long unsigned int uint64_t;
# 122 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int64_t int_least64_t;
typedef uint64_t uint_least64_t;
typedef int64_t int_fast64_t;
typedef uint64_t uint_fast64_t;
# 197 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef long int int32_t;




typedef long unsigned int uint32_t;
# 220 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int32_t int_least32_t;
typedef uint32_t uint_least32_t;
typedef int32_t int_fast32_t;
typedef uint32_t uint_fast32_t;
# 245 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int int16_t;

typedef unsigned int uint16_t;
# 259 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int16_t int_least16_t;
typedef uint16_t uint_least16_t;
typedef int16_t int_fast16_t;
typedef uint16_t uint_fast16_t;





typedef signed char int8_t;

typedef unsigned char uint8_t;







typedef int8_t int_least8_t;
typedef uint8_t uint_least8_t;
typedef int8_t int_fast8_t;
typedef uint8_t uint_fast8_t;
# 295 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/candidate/lib/clang/24/include/stdint.h" 3
typedef int intptr_t;






typedef unsigned int uintptr_t;





typedef long long int intmax_t;
typedef long long unsigned int uintmax_t;
# 26 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/lsystem.h" 2
# 1 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/../snes/sincos.h" 1







static const int16_t SINCOS[256] = {
     0, 6, 13, 19, 25, 31, 38, 44, 50, 56, 62, 68, 74, 80, 86, 92,
    98, 104, 109, 115, 121, 126, 132, 137, 142, 147, 152, 157, 162, 167, 172, 177,
   181, 185, 190, 194, 198, 202, 206, 209, 213, 216, 220, 223, 226, 229, 231, 234,
   237, 239, 241, 243, 245, 247, 248, 250, 251, 252, 253, 254, 255, 255, 256, 256,
   256, 256, 256, 255, 255, 254, 253, 252, 251, 250, 248, 247, 245, 243, 241, 239,
   237, 234, 231, 229, 226, 223, 220, 216, 213, 209, 206, 202, 198, 194, 190, 185,
   181, 177, 172, 167, 162, 157, 152, 147, 142, 137, 132, 126, 121, 115, 109, 104,
    98, 92, 86, 80, 74, 68, 62, 56, 50, 44, 38, 31, 25, 19, 13, 6,
     0, -6, -13, -19, -25, -31, -38, -44, -50, -56, -62, -68, -74, -80, -86, -92,
   -98, -104, -109, -115, -121, -126, -132, -137, -142, -147, -152, -157, -162, -167, -172, -177,
  -181, -185, -190, -194, -198, -202, -206, -209, -213, -216, -220, -223, -226, -229, -231, -234,
  -237, -239, -241, -243, -245, -247, -248, -250, -251, -252, -253, -254, -255, -255, -256, -256,
  -256, -256, -256, -255, -255, -254, -253, -252, -251, -250, -248, -247, -245, -243, -241, -239,
  -237, -234, -231, -229, -226, -223, -220, -216, -213, -209, -206, -202, -198, -194, -190, -185,
  -181, -177, -172, -167, -162, -157, -152, -147, -142, -137, -132, -126, -121, -115, -109, -104,
   -98, -92, -86, -80, -74, -68, -62, -56, -50, -44, -38, -31, -25, -19, -13, -6,
};
# 27 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/lsystem.h" 2
# 52 "/home/will/llvm-mos-65816/examples/snes/corpus/../../65816/lsystem.h"
static char ls_buf[2400u];


static const char *ls_rule(char c) {
  switch (c) {
    case 'X': return "F-[[X]+X]+F[+FX]-X";
    case 'F': return "FF";
    default: return (const char *)0;
  }
}






static const char *lsystem_build(uint16_t *out_len) {
  ls_buf[0] = 'X';
  uint16_t len = 1;
  for (uint8_t g = 0; g < (uint8_t)6u; g++) {
    uint16_t i = 0;
    while (i < len) {
      const char *p = ls_rule(ls_buf[i]);
      if (!p) { i++; continue; }
      uint16_t pl = (uint16_t)__builtin_strlen(p);
      if ((uint16_t)(len + (pl - 1u)) > (uint16_t)(2400u - 1u)) goto done;
      __builtin_memmove(&ls_buf[i + pl], &ls_buf[i + 1],
                        (uint16_t)(len - (i + 1u)));
      __builtin_memcpy(&ls_buf[i], p, pl);
      len = (uint16_t)(len + (pl - 1u));
      i = (uint16_t)(i + pl);
    }
  }
done:
  if (out_len) *out_len = len;
  return ls_buf;
}


typedef struct { int32_t x, y; uint8_t h, depth; } LTurtle;


typedef void (*LEmit)(void *ctx, uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1, uint8_t col);

static inline uint8_t ls_px(int32_t q88) {
  int32_t p = q88 >> 8;
  if (p < 0) p = 0; else if (p > 128 - 1) p = 128 - 1;
  return (uint8_t)p;
}



static uint16_t lsystem_interp(const char *s, uint16_t len, LEmit emit, void *ctx) {
  LTurtle t; t.x = (int32_t)70 << 8; t.y = (int32_t)124 << 8;
  t.h = 192; t.depth = 0;
  LTurtle stk[24]; uint8_t sp = 0;
  uint16_t crc = 0xFFFF;
  for (uint16_t i = 0; i < len; i++) {
    char c = s[i];
    if (c == 'F') {
      int32_t nx = t.x + ((int32_t)38 * SINCOS[(uint8_t)(t.h + 64)] >> 4);
      int32_t ny = t.y + ((int32_t)38 * SINCOS[t.h] >> 4);
      uint8_t x0 = ls_px(t.x), y0 = ls_px(t.y), x1 = ls_px(nx), y1 = ls_px(ny);
      uint8_t col = (uint8_t)(t.depth == 0 ? 1u : (t.depth < 3u ? 2u : 3u));
      crc = (uint16_t)((uint16_t)(((unsigned)crc << 1) | ((unsigned)crc >> 15)) ^ (uint16_t)((x0 << 8) | y0));
      crc = (uint16_t)((uint16_t)(((unsigned)crc << 1) | ((unsigned)crc >> 15)) ^ (uint16_t)((x1 << 8) | y1));
      crc = (uint16_t)((uint16_t)(((unsigned)crc << 1) | ((unsigned)crc >> 15)) ^ (uint16_t)col);
      if (emit) emit(ctx, x0, y0, x1, y1, col);
      t.x = nx; t.y = ny;
    } else if (c == '+') {
      t.h = (uint8_t)(t.h - (uint8_t)18);
    } else if (c == '-') {
      t.h = (uint8_t)(t.h + (uint8_t)18);
    } else if (c == '[') {
      if (sp < 24) stk[sp++] = t;
      if (t.depth < 255u) t.depth++;
    } else if (c == ']') {
      if (sp > 0) t = stk[--sp];
    }

  }
  return crc;
}



static inline uint16_t lsystem_gate_crc(void) {
  uint16_t len;
  const char *s = lsystem_build(&len);
  return lsystem_interp(s, len, (LEmit)0, (void *)0);
}
# 12 "/home/will/llvm-mos-65816/.scratch/carry-clang-upstream/inputs/lsystem_sim.c" 2

volatile uint16_t corpus_result;

int main(void) {
    corpus_result = lsystem_gate_crc();
    for (;;) __asm__ volatile("");
    return 0;
}
