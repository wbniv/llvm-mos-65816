; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/rotkal_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/rotkal_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.RKState = type { [8 x i8], i16 }

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca %struct.RKState, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #4
  store i8 -93, ptr %1, align 1, !tbaa !6
  %2 = getelementptr inbounds nuw i8, ptr %1, i16 1
  store i8 92, ptr %2, align 1, !tbaa !6
  %3 = getelementptr inbounds nuw i8, ptr %1, i16 2
  store i8 -31, ptr %3, align 1, !tbaa !6
  %4 = getelementptr inbounds nuw i8, ptr %1, i16 3
  store i8 120, ptr %4, align 1, !tbaa !6
  %5 = getelementptr inbounds nuw i8, ptr %1, i16 4
  store i8 47, ptr %5, align 1, !tbaa !6
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 5
  store i8 -108, ptr %6, align 1, !tbaa !6
  %7 = getelementptr inbounds nuw i8, ptr %1, i16 6
  store i8 -73, ptr %7, align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 7
  store i8 29, ptr %8, align 1, !tbaa !6
  %9 = getelementptr inbounds nuw i8, ptr %1, i16 8
  store i16 -21555, ptr %9, align 1, !tbaa !7
  br label %10

10:                                               ; preds = %29, %0
  %11 = phi i16 [ 0, %0 ], [ %33, %29 ]
  %12 = phi i16 [ 0, %0 ], [ %32, %29 ]
  %13 = icmp eq i16 %11, 100
  br i1 %13, label %34, label %14

14:                                               ; preds = %10
  %15 = and i16 %11, 14
  %16 = or disjoint i16 %15, 1
  call fastcc void @rk_step(ptr noundef %1, i16 noundef %16) #5
  br label %17

17:                                               ; preds = %21, %14
  %18 = phi i8 [ %28, %21 ], [ 0, %14 ]
  %19 = phi i16 [ %27, %21 ], [ %12, %14 ]
  %20 = icmp eq i8 %18, 8
  br i1 %20, label %29, label %21

21:                                               ; preds = %17
  %22 = zext nneg i8 %18 to i16
  %23 = getelementptr i8, ptr %1, i16 %22
  %24 = load i8, ptr %23, align 1, !tbaa !6
  %25 = zext i8 %24 to i16
  %26 = tail call i16 @llvm.fshl.i16(i16 %19, i16 %19, i16 1)
  %27 = xor i16 %26, %25
  %28 = add nuw nsw i8 %18, 1
  br label %17, !llvm.loop !9

29:                                               ; preds = %17
  %30 = load i16, ptr %9, align 1, !tbaa !7
  %31 = tail call i16 @llvm.fshl.i16(i16 %19, i16 %19, i16 1)
  %32 = xor i16 %30, %31
  %33 = add nuw nsw i16 %11, 1
  br label %10, !llvm.loop !11

34:                                               ; preds = %10
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #4
  store volatile i16 %12, ptr @corpus_result, align 1, !tbaa !2
  br label %35

35:                                               ; preds = %35, %34
  tail call void asm sideeffect "", ""() #4, !srcloc !12
  br label %35
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: minsize mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal fastcc void @rk_step(ptr noundef nonnull captures(none) %0, i16 noundef range(i16 1, 16) %1) unnamed_addr #2 {
  %3 = load i8, ptr %0, align 1, !tbaa !6
  %4 = tail call i8 @llvm.fshl.i8(i8 %3, i8 %3, i8 1)
  store i8 %4, ptr %0, align 1, !tbaa !6
  %5 = getelementptr inbounds nuw i8, ptr %0, i16 1
  %6 = load i8, ptr %5, align 1, !tbaa !6
  %7 = tail call i8 @llvm.fshl.i8(i8 %6, i8 %6, i8 2)
  store i8 %7, ptr %5, align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %9 = load i8, ptr %8, align 1, !tbaa !6
  %10 = tail call i8 @llvm.fshl.i8(i8 %9, i8 %9, i8 3)
  store i8 %10, ptr %8, align 1, !tbaa !6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %12 = load i8, ptr %11, align 1, !tbaa !6
  %13 = tail call i8 @llvm.fshl.i8(i8 %12, i8 %12, i8 1)
  store i8 %13, ptr %11, align 1, !tbaa !6
  %14 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %15 = load i8, ptr %14, align 1, !tbaa !6
  %16 = tail call i8 @llvm.fshl.i8(i8 %15, i8 %15, i8 7)
  store i8 %16, ptr %14, align 1, !tbaa !6
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 5
  %18 = load i8, ptr %17, align 1, !tbaa !6
  %19 = tail call i8 @llvm.fshl.i8(i8 %18, i8 %18, i8 6)
  store i8 %19, ptr %17, align 1, !tbaa !6
  %20 = getelementptr inbounds nuw i8, ptr %0, i16 6
  %21 = load i8, ptr %20, align 1, !tbaa !6
  %22 = tail call i8 @llvm.fshl.i8(i8 %21, i8 %21, i8 5)
  store i8 %22, ptr %20, align 1, !tbaa !6
  %23 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %24 = load i8, ptr %23, align 1, !tbaa !6
  %25 = tail call i8 @llvm.fshl.i8(i8 %24, i8 %24, i8 7)
  store i8 %25, ptr %23, align 1, !tbaa !6
  %26 = getelementptr inbounds nuw i8, ptr %0, i16 8
  %27 = load i16, ptr %26, align 1, !tbaa !7
  %28 = tail call i16 @llvm.fshl.i16(i16 %27, i16 %27, i16 %1)
  store i16 %28, ptr %26, align 1, !tbaa !7
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fshl.i8(i8, i8, i8) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #3

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { minsize mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #3 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind }
attributes #5 = { minsize optsize }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = !{!8, !3, i64 8}
!8 = !{!"", !4, i64 0, !3, i64 8}
!9 = distinct !{!9, !10}
!10 = !{!"llvm.loop.mustprogress"}
!11 = distinct !{!11, !10}
!12 = !{i64 560}
