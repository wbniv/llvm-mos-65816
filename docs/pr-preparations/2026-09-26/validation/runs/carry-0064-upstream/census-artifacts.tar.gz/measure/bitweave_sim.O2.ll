; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/bitweave_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/bitweave_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca i8, align 1
  %2 = alloca i16, align 1
  br label %3

3:                                                ; preds = %3, %0
  %4 = phi i16 [ 0, %0 ], [ %27, %3 ]
  %5 = phi i16 [ -21279, %0 ], [ %8, %3 ]
  %6 = phi i16 [ 0, %0 ], [ %28, %3 ]
  %7 = mul i16 %5, 25173
  %8 = add i16 %7, 13849
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #4
  %9 = lshr i16 %8, 5
  %10 = trunc i16 %9 to i8
  store i8 %10, ptr %1, align 1, !tbaa !6
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #4
  store i16 %8, ptr %2, align 1, !tbaa !2
  call fastcc void @bw_weave(ptr noundef %1, ptr noundef %2)
  %11 = load i8, ptr %1, align 1, !tbaa !6
  %12 = zext i8 %11 to i16
  %13 = tail call i16 @llvm.fshl.i16(i16 %4, i16 %4, i16 1)
  %14 = xor i16 %13, %12
  %15 = load i16, ptr %2, align 1, !tbaa !2
  %16 = tail call i16 @llvm.fshl.i16(i16 %14, i16 %14, i16 1)
  %17 = xor i16 %16, %15
  call fastcc void @bw_weave(ptr noundef %1, ptr noundef %2)
  %18 = load i8, ptr %1, align 1, !tbaa !6
  %19 = zext i8 %18 to i16
  %20 = and i16 %9, 255
  %21 = xor i16 %20, %19
  %22 = tail call i16 @llvm.fshl.i16(i16 %17, i16 %17, i16 1)
  %23 = xor i16 %21, %22
  %24 = load i16, ptr %2, align 1, !tbaa !2
  %25 = tail call i16 @llvm.fshl.i16(i16 %23, i16 %23, i16 1)
  %26 = xor i16 %24, %25
  %27 = xor i16 %26, %8
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #4
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #4
  %28 = add nuw nsw i16 %6, 1
  %29 = icmp eq i16 %28, 128
  br i1 %29, label %30, label %3, !llvm.loop !7

30:                                               ; preds = %3
  store volatile i16 %27, ptr @corpus_result, align 1, !tbaa !2
  br label %31

31:                                               ; preds = %31, %30
  tail call void asm sideeffect "", ""() #4, !srcloc !9
  br label %31
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc void @bw_weave(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1) unnamed_addr #2 {
  %3 = load i8, ptr %0, align 1, !tbaa !6
  %4 = load i16, ptr %1, align 1, !tbaa !2
  br label %6

5:                                                ; preds = %18
  store i8 %20, ptr %0, align 1, !tbaa !6
  store i16 %23, ptr %1, align 1, !tbaa !2
  ret void

6:                                                ; preds = %2, %18
  %7 = phi i8 [ 0, %2 ], [ %25, %18 ]
  %8 = phi i16 [ 0, %2 ], [ %23, %18 ]
  %9 = phi i16 [ %4, %2 ], [ %24, %18 ]
  %10 = phi i8 [ 0, %2 ], [ %20, %18 ]
  %11 = phi i8 [ %3, %2 ], [ %19, %18 ]
  %12 = icmp samesign ult i8 %7, 8
  br i1 %12, label %13, label %18

13:                                               ; preds = %6
  %14 = shl i8 %10, 1
  %15 = and i8 %11, 1
  %16 = or disjoint i8 %14, %15
  %17 = lshr i8 %11, 1
  br label %18

18:                                               ; preds = %13, %6
  %19 = phi i8 [ %17, %13 ], [ %11, %6 ]
  %20 = phi i8 [ %16, %13 ], [ %10, %6 ]
  %21 = shl i16 %8, 1
  %22 = and i16 %9, 1
  %23 = or disjoint i16 %21, %22
  %24 = lshr i16 %9, 1
  %25 = add nuw nsw i8 %7, 1
  %26 = icmp eq i8 %25, 16
  br i1 %26, label %5, label %6, !llvm.loop !10
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #3

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree noinline norecurse nosync nounwind memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{i64 642}
!10 = distinct !{!10, !8}
