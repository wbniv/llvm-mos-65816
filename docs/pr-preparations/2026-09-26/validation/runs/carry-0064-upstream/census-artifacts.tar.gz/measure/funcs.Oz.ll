; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/funcs.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/funcs.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@fn = dso_local global i8 12, align 1
@a = dso_local global i16 30, align 1
@b = dso_local global i16 12, align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = load volatile i8, ptr @fn, align 1, !tbaa !6
  %2 = tail call fastcc i16 @fib(i8 noundef zeroext %1) #2
  %3 = load volatile i16, ptr @a, align 1, !tbaa !2
  %4 = load volatile i16, ptr @b, align 1, !tbaa !2
  %5 = add i16 %2, 100
  %6 = add i16 %5, %3
  %7 = add i16 %6, %4
  store volatile i16 %7, ptr @corpus_result, align 1, !tbaa !2
  br label %8

8:                                                ; preds = %8, %0
  tail call void asm sideeffect "", ""() #3, !srcloc !7
  br label %8
}

; Function Attrs: minsize nofree nosync nounwind optsize memory(none)
define internal fastcc i16 @fib(i8 noundef zeroext %0) unnamed_addr #1 {
  br label %2

2:                                                ; preds = %9, %1
  %3 = phi i16 [ 0, %1 ], [ %13, %9 ]
  %4 = phi i8 [ %0, %1 ], [ %12, %9 ]
  %5 = icmp ult i8 %4, 2
  br i1 %5, label %6, label %9

6:                                                ; preds = %2
  %7 = zext nneg i8 %4 to i16
  %8 = add i16 %3, %7
  ret i16 %8

9:                                                ; preds = %2
  %10 = add i8 %4, -1
  %11 = tail call fastcc i16 @fib(i8 noundef zeroext %10) #2
  %12 = add i8 %4, -2
  %13 = add i16 %11, %3
  br label %2
}

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { minsize nofree nosync nounwind optsize memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #2 = { minsize optsize }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = !{i64 902}
