; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/structs.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/structs.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.point = type { i8, i16, i8 }

@bump = dso_local global i8 2, align 1
@pts = internal global [3 x %struct.point] [%struct.point { i8 1, i16 100, i8 7 }, %struct.point { i8 2, i16 200, i8 8 }, %struct.point { i8 3, i16 300, i8 9 }], align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %0, %1
  %2 = phi i8 [ 0, %0 ], [ %20, %1 ]
  %3 = phi ptr [ @pts, %0 ], [ %17, %1 ]
  %4 = phi i8 [ 0, %0 ], [ %18, %1 ]
  %5 = phi i16 [ 0, %0 ], [ %16, %1 ]
  %6 = load volatile i8, ptr %3, align 1, !tbaa !6
  %7 = zext i8 %6 to i16
  %8 = add i16 %5, %7
  %9 = zext nneg i8 %2 to i16
  %10 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 1), i16 %9
  %11 = load volatile i16, ptr %10, align 1, !tbaa !8
  %12 = add i16 %8, %11
  %13 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 3), i16 %9
  %14 = load volatile i8, ptr %13, align 1, !tbaa !9
  %15 = zext i8 %14 to i16
  %16 = add i16 %12, %15
  %17 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 4), i16 %9
  %18 = add nuw nsw i8 %4, 1
  %19 = icmp eq i8 %18, 3
  %20 = add nuw nsw i8 %2, 4
  br i1 %19, label %21, label %1, !llvm.loop !10

21:                                               ; preds = %1
  %22 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !8
  %23 = load volatile i8, ptr @bump, align 1, !tbaa !12
  %24 = zext i8 %23 to i16
  %25 = add i16 %22, %24
  store volatile i16 %25, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !8
  %26 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !8
  %27 = add i16 %26, %16
  store volatile i16 %27, ptr @corpus_result, align 1, !tbaa !2
  br label %28

28:                                               ; preds = %28, %21
  tail call void asm sideeffect "", ""() #1, !srcloc !13
  br label %28
}

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !4, i64 0}
!7 = !{!"point", !4, i64 0, !3, i64 1, !4, i64 3}
!8 = !{!7, !3, i64 1}
!9 = !{!7, !4, i64 3}
!10 = distinct !{!10, !11}
!11 = !{!"llvm.loop.mustprogress"}
!12 = !{!4, !4, i64 0}
!13 = !{i64 1177}
