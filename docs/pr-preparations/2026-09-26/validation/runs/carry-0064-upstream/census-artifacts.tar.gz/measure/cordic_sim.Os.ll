; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/cordic_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/cordic_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = tail call fastcc i16 @cordic_gate_crc() #5
  store volatile i16 %1, ptr @corpus_result, align 1, !tbaa !2
  br label %2

2:                                                ; preds = %2, %0
  tail call void asm sideeffect "", ""() #6, !srcloc !6
  br label %2
}

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(none)
define internal fastcc i16 @cordic_gate_crc() unnamed_addr #1 {
  %1 = alloca i16, align 1
  %2 = alloca i16, align 1
  %3 = alloca i16, align 1
  %4 = alloca i16, align 1
  br label %6

5:                                                ; preds = %221
  ret i16 %241

6:                                                ; preds = %0, %221
  %7 = phi i16 [ 0, %0 ], [ %242, %221 ]
  %8 = phi i16 [ 0, %0 ], [ %241, %221 ]
  %9 = phi i8 [ 0, %0 ], [ %39, %221 ]
  %10 = phi i16 [ 0, %0 ], [ %38, %221 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #6
  call fastcc void @cordic16_sincos(i16 noundef %10, ptr noundef %3, ptr noundef %4) #5
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #6
  call fastcc void @cordic16_sincos(i16 noundef %10, ptr noundef %1, ptr noundef %2) #5
  %11 = and i8 %9, 3
  switch i8 %11, label %24 [
    i8 0, label %12
    i8 1, label %15
    i8 2, label %19
    i8 3, label %25
  ]

12:                                               ; preds = %6
  %13 = load i16, ptr %2, align 1, !tbaa !2
  %14 = load i16, ptr %1, align 1, !tbaa !2
  br label %29

15:                                               ; preds = %6
  %16 = load i16, ptr %1, align 1, !tbaa !2
  %17 = sub nsw i16 0, %16
  %18 = load i16, ptr %2, align 1, !tbaa !2
  br label %29

19:                                               ; preds = %6
  %20 = load i16, ptr %2, align 1, !tbaa !2
  %21 = sub nsw i16 0, %20
  %22 = load i16, ptr %1, align 1, !tbaa !2
  %23 = sub nsw i16 0, %22
  br label %29

24:                                               ; preds = %6
  unreachable

25:                                               ; preds = %6
  %26 = load i16, ptr %1, align 1, !tbaa !2
  %27 = load i16, ptr %2, align 1, !tbaa !2
  %28 = sub nsw i16 0, %27
  br label %29

29:                                               ; preds = %25, %19, %15, %12
  %30 = phi i16 [ %13, %12 ], [ %17, %15 ], [ %21, %19 ], [ %26, %25 ]
  %31 = phi i16 [ %14, %12 ], [ %18, %15 ], [ %23, %19 ], [ %28, %25 ]
  %32 = add nsw i16 %10, 1072
  %33 = icmp sgt i16 %10, 24663
  br i1 %33, label %34, label %37

34:                                               ; preds = %29
  %35 = add nsw i16 %10, -24664
  %36 = add i8 %9, 1
  br label %37

37:                                               ; preds = %29, %34
  %38 = phi i16 [ %35, %34 ], [ %32, %29 ]
  %39 = phi i8 [ %36, %34 ], [ %9, %29 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #6
  %40 = tail call i16 @llvm.fshl.i16(i16 %8, i16 %8, i16 1)
  %41 = xor i16 %31, %40
  %42 = tail call i16 @llvm.fshl.i16(i16 %41, i16 %41, i16 1)
  %43 = xor i16 %42, %30
  %44 = load i16, ptr %3, align 1, !tbaa !2
  %45 = load i16, ptr %4, align 1, !tbaa !2
  %46 = ashr i16 %45, 1
  %47 = ashr i16 %44, 1
  %48 = icmp slt i16 %47, 0
  br i1 %48, label %49, label %52

49:                                               ; preds = %37
  %50 = sub nsw i16 %46, %47
  %51 = add nsw i16 %46, %47
  br label %55

52:                                               ; preds = %37
  %53 = add nsw i16 %46, %47
  %54 = sub nsw i16 %47, %46
  br label %55

55:                                               ; preds = %52, %49
  %56 = phi i16 [ -12868, %49 ], [ 12868, %52 ]
  %57 = phi i16 [ %51, %49 ], [ %54, %52 ]
  %58 = phi i16 [ %50, %49 ], [ %53, %52 ]
  %59 = ashr i16 %58, 1
  %60 = ashr i16 %57, 1
  %61 = icmp slt i16 %57, 0
  br i1 %61, label %62, label %65

62:                                               ; preds = %55
  %63 = sub nsw i16 %58, %60
  %64 = add nsw i16 %59, %57
  br label %68

65:                                               ; preds = %55
  %66 = add nsw i16 %58, %60
  %67 = sub nsw i16 %57, %59
  br label %68

68:                                               ; preds = %65, %62
  %69 = phi i16 [ 7596, %65 ], [ -7596, %62 ]
  %70 = phi i16 [ %67, %65 ], [ %64, %62 ]
  %71 = phi i16 [ %66, %65 ], [ %63, %62 ]
  %72 = ashr i16 %71, 2
  %73 = ashr i16 %70, 2
  %74 = icmp slt i16 %70, 0
  br i1 %74, label %75, label %78

75:                                               ; preds = %68
  %76 = sub nsw i16 %71, %73
  %77 = add nsw i16 %72, %70
  br label %81

78:                                               ; preds = %68
  %79 = add nsw i16 %71, %73
  %80 = sub nsw i16 %70, %72
  br label %81

81:                                               ; preds = %78, %75
  %82 = phi i16 [ 4014, %78 ], [ -4014, %75 ]
  %83 = phi i16 [ %80, %78 ], [ %77, %75 ]
  %84 = phi i16 [ %79, %78 ], [ %76, %75 ]
  %85 = ashr i16 %84, 3
  %86 = ashr i16 %83, 3
  %87 = icmp slt i16 %83, 0
  br i1 %87, label %88, label %91

88:                                               ; preds = %81
  %89 = sub nsw i16 %84, %86
  %90 = add nsw i16 %85, %83
  br label %94

91:                                               ; preds = %81
  %92 = add nsw i16 %84, %86
  %93 = sub nsw i16 %83, %85
  br label %94

94:                                               ; preds = %91, %88
  %95 = phi i16 [ 2037, %91 ], [ -2037, %88 ]
  %96 = phi i16 [ %93, %91 ], [ %90, %88 ]
  %97 = phi i16 [ %92, %91 ], [ %89, %88 ]
  %98 = ashr i16 %97, 4
  %99 = ashr i16 %96, 4
  %100 = icmp slt i16 %96, 0
  br i1 %100, label %101, label %104

101:                                              ; preds = %94
  %102 = sub nsw i16 %97, %99
  %103 = add nsw i16 %98, %96
  br label %107

104:                                              ; preds = %94
  %105 = add nsw i16 %97, %99
  %106 = sub nsw i16 %96, %98
  br label %107

107:                                              ; preds = %104, %101
  %108 = phi i16 [ 1023, %104 ], [ -1023, %101 ]
  %109 = phi i16 [ %106, %104 ], [ %103, %101 ]
  %110 = phi i16 [ %105, %104 ], [ %102, %101 ]
  %111 = ashr i16 %110, 5
  %112 = ashr i16 %109, 5
  %113 = icmp slt i16 %109, 0
  br i1 %113, label %114, label %117

114:                                              ; preds = %107
  %115 = sub nsw i16 %110, %112
  %116 = add nsw i16 %111, %109
  br label %120

117:                                              ; preds = %107
  %118 = add nsw i16 %110, %112
  %119 = sub nsw i16 %109, %111
  br label %120

120:                                              ; preds = %117, %114
  %121 = phi i16 [ 512, %117 ], [ -512, %114 ]
  %122 = phi i16 [ %119, %117 ], [ %116, %114 ]
  %123 = phi i16 [ %118, %117 ], [ %115, %114 ]
  %124 = ashr i16 %123, 6
  %125 = ashr i16 %122, 6
  %126 = icmp slt i16 %122, 0
  br i1 %126, label %127, label %130

127:                                              ; preds = %120
  %128 = sub nsw i16 %123, %125
  %129 = add nsw i16 %124, %122
  br label %133

130:                                              ; preds = %120
  %131 = add nsw i16 %123, %125
  %132 = sub nsw i16 %122, %124
  br label %133

133:                                              ; preds = %130, %127
  %134 = phi i16 [ 256, %130 ], [ -256, %127 ]
  %135 = phi i16 [ %132, %130 ], [ %129, %127 ]
  %136 = phi i16 [ %131, %130 ], [ %128, %127 ]
  %137 = ashr i16 %136, 7
  %138 = ashr i16 %135, 7
  %139 = icmp slt i16 %135, 0
  br i1 %139, label %140, label %143

140:                                              ; preds = %133
  %141 = sub nsw i16 %136, %138
  %142 = add nsw i16 %137, %135
  br label %146

143:                                              ; preds = %133
  %144 = add nsw i16 %136, %138
  %145 = sub nsw i16 %135, %137
  br label %146

146:                                              ; preds = %143, %140
  %147 = phi i16 [ 128, %143 ], [ -128, %140 ]
  %148 = phi i16 [ %145, %143 ], [ %142, %140 ]
  %149 = phi i16 [ %144, %143 ], [ %141, %140 ]
  %150 = ashr i16 %149, 8
  %151 = ashr i16 %148, 8
  %152 = icmp slt i16 %148, 0
  br i1 %152, label %153, label %156

153:                                              ; preds = %146
  %154 = sub nsw i16 %149, %151
  %155 = add nsw i16 %150, %148
  br label %159

156:                                              ; preds = %146
  %157 = add nsw i16 %149, %151
  %158 = sub nsw i16 %148, %150
  br label %159

159:                                              ; preds = %156, %153
  %160 = phi i16 [ 64, %156 ], [ -64, %153 ]
  %161 = phi i16 [ %158, %156 ], [ %155, %153 ]
  %162 = phi i16 [ %157, %156 ], [ %154, %153 ]
  %163 = ashr i16 %162, 9
  %164 = ashr i16 %161, 9
  %165 = icmp slt i16 %161, 0
  br i1 %165, label %166, label %169

166:                                              ; preds = %159
  %167 = sub nsw i16 %162, %164
  %168 = add nsw i16 %163, %161
  br label %172

169:                                              ; preds = %159
  %170 = add nsw i16 %162, %164
  %171 = sub nsw i16 %161, %163
  br label %172

172:                                              ; preds = %169, %166
  %173 = phi i16 [ 32, %169 ], [ -32, %166 ]
  %174 = phi i16 [ %171, %169 ], [ %168, %166 ]
  %175 = phi i16 [ %170, %169 ], [ %167, %166 ]
  %176 = ashr i16 %175, 10
  %177 = ashr i16 %174, 10
  %178 = icmp slt i16 %174, 0
  br i1 %178, label %179, label %182

179:                                              ; preds = %172
  %180 = sub nsw i16 %175, %177
  %181 = add nsw i16 %176, %174
  br label %185

182:                                              ; preds = %172
  %183 = add nsw i16 %175, %177
  %184 = sub nsw i16 %174, %176
  br label %185

185:                                              ; preds = %182, %179
  %186 = phi i16 [ 16, %182 ], [ -16, %179 ]
  %187 = phi i16 [ %184, %182 ], [ %181, %179 ]
  %188 = phi i16 [ %183, %182 ], [ %180, %179 ]
  %189 = ashr i16 %188, 11
  %190 = ashr i16 %187, 11
  %191 = icmp slt i16 %187, 0
  br i1 %191, label %192, label %195

192:                                              ; preds = %185
  %193 = sub nsw i16 %188, %190
  %194 = add nsw i16 %189, %187
  br label %198

195:                                              ; preds = %185
  %196 = add nsw i16 %188, %190
  %197 = sub nsw i16 %187, %189
  br label %198

198:                                              ; preds = %195, %192
  %199 = phi i16 [ 8, %195 ], [ -8, %192 ]
  %200 = phi i16 [ %197, %195 ], [ %194, %192 ]
  %201 = phi i16 [ %196, %195 ], [ %193, %192 ]
  %202 = ashr i16 %201, 12
  %203 = ashr i16 %200, 12
  %204 = icmp slt i16 %200, 0
  br i1 %204, label %205, label %208

205:                                              ; preds = %198
  %206 = sub nsw i16 %201, %203
  %207 = add nsw i16 %202, %200
  br label %211

208:                                              ; preds = %198
  %209 = add nsw i16 %201, %203
  %210 = sub nsw i16 %200, %202
  br label %211

211:                                              ; preds = %208, %205
  %212 = phi i16 [ 4, %208 ], [ -4, %205 ]
  %213 = phi i16 [ %210, %208 ], [ %207, %205 ]
  %214 = phi i16 [ %209, %208 ], [ %206, %205 ]
  %215 = ashr i16 %214, 13
  %216 = icmp slt i16 %213, 0
  br i1 %216, label %217, label %219

217:                                              ; preds = %211
  %218 = add nsw i16 %215, %213
  br label %221

219:                                              ; preds = %211
  %220 = sub nsw i16 %213, %215
  br label %221

221:                                              ; preds = %217, %219
  %222 = phi i16 [ 2, %219 ], [ -2, %217 ]
  %223 = phi i16 [ %220, %219 ], [ %218, %217 ]
  %224 = add nsw i16 %69, %56
  %225 = add nsw i16 %224, %82
  %226 = add nsw i16 %225, %95
  %227 = add nsw i16 %226, %108
  %228 = add nsw i16 %227, %121
  %229 = add nsw i16 %228, %134
  %230 = add nsw i16 %229, %147
  %231 = add nsw i16 %230, %160
  %232 = add nsw i16 %231, %173
  %233 = add nsw i16 %232, %186
  %234 = add nsw i16 %233, %199
  %235 = add nsw i16 %234, %212
  %236 = add nsw i16 %235, %222
  %237 = icmp sgt i16 %223, -1
  %238 = select i1 %237, i16 1, i16 -1
  %239 = add nsw i16 %236, %238
  %240 = tail call i16 @llvm.fshl.i16(i16 %43, i16 %43, i16 1)
  %241 = xor i16 %239, %240
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #6
  %242 = add nuw nsw i16 %7, 1
  %243 = icmp eq i16 %242, 96
  br i1 %243, label %5, label %6, !llvm.loop !7
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #2

; Function Attrs: inlinehint mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal fastcc void @cordic16_sincos(i16 noundef %0, ptr noundef nonnull writeonly captures(none) initializes((0, 2)) %1, ptr noundef nonnull writeonly captures(none) initializes((0, 2)) %2) unnamed_addr #3 {
  %4 = icmp sgt i16 %0, -1
  %5 = select i1 %4, i16 -12868, i16 12868
  %6 = select i1 %4, i16 9949, i16 -9949
  %7 = add nsw i16 %0, %5
  %8 = ashr i16 %6, 1
  %9 = icmp sgt i16 %7, -1
  br i1 %9, label %10, label %12

10:                                               ; preds = %3
  %11 = sub nsw i16 9949, %8
  br label %14

12:                                               ; preds = %3
  %13 = add nsw i16 %8, 9949
  br label %14

14:                                               ; preds = %12, %10
  %15 = phi i16 [ -4974, %12 ], [ 4974, %10 ]
  %16 = phi i16 [ 7596, %12 ], [ -7596, %10 ]
  %17 = phi i16 [ %13, %12 ], [ %11, %10 ]
  %18 = add nsw i16 %6, %15
  %19 = add nsw i16 %7, %16
  %20 = lshr i16 %17, 2
  %21 = ashr i16 %18, 2
  %22 = icmp sgt i16 %19, -1
  br i1 %22, label %23, label %26

23:                                               ; preds = %14
  %24 = sub nsw i16 %17, %21
  %25 = add nsw i16 %20, %18
  br label %29

26:                                               ; preds = %14
  %27 = add nsw i16 %17, %21
  %28 = sub nsw i16 %18, %20
  br label %29

29:                                               ; preds = %26, %23
  %30 = phi i16 [ 4014, %26 ], [ -4014, %23 ]
  %31 = phi i16 [ %28, %26 ], [ %25, %23 ]
  %32 = phi i16 [ %27, %26 ], [ %24, %23 ]
  %33 = add nsw i16 %19, %30
  %34 = lshr i16 %32, 3
  %35 = ashr i16 %31, 3
  %36 = icmp sgt i16 %33, -1
  br i1 %36, label %37, label %40

37:                                               ; preds = %29
  %38 = sub nsw i16 %32, %35
  %39 = add nsw i16 %34, %31
  br label %43

40:                                               ; preds = %29
  %41 = add nsw i16 %32, %35
  %42 = sub nsw i16 %31, %34
  br label %43

43:                                               ; preds = %40, %37
  %44 = phi i16 [ 2037, %40 ], [ -2037, %37 ]
  %45 = phi i16 [ %42, %40 ], [ %39, %37 ]
  %46 = phi i16 [ %41, %40 ], [ %38, %37 ]
  %47 = add nsw i16 %33, %44
  %48 = ashr i16 %46, 4
  %49 = ashr i16 %45, 4
  %50 = icmp sgt i16 %47, -1
  br i1 %50, label %51, label %54

51:                                               ; preds = %43
  %52 = sub nsw i16 %46, %49
  %53 = add nsw i16 %48, %45
  br label %57

54:                                               ; preds = %43
  %55 = add nsw i16 %46, %49
  %56 = sub nsw i16 %45, %48
  br label %57

57:                                               ; preds = %54, %51
  %58 = phi i16 [ 1023, %54 ], [ -1023, %51 ]
  %59 = phi i16 [ %56, %54 ], [ %53, %51 ]
  %60 = phi i16 [ %55, %54 ], [ %52, %51 ]
  %61 = add nsw i16 %47, %58
  %62 = ashr i16 %60, 5
  %63 = ashr i16 %59, 5
  %64 = icmp sgt i16 %61, -1
  br i1 %64, label %65, label %68

65:                                               ; preds = %57
  %66 = sub nsw i16 %60, %63
  %67 = add nsw i16 %62, %59
  br label %71

68:                                               ; preds = %57
  %69 = add nsw i16 %60, %63
  %70 = sub nsw i16 %59, %62
  br label %71

71:                                               ; preds = %68, %65
  %72 = phi i16 [ 512, %68 ], [ -512, %65 ]
  %73 = phi i16 [ %70, %68 ], [ %67, %65 ]
  %74 = phi i16 [ %69, %68 ], [ %66, %65 ]
  %75 = add nsw i16 %61, %72
  %76 = ashr i16 %74, 6
  %77 = ashr i16 %73, 6
  %78 = icmp sgt i16 %75, -1
  br i1 %78, label %79, label %82

79:                                               ; preds = %71
  %80 = sub nsw i16 %74, %77
  %81 = add nsw i16 %76, %73
  br label %85

82:                                               ; preds = %71
  %83 = add nsw i16 %74, %77
  %84 = sub nsw i16 %73, %76
  br label %85

85:                                               ; preds = %82, %79
  %86 = phi i16 [ 256, %82 ], [ -256, %79 ]
  %87 = phi i16 [ %84, %82 ], [ %81, %79 ]
  %88 = phi i16 [ %83, %82 ], [ %80, %79 ]
  %89 = add nsw i16 %75, %86
  %90 = ashr i16 %88, 7
  %91 = ashr i16 %87, 7
  %92 = icmp sgt i16 %89, -1
  br i1 %92, label %93, label %96

93:                                               ; preds = %85
  %94 = sub nsw i16 %88, %91
  %95 = add nsw i16 %90, %87
  br label %99

96:                                               ; preds = %85
  %97 = add nsw i16 %88, %91
  %98 = sub nsw i16 %87, %90
  br label %99

99:                                               ; preds = %96, %93
  %100 = phi i16 [ 128, %96 ], [ -128, %93 ]
  %101 = phi i16 [ %98, %96 ], [ %95, %93 ]
  %102 = phi i16 [ %97, %96 ], [ %94, %93 ]
  %103 = add nsw i16 %89, %100
  %104 = ashr i16 %102, 8
  %105 = ashr i16 %101, 8
  %106 = icmp sgt i16 %103, -1
  br i1 %106, label %107, label %110

107:                                              ; preds = %99
  %108 = sub nsw i16 %102, %105
  %109 = add nsw i16 %104, %101
  br label %113

110:                                              ; preds = %99
  %111 = add nsw i16 %102, %105
  %112 = sub nsw i16 %101, %104
  br label %113

113:                                              ; preds = %110, %107
  %114 = phi i16 [ 64, %110 ], [ -64, %107 ]
  %115 = phi i16 [ %112, %110 ], [ %109, %107 ]
  %116 = phi i16 [ %111, %110 ], [ %108, %107 ]
  %117 = add nsw i16 %103, %114
  %118 = ashr i16 %116, 9
  %119 = ashr i16 %115, 9
  %120 = icmp sgt i16 %117, -1
  br i1 %120, label %121, label %124

121:                                              ; preds = %113
  %122 = sub nsw i16 %116, %119
  %123 = add nsw i16 %118, %115
  br label %127

124:                                              ; preds = %113
  %125 = add nsw i16 %116, %119
  %126 = sub nsw i16 %115, %118
  br label %127

127:                                              ; preds = %124, %121
  %128 = phi i16 [ 32, %124 ], [ -32, %121 ]
  %129 = phi i16 [ %126, %124 ], [ %123, %121 ]
  %130 = phi i16 [ %125, %124 ], [ %122, %121 ]
  %131 = add nsw i16 %117, %128
  %132 = ashr i16 %130, 10
  %133 = ashr i16 %129, 10
  %134 = icmp sgt i16 %131, -1
  br i1 %134, label %135, label %138

135:                                              ; preds = %127
  %136 = sub nsw i16 %130, %133
  %137 = add nsw i16 %132, %129
  br label %141

138:                                              ; preds = %127
  %139 = add nsw i16 %130, %133
  %140 = sub nsw i16 %129, %132
  br label %141

141:                                              ; preds = %138, %135
  %142 = phi i16 [ 16, %138 ], [ -16, %135 ]
  %143 = phi i16 [ %140, %138 ], [ %137, %135 ]
  %144 = phi i16 [ %139, %138 ], [ %136, %135 ]
  %145 = add nsw i16 %131, %142
  %146 = ashr i16 %144, 11
  %147 = ashr i16 %143, 11
  %148 = icmp sgt i16 %145, -1
  br i1 %148, label %149, label %152

149:                                              ; preds = %141
  %150 = sub nsw i16 %144, %147
  %151 = add nsw i16 %146, %143
  br label %155

152:                                              ; preds = %141
  %153 = add nsw i16 %144, %147
  %154 = sub nsw i16 %143, %146
  br label %155

155:                                              ; preds = %152, %149
  %156 = phi i16 [ 8, %152 ], [ -8, %149 ]
  %157 = phi i16 [ %154, %152 ], [ %151, %149 ]
  %158 = phi i16 [ %153, %152 ], [ %150, %149 ]
  %159 = add nsw i16 %145, %156
  %160 = ashr i16 %158, 12
  %161 = ashr i16 %157, 12
  %162 = icmp sgt i16 %159, -1
  br i1 %162, label %163, label %166

163:                                              ; preds = %155
  %164 = sub nsw i16 %158, %161
  %165 = add nsw i16 %160, %157
  br label %169

166:                                              ; preds = %155
  %167 = add nsw i16 %158, %161
  %168 = sub nsw i16 %157, %160
  br label %169

169:                                              ; preds = %166, %163
  %170 = phi i16 [ 4, %166 ], [ -4, %163 ]
  %171 = phi i16 [ %168, %166 ], [ %165, %163 ]
  %172 = phi i16 [ %167, %166 ], [ %164, %163 ]
  %173 = add nsw i16 %159, %170
  %174 = ashr i16 %172, 13
  %175 = ashr i16 %171, 13
  %176 = icmp sgt i16 %173, -1
  br i1 %176, label %177, label %180

177:                                              ; preds = %169
  %178 = sub nsw i16 %172, %175
  %179 = add nsw i16 %174, %171
  br label %183

180:                                              ; preds = %169
  %181 = add nsw i16 %172, %175
  %182 = sub nsw i16 %171, %174
  br label %183

183:                                              ; preds = %180, %177
  %184 = phi i16 [ 2, %180 ], [ -2, %177 ]
  %185 = phi i16 [ %182, %180 ], [ %179, %177 ]
  %186 = phi i16 [ %181, %180 ], [ %178, %177 ]
  %187 = add nsw i16 %173, %184
  %188 = ashr i16 %186, 14
  %189 = ashr i16 %185, 14
  %190 = icmp sgt i16 %187, -1
  br i1 %190, label %191, label %194

191:                                              ; preds = %183
  %192 = sub nsw i16 %186, %189
  %193 = add nsw i16 %188, %185
  br label %197

194:                                              ; preds = %183
  %195 = add nsw i16 %186, %189
  %196 = sub nsw i16 %185, %188
  br label %197

197:                                              ; preds = %194, %191
  %198 = phi i16 [ %193, %191 ], [ %196, %194 ]
  %199 = phi i16 [ %192, %191 ], [ %195, %194 ]
  store i16 %199, ptr %2, align 1, !tbaa !2
  store i16 %198, ptr %1, align 1, !tbaa !2
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #4

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nofree noinline norecurse nosync nounwind optsize memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { inlinehint mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { optsize }
attributes #6 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{i64 900}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
