; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/bitweave_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/bitweave_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca i8, align 1
  %2 = alloca i16, align 1
  br label %3

3:                                                ; preds = %8, %0
  %4 = phi i16 [ 0, %0 ], [ %30, %8 ]
  %5 = phi i16 [ -21279, %0 ], [ %10, %8 ]
  %6 = phi i16 [ 0, %0 ], [ %29, %8 ]
  %7 = icmp eq i16 %4, 128
  br i1 %7, label %31, label %8

8:                                                ; preds = %3
  %9 = mul i16 %5, 25173
  %10 = add i16 %9, 13849
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #4
  %11 = lshr i16 %10, 5
  %12 = trunc i16 %11 to i8
  store i8 %12, ptr %1, align 1, !tbaa !6
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #4
  store i16 %10, ptr %2, align 1, !tbaa !2
  call fastcc void @bw_weave(ptr noundef %1, ptr noundef %2) #5
  %13 = load i8, ptr %1, align 1, !tbaa !6
  %14 = zext i8 %13 to i16
  %15 = tail call i16 @llvm.fshl.i16(i16 %6, i16 %6, i16 1)
  %16 = xor i16 %15, %14
  %17 = load i16, ptr %2, align 1, !tbaa !2
  %18 = tail call i16 @llvm.fshl.i16(i16 %16, i16 %16, i16 1)
  %19 = xor i16 %18, %17
  call fastcc void @bw_weave(ptr noundef %1, ptr noundef %2) #5
  %20 = load i8, ptr %1, align 1, !tbaa !6
  %21 = zext i8 %20 to i16
  %22 = and i16 %11, 255
  %23 = xor i16 %22, %21
  %24 = tail call i16 @llvm.fshl.i16(i16 %19, i16 %19, i16 1)
  %25 = xor i16 %23, %24
  %26 = load i16, ptr %2, align 1, !tbaa !2
  %27 = tail call i16 @llvm.fshl.i16(i16 %25, i16 %25, i16 1)
  %28 = xor i16 %26, %27
  %29 = xor i16 %28, %10
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #4
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #4
  %30 = add nuw nsw i16 %4, 1
  br label %3, !llvm.loop !7

31:                                               ; preds = %3
  store volatile i16 %6, ptr @corpus_result, align 1, !tbaa !2
  br label %32

32:                                               ; preds = %32, %31
  tail call void asm sideeffect "", ""() #4, !srcloc !9
  br label %32
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: minsize nofree noinline norecurse nosync nounwind optsize memory(argmem: readwrite)
define internal fastcc void @bw_weave(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1) unnamed_addr #2 {
  %3 = load i8, ptr %0, align 1, !tbaa !6
  %4 = load i16, ptr %1, align 1, !tbaa !2
  br label %5

5:                                                ; preds = %20, %2
  %6 = phi i8 [ %3, %2 ], [ %21, %20 ]
  %7 = phi i8 [ 0, %2 ], [ %22, %20 ]
  %8 = phi i16 [ %4, %2 ], [ %26, %20 ]
  %9 = phi i16 [ 0, %2 ], [ %25, %20 ]
  %10 = phi i8 [ 0, %2 ], [ %27, %20 ]
  %11 = icmp eq i8 %10, 16
  br i1 %11, label %12, label %13

12:                                               ; preds = %5
  store i8 %7, ptr %0, align 1, !tbaa !6
  store i16 %9, ptr %1, align 1, !tbaa !2
  ret void

13:                                               ; preds = %5
  %14 = icmp samesign ult i8 %10, 8
  br i1 %14, label %15, label %20

15:                                               ; preds = %13
  %16 = shl i8 %7, 1
  %17 = and i8 %6, 1
  %18 = or disjoint i8 %16, %17
  %19 = lshr i8 %6, 1
  br label %20

20:                                               ; preds = %15, %13
  %21 = phi i8 [ %19, %15 ], [ %6, %13 ]
  %22 = phi i8 [ %18, %15 ], [ %7, %13 ]
  %23 = shl i16 %9, 1
  %24 = and i16 %8, 1
  %25 = or disjoint i16 %23, %24
  %26 = lshr i16 %8, 1
  %27 = add nuw nsw i8 %10, 1
  br label %5, !llvm.loop !10
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #3

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { minsize nofree noinline norecurse nosync nounwind optsize memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind }
attributes #5 = { minsize optsize }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{i64 642}
!10 = distinct !{!10, !8}
