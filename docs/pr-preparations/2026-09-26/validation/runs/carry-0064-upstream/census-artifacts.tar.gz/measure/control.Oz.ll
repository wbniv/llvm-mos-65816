; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/control.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/control.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@n = dso_local global i16 100, align 1
@sel = dso_local global i8 3, align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %6, %0
  %2 = phi i16 [ 0, %0 ], [ %7, %6 ]
  %3 = phi i16 [ 1, %0 ], [ %8, %6 ]
  %4 = load volatile i16, ptr @n, align 1, !tbaa !2
  %5 = icmp ugt i16 %3, %4
  br i1 %5, label %9, label %6

6:                                                ; preds = %1
  %7 = add i16 %3, %2
  %8 = add i16 %3, 1
  br label %1, !llvm.loop !6

9:                                                ; preds = %1
  %10 = load volatile i16, ptr @n, align 1, !tbaa !2
  br label %11

11:                                               ; preds = %20, %9
  %12 = phi i16 [ %10, %9 ], [ %22, %20 ]
  %13 = phi i16 [ 0, %9 ], [ %21, %20 ]
  %14 = icmp eq i16 %12, 0
  br i1 %14, label %23, label %15

15:                                               ; preds = %11
  %16 = and i16 %12, 1
  %17 = icmp eq i16 %16, 0
  br i1 %17, label %18, label %20

18:                                               ; preds = %15
  %19 = add i16 %13, %12
  br label %20

20:                                               ; preds = %18, %15
  %21 = phi i16 [ %19, %18 ], [ %13, %15 ]
  %22 = add i16 %12, -1
  br label %11, !llvm.loop !8

23:                                               ; preds = %11
  %24 = add i16 %13, %2
  %25 = add i16 %24, 45
  %26 = load volatile i8, ptr @sel, align 1, !tbaa !9
  %27 = add i8 %26, -1
  %28 = icmp ult i8 %27, 3
  br i1 %28, label %29, label %33

29:                                               ; preds = %23
  %30 = mul nuw nsw i8 %27, 10
  %31 = add nuw nsw i8 %30, 10
  %32 = zext nneg i8 %31 to i16
  br label %33

33:                                               ; preds = %23, %29
  %34 = phi i16 [ %32, %29 ], [ 0, %23 ]
  %35 = add i16 %25, %34
  store volatile i16 %35, ptr @corpus_result, align 1, !tbaa !2
  br label %36

36:                                               ; preds = %36, %33
  tail call void asm sideeffect "", ""() #1, !srcloc !10
  br label %36
}

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = !{!4, !4, i64 0}
!10 = !{i64 1146}
