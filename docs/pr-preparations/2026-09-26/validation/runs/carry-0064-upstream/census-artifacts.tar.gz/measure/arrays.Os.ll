; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/arrays.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/arrays.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@idx = dso_local global i8 5, align 1
@lut = internal unnamed_addr constant [8 x i8] c"\03\01\04\01\05\09\02\06", align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [8 x i8], align 1
  %2 = load volatile i8, ptr @idx, align 1, !tbaa !6
  %3 = zext i8 %2 to i16
  %4 = getelementptr inbounds nuw i8, ptr @lut, i16 %3
  %5 = load i8, ptr %4, align 1, !tbaa !6
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #2
  store i8 6, ptr %1, align 1, !tbaa !6
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 1
  store i8 2, ptr %6, align 1, !tbaa !6
  %7 = getelementptr inbounds nuw i8, ptr %1, i16 2
  store i8 8, ptr %7, align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 3
  store i8 2, ptr %8, align 1, !tbaa !6
  %9 = getelementptr inbounds nuw i8, ptr %1, i16 4
  store i8 10, ptr %9, align 1, !tbaa !6
  %10 = getelementptr inbounds nuw i8, ptr %1, i16 5
  store i8 18, ptr %10, align 1, !tbaa !6
  %11 = getelementptr inbounds nuw i8, ptr %1, i16 6
  store i8 4, ptr %11, align 1, !tbaa !6
  %12 = getelementptr inbounds nuw i8, ptr %1, i16 7
  store i8 12, ptr %12, align 1, !tbaa !6
  %13 = zext i8 %5 to i16
  %14 = mul nuw nsw i16 %13, 100
  %15 = add nuw nsw i16 %14, 31
  br label %16

16:                                               ; preds = %0, %16
  %17 = phi i8 [ %24, %16 ], [ 0, %0 ]
  %18 = phi i16 [ %23, %16 ], [ %15, %0 ]
  %19 = zext nneg i8 %17 to i16
  %20 = getelementptr i8, ptr %1, i16 %19
  %21 = load i8, ptr %20, align 1, !tbaa !6
  %22 = zext i8 %21 to i16
  %23 = add i16 %18, %22
  %24 = add nuw nsw i8 %17, 1
  %25 = icmp eq i8 %24, 8
  br i1 %25, label %26, label %16, !llvm.loop !7

26:                                               ; preds = %16
  store volatile i16 %23, ptr @corpus_result, align 1, !tbaa !2
  br label %27

27:                                               ; preds = %27, %26
  tail call void asm sideeffect "", ""() #2, !srcloc !9
  br label %27
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{i64 983}
