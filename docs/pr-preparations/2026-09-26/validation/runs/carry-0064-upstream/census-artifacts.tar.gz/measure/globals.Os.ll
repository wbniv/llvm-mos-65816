; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/globals.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/globals.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@data_vals = dso_local local_unnamed_addr global [4 x i16] [i16 4369, i16 8738, i16 13107, i16 17476], align 1
@data_byte = dso_local local_unnamed_addr global i8 -85, align 1
@one = dso_local global i8 1, align 1
@bss_vals = dso_local local_unnamed_addr global [8 x i16] zeroinitializer, align 1
@bss_byte = dso_local local_unnamed_addr global i8 0, align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %0, %1
  %2 = phi i8 [ 0, %0 ], [ %14, %1 ]
  %3 = phi i8 [ 0, %0 ], [ %12, %1 ]
  %4 = phi i16 [ 0, %0 ], [ %11, %1 ]
  %5 = zext nneg i8 %2 to i16
  %6 = getelementptr i8, ptr @data_vals, i16 %5
  %7 = load i16, ptr %6, align 1, !tbaa !2
  %8 = load volatile i8, ptr @one, align 1, !tbaa !6
  %9 = zext i8 %8 to i16
  %10 = mul i16 %7, %9
  %11 = add i16 %10, %4
  %12 = add nuw nsw i8 %3, 1
  %13 = icmp eq i8 %12, 4
  %14 = add nuw nsw i8 %2, 2
  br i1 %13, label %15, label %1, !llvm.loop !7

15:                                               ; preds = %1
  %16 = load i8, ptr @data_byte, align 1, !tbaa !6
  %17 = load volatile i8, ptr @one, align 1, !tbaa !6
  br label %18

18:                                               ; preds = %15, %18
  %19 = phi i8 [ 0, %15 ], [ %28, %18 ]
  %20 = phi i16 [ 0, %15 ], [ %25, %18 ]
  %21 = phi i8 [ 0, %15 ], [ %26, %18 ]
  %22 = zext nneg i8 %19 to i16
  %23 = getelementptr i8, ptr @bss_vals, i16 %22
  %24 = load i16, ptr %23, align 1, !tbaa !2
  %25 = add i16 %24, %20
  %26 = add nuw nsw i8 %21, 1
  %27 = icmp eq i8 %26, 8
  %28 = add nuw nsw i8 %19, 2
  br i1 %27, label %29, label %18, !llvm.loop !9

29:                                               ; preds = %18
  %30 = zext i8 %16 to i16
  %31 = zext i8 %17 to i16
  %32 = mul nuw nsw i16 %31, %30
  %33 = add i16 %32, %11
  %34 = load i8, ptr @bss_byte, align 1, !tbaa !6
  %35 = zext i8 %34 to i16
  %36 = sub nsw i16 0, %35
  %37 = icmp eq i16 %25, %36
  br i1 %37, label %40, label %38

38:                                               ; preds = %29
  %39 = add i16 %33, -4096
  br label %40

40:                                               ; preds = %38, %29
  %41 = phi i16 [ %39, %38 ], [ %33, %29 ]
  store volatile i16 %41, ptr @corpus_result, align 1, !tbaa !2
  br label %42

42:                                               ; preds = %42, %40
  tail call void asm sideeffect "", ""() #1, !srcloc !10
  br label %42
}

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = distinct !{!9, !8}
!10 = !{i64 1376}
