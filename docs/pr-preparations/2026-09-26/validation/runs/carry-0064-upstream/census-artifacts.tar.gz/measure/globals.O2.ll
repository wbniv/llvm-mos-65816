; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/globals.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/globals.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@data_vals = dso_local local_unnamed_addr global [4 x i16] [i16 4369, i16 8738, i16 13107, i16 17476], align 1
@data_byte = dso_local local_unnamed_addr global i8 -85, align 1
@one = dso_local global i8 1, align 1
@bss_vals = dso_local local_unnamed_addr global [8 x i16] zeroinitializer, align 1
@bss_byte = dso_local local_unnamed_addr global i8 0, align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = load i16, ptr @data_vals, align 1, !tbaa !2
  %2 = load volatile i8, ptr @one, align 1, !tbaa !6
  %3 = load i16, ptr getelementptr inbounds nuw (i8, ptr @data_vals, i16 2), align 1, !tbaa !2
  %4 = load volatile i8, ptr @one, align 1, !tbaa !6
  %5 = load i16, ptr getelementptr inbounds nuw (i8, ptr @data_vals, i16 4), align 1, !tbaa !2
  %6 = load volatile i8, ptr @one, align 1, !tbaa !6
  %7 = load i16, ptr getelementptr inbounds nuw (i8, ptr @data_vals, i16 6), align 1, !tbaa !2
  %8 = load volatile i8, ptr @one, align 1, !tbaa !6
  %9 = load i8, ptr @data_byte, align 1, !tbaa !6
  %10 = load volatile i8, ptr @one, align 1, !tbaa !6
  %11 = load i16, ptr @bss_vals, align 1, !tbaa !2
  %12 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bss_vals, i16 2), align 1, !tbaa !2
  %13 = add i16 %12, %11
  %14 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bss_vals, i16 4), align 1, !tbaa !2
  %15 = add i16 %14, %13
  %16 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bss_vals, i16 6), align 1, !tbaa !2
  %17 = add i16 %16, %15
  %18 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bss_vals, i16 8), align 1, !tbaa !2
  %19 = add i16 %18, %17
  %20 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bss_vals, i16 10), align 1, !tbaa !2
  %21 = add i16 %20, %19
  %22 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bss_vals, i16 12), align 1, !tbaa !2
  %23 = add i16 %22, %21
  %24 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bss_vals, i16 14), align 1, !tbaa !2
  %25 = add i16 %24, %23
  %26 = zext i8 %2 to i16
  %27 = mul i16 %1, %26
  %28 = zext i8 %4 to i16
  %29 = mul i16 %3, %28
  %30 = add i16 %29, %27
  %31 = zext i8 %6 to i16
  %32 = mul i16 %5, %31
  %33 = add i16 %32, %30
  %34 = zext i8 %8 to i16
  %35 = mul i16 %7, %34
  %36 = add i16 %35, %33
  %37 = zext i8 %9 to i16
  %38 = zext i8 %10 to i16
  %39 = mul nuw nsw i16 %38, %37
  %40 = add i16 %39, %36
  %41 = load i8, ptr @bss_byte, align 1, !tbaa !6
  %42 = zext i8 %41 to i16
  %43 = sub nsw i16 0, %42
  %44 = icmp eq i16 %25, %43
  br i1 %44, label %47, label %45

45:                                               ; preds = %0
  %46 = add i16 %40, -4096
  br label %47

47:                                               ; preds = %45, %0
  %48 = phi i16 [ %46, %45 ], [ %40, %0 ]
  store volatile i16 %48, ptr @corpus_result, align 1, !tbaa !2
  br label %49

49:                                               ; preds = %49, %47
  tail call void asm sideeffect "", ""() #1, !srcloc !7
  br label %49
}

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = !{i64 1376}
