; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/lsystem_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/lsystem_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.LTurtle = type { i32, i32, i8, i8 }

@corpus_result = dso_local global i16 0, align 1
@ls_buf = internal unnamed_addr global [2400 x i8] zeroinitializer, align 1
@.str = private unnamed_addr constant [19 x i8] c"F-[[X]+X]+F[+FX]-X\00", align 1
@.str.1 = private unnamed_addr constant [3 x i8] c"FF\00", align 1
@SINCOS = internal unnamed_addr constant [256 x i16] [i16 0, i16 6, i16 13, i16 19, i16 25, i16 31, i16 38, i16 44, i16 50, i16 56, i16 62, i16 68, i16 74, i16 80, i16 86, i16 92, i16 98, i16 104, i16 109, i16 115, i16 121, i16 126, i16 132, i16 137, i16 142, i16 147, i16 152, i16 157, i16 162, i16 167, i16 172, i16 177, i16 181, i16 185, i16 190, i16 194, i16 198, i16 202, i16 206, i16 209, i16 213, i16 216, i16 220, i16 223, i16 226, i16 229, i16 231, i16 234, i16 237, i16 239, i16 241, i16 243, i16 245, i16 247, i16 248, i16 250, i16 251, i16 252, i16 253, i16 254, i16 255, i16 255, i16 256, i16 256, i16 256, i16 256, i16 256, i16 255, i16 255, i16 254, i16 253, i16 252, i16 251, i16 250, i16 248, i16 247, i16 245, i16 243, i16 241, i16 239, i16 237, i16 234, i16 231, i16 229, i16 226, i16 223, i16 220, i16 216, i16 213, i16 209, i16 206, i16 202, i16 198, i16 194, i16 190, i16 185, i16 181, i16 177, i16 172, i16 167, i16 162, i16 157, i16 152, i16 147, i16 142, i16 137, i16 132, i16 126, i16 121, i16 115, i16 109, i16 104, i16 98, i16 92, i16 86, i16 80, i16 74, i16 68, i16 62, i16 56, i16 50, i16 44, i16 38, i16 31, i16 25, i16 19, i16 13, i16 6, i16 0, i16 -6, i16 -13, i16 -19, i16 -25, i16 -31, i16 -38, i16 -44, i16 -50, i16 -56, i16 -62, i16 -68, i16 -74, i16 -80, i16 -86, i16 -92, i16 -98, i16 -104, i16 -109, i16 -115, i16 -121, i16 -126, i16 -132, i16 -137, i16 -142, i16 -147, i16 -152, i16 -157, i16 -162, i16 -167, i16 -172, i16 -177, i16 -181, i16 -185, i16 -190, i16 -194, i16 -198, i16 -202, i16 -206, i16 -209, i16 -213, i16 -216, i16 -220, i16 -223, i16 -226, i16 -229, i16 -231, i16 -234, i16 -237, i16 -239, i16 -241, i16 -243, i16 -245, i16 -247, i16 -248, i16 -250, i16 -251, i16 -252, i16 -253, i16 -254, i16 -255, i16 -255, i16 -256, i16 -256, i16 -256, i16 -256, i16 -256, i16 -255, i16 -255, i16 -254, i16 -253, i16 -252, i16 -251, i16 -250, i16 -248, i16 -247, i16 -245, i16 -243, i16 -241, i16 -239, i16 -237, i16 -234, i16 -231, i16 -229, i16 -226, i16 -223, i16 -220, i16 -216, i16 -213, i16 -209, i16 -206, i16 -202, i16 -198, i16 -194, i16 -190, i16 -185, i16 -181, i16 -177, i16 -172, i16 -167, i16 -162, i16 -157, i16 -152, i16 -147, i16 -142, i16 -137, i16 -132, i16 -126, i16 -121, i16 -115, i16 -109, i16 -104, i16 -98, i16 -92, i16 -86, i16 -80, i16 -74, i16 -68, i16 -62, i16 -56, i16 -50, i16 -44, i16 -38, i16 -31, i16 -25, i16 -19, i16 -13, i16 -6], align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [24 x %struct.LTurtle], align 1
  store i8 88, ptr @ls_buf, align 1, !tbaa !6
  br label %2

2:                                                ; preds = %37, %0
  %3 = phi i16 [ 1, %0 ], [ %38, %37 ]
  %4 = phi i8 [ 0, %0 ], [ %39, %37 ]
  %5 = icmp eq i16 %3, 0
  br i1 %5, label %40, label %6

6:                                                ; preds = %2, %30
  %7 = phi i16 [ %32, %30 ], [ %3, %2 ]
  %8 = phi i16 [ %31, %30 ], [ 0, %2 ]
  %9 = getelementptr inbounds nuw i8, ptr @ls_buf, i16 %8
  %10 = load i8, ptr %9, align 1, !tbaa !6
  %11 = icmp eq i8 %10, 70
  %12 = select i1 %11, ptr @.str.1, ptr null
  %13 = icmp eq i8 %10, 88
  %14 = select i1 %13, ptr @.str, ptr %12
  %15 = icmp eq ptr %14, null
  br i1 %15, label %16, label %18

16:                                               ; preds = %6
  %17 = add nuw nsw i16 %8, 1
  br label %30, !llvm.loop !7

18:                                               ; preds = %6
  %19 = tail call i16 @strlen(ptr noundef nonnull dereferenceable(1) %14) #5
  %20 = add nsw i16 %7, -1
  %21 = add i16 %20, %19
  %22 = icmp ugt i16 %21, 2399
  br i1 %22, label %23, label %24

23:                                               ; preds = %18
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #6
  br label %46

24:                                               ; preds = %18
  %25 = add i16 %19, %8
  %26 = getelementptr inbounds nuw i8, ptr @ls_buf, i16 %25
  %27 = add nuw nsw i16 %8, 1
  %28 = getelementptr inbounds nuw i8, ptr @ls_buf, i16 %27
  %29 = sub nsw i16 %7, %27
  tail call void @llvm.memmove.p0.p0.i16(ptr nonnull align 1 %26, ptr nonnull align 1 %28, i16 %29, i1 false)
  tail call void @llvm.memcpy.p0.p0.i16(ptr nonnull align 1 %9, ptr nonnull align 1 %14, i16 %19, i1 false)
  br label %30

30:                                               ; preds = %24, %16
  %31 = phi i16 [ %17, %16 ], [ %25, %24 ]
  %32 = phi i16 [ %7, %16 ], [ %21, %24 ]
  %33 = icmp ult i16 %31, %32
  br i1 %33, label %6, label %34

34:                                               ; preds = %30
  %35 = add nuw nsw i8 %4, 1
  %36 = icmp eq i8 %35, 6
  br i1 %36, label %44, label %37

37:                                               ; preds = %34, %40
  %38 = phi i16 [ %32, %34 ], [ 0, %40 ]
  %39 = phi i8 [ %35, %34 ], [ %41, %40 ]
  br label %2, !llvm.loop !9

40:                                               ; preds = %2
  %41 = add nuw nsw i8 %4, 1
  %42 = icmp eq i8 %41, 6
  br i1 %42, label %43, label %37

43:                                               ; preds = %40
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #6
  br label %167

44:                                               ; preds = %34
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #6
  %45 = icmp eq i16 %32, 0
  br i1 %45, label %167, label %46

46:                                               ; preds = %44, %23
  %47 = phi i16 [ %7, %23 ], [ %32, %44 ]
  br label %48

48:                                               ; preds = %158, %46
  %49 = phi i8 [ %164, %158 ], [ 0, %46 ]
  %50 = phi i8 [ %163, %158 ], [ -64, %46 ]
  %51 = phi i32 [ %162, %158 ], [ 31744, %46 ]
  %52 = phi i32 [ %161, %158 ], [ 17920, %46 ]
  %53 = phi i8 [ %160, %158 ], [ 0, %46 ]
  %54 = phi i16 [ %159, %158 ], [ -1, %46 ]
  %55 = phi i16 [ %165, %158 ], [ 0, %46 ]
  %56 = getelementptr inbounds nuw i8, ptr @ls_buf, i16 %55
  %57 = load i8, ptr %56, align 1, !tbaa !6
  switch i8 %57, label %158 [
    i8 70, label %58
    i8 43, label %127
    i8 45, label %129
    i8 91, label %131
    i8 93, label %145
  ]

58:                                               ; preds = %48
  %59 = zext i8 %50 to i16
  %60 = add i8 %50, 64
  %61 = zext i8 %60 to i16
  %62 = getelementptr inbounds nuw [2 x i8], ptr @SINCOS, i16 %61
  %63 = load i16, ptr %62, align 1, !tbaa !2
  %64 = sext i16 %63 to i32
  %65 = mul nsw i32 %64, 38
  %66 = ashr i32 %65, 4
  %67 = add nsw i32 %66, %52
  %68 = getelementptr inbounds nuw [2 x i8], ptr @SINCOS, i16 %59
  %69 = load i16, ptr %68, align 1, !tbaa !2
  %70 = sext i16 %69 to i32
  %71 = mul nsw i32 %70, 38
  %72 = ashr i32 %71, 4
  %73 = add nsw i32 %72, %51
  %74 = ashr i32 %52, 8
  %75 = icmp slt i32 %74, 0
  br i1 %75, label %80, label %76

76:                                               ; preds = %58
  %77 = icmp samesign ugt i32 %74, 127
  %78 = trunc nuw nsw i32 %74 to i8
  br i1 %77, label %79, label %80

79:                                               ; preds = %76
  br label %80

80:                                               ; preds = %79, %76, %58
  %81 = phi i8 [ %78, %76 ], [ 127, %79 ], [ 0, %58 ]
  %82 = ashr i32 %51, 8
  %83 = icmp slt i32 %82, 0
  br i1 %83, label %88, label %84

84:                                               ; preds = %80
  %85 = icmp samesign ugt i32 %82, 127
  %86 = trunc nuw nsw i32 %82 to i8
  br i1 %85, label %87, label %88

87:                                               ; preds = %84
  br label %88

88:                                               ; preds = %87, %84, %80
  %89 = phi i8 [ %86, %84 ], [ 127, %87 ], [ 0, %80 ]
  %90 = ashr i32 %67, 8
  %91 = icmp slt i32 %90, 0
  br i1 %91, label %96, label %92

92:                                               ; preds = %88
  %93 = icmp samesign ugt i32 %90, 127
  %94 = trunc nuw nsw i32 %90 to i8
  br i1 %93, label %95, label %96

95:                                               ; preds = %92
  br label %96

96:                                               ; preds = %95, %92, %88
  %97 = phi i8 [ %94, %92 ], [ 127, %95 ], [ 0, %88 ]
  %98 = ashr i32 %73, 8
  %99 = icmp slt i32 %98, 0
  br i1 %99, label %104, label %100

100:                                              ; preds = %96
  %101 = icmp samesign ugt i32 %98, 127
  %102 = trunc nuw nsw i32 %98 to i8
  br i1 %101, label %103, label %104

103:                                              ; preds = %100
  br label %104

104:                                              ; preds = %103, %100, %96
  %105 = phi i8 [ %102, %100 ], [ 127, %103 ], [ 0, %96 ]
  %106 = icmp eq i8 %49, 0
  br i1 %106, label %110, label %107

107:                                              ; preds = %104
  %108 = icmp ult i8 %49, 3
  %109 = select i1 %108, i8 2, i8 3
  br label %110

110:                                              ; preds = %107, %104
  %111 = phi i8 [ %109, %107 ], [ 1, %104 ]
  %112 = tail call i16 @llvm.fshl.i16(i16 %54, i16 %54, i16 1)
  %113 = zext nneg i8 %81 to i16
  %114 = shl nuw nsw i16 %113, 8
  %115 = zext nneg i8 %89 to i16
  %116 = or disjoint i16 %114, %115
  %117 = xor i16 %116, %112
  %118 = tail call i16 @llvm.fshl.i16(i16 %117, i16 %117, i16 1)
  %119 = zext nneg i8 %97 to i16
  %120 = shl nuw nsw i16 %119, 8
  %121 = zext nneg i8 %105 to i16
  %122 = or disjoint i16 %120, %121
  %123 = xor i16 %122, %118
  %124 = tail call i16 @llvm.fshl.i16(i16 %123, i16 %123, i16 1)
  %125 = zext nneg i8 %111 to i16
  %126 = xor i16 %124, %125
  br label %158

127:                                              ; preds = %48
  %128 = add i8 %50, -18
  br label %158

129:                                              ; preds = %48
  %130 = add i8 %50, 18
  br label %158

131:                                              ; preds = %48
  %132 = icmp ult i8 %53, 24
  br i1 %132, label %133, label %140

133:                                              ; preds = %131
  %134 = zext nneg i8 %53 to i16
  %135 = add nuw nsw i8 %53, 1
  %136 = getelementptr inbounds nuw [10 x i8], ptr %1, i16 %134
  store i32 %52, ptr %136, align 1, !tbaa !10
  %137 = getelementptr inbounds nuw i8, ptr %136, i16 4
  store i32 %51, ptr %137, align 1, !tbaa !10
  %138 = getelementptr inbounds nuw i8, ptr %136, i16 8
  store i8 %50, ptr %138, align 1, !tbaa !6
  %139 = getelementptr inbounds nuw i8, ptr %136, i16 9
  store i8 %49, ptr %139, align 1, !tbaa !6
  br label %140

140:                                              ; preds = %133, %131
  %141 = phi i8 [ %135, %133 ], [ %53, %131 ]
  %142 = icmp eq i8 %49, -1
  br i1 %142, label %158, label %143

143:                                              ; preds = %140
  %144 = add nuw i8 %49, 1
  br label %158

145:                                              ; preds = %48
  %146 = icmp eq i8 %53, 0
  br i1 %146, label %158, label %147

147:                                              ; preds = %145
  %148 = add i8 %53, -1
  %149 = zext i8 %148 to i16
  %150 = getelementptr inbounds nuw [10 x i8], ptr %1, i16 %149
  %151 = load i32, ptr %150, align 1, !tbaa !10
  %152 = getelementptr inbounds nuw i8, ptr %150, i16 4
  %153 = load i32, ptr %152, align 1, !tbaa !10
  %154 = getelementptr inbounds nuw i8, ptr %150, i16 8
  %155 = load i8, ptr %154, align 1, !tbaa !6
  %156 = getelementptr inbounds nuw i8, ptr %150, i16 9
  %157 = load i8, ptr %156, align 1, !tbaa !6
  br label %158

158:                                              ; preds = %147, %145, %143, %140, %129, %127, %110, %48
  %159 = phi i16 [ %126, %110 ], [ %54, %127 ], [ %54, %129 ], [ %54, %143 ], [ %54, %140 ], [ %54, %147 ], [ %54, %145 ], [ %54, %48 ]
  %160 = phi i8 [ %53, %110 ], [ %53, %127 ], [ %53, %129 ], [ %141, %143 ], [ %141, %140 ], [ %148, %147 ], [ 0, %145 ], [ %53, %48 ]
  %161 = phi i32 [ %67, %110 ], [ %52, %127 ], [ %52, %129 ], [ %52, %143 ], [ %52, %140 ], [ %151, %147 ], [ %52, %145 ], [ %52, %48 ]
  %162 = phi i32 [ %73, %110 ], [ %51, %127 ], [ %51, %129 ], [ %51, %143 ], [ %51, %140 ], [ %153, %147 ], [ %51, %145 ], [ %51, %48 ]
  %163 = phi i8 [ %50, %110 ], [ %128, %127 ], [ %130, %129 ], [ %50, %143 ], [ %50, %140 ], [ %155, %147 ], [ %50, %145 ], [ %50, %48 ]
  %164 = phi i8 [ %49, %110 ], [ %49, %127 ], [ %49, %129 ], [ %144, %143 ], [ -1, %140 ], [ %157, %147 ], [ %49, %145 ], [ %49, %48 ]
  %165 = add nuw i16 %55, 1
  %166 = icmp eq i16 %165, %47
  br i1 %166, label %167, label %48, !llvm.loop !12

167:                                              ; preds = %158, %43, %44
  %168 = phi i16 [ -1, %44 ], [ -1, %43 ], [ %159, %158 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #6
  store volatile i16 %168, ptr @corpus_result, align 1, !tbaa !2
  br label %169

169:                                              ; preds = %169, %167
  tail call void asm sideeffect "", ""() #6, !srcloc !13
  br label %169
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nounwind optsize willreturn memory(argmem: read)
declare dso_local i16 @strlen(ptr noundef captures(none)) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i16(ptr writeonly captures(none), ptr readonly captures(none), i16, i1 immarg) #3

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #4

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nocallback nofree nounwind optsize willreturn memory(argmem: read) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #3 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nounwind optsize }
attributes #6 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = distinct !{!9, !8}
!10 = !{!11, !11, i64 0}
!11 = !{!"long", !4, i64 0}
!12 = distinct !{!12, !8}
!13 = !{i64 945}
