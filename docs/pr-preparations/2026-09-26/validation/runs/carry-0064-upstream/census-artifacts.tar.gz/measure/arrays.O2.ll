; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/arrays.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/arrays.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@idx = dso_local global i8 5, align 1
@lut = internal unnamed_addr constant [8 x i8] c"\03\01\04\01\05\09\02\06", align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = load volatile i8, ptr @idx, align 1, !tbaa !6
  %2 = zext i8 %1 to i16
  %3 = getelementptr inbounds nuw i8, ptr @lut, i16 %2
  %4 = load i8, ptr %3, align 1, !tbaa !6
  %5 = zext i8 %4 to i16
  %6 = mul nuw nsw i16 %5, 100
  %7 = add nuw nsw i16 %6, 93
  store volatile i16 %7, ptr @corpus_result, align 1, !tbaa !2
  br label %8

8:                                                ; preds = %8, %0
  tail call void asm sideeffect "", ""() #1, !srcloc !7
  br label %8
}

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = !{i64 983}
