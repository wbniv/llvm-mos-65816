; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/bitshuffle_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/bitshuffle_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %1, %0
  %2 = phi i16 [ 0, %0 ], [ %34, %1 ]
  %3 = phi i16 [ 0, %0 ], [ %35, %1 ]
  %4 = zext nneg i16 %3 to i32
  %5 = mul nuw nsw i32 %4, 131136
  %6 = mul nuw nsw i16 %3, 5
  %7 = zext nneg i16 %6 to i32
  %8 = xor i32 %5, %7
  %9 = xor i32 %8, -1640531527
  %10 = tail call noundef i32 @llvm.bitreverse.i32(i32 range(i32 -1644167168, 256) %9)
  %11 = xor i32 %8, -878884235
  %12 = tail call noundef i32 @llvm.bswap.i32(i32 range(i32 -905969664, -872415232) %11)
  %13 = tail call noundef i32 @llvm.bitreverse.i32(i32 range(i32 -1644167168, 256) %4)
  %14 = lshr exact i32 %13, 24
  %15 = tail call noundef i32 @llvm.bitreverse.i32(i32 range(i32 -1644167168, 256) %14)
  %16 = trunc i32 %10 to i16
  %17 = tail call i16 @llvm.fshl.i16(i16 %2, i16 %2, i16 1)
  %18 = xor i16 %17, %16
  %19 = lshr i32 %10, 16
  %20 = trunc nuw i32 %19 to i16
  %21 = tail call i16 @llvm.fshl.i16(i16 %18, i16 %18, i16 1)
  %22 = xor i16 %21, %20
  %23 = trunc i32 %12 to i16
  %24 = tail call i16 @llvm.fshl.i16(i16 %22, i16 %22, i16 1)
  %25 = xor i16 %24, %23
  %26 = lshr i32 %12, 16
  %27 = trunc nuw i32 %26 to i16
  %28 = tail call i16 @llvm.fshl.i16(i16 %25, i16 %25, i16 1)
  %29 = xor i16 %28, %27
  %30 = lshr exact i32 %15, 16
  %31 = or disjoint i32 %30, %14
  %32 = trunc nuw i32 %31 to i16
  %33 = tail call i16 @llvm.fshl.i16(i16 %29, i16 %29, i16 1)
  %34 = xor i16 %33, %32
  %35 = add nuw nsw i16 %3, 1
  %36 = icmp eq i16 %35, 256
  br i1 %36, label %37, label %1, !llvm.loop !6

37:                                               ; preds = %1
  store volatile i16 %34, ptr @corpus_result, align 1, !tbaa !2
  br label %38

38:                                               ; preds = %38, %37
  tail call void asm sideeffect "", ""() #3, !srcloc !8
  br label %38
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bitreverse.i32(i32) #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #2

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{i64 466}
