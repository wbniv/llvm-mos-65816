; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/arrays.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/arrays.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@idx = dso_local global i8 5, align 1
@lut = internal unnamed_addr constant [8 x i8] c"\03\01\04\01\05\09\02\06", align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [8 x i8], align 1
  %2 = load volatile i8, ptr @idx, align 1, !tbaa !6
  %3 = zext i8 %2 to i16
  %4 = getelementptr inbounds nuw i8, ptr @lut, i16 %3
  %5 = load i8, ptr %4, align 1, !tbaa !6
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #2
  br label %6

6:                                                ; preds = %13, %0
  %7 = phi i8 [ 0, %0 ], [ %19, %13 ]
  %8 = icmp eq i8 %7, 8
  br i1 %8, label %9, label %13

9:                                                ; preds = %6
  %10 = zext i8 %5 to i16
  %11 = mul nuw nsw i16 %10, 100
  %12 = add nuw nsw i16 %11, 31
  br label %20

13:                                               ; preds = %6
  %14 = zext nneg i8 %7 to i16
  %15 = getelementptr i8, ptr @lut, i16 %14
  %16 = load i8, ptr %15, align 1, !tbaa !6
  %17 = shl i8 %16, 1
  %18 = getelementptr i8, ptr %1, i16 %14
  store i8 %17, ptr %18, align 1, !tbaa !6
  %19 = add nuw nsw i8 %7, 1
  br label %6, !llvm.loop !7

20:                                               ; preds = %9, %24
  %21 = phi i16 [ %29, %24 ], [ %12, %9 ]
  %22 = phi i8 [ %30, %24 ], [ 0, %9 ]
  %23 = icmp eq i8 %22, 8
  br i1 %23, label %31, label %24

24:                                               ; preds = %20
  %25 = zext nneg i8 %22 to i16
  %26 = getelementptr i8, ptr %1, i16 %25
  %27 = load i8, ptr %26, align 1, !tbaa !6
  %28 = zext i8 %27 to i16
  %29 = add i16 %21, %28
  %30 = add nuw nsw i8 %22, 1
  br label %20, !llvm.loop !9

31:                                               ; preds = %20
  store volatile i16 %21, ptr @corpus_result, align 1, !tbaa !2
  br label %32

32:                                               ; preds = %32, %31
  tail call void asm sideeffect "", ""() #2, !srcloc !10
  br label %32
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = distinct !{!9, !8}
!10 = !{i64 983}
