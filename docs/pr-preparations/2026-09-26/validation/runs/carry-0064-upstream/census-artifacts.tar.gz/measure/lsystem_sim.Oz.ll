; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/lsystem_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/lsystem_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.LTurtle = type { i32, i32, i8, i8 }

@corpus_result = dso_local global i16 0, align 1
@ls_buf = internal unnamed_addr global [2400 x i8] zeroinitializer, align 1
@.str = private unnamed_addr constant [19 x i8] c"F-[[X]+X]+F[+FX]-X\00", align 1
@.str.1 = private unnamed_addr constant [3 x i8] c"FF\00", align 1
@SINCOS = internal unnamed_addr constant [256 x i16] [i16 0, i16 6, i16 13, i16 19, i16 25, i16 31, i16 38, i16 44, i16 50, i16 56, i16 62, i16 68, i16 74, i16 80, i16 86, i16 92, i16 98, i16 104, i16 109, i16 115, i16 121, i16 126, i16 132, i16 137, i16 142, i16 147, i16 152, i16 157, i16 162, i16 167, i16 172, i16 177, i16 181, i16 185, i16 190, i16 194, i16 198, i16 202, i16 206, i16 209, i16 213, i16 216, i16 220, i16 223, i16 226, i16 229, i16 231, i16 234, i16 237, i16 239, i16 241, i16 243, i16 245, i16 247, i16 248, i16 250, i16 251, i16 252, i16 253, i16 254, i16 255, i16 255, i16 256, i16 256, i16 256, i16 256, i16 256, i16 255, i16 255, i16 254, i16 253, i16 252, i16 251, i16 250, i16 248, i16 247, i16 245, i16 243, i16 241, i16 239, i16 237, i16 234, i16 231, i16 229, i16 226, i16 223, i16 220, i16 216, i16 213, i16 209, i16 206, i16 202, i16 198, i16 194, i16 190, i16 185, i16 181, i16 177, i16 172, i16 167, i16 162, i16 157, i16 152, i16 147, i16 142, i16 137, i16 132, i16 126, i16 121, i16 115, i16 109, i16 104, i16 98, i16 92, i16 86, i16 80, i16 74, i16 68, i16 62, i16 56, i16 50, i16 44, i16 38, i16 31, i16 25, i16 19, i16 13, i16 6, i16 0, i16 -6, i16 -13, i16 -19, i16 -25, i16 -31, i16 -38, i16 -44, i16 -50, i16 -56, i16 -62, i16 -68, i16 -74, i16 -80, i16 -86, i16 -92, i16 -98, i16 -104, i16 -109, i16 -115, i16 -121, i16 -126, i16 -132, i16 -137, i16 -142, i16 -147, i16 -152, i16 -157, i16 -162, i16 -167, i16 -172, i16 -177, i16 -181, i16 -185, i16 -190, i16 -194, i16 -198, i16 -202, i16 -206, i16 -209, i16 -213, i16 -216, i16 -220, i16 -223, i16 -226, i16 -229, i16 -231, i16 -234, i16 -237, i16 -239, i16 -241, i16 -243, i16 -245, i16 -247, i16 -248, i16 -250, i16 -251, i16 -252, i16 -253, i16 -254, i16 -255, i16 -255, i16 -256, i16 -256, i16 -256, i16 -256, i16 -256, i16 -255, i16 -255, i16 -254, i16 -253, i16 -252, i16 -251, i16 -250, i16 -248, i16 -247, i16 -245, i16 -243, i16 -241, i16 -239, i16 -237, i16 -234, i16 -231, i16 -229, i16 -226, i16 -223, i16 -220, i16 -216, i16 -213, i16 -209, i16 -206, i16 -202, i16 -198, i16 -194, i16 -190, i16 -185, i16 -181, i16 -177, i16 -172, i16 -167, i16 -162, i16 -157, i16 -152, i16 -147, i16 -142, i16 -137, i16 -132, i16 -126, i16 -121, i16 -115, i16 -109, i16 -104, i16 -98, i16 -92, i16 -86, i16 -80, i16 -74, i16 -68, i16 -62, i16 -56, i16 -50, i16 -44, i16 -38, i16 -31, i16 -25, i16 -19, i16 -13, i16 -6], align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [24 x %struct.LTurtle], align 1
  store i8 88, ptr @ls_buf, align 1, !tbaa !6
  br label %2

2:                                                ; preds = %33, %0
  %3 = phi i8 [ 0, %0 ], [ %34, %33 ]
  %4 = phi i16 [ 1, %0 ], [ %8, %33 ]
  %5 = icmp eq i8 %3, 6
  br i1 %5, label %35, label %6

6:                                                ; preds = %2, %27
  %7 = phi i16 [ %28, %27 ], [ 0, %2 ]
  %8 = phi i16 [ %25, %27 ], [ %4, %2 ]
  br label %9

9:                                                ; preds = %6, %20
  %10 = phi i16 [ %21, %20 ], [ %7, %6 ]
  %11 = icmp ult i16 %10, %8
  br i1 %11, label %12, label %33

12:                                               ; preds = %9
  %13 = getelementptr inbounds nuw i8, ptr @ls_buf, i16 %10
  %14 = load i8, ptr %13, align 1, !tbaa !6
  %15 = icmp eq i8 %14, 70
  %16 = select i1 %15, ptr @.str.1, ptr null
  %17 = icmp eq i8 %14, 88
  %18 = select i1 %17, ptr @.str, ptr %16
  %19 = icmp eq ptr %18, null
  br i1 %19, label %20, label %22

20:                                               ; preds = %12
  %21 = add nuw nsw i16 %10, 1
  br label %9, !llvm.loop !7

22:                                               ; preds = %12
  %23 = tail call i16 @strlen(ptr noundef nonnull dereferenceable(1) %18) #5
  %24 = add nsw i16 %8, -1
  %25 = add i16 %24, %23
  %26 = icmp ugt i16 %25, 2399
  br i1 %26, label %35, label %27

27:                                               ; preds = %22
  %28 = add i16 %23, %10
  %29 = getelementptr inbounds nuw i8, ptr @ls_buf, i16 %28
  %30 = add nuw nsw i16 %10, 1
  %31 = getelementptr inbounds nuw i8, ptr @ls_buf, i16 %30
  %32 = sub nsw i16 %8, %30
  tail call void @llvm.memmove.p0.p0.i16(ptr nonnull align 1 %29, ptr nonnull align 1 %31, i16 %32, i1 false)
  tail call void @llvm.memcpy.p0.p0.i16(ptr nonnull align 1 %13, ptr nonnull align 1 %18, i16 %23, i1 false)
  br label %6

33:                                               ; preds = %9
  %34 = add nuw nsw i8 %3, 1
  br label %2, !llvm.loop !9

35:                                               ; preds = %2, %22
  %36 = phi i16 [ %8, %22 ], [ %4, %2 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #6
  br label %37

37:                                               ; preds = %149, %35
  %38 = phi i16 [ 0, %35 ], [ %156, %149 ]
  %39 = phi i16 [ -1, %35 ], [ %150, %149 ]
  %40 = phi i8 [ 0, %35 ], [ %151, %149 ]
  %41 = phi i32 [ 17920, %35 ], [ %152, %149 ]
  %42 = phi i32 [ 31744, %35 ], [ %153, %149 ]
  %43 = phi i8 [ -64, %35 ], [ %154, %149 ]
  %44 = phi i8 [ 0, %35 ], [ %155, %149 ]
  %45 = icmp eq i16 %38, %36
  br i1 %45, label %157, label %46

46:                                               ; preds = %37
  %47 = getelementptr inbounds nuw i8, ptr @ls_buf, i16 %38
  %48 = load i8, ptr %47, align 1, !tbaa !6
  switch i8 %48, label %149 [
    i8 70, label %49
    i8 43, label %118
    i8 45, label %120
    i8 91, label %122
    i8 93, label %136
  ]

49:                                               ; preds = %46
  %50 = zext i8 %43 to i16
  %51 = add i8 %43, 64
  %52 = zext i8 %51 to i16
  %53 = getelementptr inbounds nuw [2 x i8], ptr @SINCOS, i16 %52
  %54 = load i16, ptr %53, align 1, !tbaa !2
  %55 = sext i16 %54 to i32
  %56 = mul nsw i32 %55, 38
  %57 = ashr i32 %56, 4
  %58 = add nsw i32 %57, %41
  %59 = getelementptr inbounds nuw [2 x i8], ptr @SINCOS, i16 %50
  %60 = load i16, ptr %59, align 1, !tbaa !2
  %61 = sext i16 %60 to i32
  %62 = mul nsw i32 %61, 38
  %63 = ashr i32 %62, 4
  %64 = add nsw i32 %63, %42
  %65 = ashr i32 %41, 8
  %66 = icmp slt i32 %65, 0
  br i1 %66, label %71, label %67

67:                                               ; preds = %49
  %68 = icmp samesign ugt i32 %65, 127
  %69 = trunc nuw nsw i32 %65 to i8
  br i1 %68, label %70, label %71

70:                                               ; preds = %67
  br label %71

71:                                               ; preds = %70, %67, %49
  %72 = phi i8 [ %69, %67 ], [ 127, %70 ], [ 0, %49 ]
  %73 = ashr i32 %42, 8
  %74 = icmp slt i32 %73, 0
  br i1 %74, label %79, label %75

75:                                               ; preds = %71
  %76 = icmp samesign ugt i32 %73, 127
  %77 = trunc nuw nsw i32 %73 to i8
  br i1 %76, label %78, label %79

78:                                               ; preds = %75
  br label %79

79:                                               ; preds = %78, %75, %71
  %80 = phi i8 [ %77, %75 ], [ 127, %78 ], [ 0, %71 ]
  %81 = ashr i32 %58, 8
  %82 = icmp slt i32 %81, 0
  br i1 %82, label %87, label %83

83:                                               ; preds = %79
  %84 = icmp samesign ugt i32 %81, 127
  %85 = trunc nuw nsw i32 %81 to i8
  br i1 %84, label %86, label %87

86:                                               ; preds = %83
  br label %87

87:                                               ; preds = %86, %83, %79
  %88 = phi i8 [ %85, %83 ], [ 127, %86 ], [ 0, %79 ]
  %89 = ashr i32 %64, 8
  %90 = icmp slt i32 %89, 0
  br i1 %90, label %95, label %91

91:                                               ; preds = %87
  %92 = icmp samesign ugt i32 %89, 127
  %93 = trunc nuw nsw i32 %89 to i8
  br i1 %92, label %94, label %95

94:                                               ; preds = %91
  br label %95

95:                                               ; preds = %94, %91, %87
  %96 = phi i8 [ %93, %91 ], [ 127, %94 ], [ 0, %87 ]
  %97 = icmp eq i8 %44, 0
  br i1 %97, label %101, label %98

98:                                               ; preds = %95
  %99 = icmp ult i8 %44, 3
  %100 = select i1 %99, i8 2, i8 3
  br label %101

101:                                              ; preds = %98, %95
  %102 = phi i8 [ %100, %98 ], [ 1, %95 ]
  %103 = tail call i16 @llvm.fshl.i16(i16 %39, i16 %39, i16 1)
  %104 = zext nneg i8 %72 to i16
  %105 = shl nuw nsw i16 %104, 8
  %106 = zext nneg i8 %80 to i16
  %107 = or disjoint i16 %105, %106
  %108 = xor i16 %107, %103
  %109 = tail call i16 @llvm.fshl.i16(i16 %108, i16 %108, i16 1)
  %110 = zext nneg i8 %88 to i16
  %111 = shl nuw nsw i16 %110, 8
  %112 = zext nneg i8 %96 to i16
  %113 = or disjoint i16 %111, %112
  %114 = xor i16 %113, %109
  %115 = tail call i16 @llvm.fshl.i16(i16 %114, i16 %114, i16 1)
  %116 = zext nneg i8 %102 to i16
  %117 = xor i16 %115, %116
  br label %149

118:                                              ; preds = %46
  %119 = add i8 %43, -18
  br label %149

120:                                              ; preds = %46
  %121 = add i8 %43, 18
  br label %149

122:                                              ; preds = %46
  %123 = icmp ult i8 %40, 24
  br i1 %123, label %124, label %131

124:                                              ; preds = %122
  %125 = zext nneg i8 %40 to i16
  %126 = add nuw nsw i8 %40, 1
  %127 = getelementptr inbounds nuw [10 x i8], ptr %1, i16 %125
  store i32 %41, ptr %127, align 1, !tbaa !10
  %128 = getelementptr inbounds nuw i8, ptr %127, i16 4
  store i32 %42, ptr %128, align 1, !tbaa !10
  %129 = getelementptr inbounds nuw i8, ptr %127, i16 8
  store i8 %43, ptr %129, align 1, !tbaa !6
  %130 = getelementptr inbounds nuw i8, ptr %127, i16 9
  store i8 %44, ptr %130, align 1, !tbaa !6
  br label %131

131:                                              ; preds = %124, %122
  %132 = phi i8 [ %126, %124 ], [ %40, %122 ]
  %133 = icmp eq i8 %44, -1
  br i1 %133, label %149, label %134

134:                                              ; preds = %131
  %135 = add nuw i8 %44, 1
  br label %149

136:                                              ; preds = %46
  %137 = icmp eq i8 %40, 0
  br i1 %137, label %149, label %138

138:                                              ; preds = %136
  %139 = add i8 %40, -1
  %140 = zext i8 %139 to i16
  %141 = getelementptr inbounds nuw [10 x i8], ptr %1, i16 %140
  %142 = load i32, ptr %141, align 1, !tbaa !10
  %143 = getelementptr inbounds nuw i8, ptr %141, i16 4
  %144 = load i32, ptr %143, align 1, !tbaa !10
  %145 = getelementptr inbounds nuw i8, ptr %141, i16 8
  %146 = load i8, ptr %145, align 1, !tbaa !6
  %147 = getelementptr inbounds nuw i8, ptr %141, i16 9
  %148 = load i8, ptr %147, align 1, !tbaa !6
  br label %149

149:                                              ; preds = %138, %136, %134, %131, %120, %118, %101, %46
  %150 = phi i16 [ %117, %101 ], [ %39, %118 ], [ %39, %120 ], [ %39, %134 ], [ %39, %131 ], [ %39, %138 ], [ %39, %136 ], [ %39, %46 ]
  %151 = phi i8 [ %40, %101 ], [ %40, %118 ], [ %40, %120 ], [ %132, %134 ], [ %132, %131 ], [ %139, %138 ], [ 0, %136 ], [ %40, %46 ]
  %152 = phi i32 [ %58, %101 ], [ %41, %118 ], [ %41, %120 ], [ %41, %134 ], [ %41, %131 ], [ %142, %138 ], [ %41, %136 ], [ %41, %46 ]
  %153 = phi i32 [ %64, %101 ], [ %42, %118 ], [ %42, %120 ], [ %42, %134 ], [ %42, %131 ], [ %144, %138 ], [ %42, %136 ], [ %42, %46 ]
  %154 = phi i8 [ %43, %101 ], [ %119, %118 ], [ %121, %120 ], [ %43, %134 ], [ %43, %131 ], [ %146, %138 ], [ %43, %136 ], [ %43, %46 ]
  %155 = phi i8 [ %44, %101 ], [ %44, %118 ], [ %44, %120 ], [ %135, %134 ], [ -1, %131 ], [ %148, %138 ], [ %44, %136 ], [ %44, %46 ]
  %156 = add i16 %38, 1
  br label %37, !llvm.loop !12

157:                                              ; preds = %37
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #6
  store volatile i16 %39, ptr @corpus_result, align 1, !tbaa !2
  br label %158

158:                                              ; preds = %158, %157
  tail call void asm sideeffect "", ""() #6, !srcloc !13
  br label %158
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: minsize mustprogress nocallback nofree nounwind optsize willreturn memory(argmem: read)
declare dso_local i16 @strlen(ptr noundef captures(none)) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i16(ptr writeonly captures(none), ptr readonly captures(none), i16, i1 immarg) #3

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #4

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { minsize mustprogress nocallback nofree nounwind optsize willreturn memory(argmem: read) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #3 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { minsize nounwind optsize }
attributes #6 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = distinct !{!9, !8}
!10 = !{!11, !11, i64 0}
!11 = !{!"long", !4, i64 0}
!12 = distinct !{!12, !8}
!13 = !{i64 945}
