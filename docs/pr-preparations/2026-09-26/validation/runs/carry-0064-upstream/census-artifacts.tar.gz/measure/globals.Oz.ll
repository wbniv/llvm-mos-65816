; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/globals.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/globals.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@data_vals = dso_local local_unnamed_addr global [4 x i16] [i16 4369, i16 8738, i16 13107, i16 17476], align 1
@data_byte = dso_local local_unnamed_addr global i8 -85, align 1
@one = dso_local global i8 1, align 1
@bss_vals = dso_local local_unnamed_addr global [8 x i16] zeroinitializer, align 1
@bss_byte = dso_local local_unnamed_addr global i8 0, align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %6, %0
  %2 = phi i8 [ %15, %6 ], [ 0, %0 ]
  %3 = phi i16 [ %13, %6 ], [ 0, %0 ]
  %4 = phi i8 [ %14, %6 ], [ 0, %0 ]
  %5 = icmp eq i8 %4, 4
  br i1 %5, label %16, label %6

6:                                                ; preds = %1
  %7 = zext nneg i8 %2 to i16
  %8 = getelementptr i8, ptr @data_vals, i16 %7
  %9 = load i16, ptr %8, align 1, !tbaa !2
  %10 = load volatile i8, ptr @one, align 1, !tbaa !6
  %11 = zext i8 %10 to i16
  %12 = mul i16 %9, %11
  %13 = add i16 %12, %3
  %14 = add nuw nsw i8 %4, 1
  %15 = add nuw nsw i8 %2, 2
  br label %1, !llvm.loop !7

16:                                               ; preds = %1
  %17 = load i8, ptr @data_byte, align 1, !tbaa !6
  %18 = load volatile i8, ptr @one, align 1, !tbaa !6
  br label %19

19:                                               ; preds = %24, %16
  %20 = phi i8 [ %30, %24 ], [ 0, %16 ]
  %21 = phi i8 [ %29, %24 ], [ 0, %16 ]
  %22 = phi i16 [ %28, %24 ], [ 0, %16 ]
  %23 = icmp eq i8 %21, 8
  br i1 %23, label %31, label %24

24:                                               ; preds = %19
  %25 = zext nneg i8 %20 to i16
  %26 = getelementptr i8, ptr @bss_vals, i16 %25
  %27 = load i16, ptr %26, align 1, !tbaa !2
  %28 = add i16 %27, %22
  %29 = add nuw nsw i8 %21, 1
  %30 = add nuw nsw i8 %20, 2
  br label %19, !llvm.loop !9

31:                                               ; preds = %19
  %32 = zext i8 %17 to i16
  %33 = zext i8 %18 to i16
  %34 = mul nuw nsw i16 %33, %32
  %35 = add i16 %34, %3
  %36 = load i8, ptr @bss_byte, align 1, !tbaa !6
  %37 = zext i8 %36 to i16
  %38 = sub nsw i16 0, %37
  %39 = icmp eq i16 %22, %38
  br i1 %39, label %42, label %40

40:                                               ; preds = %31
  %41 = add i16 %35, -4096
  br label %42

42:                                               ; preds = %40, %31
  %43 = phi i16 [ %41, %40 ], [ %35, %31 ]
  store volatile i16 %43, ptr @corpus_result, align 1, !tbaa !2
  br label %44

44:                                               ; preds = %44, %42
  tail call void asm sideeffect "", ""() #1, !srcloc !10
  br label %44
}

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = distinct !{!9, !8}
!10 = !{i64 1376}
