; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/rotkal_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/rotkal_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.RKState = type { [8 x i8], i16 }

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca %struct.RKState, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #4
  store i8 -93, ptr %1, align 1, !tbaa !6
  %2 = getelementptr inbounds nuw i8, ptr %1, i16 1
  store i8 92, ptr %2, align 1, !tbaa !6
  %3 = getelementptr inbounds nuw i8, ptr %1, i16 2
  store i8 -31, ptr %3, align 1, !tbaa !6
  %4 = getelementptr inbounds nuw i8, ptr %1, i16 3
  store i8 120, ptr %4, align 1, !tbaa !6
  %5 = getelementptr inbounds nuw i8, ptr %1, i16 4
  store i8 47, ptr %5, align 1, !tbaa !6
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 5
  store i8 -108, ptr %6, align 1, !tbaa !6
  %7 = getelementptr inbounds nuw i8, ptr %1, i16 6
  store i8 -73, ptr %7, align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 7
  store i8 29, ptr %8, align 1, !tbaa !6
  %9 = getelementptr inbounds nuw i8, ptr %1, i16 8
  store i16 -21555, ptr %9, align 1, !tbaa !7
  br label %10

10:                                               ; preds = %26, %0
  %11 = phi i16 [ 0, %0 ], [ %29, %26 ]
  %12 = phi i16 [ 0, %0 ], [ %30, %26 ]
  %13 = and i16 %12, 14
  %14 = or disjoint i16 %13, 1
  call fastcc void @rk_step(ptr noundef %1, i16 noundef %14) #5
  br label %15

15:                                               ; preds = %15, %10
  %16 = phi i8 [ 0, %10 ], [ %24, %15 ]
  %17 = phi i16 [ %11, %10 ], [ %23, %15 ]
  %18 = zext nneg i8 %16 to i16
  %19 = getelementptr i8, ptr %1, i16 %18
  %20 = load i8, ptr %19, align 1, !tbaa !6
  %21 = zext i8 %20 to i16
  %22 = tail call i16 @llvm.fshl.i16(i16 %17, i16 %17, i16 1)
  %23 = xor i16 %22, %21
  %24 = add nuw nsw i8 %16, 1
  %25 = icmp eq i8 %24, 8
  br i1 %25, label %26, label %15, !llvm.loop !9

26:                                               ; preds = %15
  %27 = load i16, ptr %9, align 1, !tbaa !7
  %28 = tail call i16 @llvm.fshl.i16(i16 %23, i16 %23, i16 1)
  %29 = xor i16 %27, %28
  %30 = add nuw nsw i16 %12, 1
  %31 = icmp eq i16 %30, 100
  br i1 %31, label %32, label %10, !llvm.loop !11

32:                                               ; preds = %26
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #4
  store volatile i16 %29, ptr @corpus_result, align 1, !tbaa !2
  br label %33

33:                                               ; preds = %33, %32
  tail call void asm sideeffect "", ""() #4, !srcloc !12
  br label %33
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal fastcc void @rk_step(ptr noundef nonnull captures(none) %0, i16 noundef range(i16 1, 16) %1) unnamed_addr #2 {
  %3 = load i8, ptr %0, align 1, !tbaa !6
  %4 = tail call i8 @llvm.fshl.i8(i8 %3, i8 %3, i8 1)
  store i8 %4, ptr %0, align 1, !tbaa !6
  %5 = getelementptr inbounds nuw i8, ptr %0, i16 1
  %6 = load i8, ptr %5, align 1, !tbaa !6
  %7 = tail call i8 @llvm.fshl.i8(i8 %6, i8 %6, i8 2)
  store i8 %7, ptr %5, align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %9 = load i8, ptr %8, align 1, !tbaa !6
  %10 = tail call i8 @llvm.fshl.i8(i8 %9, i8 %9, i8 3)
  store i8 %10, ptr %8, align 1, !tbaa !6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %12 = load i8, ptr %11, align 1, !tbaa !6
  %13 = tail call i8 @llvm.fshl.i8(i8 %12, i8 %12, i8 1)
  store i8 %13, ptr %11, align 1, !tbaa !6
  %14 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %15 = load i8, ptr %14, align 1, !tbaa !6
  %16 = tail call i8 @llvm.fshl.i8(i8 %15, i8 %15, i8 7)
  store i8 %16, ptr %14, align 1, !tbaa !6
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 5
  %18 = load i8, ptr %17, align 1, !tbaa !6
  %19 = tail call i8 @llvm.fshl.i8(i8 %18, i8 %18, i8 6)
  store i8 %19, ptr %17, align 1, !tbaa !6
  %20 = getelementptr inbounds nuw i8, ptr %0, i16 6
  %21 = load i8, ptr %20, align 1, !tbaa !6
  %22 = tail call i8 @llvm.fshl.i8(i8 %21, i8 %21, i8 5)
  store i8 %22, ptr %20, align 1, !tbaa !6
  %23 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %24 = load i8, ptr %23, align 1, !tbaa !6
  %25 = tail call i8 @llvm.fshl.i8(i8 %24, i8 %24, i8 7)
  store i8 %25, ptr %23, align 1, !tbaa !6
  %26 = getelementptr inbounds nuw i8, ptr %0, i16 8
  %27 = load i16, ptr %26, align 1, !tbaa !7
  %28 = tail call i16 @llvm.fshl.i16(i16 %27, i16 %27, i16 %1)
  store i16 %28, ptr %26, align 1, !tbaa !7
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fshl.i8(i8, i8, i8) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #3

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #3 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind }
attributes #5 = { optsize }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = !{!8, !3, i64 8}
!8 = !{!"", !4, i64 0, !3, i64 8}
!9 = distinct !{!9, !10}
!10 = !{!"llvm.loop.mustprogress"}
!11 = distinct !{!11, !10}
!12 = !{i64 560}
