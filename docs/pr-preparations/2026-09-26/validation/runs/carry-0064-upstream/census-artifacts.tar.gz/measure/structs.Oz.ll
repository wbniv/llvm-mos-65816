; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/structs.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/structs.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.point = type { i8, i16, i8 }

@bump = dso_local global i8 2, align 1
@pts = internal global [3 x %struct.point] [%struct.point { i8 1, i16 100, i8 7 }, %struct.point { i8 2, i16 200, i8 8 }, %struct.point { i8 3, i16 300, i8 9 }], align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %7, %0
  %2 = phi i8 [ %21, %7 ], [ 0, %0 ]
  %3 = phi i16 [ %18, %7 ], [ 0, %0 ]
  %4 = phi i8 [ %20, %7 ], [ 0, %0 ]
  %5 = phi ptr [ %19, %7 ], [ @pts, %0 ]
  %6 = icmp eq i8 %4, 3
  br i1 %6, label %22, label %7

7:                                                ; preds = %1
  %8 = load volatile i8, ptr %5, align 1, !tbaa !6
  %9 = zext i8 %8 to i16
  %10 = add i16 %3, %9
  %11 = zext nneg i8 %2 to i16
  %12 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 1), i16 %11
  %13 = load volatile i16, ptr %12, align 1, !tbaa !8
  %14 = add i16 %10, %13
  %15 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 3), i16 %11
  %16 = load volatile i8, ptr %15, align 1, !tbaa !9
  %17 = zext i8 %16 to i16
  %18 = add i16 %14, %17
  %19 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 4), i16 %11
  %20 = add nuw nsw i8 %4, 1
  %21 = add nuw nsw i8 %2, 4
  br label %1, !llvm.loop !10

22:                                               ; preds = %1
  %23 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !8
  %24 = load volatile i8, ptr @bump, align 1, !tbaa !12
  %25 = zext i8 %24 to i16
  %26 = add i16 %23, %25
  store volatile i16 %26, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !8
  %27 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !8
  %28 = add i16 %27, %3
  store volatile i16 %28, ptr @corpus_result, align 1, !tbaa !2
  br label %29

29:                                               ; preds = %29, %22
  tail call void asm sideeffect "", ""() #1, !srcloc !13
  br label %29
}

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !4, i64 0}
!7 = !{!"point", !4, i64 0, !3, i64 1, !4, i64 3}
!8 = !{!7, !3, i64 1}
!9 = !{!7, !4, i64 3}
!10 = distinct !{!10, !11}
!11 = !{!"llvm.loop.mustprogress"}
!12 = !{!4, !4, i64 0}
!13 = !{i64 1177}
