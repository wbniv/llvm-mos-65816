; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/cordic_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/cordic_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = tail call fastcc i16 @cordic_gate_crc() #5
  store volatile i16 %1, ptr @corpus_result, align 1, !tbaa !2
  br label %2

2:                                                ; preds = %2, %0
  tail call void asm sideeffect "", ""() #6, !srcloc !6
  br label %2
}

; Function Attrs: minsize nofree noinline norecurse nosync nounwind optsize memory(none)
define internal fastcc i16 @cordic_gate_crc() unnamed_addr #1 {
  %1 = alloca i16, align 1
  %2 = alloca i16, align 1
  %3 = alloca i16, align 1
  %4 = alloca i16, align 1
  br label %5

5:                                                ; preds = %223, %0
  %6 = phi i16 [ 0, %0 ], [ %40, %223 ]
  %7 = phi i8 [ 0, %0 ], [ %41, %223 ]
  %8 = phi i16 [ 0, %0 ], [ %243, %223 ]
  %9 = phi i16 [ 0, %0 ], [ %244, %223 ]
  %10 = icmp eq i16 %9, 96
  br i1 %10, label %11, label %12

11:                                               ; preds = %5
  ret i16 %8

12:                                               ; preds = %5
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #6
  call fastcc void @cordic16_sincos(i16 noundef %6, ptr noundef %3, ptr noundef %4) #5
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #6
  call fastcc void @cordic16_sincos(i16 noundef %6, ptr noundef %1, ptr noundef %2) #5
  %13 = and i8 %7, 3
  switch i8 %13, label %26 [
    i8 0, label %14
    i8 1, label %17
    i8 2, label %21
    i8 3, label %27
  ]

14:                                               ; preds = %12
  %15 = load i16, ptr %2, align 1, !tbaa !2
  %16 = load i16, ptr %1, align 1, !tbaa !2
  br label %31

17:                                               ; preds = %12
  %18 = load i16, ptr %1, align 1, !tbaa !2
  %19 = sub nsw i16 0, %18
  %20 = load i16, ptr %2, align 1, !tbaa !2
  br label %31

21:                                               ; preds = %12
  %22 = load i16, ptr %2, align 1, !tbaa !2
  %23 = sub nsw i16 0, %22
  %24 = load i16, ptr %1, align 1, !tbaa !2
  %25 = sub nsw i16 0, %24
  br label %31

26:                                               ; preds = %12
  unreachable

27:                                               ; preds = %12
  %28 = load i16, ptr %1, align 1, !tbaa !2
  %29 = load i16, ptr %2, align 1, !tbaa !2
  %30 = sub nsw i16 0, %29
  br label %31

31:                                               ; preds = %27, %21, %17, %14
  %32 = phi i16 [ %15, %14 ], [ %19, %17 ], [ %23, %21 ], [ %28, %27 ]
  %33 = phi i16 [ %16, %14 ], [ %20, %17 ], [ %25, %21 ], [ %30, %27 ]
  %34 = add nsw i16 %6, 1072
  %35 = icmp sgt i16 %6, 24663
  br i1 %35, label %36, label %39

36:                                               ; preds = %31
  %37 = add nsw i16 %6, -24664
  %38 = add i8 %7, 1
  br label %39

39:                                               ; preds = %31, %36
  %40 = phi i16 [ %37, %36 ], [ %34, %31 ]
  %41 = phi i8 [ %38, %36 ], [ %7, %31 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #6
  %42 = tail call i16 @llvm.fshl.i16(i16 %8, i16 %8, i16 1)
  %43 = xor i16 %33, %42
  %44 = tail call i16 @llvm.fshl.i16(i16 %43, i16 %43, i16 1)
  %45 = xor i16 %44, %32
  %46 = load i16, ptr %3, align 1, !tbaa !2
  %47 = load i16, ptr %4, align 1, !tbaa !2
  %48 = ashr i16 %47, 1
  %49 = ashr i16 %46, 1
  %50 = icmp slt i16 %49, 0
  br i1 %50, label %51, label %54

51:                                               ; preds = %39
  %52 = sub nsw i16 %48, %49
  %53 = add nsw i16 %48, %49
  br label %57

54:                                               ; preds = %39
  %55 = add nsw i16 %48, %49
  %56 = sub nsw i16 %49, %48
  br label %57

57:                                               ; preds = %54, %51
  %58 = phi i16 [ -12868, %51 ], [ 12868, %54 ]
  %59 = phi i16 [ %53, %51 ], [ %56, %54 ]
  %60 = phi i16 [ %52, %51 ], [ %55, %54 ]
  %61 = ashr i16 %60, 1
  %62 = ashr i16 %59, 1
  %63 = icmp slt i16 %59, 0
  br i1 %63, label %64, label %67

64:                                               ; preds = %57
  %65 = sub nsw i16 %60, %62
  %66 = add nsw i16 %61, %59
  br label %70

67:                                               ; preds = %57
  %68 = add nsw i16 %60, %62
  %69 = sub nsw i16 %59, %61
  br label %70

70:                                               ; preds = %67, %64
  %71 = phi i16 [ 7596, %67 ], [ -7596, %64 ]
  %72 = phi i16 [ %69, %67 ], [ %66, %64 ]
  %73 = phi i16 [ %68, %67 ], [ %65, %64 ]
  %74 = ashr i16 %73, 2
  %75 = ashr i16 %72, 2
  %76 = icmp slt i16 %72, 0
  br i1 %76, label %77, label %80

77:                                               ; preds = %70
  %78 = sub nsw i16 %73, %75
  %79 = add nsw i16 %74, %72
  br label %83

80:                                               ; preds = %70
  %81 = add nsw i16 %73, %75
  %82 = sub nsw i16 %72, %74
  br label %83

83:                                               ; preds = %80, %77
  %84 = phi i16 [ 4014, %80 ], [ -4014, %77 ]
  %85 = phi i16 [ %82, %80 ], [ %79, %77 ]
  %86 = phi i16 [ %81, %80 ], [ %78, %77 ]
  %87 = ashr i16 %86, 3
  %88 = ashr i16 %85, 3
  %89 = icmp slt i16 %85, 0
  br i1 %89, label %90, label %93

90:                                               ; preds = %83
  %91 = sub nsw i16 %86, %88
  %92 = add nsw i16 %87, %85
  br label %96

93:                                               ; preds = %83
  %94 = add nsw i16 %86, %88
  %95 = sub nsw i16 %85, %87
  br label %96

96:                                               ; preds = %93, %90
  %97 = phi i16 [ 2037, %93 ], [ -2037, %90 ]
  %98 = phi i16 [ %95, %93 ], [ %92, %90 ]
  %99 = phi i16 [ %94, %93 ], [ %91, %90 ]
  %100 = ashr i16 %99, 4
  %101 = ashr i16 %98, 4
  %102 = icmp slt i16 %98, 0
  br i1 %102, label %103, label %106

103:                                              ; preds = %96
  %104 = sub nsw i16 %99, %101
  %105 = add nsw i16 %100, %98
  br label %109

106:                                              ; preds = %96
  %107 = add nsw i16 %99, %101
  %108 = sub nsw i16 %98, %100
  br label %109

109:                                              ; preds = %106, %103
  %110 = phi i16 [ 1023, %106 ], [ -1023, %103 ]
  %111 = phi i16 [ %108, %106 ], [ %105, %103 ]
  %112 = phi i16 [ %107, %106 ], [ %104, %103 ]
  %113 = ashr i16 %112, 5
  %114 = ashr i16 %111, 5
  %115 = icmp slt i16 %111, 0
  br i1 %115, label %116, label %119

116:                                              ; preds = %109
  %117 = sub nsw i16 %112, %114
  %118 = add nsw i16 %113, %111
  br label %122

119:                                              ; preds = %109
  %120 = add nsw i16 %112, %114
  %121 = sub nsw i16 %111, %113
  br label %122

122:                                              ; preds = %119, %116
  %123 = phi i16 [ 512, %119 ], [ -512, %116 ]
  %124 = phi i16 [ %121, %119 ], [ %118, %116 ]
  %125 = phi i16 [ %120, %119 ], [ %117, %116 ]
  %126 = ashr i16 %125, 6
  %127 = ashr i16 %124, 6
  %128 = icmp slt i16 %124, 0
  br i1 %128, label %129, label %132

129:                                              ; preds = %122
  %130 = sub nsw i16 %125, %127
  %131 = add nsw i16 %126, %124
  br label %135

132:                                              ; preds = %122
  %133 = add nsw i16 %125, %127
  %134 = sub nsw i16 %124, %126
  br label %135

135:                                              ; preds = %132, %129
  %136 = phi i16 [ 256, %132 ], [ -256, %129 ]
  %137 = phi i16 [ %134, %132 ], [ %131, %129 ]
  %138 = phi i16 [ %133, %132 ], [ %130, %129 ]
  %139 = ashr i16 %138, 7
  %140 = ashr i16 %137, 7
  %141 = icmp slt i16 %137, 0
  br i1 %141, label %142, label %145

142:                                              ; preds = %135
  %143 = sub nsw i16 %138, %140
  %144 = add nsw i16 %139, %137
  br label %148

145:                                              ; preds = %135
  %146 = add nsw i16 %138, %140
  %147 = sub nsw i16 %137, %139
  br label %148

148:                                              ; preds = %145, %142
  %149 = phi i16 [ 128, %145 ], [ -128, %142 ]
  %150 = phi i16 [ %147, %145 ], [ %144, %142 ]
  %151 = phi i16 [ %146, %145 ], [ %143, %142 ]
  %152 = ashr i16 %151, 8
  %153 = ashr i16 %150, 8
  %154 = icmp slt i16 %150, 0
  br i1 %154, label %155, label %158

155:                                              ; preds = %148
  %156 = sub nsw i16 %151, %153
  %157 = add nsw i16 %152, %150
  br label %161

158:                                              ; preds = %148
  %159 = add nsw i16 %151, %153
  %160 = sub nsw i16 %150, %152
  br label %161

161:                                              ; preds = %158, %155
  %162 = phi i16 [ 64, %158 ], [ -64, %155 ]
  %163 = phi i16 [ %160, %158 ], [ %157, %155 ]
  %164 = phi i16 [ %159, %158 ], [ %156, %155 ]
  %165 = ashr i16 %164, 9
  %166 = ashr i16 %163, 9
  %167 = icmp slt i16 %163, 0
  br i1 %167, label %168, label %171

168:                                              ; preds = %161
  %169 = sub nsw i16 %164, %166
  %170 = add nsw i16 %165, %163
  br label %174

171:                                              ; preds = %161
  %172 = add nsw i16 %164, %166
  %173 = sub nsw i16 %163, %165
  br label %174

174:                                              ; preds = %171, %168
  %175 = phi i16 [ 32, %171 ], [ -32, %168 ]
  %176 = phi i16 [ %173, %171 ], [ %170, %168 ]
  %177 = phi i16 [ %172, %171 ], [ %169, %168 ]
  %178 = ashr i16 %177, 10
  %179 = ashr i16 %176, 10
  %180 = icmp slt i16 %176, 0
  br i1 %180, label %181, label %184

181:                                              ; preds = %174
  %182 = sub nsw i16 %177, %179
  %183 = add nsw i16 %178, %176
  br label %187

184:                                              ; preds = %174
  %185 = add nsw i16 %177, %179
  %186 = sub nsw i16 %176, %178
  br label %187

187:                                              ; preds = %184, %181
  %188 = phi i16 [ 16, %184 ], [ -16, %181 ]
  %189 = phi i16 [ %186, %184 ], [ %183, %181 ]
  %190 = phi i16 [ %185, %184 ], [ %182, %181 ]
  %191 = ashr i16 %190, 11
  %192 = ashr i16 %189, 11
  %193 = icmp slt i16 %189, 0
  br i1 %193, label %194, label %197

194:                                              ; preds = %187
  %195 = sub nsw i16 %190, %192
  %196 = add nsw i16 %191, %189
  br label %200

197:                                              ; preds = %187
  %198 = add nsw i16 %190, %192
  %199 = sub nsw i16 %189, %191
  br label %200

200:                                              ; preds = %197, %194
  %201 = phi i16 [ 8, %197 ], [ -8, %194 ]
  %202 = phi i16 [ %199, %197 ], [ %196, %194 ]
  %203 = phi i16 [ %198, %197 ], [ %195, %194 ]
  %204 = ashr i16 %203, 12
  %205 = ashr i16 %202, 12
  %206 = icmp slt i16 %202, 0
  br i1 %206, label %207, label %210

207:                                              ; preds = %200
  %208 = sub nsw i16 %203, %205
  %209 = add nsw i16 %204, %202
  br label %213

210:                                              ; preds = %200
  %211 = add nsw i16 %203, %205
  %212 = sub nsw i16 %202, %204
  br label %213

213:                                              ; preds = %210, %207
  %214 = phi i16 [ 4, %210 ], [ -4, %207 ]
  %215 = phi i16 [ %212, %210 ], [ %209, %207 ]
  %216 = phi i16 [ %211, %210 ], [ %208, %207 ]
  %217 = ashr i16 %216, 13
  %218 = icmp slt i16 %215, 0
  br i1 %218, label %219, label %221

219:                                              ; preds = %213
  %220 = add nsw i16 %217, %215
  br label %223

221:                                              ; preds = %213
  %222 = sub nsw i16 %215, %217
  br label %223

223:                                              ; preds = %219, %221
  %224 = phi i16 [ 2, %221 ], [ -2, %219 ]
  %225 = phi i16 [ %222, %221 ], [ %220, %219 ]
  %226 = add nsw i16 %71, %58
  %227 = add nsw i16 %226, %84
  %228 = add nsw i16 %227, %97
  %229 = add nsw i16 %228, %110
  %230 = add nsw i16 %229, %123
  %231 = add nsw i16 %230, %136
  %232 = add nsw i16 %231, %149
  %233 = add nsw i16 %232, %162
  %234 = add nsw i16 %233, %175
  %235 = add nsw i16 %234, %188
  %236 = add nsw i16 %235, %201
  %237 = add nsw i16 %236, %214
  %238 = add nsw i16 %237, %224
  %239 = icmp sgt i16 %225, -1
  %240 = select i1 %239, i16 1, i16 -1
  %241 = add nsw i16 %238, %240
  %242 = tail call i16 @llvm.fshl.i16(i16 %45, i16 %45, i16 1)
  %243 = xor i16 %241, %242
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #6
  %244 = add nuw nsw i16 %9, 1
  br label %5, !llvm.loop !7
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #2

; Function Attrs: inlinehint minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal fastcc void @cordic16_sincos(i16 noundef %0, ptr noundef nonnull writeonly captures(none) initializes((0, 2)) %1, ptr noundef nonnull writeonly captures(none) initializes((0, 2)) %2) unnamed_addr #3 {
  %4 = icmp sgt i16 %0, -1
  %5 = select i1 %4, i16 -12868, i16 12868
  %6 = select i1 %4, i16 9949, i16 -9949
  %7 = add nsw i16 %0, %5
  %8 = ashr i16 %6, 1
  %9 = icmp sgt i16 %7, -1
  br i1 %9, label %10, label %12

10:                                               ; preds = %3
  %11 = sub nsw i16 9949, %8
  br label %14

12:                                               ; preds = %3
  %13 = add nsw i16 %8, 9949
  br label %14

14:                                               ; preds = %12, %10
  %15 = phi i16 [ -4974, %12 ], [ 4974, %10 ]
  %16 = phi i16 [ 7596, %12 ], [ -7596, %10 ]
  %17 = phi i16 [ %13, %12 ], [ %11, %10 ]
  %18 = add nsw i16 %6, %15
  %19 = add nsw i16 %7, %16
  %20 = lshr i16 %17, 2
  %21 = ashr i16 %18, 2
  %22 = icmp sgt i16 %19, -1
  br i1 %22, label %23, label %26

23:                                               ; preds = %14
  %24 = sub nsw i16 %17, %21
  %25 = add nsw i16 %20, %18
  br label %29

26:                                               ; preds = %14
  %27 = add nsw i16 %17, %21
  %28 = sub nsw i16 %18, %20
  br label %29

29:                                               ; preds = %26, %23
  %30 = phi i16 [ 4014, %26 ], [ -4014, %23 ]
  %31 = phi i16 [ %28, %26 ], [ %25, %23 ]
  %32 = phi i16 [ %27, %26 ], [ %24, %23 ]
  %33 = add nsw i16 %19, %30
  %34 = lshr i16 %32, 3
  %35 = ashr i16 %31, 3
  %36 = icmp sgt i16 %33, -1
  br i1 %36, label %37, label %40

37:                                               ; preds = %29
  %38 = sub nsw i16 %32, %35
  %39 = add nsw i16 %34, %31
  br label %43

40:                                               ; preds = %29
  %41 = add nsw i16 %32, %35
  %42 = sub nsw i16 %31, %34
  br label %43

43:                                               ; preds = %40, %37
  %44 = phi i16 [ 2037, %40 ], [ -2037, %37 ]
  %45 = phi i16 [ %42, %40 ], [ %39, %37 ]
  %46 = phi i16 [ %41, %40 ], [ %38, %37 ]
  %47 = add nsw i16 %33, %44
  %48 = ashr i16 %46, 4
  %49 = ashr i16 %45, 4
  %50 = icmp sgt i16 %47, -1
  br i1 %50, label %51, label %54

51:                                               ; preds = %43
  %52 = sub nsw i16 %46, %49
  %53 = add nsw i16 %48, %45
  br label %57

54:                                               ; preds = %43
  %55 = add nsw i16 %46, %49
  %56 = sub nsw i16 %45, %48
  br label %57

57:                                               ; preds = %54, %51
  %58 = phi i16 [ 1023, %54 ], [ -1023, %51 ]
  %59 = phi i16 [ %56, %54 ], [ %53, %51 ]
  %60 = phi i16 [ %55, %54 ], [ %52, %51 ]
  %61 = add nsw i16 %47, %58
  %62 = ashr i16 %60, 5
  %63 = ashr i16 %59, 5
  %64 = icmp sgt i16 %61, -1
  br i1 %64, label %65, label %68

65:                                               ; preds = %57
  %66 = sub nsw i16 %60, %63
  %67 = add nsw i16 %62, %59
  br label %71

68:                                               ; preds = %57
  %69 = add nsw i16 %60, %63
  %70 = sub nsw i16 %59, %62
  br label %71

71:                                               ; preds = %68, %65
  %72 = phi i16 [ 512, %68 ], [ -512, %65 ]
  %73 = phi i16 [ %70, %68 ], [ %67, %65 ]
  %74 = phi i16 [ %69, %68 ], [ %66, %65 ]
  %75 = add nsw i16 %61, %72
  %76 = ashr i16 %74, 6
  %77 = ashr i16 %73, 6
  %78 = icmp sgt i16 %75, -1
  br i1 %78, label %79, label %82

79:                                               ; preds = %71
  %80 = sub nsw i16 %74, %77
  %81 = add nsw i16 %76, %73
  br label %85

82:                                               ; preds = %71
  %83 = add nsw i16 %74, %77
  %84 = sub nsw i16 %73, %76
  br label %85

85:                                               ; preds = %82, %79
  %86 = phi i16 [ 256, %82 ], [ -256, %79 ]
  %87 = phi i16 [ %84, %82 ], [ %81, %79 ]
  %88 = phi i16 [ %83, %82 ], [ %80, %79 ]
  %89 = add nsw i16 %75, %86
  %90 = ashr i16 %88, 7
  %91 = ashr i16 %87, 7
  %92 = icmp sgt i16 %89, -1
  br i1 %92, label %93, label %96

93:                                               ; preds = %85
  %94 = sub nsw i16 %88, %91
  %95 = add nsw i16 %90, %87
  br label %99

96:                                               ; preds = %85
  %97 = add nsw i16 %88, %91
  %98 = sub nsw i16 %87, %90
  br label %99

99:                                               ; preds = %96, %93
  %100 = phi i16 [ 128, %96 ], [ -128, %93 ]
  %101 = phi i16 [ %98, %96 ], [ %95, %93 ]
  %102 = phi i16 [ %97, %96 ], [ %94, %93 ]
  %103 = add nsw i16 %89, %100
  %104 = ashr i16 %102, 8
  %105 = ashr i16 %101, 8
  %106 = icmp sgt i16 %103, -1
  br i1 %106, label %107, label %110

107:                                              ; preds = %99
  %108 = sub nsw i16 %102, %105
  %109 = add nsw i16 %104, %101
  br label %113

110:                                              ; preds = %99
  %111 = add nsw i16 %102, %105
  %112 = sub nsw i16 %101, %104
  br label %113

113:                                              ; preds = %110, %107
  %114 = phi i16 [ 64, %110 ], [ -64, %107 ]
  %115 = phi i16 [ %112, %110 ], [ %109, %107 ]
  %116 = phi i16 [ %111, %110 ], [ %108, %107 ]
  %117 = add nsw i16 %103, %114
  %118 = ashr i16 %116, 9
  %119 = ashr i16 %115, 9
  %120 = icmp sgt i16 %117, -1
  br i1 %120, label %121, label %124

121:                                              ; preds = %113
  %122 = sub nsw i16 %116, %119
  %123 = add nsw i16 %118, %115
  br label %127

124:                                              ; preds = %113
  %125 = add nsw i16 %116, %119
  %126 = sub nsw i16 %115, %118
  br label %127

127:                                              ; preds = %124, %121
  %128 = phi i16 [ 32, %124 ], [ -32, %121 ]
  %129 = phi i16 [ %126, %124 ], [ %123, %121 ]
  %130 = phi i16 [ %125, %124 ], [ %122, %121 ]
  %131 = add nsw i16 %117, %128
  %132 = ashr i16 %130, 10
  %133 = ashr i16 %129, 10
  %134 = icmp sgt i16 %131, -1
  br i1 %134, label %135, label %138

135:                                              ; preds = %127
  %136 = sub nsw i16 %130, %133
  %137 = add nsw i16 %132, %129
  br label %141

138:                                              ; preds = %127
  %139 = add nsw i16 %130, %133
  %140 = sub nsw i16 %129, %132
  br label %141

141:                                              ; preds = %138, %135
  %142 = phi i16 [ 16, %138 ], [ -16, %135 ]
  %143 = phi i16 [ %140, %138 ], [ %137, %135 ]
  %144 = phi i16 [ %139, %138 ], [ %136, %135 ]
  %145 = add nsw i16 %131, %142
  %146 = ashr i16 %144, 11
  %147 = ashr i16 %143, 11
  %148 = icmp sgt i16 %145, -1
  br i1 %148, label %149, label %152

149:                                              ; preds = %141
  %150 = sub nsw i16 %144, %147
  %151 = add nsw i16 %146, %143
  br label %155

152:                                              ; preds = %141
  %153 = add nsw i16 %144, %147
  %154 = sub nsw i16 %143, %146
  br label %155

155:                                              ; preds = %152, %149
  %156 = phi i16 [ 8, %152 ], [ -8, %149 ]
  %157 = phi i16 [ %154, %152 ], [ %151, %149 ]
  %158 = phi i16 [ %153, %152 ], [ %150, %149 ]
  %159 = add nsw i16 %145, %156
  %160 = ashr i16 %158, 12
  %161 = ashr i16 %157, 12
  %162 = icmp sgt i16 %159, -1
  br i1 %162, label %163, label %166

163:                                              ; preds = %155
  %164 = sub nsw i16 %158, %161
  %165 = add nsw i16 %160, %157
  br label %169

166:                                              ; preds = %155
  %167 = add nsw i16 %158, %161
  %168 = sub nsw i16 %157, %160
  br label %169

169:                                              ; preds = %166, %163
  %170 = phi i16 [ 4, %166 ], [ -4, %163 ]
  %171 = phi i16 [ %168, %166 ], [ %165, %163 ]
  %172 = phi i16 [ %167, %166 ], [ %164, %163 ]
  %173 = add nsw i16 %159, %170
  %174 = ashr i16 %172, 13
  %175 = ashr i16 %171, 13
  %176 = icmp sgt i16 %173, -1
  br i1 %176, label %177, label %180

177:                                              ; preds = %169
  %178 = sub nsw i16 %172, %175
  %179 = add nsw i16 %174, %171
  br label %183

180:                                              ; preds = %169
  %181 = add nsw i16 %172, %175
  %182 = sub nsw i16 %171, %174
  br label %183

183:                                              ; preds = %180, %177
  %184 = phi i16 [ 2, %180 ], [ -2, %177 ]
  %185 = phi i16 [ %182, %180 ], [ %179, %177 ]
  %186 = phi i16 [ %181, %180 ], [ %178, %177 ]
  %187 = add nsw i16 %173, %184
  %188 = ashr i16 %186, 14
  %189 = ashr i16 %185, 14
  %190 = icmp sgt i16 %187, -1
  br i1 %190, label %191, label %194

191:                                              ; preds = %183
  %192 = sub nsw i16 %186, %189
  %193 = add nsw i16 %188, %185
  br label %197

194:                                              ; preds = %183
  %195 = add nsw i16 %186, %189
  %196 = sub nsw i16 %185, %188
  br label %197

197:                                              ; preds = %194, %191
  %198 = phi i16 [ %193, %191 ], [ %196, %194 ]
  %199 = phi i16 [ %192, %191 ], [ %195, %194 ]
  store i16 %199, ptr %2, align 1, !tbaa !2
  store i16 %198, ptr %1, align 1, !tbaa !2
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #4

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { minsize nofree noinline norecurse nosync nounwind optsize memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { inlinehint minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { minsize optsize }
attributes #6 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{i64 900}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
