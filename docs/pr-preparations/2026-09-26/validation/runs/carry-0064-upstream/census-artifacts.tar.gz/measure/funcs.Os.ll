; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/funcs.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/funcs.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@fn = dso_local global i8 12, align 1
@a = dso_local global i16 30, align 1
@b = dso_local global i16 12, align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = load volatile i8, ptr @fn, align 1, !tbaa !6
  %2 = tail call fastcc i16 @fib(i8 noundef zeroext %1) #2
  %3 = load volatile i16, ptr @a, align 1, !tbaa !2
  %4 = load volatile i16, ptr @b, align 1, !tbaa !2
  %5 = add i16 %2, 100
  %6 = add i16 %5, %3
  %7 = add i16 %6, %4
  store volatile i16 %7, ptr @corpus_result, align 1, !tbaa !2
  br label %8

8:                                                ; preds = %8, %0
  tail call void asm sideeffect "", ""() #3, !srcloc !7
  br label %8
}

; Function Attrs: nofree nosync nounwind optsize memory(none)
define internal fastcc i16 @fib(i8 noundef zeroext %0) unnamed_addr #1 {
  %2 = icmp ult i8 %0, 2
  br i1 %2, label %3, label %8

3:                                                ; preds = %8, %1
  %4 = phi i16 [ 0, %1 ], [ %14, %8 ]
  %5 = phi i8 [ %0, %1 ], [ %13, %8 ]
  %6 = zext nneg i8 %5 to i16
  %7 = add i16 %4, %6
  ret i16 %7

8:                                                ; preds = %1, %8
  %9 = phi i8 [ %13, %8 ], [ %0, %1 ]
  %10 = phi i16 [ %14, %8 ], [ 0, %1 ]
  %11 = add i8 %9, -1
  %12 = tail call fastcc i16 @fib(i8 noundef zeroext %11) #2
  %13 = add i8 %9, -2
  %14 = add i16 %12, %10
  %15 = icmp ult i8 %13, 2
  br i1 %15, label %3, label %8
}

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nofree nosync nounwind optsize memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #2 = { optsize }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = !{i64 902}
