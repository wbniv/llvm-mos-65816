; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/ovmatrix_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/ovmatrix_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1
@ov_fire = internal unnamed_addr global [18 x i16] zeroinitializer, align 1
@ov_clean = internal unnamed_addr global [18 x i16] zeroinitializer, align 1
@ov_res = internal unnamed_addr global [18 x i32] zeroinitializer, align 1
@ov_u16 = internal unnamed_addr global i16 0, align 1
@ov_i16 = internal unnamed_addr global i16 0, align 1
@ov_u32 = internal unnamed_addr global i32 0, align 1
@ov_i32 = internal unnamed_addr global i32 0, align 1
@ov_u64 = internal unnamed_addr global i64 0, align 8
@ov_i64 = internal unnamed_addr global i64 0, align 8

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %6, %0
  %2 = phi i8 [ %14, %6 ], [ 0, %0 ]
  %3 = phi i8 [ %13, %6 ], [ 0, %0 ]
  %4 = phi i8 [ %12, %6 ], [ 0, %0 ]
  %5 = icmp eq i8 %4, 18
  br i1 %5, label %15, label %6

6:                                                ; preds = %1
  %7 = zext nneg i8 %3 to i16
  %8 = getelementptr i8, ptr @ov_fire, i16 %7
  store i16 0, ptr %8, align 1, !tbaa !2
  %9 = getelementptr i8, ptr @ov_clean, i16 %7
  store i16 0, ptr %9, align 1, !tbaa !2
  %10 = zext nneg i8 %2 to i16
  %11 = getelementptr i8, ptr @ov_res, i16 %10
  store i32 0, ptr %11, align 1, !tbaa !6
  %12 = add nuw nsw i8 %4, 1
  %13 = add nuw nsw i8 %3, 2
  %14 = add nuw nsw i8 %2, 4
  br label %1, !llvm.loop !8

15:                                               ; preds = %1
  store i16 4951, ptr @ov_u16, align 1, !tbaa !2
  store i16 9320, ptr @ov_i16, align 1, !tbaa !2
  store i32 -1985229329, ptr @ov_u32, align 1, !tbaa !6
  store i32 305419896, ptr @ov_i32, align 1, !tbaa !6
  store i64 81985529216486895, ptr @ov_u64, align 8, !tbaa !10
  store i64 1147797409030816545, ptr @ov_i64, align 8, !tbaa !10
  br label %16

16:                                               ; preds = %20, %15
  %17 = phi i16 [ -25029, %15 ], [ %22, %20 ]
  %18 = phi i16 [ 0, %15 ], [ %23, %20 ]
  %19 = icmp eq i16 %18, 96
  br i1 %19, label %24, label %20

20:                                               ; preds = %16
  %21 = mul i16 %17, 25173
  %22 = add i16 %21, 13849
  tail call fastcc void @ov_kernel(i16 noundef %22) #5
  %23 = add nuw nsw i16 %18, 1
  br label %16, !llvm.loop !12

24:                                               ; preds = %16, %30
  %25 = phi i8 [ %50, %30 ], [ 0, %16 ]
  %26 = phi i8 [ %49, %30 ], [ 0, %16 ]
  %27 = phi i16 [ %47, %30 ], [ 31822, %16 ]
  %28 = phi i8 [ %48, %30 ], [ 0, %16 ]
  %29 = icmp eq i8 %28, 18
  br i1 %29, label %51, label %30

30:                                               ; preds = %24
  %31 = zext nneg i8 %26 to i16
  %32 = getelementptr i8, ptr @ov_fire, i16 %31
  %33 = load i16, ptr %32, align 1, !tbaa !2
  %34 = xor i16 %33, %27
  %35 = tail call i16 @llvm.fshl.i16(i16 %34, i16 %34, i16 1)
  %36 = mul i16 %35, 25173
  %37 = add i16 %36, 13849
  %38 = getelementptr i8, ptr @ov_clean, i16 %31
  %39 = load i16, ptr %38, align 1, !tbaa !2
  %40 = xor i16 %37, %39
  %41 = tail call i16 @llvm.fshl.i16(i16 %40, i16 %40, i16 1)
  %42 = mul i16 %41, 25173
  %43 = add i16 %42, 13849
  %44 = zext nneg i8 %25 to i16
  %45 = getelementptr i8, ptr @ov_res, i16 %44
  %46 = load i32, ptr %45, align 1, !tbaa !6
  %47 = tail call fastcc i16 @ov_mix32(i16 noundef %43, i32 noundef %46) #5
  %48 = add nuw nsw i8 %28, 1
  %49 = add nuw nsw i8 %26, 2
  %50 = add nuw nsw i8 %25, 4
  br label %24, !llvm.loop !13

51:                                               ; preds = %24
  %52 = load i16, ptr @ov_u16, align 1, !tbaa !2
  %53 = xor i16 %52, %27
  %54 = tail call i16 @llvm.fshl.i16(i16 %53, i16 %53, i16 1)
  %55 = mul i16 %54, 25173
  %56 = add i16 %55, 13849
  %57 = load i16, ptr @ov_i16, align 1, !tbaa !2
  %58 = xor i16 %56, %57
  %59 = tail call i16 @llvm.fshl.i16(i16 %58, i16 %58, i16 1)
  %60 = mul i16 %59, 25173
  %61 = add i16 %60, 13849
  %62 = load i32, ptr @ov_u32, align 1, !tbaa !6
  %63 = tail call fastcc i16 @ov_mix32(i16 noundef %61, i32 noundef %62) #5
  %64 = load i32, ptr @ov_i32, align 1, !tbaa !6
  %65 = tail call fastcc i16 @ov_mix32(i16 noundef %63, i32 noundef %64) #5
  %66 = load i64, ptr @ov_u64, align 8, !tbaa !10
  %67 = tail call fastcc i16 @ov_mix64(i16 noundef %65, i64 noundef %66) #5
  %68 = load i64, ptr @ov_i64, align 8, !tbaa !10
  %69 = tail call fastcc i16 @ov_mix64(i16 noundef %67, i64 noundef %68) #5
  store volatile i16 %69, ptr @corpus_result, align 1, !tbaa !2
  br label %70

70:                                               ; preds = %70, %51
  tail call void asm sideeffect "", ""() #6, !srcloc !14
  br label %70
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define internal fastcc i16 @ov_mix32(i16 noundef %0, i32 noundef %1) unnamed_addr #1 {
  %3 = trunc i32 %1 to i16
  %4 = xor i16 %0, %3
  %5 = tail call i16 @llvm.fshl.i16(i16 %4, i16 %4, i16 1)
  %6 = mul i16 %5, 25173
  %7 = add i16 %6, 13849
  %8 = lshr i32 %1, 16
  %9 = trunc nuw i32 %8 to i16
  %10 = xor i16 %7, %9
  %11 = tail call i16 @llvm.fshl.i16(i16 %10, i16 %10, i16 1)
  %12 = mul i16 %11, 25173
  %13 = add i16 %12, 13849
  ret i16 %13
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define internal fastcc i16 @ov_mix64(i16 noundef %0, i64 noundef %1) unnamed_addr #1 {
  %3 = trunc i64 %1 to i32
  %4 = tail call fastcc i16 @ov_mix32(i16 noundef %0, i32 noundef %3) #5
  %5 = lshr i64 %1, 32
  %6 = trunc nuw i64 %5 to i32
  %7 = tail call fastcc i16 @ov_mix32(i16 noundef %4, i32 noundef %6) #5
  ret i16 %7
}

; Function Attrs: minsize mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @ov_kernel(i16 noundef %0) unnamed_addr #2 {
  %2 = and i16 %0, 511
  %3 = add nuw nsw i16 %2, 1
  %4 = lshr i16 %0, 5
  %5 = and i16 %4, 1023
  %6 = load i16, ptr @ov_u16, align 1, !tbaa !2
  %7 = shl nuw i16 %5, 6
  %8 = xor i16 %7, -1
  %9 = tail call { i16, i1 } @llvm.uadd.with.overflow.i16(i16 %6, i16 %8)
  %10 = extractvalue { i16, i1 } %9, 1
  %11 = extractvalue { i16, i1 } %9, 0
  %12 = select i1 %10, ptr @ov_fire, ptr @ov_clean
  %13 = load i16, ptr %12, align 1, !tbaa !2
  %14 = add i16 %13, 1
  store i16 %14, ptr %12, align 1, !tbaa !2
  %15 = load i32, ptr @ov_res, align 1, !tbaa !6
  %16 = mul i32 %15, 3
  %17 = zext i16 %11 to i32
  %18 = add i32 %16, %17
  store i32 %18, ptr @ov_res, align 1, !tbaa !6
  store i16 %11, ptr @ov_u16, align 1, !tbaa !2
  %19 = load i16, ptr @ov_i16, align 1, !tbaa !2
  %20 = or i16 %19, 1
  %21 = xor i16 %5, 32767
  %22 = tail call { i16, i1 } @llvm.sadd.with.overflow.i16(i16 %20, i16 %21)
  %23 = extractvalue { i16, i1 } %22, 1
  %24 = extractvalue { i16, i1 } %22, 0
  br i1 %23, label %25, label %28

25:                                               ; preds = %1
  %26 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 2), align 1, !tbaa !2
  %27 = add i16 %26, 1
  store i16 %27, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 2), align 1, !tbaa !2
  br label %31

28:                                               ; preds = %1
  %29 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 2), align 1, !tbaa !2
  %30 = add i16 %29, 1
  store i16 %30, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 2), align 1, !tbaa !2
  br label %31

31:                                               ; preds = %28, %25
  %32 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 4), align 1, !tbaa !6
  %33 = mul i32 %32, 3
  %34 = sext i16 %24 to i32
  %35 = add i32 %33, %34
  store i32 %35, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 4), align 1, !tbaa !6
  store i16 %24, ptr @ov_i16, align 1, !tbaa !2
  %36 = load i32, ptr @ov_u32, align 1, !tbaa !6
  %37 = zext nneg i16 %5 to i32
  %38 = shl nuw i32 %37, 22
  %39 = xor i32 %38, -1
  %40 = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %36, i32 %39)
  %41 = extractvalue { i32, i1 } %40, 1
  %42 = extractvalue { i32, i1 } %40, 0
  br i1 %41, label %43, label %46

43:                                               ; preds = %31
  %44 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 4), align 1, !tbaa !2
  %45 = add i16 %44, 1
  store i16 %45, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 4), align 1, !tbaa !2
  br label %49

46:                                               ; preds = %31
  %47 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 4), align 1, !tbaa !2
  %48 = add i16 %47, 1
  store i16 %48, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 4), align 1, !tbaa !2
  br label %49

49:                                               ; preds = %46, %43
  %50 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 8), align 1, !tbaa !6
  %51 = mul i32 %50, 3
  %52 = add i32 %51, %42
  store i32 %52, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 8), align 1, !tbaa !6
  store i32 %42, ptr @ov_u32, align 1, !tbaa !6
  %53 = load i32, ptr @ov_i32, align 1, !tbaa !6
  %54 = or i32 %53, 1
  %55 = shl nuw nsw i32 %37, 16
  %56 = xor i32 %55, 2147483647
  %57 = tail call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %54, i32 %56)
  %58 = extractvalue { i32, i1 } %57, 1
  %59 = extractvalue { i32, i1 } %57, 0
  br i1 %58, label %60, label %63

60:                                               ; preds = %49
  %61 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 6), align 1, !tbaa !2
  %62 = add i16 %61, 1
  store i16 %62, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 6), align 1, !tbaa !2
  br label %66

63:                                               ; preds = %49
  %64 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 6), align 1, !tbaa !2
  %65 = add i16 %64, 1
  store i16 %65, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 6), align 1, !tbaa !2
  br label %66

66:                                               ; preds = %63, %60
  %67 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 12), align 1, !tbaa !6
  %68 = mul i32 %67, 3
  %69 = add i32 %68, %59
  store i32 %69, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 12), align 1, !tbaa !6
  store i32 %59, ptr @ov_i32, align 1, !tbaa !6
  %70 = load i64, ptr @ov_u64, align 8, !tbaa !10
  %71 = zext nneg i16 %5 to i64
  %72 = shl nuw i64 %71, 54
  %73 = xor i64 %72, -1
  %74 = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %70, i64 %73)
  %75 = extractvalue { i64, i1 } %74, 1
  %76 = extractvalue { i64, i1 } %74, 0
  br i1 %75, label %77, label %80

77:                                               ; preds = %66
  %78 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 8), align 1, !tbaa !2
  %79 = add i16 %78, 1
  store i16 %79, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 8), align 1, !tbaa !2
  br label %83

80:                                               ; preds = %66
  %81 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 8), align 1, !tbaa !2
  %82 = add i16 %81, 1
  store i16 %82, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 8), align 1, !tbaa !2
  br label %83

83:                                               ; preds = %80, %77
  %84 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 16), align 1, !tbaa !6
  %85 = mul i32 %84, 3
  %86 = trunc i64 %76 to i32
  %87 = add i32 %85, %86
  store i32 %87, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 16), align 1, !tbaa !6
  store i64 %76, ptr @ov_u64, align 8, !tbaa !10
  %88 = load i64, ptr @ov_i64, align 8, !tbaa !10
  %89 = or i64 %88, 1
  %90 = shl nuw nsw i64 %71, 48
  %91 = xor i64 %90, 9223372036854775807
  %92 = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %89, i64 %91)
  %93 = extractvalue { i64, i1 } %92, 1
  %94 = extractvalue { i64, i1 } %92, 0
  br i1 %93, label %95, label %98

95:                                               ; preds = %83
  %96 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 10), align 1, !tbaa !2
  %97 = add i16 %96, 1
  store i16 %97, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 10), align 1, !tbaa !2
  br label %101

98:                                               ; preds = %83
  %99 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 10), align 1, !tbaa !2
  %100 = add i16 %99, 1
  store i16 %100, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 10), align 1, !tbaa !2
  br label %101

101:                                              ; preds = %98, %95
  %102 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 20), align 1, !tbaa !6
  %103 = mul i32 %102, 3
  %104 = trunc i64 %94 to i32
  %105 = add i32 %103, %104
  store i32 %105, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 20), align 1, !tbaa !6
  store i64 %94, ptr @ov_i64, align 8, !tbaa !10
  %106 = xor i16 %11, %3
  %107 = tail call { i16, i1 } @llvm.usub.with.overflow.i16(i16 %106, i16 %7)
  %108 = extractvalue { i16, i1 } %107, 1
  %109 = extractvalue { i16, i1 } %107, 0
  br i1 %108, label %110, label %113

110:                                              ; preds = %101
  %111 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 12), align 1, !tbaa !2
  %112 = add i16 %111, 1
  store i16 %112, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 12), align 1, !tbaa !2
  br label %116

113:                                              ; preds = %101
  %114 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 12), align 1, !tbaa !2
  %115 = add i16 %114, 1
  store i16 %115, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 12), align 1, !tbaa !2
  br label %116

116:                                              ; preds = %113, %110
  %117 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 24), align 1, !tbaa !6
  %118 = mul i32 %117, 3
  %119 = zext i16 %109 to i32
  %120 = add i32 %118, %119
  store i32 %120, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 24), align 1, !tbaa !6
  store i16 %109, ptr @ov_u16, align 1, !tbaa !2
  %121 = or i16 %24, 1
  %122 = or disjoint i16 %5, -32768
  %123 = tail call { i16, i1 } @llvm.ssub.with.overflow.i16(i16 %121, i16 %122)
  %124 = extractvalue { i16, i1 } %123, 1
  %125 = extractvalue { i16, i1 } %123, 0
  br i1 %124, label %126, label %129

126:                                              ; preds = %116
  %127 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 14), align 1, !tbaa !2
  %128 = add i16 %127, 1
  store i16 %128, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 14), align 1, !tbaa !2
  br label %132

129:                                              ; preds = %116
  %130 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 14), align 1, !tbaa !2
  %131 = add i16 %130, 1
  store i16 %131, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 14), align 1, !tbaa !2
  br label %132

132:                                              ; preds = %129, %126
  %133 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 28), align 1, !tbaa !6
  %134 = mul i32 %133, 3
  %135 = sext i16 %125 to i32
  %136 = add i32 %134, %135
  store i32 %136, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 28), align 1, !tbaa !6
  store i16 %125, ptr @ov_i16, align 1, !tbaa !2
  %137 = zext nneg i16 %3 to i32
  %138 = xor i32 %42, %137
  %139 = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %138, i32 %38)
  %140 = extractvalue { i32, i1 } %139, 1
  %141 = extractvalue { i32, i1 } %139, 0
  br i1 %140, label %142, label %145

142:                                              ; preds = %132
  %143 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 16), align 1, !tbaa !2
  %144 = add i16 %143, 1
  store i16 %144, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 16), align 1, !tbaa !2
  br label %148

145:                                              ; preds = %132
  %146 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 16), align 1, !tbaa !2
  %147 = add i16 %146, 1
  store i16 %147, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 16), align 1, !tbaa !2
  br label %148

148:                                              ; preds = %145, %142
  %149 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 32), align 1, !tbaa !6
  %150 = mul i32 %149, 3
  %151 = add i32 %150, %141
  store i32 %151, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 32), align 1, !tbaa !6
  store i32 %141, ptr @ov_u32, align 1, !tbaa !6
  %152 = or disjoint i32 %59, 1
  %153 = or disjoint i32 %55, -2147483648
  %154 = tail call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %152, i32 %153)
  %155 = extractvalue { i32, i1 } %154, 1
  %156 = extractvalue { i32, i1 } %154, 0
  br i1 %155, label %157, label %160

157:                                              ; preds = %148
  %158 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 18), align 1, !tbaa !2
  %159 = add i16 %158, 1
  store i16 %159, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 18), align 1, !tbaa !2
  br label %163

160:                                              ; preds = %148
  %161 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 18), align 1, !tbaa !2
  %162 = add i16 %161, 1
  store i16 %162, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 18), align 1, !tbaa !2
  br label %163

163:                                              ; preds = %160, %157
  %164 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 36), align 1, !tbaa !6
  %165 = mul i32 %164, 3
  %166 = add i32 %165, %156
  store i32 %166, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 36), align 1, !tbaa !6
  store i32 %156, ptr @ov_i32, align 1, !tbaa !6
  %167 = zext nneg i16 %3 to i64
  %168 = xor i64 %76, %167
  %169 = tail call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %168, i64 %72)
  %170 = extractvalue { i64, i1 } %169, 1
  %171 = extractvalue { i64, i1 } %169, 0
  br i1 %170, label %172, label %175

172:                                              ; preds = %163
  %173 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 20), align 1, !tbaa !2
  %174 = add i16 %173, 1
  store i16 %174, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 20), align 1, !tbaa !2
  br label %178

175:                                              ; preds = %163
  %176 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 20), align 1, !tbaa !2
  %177 = add i16 %176, 1
  store i16 %177, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 20), align 1, !tbaa !2
  br label %178

178:                                              ; preds = %175, %172
  %179 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 40), align 1, !tbaa !6
  %180 = mul i32 %179, 3
  %181 = trunc i64 %171 to i32
  %182 = add i32 %180, %181
  store i32 %182, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 40), align 1, !tbaa !6
  store i64 %171, ptr @ov_u64, align 8, !tbaa !10
  %183 = or disjoint i64 %94, 1
  %184 = or disjoint i64 %90, -9223372036854775808
  %185 = tail call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %183, i64 %184)
  %186 = extractvalue { i64, i1 } %185, 1
  %187 = extractvalue { i64, i1 } %185, 0
  br i1 %186, label %188, label %191

188:                                              ; preds = %178
  %189 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 22), align 1, !tbaa !2
  %190 = add i16 %189, 1
  store i16 %190, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 22), align 1, !tbaa !2
  br label %194

191:                                              ; preds = %178
  %192 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 22), align 1, !tbaa !2
  %193 = add i16 %192, 1
  store i16 %193, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 22), align 1, !tbaa !2
  br label %194

194:                                              ; preds = %191, %188
  %195 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 44), align 1, !tbaa !6
  %196 = mul i32 %195, 3
  %197 = trunc i64 %187 to i32
  %198 = add i32 %196, %197
  store i32 %198, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 44), align 1, !tbaa !6
  store i64 %187, ptr @ov_i64, align 8, !tbaa !10
  %199 = and i16 %109, 1022
  %200 = or disjoint i16 %199, 1
  %201 = or i16 %3, 1
  %202 = tail call { i16, i1 } @llvm.umul.with.overflow.i16(i16 %200, i16 %201)
  %203 = extractvalue { i16, i1 } %202, 1
  %204 = extractvalue { i16, i1 } %202, 0
  br i1 %203, label %205, label %208

205:                                              ; preds = %194
  %206 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 24), align 1, !tbaa !2
  %207 = add i16 %206, 1
  store i16 %207, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 24), align 1, !tbaa !2
  br label %211

208:                                              ; preds = %194
  %209 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 24), align 1, !tbaa !2
  %210 = add i16 %209, 1
  store i16 %210, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 24), align 1, !tbaa !2
  br label %211

211:                                              ; preds = %208, %205
  %212 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 48), align 1, !tbaa !6
  %213 = mul i32 %212, 3
  %214 = zext i16 %204 to i32
  %215 = add i32 %213, %214
  store i32 %215, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 48), align 1, !tbaa !6
  store i16 %204, ptr @ov_u16, align 1, !tbaa !2
  %216 = and i16 %125, 1022
  %217 = or disjoint i16 %216, 1
  %218 = add nsw i16 %201, -256
  %219 = tail call { i16, i1 } @llvm.smul.with.overflow.i16(i16 %217, i16 %218)
  %220 = extractvalue { i16, i1 } %219, 1
  %221 = extractvalue { i16, i1 } %219, 0
  br i1 %220, label %222, label %225

222:                                              ; preds = %211
  %223 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 26), align 1, !tbaa !2
  %224 = add i16 %223, 1
  store i16 %224, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 26), align 1, !tbaa !2
  br label %228

225:                                              ; preds = %211
  %226 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 26), align 1, !tbaa !2
  %227 = add i16 %226, 1
  store i16 %227, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 26), align 1, !tbaa !2
  br label %228

228:                                              ; preds = %225, %222
  %229 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 52), align 1, !tbaa !6
  %230 = mul i32 %229, 3
  %231 = sext i16 %221 to i32
  %232 = add i32 %230, %231
  store i32 %232, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 52), align 1, !tbaa !6
  store i16 %221, ptr @ov_i16, align 1, !tbaa !2
  %233 = and i32 %141, 67108862
  %234 = or disjoint i32 %233, 1
  %235 = zext nneg i16 %201 to i32
  %236 = tail call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %234, i32 %235)
  %237 = extractvalue { i32, i1 } %236, 1
  %238 = extractvalue { i32, i1 } %236, 0
  br i1 %237, label %239, label %242

239:                                              ; preds = %228
  %240 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 28), align 1, !tbaa !2
  %241 = add i16 %240, 1
  store i16 %241, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 28), align 1, !tbaa !2
  br label %245

242:                                              ; preds = %228
  %243 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 28), align 1, !tbaa !2
  %244 = add i16 %243, 1
  store i16 %244, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 28), align 1, !tbaa !2
  br label %245

245:                                              ; preds = %242, %239
  %246 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 56), align 1, !tbaa !6
  %247 = mul i32 %246, 3
  %248 = add i32 %247, %238
  store i32 %248, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 56), align 1, !tbaa !6
  store i32 %238, ptr @ov_u32, align 1, !tbaa !6
  %249 = and i32 %156, 67108863
  %250 = add nsw i32 %235, -256
  %251 = tail call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %249, i32 %250)
  %252 = extractvalue { i32, i1 } %251, 1
  %253 = extractvalue { i32, i1 } %251, 0
  br i1 %252, label %254, label %257

254:                                              ; preds = %245
  %255 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 30), align 1, !tbaa !2
  %256 = add i16 %255, 1
  store i16 %256, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 30), align 1, !tbaa !2
  br label %260

257:                                              ; preds = %245
  %258 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 30), align 1, !tbaa !2
  %259 = add i16 %258, 1
  store i16 %259, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 30), align 1, !tbaa !2
  br label %260

260:                                              ; preds = %257, %254
  %261 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 60), align 1, !tbaa !6
  %262 = mul i32 %261, 3
  %263 = add i32 %262, %253
  store i32 %263, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 60), align 1, !tbaa !6
  store i32 %253, ptr @ov_i32, align 1, !tbaa !6
  %264 = and i64 %171, 288230376151711742
  %265 = or disjoint i64 %264, 1
  %266 = zext nneg i16 %201 to i64
  %267 = tail call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %265, i64 %266)
  %268 = extractvalue { i64, i1 } %267, 1
  %269 = extractvalue { i64, i1 } %267, 0
  br i1 %268, label %270, label %273

270:                                              ; preds = %260
  %271 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 32), align 1, !tbaa !2
  %272 = add i16 %271, 1
  store i16 %272, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 32), align 1, !tbaa !2
  br label %276

273:                                              ; preds = %260
  %274 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 32), align 1, !tbaa !2
  %275 = add i16 %274, 1
  store i16 %275, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 32), align 1, !tbaa !2
  br label %276

276:                                              ; preds = %273, %270
  %277 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 64), align 1, !tbaa !6
  %278 = mul i32 %277, 3
  %279 = trunc i64 %269 to i32
  %280 = add i32 %278, %279
  store i32 %280, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 64), align 1, !tbaa !6
  store i64 %269, ptr @ov_u64, align 8, !tbaa !10
  %281 = and i64 %187, 288230376151711743
  %282 = sext i32 %250 to i64
  %283 = tail call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %281, i64 %282)
  %284 = extractvalue { i64, i1 } %283, 1
  br i1 %284, label %285, label %288

285:                                              ; preds = %276
  %286 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 34), align 1, !tbaa !2
  %287 = add i16 %286, 1
  store i16 %287, ptr getelementptr inbounds nuw (i8, ptr @ov_fire, i16 34), align 1, !tbaa !2
  br label %291

288:                                              ; preds = %276
  %289 = load i16, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 34), align 1, !tbaa !2
  %290 = add i16 %289, 1
  store i16 %290, ptr getelementptr inbounds nuw (i8, ptr @ov_clean, i16 34), align 1, !tbaa !2
  br label %291

291:                                              ; preds = %288, %285
  %292 = extractvalue { i64, i1 } %283, 0
  %293 = load i32, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 68), align 1, !tbaa !6
  %294 = mul i32 %293, 3
  %295 = trunc i64 %292 to i32
  %296 = add i32 %294, %295
  store i32 %296, ptr getelementptr inbounds nuw (i8, ptr @ov_res, i16 68), align 1, !tbaa !6
  store i64 %292, ptr @ov_i64, align 8, !tbaa !10
  ret void
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.uadd.with.overflow.i16(i16, i16) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.sadd.with.overflow.i16(i16, i16) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.uadd.with.overflow.i32(i32, i32) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.usub.with.overflow.i16(i16, i16) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.ssub.with.overflow.i16(i16, i16) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.usub.with.overflow.i32(i32, i32) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.usub.with.overflow.i64(i64, i64) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.umul.with.overflow.i16(i16, i16) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.smul.with.overflow.i16(i16, i16) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #4

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #2 = { minsize mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #3 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { minsize optsize }
attributes #6 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !7, i64 0}
!7 = !{!"long", !4, i64 0}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = !{!11, !11, i64 0}
!11 = !{!"long long", !4, i64 0}
!12 = distinct !{!12, !9}
!13 = distinct !{!13, !9}
!14 = !{i64 1246}
