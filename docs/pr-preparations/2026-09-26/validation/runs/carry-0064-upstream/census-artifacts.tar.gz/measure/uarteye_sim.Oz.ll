; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/uarteye_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/uarteye_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %6, %0
  %2 = phi i16 [ 0, %0 ], [ %23, %6 ]
  %3 = phi i16 [ 21930, %0 ], [ %8, %6 ]
  %4 = phi i16 [ 0, %0 ], [ %22, %6 ]
  %5 = icmp eq i16 %2, 128
  br i1 %5, label %24, label %6

6:                                                ; preds = %1
  %7 = mul i16 %3, 25173
  %8 = add i16 %7, 13849
  %9 = lshr i16 %8, 7
  %10 = trunc i16 %9 to i8
  %11 = tail call fastcc zeroext i8 @uart_roundtrip(i8 noundef zeroext %10) #3
  %12 = zext i8 %11 to i16
  %13 = tail call i16 @llvm.fshl.i16(i16 %4, i16 %4, i16 1)
  %14 = xor i16 %13, %12
  %15 = xor i8 %11, %10
  %16 = zext i8 %15 to i16
  %17 = tail call i16 @llvm.fshl.i16(i16 %14, i16 %14, i16 1)
  %18 = xor i16 %17, %16
  %19 = shl nuw nsw i16 %9, 1
  %20 = or i16 %19, 512
  %21 = tail call i16 @llvm.fshl.i16(i16 %18, i16 %18, i16 1)
  %22 = xor i16 %21, %20
  %23 = add nuw nsw i16 %2, 1
  br label %1, !llvm.loop !6

24:                                               ; preds = %1
  store volatile i16 %4, ptr @corpus_result, align 1, !tbaa !2
  br label %25

25:                                               ; preds = %25, %24
  tail call void asm sideeffect "", ""() #4, !srcloc !8
  br label %25
}

; Function Attrs: minsize nofree noinline norecurse nosync nounwind optsize memory(none)
define internal fastcc zeroext i8 @uart_roundtrip(i8 noundef zeroext %0) unnamed_addr #1 {
  %2 = zext i8 %0 to i16
  %3 = shl nuw nsw i16 %2, 1
  %4 = or disjoint i16 %3, 512
  br label %5

5:                                                ; preds = %13, %1
  %6 = phi i16 [ 0, %1 ], [ %18, %13 ]
  %7 = phi i8 [ 0, %1 ], [ %19, %13 ]
  %8 = phi i16 [ %4, %1 ], [ %14, %13 ]
  %9 = icmp eq i8 %7, 10
  br i1 %9, label %10, label %13

10:                                               ; preds = %5
  %11 = lshr i16 %6, 1
  %12 = trunc i16 %11 to i8
  ret i8 %12

13:                                               ; preds = %5
  %14 = lshr i16 %8, 1
  %15 = lshr i16 %6, 1
  %16 = shl i16 %8, 9
  %17 = and i16 %16, 512
  %18 = or i16 %17, %15
  %19 = add nuw nsw i8 %7, 1
  br label %5, !llvm.loop !9
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #2

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { minsize nofree noinline norecurse nosync nounwind optsize memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { minsize optsize }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{i64 657}
!9 = distinct !{!9, !7}
