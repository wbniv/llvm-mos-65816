; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/uarteye_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/uarteye_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %1, %0
  %2 = phi i16 [ 0, %0 ], [ %20, %1 ]
  %3 = phi i16 [ 21930, %0 ], [ %6, %1 ]
  %4 = phi i16 [ 0, %0 ], [ %21, %1 ]
  %5 = mul i16 %3, 25173
  %6 = add i16 %5, 13849
  %7 = lshr i16 %6, 7
  %8 = trunc i16 %7 to i8
  %9 = tail call fastcc zeroext i8 @uart_roundtrip(i8 noundef zeroext %8) #3
  %10 = zext i8 %9 to i16
  %11 = tail call i16 @llvm.fshl.i16(i16 %2, i16 %2, i16 1)
  %12 = xor i16 %11, %10
  %13 = xor i8 %9, %8
  %14 = zext i8 %13 to i16
  %15 = tail call i16 @llvm.fshl.i16(i16 %12, i16 %12, i16 1)
  %16 = xor i16 %15, %14
  %17 = shl nuw nsw i16 %7, 1
  %18 = or i16 %17, 512
  %19 = tail call i16 @llvm.fshl.i16(i16 %16, i16 %16, i16 1)
  %20 = xor i16 %19, %18
  %21 = add nuw nsw i16 %4, 1
  %22 = icmp eq i16 %21, 128
  br i1 %22, label %23, label %1, !llvm.loop !6

23:                                               ; preds = %1
  store volatile i16 %20, ptr @corpus_result, align 1, !tbaa !2
  br label %24

24:                                               ; preds = %24, %23
  tail call void asm sideeffect "", ""() #4, !srcloc !8
  br label %24
}

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(none)
define internal fastcc zeroext i8 @uart_roundtrip(i8 noundef zeroext %0) unnamed_addr #1 {
  %2 = zext i8 %0 to i16
  %3 = shl nuw nsw i16 %2, 1
  %4 = or disjoint i16 %3, 512
  br label %8

5:                                                ; preds = %8
  %6 = lshr i16 %11, 2
  %7 = trunc nuw i16 %6 to i8
  ret i8 %7

8:                                                ; preds = %1, %8
  %9 = phi i16 [ %4, %1 ], [ %12, %8 ]
  %10 = phi i8 [ 0, %1 ], [ %17, %8 ]
  %11 = phi i16 [ 0, %1 ], [ %16, %8 ]
  %12 = lshr i16 %9, 1
  %13 = lshr i16 %11, 1
  %14 = shl i16 %9, 9
  %15 = and i16 %14, 512
  %16 = or i16 %15, %13
  %17 = add nuw nsw i8 %10, 1
  %18 = icmp eq i8 %17, 10
  br i1 %18, label %5, label %8, !llvm.loop !9
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #2

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nofree noinline norecurse nosync nounwind optsize memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { optsize }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{i64 657}
!9 = distinct !{!9, !7}
