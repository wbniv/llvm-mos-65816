; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/uarteye_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/uarteye_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %1, %0
  %2 = phi i16 [ 0, %0 ], [ %14, %1 ]
  %3 = phi i16 [ 21930, %0 ], [ %6, %1 ]
  %4 = phi i16 [ 0, %0 ], [ %15, %1 ]
  %5 = mul i16 %3, 25173
  %6 = add i16 %5, 13849
  %7 = lshr i16 %6, 7
  %8 = and i16 %7, 255
  %9 = tail call i16 @llvm.fshl.i16(i16 %2, i16 %2, i16 1)
  %10 = xor i16 %8, %9
  %11 = shl nuw nsw i16 %7, 1
  %12 = or i16 %11, 512
  %13 = tail call i16 @llvm.fshl.i16(i16 %10, i16 %10, i16 2)
  %14 = xor i16 %13, %12
  %15 = add nuw nsw i16 %4, 1
  %16 = icmp eq i16 %15, 128
  br i1 %16, label %17, label %1, !llvm.loop !6

17:                                               ; preds = %1
  store volatile i16 %14, ptr @corpus_result, align 1, !tbaa !2
  br label %18

18:                                               ; preds = %18, %17
  tail call void asm sideeffect "", ""() #2, !srcloc !8
  br label %18
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #1

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{i64 657}
