; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/structs.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/structs.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.point = type { i8, i16, i8 }

@bump = dso_local global i8 2, align 1
@pts = internal global [3 x %struct.point] [%struct.point { i8 1, i16 100, i8 7 }, %struct.point { i8 2, i16 200, i8 8 }, %struct.point { i8 3, i16 300, i8 9 }], align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = load volatile i8, ptr @pts, align 1, !tbaa !6
  %2 = zext i8 %1 to i16
  %3 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 1), align 1, !tbaa !8
  %4 = add i16 %3, %2
  %5 = load volatile i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 3), align 1, !tbaa !9
  %6 = zext i8 %5 to i16
  %7 = add i16 %4, %6
  %8 = load volatile i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 4), align 1, !tbaa !6
  %9 = zext i8 %8 to i16
  %10 = add i16 %7, %9
  %11 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !8
  %12 = add i16 %10, %11
  %13 = load volatile i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 7), align 1, !tbaa !9
  %14 = zext i8 %13 to i16
  %15 = add i16 %12, %14
  %16 = load volatile i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 8), align 1, !tbaa !6
  %17 = zext i8 %16 to i16
  %18 = add i16 %15, %17
  %19 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 9), align 1, !tbaa !8
  %20 = add i16 %18, %19
  %21 = load volatile i8, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 11), align 1, !tbaa !9
  %22 = zext i8 %21 to i16
  %23 = add i16 %20, %22
  %24 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !8
  %25 = load volatile i8, ptr @bump, align 1, !tbaa !10
  %26 = zext i8 %25 to i16
  %27 = add i16 %24, %26
  store volatile i16 %27, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !8
  %28 = load volatile i16, ptr getelementptr inbounds nuw (i8, ptr @pts, i16 5), align 1, !tbaa !8
  %29 = add i16 %28, %23
  store volatile i16 %29, ptr @corpus_result, align 1, !tbaa !2
  br label %30

30:                                               ; preds = %30, %0
  tail call void asm sideeffect "", ""() #1, !srcloc !11
  br label %30
}

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !4, i64 0}
!7 = !{!"point", !4, i64 0, !3, i64 1, !4, i64 3}
!8 = !{!7, !3, i64 1}
!9 = !{!7, !4, i64 3}
!10 = !{!4, !4, i64 0}
!11 = !{i64 1177}
