; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/control.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/control.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@n = dso_local global i16 100, align 1
@sel = dso_local global i8 3, align 1
@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = load volatile i16, ptr @n, align 1, !tbaa !2
  %2 = icmp eq i16 %1, 0
  br i1 %2, label %10, label %3

3:                                                ; preds = %0, %3
  %4 = phi i16 [ %7, %3 ], [ 1, %0 ]
  %5 = phi i16 [ %6, %3 ], [ 0, %0 ]
  %6 = add i16 %4, %5
  %7 = add i16 %4, 1
  %8 = load volatile i16, ptr @n, align 1, !tbaa !2
  %9 = icmp ugt i16 %7, %8
  br i1 %9, label %10, label %3, !llvm.loop !6

10:                                               ; preds = %3, %0
  %11 = phi i16 [ 0, %0 ], [ %6, %3 ]
  %12 = load volatile i16, ptr @n, align 1, !tbaa !2
  %13 = icmp eq i16 %12, 0
  br i1 %13, label %25, label %14

14:                                               ; preds = %10, %21
  %15 = phi i16 [ %22, %21 ], [ 0, %10 ]
  %16 = phi i16 [ %23, %21 ], [ %12, %10 ]
  %17 = and i16 %16, 1
  %18 = icmp eq i16 %17, 0
  br i1 %18, label %19, label %21

19:                                               ; preds = %14
  %20 = add i16 %15, %16
  br label %21

21:                                               ; preds = %19, %14
  %22 = phi i16 [ %20, %19 ], [ %15, %14 ]
  %23 = add i16 %16, -1
  %24 = icmp eq i16 %23, 0
  br i1 %24, label %25, label %14, !llvm.loop !8

25:                                               ; preds = %21, %10
  %26 = phi i16 [ 0, %10 ], [ %22, %21 ]
  %27 = add i16 %26, %11
  %28 = add i16 %27, 45
  %29 = load volatile i8, ptr @sel, align 1, !tbaa !9
  %30 = add i8 %29, -1
  %31 = icmp ult i8 %30, 3
  br i1 %31, label %32, label %36

32:                                               ; preds = %25
  %33 = mul nuw nsw i8 %30, 10
  %34 = add nuw nsw i8 %33, 10
  %35 = zext nneg i8 %34 to i16
  br label %36

36:                                               ; preds = %25, %32
  %37 = phi i16 [ %35, %32 ], [ 0, %25 ]
  %38 = add i16 %28, %37
  store volatile i16 %38, ptr @corpus_result, align 1, !tbaa !2
  br label %39

39:                                               ; preds = %39, %36
  tail call void asm sideeffect "", ""() #1, !srcloc !10
  br label %39
}

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = !{!4, !4, i64 0}
!10 = !{i64 1146}
