; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/bitshuffle_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/bitshuffle_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %5, %0
  %2 = phi i16 [ 0, %0 ], [ %37, %5 ]
  %3 = phi i16 [ 0, %0 ], [ %36, %5 ]
  %4 = icmp eq i16 %2, 256
  br i1 %4, label %38, label %5

5:                                                ; preds = %1
  %6 = zext nneg i16 %2 to i32
  %7 = mul nuw nsw i32 %6, 131136
  %8 = mul nuw nsw i16 %2, 5
  %9 = zext nneg i16 %8 to i32
  %10 = xor i32 %7, %9
  %11 = xor i32 %10, -1640531527
  %12 = tail call noundef i32 @llvm.bitreverse.i32(i32 range(i32 -1644167168, 256) %11)
  %13 = xor i32 %10, -878884235
  %14 = tail call noundef i32 @llvm.bswap.i32(i32 range(i32 -905969664, -872415232) %13)
  %15 = tail call noundef i32 @llvm.bitreverse.i32(i32 range(i32 -1644167168, 256) %6)
  %16 = lshr exact i32 %15, 24
  %17 = tail call noundef i32 @llvm.bitreverse.i32(i32 range(i32 -1644167168, 256) %16)
  %18 = trunc i32 %12 to i16
  %19 = tail call i16 @llvm.fshl.i16(i16 %3, i16 %3, i16 1)
  %20 = xor i16 %19, %18
  %21 = lshr i32 %12, 16
  %22 = trunc nuw i32 %21 to i16
  %23 = tail call i16 @llvm.fshl.i16(i16 %20, i16 %20, i16 1)
  %24 = xor i16 %23, %22
  %25 = trunc i32 %14 to i16
  %26 = tail call i16 @llvm.fshl.i16(i16 %24, i16 %24, i16 1)
  %27 = xor i16 %26, %25
  %28 = lshr i32 %14, 16
  %29 = trunc nuw i32 %28 to i16
  %30 = tail call i16 @llvm.fshl.i16(i16 %27, i16 %27, i16 1)
  %31 = xor i16 %30, %29
  %32 = lshr exact i32 %17, 16
  %33 = or disjoint i32 %32, %16
  %34 = trunc nuw i32 %33 to i16
  %35 = tail call i16 @llvm.fshl.i16(i16 %31, i16 %31, i16 1)
  %36 = xor i16 %35, %34
  %37 = add nuw nsw i16 %2, 1
  br label %1, !llvm.loop !6

38:                                               ; preds = %1
  store volatile i16 %3, ptr @corpus_result, align 1, !tbaa !2
  br label %39

39:                                               ; preds = %39, %38
  tail call void asm sideeffect "", ""() #3, !srcloc !8
  br label %39
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bitreverse.i32(i32) #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #2

attributes #0 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{i64 466}
