; ModuleID = '/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/rotkal_sim.c'
source_filename = "/home/will/llvm-mos-65816/.scratch/carry-pr/inputs/rotkal_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.RKState = type { [8 x i8], i16 }

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca %struct.RKState, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #4
  store i8 -93, ptr %1, align 1, !tbaa !6
  %2 = getelementptr inbounds nuw i8, ptr %1, i16 1
  store i8 92, ptr %2, align 1, !tbaa !6
  %3 = getelementptr inbounds nuw i8, ptr %1, i16 2
  store i8 -31, ptr %3, align 1, !tbaa !6
  %4 = getelementptr inbounds nuw i8, ptr %1, i16 3
  store i8 120, ptr %4, align 1, !tbaa !6
  %5 = getelementptr inbounds nuw i8, ptr %1, i16 4
  store i8 47, ptr %5, align 1, !tbaa !6
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 5
  store i8 -108, ptr %6, align 1, !tbaa !6
  %7 = getelementptr inbounds nuw i8, ptr %1, i16 6
  store i8 -73, ptr %7, align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 7
  store i8 29, ptr %8, align 1, !tbaa !6
  %9 = getelementptr inbounds nuw i8, ptr %1, i16 8
  store i16 -21555, ptr %9, align 1, !tbaa !7
  br label %10

10:                                               ; preds = %10, %0
  %11 = phi i16 [ 0, %0 ], [ %49, %10 ]
  %12 = phi i16 [ 0, %0 ], [ %50, %10 ]
  %13 = and i16 %12, 14
  %14 = or disjoint i16 %13, 1
  call fastcc void @rk_step(ptr noundef %1, i16 noundef %14)
  %15 = load i8, ptr %1, align 1, !tbaa !6
  %16 = zext i8 %15 to i16
  %17 = tail call i16 @llvm.fshl.i16(i16 %11, i16 %11, i16 1)
  %18 = xor i16 %17, %16
  %19 = load i8, ptr %2, align 1, !tbaa !6
  %20 = zext i8 %19 to i16
  %21 = tail call i16 @llvm.fshl.i16(i16 %18, i16 %18, i16 1)
  %22 = xor i16 %21, %20
  %23 = load i8, ptr %3, align 1, !tbaa !6
  %24 = zext i8 %23 to i16
  %25 = tail call i16 @llvm.fshl.i16(i16 %22, i16 %22, i16 1)
  %26 = xor i16 %25, %24
  %27 = load i8, ptr %4, align 1, !tbaa !6
  %28 = zext i8 %27 to i16
  %29 = tail call i16 @llvm.fshl.i16(i16 %26, i16 %26, i16 1)
  %30 = xor i16 %29, %28
  %31 = load i8, ptr %5, align 1, !tbaa !6
  %32 = zext i8 %31 to i16
  %33 = tail call i16 @llvm.fshl.i16(i16 %30, i16 %30, i16 1)
  %34 = xor i16 %33, %32
  %35 = load i8, ptr %6, align 1, !tbaa !6
  %36 = zext i8 %35 to i16
  %37 = tail call i16 @llvm.fshl.i16(i16 %34, i16 %34, i16 1)
  %38 = xor i16 %37, %36
  %39 = load i8, ptr %7, align 1, !tbaa !6
  %40 = zext i8 %39 to i16
  %41 = tail call i16 @llvm.fshl.i16(i16 %38, i16 %38, i16 1)
  %42 = xor i16 %41, %40
  %43 = load i8, ptr %8, align 1, !tbaa !6
  %44 = zext i8 %43 to i16
  %45 = tail call i16 @llvm.fshl.i16(i16 %42, i16 %42, i16 1)
  %46 = xor i16 %45, %44
  %47 = load i16, ptr %9, align 1, !tbaa !7
  %48 = tail call i16 @llvm.fshl.i16(i16 %46, i16 %46, i16 1)
  %49 = xor i16 %48, %47
  %50 = add nuw nsw i16 %12, 1
  %51 = icmp eq i16 %50, 100
  br i1 %51, label %52, label %10, !llvm.loop !9

52:                                               ; preds = %10
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #4
  store volatile i16 %49, ptr @corpus_result, align 1, !tbaa !2
  br label %53

53:                                               ; preds = %53, %52
  tail call void asm sideeffect "", ""() #4, !srcloc !11
  br label %53
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite)
define internal fastcc void @rk_step(ptr noundef nonnull captures(none) %0, i16 noundef range(i16 1, 16) %1) unnamed_addr #2 {
  %3 = load i8, ptr %0, align 1, !tbaa !6
  %4 = tail call i8 @llvm.fshl.i8(i8 %3, i8 %3, i8 1)
  store i8 %4, ptr %0, align 1, !tbaa !6
  %5 = getelementptr inbounds nuw i8, ptr %0, i16 1
  %6 = load i8, ptr %5, align 1, !tbaa !6
  %7 = tail call i8 @llvm.fshl.i8(i8 %6, i8 %6, i8 2)
  store i8 %7, ptr %5, align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %9 = load i8, ptr %8, align 1, !tbaa !6
  %10 = tail call i8 @llvm.fshl.i8(i8 %9, i8 %9, i8 3)
  store i8 %10, ptr %8, align 1, !tbaa !6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %12 = load i8, ptr %11, align 1, !tbaa !6
  %13 = tail call i8 @llvm.fshl.i8(i8 %12, i8 %12, i8 1)
  store i8 %13, ptr %11, align 1, !tbaa !6
  %14 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %15 = load i8, ptr %14, align 1, !tbaa !6
  %16 = tail call i8 @llvm.fshl.i8(i8 %15, i8 %15, i8 7)
  store i8 %16, ptr %14, align 1, !tbaa !6
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 5
  %18 = load i8, ptr %17, align 1, !tbaa !6
  %19 = tail call i8 @llvm.fshl.i8(i8 %18, i8 %18, i8 6)
  store i8 %19, ptr %17, align 1, !tbaa !6
  %20 = getelementptr inbounds nuw i8, ptr %0, i16 6
  %21 = load i8, ptr %20, align 1, !tbaa !6
  %22 = tail call i8 @llvm.fshl.i8(i8 %21, i8 %21, i8 5)
  store i8 %22, ptr %20, align 1, !tbaa !6
  %23 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %24 = load i8, ptr %23, align 1, !tbaa !6
  %25 = tail call i8 @llvm.fshl.i8(i8 %24, i8 %24, i8 7)
  store i8 %25, ptr %23, align 1, !tbaa !6
  %26 = getelementptr inbounds nuw i8, ptr %0, i16 8
  %27 = load i16, ptr %26, align 1, !tbaa !7
  %28 = tail call i16 @llvm.fshl.i16(i16 %27, i16 %27, i16 %1)
  store i16 %28, ptr %26, align 1, !tbaa !7
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fshl.i8(i8, i8, i8) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #3

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mos6502" }
attributes #3 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (/upstream 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = !{!8, !3, i64 8}
!8 = !{!"", !4, i64 0, !3, i64 8}
!9 = distinct !{!9, !10}
!10 = !{!"llvm.loop.mustprogress"}
!11 = !{i64 560}
