	.zeropage	__rc0
	.zeropage	__rc1
	.zeropage	__rc2
	.zeropage	__rc3
	.zeropage	__rc4
	.zeropage	__rc5
	.zeropage	__rc6
	.zeropage	__rc7
	.zeropage	__rc8
	.zeropage	__rc9
	.zeropage	__rc10
	.zeropage	__rc11
	.zeropage	__rc12
	.zeropage	__rc13
	.zeropage	__rc14
	.zeropage	__rc15
	.zeropage	__rc16
	.zeropage	__rc17
	.zeropage	__rc18
	.zeropage	__rc19
	.zeropage	__rc20
	.zeropage	__rc21
	.zeropage	__rc22
	.zeropage	__rc23
	.zeropage	__rc24
	.zeropage	__rc25
	.zeropage	__rc26
	.zeropage	__rc27
	.zeropage	__rc28
	.zeropage	__rc29
	.zeropage	__rc30
	.zeropage	__rc31
	.file	"context.c"
	.text
	.globl	across_call                     ; -- Begin function across_call
	.type	across_call,@function
across_call:                            ; @across_call
; %bb.0:
	ldy	__rc20
	phy
	ldy	__rc21
	phy
	sta	__rc20
	stx	__rc21
	jsr	opaque
	ldx	__rc20
	stx	g
	ldx	__rc21
	stx	g+1
	plx
	stx	__rc21
	plx
	stx	__rc20
	rts
.Lfunc_end0:
	.size	across_call, .Lfunc_end0-across_call
                                        ; -- End function
	.globl	native_context                  ; -- Begin function native_context
	.type	native_context,@function
native_context:                         ; @native_context
; %bb.0:
	sta	__rc4
	lda	h
	sta	__rc3
	lda	h+1
	sta	__rc2
	clc
	lda	__rc3
	adc	#42
	tay
	lda	__rc2
	adc	#0
	sty	h
	sta	h+1
	ldy	__rc4
	sty	g
	stx	g+1
	rts
.Lfunc_end1:
	.size	native_context, .Lfunc_end1-native_context
                                        ; -- End function
	.globl	before_call                     ; -- Begin function before_call
	.type	before_call,@function
before_call:                            ; @before_call
; %bb.0:
	sta	g
	stx	g+1
	jmp	opaque
.Lfunc_end2:
	.size	before_call, .Lfunc_end2-before_call
                                        ; -- End function
	.globl	conditional                     ; -- Begin function conditional
	.type	conditional,@function
conditional:                            ; @conditional
; %bb.0:
	ldy	__rc2
	beq	.LBB3_2
; %bb.1:
	ldy	__rc20
	phy
	ldy	__rc21
	phy
	sta	__rc20
	stx	__rc21
	jsr	opaque
	ldx	__rc21
	lda	__rc20
	ply
	sty	__rc21
	ply
	sty	__rc20
.LBB3_2:
	sta	g
	stx	g+1
	rts
.Lfunc_end3:
	.size	conditional, .Lfunc_end3-conditional
                                        ; -- End function
	.globl	through_pointer                 ; -- Begin function through_pointer
	.type	through_pointer,@function
through_pointer:                        ; @through_pointer
; %bb.0:
	sta	__rc4
	sta	(__rc2)
	ldy	#1
	txa
	sta	(__rc2),y
	ldx	__rc4
	stx	g
	sta	g+1
	rts
.Lfunc_end4:
	.size	through_pointer, .Lfunc_end4-through_pointer
                                        ; -- End function
	.type	g,@object                       ; @g
	.bss
	.globl	g
g:
	.short	0                               ; 0x0
	.size	g, 2

	.type	h,@object                       ; @h
	.globl	h
h:
	.short	0                               ; 0x0
	.size	h, 2

	.ident	"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"
	.section	".note.GNU-stack","",@progbits
	;Declaring this symbol tells the CRT that there is something in .bss, so it may need to be zeroed.
	.globl	__do_zero_bss
	;Declaring this symbol tells the CRT that the stack pointer needs to be initialized.
	.globl	__do_init_stack
