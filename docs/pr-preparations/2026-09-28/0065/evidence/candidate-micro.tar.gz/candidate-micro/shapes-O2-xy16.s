	.zeropage	__rc0
	.zeropage	__rc1
	.zeropage	__rc2
	.zeropage	__rc3
	.zeropage	__rc4
	.zeropage	__rc5
	.zeropage	__rc6
	.zeropage	__rc7
	.zeropage	__rc8
	.zeropage	__rc9
	.zeropage	__rc10
	.zeropage	__rc11
	.zeropage	__rc12
	.zeropage	__rc13
	.zeropage	__rc14
	.zeropage	__rc15
	.zeropage	__rc16
	.zeropage	__rc17
	.zeropage	__rc18
	.zeropage	__rc19
	.zeropage	__rc20
	.zeropage	__rc21
	.zeropage	__rc22
	.zeropage	__rc23
	.zeropage	__rc24
	.zeropage	__rc25
	.zeropage	__rc26
	.zeropage	__rc27
	.zeropage	__rc28
	.zeropage	__rc29
	.zeropage	__rc30
	.zeropage	__rc31
	.file	"shapes.c"
	.text
	.globl	set                             ; -- Begin function set
	.type	set,@function
set:                                    ; @set
; %bb.0:
	sta	g
	stx	g+1
	rts
.Lfunc_end0:
	.size	set, .Lfunc_end0-set
                                        ; -- End function
	.globl	vset                            ; -- Begin function vset
	.type	vset,@function
vset:                                   ; @vset
; %bb.0:
	sta	vg
	stx	vg+1
	rts
.Lfunc_end1:
	.size	vset, .Lfunc_end1-vset
                                        ; -- End function
	.globl	pset                            ; -- Begin function pset
	.type	pset,@function
pset:                                   ; @pset
; %bb.0:
	sta	(__rc2)
	ldy	#1
	txa
	sta	(__rc2),y
	rts
.Lfunc_end2:
	.size	pset, .Lfunc_end2-pset
                                        ; -- End function
	.globl	iset                            ; -- Begin function iset
	.type	iset,@function
iset:                                   ; @iset
; %bb.0:
	sta	__rc4
	stx	__rc6
	ldx	__rc2
	stx	__rc7
	stz	__rc5
	rep	#32
	lda	__rc4
	asl
	sta	__rc2
	sep	#32
	rep	#16
	ldx	__rc2
	rep	#32
	lda	__rc6
	sta	arr,x
	sep	#48
	rts
.Lfunc_end3:
	.size	iset, .Lfunc_end3-iset
                                        ; -- End function
	.globl	copy                            ; -- Begin function copy
	.type	copy,@function
copy:                                   ; @copy
; %bb.0:
	ldx	h
	stx	g
	ldx	h+1
	stx	g+1
	rts
.Lfunc_end4:
	.size	copy, .Lfunc_end4-copy
                                        ; -- End function
	.globl	add                             ; -- Begin function add
	.type	add,@function
add:                                    ; @add
; %bb.0:
	sta	__rc2
	stx	__rc3
	rep	#32
	lda	__rc2
	clc
	adc	#mos16(42)
	sta	g
	sep	#32
	rts
.Lfunc_end5:
	.size	add, .Lfunc_end5-add
                                        ; -- End function
	.globl	bit                             ; -- Begin function bit
	.type	bit,@function
bit:                                    ; @bit
; %bb.0:
	sta	__rc2
	stx	__rc3
	rep	#32
	lda	__rc2
	eor	#4660
	sta	g
	sep	#32
	rts
.Lfunc_end6:
	.size	bit, .Lfunc_end6-bit
                                        ; -- End function
	.globl	zero                            ; -- Begin function zero
	.type	zero,@function
zero:                                   ; @zero
; %bb.0:
	rep	#32
	stz	g
	sep	#32
	rts
.Lfunc_end7:
	.size	zero, .Lfunc_end7-zero
                                        ; -- End function
	.globl	multiple                        ; -- Begin function multiple
	.type	multiple,@function
multiple:                               ; @multiple
; %bb.0:
	sta	g
	stx	g+1
	sta	h
	stx	h+1
	rts
.Lfunc_end8:
	.size	multiple, .Lfunc_end8-multiple
                                        ; -- End function
	.globl	mixed                           ; -- Begin function mixed
	.type	mixed,@function
mixed:                                  ; @mixed
; %bb.0:
	sta	g
	stx	g+1
	inc
	bne	.LBB9_2
; %bb.1:
	inx
.LBB9_2:
	rts
.Lfunc_end9:
	.size	mixed, .Lfunc_end9-mixed
                                        ; -- End function
	.globl	passthrough                     ; -- Begin function passthrough
	.type	passthrough,@function
passthrough:                            ; @passthrough
; %bb.0:
	sta	g
	stx	g+1
	rts
.Lfunc_end10:
	.size	passthrough, .Lfunc_end10-passthrough
                                        ; -- End function
	.globl	callresult                      ; -- Begin function callresult
	.type	callresult,@function
callresult:                             ; @callresult
; %bb.0:
	jsr	f
	sta	g
	stx	g+1
	rts
.Lfunc_end11:
	.size	callresult, .Lfunc_end11-callresult
                                        ; -- End function
	.type	g,@object                       ; @g
	.bss
	.globl	g
g:
	.short	0                               ; 0x0
	.size	g, 2

	.type	vg,@object                      ; @vg
	.globl	vg
vg:
	.short	0                               ; 0x0
	.size	vg, 2

	.type	arr,@object                     ; @arr
	.globl	arr
arr:
	.zero	256
	.size	arr, 256

	.type	h,@object                       ; @h
	.globl	h
h:
	.short	0                               ; 0x0
	.size	h, 2

	.ident	"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"
	.section	".note.GNU-stack","",@progbits
	;Declaring this symbol tells the CRT that there is something in .bss, so it may need to be zeroed.
	.globl	__do_zero_bss
	;Declaring this symbol tells the CRT that the stack pointer needs to be initialized.
	.globl	__do_init_stack
