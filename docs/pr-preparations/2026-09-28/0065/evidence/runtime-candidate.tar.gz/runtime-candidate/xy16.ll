; ModuleID = '/work/examples/65816/a16storebroad.c'
source_filename = "/work/examples/65816/a16storebroad.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.Storage = type { [255 x i8], %struct.Word, i8 }
%struct.Word = type { i16 }

@word_source = dso_local global i16 0, align 1
@absolute_word = dso_local global i16 0, align 1
@byte_source = dso_local global i8 0, align 1
@corpus_result = dso_local global i16 0, align 1
@kernel.values = internal unnamed_addr constant [10 x i16] [i16 0, i16 1, i16 255, i16 256, i16 257, i16 -32768, i16 -23236, i16 -256, i16 -2, i16 -1], align 1
@storage = internal global %struct.Storage zeroinitializer, align 256

; Function Attrs: mustprogress nofree noinline norecurse nounwind optsize willreturn memory(readwrite, argmem: none, target_mem: none)
define dso_local i16 @produce() local_unnamed_addr #0 {
  %1 = load volatile i16, ptr @word_source, align 1, !tbaa !2
  ret i16 %1
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, argmem: none, target_mem: none)
define dso_local void @clobber() local_unnamed_addr #1 {
  %1 = load volatile i16, ptr @word_source, align 1, !tbaa !2
  %2 = xor i16 %1, 23235
  store volatile i16 %2, ptr @word_source, align 1, !tbaa !2
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, argmem: none, target_mem: none)
define dso_local noundef i16 @absolute_dec(i16 noundef %0) local_unnamed_addr #1 {
  store volatile i16 %0, ptr @absolute_word, align 1, !tbaa !2
  %2 = add i16 %0, -1
  ret i16 %2
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(argmem: readwrite, inaccessiblemem: readwrite)
define dso_local noundef i16 @indirect_inc(ptr noundef %0, i16 noundef %1) local_unnamed_addr #2 {
  store volatile i16 %1, ptr %0, align 1, !tbaa !6
  %3 = add i16 %1, 1
  ret i16 %3
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(argmem: readwrite, inaccessiblemem: readwrite)
define dso_local noundef i16 @indirect_dec(ptr noundef %0, i16 noundef %1) local_unnamed_addr #2 {
  store volatile i16 %1, ptr %0, align 1, !tbaa !6
  %3 = add i16 %1, -1
  ret i16 %3
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define dso_local void @call_result(ptr noundef %0) local_unnamed_addr #3 {
  %2 = tail call i16 @produce() #6
  store volatile i16 %2, ptr %0, align 1, !tbaa !6
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define dso_local i16 @call_return(ptr noundef %0) local_unnamed_addr #3 {
  %2 = tail call i16 @produce() #6
  store volatile i16 %2, ptr %0, align 1, !tbaa !6
  ret i16 %2
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #4

; Function Attrs: nofree noinline norecurse nounwind optsize memory(argmem: readwrite, inaccessiblemem: readwrite)
define dso_local void @byte_argument(ptr noundef %0, i8 noundef zeroext %1) local_unnamed_addr #2 {
  %3 = zext i8 %1 to i16
  store volatile i16 %3, ptr %0, align 1, !tbaa !6
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define dso_local void @byte_absolute(ptr noundef %0) local_unnamed_addr #3 {
  %2 = load volatile i8, ptr @byte_source, align 1, !tbaa !8
  %3 = zext i8 %2 to i16
  store volatile i16 %3, ptr %0, align 1, !tbaa !6
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(argmem: readwrite, inaccessiblemem: readwrite)
define dso_local void @byte_indirect(ptr noundef %0, ptr noundef %1) local_unnamed_addr #2 {
  %3 = load volatile i8, ptr %1, align 1, !tbaa !8
  %4 = zext i8 %3 to i16
  store volatile i16 %4, ptr %0, align 1, !tbaa !6
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define dso_local void @loaded_pointer(ptr noundef %0, i16 noundef %1) local_unnamed_addr #3 {
  %3 = load volatile ptr, ptr %0, align 1, !tbaa !9
  store volatile i16 %1, ptr %3, align 1, !tbaa !6
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define dso_local void @call_live(ptr noundef %0, i16 noundef %1) local_unnamed_addr #3 {
  tail call void @clobber() #6
  store volatile i16 %1, ptr %0, align 1, !tbaa !6
  ret void
}

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #5 {
  %1 = alloca ptr, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #7
  store volatile ptr getelementptr inbounds nuw (i8, ptr @storage, i16 255), ptr %1, align 1, !tbaa !9
  %2 = load volatile ptr, ptr %1, align 1, !tbaa !9
  br label %3

3:                                                ; preds = %3, %0
  %4 = phi i8 [ 0, %0 ], [ %62, %3 ]
  %5 = phi i16 [ 4660, %0 ], [ %59, %3 ]
  %6 = phi i16 [ 0, %0 ], [ %60, %3 ]
  %7 = zext nneg i8 %4 to i16
  %8 = getelementptr i8, ptr @kernel.values, i16 %7
  %9 = load i16, ptr %8, align 1, !tbaa !2
  store volatile i8 105, ptr getelementptr inbounds nuw (i8, ptr @storage, i16 254), align 2, !tbaa !8
  store volatile i8 -106, ptr getelementptr inbounds nuw (i8, ptr @storage, i16 257), align 1, !tbaa !11
  store volatile i16 %9, ptr @word_source, align 1, !tbaa !2
  %10 = trunc i16 %9 to i8
  store volatile i8 %10, ptr @byte_source, align 1, !tbaa !8
  %11 = call i16 @absolute_dec(i16 noundef %9) #6
  %12 = xor i16 %11, %5
  %13 = mul i16 %12, 33
  %14 = load volatile i16, ptr @absolute_word, align 1, !tbaa !2
  %15 = xor i16 %13, %14
  %16 = call i16 @indirect_inc(ptr noundef %2, i16 noundef %9) #6
  %17 = xor i16 %15, %16
  %18 = mul i16 %17, 33
  %19 = load volatile i16, ptr %2, align 1, !tbaa !6
  %20 = call i16 @indirect_dec(ptr noundef nonnull %2, i16 noundef %9) #6
  %21 = xor i16 %20, %19
  %22 = xor i16 %21, %18
  %23 = mul i16 %22, 33
  %24 = load volatile i16, ptr %2, align 1, !tbaa !6
  %25 = xor i16 %23, %24
  call void @call_result(ptr noundef nonnull %2) #6
  %26 = mul i16 %25, 33
  %27 = load volatile i16, ptr %2, align 1, !tbaa !6
  %28 = call i16 @call_return(ptr noundef nonnull %2) #6
  %29 = xor i16 %28, %27
  %30 = xor i16 %29, %26
  %31 = mul i16 %30, 33
  %32 = load volatile i16, ptr %2, align 1, !tbaa !6
  %33 = xor i16 %31, %32
  call void @byte_argument(ptr noundef nonnull %2, i8 noundef zeroext %10) #6
  %34 = mul i16 %33, 33
  %35 = load volatile i16, ptr %2, align 1, !tbaa !6
  %36 = xor i16 %34, %35
  call void @byte_absolute(ptr noundef nonnull %2) #6
  %37 = mul i16 %36, 33
  %38 = load volatile i16, ptr %2, align 1, !tbaa !6
  %39 = xor i16 %37, %38
  call void @byte_indirect(ptr noundef nonnull %2, ptr noundef nonnull @byte_source) #6
  %40 = mul i16 %39, 33
  %41 = load volatile i16, ptr %2, align 1, !tbaa !6
  %42 = xor i16 %40, %41
  store volatile i16 %9, ptr %2, align 1, !tbaa !6
  call void @byte_indirect(ptr noundef nonnull %2, ptr noundef nonnull %2) #6
  %43 = mul i16 %42, 33
  %44 = load volatile i16, ptr %2, align 1, !tbaa !6
  %45 = xor i16 %43, %44
  call void @loaded_pointer(ptr noundef nonnull %1, i16 noundef %9) #6
  %46 = mul i16 %45, 33
  %47 = load volatile i16, ptr %2, align 1, !tbaa !6
  %48 = xor i16 %46, %47
  call void @call_live(ptr noundef nonnull %2, i16 noundef %9) #6
  %49 = mul i16 %48, 33
  %50 = load volatile i16, ptr %2, align 1, !tbaa !6
  %51 = xor i16 %49, %50
  %52 = mul i16 %51, 33
  %53 = load volatile i8, ptr getelementptr inbounds nuw (i8, ptr @storage, i16 254), align 2, !tbaa !8
  %54 = zext i8 %53 to i16
  %55 = xor i16 %52, %54
  %56 = mul i16 %55, 33
  %57 = load volatile i8, ptr getelementptr inbounds nuw (i8, ptr @storage, i16 257), align 1, !tbaa !11
  %58 = zext i8 %57 to i16
  %59 = xor i16 %56, %58
  %60 = add nuw nsw i16 %6, 1
  %61 = icmp eq i16 %60, 10
  %62 = add nuw nsw i8 %4, 2
  br i1 %61, label %63, label %3, !llvm.loop !13

63:                                               ; preds = %3
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #7
  store volatile i16 %59, ptr @corpus_result, align 1, !tbaa !2
  br label %64

64:                                               ; preds = %64, %63
  call void asm sideeffect "wai", ""() #7, !srcloc !15
  br label %64
}

attributes #0 = { mustprogress nofree noinline norecurse nounwind optsize willreturn memory(readwrite, argmem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #1 = { nofree noinline norecurse nounwind optsize memory(readwrite, argmem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #2 = { nofree noinline norecurse nounwind optsize memory(argmem: readwrite, inaccessiblemem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #3 = { nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #4 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #6 = { optsize }
attributes #7 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !3, i64 0}
!7 = !{!"", !3, i64 0}
!8 = !{!4, !4, i64 0}
!9 = !{!10, !10, i64 0}
!10 = !{!"any pointer", !4, i64 0}
!11 = !{!12, !4, i64 257}
!12 = !{!"", !4, i64 0, !7, i64 255, !4, i64 257}
!13 = distinct !{!13, !14}
!14 = !{!"llvm.loop.mustprogress"}
!15 = !{i64 3489}
