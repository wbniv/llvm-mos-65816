; ModuleID = '/home/will/llvm-mos-65816/dev/near-store/shapes.c'
source_filename = "/home/will/llvm-mos-65816/dev/near-store/shapes.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@g = dso_local local_unnamed_addr global i16 0, align 1
@vg = dso_local global i16 0, align 1
@arr = dso_local local_unnamed_addr global [128 x i16] zeroinitializer, align 1
@h = dso_local local_unnamed_addr global i16 0, align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none, target_mem: none)
define dso_local void @set(i16 noundef zeroext %0) local_unnamed_addr #0 {
  store i16 %0, ptr @g, align 1, !tbaa !6
  ret void
}

; Function Attrs: nofree norecurse nounwind memory(readwrite, argmem: none, target_mem: none)
define dso_local void @vset(i16 noundef zeroext %0) local_unnamed_addr #1 {
  store volatile i16 %0, ptr @vg, align 1, !tbaa !6
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define dso_local void @pset(ptr noundef writeonly captures(none) initializes((0, 2)) %0, i16 noundef zeroext %1) local_unnamed_addr #2 {
  store i16 %1, ptr %0, align 1, !tbaa !6
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none, target_mem: none)
define dso_local void @iset(i8 noundef zeroext %0, i16 noundef zeroext %1) local_unnamed_addr #0 {
  %3 = zext i8 %0 to i16
  %4 = getelementptr inbounds nuw [2 x i8], ptr @arr, i16 %3
  store i16 %1, ptr %4, align 1, !tbaa !6
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none)
define dso_local void @copy() local_unnamed_addr #3 {
  %1 = load i16, ptr @h, align 1, !tbaa !6
  store i16 %1, ptr @g, align 1, !tbaa !6
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none, target_mem: none)
define dso_local void @add(i16 noundef zeroext %0) local_unnamed_addr #0 {
  %2 = add i16 %0, 42
  store i16 %2, ptr @g, align 1, !tbaa !6
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none, target_mem: none)
define dso_local void @bit(i16 noundef zeroext %0) local_unnamed_addr #0 {
  %2 = xor i16 %0, 4660
  store i16 %2, ptr @g, align 1, !tbaa !6
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none, target_mem: none)
define dso_local void @zero() local_unnamed_addr #0 {
  store i16 0, ptr @g, align 1, !tbaa !6
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none, target_mem: none)
define dso_local void @multiple(i16 noundef zeroext %0) local_unnamed_addr #0 {
  store i16 %0, ptr @g, align 1, !tbaa !6
  store i16 %0, ptr @h, align 1, !tbaa !6
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none, target_mem: none)
define dso_local noundef zeroext i16 @mixed(i16 noundef zeroext %0) local_unnamed_addr #0 {
  store i16 %0, ptr @g, align 1, !tbaa !6
  %2 = add i16 %0, 1
  ret i16 %2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none, target_mem: none)
define dso_local noundef zeroext i16 @passthrough(i16 noundef returned zeroext %0) local_unnamed_addr #0 {
  store i16 %0, ptr @g, align 1, !tbaa !6
  ret i16 %0
}

; Function Attrs: nounwind
define dso_local void @callresult() local_unnamed_addr #4 {
  %1 = tail call zeroext i16 @f() #6
  store i16 %1, ptr @g, align 1, !tbaa !6
  ret void
}

declare dso_local zeroext i16 @f() local_unnamed_addr #5

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #1 = { nofree norecurse nounwind memory(readwrite, argmem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #2 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #3 = { mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #5 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #6 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !7, i64 0}
!7 = !{!"short", !4, i64 0}
