; ModuleID = '/home/will/llvm-mos-65816/dev/near-store/context.c'
source_filename = "/home/will/llvm-mos-65816/dev/near-store/context.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@g = dso_local global i16 0, align 1
@h = dso_local global i16 0, align 1

; Function Attrs: nounwind
define dso_local void @across_call(i16 noundef zeroext %0) local_unnamed_addr #0 {
  tail call void @opaque() #4
  store volatile i16 %0, ptr @g, align 1, !tbaa !6
  ret void
}

declare dso_local void @opaque() local_unnamed_addr #1

; Function Attrs: nofree norecurse nounwind memory(readwrite, argmem: none, target_mem: none)
define dso_local void @native_context(i16 noundef zeroext %0) local_unnamed_addr #2 {
  %2 = load volatile i16, ptr @h, align 1, !tbaa !6
  %3 = add i16 %2, 42
  store volatile i16 %3, ptr @h, align 1, !tbaa !6
  store volatile i16 %0, ptr @g, align 1, !tbaa !6
  ret void
}

; Function Attrs: nounwind
define dso_local void @before_call(i16 noundef zeroext %0) local_unnamed_addr #0 {
  store volatile i16 %0, ptr @g, align 1, !tbaa !6
  tail call void @opaque() #4
  ret void
}

; Function Attrs: nounwind
define dso_local void @conditional(i16 noundef zeroext %0, i8 noundef zeroext %1) local_unnamed_addr #0 {
  %3 = icmp eq i8 %1, 0
  br i1 %3, label %5, label %4

4:                                                ; preds = %2
  tail call void @opaque() #4
  br label %5

5:                                                ; preds = %4, %2
  store volatile i16 %0, ptr @g, align 1, !tbaa !6
  ret void
}

; Function Attrs: nofree norecurse nounwind memory(readwrite, argmem: write, target_mem: none)
define dso_local void @through_pointer(i16 noundef zeroext %0, ptr noundef writeonly captures(none) initializes((0, 2)) %1) local_unnamed_addr #3 {
  store i16 %0, ptr %1, align 1, !tbaa !6
  store volatile i16 %0, ptr @g, align 1, !tbaa !6
  ret void
}

attributes #0 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #2 = { nofree norecurse nounwind memory(readwrite, argmem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #3 = { nofree norecurse nounwind memory(readwrite, argmem: write, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !7, i64 0}
!7 = !{!"short", !4, i64 0}
