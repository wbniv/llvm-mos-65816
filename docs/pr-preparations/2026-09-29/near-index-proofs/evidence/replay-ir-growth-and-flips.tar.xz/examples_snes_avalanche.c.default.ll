; ModuleID = '/work/examples/snes/avalanche.c'
source_filename = "/work/examples/snes/avalanche.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@.str = private unnamed_addr constant [7 x i8] c"64-BIT\00", align 1
@.str.1 = private unnamed_addr constant [10 x i8] c"AVALANCHE\00", align 1
@m7_zero = internal constant i8 0, align 1
@corpus_result = dso_local global i16 0, align 1
@_m7t_zero = internal global i8 0, align 1
@FONT16 = internal unnamed_addr constant [2048 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 192, i16 192, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 768, i16 768, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 -4096, i16 -4096, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3840, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 3312, i16 15360, i16 15360, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 28, i16 28, i16 796, i16 127, i16 127, i16 796, i16 796, i16 127, i16 112, i16 112, i16 3184, i16 252, i16 252, i16 -28816, i16 -28816, i16 252, i16 127, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 0, i16 0, i16 252, i16 -28816, i16 -28816, i16 3184, i16 7168, i16 7168, i16 0, i16 0, i16 3, i16 63, i16 123, i16 1147, i16 63, i16 4111, i16 3075, i16 123, i16 192, i16 248, i16 8414, i16 16064, i16 2040, i16 248, i16 8414, i16 8414, i16 63, i16 7171, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 2040, i16 14272, i16 -512, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3585, i16 3, i16 7, i16 28, i16 56, i16 1904, i16 3808, i16 7392, i16 14528, i16 14464, i16 28672, i16 14, i16 284, i16 824, i16 1792, i16 3584, i16 0, i16 0, i16 0, i16 -8162, i16 -16354, i16 -32482, i16 286, i16 1792, i16 1792, i16 0, i16 0, i16 15, i16 31, i16 828, i16 828, i16 573, i16 31, i16 31, i16 63, i16 192, i16 224, i16 240, i16 2288, i16 7392, i16 15488, i16 30720, i16 -32648, i16 382, i16 3060, i16 3825, i16 1275, i16 127, i16 63, i16 7936, i16 3840, i16 248, i16 3824, i16 7904, i16 7392, i16 4332, i16 12492, i16 -1280, i16 -3328, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 7, i16 15, i16 15, i16 15, i16 15, i16 15, i16 240, i16 192, i16 15488, i16 -4096, i16 -8192, i16 -16384, i16 -16384, i16 -16384, i16 15, i16 7, i16 3, i16 256, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 16512, i16 192, i16 240, i16 -4096, i16 15360, i16 0, i16 0, i16 15, i16 3, i16 513, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 224, i16 240, i16 2288, i16 3312, i16 3312, i16 3312, i16 0, i16 1, i16 3, i16 15, i16 0, i16 768, i16 0, i16 0, i16 3312, i16 7392, i16 15552, i16 30720, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 51, i16 31, i16 15, i16 1027, i16 0, i16 0, i16 192, i16 192, i16 12492, i16 252, i16 1016, i16 16320, i16 15, i16 31, i16 51, i16 1027, i16 3072, i16 0, i16 0, i16 0, i16 1784, i16 252, i16 13004, i16 16320, i16 -3328, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 3, i16 63, i16 63, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 248, i16 248, i16 63, i16 3075, i16 3075, i16 3, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 16064, i16 16064, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 286, i16 828, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 28800, i16 -4096, i16 -8192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 -512, i16 -512, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7360, i16 14464, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7168, i16 14336, i16 28672, i16 -8192, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 828, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 15, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 1, i16 3, i16 15, i16 15, i16 513, i16 513, i16 1, i16 1, i16 240, i16 240, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 1, i16 1, i16 1, i16 1, i16 1, i16 1, i16 0, i16 0, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 31744, i16 31744, i16 15, i16 31, i16 318, i16 828, i16 3840, i16 3840, i16 3, i16 15, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 63, i16 510, i16 4080, i16 31, i16 318, i16 318, i16 318, i16 63, i16 63, i16 3840, i16 3840, i16 32640, i16 -1024, i16 -8192, i16 -32768, i16 255, i16 255, i16 -256, i16 -256, i16 15, i16 63, i16 824, i16 3840, i16 2055, i16 7, i16 256, i16 256, i16 252, i16 254, i16 -8161, i16 -4081, i16 510, i16 1020, i16 -7906, i16 -4081, i16 0, i16 0, i16 56, i16 60, i16 63, i16 31, i16 3840, i16 1792, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 15, i16 286, i16 62, i16 126, i16 510, i16 510, i16 8670, i16 24990, i16 -7906, i16 -7906, i16 828, i16 828, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 -16098, i16 -32482, i16 255, i16 255, i16 -7906, i16 -7906, i16 1792, i16 1792, i16 31, i16 63, i16 828, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 254, i16 254, i16 -256, i16 -256, i16 252, i16 254, i16 -8161, i16 -4081, i16 0, i16 0, i16 60, i16 62, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 63, i16 63, i16 318, i16 828, i16 254, i16 255, i16 -2041, i16 -256, i16 508, i16 254, i16 -4081, i16 -2041, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 -32761, i16 7, i16 7, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 31, i16 318, i16 892, i16 0, i16 1, i16 3, i16 7, i16 7, i16 7, i16 256, i16 256, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 28800, i16 -8192, i16 -8192, i16 15, i16 31, i16 828, i16 828, i16 828, i16 31, i16 15, i16 796, i16 252, i16 254, i16 -4081, i16 -4081, i16 15, i16 510, i16 1020, i16 -3826, i16 828, i16 828, i16 828, i16 828, i16 31, i16 15, i16 1792, i16 768, i16 -4081, i16 15, i16 15, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 318, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 31, i16 31, i16 15, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 270, i16 796, i16 824, i16 1792, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 15, i16 60, i16 828, i16 0, i16 0, i16 60, i16 240, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 15360, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 60, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 60, i16 0, i16 3, i16 15, i16 60, i16 768, i16 3840, i16 0, i16 0, i16 4080, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 31, i16 63, i16 828, i16 3840, i16 3840, i16 7, i16 7, i16 7, i16 240, i16 248, i16 -32644, i16 -32132, i16 2040, i16 4080, i16 16064, i16 31872, i16 256, i16 256, i16 7, i16 7, i16 7, i16 256, i16 256, i16 0, i16 -4096, i16 -8192, i16 128, i16 128, i16 24704, i16 -8192, i16 -8192, i16 0, i16 31, i16 63, i16 828, i16 573, i16 573, i16 573, i16 573, i16 573, i16 248, i16 252, i16 -15812, i16 4590, i16 494, i16 4590, i16 1020, i16 1016, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 0, i16 0, i16 0, i16 32512, i16 764, i16 248, i16 -256, i16 -512, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 892, i16 1020, i16 1020, i16 255, i16 255, i16 224, i16 240, i16 -32648, i16 -16324, i16 -32196, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -28928, i16 1792, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 0, i16 0, i16 28, i16 60, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -8164, i16 -3572, i16 -30976, i16 768, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 8988, i16 8988, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 60, i16 60, i16 828, i16 828, i16 828, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 255, i16 255, i16 16128, i16 16128, i16 12480, i16 12480, i16 12480, i16 12480, i16 252, i16 252, i16 -256, i16 -256, i16 63, i16 63, i16 3075, i16 3075, i16 3, i16 3, i16 51, i16 51, i16 252, i16 252, i16 4080, i16 4080, i16 3312, i16 3312, i16 3312, i16 3312, i16 3123, i16 3123, i16 63, i16 63, i16 31, i16 15, i16 1792, i16 768, i16 3312, i16 3312, i16 3312, i16 3312, i16 7392, i16 15552, i16 -2048, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 765, i16 255, i16 255, i16 255, i16 28, i16 60, i16 1912, i16 4080, i16 7904, i16 15552, i16 30848, i16 12480, i16 255, i16 765, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 224, i16 240, i16 248, i16 124, i16 572, i16 828, i16 3840, i16 3840, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 0, i16 0, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 248, i16 252, i16 254, i16 2295, i16 3315, i16 3315, i16 3315, i16 3315, i16 60, i16 124, i16 1020, i16 988, i16 9116, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 15360, i16 15360, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 -6400, i16 -6400, i16 240, i16 248, i16 252, i16 254, i16 255, i16 255, i16 2295, i16 3315, i16 60, i16 60, i16 828, i16 828, i16 828, i16 956, i16 1020, i16 1020, i16 3313, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 15360, i16 15360, i16 1020, i16 1020, i16 892, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -31972, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -512, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 224, i16 240, i16 -32648, i16 -15304, i16 -31176, i16 1592, i16 1592, i16 1592, i16 765, i16 765, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 1784, i16 1784, i16 17976, i16 1656, i16 764, i16 764, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 63, i16 127, i16 2040, i16 4080, i16 1784, i16 255, i16 127, i16 63, i16 248, i16 252, i16 -15812, i16 -256, i16 3840, i16 240, i16 248, i16 252, i16 7936, i16 3840, i16 224, i16 255, i16 255, i16 127, i16 16128, i16 7936, i16 -32132, i16 -15556, i16 892, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 -4096, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 28, i16 28, i16 796, i16 796, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 510, i16 255, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 828, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 248, i16 248, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 124, i16 124, i16 1912, i16 1912, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 572, i16 63, i16 31, i16 15, i16 7, i16 768, i16 256, i16 1656, i16 3824, i16 3824, i16 7392, i16 15552, i16 30848, i16 -4096, i16 -8192, i16 243, i16 243, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 156, i16 156, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 2295, i16 255, i16 510, i16 892, i16 16128, i16 7936, i16 25500, i16 25500, i16 9180, i16 1020, i16 1020, i16 -30856, i16 -16640, i16 7680, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 15, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 14528, i16 31, i16 63, i16 892, i16 2040, i16 4080, i16 3824, i16 15360, i16 15360, i16 4320, i16 240, i16 248, i16 -32644, i16 572, i16 828, i16 3840, i16 3840, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 7, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 7, i16 7, i16 7, i16 7, i16 7, i16 7, i16 256, i16 256, i16 28800, i16 24704, i16 24704, i16 24704, i16 24704, i16 24704, i16 -8192, i16 -8192, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 1, i16 3, i16 7, i16 252, i16 252, i16 1020, i16 -31876, i16 2040, i16 4080, i16 7904, i16 15552, i16 15, i16 31, i16 318, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 30848, i16 -4096, i16 -8192, i16 252, i16 252, i16 1020, i16 -256, i16 -256, i16 31, i16 31, i16 286, i16 286, i16 286, i16 286, i16 286, i16 286, i16 224, i16 224, i16 -2048, i16 -2048, i16 -32768, i16 -32768, i16 -32768, i16 -32768, i16 286, i16 286, i16 286, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 -32768, i16 -32768, i16 -32768, i16 224, i16 224, i16 -2048, i16 -2048, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 3, i16 1, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 128, i16 192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 768, i16 256, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 0, i16 0, i16 0, i16 224, i16 224, i16 2288, i16 2288, i16 3312, i16 3312, i16 3312, i16 3312, i16 0, i16 0, i16 0, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 3312, i16 3312, i16 3312, i16 7392, i16 7392, i16 -2048, i16 -2048, i16 0, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1840, i16 3584, i16 3072, i16 192, i16 224, i16 -32656, i16 -16328, i16 -32740, i16 524, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 127, i16 127, i16 7936, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 -512], align 1
@SINCOS = internal unnamed_addr constant [256 x i16] [i16 0, i16 6, i16 13, i16 19, i16 25, i16 31, i16 38, i16 44, i16 50, i16 56, i16 62, i16 68, i16 74, i16 80, i16 86, i16 92, i16 98, i16 104, i16 109, i16 115, i16 121, i16 126, i16 132, i16 137, i16 142, i16 147, i16 152, i16 157, i16 162, i16 167, i16 172, i16 177, i16 181, i16 185, i16 190, i16 194, i16 198, i16 202, i16 206, i16 209, i16 213, i16 216, i16 220, i16 223, i16 226, i16 229, i16 231, i16 234, i16 237, i16 239, i16 241, i16 243, i16 245, i16 247, i16 248, i16 250, i16 251, i16 252, i16 253, i16 254, i16 255, i16 255, i16 256, i16 256, i16 256, i16 256, i16 256, i16 255, i16 255, i16 254, i16 253, i16 252, i16 251, i16 250, i16 248, i16 247, i16 245, i16 243, i16 241, i16 239, i16 237, i16 234, i16 231, i16 229, i16 226, i16 223, i16 220, i16 216, i16 213, i16 209, i16 206, i16 202, i16 198, i16 194, i16 190, i16 185, i16 181, i16 177, i16 172, i16 167, i16 162, i16 157, i16 152, i16 147, i16 142, i16 137, i16 132, i16 126, i16 121, i16 115, i16 109, i16 104, i16 98, i16 92, i16 86, i16 80, i16 74, i16 68, i16 62, i16 56, i16 50, i16 44, i16 38, i16 31, i16 25, i16 19, i16 13, i16 6, i16 0, i16 -6, i16 -13, i16 -19, i16 -25, i16 -31, i16 -38, i16 -44, i16 -50, i16 -56, i16 -62, i16 -68, i16 -74, i16 -80, i16 -86, i16 -92, i16 -98, i16 -104, i16 -109, i16 -115, i16 -121, i16 -126, i16 -132, i16 -137, i16 -142, i16 -147, i16 -152, i16 -157, i16 -162, i16 -167, i16 -172, i16 -177, i16 -181, i16 -185, i16 -190, i16 -194, i16 -198, i16 -202, i16 -206, i16 -209, i16 -213, i16 -216, i16 -220, i16 -223, i16 -226, i16 -229, i16 -231, i16 -234, i16 -237, i16 -239, i16 -241, i16 -243, i16 -245, i16 -247, i16 -248, i16 -250, i16 -251, i16 -252, i16 -253, i16 -254, i16 -255, i16 -255, i16 -256, i16 -256, i16 -256, i16 -256, i16 -256, i16 -255, i16 -255, i16 -254, i16 -253, i16 -252, i16 -251, i16 -250, i16 -248, i16 -247, i16 -245, i16 -243, i16 -241, i16 -239, i16 -237, i16 -234, i16 -231, i16 -229, i16 -226, i16 -223, i16 -220, i16 -216, i16 -213, i16 -209, i16 -206, i16 -202, i16 -198, i16 -194, i16 -190, i16 -185, i16 -181, i16 -177, i16 -172, i16 -167, i16 -162, i16 -157, i16 -152, i16 -147, i16 -142, i16 -137, i16 -132, i16 -126, i16 -121, i16 -115, i16 -109, i16 -104, i16 -98, i16 -92, i16 -86, i16 -80, i16 -74, i16 -68, i16 -62, i16 -56, i16 -50, i16 -44, i16 -38, i16 -31, i16 -25, i16 -19, i16 -13, i16 -6], align 1
@pal = internal unnamed_addr global [9 x i16] zeroinitializer, align 1
@mat = internal unnamed_addr global [3584 x i8] zeroinitializer, align 1
@pcount = internal unnamed_addr global i8 0, align 1
@pshift = internal unnamed_addr global i8 0, align 1
@g_done = internal unnamed_addr global i1 false, align 1
@g_k = internal unnamed_addr global i16 0, align 1
@g_s = internal unnamed_addr global i64 81985529216486895, align 8
@g_acc = internal unnamed_addr global i64 -1, align 8

; Function Attrs: nofree norecurse noreturn nounwind optsize memory(readwrite, target_mem: none)
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  store volatile i8 -113, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  br label %1

1:                                                ; preds = %5, %0
  %2 = phi i16 [ 8449, %0 ], [ %6, %5 ]
  switch i16 %2, label %3 [
    i16 8452, label %5
    i16 8470, label %5
    i16 8471, label %5
    i16 8472, label %5
    i16 8473, label %5
    i16 8481, label %5
    i16 8482, label %5
  ]

3:                                                ; preds = %1
  %4 = inttoptr i16 %2 to ptr
  store volatile i8 0, ptr %4, align 1, !tbaa !6
  br label %5

5:                                                ; preds = %3, %1, %1, %1, %1, %1, %1, %1
  %6 = add nuw nsw i16 %2, 1
  %7 = icmp eq i16 %6, 8500
  br i1 %7, label %8, label %1, !llvm.loop !7

8:                                                ; preds = %5
  store volatile i8 0, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !6
  store volatile i8 -113, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  br label %9

9:                                                ; preds = %13, %8
  %10 = phi i16 [ 8449, %8 ], [ %14, %13 ]
  switch i16 %10, label %11 [
    i16 8452, label %13
    i16 8470, label %13
    i16 8471, label %13
    i16 8472, label %13
    i16 8473, label %13
    i16 8481, label %13
    i16 8482, label %13
  ]

11:                                               ; preds = %9
  %12 = inttoptr i16 %10 to ptr
  store volatile i8 0, ptr %12, align 1, !tbaa !6
  br label %13

13:                                               ; preds = %11, %9, %9, %9, %9, %9, %9, %9
  %14 = add nuw nsw i16 %10, 1
  %15 = icmp eq i16 %14, 8500
  br i1 %15, label %16, label %9, !llvm.loop !7

16:                                               ; preds = %13
  store volatile i8 0, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 0, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  store volatile i8 8, ptr inttoptr (i16 17152 to ptr), align 256, !tbaa !6
  store volatile i8 24, ptr inttoptr (i16 17153 to ptr), align 1, !tbaa !6
  store volatile i8 ptrtoint (ptr @_m7t_zero to i8), ptr inttoptr (i16 17154 to ptr), align 2, !tbaa !6
  %17 = lshr i16 ptrtoint (ptr @_m7t_zero to i16), 8
  %18 = trunc nuw i16 %17 to i8
  store volatile i8 %18, ptr inttoptr (i16 17155 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17156 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17157 to ptr), align 1, !tbaa !6
  store volatile i8 64, ptr inttoptr (i16 17158 to ptr), align 2, !tbaa !6
  store volatile i8 1, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 0, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %19

19:                                               ; preds = %27, %16
  %20 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 16), %16 ], [ %30, %27 ]
  %21 = phi ptr [ @FONT16, %16 ], [ %29, %27 ]
  %22 = phi i16 [ 0, %16 ], [ %28, %27 ]
  br label %23

23:                                               ; preds = %32, %19
  %24 = phi i8 [ %37, %32 ], [ 0, %19 ]
  %25 = phi ptr [ %35, %32 ], [ %21, %19 ]
  %26 = phi i8 [ %33, %32 ], [ 0, %19 ]
  br label %38

27:                                               ; preds = %32
  %28 = add nuw nsw i16 %22, 1
  %29 = getelementptr i8, ptr %21, i16 64
  %30 = getelementptr i8, ptr %20, i16 64
  %31 = icmp eq i16 %28, 64
  br i1 %31, label %63, label %19, !llvm.loop !9

32:                                               ; preds = %45
  %33 = add nuw nsw i8 %26, 1
  %34 = zext nneg i8 %24 to i16
  %35 = getelementptr i8, ptr %20, i16 %34
  %36 = icmp eq i8 %33, 4
  %37 = add nuw nsw i8 %24, 16
  br i1 %36, label %27, label %23, !llvm.loop !10

38:                                               ; preds = %45, %23
  %39 = phi i8 [ 0, %23 ], [ %48, %45 ]
  %40 = phi i8 [ 0, %23 ], [ %46, %45 ]
  %41 = zext nneg i8 %39 to i16
  %42 = getelementptr i8, ptr %25, i16 %41
  %43 = load i16, ptr %42, align 1, !tbaa !2
  %44 = lshr i16 %43, 8
  br label %49

45:                                               ; preds = %59
  %46 = add nuw nsw i8 %40, 1
  %47 = icmp eq i8 %46, 8
  %48 = add nuw nsw i8 %39, 2
  br i1 %47, label %32, label %38, !llvm.loop !11

49:                                               ; preds = %59, %38
  %50 = phi i8 [ 0, %38 ], [ %61, %59 ]
  %51 = lshr exact i8 -128, %50
  %52 = zext i8 %51 to i16
  %53 = and i16 %43, %52
  %54 = icmp eq i16 %53, 0
  br i1 %54, label %55, label %59

55:                                               ; preds = %49
  %56 = and i16 %44, %52
  %57 = icmp eq i16 %56, 0
  %58 = select i1 %57, i8 0, i8 2
  br label %59

59:                                               ; preds = %55, %49
  %60 = phi i8 [ %58, %55 ], [ 1, %49 ]
  store volatile i8 %60, ptr inttoptr (i16 8473 to ptr), align 1, !tbaa !6
  %61 = add nuw nsw i8 %50, 1
  %62 = icmp eq i8 %61, 8
  br i1 %62, label %45, label %49, !llvm.loop !12

63:                                               ; preds = %27
  tail call fastcc void @_m7t_write_line(ptr noundef nonnull @.str.1, i8 noundef zeroext 13) #5
  tail call fastcc void @_m7t_write_line(ptr noundef nonnull @.str, i8 noundef zeroext 10) #5
  store volatile i8 0, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  store volatile i8 66, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 20, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -1, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 127, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -124, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -127, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !6
  store volatile i8 7, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8474 to ptr), align 2, !tbaa !6
  store volatile i8 1, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8474 to ptr), align 2, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8479 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8479 to ptr), align 1, !tbaa !6
  store volatile i8 112, ptr inttoptr (i16 8480 to ptr), align 32, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8480 to ptr), align 32, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8461 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8461 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8462 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8462 to ptr), align 2, !tbaa !6
  br label %64

64:                                               ; preds = %94, %63
  %65 = phi i8 [ 0, %63 ], [ %84, %94 ]
  %66 = phi i8 [ 0, %63 ], [ %83, %94 ]
  %67 = phi i16 [ 16, %63 ], [ %78, %94 ]
  %68 = sub nsw i16 256, %67
  %69 = ashr i16 %68, 3
  %70 = icmp slt i16 %69, 1
  br i1 %70, label %71, label %72

71:                                               ; preds = %64
  br label %72

72:                                               ; preds = %71, %64
  %73 = phi i16 [ 1, %71 ], [ %69, %64 ]
  %74 = add nsw i16 %73, %67
  %75 = icmp sgt i16 %74, 253
  br i1 %75, label %76, label %77

76:                                               ; preds = %72
  br label %77

77:                                               ; preds = %76, %72
  %78 = phi i16 [ 256, %76 ], [ %74, %72 ]
  %79 = icmp ult i8 %66, 15
  br i1 %79, label %80, label %82

80:                                               ; preds = %77
  %81 = add nuw nsw i8 %66, 1
  br label %82

82:                                               ; preds = %80, %77
  %83 = phi i8 [ %81, %80 ], [ %66, %77 ]
  %84 = add i8 %65, 2
  %85 = icmp sgt i8 %84, -1
  br i1 %85, label %88, label %86

86:                                               ; preds = %82
  %87 = sub nuw i8 -3, %65
  br label %88

88:                                               ; preds = %86, %82
  %89 = phi i8 [ %87, %86 ], [ %84, %82 ]
  %90 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %91

91:                                               ; preds = %91, %88
  %92 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %93 = icmp sgt i8 %92, -1
  br i1 %93, label %91, label %94, !llvm.loop !13

94:                                               ; preds = %91
  %95 = lshr i8 %89, 4
  %96 = add nuw nsw i8 %95, 22
  %97 = zext nneg i8 %96 to i16
  %98 = mul nuw nsw i16 %97, 1057
  %99 = trunc i16 %78 to i8
  store volatile i8 %99, ptr inttoptr (i16 8475 to ptr), align 1, !tbaa !6
  %100 = lshr i16 %78, 8
  %101 = trunc nuw i16 %100 to i8
  store volatile i8 %101, ptr inttoptr (i16 8475 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8476 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8476 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8477 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8477 to ptr), align 1, !tbaa !6
  store volatile i8 %99, ptr inttoptr (i16 8478 to ptr), align 2, !tbaa !6
  store volatile i8 %101, ptr inttoptr (i16 8478 to ptr), align 2, !tbaa !6
  store volatile i8 1, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  %102 = trunc i16 %98 to i8
  store volatile i8 %102, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  %103 = lshr i16 %98, 8
  %104 = trunc nuw nsw i16 %103 to i8
  store volatile i8 %104, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 %83, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  %105 = icmp eq i16 %78, 256
  %106 = icmp eq i8 %83, 15
  %107 = select i1 %105, i1 %106, i1 false
  br i1 %107, label %108, label %64

108:                                              ; preds = %94, %121
  %109 = phi i8 [ %111, %121 ], [ %84, %94 ]
  %110 = phi i16 [ %129, %121 ], [ 0, %94 ]
  %111 = add i8 %109, 2
  %112 = icmp sgt i8 %111, -1
  br i1 %112, label %115, label %113

113:                                              ; preds = %108
  %114 = sub nuw i8 -3, %109
  br label %115

115:                                              ; preds = %113, %108
  %116 = phi i8 [ %114, %113 ], [ %111, %108 ]
  %117 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %118

118:                                              ; preds = %118, %115
  %119 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %120 = icmp sgt i8 %119, -1
  br i1 %120, label %118, label %121, !llvm.loop !13

121:                                              ; preds = %118
  %122 = lshr i8 %116, 4
  %123 = add nuw nsw i8 %122, 22
  %124 = zext nneg i8 %123 to i16
  %125 = mul nuw nsw i16 %124, 1057
  store volatile i8 0, ptr inttoptr (i16 8475 to ptr), align 1, !tbaa !6
  store volatile i8 1, ptr inttoptr (i16 8475 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8476 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8476 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8477 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8477 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8478 to ptr), align 2, !tbaa !6
  store volatile i8 1, ptr inttoptr (i16 8478 to ptr), align 2, !tbaa !6
  store volatile i8 1, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  %126 = trunc i16 %125 to i8
  store volatile i8 %126, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  %127 = lshr i16 %125, 8
  %128 = trunc nuw nsw i16 %127 to i8
  store volatile i8 %128, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 15, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  %129 = add nuw nsw i16 %110, 1
  %130 = icmp eq i16 %129, 90
  br i1 %130, label %131, label %108, !llvm.loop !14

131:                                              ; preds = %121, %161
  %132 = phi i16 [ %141, %161 ], [ 256, %121 ]
  %133 = phi i8 [ %136, %161 ], [ 0, %121 ]
  %134 = phi i8 [ %149, %161 ], [ 15, %121 ]
  %135 = phi i8 [ %180, %161 ], [ 0, %121 ]
  %136 = add i8 %133, 4
  %137 = add nsw i16 %132, -4
  %138 = icmp slt i16 %132, 4
  br i1 %138, label %139, label %140

139:                                              ; preds = %131
  br label %140

140:                                              ; preds = %139, %131
  %141 = phi i16 [ 0, %139 ], [ %137, %131 ]
  %142 = and i8 %135, 3
  %143 = icmp eq i8 %142, 0
  br i1 %143, label %144, label %148

144:                                              ; preds = %140
  %145 = icmp ugt i8 %134, 4
  br i1 %145, label %146, label %148

146:                                              ; preds = %144
  %147 = add i8 %134, -1
  br label %148

148:                                              ; preds = %146, %144, %140
  %149 = phi i8 [ %147, %146 ], [ %134, %144 ], [ %134, %140 ]
  %150 = zext i8 %136 to i16
  %151 = add i8 %133, 68
  %152 = zext i8 %151 to i16
  %153 = getelementptr inbounds nuw [2 x i8], ptr @SINCOS, i16 %152
  %154 = load i16, ptr %153, align 1, !tbaa !2
  %155 = getelementptr inbounds nuw [2 x i8], ptr @SINCOS, i16 %150
  %156 = load i16, ptr %155, align 1, !tbaa !2
  %157 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %158

158:                                              ; preds = %158, %148
  %159 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %160 = icmp sgt i8 %159, -1
  br i1 %160, label %158, label %161, !llvm.loop !13

161:                                              ; preds = %158
  %162 = sext i16 %154 to i32
  %163 = zext nneg i16 %141 to i32
  %164 = mul nsw i32 %162, %163
  %165 = lshr i32 %164, 8
  %166 = sext i16 %156 to i32
  %167 = mul nsw i32 %166, %163
  %168 = sub nsw i32 0, %167
  %169 = lshr i32 %168, 8
  %170 = lshr i32 %167, 8
  %171 = trunc i32 %165 to i8
  store volatile i8 %171, ptr inttoptr (i16 8475 to ptr), align 1, !tbaa !6
  %172 = lshr i32 %164, 16
  %173 = trunc i32 %172 to i8
  store volatile i8 %173, ptr inttoptr (i16 8475 to ptr), align 1, !tbaa !6
  %174 = trunc i32 %169 to i8
  store volatile i8 %174, ptr inttoptr (i16 8476 to ptr), align 4, !tbaa !6
  %175 = lshr i32 %168, 16
  %176 = trunc i32 %175 to i8
  store volatile i8 %176, ptr inttoptr (i16 8476 to ptr), align 4, !tbaa !6
  %177 = trunc i32 %170 to i8
  store volatile i8 %177, ptr inttoptr (i16 8477 to ptr), align 1, !tbaa !6
  %178 = lshr i32 %167, 16
  %179 = trunc i32 %178 to i8
  store volatile i8 %179, ptr inttoptr (i16 8477 to ptr), align 1, !tbaa !6
  store volatile i8 %171, ptr inttoptr (i16 8478 to ptr), align 2, !tbaa !6
  store volatile i8 %173, ptr inttoptr (i16 8478 to ptr), align 2, !tbaa !6
  store volatile i8 %149, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  %180 = add nuw nsw i8 %135, 1
  %181 = icmp eq i8 %180, 64
  br i1 %181, label %182, label %131, !llvm.loop !15

182:                                              ; preds = %161
  store volatile i8 -128, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 0, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  store volatile i8 8, ptr inttoptr (i16 17152 to ptr), align 256, !tbaa !6
  store volatile i8 24, ptr inttoptr (i16 17153 to ptr), align 1, !tbaa !6
  store volatile i8 ptrtoint (ptr @_m7t_zero to i8), ptr inttoptr (i16 17154 to ptr), align 2, !tbaa !6
  store volatile i8 %18, ptr inttoptr (i16 17155 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17156 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17157 to ptr), align 1, !tbaa !6
  store volatile i8 64, ptr inttoptr (i16 17158 to ptr), align 2, !tbaa !6
  store volatile i8 1, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 0, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  store volatile i8 8, ptr inttoptr (i16 17152 to ptr), align 256, !tbaa !6
  store volatile i8 25, ptr inttoptr (i16 17153 to ptr), align 1, !tbaa !6
  store volatile i8 ptrtoint (ptr @_m7t_zero to i8), ptr inttoptr (i16 17154 to ptr), align 2, !tbaa !6
  store volatile i8 %18, ptr inttoptr (i16 17155 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17156 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17157 to ptr), align 1, !tbaa !6
  store volatile i8 64, ptr inttoptr (i16 17158 to ptr), align 2, !tbaa !6
  store volatile i8 1, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !6
  store volatile i8 7, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8474 to ptr), align 2, !tbaa !6
  store volatile i8 1, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 0, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  store volatile i8 8, ptr inttoptr (i16 17152 to ptr), align 256, !tbaa !6
  store volatile i8 24, ptr inttoptr (i16 17153 to ptr), align 1, !tbaa !6
  store volatile i8 ptrtoint (ptr @m7_zero to i8), ptr inttoptr (i16 17154 to ptr), align 2, !tbaa !6
  %183 = lshr i16 ptrtoint (ptr @m7_zero to i16), 8
  %184 = trunc nuw i16 %183 to i8
  store volatile i8 %184, ptr inttoptr (i16 17155 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17156 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17157 to ptr), align 1, !tbaa !6
  store volatile i8 64, ptr inttoptr (i16 17158 to ptr), align 2, !tbaa !6
  store volatile i8 1, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !6
  br label %185

185:                                              ; preds = %190, %182
  %186 = phi i8 [ 0, %182 ], [ %191, %190 ]
  %187 = zext nneg i8 %186 to i16
  %188 = shl nuw nsw i16 %187, 7
  %189 = shl nuw nsw i8 %186, 3
  br label %193

190:                                              ; preds = %193
  %191 = add nuw nsw i8 %186, 1
  %192 = icmp eq i8 %191, 7
  br i1 %192, label %200, label %185, !llvm.loop !16

193:                                              ; preds = %193, %185
  %194 = phi i8 [ 0, %185 ], [ %198, %193 ]
  %195 = zext nneg i8 %194 to i16
  %196 = or disjoint i16 %188, %195
  %197 = add nuw nsw i8 %194, %189
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %196, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  store volatile i8 %197, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !6
  %198 = add nuw nsw i8 %194, 1
  %199 = icmp eq i8 %198, 8
  br i1 %199, label %190, label %193, !llvm.loop !17

200:                                              ; preds = %190
  store volatile i8 0, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  br label %201

201:                                              ; preds = %221, %200
  %202 = phi i8 [ 0, %200 ], [ %239, %221 ]
  %203 = phi i8 [ 0, %200 ], [ %237, %221 ]
  %204 = icmp eq i8 %203, 0
  br i1 %204, label %221, label %205

205:                                              ; preds = %201
  %206 = add nuw nsw i8 %203, 7
  %207 = and i8 %206, 7
  %208 = mul nuw nsw i8 %207, 6
  %209 = lshr i8 %208, 3
  %210 = and i8 %208, 6
  %211 = mul nuw i8 %210, 31
  %212 = lshr i8 %211, 3
  switch i8 %209, label %219 [
    i8 0, label %221
    i8 1, label %213
    i8 2, label %215
    i8 3, label %216
    i8 4, label %218
  ]

213:                                              ; preds = %205
  %214 = xor i8 %212, 31
  br label %221

215:                                              ; preds = %205
  br label %221

216:                                              ; preds = %205
  %217 = xor i8 %212, 31
  br label %221

218:                                              ; preds = %205
  br label %221

219:                                              ; preds = %205
  %220 = xor i8 %212, 31
  br label %221

221:                                              ; preds = %219, %218, %216, %215, %213, %205, %201
  %222 = phi i8 [ 0, %218 ], [ 0, %219 ], [ 0, %201 ], [ 31, %213 ], [ 31, %215 ], [ %217, %216 ], [ %212, %205 ]
  %223 = phi i8 [ %212, %218 ], [ 31, %219 ], [ 0, %201 ], [ %214, %213 ], [ 0, %215 ], [ 0, %216 ], [ 31, %205 ]
  %224 = phi i8 [ 31, %218 ], [ %220, %219 ], [ 0, %201 ], [ 0, %213 ], [ %212, %215 ], [ 31, %216 ], [ %209, %205 ]
  %225 = zext nneg i8 %224 to i16
  %226 = shl nuw nsw i16 %225, 10
  %227 = zext nneg i8 %222 to i16
  %228 = shl nuw nsw i16 %227, 5
  %229 = add nuw nsw i16 %226, %228
  %230 = zext nneg i8 %223 to i16
  %231 = or disjoint i16 %229, %230
  %232 = zext nneg i8 %202 to i16
  %233 = getelementptr i8, ptr @pal, i16 %232
  store i16 %231, ptr %233, align 1, !tbaa !2
  %234 = trunc i16 %231 to i8
  store volatile i8 %234, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  %235 = lshr i16 %229, 8
  %236 = trunc nuw nsw i16 %235 to i8
  store volatile i8 %236, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  %237 = add nuw nsw i8 %203, 1
  %238 = icmp eq i8 %237, 9
  %239 = add nuw nsw i8 %202, 2
  br i1 %238, label %240, label %201, !llvm.loop !18

240:                                              ; preds = %221
  store volatile i8 64, ptr inttoptr (i16 8475 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8475 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8476 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8476 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8477 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8477 to ptr), align 1, !tbaa !6
  store volatile i8 64, ptr inttoptr (i16 8478 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8478 to ptr), align 2, !tbaa !6
  store volatile i8 32, ptr inttoptr (i16 8479 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8479 to ptr), align 1, !tbaa !6
  store volatile i8 28, ptr inttoptr (i16 8480 to ptr), align 32, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8480 to ptr), align 32, !tbaa !6
  store volatile i8 -96, ptr inttoptr (i16 8461 to ptr), align 1, !tbaa !6
  store volatile i8 -1, ptr inttoptr (i16 8461 to ptr), align 1, !tbaa !6
  store volatile i8 -84, ptr inttoptr (i16 8462 to ptr), align 2, !tbaa !6
  store volatile i8 -1, ptr inttoptr (i16 8462 to ptr), align 2, !tbaa !6
  store volatile i8 15, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !6
  br label %241

241:                                              ; preds = %240, %241
  %242 = phi i8 [ 0, %240 ], [ %243, %241 ]
  tail call fastcc void @compute_col(i8 noundef zeroext %242, i64 noundef 3395287075146519) #5
  %243 = add nuw nsw i8 %242, 1
  %244 = icmp eq i8 %243, 64
  br i1 %244, label %245, label %241, !llvm.loop !19

245:                                              ; preds = %241, %250
  %246 = phi i64 [ %247, %250 ], [ 3395287075146519, %241 ]
  tail call fastcc void @blit_in() #5
  %247 = add i64 %246, -7046029254386353131
  br label %251

248:                                              ; preds = %317
  %249 = icmp ult i8 %318, 64
  br i1 %249, label %321, label %250

250:                                              ; preds = %321, %248
  br label %245

251:                                              ; preds = %245, %317
  %252 = phi i16 [ 0, %245 ], [ %319, %317 ]
  %253 = phi i8 [ 0, %245 ], [ %318, %317 ]
  %254 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %255

255:                                              ; preds = %255, %251
  %256 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %257 = icmp sgt i8 %256, -1
  br i1 %257, label %255, label %258, !llvm.loop !13

258:                                              ; preds = %255
  %259 = getelementptr inbounds nuw [2 x i8], ptr @SINCOS, i16 %252
  %260 = load i16, ptr %259, align 1, !tbaa !2
  %261 = ashr i16 %260, 5
  %262 = add nsw i16 %261, 64
  %263 = trunc i16 %262 to i8
  store volatile i8 %263, ptr inttoptr (i16 8475 to ptr), align 1, !tbaa !6
  %264 = lshr i16 %262, 8
  %265 = trunc nuw i16 %264 to i8
  store volatile i8 %265, ptr inttoptr (i16 8475 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8476 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8476 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8477 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8477 to ptr), align 1, !tbaa !6
  store volatile i8 %263, ptr inttoptr (i16 8478 to ptr), align 2, !tbaa !6
  store volatile i8 %265, ptr inttoptr (i16 8478 to ptr), align 2, !tbaa !6
  tail call fastcc void @tick_cycle(i8 noundef zeroext 4) #5
  %266 = load i1, ptr @g_done, align 1
  br i1 %266, label %313, label %267

267:                                              ; preds = %258
  %268 = load i16, ptr @g_k, align 1, !tbaa !2
  %269 = load i64, ptr @g_s, align 8
  %270 = load i64, ptr @g_acc, align 8
  %271 = tail call i16 @llvm.umax.i16(i16 %268, i16 256)
  br label %272

272:                                              ; preds = %282, %267
  %273 = phi i1 [ true, %267 ], [ false, %282 ]
  %274 = phi i16 [ %268, %267 ], [ %300, %282 ]
  %275 = phi i64 [ %269, %267 ], [ %293, %282 ]
  %276 = phi i64 [ %270, %267 ], [ %299, %282 ]
  %277 = icmp eq i16 %274, %271
  br i1 %277, label %278, label %282

278:                                              ; preds = %272, %280
  %279 = phi i64 [ %299, %280 ], [ %276, %272 ]
  br label %302

280:                                              ; preds = %282
  %281 = icmp ugt i16 %300, 255
  br i1 %281, label %278, label %313

282:                                              ; preds = %272
  %283 = add i64 %275, -7046029254386353131
  %284 = lshr i64 %283, 30
  %285 = xor i64 %284, %283
  %286 = mul i64 %285, -4658895280553007687
  %287 = lshr i64 %286, 27
  %288 = xor i64 %287, %286
  %289 = mul i64 %288, -7723592293110705685
  %290 = lshr i64 %289, 31
  %291 = xor i64 %290, %289
  %292 = lshr i64 %291, 32
  %293 = xor i64 %292, %291
  store i64 %293, ptr @g_s, align 8, !tbaa !20
  %294 = xor i64 %293, %276
  %295 = lshr i64 %293, 17
  %296 = add i64 %294, %295
  %297 = or i64 %293, 1
  %298 = udiv i64 %296, %297
  %299 = xor i64 %298, %296
  store i64 %299, ptr @g_acc, align 8, !tbaa !20
  %300 = add i16 %274, 1
  store i16 %300, ptr @g_k, align 1, !tbaa !2
  br i1 %273, label %272, label %280, !llvm.loop !22

301:                                              ; preds = %302
  store volatile i16 %310, ptr @corpus_result, align 1, !tbaa !2
  store i1 true, ptr @g_done, align 1
  br label %313

302:                                              ; preds = %302, %278
  %303 = phi i8 [ 0, %278 ], [ %311, %302 ]
  %304 = phi i16 [ 0, %278 ], [ %310, %302 ]
  %305 = shl nuw nsw i8 %303, 4
  %306 = zext nneg i8 %305 to i64
  %307 = lshr i64 %279, %306
  %308 = trunc i64 %307 to i16
  %309 = tail call i16 @llvm.fshl.i16(i16 %304, i16 %304, i16 1)
  %310 = xor i16 %309, %308
  %311 = add nuw nsw i8 %303, 1
  %312 = icmp eq i8 %311, 4
  br i1 %312, label %301, label %302, !llvm.loop !23

313:                                              ; preds = %258, %280, %301
  %314 = icmp ult i8 %253, 64
  br i1 %314, label %315, label %317

315:                                              ; preds = %313
  tail call fastcc void @compute_col(i8 noundef zeroext %253, i64 noundef %247) #5
  %316 = add nuw nsw i8 %253, 1
  br label %317

317:                                              ; preds = %313, %315
  %318 = phi i8 [ %316, %315 ], [ %253, %313 ]
  %319 = add nuw nsw i16 %252, 1
  %320 = icmp eq i16 %319, 150
  br i1 %320, label %248, label %251, !llvm.loop !24

321:                                              ; preds = %248, %321
  %322 = phi i8 [ %323, %321 ], [ %318, %248 ]
  tail call fastcc void @compute_col(i8 noundef zeroext %322, i64 noundef %247) #5
  %323 = add i8 %322, 1
  %324 = icmp eq i8 %323, 64
  br i1 %324, label %250, label %321, !llvm.loop !25
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: none, inaccessiblemem: none, target_mem: none)
define internal fastcc void @compute_col(i8 noundef zeroext %0, i64 noundef %1) unnamed_addr #2 {
  %3 = alloca [4 x i16], align 1
  %4 = zext nneg i8 %0 to i64
  %5 = shl nuw i64 1, %4
  %6 = xor i64 %5, %1
  %7 = add i64 %6, -7046029254386353131
  %8 = lshr i64 %7, 30
  %9 = xor i64 %8, %7
  %10 = mul i64 %9, -4658895280553007687
  %11 = lshr i64 %10, 27
  %12 = xor i64 %11, %10
  %13 = mul i64 %12, -7723592293110705685
  %14 = lshr i64 %13, 31
  %15 = xor i64 %14, %13
  %16 = lshr i64 %15, 32
  %17 = xor i64 %16, %15
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #6
  %18 = trunc i64 %17 to i16
  store i16 %18, ptr %3, align 1, !tbaa !2
  %19 = lshr i64 %17, 16
  %20 = trunc i64 %19 to i16
  %21 = getelementptr inbounds nuw i8, ptr %3, i16 2
  store i16 %20, ptr %21, align 1, !tbaa !2
  %22 = trunc i64 %16 to i16
  %23 = getelementptr inbounds nuw i8, ptr %3, i16 4
  store i16 %22, ptr %23, align 1, !tbaa !2
  %24 = lshr i64 %13, 48
  %25 = trunc nuw i64 %24 to i16
  %26 = getelementptr inbounds nuw i8, ptr %3, i16 6
  store i16 %25, ptr %26, align 1, !tbaa !2
  %27 = zext i8 %0 to i16
  %28 = getelementptr inbounds nuw i8, ptr @mat, i16 %27
  br label %30

29:                                               ; preds = %44
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #6
  ret void

30:                                               ; preds = %2, %44
  %31 = phi i8 [ 0, %2 ], [ %50, %44 ]
  %32 = phi i8 [ 0, %2 ], [ %45, %44 ]
  %33 = phi i8 [ 0, %2 ], [ %46, %44 ]
  %34 = zext nneg i8 %31 to i16
  %35 = getelementptr i8, ptr %3, i16 %34
  %36 = load i16, ptr %35, align 1, !tbaa !2
  %37 = sub nuw nsw i8 56, %32
  br label %38

38:                                               ; preds = %30, %57
  %39 = phi i8 [ %32, %30 ], [ %63, %57 ]
  %40 = phi i8 [ 0, %30 ], [ %62, %57 ]
  %41 = phi i16 [ %36, %30 ], [ %61, %57 ]
  %42 = zext nneg i8 %39 to i16
  %43 = icmp eq i8 %40, %37
  br i1 %43, label %44, label %51

44:                                               ; preds = %57, %38
  %45 = phi i8 [ %63, %57 ], [ %39, %38 ]
  %46 = add nuw nsw i8 %33, 1
  %47 = icmp samesign ult i8 %33, 3
  %48 = icmp ult i8 %45, 56
  %49 = select i1 %47, i1 %48, i1 false
  %50 = add nuw nsw i8 %31, 2
  br i1 %49, label %30, label %29, !llvm.loop !26

51:                                               ; preds = %38
  %52 = and i16 %41, 1
  %53 = icmp eq i16 %52, 0
  br i1 %53, label %57, label %54

54:                                               ; preds = %51
  %55 = udiv i8 %39, 7
  %56 = add nuw nsw i8 %55, 1
  br label %57

57:                                               ; preds = %51, %54
  %58 = phi i8 [ %56, %54 ], [ 0, %51 ]
  %59 = shl nuw nsw i16 %42, 6
  %60 = getelementptr inbounds nuw i8, ptr %28, i16 %59
  store i8 %58, ptr %60, align 1, !tbaa !6
  %61 = lshr i16 %41, 1
  %62 = add nuw nsw i8 %40, 1
  %63 = add nuw nsw i8 %39, 1
  %64 = icmp eq i8 %62, 16
  br i1 %64, label %44, label %38, !llvm.loop !27
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @blit_in() unnamed_addr #3 {
  br label %1

1:                                                ; preds = %0, %22
  %2 = phi i8 [ 0, %0 ], [ %23, %22 ]
  %3 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %4

4:                                                ; preds = %4, %1
  %5 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %6 = icmp sgt i8 %5, -1
  br i1 %6, label %4, label %7, !llvm.loop !13

7:                                                ; preds = %4
  store volatile i8 64, ptr inttoptr (i16 8475 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8475 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8476 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8476 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8477 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8477 to ptr), align 1, !tbaa !6
  store volatile i8 64, ptr inttoptr (i16 8478 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8478 to ptr), align 2, !tbaa !6
  tail call fastcc void @tick_cycle(i8 noundef zeroext 2) #5
  %8 = zext nneg i8 %2 to i16
  %9 = shl nuw nsw i16 %8, 6
  %10 = getelementptr i8, ptr @mat, i16 %9
  %11 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @mat, i16 8), i16 %9
  %12 = sub nuw nsw i8 56, %2
  %13 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @mat, i16 64), i16 %9
  %14 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @mat, i16 72), i16 %9
  br label %15

15:                                               ; preds = %7, %30
  %16 = phi i8 [ 0, %7 ], [ %37, %30 ]
  %17 = phi ptr [ %11, %7 ], [ %35, %30 ]
  %18 = phi ptr [ %10, %7 ], [ %34, %30 ]
  %19 = phi i8 [ %2, %7 ], [ %33, %30 ]
  %20 = phi i8 [ 0, %7 ], [ %32, %30 ]
  %21 = icmp eq i8 %20, %12
  br i1 %21, label %22, label %25

22:                                               ; preds = %30, %15
  %23 = phi i8 [ %33, %30 ], [ %19, %15 ]
  %24 = icmp ult i8 %23, 56
  br i1 %24, label %1, label %59, !llvm.loop !28

25:                                               ; preds = %15
  %26 = and i8 %19, 56
  %27 = shl i8 %19, 3
  %28 = and i8 %27, 56
  %29 = zext nneg i8 %28 to i16
  br label %38

30:                                               ; preds = %46
  %31 = zext i8 %16 to i16
  %32 = add nuw nsw i8 %20, 1
  %33 = add nuw nsw i8 %19, 1
  %34 = getelementptr i8, ptr %13, i16 %31
  %35 = getelementptr i8, ptr %14, i16 %31
  %36 = icmp eq i8 %32, 4
  %37 = add i8 %16, 64
  br i1 %36, label %22, label %15, !llvm.loop !29

38:                                               ; preds = %25, %46
  %39 = phi i8 [ 0, %25 ], [ %51, %46 ]
  %40 = phi ptr [ %18, %25 ], [ %49, %46 ]
  %41 = phi i8 [ 0, %25 ], [ %47, %46 ]
  %42 = or disjoint i8 %41, %26
  %43 = zext nneg i8 %42 to i16
  %44 = shl nuw nsw i16 %43, 6
  %45 = or disjoint i16 %44, %29
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %45, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %52

46:                                               ; preds = %52
  %47 = add nuw nsw i8 %41, 1
  %48 = zext nneg i8 %39 to i16
  %49 = getelementptr i8, ptr %17, i16 %48
  %50 = icmp eq i8 %47, 8
  %51 = add nuw nsw i8 %39, 8
  br i1 %50, label %30, label %38, !llvm.loop !30

52:                                               ; preds = %38, %52
  %53 = phi i8 [ 0, %38 ], [ %57, %52 ]
  %54 = zext nneg i8 %53 to i16
  %55 = getelementptr i8, ptr %40, i16 %54
  %56 = load i8, ptr %55, align 1, !tbaa !6
  store volatile i8 %56, ptr inttoptr (i16 8473 to ptr), align 1, !tbaa !6
  %57 = add nuw nsw i8 %53, 1
  %58 = icmp eq i8 %57, 8
  br i1 %58, label %46, label %52, !llvm.loop !31

59:                                               ; preds = %22
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @_m7t_write_line(ptr noundef readonly captures(address_is_null) %0, i8 noundef zeroext range(i8 10, 14) %1) unnamed_addr #3 {
  %3 = icmp eq ptr %0, null
  br i1 %3, label %61, label %4

4:                                                ; preds = %2, %10
  %5 = phi i8 [ %11, %10 ], [ 0, %2 ]
  %6 = zext nneg i8 %5 to i16
  %7 = getelementptr i8, ptr %0, i16 %6
  %8 = load i8, ptr %7, align 1, !tbaa !6
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %13, label %10

10:                                               ; preds = %4
  %11 = add nuw nsw i8 %5, 1
  %12 = icmp eq i8 %11, 16
  br i1 %12, label %13, label %4, !llvm.loop !32

13:                                               ; preds = %4, %10
  %14 = phi i8 [ %5, %4 ], [ 16, %10 ]
  %15 = shl nuw i8 %14, 1
  %16 = zext i8 %15 to i16
  %17 = sub nsw i16 32, %16
  %18 = lshr exact i16 %17, 1
  store volatile i8 0, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  %19 = zext nneg i8 %1 to i16
  %20 = shl nuw nsw i16 %19, 7
  %21 = and i16 %18, 255
  %22 = add nuw nsw i16 %21, %20
  store volatile i16 %22, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %23 = icmp eq i8 %14, 0
  br i1 %23, label %24, label %28

24:                                               ; preds = %13
  %25 = add nuw nsw i16 %22, 128
  store volatile i16 %25, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %61

26:                                               ; preds = %39
  %27 = add nuw nsw i16 %22, 128
  store volatile i16 %27, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %44

28:                                               ; preds = %13, %39
  %29 = phi i8 [ %42, %39 ], [ 0, %13 ]
  %30 = zext nneg i8 %29 to i16
  %31 = getelementptr i8, ptr %0, i16 %30
  %32 = load i8, ptr %31, align 1, !tbaa !6
  %33 = icmp ugt i8 %32, 31
  br i1 %33, label %34, label %39

34:                                               ; preds = %28
  %35 = icmp ult i8 %32, 96
  br i1 %35, label %36, label %39

36:                                               ; preds = %34
  %37 = shl i8 %32, 2
  %38 = xor i8 %37, -128
  br label %39

39:                                               ; preds = %28, %34, %36
  %40 = phi i8 [ %38, %36 ], [ 0, %34 ], [ 0, %28 ]
  store volatile i8 %40, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !6
  %41 = or disjoint i8 %40, 1
  store volatile i8 %41, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !6
  %42 = add nuw nsw i8 %29, 1
  %43 = icmp eq i8 %42, %14
  br i1 %43, label %26, label %28, !llvm.loop !33

44:                                               ; preds = %26, %55
  %45 = phi i8 [ %59, %55 ], [ 0, %26 ]
  %46 = zext nneg i8 %45 to i16
  %47 = getelementptr i8, ptr %0, i16 %46
  %48 = load i8, ptr %47, align 1, !tbaa !6
  %49 = icmp ugt i8 %48, 31
  br i1 %49, label %50, label %55

50:                                               ; preds = %44
  %51 = icmp ult i8 %48, 96
  br i1 %51, label %52, label %55

52:                                               ; preds = %50
  %53 = shl i8 %48, 2
  %54 = xor i8 %53, -128
  br label %55

55:                                               ; preds = %44, %50, %52
  %56 = phi i8 [ %54, %52 ], [ 0, %50 ], [ 0, %44 ]
  %57 = or disjoint i8 %56, 2
  store volatile i8 %57, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !6
  %58 = or disjoint i8 %56, 3
  store volatile i8 %58, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !6
  %59 = add nuw nsw i8 %45, 1
  %60 = icmp eq i8 %59, %14
  br i1 %60, label %61, label %44, !llvm.loop !34

61:                                               ; preds = %55, %24, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @tick_cycle(i8 noundef zeroext range(i8 2, 5) %0) unnamed_addr #3 {
  %2 = load i8, ptr @pcount, align 1, !tbaa !6
  %3 = add i8 %2, 1
  store i8 %3, ptr @pcount, align 1, !tbaa !6
  %4 = icmp ult i8 %3, %0
  br i1 %4, label %35, label %5

5:                                                ; preds = %1
  store i8 0, ptr @pcount, align 1, !tbaa !6
  %6 = load i8, ptr @pshift, align 1, !tbaa !6
  %7 = add i8 %6, 1
  %8 = icmp ugt i8 %7, 7
  br i1 %8, label %9, label %10

9:                                                ; preds = %5
  br label %10

10:                                               ; preds = %9, %5
  %11 = phi i8 [ 0, %9 ], [ %7, %5 ]
  store i8 %11, ptr @pshift, align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  %12 = load i16, ptr @pal, align 1, !tbaa !2
  %13 = trunc i16 %12 to i8
  store volatile i8 %13, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  %14 = load i16, ptr @pal, align 1, !tbaa !2
  %15 = lshr i16 %14, 8
  %16 = trunc nuw i16 %15 to i8
  store volatile i8 %16, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  br label %17

17:                                               ; preds = %23, %10
  %18 = phi i8 [ 0, %10 ], [ %33, %23 ]
  %19 = add nuw nsw i8 %18, %11
  %20 = icmp samesign ugt i8 %19, 7
  br i1 %20, label %21, label %23

21:                                               ; preds = %17
  %22 = add nsw i8 %19, -8
  br label %23

23:                                               ; preds = %21, %17
  %24 = phi i8 [ %22, %21 ], [ %19, %17 ]
  %25 = zext i8 %24 to i16
  %26 = getelementptr inbounds nuw [2 x i8], ptr @pal, i16 %25
  %27 = getelementptr inbounds nuw i8, ptr %26, i16 2
  %28 = load i16, ptr %27, align 1, !tbaa !2
  %29 = trunc i16 %28 to i8
  store volatile i8 %29, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  %30 = load i16, ptr %27, align 1, !tbaa !2
  %31 = lshr i16 %30, 8
  %32 = trunc nuw i16 %31 to i8
  store volatile i8 %32, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  %33 = add nuw nsw i8 %18, 1
  %34 = icmp eq i8 %33, 8
  br i1 %34, label %35, label %17, !llvm.loop !35

35:                                               ; preds = %23, %1
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #4

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.umax.i16(i16, i16) #4

attributes #0 = { nofree norecurse noreturn nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree norecurse nosync nounwind optsize memory(write, argmem: none, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #3 = { nofree norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { optsize }
attributes #6 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = distinct !{!9, !8}
!10 = distinct !{!10, !8}
!11 = distinct !{!11, !8}
!12 = distinct !{!12, !8}
!13 = distinct !{!13, !8}
!14 = distinct !{!14, !8}
!15 = distinct !{!15, !8}
!16 = distinct !{!16, !8}
!17 = distinct !{!17, !8}
!18 = distinct !{!18, !8}
!19 = distinct !{!19, !8}
!20 = !{!21, !21, i64 0}
!21 = !{!"long long", !4, i64 0}
!22 = distinct !{!22, !8}
!23 = distinct !{!23, !8}
!24 = distinct !{!24, !8}
!25 = distinct !{!25, !8}
!26 = distinct !{!26, !8}
!27 = distinct !{!27, !8}
!28 = distinct !{!28, !8}
!29 = distinct !{!29, !8}
!30 = distinct !{!30, !8}
!31 = distinct !{!31, !8}
!32 = distinct !{!32, !8}
!33 = distinct !{!33, !8}
!34 = distinct !{!34, !8}
!35 = distinct !{!35, !8}
