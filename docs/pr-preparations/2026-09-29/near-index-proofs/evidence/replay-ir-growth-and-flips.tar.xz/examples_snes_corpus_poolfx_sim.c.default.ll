; ModuleID = '/work/examples/snes/corpus/poolfx_sim.c'
source_filename = "/work/examples/snes/corpus/poolfx_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.Pool = type { [48 x %struct.Particle], i16, i16 }
%struct.Particle = type { i16, i16, i16, i16, i16, i16 }

@corpus_result = dso_local global i16 0, align 1
@poolfx_gate_crc.pl = internal unnamed_addr global %struct.Pool zeroinitializer, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %1, %0
  %2 = phi i16 [ 0, %0 ], [ %3, %1 ]
  %3 = add nuw nsw i16 %2, 1
  %4 = getelementptr inbounds nuw [12 x i8], ptr @poolfx_gate_crc.pl, i16 %2
  %5 = getelementptr inbounds nuw i8, ptr %4, i16 10
  store i16 %3, ptr %5, align 1, !tbaa !6
  %6 = getelementptr inbounds nuw i8, ptr %4, i16 8
  store i16 0, ptr %6, align 1, !tbaa !8
  %7 = icmp eq i16 %3, 48
  br i1 %7, label %8, label %1, !llvm.loop !9

8:                                                ; preds = %1
  store i16 -1, ptr getelementptr inbounds nuw (i8, ptr @poolfx_gate_crc.pl, i16 574), align 1, !tbaa !6
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @poolfx_gate_crc.pl, i16 576), align 1, !tbaa !11
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @poolfx_gate_crc.pl, i16 578), align 1, !tbaa !13
  br label %9

9:                                                ; preds = %101, %8
  %10 = phi i16 [ 0, %8 ], [ %98, %101 ]
  %11 = phi i16 [ 0, %8 ], [ %97, %101 ]
  %12 = phi i16 [ 0, %8 ], [ %104, %101 ]
  %13 = phi i16 [ 0, %8 ], [ %103, %101 ]
  %14 = phi i16 [ -21279, %8 ], [ %59, %101 ]
  br label %18

15:                                               ; preds = %58
  %16 = load i16, ptr getelementptr inbounds nuw (i8, ptr @poolfx_gate_crc.pl, i16 576), align 1
  %17 = load i16, ptr getelementptr inbounds nuw (i8, ptr @poolfx_gate_crc.pl, i16 578), align 1
  br label %65

18:                                               ; preds = %58, %9
  %19 = phi i16 [ %14, %9 ], [ %59, %58 ]
  %20 = phi i8 [ 0, %9 ], [ %63, %58 ]
  %21 = phi i16 [ %11, %9 ], [ %62, %58 ]
  %22 = phi i16 [ %10, %9 ], [ %61, %58 ]
  %23 = phi i16 [ %14, %9 ], [ %60, %58 ]
  %24 = icmp eq i16 %21, -1
  br i1 %24, label %58, label %25

25:                                               ; preds = %18
  %26 = getelementptr inbounds nuw [12 x i8], ptr @poolfx_gate_crc.pl, i16 %21
  %27 = getelementptr inbounds nuw i8, ptr %26, i16 10
  %28 = load i16, ptr %27, align 1, !tbaa !6
  store i16 %28, ptr getelementptr inbounds nuw (i8, ptr @poolfx_gate_crc.pl, i16 576), align 1, !tbaa !11
  %29 = add i16 %22, 1
  store i16 %29, ptr getelementptr inbounds nuw (i8, ptr @poolfx_gate_crc.pl, i16 578), align 1, !tbaa !13
  store i16 1024, ptr %26, align 1, !tbaa !14
  %30 = getelementptr inbounds nuw i8, ptr %26, i16 2
  store i16 1920, ptr %30, align 1, !tbaa !15
  %31 = shl i16 %23, 7
  %32 = xor i16 %31, %23
  %33 = lshr i16 %32, 9
  %34 = xor i16 %33, %32
  %35 = shl i16 %34, 8
  %36 = xor i16 %35, %34
  %37 = and i16 %34, 63
  %38 = add nsw i16 %37, -32
  %39 = getelementptr inbounds nuw i8, ptr %26, i16 4
  store i16 %38, ptr %39, align 1, !tbaa !16
  %40 = shl i16 %36, 7
  %41 = xor i16 %40, %36
  %42 = lshr i16 %41, 9
  %43 = xor i16 %42, %41
  %44 = shl i16 %43, 8
  %45 = xor i16 %44, %43
  %46 = and i16 %43, 31
  %47 = sub nuw nsw i16 -40, %46
  %48 = getelementptr inbounds nuw i8, ptr %26, i16 6
  store i16 %47, ptr %48, align 1, !tbaa !17
  %49 = shl i16 %45, 7
  %50 = xor i16 %49, %45
  %51 = lshr i16 %50, 9
  %52 = xor i16 %51, %50
  %53 = shl i16 %52, 8
  %54 = xor i16 %53, %52
  %55 = and i16 %52, 31
  %56 = add nuw nsw i16 %55, 24
  %57 = getelementptr inbounds nuw i8, ptr %26, i16 8
  store i16 %56, ptr %57, align 1, !tbaa !8
  br label %58

58:                                               ; preds = %25, %18
  %59 = phi i16 [ %19, %18 ], [ %54, %25 ]
  %60 = phi i16 [ %23, %18 ], [ %54, %25 ]
  %61 = phi i16 [ %22, %18 ], [ %29, %25 ]
  %62 = phi i16 [ -1, %18 ], [ %28, %25 ]
  %63 = add nuw nsw i8 %20, 1
  %64 = icmp eq i8 %63, 3
  br i1 %64, label %15, label %18, !llvm.loop !18

65:                                               ; preds = %91, %15
  %66 = phi i16 [ 0, %15 ], [ %94, %91 ]
  %67 = phi i16 [ %16, %15 ], [ %93, %91 ]
  %68 = phi i16 [ %17, %15 ], [ %92, %91 ]
  %69 = getelementptr inbounds nuw [12 x i8], ptr @poolfx_gate_crc.pl, i16 %66
  %70 = getelementptr inbounds nuw i8, ptr %69, i16 8
  %71 = load i16, ptr %70, align 1, !tbaa !8
  %72 = icmp slt i16 %71, 1
  br i1 %72, label %91, label %73

73:                                               ; preds = %65
  %74 = getelementptr inbounds nuw i8, ptr %69, i16 6
  %75 = load i16, ptr %74, align 1, !tbaa !17
  %76 = add nsw i16 %75, 3
  store i16 %76, ptr %74, align 1, !tbaa !17
  %77 = load i16, ptr %69, align 1, !tbaa !14
  %78 = getelementptr inbounds nuw i8, ptr %69, i16 4
  %79 = load i16, ptr %78, align 1, !tbaa !16
  %80 = add nsw i16 %79, %77
  store i16 %80, ptr %69, align 1, !tbaa !14
  %81 = getelementptr inbounds nuw i8, ptr %69, i16 2
  %82 = load i16, ptr %81, align 1, !tbaa !15
  %83 = add nsw i16 %82, %76
  store i16 %83, ptr %81, align 1, !tbaa !15
  %84 = add nsw i16 %71, -1
  store i16 %84, ptr %70, align 1, !tbaa !8
  %85 = icmp eq i16 %71, 1
  br i1 %85, label %88, label %86

86:                                               ; preds = %73
  %87 = icmp sgt i16 %83, 2047
  br i1 %87, label %88, label %91

88:                                               ; preds = %86, %73
  %89 = getelementptr inbounds nuw i8, ptr %69, i16 10
  store i16 %67, ptr %89, align 1, !tbaa !6
  store i16 %66, ptr getelementptr inbounds nuw (i8, ptr @poolfx_gate_crc.pl, i16 576), align 1, !tbaa !11
  store i16 0, ptr %70, align 1, !tbaa !8
  %90 = add i16 %68, -1
  store i16 %90, ptr getelementptr inbounds nuw (i8, ptr @poolfx_gate_crc.pl, i16 578), align 1, !tbaa !13
  br label %91

91:                                               ; preds = %88, %86, %65
  %92 = phi i16 [ %68, %86 ], [ %90, %88 ], [ %68, %65 ]
  %93 = phi i16 [ %67, %86 ], [ %66, %88 ], [ %67, %65 ]
  %94 = add nuw nsw i16 %66, 1
  %95 = icmp eq i16 %94, 48
  br i1 %95, label %96, label %65, !llvm.loop !19

96:                                               ; preds = %91
  %97 = load i16, ptr getelementptr inbounds nuw (i8, ptr @poolfx_gate_crc.pl, i16 576), align 1, !tbaa !11
  %98 = load i16, ptr getelementptr inbounds nuw (i8, ptr @poolfx_gate_crc.pl, i16 578), align 1, !tbaa !13
  %99 = shl i16 %98, 3
  %100 = xor i16 %99, %97
  br label %106

101:                                              ; preds = %106
  %102 = tail call i16 @llvm.fshl.i16(i16 %13, i16 %13, i16 1)
  %103 = xor i16 %118, %102
  %104 = add nuw nsw i16 %12, 1
  %105 = icmp eq i16 %104, 100
  br i1 %105, label %121, label %9, !llvm.loop !20

106:                                              ; preds = %106, %96
  %107 = phi i16 [ 0, %96 ], [ %119, %106 ]
  %108 = phi i16 [ %100, %96 ], [ %118, %106 ]
  %109 = getelementptr inbounds nuw [12 x i8], ptr @poolfx_gate_crc.pl, i16 %107
  %110 = load i16, ptr %109, align 1, !tbaa !14
  %111 = mul i16 %110, 3
  %112 = add i16 %111, %108
  %113 = getelementptr inbounds nuw i8, ptr %109, i16 2
  %114 = load i16, ptr %113, align 1, !tbaa !15
  %115 = add i16 %112, %114
  %116 = getelementptr inbounds nuw i8, ptr %109, i16 10
  %117 = load i16, ptr %116, align 1, !tbaa !6
  %118 = add i16 %115, %117
  %119 = add nuw nsw i16 %107, 1
  %120 = icmp eq i16 %119, 48
  br i1 %120, label %101, label %106, !llvm.loop !21

121:                                              ; preds = %101
  store volatile i16 %103, ptr @corpus_result, align 1, !tbaa !2
  br label %122

122:                                              ; preds = %122, %121
  tail call void asm sideeffect "wai", ""() #2, !srcloc !22
  br label %122
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #1

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !3, i64 10}
!7 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !3, i64 6, !3, i64 8, !3, i64 10}
!8 = !{!7, !3, i64 8}
!9 = distinct !{!9, !10}
!10 = !{!"llvm.loop.mustprogress"}
!11 = !{!12, !3, i64 576}
!12 = !{!"", !4, i64 0, !3, i64 576, !3, i64 578}
!13 = !{!12, !3, i64 578}
!14 = !{!7, !3, i64 0}
!15 = !{!7, !3, i64 2}
!16 = !{!7, !3, i64 4}
!17 = !{!7, !3, i64 6}
!18 = distinct !{!18, !10}
!19 = distinct !{!19, !10}
!20 = distinct !{!20, !10}
!21 = distinct !{!21, !10}
!22 = !{i64 480}
