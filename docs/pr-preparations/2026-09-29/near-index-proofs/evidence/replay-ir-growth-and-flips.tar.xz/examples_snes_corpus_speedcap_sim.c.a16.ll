; ModuleID = '/work/examples/snes/corpus/speedcap_sim.c'
source_filename = "/work/examples/snes/corpus/speedcap_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1
@SC_INIT_PX = internal unnamed_addr constant [12 x i16] [i16 64, i16 88, i16 105, i16 112, i16 105, i16 88, i16 64, i16 40, i16 23, i16 16, i16 23, i16 40], align 1
@SC_INIT_PY = internal unnamed_addr constant [12 x i16] [i16 16, i16 23, i16 40, i16 64, i16 88, i16 105, i16 112, i16 105, i16 88, i16 64, i16 40, i16 23], align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [12 x i16], align 1
  %2 = alloca [12 x i16], align 1
  %3 = alloca [12 x float], align 1
  %4 = alloca [12 x float], align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #6
  call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(48) %3, i8 0, i16 48, i1 false), !tbaa !6
  call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(48) %4, i8 0, i16 48, i1 false), !tbaa !6
  call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(24) %1, ptr noundef nonnull align 1 dereferenceable(24) @SC_INIT_PX, i16 24, i1 false), !tbaa !2
  call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(24) %2, ptr noundef nonnull align 1 dereferenceable(24) @SC_INIT_PY, i16 24, i1 false), !tbaa !2
  br label %5

5:                                                ; preds = %59, %0
  %6 = phi i16 [ %55, %59 ], [ 0, %0 ]
  %7 = phi i16 [ %60, %59 ], [ 0, %0 ]
  br label %8

8:                                                ; preds = %8, %5
  %9 = phi i8 [ 0, %5 ], [ %41, %8 ]
  %10 = phi i8 [ 0, %5 ], [ %40, %8 ]
  %11 = phi i16 [ 0, %5 ], [ %38, %8 ]
  %12 = zext nneg i8 %10 to i16
  %13 = getelementptr i8, ptr %1, i16 %12
  %14 = load i16, ptr %13, align 1, !tbaa !2
  %15 = sub nsw i16 64, %14
  %16 = sitofp i16 %15 to float
  %17 = getelementptr i8, ptr %2, i16 %12
  %18 = load i16, ptr %17, align 1, !tbaa !2
  %19 = sub nsw i16 64, %18
  %20 = sitofp i16 %19 to float
  %21 = fmul nnan float %16, 0x3F947AE140000000
  %22 = fmul nnan float %20, 0x3F947AE140000000
  %23 = zext nneg i8 %9 to i16
  %24 = getelementptr i8, ptr %3, i16 %23
  %25 = load float, ptr %24, align 1, !tbaa !6
  %26 = fadd float %25, %21
  %27 = getelementptr i8, ptr %4, i16 %23
  %28 = load float, ptr %27, align 1, !tbaa !6
  %29 = fadd float %28, %22
  %30 = tail call nsz float @llvm.maxnum.f32(float %26, float -8.000000e+00)
  %31 = tail call nsz float @llvm.minnum.f32(float %30, float 8.000000e+00)
  store float %31, ptr %24, align 1, !tbaa !6
  %32 = tail call nsz float @llvm.maxnum.f32(float %29, float -8.000000e+00)
  %33 = tail call nsz float @llvm.minnum.f32(float %32, float 8.000000e+00)
  store float %33, ptr %27, align 1, !tbaa !6
  %34 = fptosi float %31 to i16
  %35 = fptosi float %33 to i16
  %36 = add nsw i16 %14, %34
  store i16 %36, ptr %13, align 1, !tbaa !2
  %37 = add nsw i16 %18, %35
  store i16 %37, ptr %17, align 1, !tbaa !2
  %38 = add nuw nsw i16 %11, 1
  %39 = icmp eq i16 %38, 12
  %40 = add nuw nsw i8 %10, 2
  %41 = add nuw nsw i8 %9, 4
  br i1 %39, label %42, label %8, !llvm.loop !8

42:                                               ; preds = %8, %42
  %43 = phi i8 [ %58, %42 ], [ 0, %8 ]
  %44 = phi i16 [ %56, %42 ], [ 0, %8 ]
  %45 = phi i16 [ %55, %42 ], [ %6, %8 ]
  %46 = tail call i16 @llvm.fshl.i16(i16 %45, i16 %45, i16 1)
  %47 = zext nneg i8 %43 to i16
  %48 = getelementptr i8, ptr %1, i16 %47
  %49 = load i16, ptr %48, align 1, !tbaa !2
  %50 = mul nsw i16 %49, 97
  %51 = getelementptr i8, ptr %2, i16 %47
  %52 = load i16, ptr %51, align 1, !tbaa !2
  %53 = mul nsw i16 %52, 13
  %54 = xor i16 %50, %46
  %55 = xor i16 %54, %53
  %56 = add nuw nsw i16 %44, 1
  %57 = icmp eq i16 %56, 12
  %58 = add nuw nsw i8 %43, 2
  br i1 %57, label %59, label %42, !llvm.loop !10

59:                                               ; preds = %42
  %60 = add nuw nsw i16 %7, 1
  %61 = icmp eq i16 %60, 16
  br i1 %61, label %62, label %5, !llvm.loop !11

62:                                               ; preds = %59
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #6
  store volatile i16 %55, ptr @corpus_result, align 1, !tbaa !2
  br label %63

63:                                               ; preds = %63, %62
  tail call void asm sideeffect "wai", ""() #6, !srcloc !12
  br label %63
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maxnum.f32(float, float) #2

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.minnum.f32(float, float) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #5

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !7, i64 0}
!7 = !{!"float", !4, i64 0}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = distinct !{!10, !9}
!11 = distinct !{!11, !9}
!12 = !{i64 613}
