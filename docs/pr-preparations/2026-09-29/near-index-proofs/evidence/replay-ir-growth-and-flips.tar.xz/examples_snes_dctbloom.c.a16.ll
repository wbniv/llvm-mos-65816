; ModuleID = '/work/examples/snes/dctbloom.c'
source_filename = "/work/examples/snes/dctbloom.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.App = type { %struct.Display, %struct.BitmapCanvas, %struct.TextLayer, i16, i16 }
%struct.Display = type { %struct.UploadQueue, %struct.VramAlloc, %struct.Scene, i8, i8, i8, i8, i8 }
%struct.UploadQueue = type { [16 x %struct.UpqJob], i8, i8 }
%struct.UpqJob = type { i16, i16, i16, i8, i8, i8, i8, i8 }
%struct.VramAlloc = type { i16, i16 }
%struct.Scene = type { [4 x ptr], i8 }
%struct.BitmapCanvas = type { %struct.Drawable, [4096 x i8], i16, i16, i16, i16, i8, i8 }
%struct.Drawable = type { ptr, i8 }
%struct.TextLayer = type { %struct.Drawable, i16, [2 x i8], [64 x i16], i8 }
%struct.TitleLayer = type { %struct.Drawable, ptr, ptr, ptr, ptr, i8, i8, i16, i16, i16, i16, i16, i16, i8, i16, i8, i8, i8, i8, i8, i8, i16, i16, %struct.HScrollDB, %struct.HScrollDB }
%struct.HScrollDB = type { [2 x %struct.HScrollN], i8 }
%struct.HScrollN = type { [25 x i8] }
%struct.DrawableVT = type { ptr, ptr }
%struct.HScrollW = type { ptr, i8 }

@main.a = internal global %struct.App zeroinitializer, align 1
@main.title = internal global %struct.TitleLayer zeroinitializer, align 1
@.str = private unnamed_addr constant [10 x i8] c"DCT BLOOM\00", align 1
@.str.1 = private unnamed_addr constant [15 x i8] c"INT COSINE MAC\00", align 1
@corpus_result = dso_local global i16 0, align 1
@bg3_pal = internal constant [4 x i16] [i16 4129, i16 25030, i16 8854, i16 25183], align 1
@.str.2 = private unnamed_addr constant [18 x i8] c"DCT BLOOM 8X8 MAC\00", align 1
@CANVAS_VT = internal constant %struct.DrawableVT { ptr @_canvas_reserve, ptr @_canvas_emit }, align 1
@TEXT_VT = internal constant %struct.DrawableVT { ptr @_text_reserve, ptr @_text_emit }, align 1
@FONT8 = internal unnamed_addr constant [512 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 32, i16 0, i16 80, i16 80, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 80, i16 80, i16 248, i16 80, i16 248, i16 80, i16 80, i16 0, i16 32, i16 120, i16 160, i16 112, i16 40, i16 240, i16 32, i16 0, i16 196, i16 200, i16 16, i16 32, i16 64, i16 152, i16 12, i16 0, i16 96, i16 144, i16 160, i16 64, i16 168, i16 144, i16 104, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 16, i16 32, i16 64, i16 64, i16 64, i16 32, i16 16, i16 0, i16 64, i16 32, i16 16, i16 16, i16 16, i16 32, i16 64, i16 0, i16 0, i16 32, i16 168, i16 112, i16 168, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 248, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 64, i16 0, i16 0, i16 0, i16 248, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 0, i16 8, i16 8, i16 16, i16 32, i16 64, i16 128, i16 128, i16 0, i16 112, i16 136, i16 152, i16 168, i16 200, i16 136, i16 112, i16 0, i16 32, i16 96, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 64, i16 248, i16 0, i16 112, i16 136, i16 8, i16 48, i16 8, i16 136, i16 112, i16 0, i16 16, i16 48, i16 80, i16 144, i16 248, i16 16, i16 16, i16 0, i16 248, i16 128, i16 240, i16 8, i16 8, i16 136, i16 112, i16 0, i16 112, i16 136, i16 128, i16 240, i16 136, i16 136, i16 112, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 64, i16 64, i16 0, i16 112, i16 136, i16 136, i16 112, i16 136, i16 136, i16 112, i16 0, i16 112, i16 136, i16 136, i16 120, i16 8, i16 136, i16 112, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 64, i16 0, i16 16, i16 32, i16 64, i16 128, i16 64, i16 32, i16 16, i16 0, i16 0, i16 0, i16 248, i16 0, i16 248, i16 0, i16 0, i16 0, i16 128, i16 64, i16 32, i16 16, i16 32, i16 64, i16 128, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 0, i16 32, i16 0, i16 112, i16 136, i16 184, i16 168, i16 184, i16 128, i16 112, i16 0, i16 112, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 240, i16 136, i16 136, i16 240, i16 136, i16 136, i16 240, i16 0, i16 112, i16 136, i16 128, i16 128, i16 128, i16 136, i16 112, i16 0, i16 224, i16 144, i16 136, i16 136, i16 136, i16 144, i16 224, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 248, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 128, i16 176, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 112, i16 32, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 56, i16 16, i16 16, i16 16, i16 144, i16 144, i16 96, i16 0, i16 136, i16 144, i16 160, i16 192, i16 160, i16 144, i16 136, i16 0, i16 128, i16 128, i16 128, i16 128, i16 128, i16 128, i16 248, i16 0, i16 136, i16 216, i16 168, i16 136, i16 136, i16 136, i16 136, i16 0, i16 136, i16 200, i16 168, i16 152, i16 136, i16 136, i16 136, i16 0, i16 112, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 240, i16 136, i16 136, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 136, i16 136, i16 168, i16 144, i16 104, i16 0, i16 240, i16 136, i16 136, i16 240, i16 160, i16 144, i16 136, i16 0, i16 112, i16 136, i16 128, i16 112, i16 8, i16 136, i16 112, i16 0, i16 248, i16 32, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 80, i16 32, i16 0, i16 136, i16 136, i16 136, i16 168, i16 168, i16 216, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 80, i16 136, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 32, i16 32, i16 32, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 128, i16 248, i16 0, i16 48, i16 32, i16 32, i16 32, i16 32, i16 32, i16 48, i16 0, i16 128, i16 128, i16 64, i16 32, i16 16, i16 8, i16 8, i16 0, i16 48, i16 16, i16 16, i16 16, i16 16, i16 16, i16 48, i16 0, i16 32, i16 80, i16 136, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248], align 1
@TITLE_VT = internal constant %struct.DrawableVT { ptr @_title_reserve, ptr @_title_emit }, align 1
@FONT16 = internal unnamed_addr constant [2048 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 192, i16 192, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 768, i16 768, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 -4096, i16 -4096, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3840, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 3312, i16 15360, i16 15360, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 28, i16 28, i16 796, i16 127, i16 127, i16 796, i16 796, i16 127, i16 112, i16 112, i16 3184, i16 252, i16 252, i16 -28816, i16 -28816, i16 252, i16 127, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 0, i16 0, i16 252, i16 -28816, i16 -28816, i16 3184, i16 7168, i16 7168, i16 0, i16 0, i16 3, i16 63, i16 123, i16 1147, i16 63, i16 4111, i16 3075, i16 123, i16 192, i16 248, i16 8414, i16 16064, i16 2040, i16 248, i16 8414, i16 8414, i16 63, i16 7171, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 2040, i16 14272, i16 -512, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3585, i16 3, i16 7, i16 28, i16 56, i16 1904, i16 3808, i16 7392, i16 14528, i16 14464, i16 28672, i16 14, i16 284, i16 824, i16 1792, i16 3584, i16 0, i16 0, i16 0, i16 -8162, i16 -16354, i16 -32482, i16 286, i16 1792, i16 1792, i16 0, i16 0, i16 15, i16 31, i16 828, i16 828, i16 573, i16 31, i16 31, i16 63, i16 192, i16 224, i16 240, i16 2288, i16 7392, i16 15488, i16 30720, i16 -32648, i16 382, i16 3060, i16 3825, i16 1275, i16 127, i16 63, i16 7936, i16 3840, i16 248, i16 3824, i16 7904, i16 7392, i16 4332, i16 12492, i16 -1280, i16 -3328, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 7, i16 15, i16 15, i16 15, i16 15, i16 15, i16 240, i16 192, i16 15488, i16 -4096, i16 -8192, i16 -16384, i16 -16384, i16 -16384, i16 15, i16 7, i16 3, i16 256, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 16512, i16 192, i16 240, i16 -4096, i16 15360, i16 0, i16 0, i16 15, i16 3, i16 513, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 224, i16 240, i16 2288, i16 3312, i16 3312, i16 3312, i16 0, i16 1, i16 3, i16 15, i16 0, i16 768, i16 0, i16 0, i16 3312, i16 7392, i16 15552, i16 30720, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 51, i16 31, i16 15, i16 1027, i16 0, i16 0, i16 192, i16 192, i16 12492, i16 252, i16 1016, i16 16320, i16 15, i16 31, i16 51, i16 1027, i16 3072, i16 0, i16 0, i16 0, i16 1784, i16 252, i16 13004, i16 16320, i16 -3328, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 3, i16 63, i16 63, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 248, i16 248, i16 63, i16 3075, i16 3075, i16 3, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 16064, i16 16064, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 286, i16 828, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 28800, i16 -4096, i16 -8192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 -512, i16 -512, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7360, i16 14464, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7168, i16 14336, i16 28672, i16 -8192, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 828, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 15, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 1, i16 3, i16 15, i16 15, i16 513, i16 513, i16 1, i16 1, i16 240, i16 240, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 1, i16 1, i16 1, i16 1, i16 1, i16 1, i16 0, i16 0, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 31744, i16 31744, i16 15, i16 31, i16 318, i16 828, i16 3840, i16 3840, i16 3, i16 15, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 63, i16 510, i16 4080, i16 31, i16 318, i16 318, i16 318, i16 63, i16 63, i16 3840, i16 3840, i16 32640, i16 -1024, i16 -8192, i16 -32768, i16 255, i16 255, i16 -256, i16 -256, i16 15, i16 63, i16 824, i16 3840, i16 2055, i16 7, i16 256, i16 256, i16 252, i16 254, i16 -8161, i16 -4081, i16 510, i16 1020, i16 -7906, i16 -4081, i16 0, i16 0, i16 56, i16 60, i16 63, i16 31, i16 3840, i16 1792, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 15, i16 286, i16 62, i16 126, i16 510, i16 510, i16 8670, i16 24990, i16 -7906, i16 -7906, i16 828, i16 828, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 -16098, i16 -32482, i16 255, i16 255, i16 -7906, i16 -7906, i16 1792, i16 1792, i16 31, i16 63, i16 828, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 254, i16 254, i16 -256, i16 -256, i16 252, i16 254, i16 -8161, i16 -4081, i16 0, i16 0, i16 60, i16 62, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 63, i16 63, i16 318, i16 828, i16 254, i16 255, i16 -2041, i16 -256, i16 508, i16 254, i16 -4081, i16 -2041, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 -32761, i16 7, i16 7, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 31, i16 318, i16 892, i16 0, i16 1, i16 3, i16 7, i16 7, i16 7, i16 256, i16 256, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 28800, i16 -8192, i16 -8192, i16 15, i16 31, i16 828, i16 828, i16 828, i16 31, i16 15, i16 796, i16 252, i16 254, i16 -4081, i16 -4081, i16 15, i16 510, i16 1020, i16 -3826, i16 828, i16 828, i16 828, i16 828, i16 31, i16 15, i16 1792, i16 768, i16 -4081, i16 15, i16 15, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 318, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 31, i16 31, i16 15, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 270, i16 796, i16 824, i16 1792, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 15, i16 60, i16 828, i16 0, i16 0, i16 60, i16 240, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 15360, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 60, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 60, i16 0, i16 3, i16 15, i16 60, i16 768, i16 3840, i16 0, i16 0, i16 4080, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 31, i16 63, i16 828, i16 3840, i16 3840, i16 7, i16 7, i16 7, i16 240, i16 248, i16 -32644, i16 -32132, i16 2040, i16 4080, i16 16064, i16 31872, i16 256, i16 256, i16 7, i16 7, i16 7, i16 256, i16 256, i16 0, i16 -4096, i16 -8192, i16 128, i16 128, i16 24704, i16 -8192, i16 -8192, i16 0, i16 31, i16 63, i16 828, i16 573, i16 573, i16 573, i16 573, i16 573, i16 248, i16 252, i16 -15812, i16 4590, i16 494, i16 4590, i16 1020, i16 1016, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 0, i16 0, i16 0, i16 32512, i16 764, i16 248, i16 -256, i16 -512, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 892, i16 1020, i16 1020, i16 255, i16 255, i16 224, i16 240, i16 -32648, i16 -16324, i16 -32196, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -28928, i16 1792, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 0, i16 0, i16 28, i16 60, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -8164, i16 -3572, i16 -30976, i16 768, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 8988, i16 8988, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 60, i16 60, i16 828, i16 828, i16 828, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 255, i16 255, i16 16128, i16 16128, i16 12480, i16 12480, i16 12480, i16 12480, i16 252, i16 252, i16 -256, i16 -256, i16 63, i16 63, i16 3075, i16 3075, i16 3, i16 3, i16 51, i16 51, i16 252, i16 252, i16 4080, i16 4080, i16 3312, i16 3312, i16 3312, i16 3312, i16 3123, i16 3123, i16 63, i16 63, i16 31, i16 15, i16 1792, i16 768, i16 3312, i16 3312, i16 3312, i16 3312, i16 7392, i16 15552, i16 -2048, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 765, i16 255, i16 255, i16 255, i16 28, i16 60, i16 1912, i16 4080, i16 7904, i16 15552, i16 30848, i16 12480, i16 255, i16 765, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 224, i16 240, i16 248, i16 124, i16 572, i16 828, i16 3840, i16 3840, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 0, i16 0, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 248, i16 252, i16 254, i16 2295, i16 3315, i16 3315, i16 3315, i16 3315, i16 60, i16 124, i16 1020, i16 988, i16 9116, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 15360, i16 15360, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 -6400, i16 -6400, i16 240, i16 248, i16 252, i16 254, i16 255, i16 255, i16 2295, i16 3315, i16 60, i16 60, i16 828, i16 828, i16 828, i16 956, i16 1020, i16 1020, i16 3313, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 15360, i16 15360, i16 1020, i16 1020, i16 892, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -31972, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -512, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 224, i16 240, i16 -32648, i16 -15304, i16 -31176, i16 1592, i16 1592, i16 1592, i16 765, i16 765, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 1784, i16 1784, i16 17976, i16 1656, i16 764, i16 764, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 63, i16 127, i16 2040, i16 4080, i16 1784, i16 255, i16 127, i16 63, i16 248, i16 252, i16 -15812, i16 -256, i16 3840, i16 240, i16 248, i16 252, i16 7936, i16 3840, i16 224, i16 255, i16 255, i16 127, i16 16128, i16 7936, i16 -32132, i16 -15556, i16 892, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 -4096, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 28, i16 28, i16 796, i16 796, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 510, i16 255, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 828, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 248, i16 248, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 124, i16 124, i16 1912, i16 1912, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 572, i16 63, i16 31, i16 15, i16 7, i16 768, i16 256, i16 1656, i16 3824, i16 3824, i16 7392, i16 15552, i16 30848, i16 -4096, i16 -8192, i16 243, i16 243, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 156, i16 156, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 2295, i16 255, i16 510, i16 892, i16 16128, i16 7936, i16 25500, i16 25500, i16 9180, i16 1020, i16 1020, i16 -30856, i16 -16640, i16 7680, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 15, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 14528, i16 31, i16 63, i16 892, i16 2040, i16 4080, i16 3824, i16 15360, i16 15360, i16 4320, i16 240, i16 248, i16 -32644, i16 572, i16 828, i16 3840, i16 3840, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 7, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 7, i16 7, i16 7, i16 7, i16 7, i16 7, i16 256, i16 256, i16 28800, i16 24704, i16 24704, i16 24704, i16 24704, i16 24704, i16 -8192, i16 -8192, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 1, i16 3, i16 7, i16 252, i16 252, i16 1020, i16 -31876, i16 2040, i16 4080, i16 7904, i16 15552, i16 15, i16 31, i16 318, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 30848, i16 -4096, i16 -8192, i16 252, i16 252, i16 1020, i16 -256, i16 -256, i16 31, i16 31, i16 286, i16 286, i16 286, i16 286, i16 286, i16 286, i16 224, i16 224, i16 -2048, i16 -2048, i16 -32768, i16 -32768, i16 -32768, i16 -32768, i16 286, i16 286, i16 286, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 -32768, i16 -32768, i16 -32768, i16 224, i16 224, i16 -2048, i16 -2048, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 3, i16 1, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 128, i16 192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 768, i16 256, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 0, i16 0, i16 0, i16 224, i16 224, i16 2288, i16 2288, i16 3312, i16 3312, i16 3312, i16 3312, i16 0, i16 0, i16 0, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 3312, i16 3312, i16 3312, i16 7392, i16 7392, i16 -2048, i16 -2048, i16 0, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1840, i16 3584, i16 3072, i16 192, i16 224, i16 -32656, i16 -16328, i16 -32740, i16 524, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 127, i16 127, i16 7936, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 -512], align 1
@DCT_M = internal unnamed_addr constant [8 x [8 x i16]] [[8 x i16] [i16 91, i16 91, i16 91, i16 91, i16 91, i16 91, i16 91, i16 91], [8 x i16] [i16 126, i16 106, i16 71, i16 25, i16 -25, i16 -71, i16 -106, i16 -126], [8 x i16] [i16 118, i16 49, i16 -49, i16 -118, i16 -118, i16 -49, i16 49, i16 118], [8 x i16] [i16 106, i16 -25, i16 -126, i16 -71, i16 71, i16 126, i16 25, i16 -106], [8 x i16] [i16 91, i16 -91, i16 -91, i16 91, i16 91, i16 -91, i16 -91, i16 91], [8 x i16] [i16 71, i16 -126, i16 25, i16 106, i16 -106, i16 -25, i16 126, i16 -71], [8 x i16] [i16 49, i16 -118, i16 118, i16 -49, i16 -49, i16 118, i16 -118, i16 49], [8 x i16] [i16 25, i16 -71, i16 106, i16 -126, i16 126, i16 -106, i16 71, i16 -25]], align 1
@title_end._title_bg_black = internal constant i16 0, align 1
@update_hud.H = internal unnamed_addr constant [17 x i8] c"0123456789ABCDEF\00", align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [21 x i8], align 1
  %2 = alloca [8 x [8 x i16]], align 1
  %3 = alloca [8 x [8 x i16]], align 1
  store volatile i8 -113, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  br label %4

4:                                                ; preds = %8, %0
  %5 = phi i16 [ 8449, %0 ], [ %9, %8 ]
  switch i16 %5, label %6 [
    i16 8452, label %8
    i16 8470, label %8
    i16 8471, label %8
    i16 8472, label %8
    i16 8473, label %8
    i16 8481, label %8
    i16 8482, label %8
  ]

6:                                                ; preds = %4
  %7 = inttoptr i16 %5 to ptr
  store volatile i8 0, ptr %7, align 1, !tbaa !6
  br label %8

8:                                                ; preds = %6, %4, %4, %4, %4, %4, %4, %4
  %9 = add nuw nsw i16 %5, 1
  %10 = icmp eq i16 %9, 8500
  br i1 %10, label %11, label %4, !llvm.loop !7

11:                                               ; preds = %8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) getelementptr inbounds nuw (i8, ptr @main.a, i16 176), i8 0, i64 6, i1 false)
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  store volatile i8 1, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 -127, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !6
  store ptr @CANVAS_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), align 1, !tbaa !15
  store i8 4, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !19
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4299), align 1, !tbaa !20
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4301), align 1, !tbaa !21
  store i8 8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4303), align 1, !tbaa !22
  store i8 3, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4304), align 1, !tbaa !23
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(4096) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i16 4096, i1 false), !tbaa !6
  store i16 -1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  store ptr @TEXT_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !26
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !28
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4308), align 1, !tbaa !29
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4310), align 1, !tbaa !6
  store i8 25, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4311), align 1, !tbaa !6
  br label %12

12:                                               ; preds = %12, %11
  %13 = phi i8 [ 0, %11 ], [ %19, %12 ]
  %14 = phi i16 [ 0, %11 ], [ %17, %12 ]
  %15 = zext i8 %13 to i16
  %16 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4312), i16 %15
  store i16 256, ptr %16, align 1, !tbaa !2
  %17 = add nuw nsw i16 %14, 1
  %18 = icmp eq i16 %17, 64
  %19 = add nuw i8 %13, 2
  br i1 %18, label %20, label %12, !llvm.loop !30

20:                                               ; preds = %12
  store i8 3, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %21 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %22 = icmp eq i8 %21, 0
  br i1 %22, label %24, label %23

23:                                               ; preds = %20
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %24

24:                                               ; preds = %23, %20
  %25 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %26 = icmp ult i8 %25, 4
  br i1 %26, label %27, label %31

27:                                               ; preds = %24
  %28 = zext nneg i8 %25 to i16
  %29 = add nuw nsw i8 %25, 1
  store i8 %29, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %30 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %28
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr %30, align 1, !tbaa !35
  br label %31

31:                                               ; preds = %27, %24
  tail call void @_canvas_reserve(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr nonnull poison) #12, !inline_history !37
  %32 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %33 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !39
  %34 = or i8 %33, %32
  store i8 %34, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %34, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %35 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %36 = icmp eq i8 %35, 0
  br i1 %36, label %38, label %37

37:                                               ; preds = %31
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %38

38:                                               ; preds = %37, %31
  %39 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %40 = icmp ult i8 %39, 4
  br i1 %40, label %41, label %45

41:                                               ; preds = %38
  %42 = zext nneg i8 %39 to i16
  %43 = add nuw nsw i8 %39, 1
  store i8 %43, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %44 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %42
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr %44, align 1, !tbaa !35
  br label %45

45:                                               ; preds = %41, %38
  %46 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !40
  %47 = load ptr, ptr %46, align 1, !tbaa !41
  tail call void %47(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 178)) #12, !inline_history !43
  %48 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %49 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !39
  %50 = or i8 %49, %48
  store i8 %50, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %50, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %51 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %52 = icmp ugt i8 %51, 15
  br i1 %52, label %64, label %53

53:                                               ; preds = %45
  %54 = zext nneg i8 %51 to i16
  %55 = add nuw nsw i8 %51, 1
  store i8 %55, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %56 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %54
  %57 = getelementptr inbounds nuw i8, ptr %56, i16 10
  store i8 1, ptr %57, align 1, !tbaa !45
  store i16 0, ptr %56, align 1, !tbaa !47
  %58 = getelementptr inbounds nuw i8, ptr %56, i16 9
  store i8 0, ptr %58, align 1, !tbaa !48
  %59 = getelementptr inbounds nuw i8, ptr %56, i16 7
  store i8 34, ptr %59, align 1, !tbaa !49
  %60 = getelementptr inbounds nuw i8, ptr %56, i16 8
  store i8 0, ptr %60, align 1, !tbaa !50
  %61 = getelementptr inbounds nuw i8, ptr %56, i16 2
  store i16 ptrtoint (ptr @bg3_pal to i16), ptr %61, align 1, !tbaa !51
  %62 = getelementptr inbounds nuw i8, ptr %56, i16 6
  store i8 0, ptr %62, align 1, !tbaa !52
  %63 = getelementptr inbounds nuw i8, ptr %56, i16 4
  store i16 8, ptr %63, align 1, !tbaa !53
  br label %64

64:                                               ; preds = %53, %45
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !54
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), align 1, !tbaa !56
  br label %65

65:                                               ; preds = %75, %64
  %66 = phi i8 [ 0, %64 ], [ %83, %75 ]
  %67 = phi i8 [ 0, %64 ], [ %82, %75 ]
  %68 = phi i8 [ 68, %64 ], [ %81, %75 ]
  %69 = zext i8 %68 to i16
  %70 = icmp ugt i8 %68, 31
  br i1 %70, label %71, label %75

71:                                               ; preds = %65
  %72 = icmp ult i8 %68, 96
  br i1 %72, label %73, label %75

73:                                               ; preds = %71
  %74 = add nuw nsw i16 %69, 224
  br label %75

75:                                               ; preds = %73, %71, %65
  %76 = phi i16 [ %74, %73 ], [ 256, %71 ], [ 256, %65 ]
  %77 = zext nneg i8 %67 to i16
  %78 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4318), i16 %77
  store i16 %76, ptr %78, align 1, !tbaa !2
  %79 = zext nneg i8 %66 to i16
  %80 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @.str.2, i16 1), i16 %79
  %81 = load i8, ptr %80, align 1, !tbaa !6
  %82 = add nuw nsw i8 %67, 2
  %83 = add nuw nsw i8 %66, 1
  %84 = icmp eq i8 %83, 17
  br i1 %84, label %85, label %65, !llvm.loop !57

85:                                               ; preds = %75
  %86 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %87 = or i8 %86, 1
  store i8 %87, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  store ptr @TITLE_VT, ptr @main.title, align 1, !tbaa !58
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !62
  store ptr @.str, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 3), align 1, !tbaa !63
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 5), align 1, !tbaa !64
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 7), align 1, !tbaa !65
  store i8 14, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 11), align 1, !tbaa !66
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 9), align 1, !tbaa !67
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 12), align 1, !tbaa !68
  store i16 96, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 13), align 1, !tbaa !69
  store i16 112, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 15), align 1, !tbaa !70
  store i16 16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 17), align 1, !tbaa !71
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 28), align 1, !tbaa !72
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !73
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !74
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !75
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !76
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !77
  store i16 32767, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 34), align 1, !tbaa !78
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 36), align 1, !tbaa !79
  %88 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %89 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %90 = icmp eq i8 %89, 0
  br i1 %90, label %92, label %91

91:                                               ; preds = %85
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %92

92:                                               ; preds = %91, %85
  %93 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %94 = icmp ult i8 %93, 4
  br i1 %94, label %95, label %99

95:                                               ; preds = %92
  %96 = zext nneg i8 %93 to i16
  %97 = add nuw nsw i8 %93, 1
  store i8 %97, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %98 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %96
  store ptr @main.title, ptr %98, align 1, !tbaa !35
  br label %99

99:                                               ; preds = %95, %92
  tail call void @_title_reserve(ptr noundef nonnull @main.title, ptr nonnull poison) #12, !inline_history !37
  %100 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %101 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %102 = or i8 %101, %100
  store volatile i8 %102, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store i8 %88, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !80
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 2, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 24, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  br label %103

103:                                              ; preds = %131, %99
  %104 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %105 = icmp eq i8 %104, 0
  br i1 %105, label %117, label %106

106:                                              ; preds = %103, %106
  %107 = phi i8 [ %114, %106 ], [ 0, %103 ]
  %108 = zext i8 %107 to i16
  %109 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %108
  %110 = load ptr, ptr %109, align 1, !tbaa !35
  %111 = load ptr, ptr %110, align 1, !tbaa !40
  %112 = getelementptr inbounds nuw i8, ptr %111, i16 2
  %113 = load ptr, ptr %112, align 1, !tbaa !81
  tail call void %113(ptr noundef nonnull %110, ptr noundef nonnull @main.a) #12, !inline_history !82
  %114 = add nuw i8 %107, 1
  %115 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %116 = icmp ult i8 %114, %115
  br i1 %116, label %106, label %117, !llvm.loop !83

117:                                              ; preds = %106, %103
  %118 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %119

119:                                              ; preds = %119, %117
  %120 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %121 = icmp sgt i8 %120, -1
  br i1 %121, label %119, label %122, !llvm.loop !84

122:                                              ; preds = %119
  tail call fastcc void @upq_flush() #13
  %123 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %124 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %125 = icmp ult i8 %123, %124
  br i1 %125, label %128, label %126

126:                                              ; preds = %122
  %127 = icmp ugt i8 %123, %124
  br i1 %127, label %128, label %131

128:                                              ; preds = %126, %122
  %129 = phi i8 [ 1, %122 ], [ -1, %126 ]
  %130 = add i8 %129, %123
  store i8 %130, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %131

131:                                              ; preds = %128, %126
  %132 = phi i8 [ %123, %126 ], [ %130, %128 ]
  %133 = and i8 %132, 15
  store volatile i8 %133, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %134 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %135 = icmp eq i8 %134, 15
  br i1 %135, label %136, label %103, !llvm.loop !85

136:                                              ; preds = %131
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !76
  %137 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !77
  %138 = icmp eq i8 %137, -1
  br i1 %138, label %176, label %139

139:                                              ; preds = %136, %168
  %140 = phi i8 [ %171, %168 ], [ 0, %136 ]
  %141 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %142 = icmp eq i8 %141, 0
  br i1 %142, label %154, label %143

143:                                              ; preds = %139, %143
  %144 = phi i8 [ %151, %143 ], [ 0, %139 ]
  %145 = zext i8 %144 to i16
  %146 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %145
  %147 = load ptr, ptr %146, align 1, !tbaa !35
  %148 = load ptr, ptr %147, align 1, !tbaa !40
  %149 = getelementptr inbounds nuw i8, ptr %148, i16 2
  %150 = load ptr, ptr %149, align 1, !tbaa !81
  tail call void %150(ptr noundef nonnull %147, ptr noundef nonnull @main.a) #12, !inline_history !86
  %151 = add nuw i8 %144, 1
  %152 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %153 = icmp ult i8 %151, %152
  br i1 %153, label %143, label %154, !llvm.loop !83

154:                                              ; preds = %143, %139
  %155 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %156

156:                                              ; preds = %156, %154
  %157 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %158 = icmp sgt i8 %157, -1
  br i1 %158, label %156, label %159, !llvm.loop !84

159:                                              ; preds = %156
  tail call fastcc void @upq_flush() #13
  %160 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %161 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %162 = icmp ult i8 %160, %161
  br i1 %162, label %165, label %163

163:                                              ; preds = %159
  %164 = icmp ugt i8 %160, %161
  br i1 %164, label %165, label %168

165:                                              ; preds = %163, %159
  %166 = phi i8 [ 1, %159 ], [ -1, %163 ]
  %167 = add i8 %166, %160
  store i8 %167, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %168

168:                                              ; preds = %165, %163
  %169 = phi i8 [ %160, %163 ], [ %167, %165 ]
  %170 = and i8 %169, 15
  store volatile i8 %170, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %171 = add nuw i8 %140, 1
  %172 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !77
  %173 = icmp ne i8 %172, -1
  %174 = icmp ult i8 %140, -57
  %175 = select i1 %173, i1 %174, i1 false
  br i1 %175, label %139, label %176, !llvm.loop !87

176:                                              ; preds = %168, %136
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !76
  %177 = getelementptr inbounds nuw i8, ptr %3, i16 16
  br label %178

178:                                              ; preds = %205, %176
  %179 = phi i16 [ 0, %176 ], [ %206, %205 ]
  %180 = phi i16 [ 0, %176 ], [ %195, %205 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #14
  call fastcc void @db_dct8x8(i16 noundef %179, ptr noundef %3) #13
  br label %181

181:                                              ; preds = %199, %178
  %182 = phi i8 [ %204, %199 ], [ 0, %178 ]
  %183 = phi ptr [ %202, %199 ], [ %3, %178 ]
  %184 = phi i8 [ %200, %199 ], [ 0, %178 ]
  %185 = phi i16 [ %195, %199 ], [ %180, %178 ]
  br label %186

186:                                              ; preds = %186, %181
  %187 = phi i8 [ 0, %181 ], [ %198, %186 ]
  %188 = phi i8 [ 0, %181 ], [ %196, %186 ]
  %189 = phi i16 [ %185, %181 ], [ %195, %186 ]
  %190 = tail call i16 @llvm.fshl.i16(i16 %189, i16 %189, i16 1)
  %191 = zext nneg i8 %187 to i16
  %192 = getelementptr i8, ptr %183, i16 %191
  %193 = load i16, ptr %192, align 1, !tbaa !2
  %194 = mul nsw i16 %193, 97
  %195 = xor i16 %194, %190
  %196 = add nuw nsw i8 %188, 1
  %197 = icmp eq i8 %196, 8
  %198 = add nuw nsw i8 %187, 2
  br i1 %197, label %199, label %186, !llvm.loop !88

199:                                              ; preds = %186
  %200 = add nuw nsw i8 %184, 1
  %201 = zext i8 %182 to i16
  %202 = getelementptr i8, ptr %177, i16 %201
  %203 = icmp eq i8 %200, 8
  %204 = add nuw i8 %182, 16
  br i1 %203, label %205, label %181, !llvm.loop !89

205:                                              ; preds = %199
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #14
  %206 = add nuw nsw i16 %179, 16
  %207 = icmp samesign ult i16 %179, 48
  br i1 %207, label %178, label %208, !llvm.loop !90

208:                                              ; preds = %205
  store volatile i16 %195, ptr @corpus_result, align 1, !tbaa !2
  br label %209

209:                                              ; preds = %239, %208
  %210 = phi i16 [ 90, %208 ], [ %211, %239 ]
  %211 = add nsw i16 %210, -1
  %212 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %213 = icmp eq i8 %212, 0
  br i1 %213, label %225, label %214

214:                                              ; preds = %209, %214
  %215 = phi i8 [ %222, %214 ], [ 0, %209 ]
  %216 = zext i8 %215 to i16
  %217 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %216
  %218 = load ptr, ptr %217, align 1, !tbaa !35
  %219 = load ptr, ptr %218, align 1, !tbaa !40
  %220 = getelementptr inbounds nuw i8, ptr %219, i16 2
  %221 = load ptr, ptr %220, align 1, !tbaa !81
  tail call void %221(ptr noundef nonnull %218, ptr noundef nonnull @main.a) #12, !inline_history !91
  %222 = add nuw i8 %215, 1
  %223 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %224 = icmp ult i8 %222, %223
  br i1 %224, label %214, label %225, !llvm.loop !83

225:                                              ; preds = %214, %209
  %226 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %227

227:                                              ; preds = %227, %225
  %228 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %229 = icmp sgt i8 %228, -1
  br i1 %229, label %227, label %230, !llvm.loop !84

230:                                              ; preds = %227
  tail call fastcc void @upq_flush() #13
  %231 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %232 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %233 = icmp ult i8 %231, %232
  br i1 %233, label %236, label %234

234:                                              ; preds = %230
  %235 = icmp ugt i8 %231, %232
  br i1 %235, label %236, label %239

236:                                              ; preds = %234, %230
  %237 = phi i8 [ 1, %230 ], [ -1, %234 ]
  %238 = add i8 %237, %231
  store i8 %238, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %239

239:                                              ; preds = %236, %234
  %240 = phi i8 [ %231, %234 ], [ %238, %236 ]
  %241 = and i8 %240, 15
  store volatile i8 %241, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %242 = icmp eq i16 %211, 0
  br i1 %242, label %243, label %209, !llvm.loop !92

243:                                              ; preds = %239
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !74
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !75
  br label %247

244:                                              ; preds = %276
  %245 = add nuw nsw i8 %248, 1
  %246 = icmp eq i8 %245, 90
  br i1 %246, label %281, label %247, !llvm.loop !93

247:                                              ; preds = %244, %243
  %248 = phi i8 [ 0, %243 ], [ %245, %244 ]
  %249 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %250 = icmp eq i8 %249, 0
  br i1 %250, label %262, label %251

251:                                              ; preds = %247, %251
  %252 = phi i8 [ %259, %251 ], [ 0, %247 ]
  %253 = zext i8 %252 to i16
  %254 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %253
  %255 = load ptr, ptr %254, align 1, !tbaa !35
  %256 = load ptr, ptr %255, align 1, !tbaa !40
  %257 = getelementptr inbounds nuw i8, ptr %256, i16 2
  %258 = load ptr, ptr %257, align 1, !tbaa !81
  tail call void %258(ptr noundef nonnull %255, ptr noundef nonnull @main.a) #12, !inline_history !94
  %259 = add nuw i8 %252, 1
  %260 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %261 = icmp ult i8 %259, %260
  br i1 %261, label %251, label %262, !llvm.loop !83

262:                                              ; preds = %251, %247
  %263 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %264

264:                                              ; preds = %264, %262
  %265 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %266 = icmp sgt i8 %265, -1
  br i1 %266, label %264, label %267, !llvm.loop !84

267:                                              ; preds = %264
  tail call fastcc void @upq_flush() #13
  %268 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %269 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %270 = icmp ult i8 %268, %269
  br i1 %270, label %273, label %271

271:                                              ; preds = %267
  %272 = icmp ugt i8 %268, %269
  br i1 %272, label %273, label %276

273:                                              ; preds = %271, %267
  %274 = phi i8 [ 1, %267 ], [ -1, %271 ]
  %275 = add i8 %274, %268
  store i8 %275, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %276

276:                                              ; preds = %273, %271
  %277 = phi i8 [ %268, %271 ], [ %275, %273 ]
  %278 = and i8 %277, 15
  store volatile i8 %278, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %279 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 19), align 1, !tbaa !95
  %280 = icmp sgt i16 %279, 3583
  br i1 %280, label %281, label %244

281:                                              ; preds = %276, %244
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !74
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %282 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %283 = icmp eq i8 %282, 0
  br i1 %283, label %317, label %284

284:                                              ; preds = %281, %312
  %285 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %286 = icmp eq i8 %285, 0
  br i1 %286, label %298, label %287

287:                                              ; preds = %284, %287
  %288 = phi i8 [ %295, %287 ], [ 0, %284 ]
  %289 = zext i8 %288 to i16
  %290 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %289
  %291 = load ptr, ptr %290, align 1, !tbaa !35
  %292 = load ptr, ptr %291, align 1, !tbaa !40
  %293 = getelementptr inbounds nuw i8, ptr %292, i16 2
  %294 = load ptr, ptr %293, align 1, !tbaa !81
  tail call void %294(ptr noundef nonnull %291, ptr noundef nonnull @main.a) #12, !inline_history !96
  %295 = add nuw i8 %288, 1
  %296 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %297 = icmp ult i8 %295, %296
  br i1 %297, label %287, label %298, !llvm.loop !83

298:                                              ; preds = %287, %284
  %299 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %300

300:                                              ; preds = %300, %298
  %301 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %302 = icmp sgt i8 %301, -1
  br i1 %302, label %300, label %303, !llvm.loop !84

303:                                              ; preds = %300
  tail call fastcc void @upq_flush() #13
  %304 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %305 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %306 = icmp ult i8 %304, %305
  br i1 %306, label %309, label %307

307:                                              ; preds = %303
  %308 = icmp ugt i8 %304, %305
  br i1 %308, label %309, label %312

309:                                              ; preds = %307, %303
  %310 = phi i8 [ 1, %303 ], [ -1, %307 ]
  %311 = add i8 %310, %304
  store i8 %311, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %312

312:                                              ; preds = %309, %307
  %313 = phi i8 [ %304, %307 ], [ %311, %309 ]
  %314 = and i8 %313, 15
  store volatile i8 %314, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %315 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %316 = icmp eq i8 %315, 0
  br i1 %316, label %317, label %284, !llvm.loop !85

317:                                              ; preds = %312, %281
  %318 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !80
  %319 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %320 = or i8 %319, %318
  %321 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %322 = xor i8 %321, -1
  %323 = and i8 %320, %322
  store i8 %323, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %323, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !73
  %324 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %325 = icmp ugt i8 %324, 15
  br i1 %325, label %337, label %326

326:                                              ; preds = %317
  %327 = zext nneg i8 %324 to i16
  %328 = add nuw nsw i8 %324, 1
  store i8 %328, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %329 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %327
  %330 = getelementptr inbounds nuw i8, ptr %329, i16 10
  store i8 1, ptr %330, align 1, !tbaa !45
  store i16 0, ptr %329, align 1, !tbaa !47
  %331 = getelementptr inbounds nuw i8, ptr %329, i16 9
  store i8 0, ptr %331, align 1, !tbaa !48
  %332 = getelementptr inbounds nuw i8, ptr %329, i16 7
  store i8 34, ptr %332, align 1, !tbaa !49
  %333 = getelementptr inbounds nuw i8, ptr %329, i16 8
  store i8 0, ptr %333, align 1, !tbaa !50
  %334 = getelementptr inbounds nuw i8, ptr %329, i16 2
  store i16 ptrtoint (ptr @title_end._title_bg_black to i16), ptr %334, align 1, !tbaa !51
  %335 = getelementptr inbounds nuw i8, ptr %329, i16 6
  store i8 0, ptr %335, align 1, !tbaa !52
  %336 = getelementptr inbounds nuw i8, ptr %329, i16 4
  store i16 2, ptr %336, align 1, !tbaa !53
  br label %337

337:                                              ; preds = %317, %326
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %338 = getelementptr inbounds nuw i8, ptr %1, i16 1
  %339 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %340 = getelementptr inbounds nuw i8, ptr %1, i16 3
  %341 = getelementptr inbounds nuw i8, ptr %1, i16 4
  %342 = getelementptr inbounds nuw i8, ptr %1, i16 5
  %343 = getelementptr inbounds nuw i8, ptr %1, i16 6
  %344 = getelementptr inbounds nuw i8, ptr %1, i16 7
  %345 = getelementptr inbounds nuw i8, ptr %1, i16 8
  %346 = getelementptr inbounds nuw i8, ptr %1, i16 9
  %347 = getelementptr inbounds nuw i8, ptr %1, i16 10
  %348 = getelementptr inbounds nuw i8, ptr %1, i16 11
  %349 = getelementptr inbounds nuw i8, ptr %1, i16 12
  %350 = getelementptr inbounds nuw i8, ptr %1, i16 13
  %351 = getelementptr inbounds nuw i8, ptr %1, i16 14
  %352 = getelementptr inbounds nuw i8, ptr %1, i16 15
  %353 = getelementptr inbounds nuw i8, ptr %1, i16 16
  %354 = getelementptr inbounds nuw i8, ptr %1, i16 20
  %355 = getelementptr inbounds nuw i8, ptr %2, i16 16
  br label %356

356:                                              ; preds = %510, %337
  %357 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), align 1, !tbaa !56
  %358 = add i16 %357, 1
  store i16 %358, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), align 1, !tbaa !56
  %359 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !54
  %360 = add nsw i16 %359, 3
  store i16 %360, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !54
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #14
  call fastcc void @db_dct8x8(i16 noundef %360, ptr noundef %2) #13
  br label %361

361:                                              ; preds = %403, %356
  %362 = phi i8 [ 0, %356 ], [ %404, %403 ]
  %363 = zext nneg i8 %362 to i16
  %364 = mul nuw nsw i16 %363, 24
  br label %365

365:                                              ; preds = %399, %361
  %366 = phi i8 [ 0, %361 ], [ %401, %399 ]
  %367 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !54
  %368 = zext nneg i8 %366 to i16
  %369 = mul nuw nsw i16 %368, 40
  %370 = add nsw i16 %369, %367
  %371 = and i16 %370, 255
  %372 = sub nsw i16 %364, %367
  %373 = and i16 %372, 255
  %374 = add nuw nsw i16 %371, %373
  %375 = add nsw i16 %374, -256
  %376 = xor i16 %368, %363
  %377 = and i16 %376, 1
  %378 = icmp eq i16 %377, 0
  br i1 %378, label %381, label %379

379:                                              ; preds = %365
  %380 = add nsw i16 %374, -216
  br label %381

381:                                              ; preds = %379, %365
  %382 = phi i16 [ %380, %379 ], [ %375, %365 ]
  %383 = icmp sgt i16 %382, 127
  br i1 %383, label %399, label %384

384:                                              ; preds = %381
  %385 = icmp slt i16 %382, -128
  br i1 %385, label %388, label %386

386:                                              ; preds = %384
  %387 = icmp slt i16 %382, 0
  br i1 %387, label %388, label %391

388:                                              ; preds = %386, %384
  %389 = phi i16 [ %382, %386 ], [ -128, %384 ]
  %390 = sub nsw i16 0, %389
  br label %391

391:                                              ; preds = %388, %386
  %392 = phi i16 [ %390, %388 ], [ %382, %386 ]
  %393 = icmp samesign ugt i16 %392, 95
  br i1 %393, label %399, label %394

394:                                              ; preds = %391
  %395 = icmp samesign ugt i16 %392, 39
  br i1 %395, label %399, label %396

396:                                              ; preds = %394
  %397 = icmp samesign ugt i16 %392, 11
  %398 = zext i1 %397 to i8
  br label %399

399:                                              ; preds = %396, %394, %391, %381
  %400 = phi i8 [ 2, %394 ], [ 3, %391 ], [ %398, %396 ], [ 3, %381 ]
  tail call fastcc void @fill_cell(i8 noundef zeroext 4, i8 noundef zeroext %366, i8 noundef zeroext %362, i8 noundef zeroext %400) #13
  %401 = add nuw nsw i8 %366, 1
  %402 = icmp eq i8 %401, 8
  br i1 %402, label %403, label %365, !llvm.loop !97

403:                                              ; preds = %399
  %404 = add nuw nsw i8 %362, 1
  %405 = icmp eq i8 %404, 8
  br i1 %405, label %406, label %361, !llvm.loop !98

406:                                              ; preds = %403, %432
  %407 = phi i8 [ %437, %432 ], [ 0, %403 ]
  %408 = phi ptr [ %435, %432 ], [ %2, %403 ]
  %409 = phi i8 [ %433, %432 ], [ 0, %403 ]
  br label %410

410:                                              ; preds = %427, %406
  %411 = phi i8 [ 0, %406 ], [ %431, %427 ]
  %412 = phi i8 [ 0, %406 ], [ %429, %427 ]
  %413 = zext nneg i8 %411 to i16
  %414 = getelementptr i8, ptr %408, i16 %413
  %415 = load i16, ptr %414, align 1, !tbaa !2
  %416 = icmp slt i16 %415, 0
  br i1 %416, label %417, label %419

417:                                              ; preds = %410
  %418 = sub nsw i16 0, %415
  br label %419

419:                                              ; preds = %417, %410
  %420 = phi i16 [ %418, %417 ], [ %415, %410 ]
  %421 = icmp samesign ugt i16 %420, 95
  br i1 %421, label %427, label %422

422:                                              ; preds = %419
  %423 = icmp samesign ugt i16 %420, 39
  br i1 %423, label %427, label %424

424:                                              ; preds = %422
  %425 = icmp samesign ugt i16 %420, 11
  %426 = zext i1 %425 to i8
  br label %427

427:                                              ; preds = %424, %422, %419
  %428 = phi i8 [ 2, %422 ], [ 3, %419 ], [ %426, %424 ]
  tail call fastcc void @fill_cell(i8 noundef zeroext 72, i8 noundef zeroext %412, i8 noundef zeroext %409, i8 noundef zeroext %428) #13
  %429 = add nuw nsw i8 %412, 1
  %430 = icmp eq i8 %429, 8
  %431 = add nuw nsw i8 %411, 2
  br i1 %430, label %432, label %410, !llvm.loop !99

432:                                              ; preds = %427
  %433 = add nuw nsw i8 %409, 1
  %434 = zext i8 %407 to i16
  %435 = getelementptr i8, ptr %355, i16 %434
  %436 = icmp eq i8 %433, 8
  %437 = add nuw i8 %407, 16
  br i1 %436, label %438, label %406, !llvm.loop !100

438:                                              ; preds = %432
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #14
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #14
  store i8 82, ptr %338, align 1, !tbaa !6
  store i8 67, ptr %339, align 1, !tbaa !6
  store i8 61, ptr %340, align 1, !tbaa !6
  %439 = load volatile i16, ptr @corpus_result, align 1, !tbaa !2
  %440 = lshr i16 %439, 12
  %441 = getelementptr inbounds nuw i8, ptr @update_hud.H, i16 %440
  %442 = load i8, ptr %441, align 1, !tbaa !6
  store i8 %442, ptr %341, align 1, !tbaa !6
  %443 = load volatile i16, ptr @corpus_result, align 1, !tbaa !2
  %444 = lshr i16 %443, 8
  %445 = and i16 %444, 15
  %446 = getelementptr inbounds nuw i8, ptr @update_hud.H, i16 %445
  %447 = load i8, ptr %446, align 1, !tbaa !6
  store i8 %447, ptr %342, align 1, !tbaa !6
  %448 = load volatile i16, ptr @corpus_result, align 1, !tbaa !2
  %449 = lshr i16 %448, 4
  %450 = and i16 %449, 15
  %451 = getelementptr inbounds nuw i8, ptr @update_hud.H, i16 %450
  %452 = load i8, ptr %451, align 1, !tbaa !6
  store i8 %452, ptr %343, align 1, !tbaa !6
  %453 = load volatile i16, ptr @corpus_result, align 1, !tbaa !2
  %454 = and i16 %453, 15
  %455 = getelementptr inbounds nuw i8, ptr @update_hud.H, i16 %454
  %456 = load i8, ptr %455, align 1, !tbaa !6
  store i8 %456, ptr %344, align 1, !tbaa !6
  store i8 32, ptr %345, align 1, !tbaa !6
  store i8 83, ptr %346, align 1, !tbaa !6
  store i8 82, ptr %347, align 1, !tbaa !6
  store i8 67, ptr %348, align 1, !tbaa !6
  store i8 124, ptr %349, align 1, !tbaa !6
  store i8 68, ptr %350, align 1, !tbaa !6
  store i8 67, ptr %351, align 1, !tbaa !6
  store i8 84, ptr %352, align 1, !tbaa !6
  store i32 538976288, ptr %353, align 1
  store i8 0, ptr %354, align 1, !tbaa !6
  br label %462

457:                                              ; preds = %472
  %458 = add nuw nsw i8 %465, 2
  %459 = add nuw nsw i8 %466, 1
  %460 = zext i8 %478 to i16
  %461 = icmp eq i8 %459, 32
  br i1 %461, label %480, label %462, !llvm.loop !57

462:                                              ; preds = %438, %457
  %463 = phi i16 [ 67, %438 ], [ %460, %457 ]
  %464 = phi i8 [ 67, %438 ], [ %478, %457 ]
  %465 = phi i8 [ 0, %438 ], [ %458, %457 ]
  %466 = phi i8 [ 0, %438 ], [ %459, %457 ]
  %467 = icmp ugt i8 %464, 31
  br i1 %467, label %468, label %472

468:                                              ; preds = %462
  %469 = icmp ult i8 %464, 96
  br i1 %469, label %470, label %472

470:                                              ; preds = %468
  %471 = add nuw nsw i16 %463, 224
  br label %472

472:                                              ; preds = %470, %468, %462
  %473 = phi i16 [ %471, %470 ], [ 256, %468 ], [ 256, %462 ]
  %474 = zext nneg i8 %465 to i16
  %475 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4376), i16 %474
  store i16 %473, ptr %475, align 1, !tbaa !2
  %476 = zext nneg i8 %466 to i16
  %477 = getelementptr i8, ptr %338, i16 %476
  %478 = load i8, ptr %477, align 1, !tbaa !6
  %479 = icmp eq i8 %478, 0
  br i1 %479, label %480, label %457, !llvm.loop !57

480:                                              ; preds = %457, %472
  %481 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %482 = or i8 %481, 2
  store i8 %482, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #14
  %483 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %484 = icmp eq i8 %483, 0
  br i1 %484, label %496, label %485

485:                                              ; preds = %480, %485
  %486 = phi i8 [ %493, %485 ], [ 0, %480 ]
  %487 = zext i8 %486 to i16
  %488 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %487
  %489 = load ptr, ptr %488, align 1, !tbaa !35
  %490 = load ptr, ptr %489, align 1, !tbaa !40
  %491 = getelementptr inbounds nuw i8, ptr %490, i16 2
  %492 = load ptr, ptr %491, align 1, !tbaa !81
  tail call void %492(ptr noundef nonnull %489, ptr noundef nonnull @main.a) #12, !inline_history !101
  %493 = add nuw i8 %486, 1
  %494 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %495 = icmp ult i8 %493, %494
  br i1 %495, label %485, label %496, !llvm.loop !83

496:                                              ; preds = %485, %480
  %497 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %498

498:                                              ; preds = %498, %496
  %499 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %500 = icmp sgt i8 %499, -1
  br i1 %500, label %498, label %501, !llvm.loop !84

501:                                              ; preds = %498
  tail call fastcc void @upq_flush() #13
  %502 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %503 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %504 = icmp ult i8 %502, %503
  br i1 %504, label %507, label %505

505:                                              ; preds = %501
  %506 = icmp ugt i8 %502, %503
  br i1 %506, label %507, label %510

507:                                              ; preds = %505, %501
  %508 = phi i8 [ 1, %501 ], [ -1, %505 ]
  %509 = add i8 %508, %502
  store i8 %509, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %510

510:                                              ; preds = %505, %507
  %511 = phi i8 [ %502, %505 ], [ %509, %507 ]
  %512 = and i8 %511, 15
  store volatile i8 %512, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  br label %356
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_canvas_reserve(ptr noundef readonly captures(none) %0, ptr readnone captures(none) %1) #2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4105
  %4 = load i16, ptr %3, align 1, !tbaa !21
  %5 = lshr i16 %4, 8
  %6 = trunc nuw i16 %5 to i8
  %7 = and i8 %6, -4
  store volatile i8 %7, ptr inttoptr (i16 8457 to ptr), align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %9 = load i16, ptr %8, align 1, !tbaa !20
  %10 = lshr i16 %9, 12
  %11 = trunc nuw nsw i16 %10 to i8
  store volatile i8 %11, ptr inttoptr (i16 8460 to ptr), align 4, !tbaa !6
  %12 = load i16, ptr %8, align 1, !tbaa !20
  %13 = lshr i16 %12, 3
  %14 = add nuw nsw i16 %13, 256
  %15 = load i16, ptr %3, align 1, !tbaa !21
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %15, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %16 = getelementptr inbounds nuw i8, ptr %0, i16 4107
  %17 = load i8, ptr %16, align 1, !tbaa !22
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 4108
  br label %19

19:                                               ; preds = %2, %23
  %20 = phi i8 [ 0, %2 ], [ %24, %23 ]
  br label %26

21:                                               ; preds = %23
  %22 = load i16, ptr %8, align 1, !tbaa !20
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %22, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %45

23:                                               ; preds = %40
  %24 = add nuw nsw i8 %20, 1
  %25 = icmp eq i8 %24, 32
  br i1 %25, label %21, label %19, !llvm.loop !102

26:                                               ; preds = %19, %40
  %27 = phi i8 [ 0, %19 ], [ %42, %40 ]
  %28 = sub i8 %27, %17
  %29 = zext i8 %28 to i16
  %30 = icmp ult i8 %28, 16
  br i1 %30, label %31, label %40

31:                                               ; preds = %26
  %32 = load i8, ptr %18, align 1, !tbaa !23
  %33 = sub i8 %20, %32
  %34 = icmp ult i8 %33, 16
  br i1 %34, label %35, label %40

35:                                               ; preds = %31
  %36 = shl nuw i8 %33, 4
  %37 = zext i8 %36 to i16
  %38 = add nuw nsw i16 %13, %29
  %39 = add nuw nsw i16 %38, %37
  br label %40

40:                                               ; preds = %26, %31, %35
  %41 = phi i16 [ %39, %35 ], [ %14, %31 ], [ %14, %26 ]
  store volatile i16 %41, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %42 = add nuw nsw i8 %27, 1
  %43 = icmp eq i8 %42, 32
  br i1 %43, label %23, label %26, !llvm.loop !103

44:                                               ; preds = %45
  ret void

45:                                               ; preds = %21, %45
  %46 = phi i16 [ 0, %21 ], [ %47, %45 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %47 = add nuw nsw i16 %46, 1
  %48 = icmp eq i16 %47, 2056
  br i1 %48, label %44, label %45, !llvm.loop !104
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal void @_canvas_emit(ptr noundef %0, ptr noundef captures(none) %1) #3 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4099
  %4 = load i16, ptr %3, align 1, !tbaa !24
  %5 = getelementptr inbounds nuw i8, ptr %0, i16 4101
  %6 = load i16, ptr %5, align 1, !tbaa !25
  %7 = icmp ugt i16 %4, %6
  br i1 %7, label %48, label %8

8:                                                ; preds = %2
  %9 = sub nuw i16 %6, %4
  %10 = add i16 %9, -256
  %11 = icmp ult i16 %10, -257
  br i1 %11, label %12, label %14

12:                                               ; preds = %8
  %13 = add i16 %4, 255
  br label %14

14:                                               ; preds = %12, %8
  %15 = phi i16 [ 255, %12 ], [ %9, %8 ]
  %16 = phi i16 [ %13, %12 ], [ %6, %8 ]
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %18 = load i16, ptr %17, align 1, !tbaa !20
  %19 = shl i16 %4, 3
  %20 = add i16 %18, %19
  %21 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %22 = shl i16 %4, 4
  %23 = getelementptr inbounds nuw i8, ptr %21, i16 %22
  %24 = shl nsw i16 %15, 4
  %25 = add nsw i16 %24, 16
  %26 = icmp eq i16 %25, 0
  br i1 %26, label %43, label %27

27:                                               ; preds = %14
  %28 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %29 = load i8, ptr %28, align 1, !tbaa !44
  %30 = icmp ugt i8 %29, 15
  br i1 %30, label %43, label %31

31:                                               ; preds = %27
  %32 = zext nneg i8 %29 to i16
  %33 = add nuw nsw i8 %29, 1
  store i8 %33, ptr %28, align 1, !tbaa !44
  %34 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %32
  %35 = getelementptr inbounds nuw i8, ptr %34, i16 10
  store i8 0, ptr %35, align 1, !tbaa !45
  store i16 %20, ptr %34, align 1, !tbaa !47
  %36 = getelementptr inbounds nuw i8, ptr %34, i16 9
  store i8 -128, ptr %36, align 1, !tbaa !48
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 7
  store i8 24, ptr %37, align 1, !tbaa !49
  %38 = getelementptr inbounds nuw i8, ptr %34, i16 8
  store i8 1, ptr %38, align 1, !tbaa !50
  %39 = ptrtoint ptr %23 to i16
  %40 = getelementptr inbounds nuw i8, ptr %34, i16 2
  store i16 %39, ptr %40, align 1, !tbaa !51
  %41 = getelementptr inbounds nuw i8, ptr %34, i16 6
  store i8 0, ptr %41, align 1, !tbaa !52
  %42 = getelementptr inbounds nuw i8, ptr %34, i16 4
  store i16 %25, ptr %42, align 1, !tbaa !53
  br label %43

43:                                               ; preds = %14, %27, %31
  %44 = icmp ult i16 %16, %6
  br i1 %44, label %46, label %45

45:                                               ; preds = %43
  store i16 -1, ptr %3, align 1, !tbaa !24
  store i16 0, ptr %5, align 1, !tbaa !25
  br label %48

46:                                               ; preds = %43
  %47 = add nuw i16 %16, 1
  store i16 %47, ptr %3, align 1, !tbaa !24
  br label %48

48:                                               ; preds = %45, %46, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_text_reserve(ptr readnone captures(none) %0, ptr readnone captures(none) %1) #2 {
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 2048, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %4

3:                                                ; preds = %4
  ret void

4:                                                ; preds = %2, %4
  %5 = phi i16 [ 0, %2 ], [ %8, %4 ]
  %6 = getelementptr inbounds nuw [2 x i8], ptr @FONT8, i16 %5
  %7 = load i16, ptr %6, align 1, !tbaa !2
  store volatile i16 %7, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %8 = add nuw nsw i16 %5, 1
  %9 = icmp eq i16 %8, 512
  br i1 %9, label %3, label %4, !llvm.loop !105
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(argmem: readwrite)
define internal void @_text_emit(ptr noundef %0, ptr noundef captures(none) %1) #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 135
  %4 = load i8, ptr %3, align 1, !tbaa !31
  %5 = zext i8 %4 to i16
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %7 = getelementptr i8, ptr %0, i16 7
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %9 = getelementptr i8, ptr %0, i16 5
  br label %11

10:                                               ; preds = %42
  store i8 0, ptr %3, align 1, !tbaa !31
  ret void

11:                                               ; preds = %2, %42
  %12 = phi i8 [ 0, %2 ], [ %43, %42 ]
  %13 = phi i1 [ true, %2 ], [ false, %42 ]
  %14 = phi i8 [ 0, %2 ], [ 1, %42 ]
  %15 = zext nneg i8 %14 to i16
  %16 = shl nuw nsw i16 1, %15
  %17 = and i16 %16, %5
  %18 = icmp eq i16 %17, 0
  br i1 %18, label %42, label %19

19:                                               ; preds = %11
  %20 = load i8, ptr %6, align 1, !tbaa !44
  %21 = icmp ugt i8 %20, 15
  br i1 %21, label %42, label %22

22:                                               ; preds = %19
  %23 = zext i8 %12 to i16
  %24 = getelementptr i8, ptr %7, i16 %23
  %25 = load i16, ptr %8, align 1, !tbaa !29
  %26 = getelementptr i8, ptr %9, i16 %15
  %27 = load i8, ptr %26, align 1, !tbaa !6
  %28 = zext i8 %27 to i16
  %29 = shl nuw nsw i16 %28, 5
  %30 = add i16 %29, %25
  %31 = zext nneg i8 %20 to i16
  %32 = add nuw nsw i8 %20, 1
  store i8 %32, ptr %6, align 1, !tbaa !44
  %33 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %31
  %34 = getelementptr inbounds nuw i8, ptr %33, i16 10
  store i8 0, ptr %34, align 1, !tbaa !45
  store i16 %30, ptr %33, align 1, !tbaa !47
  %35 = getelementptr inbounds nuw i8, ptr %33, i16 9
  store i8 -128, ptr %35, align 1, !tbaa !48
  %36 = getelementptr inbounds nuw i8, ptr %33, i16 7
  store i8 24, ptr %36, align 1, !tbaa !49
  %37 = getelementptr inbounds nuw i8, ptr %33, i16 8
  store i8 1, ptr %37, align 1, !tbaa !50
  %38 = ptrtoint ptr %24 to i16
  %39 = getelementptr inbounds nuw i8, ptr %33, i16 2
  store i16 %38, ptr %39, align 1, !tbaa !51
  %40 = getelementptr inbounds nuw i8, ptr %33, i16 6
  store i8 0, ptr %40, align 1, !tbaa !52
  %41 = getelementptr inbounds nuw i8, ptr %33, i16 4
  store i16 64, ptr %41, align 1, !tbaa !53
  br label %42

42:                                               ; preds = %22, %19, %11
  %43 = add nuw i8 %12, 64
  br i1 %13, label %11, label %10, !llvm.loop !106
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_title_reserve(ptr noundef %0, ptr readnone captures(none) %1) #2 {
  store volatile i8 80, ptr inttoptr (i16 8456 to ptr), align 8, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !6
  store volatile i8 112, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -1, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 127, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -124, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 4096, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %3

3:                                                ; preds = %2, %16
  %4 = phi ptr [ @FONT8, %2 ], [ %18, %16 ]
  %5 = phi i16 [ 0, %2 ], [ %17, %16 ]
  br label %7

6:                                                ; preds = %16
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 5120, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %24

7:                                                ; preds = %3, %7
  %8 = phi i8 [ 0, %3 ], [ %15, %7 ]
  %9 = phi i8 [ 0, %3 ], [ %13, %7 ]
  %10 = zext nneg i8 %8 to i16
  %11 = getelementptr i8, ptr %4, i16 %10
  %12 = load i16, ptr %11, align 1, !tbaa !2
  store volatile i16 %12, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %13 = add nuw nsw i8 %9, 1
  %14 = icmp eq i8 %13, 8
  %15 = add nuw nsw i8 %8, 2
  br i1 %14, label %20, label %7, !llvm.loop !107

16:                                               ; preds = %20
  %17 = add nuw nsw i16 %5, 1
  %18 = getelementptr i8, ptr %4, i16 16
  %19 = icmp eq i16 %17, 64
  br i1 %19, label %6, label %3, !llvm.loop !108

20:                                               ; preds = %7, %20
  %21 = phi i8 [ %22, %20 ], [ 0, %7 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %22 = add nuw nsw i8 %21, 1
  %23 = icmp eq i8 %22, 8
  br i1 %23, label %16, label %20, !llvm.loop !109

24:                                               ; preds = %6, %33
  %25 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 16), %6 ], [ %36, %33 ]
  %26 = phi ptr [ @FONT16, %6 ], [ %35, %33 ]
  %27 = phi i16 [ 0, %6 ], [ %34, %33 ]
  br label %29

28:                                               ; preds = %33
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 20480, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %66

29:                                               ; preds = %24, %47
  %30 = phi i8 [ 0, %24 ], [ %52, %47 ]
  %31 = phi ptr [ %26, %24 ], [ %50, %47 ]
  %32 = phi i8 [ 0, %24 ], [ %48, %47 ]
  br label %38

33:                                               ; preds = %47
  %34 = add nuw nsw i16 %27, 1
  %35 = getelementptr i8, ptr %26, i16 64
  %36 = getelementptr i8, ptr %25, i16 64
  %37 = icmp eq i16 %34, 64
  br i1 %37, label %28, label %24, !llvm.loop !110

38:                                               ; preds = %29, %38
  %39 = phi i8 [ 0, %29 ], [ %46, %38 ]
  %40 = phi i8 [ 0, %29 ], [ %44, %38 ]
  %41 = zext nneg i8 %39 to i16
  %42 = getelementptr i8, ptr %31, i16 %41
  %43 = load i16, ptr %42, align 1, !tbaa !2
  store volatile i16 %43, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %44 = add nuw nsw i8 %40, 1
  %45 = icmp eq i8 %44, 8
  %46 = add nuw nsw i8 %39, 2
  br i1 %45, label %53, label %38, !llvm.loop !111

47:                                               ; preds = %53
  %48 = add nuw nsw i8 %32, 1
  %49 = zext nneg i8 %30 to i16
  %50 = getelementptr i8, ptr %25, i16 %49
  %51 = icmp eq i8 %48, 4
  %52 = add nuw nsw i8 %30, 16
  br i1 %51, label %33, label %29, !llvm.loop !112

53:                                               ; preds = %38, %53
  %54 = phi i8 [ %55, %53 ], [ 0, %38 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %55 = add nuw nsw i8 %54, 1
  %56 = icmp eq i8 %55, 8
  br i1 %56, label %47, label %53, !llvm.loop !113

57:                                               ; preds = %66
  %58 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %59 = load ptr, ptr %58, align 1, !tbaa !63
  %60 = icmp eq ptr %59, null
  br i1 %60, label %79, label %61

61:                                               ; preds = %57
  %62 = load i8, ptr %59, align 1, !tbaa !6
  %63 = icmp eq i8 %62, 0
  br i1 %63, label %79, label %64

64:                                               ; preds = %61
  %65 = getelementptr i8, ptr %59, i16 1
  br label %70

66:                                               ; preds = %28, %66
  %67 = phi i16 [ 0, %28 ], [ %68, %66 ]
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %68 = add nuw nsw i16 %67, 1
  %69 = icmp eq i16 %68, 1024
  br i1 %69, label %57, label %66, !llvm.loop !114

70:                                               ; preds = %64, %70
  %71 = phi i8 [ %72, %70 ], [ 0, %64 ]
  %72 = add nuw nsw i8 %71, 1
  %73 = zext nneg i8 %71 to i16
  %74 = getelementptr i8, ptr %65, i16 %73
  %75 = load i8, ptr %74, align 1, !tbaa !6
  %76 = icmp ne i8 %75, 0
  %77 = icmp samesign ult i8 %71, 31
  %78 = select i1 %76, i1 %77, i1 false
  br i1 %78, label %70, label %79, !llvm.loop !115

79:                                               ; preds = %70, %61, %57
  %80 = phi i8 [ 0, %57 ], [ 0, %61 ], [ %72, %70 ]
  %81 = zext nneg i8 %80 to i16
  %82 = sub nuw nsw i16 32, %81
  %83 = lshr i16 %82, 1
  %84 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %85 = load i16, ptr %84, align 1, !tbaa !69
  %86 = shl i16 %85, 2
  %87 = and i16 %86, -32
  %88 = add i16 %87, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %88, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %89 = trunc nuw nsw i16 %83 to i8
  %90 = add nuw nsw i8 %80, %89
  %91 = sub nsw i16 0, %83
  %92 = getelementptr i8, ptr %59, i16 %91
  br label %105

93:                                               ; preds = %128
  %94 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %95 = load ptr, ptr %94, align 1, !tbaa !65
  %96 = getelementptr inbounds nuw i8, ptr %0, i16 11
  %97 = load i8, ptr %96, align 1, !tbaa !66
  %98 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %99 = load i16, ptr %98, align 1, !tbaa !70
  %100 = lshr i16 %99, 3
  %101 = trunc i16 %100 to i8
  tail call fastcc void @_title_write16(ptr noundef %95, i8 noundef zeroext %97, i8 noundef zeroext %101) #13
  %102 = getelementptr inbounds nuw i8, ptr %0, i16 9
  %103 = load ptr, ptr %102, align 1, !tbaa !67
  %104 = icmp eq ptr %103, null
  br i1 %104, label %139, label %132

105:                                              ; preds = %79, %128
  %106 = phi i8 [ 0, %79 ], [ %130, %128 ]
  %107 = zext nneg i8 %106 to i16
  br i1 %60, label %128, label %108

108:                                              ; preds = %105
  %109 = icmp samesign ugt i16 %83, %107
  br i1 %109, label %128, label %110

110:                                              ; preds = %108
  %111 = icmp ult i8 %106, %90
  br i1 %111, label %112, label %128

112:                                              ; preds = %110
  %113 = getelementptr i8, ptr %92, i16 %107
  %114 = load i8, ptr %113, align 1, !tbaa !6
  %115 = icmp ugt i8 %114, 96
  br i1 %115, label %116, label %120

116:                                              ; preds = %112
  %117 = icmp ult i8 %114, 123
  br i1 %117, label %118, label %128

118:                                              ; preds = %116
  %119 = add nsw i8 %114, -32
  br label %124

120:                                              ; preds = %112
  %121 = icmp samesign ugt i8 %114, 31
  br i1 %121, label %122, label %128

122:                                              ; preds = %120
  %123 = icmp eq i8 %114, 96
  br i1 %123, label %128, label %124

124:                                              ; preds = %122, %118
  %125 = phi i8 [ %119, %118 ], [ %114, %122 ]
  %126 = zext nneg i8 %125 to i16
  %127 = add nuw nsw i16 %126, 7136
  br label %128

128:                                              ; preds = %124, %122, %120, %116, %105, %108, %110
  %129 = phi i16 [ 7168, %105 ], [ 7168, %110 ], [ 7168, %108 ], [ %127, %124 ], [ 7168, %122 ], [ 7168, %120 ], [ 7168, %116 ]
  store volatile i16 %129, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %130 = add nuw nsw i8 %106, 1
  %131 = icmp eq i8 %130, 32
  br i1 %131, label %93, label %105, !llvm.loop !116

132:                                              ; preds = %93
  %133 = getelementptr inbounds nuw i8, ptr %0, i16 12
  %134 = load i8, ptr %133, align 1, !tbaa !68
  %135 = load i16, ptr %98, align 1, !tbaa !70
  %136 = lshr i16 %135, 3
  %137 = trunc i16 %136 to i8
  %138 = add i8 %137, 2
  tail call fastcc void @_title_write16(ptr noundef nonnull %103, i8 noundef zeroext %134, i8 noundef zeroext %138) #13
  br label %139

139:                                              ; preds = %132, %93
  %140 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 -128, ptr %140, align 1, !tbaa !95
  %141 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 3584, ptr %141, align 1, !tbaa !117
  %142 = getelementptr inbounds nuw i8, ptr %0, i16 23
  store i16 0, ptr %142, align 1, !tbaa !118
  %143 = load ptr, ptr %58, align 1, !tbaa !63
  %144 = icmp eq ptr %143, null
  br i1 %144, label %167, label %145

145:                                              ; preds = %139
  %146 = load i8, ptr %143, align 1, !tbaa !6
  %147 = icmp eq i8 %146, 0
  br i1 %147, label %150, label %148

148:                                              ; preds = %145
  %149 = getelementptr i8, ptr %143, i16 1
  br label %158

150:                                              ; preds = %158, %145
  %151 = phi i8 [ 0, %145 ], [ %160, %158 ]
  %152 = zext nneg i8 %151 to i16
  %153 = shl nuw nsw i16 %152, 2
  %154 = sub nuw nsw i16 128, %153
  %155 = and i16 %154, 248
  %156 = add nsw i16 %153, -128
  %157 = add nsw i16 %156, %155
  br label %167

158:                                              ; preds = %158, %148
  %159 = phi i8 [ %160, %158 ], [ 0, %148 ]
  %160 = add nuw nsw i8 %159, 1
  %161 = zext nneg i8 %159 to i16
  %162 = getelementptr i8, ptr %149, i16 %161
  %163 = load i8, ptr %162, align 1, !tbaa !6
  %164 = icmp ne i8 %163, 0
  %165 = icmp samesign ult i8 %159, 31
  %166 = select i1 %164, i1 %165, i1 false
  br i1 %166, label %158, label %150, !llvm.loop !119

167:                                              ; preds = %139, %150
  %168 = phi i16 [ %157, %150 ], [ 0, %139 ]
  %169 = getelementptr inbounds nuw i8, ptr %0, i16 26
  store i16 %168, ptr %169, align 1, !tbaa !120
  store volatile i8 -112, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  %170 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %171 = getelementptr inbounds nuw i8, ptr %0, i16 89
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef -8, i16 noundef 224, ptr noundef nonnull %170, ptr noundef nonnull %171) #13
  %172 = getelementptr inbounds nuw i8, ptr %0, i16 88
  store i8 0, ptr %172, align 1, !tbaa !121
  store volatile i8 2, ptr inttoptr (i16 17200 to ptr), align 16, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 17201 to ptr), align 1, !tbaa !6
  %173 = ptrtoint ptr %170 to i16
  %174 = trunc i16 %173 to i8
  store volatile i8 %174, ptr inttoptr (i16 17202 to ptr), align 2, !tbaa !6
  %175 = lshr i16 %173, 8
  %176 = trunc nuw i16 %175 to i8
  store volatile i8 %176, ptr inttoptr (i16 17203 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17204 to ptr), align 4, !tbaa !6
  %177 = getelementptr inbounds nuw i8, ptr %0, i16 139
  store i8 0, ptr %177, align 1, !tbaa !121
  store volatile i8 2, ptr inttoptr (i16 17216 to ptr), align 64, !tbaa !6
  store volatile i8 15, ptr inttoptr (i16 17217 to ptr), align 1, !tbaa !6
  %178 = ptrtoint ptr %171 to i16
  %179 = trunc i16 %178 to i8
  store volatile i8 %179, ptr inttoptr (i16 17218 to ptr), align 2, !tbaa !6
  %180 = lshr i16 %178, 8
  %181 = trunc nuw i16 %180 to i8
  store volatile i8 %181, ptr inttoptr (i16 17219 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17220 to ptr), align 4, !tbaa !6
  %182 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 2, ptr %182, align 1, !tbaa !62
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal void @_title_emit(ptr noundef %0, ptr noundef captures(none) %1) #5 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 29
  %4 = load i8, ptr %3, align 1, !tbaa !73
  %5 = icmp eq i8 %4, 0
  br i1 %5, label %188, label %6

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 30
  %8 = load i8, ptr %7, align 1, !tbaa !76
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %39, label %10

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 25
  %12 = load i8, ptr %11, align 1, !tbaa !77
  %13 = icmp ugt i8 %12, -6
  br i1 %13, label %16, label %14

14:                                               ; preds = %10
  %15 = add nuw i8 %12, 4
  br label %16

16:                                               ; preds = %10, %14
  %17 = phi i8 [ %15, %14 ], [ -1, %10 ]
  store i8 %17, ptr %11, align 1, !tbaa !77
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %19 = load i16, ptr %18, align 1, !tbaa !69
  %20 = xor i8 %17, -1
  %21 = zext i8 %20 to i16
  %22 = mul nuw i16 %21, %21
  %23 = lshr i16 %22, 8
  %24 = sub nuw nsw i16 256, %23
  %25 = add nsw i16 %19, 8
  %26 = mul nsw i16 %24, %25
  %27 = ashr i16 %26, 4
  %28 = and i16 %27, -16
  %29 = add nsw i16 %28, -128
  %30 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 %29, ptr %30, align 1, !tbaa !95
  %31 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %32 = load i16, ptr %31, align 1, !tbaa !70
  %33 = add nsw i16 %32, -224
  %34 = mul nsw i16 %33, %24
  %35 = ashr i16 %34, 4
  %36 = and i16 %35, -16
  %37 = add nsw i16 %36, 3584
  %38 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 %37, ptr %38, align 1, !tbaa !117
  br label %64

39:                                               ; preds = %6
  %40 = getelementptr inbounds nuw i8, ptr %0, i16 31
  %41 = load i8, ptr %40, align 1, !tbaa !74
  %42 = icmp eq i8 %41, 0
  br i1 %42, label %43, label %48

43:                                               ; preds = %39
  %44 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %45 = load i16, ptr %44, align 1, !tbaa !95
  %46 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %47 = load i16, ptr %46, align 1, !tbaa !117
  br label %64

48:                                               ; preds = %39
  %49 = getelementptr inbounds nuw i8, ptr %0, i16 23
  %50 = load i16, ptr %49, align 1, !tbaa !118
  %51 = add nsw i16 %50, 2
  store i16 %51, ptr %49, align 1, !tbaa !118
  %52 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %53 = load i16, ptr %52, align 1, !tbaa !95
  %54 = add nsw i16 %53, %51
  store i16 %54, ptr %52, align 1, !tbaa !95
  %55 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %56 = load i16, ptr %55, align 1, !tbaa !117
  %57 = add nsw i16 %56, %51
  store i16 %57, ptr %55, align 1, !tbaa !117
  %58 = icmp sgt i16 %54, 4480
  br i1 %58, label %59, label %60

59:                                               ; preds = %48
  store i16 4480, ptr %52, align 1, !tbaa !95
  br label %60

60:                                               ; preds = %59, %48
  %61 = phi i16 [ 4480, %59 ], [ %54, %48 ]
  %62 = icmp sgt i16 %57, 4736
  br i1 %62, label %63, label %64

63:                                               ; preds = %60
  store i16 4736, ptr %55, align 1, !tbaa !117
  br label %64

64:                                               ; preds = %43, %63, %60, %16
  %65 = phi i16 [ %47, %43 ], [ 4736, %63 ], [ %57, %60 ], [ %37, %16 ]
  %66 = phi i16 [ %45, %43 ], [ %61, %63 ], [ %61, %60 ], [ %29, %16 ]
  %67 = ashr i16 %66, 4
  %68 = ashr i16 %65, 4
  %69 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %70 = getelementptr inbounds nuw i8, ptr %0, i16 88
  %71 = load i8, ptr %70, align 1, !tbaa !121
  %72 = xor i8 %71, 1
  %73 = zext i8 %72 to i16
  %74 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %73
  %75 = getelementptr inbounds nuw i8, ptr %0, i16 89
  %76 = getelementptr inbounds nuw i8, ptr %0, i16 139
  %77 = load i8, ptr %76, align 1, !tbaa !121
  %78 = xor i8 %77, 1
  %79 = zext i8 %78 to i16
  %80 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %79
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef %67, i16 noundef %68, ptr noundef nonnull %74, ptr noundef nonnull %80) #13
  %81 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %82 = load i8, ptr %81, align 1, !tbaa !44
  %83 = icmp ugt i8 %82, 15
  br i1 %83, label %109, label %84

84:                                               ; preds = %64
  %85 = load i8, ptr %70, align 1, !tbaa !121
  %86 = xor i8 %85, 1
  %87 = zext i8 %86 to i16
  %88 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %87
  %89 = ptrtoint ptr %88 to i16
  %90 = zext nneg i8 %82 to i16
  %91 = add nuw nsw i8 %82, 1
  store i8 %91, ptr %81, align 1, !tbaa !44
  %92 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %90
  %93 = getelementptr inbounds nuw i8, ptr %92, i16 10
  store i8 4, ptr %93, align 1, !tbaa !45
  store i16 17202, ptr %92, align 1, !tbaa !47
  %94 = getelementptr inbounds nuw i8, ptr %92, i16 2
  store i16 %89, ptr %94, align 1, !tbaa !51
  %95 = getelementptr inbounds nuw i8, ptr %92, i16 4
  store i16 0, ptr %95, align 1, !tbaa !53
  store i8 %86, ptr %70, align 1, !tbaa !121
  %96 = icmp eq i8 %82, 15
  br i1 %96, label %109, label %97

97:                                               ; preds = %84
  %98 = load i8, ptr %76, align 1, !tbaa !121
  %99 = xor i8 %98, 1
  %100 = zext i8 %99 to i16
  %101 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %100
  %102 = ptrtoint ptr %101 to i16
  %103 = zext nneg i8 %91 to i16
  %104 = add nuw nsw i8 %82, 2
  store i8 %104, ptr %81, align 1, !tbaa !44
  %105 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %103
  %106 = getelementptr inbounds nuw i8, ptr %105, i16 10
  store i8 4, ptr %106, align 1, !tbaa !45
  store i16 17218, ptr %105, align 1, !tbaa !47
  %107 = getelementptr inbounds nuw i8, ptr %105, i16 2
  store i16 %102, ptr %107, align 1, !tbaa !51
  %108 = getelementptr inbounds nuw i8, ptr %105, i16 4
  store i16 0, ptr %108, align 1, !tbaa !53
  store i8 %99, ptr %76, align 1, !tbaa !121
  br label %109

109:                                              ; preds = %64, %84, %97
  %110 = phi i8 [ %82, %64 ], [ 16, %84 ], [ %104, %97 ]
  %111 = getelementptr inbounds nuw i8, ptr %0, i16 28
  %112 = load i8, ptr %111, align 1, !tbaa !72
  %113 = add i8 %112, 1
  store i8 %113, ptr %111, align 1, !tbaa !72
  %114 = getelementptr inbounds nuw i8, ptr %0, i16 32
  %115 = load i8, ptr %114, align 1, !tbaa !75
  %116 = icmp eq i8 %115, 0
  br i1 %116, label %117, label %155

117:                                              ; preds = %109
  %118 = shl i8 %113, 1
  %119 = icmp sgt i8 %118, -1
  br i1 %119, label %122, label %120

120:                                              ; preds = %117
  %121 = xor i8 %118, -1
  br label %122

122:                                              ; preds = %117, %120
  %123 = phi i8 [ %121, %120 ], [ %118, %117 ]
  %124 = lshr i8 %123, 4
  %125 = add nuw nsw i8 %124, 24
  %126 = zext nneg i8 %125 to i16
  %127 = mul nuw nsw i16 %126, 1057
  %128 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 %127, ptr %128, align 1, !tbaa !78
  %129 = add i8 %118, -86
  %130 = icmp sgt i8 %129, -1
  br i1 %130, label %133, label %131

131:                                              ; preds = %122
  %132 = sub nsw i8 85, %118
  br label %133

133:                                              ; preds = %122, %131
  %134 = phi i8 [ %132, %131 ], [ %129, %122 ]
  %135 = lshr i8 %134, 2
  %136 = zext nneg i8 %135 to i16
  %137 = shl nuw nsw i16 %136, 10
  %138 = add i8 %118, 85
  %139 = icmp sgt i8 %138, -1
  br i1 %139, label %142, label %140

140:                                              ; preds = %133
  %141 = sub nuw i8 -86, %118
  br label %142

142:                                              ; preds = %133, %140
  %143 = phi i8 [ %141, %140 ], [ %138, %133 ]
  %144 = lshr i8 %143, 2
  %145 = zext nneg i8 %144 to i16
  %146 = shl nuw nsw i16 %145, 5
  %147 = add nuw nsw i16 %146, %137
  br i1 %119, label %150, label %148

148:                                              ; preds = %142
  %149 = xor i8 %118, -1
  br label %150

150:                                              ; preds = %142, %148
  %151 = phi i8 [ %149, %148 ], [ %118, %142 ]
  %152 = lshr i8 %151, 2
  %153 = zext nneg i8 %152 to i16
  %154 = add nuw nsw i16 %147, %153
  br label %157

155:                                              ; preds = %109
  %156 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 29596, ptr %156, align 1, !tbaa !78
  br label %157

157:                                              ; preds = %155, %150
  %158 = phi i16 [ 0, %155 ], [ %154, %150 ]
  %159 = getelementptr inbounds nuw i8, ptr %0, i16 36
  store i16 %158, ptr %159, align 1, !tbaa !79
  %160 = icmp ugt i8 %110, 15
  br i1 %160, label %188, label %161

161:                                              ; preds = %157
  %162 = getelementptr inbounds nuw i8, ptr %0, i16 34
  %163 = zext nneg i8 %110 to i16
  %164 = add nuw nsw i8 %110, 1
  store i8 %164, ptr %81, align 1, !tbaa !44
  %165 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %163
  %166 = getelementptr inbounds nuw i8, ptr %165, i16 10
  store i8 1, ptr %166, align 1, !tbaa !45
  store i16 113, ptr %165, align 1, !tbaa !47
  %167 = getelementptr inbounds nuw i8, ptr %165, i16 9
  store i8 0, ptr %167, align 1, !tbaa !48
  %168 = getelementptr inbounds nuw i8, ptr %165, i16 7
  store i8 34, ptr %168, align 1, !tbaa !49
  %169 = getelementptr inbounds nuw i8, ptr %165, i16 8
  store i8 0, ptr %169, align 1, !tbaa !50
  %170 = ptrtoint ptr %162 to i16
  %171 = getelementptr inbounds nuw i8, ptr %165, i16 2
  store i16 %170, ptr %171, align 1, !tbaa !51
  %172 = getelementptr inbounds nuw i8, ptr %165, i16 6
  store i8 0, ptr %172, align 1, !tbaa !52
  %173 = getelementptr inbounds nuw i8, ptr %165, i16 4
  store i16 2, ptr %173, align 1, !tbaa !53
  %174 = icmp eq i8 %110, 15
  br i1 %174, label %188, label %175

175:                                              ; preds = %161
  %176 = getelementptr inbounds nuw i8, ptr %0, i16 36
  %177 = zext nneg i8 %164 to i16
  %178 = add nuw nsw i8 %110, 2
  store i8 %178, ptr %81, align 1, !tbaa !44
  %179 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %177
  %180 = getelementptr inbounds nuw i8, ptr %179, i16 10
  store i8 1, ptr %180, align 1, !tbaa !45
  store i16 0, ptr %179, align 1, !tbaa !47
  %181 = getelementptr inbounds nuw i8, ptr %179, i16 9
  store i8 0, ptr %181, align 1, !tbaa !48
  %182 = getelementptr inbounds nuw i8, ptr %179, i16 7
  store i8 34, ptr %182, align 1, !tbaa !49
  %183 = getelementptr inbounds nuw i8, ptr %179, i16 8
  store i8 0, ptr %183, align 1, !tbaa !50
  %184 = ptrtoint ptr %176 to i16
  %185 = getelementptr inbounds nuw i8, ptr %179, i16 2
  store i16 %184, ptr %185, align 1, !tbaa !51
  %186 = getelementptr inbounds nuw i8, ptr %179, i16 6
  store i8 0, ptr %186, align 1, !tbaa !52
  %187 = getelementptr inbounds nuw i8, ptr %179, i16 4
  store i16 2, ptr %187, align 1, !tbaa !53
  br label %188

188:                                              ; preds = %157, %175, %161, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @_title_write16(ptr noundef readonly captures(address_is_null) %0, i8 noundef zeroext %1, i8 noundef zeroext %2) unnamed_addr #2 {
  %4 = zext i8 %1 to i16
  %5 = shl nuw nsw i16 %4, 1
  %6 = and i16 %5, 254
  %7 = sub nsw i16 32, %6
  %8 = lshr exact i16 %7, 1
  %9 = zext i8 %2 to i16
  %10 = icmp eq ptr %0, null
  %11 = and i16 %8, 255
  %12 = add nuw i16 %8, %5
  %13 = and i16 %12, 255
  br label %15

14:                                               ; preds = %23
  ret void

15:                                               ; preds = %3, %23
  %16 = phi i1 [ true, %3 ], [ false, %23 ]
  %17 = phi i8 [ 0, %3 ], [ 1, %23 ]
  %18 = zext nneg i8 %17 to i16
  %19 = add nuw nsw i16 %18, %9
  %20 = shl nuw nsw i16 %19, 5
  %21 = add nuw nsw i16 %20, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %21, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %22 = select i1 %16, i16 7168, i16 7170
  br label %24

23:                                               ; preds = %56
  br i1 %16, label %15, label %14, !llvm.loop !122

24:                                               ; preds = %15, %56
  %25 = phi i8 [ 0, %15 ], [ %58, %56 ]
  %26 = zext nneg i8 %25 to i16
  br i1 %10, label %56, label %27

27:                                               ; preds = %24
  %28 = icmp samesign ugt i16 %11, %26
  br i1 %28, label %56, label %29

29:                                               ; preds = %27
  %30 = icmp samesign ugt i16 %13, %26
  br i1 %30, label %31, label %56

31:                                               ; preds = %29
  %32 = sub nsw i16 %26, %11
  %33 = lshr i16 %32, 1
  %34 = and i16 %33, 255
  %35 = getelementptr inbounds nuw i8, ptr %0, i16 %34
  %36 = load i8, ptr %35, align 1, !tbaa !6
  %37 = icmp ugt i8 %36, 96
  br i1 %37, label %38, label %42

38:                                               ; preds = %31
  %39 = icmp ult i8 %36, 123
  br i1 %39, label %40, label %51

40:                                               ; preds = %38
  %41 = add nsw i8 %36, -32
  br label %46

42:                                               ; preds = %31
  %43 = icmp samesign ugt i8 %36, 31
  br i1 %43, label %44, label %51

44:                                               ; preds = %42
  %45 = icmp eq i8 %36, 96
  br i1 %45, label %51, label %46

46:                                               ; preds = %44, %40
  %47 = phi i8 [ %41, %40 ], [ %36, %44 ]
  %48 = zext nneg i8 %47 to i16
  %49 = shl nuw nsw i16 %48, 2
  %50 = add nsw i16 %49, -64
  br label %51

51:                                               ; preds = %38, %42, %44, %46
  %52 = phi i16 [ %50, %46 ], [ 64, %44 ], [ 64, %42 ], [ 64, %38 ]
  %53 = and i16 %32, 1
  %54 = or disjoint i16 %22, %53
  %55 = or disjoint i16 %54, %52
  br label %56

56:                                               ; preds = %51, %29, %27, %24
  %57 = phi i16 [ %55, %51 ], [ 7168, %29 ], [ 7168, %27 ], [ 7168, %24 ]
  store volatile i16 %57, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %58 = add nuw nsw i8 %25, 1
  %59 = icmp eq i8 %58, 32
  br i1 %59, label %23, label %24, !llvm.loop !123
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_build(ptr noundef readonly captures(none) %0, i16 noundef range(i16 -2048, 2048) %1, i16 noundef range(i16 -2048, 2048) %2, ptr noundef %3, ptr noundef %4) unnamed_addr #5 {
  %6 = alloca %struct.HScrollW, align 1
  %7 = alloca %struct.HScrollW, align 1
  %8 = alloca i16, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #14
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #14
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #14
  store i16 0, ptr %8, align 1, !tbaa !2
  store ptr %3, ptr %6, align 1, !tbaa !124
  %9 = getelementptr inbounds nuw i8, ptr %6, i16 2
  store i8 0, ptr %9, align 1, !tbaa !126
  store ptr %4, ptr %7, align 1, !tbaa !124
  %10 = getelementptr inbounds nuw i8, ptr %7, i16 2
  store i8 0, ptr %10, align 1, !tbaa !126
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %12 = load i16, ptr %11, align 1, !tbaa !69
  %13 = getelementptr inbounds nuw i8, ptr %0, i16 26
  %14 = load i16, ptr %13, align 1, !tbaa !120
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %1, i16 noundef 8, i16 noundef %12, i16 noundef %14) #13
  %15 = getelementptr inbounds nuw i8, ptr %0, i16 17
  %16 = load i16, ptr %15, align 1, !tbaa !71
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %18 = load i16, ptr %17, align 1, !tbaa !70
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %2, i16 noundef %16, i16 noundef %18, i16 noundef 0) #13
  %19 = load i16, ptr %8, align 1, !tbaa !2
  call fastcc void @_title_blank(ptr noundef %6, ptr noundef %7, i16 noundef %19, i16 noundef 224) #13
  %20 = load ptr, ptr %6, align 1, !tbaa !124
  %21 = load i8, ptr %9, align 1, !tbaa !126
  %22 = zext i8 %21 to i16
  %23 = getelementptr inbounds nuw i8, ptr %20, i16 %22
  store i8 0, ptr %23, align 1, !tbaa !6
  %24 = load ptr, ptr %7, align 1, !tbaa !124
  %25 = load i8, ptr %10, align 1, !tbaa !126
  %26 = zext i8 %25 to i16
  %27 = getelementptr inbounds nuw i8, ptr %24, i16 %26
  store i8 0, ptr %27, align 1, !tbaa !6
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #14
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #14
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #14
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_glyph_band(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, ptr noundef nonnull captures(none) %2, i16 noundef range(i16 -2048, 2048) %3, i16 noundef %4, i16 noundef %5, i16 noundef %6) unnamed_addr #5 {
  %8 = add nsw i16 %3, -2
  %9 = add nsw i16 %4, %3
  %10 = add nsw i16 %9, 2
  %11 = load i16, ptr %2, align 1, !tbaa !2
  %12 = icmp slt i16 %8, %11
  br i1 %12, label %13, label %14

13:                                               ; preds = %7
  br label %14

14:                                               ; preds = %13, %7
  %15 = phi i16 [ %11, %13 ], [ %8, %7 ]
  %16 = icmp sgt i16 %9, 222
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  br label %18

18:                                               ; preds = %17, %14
  %19 = phi i16 [ 224, %17 ], [ %10, %14 ]
  %20 = icmp sgt i16 %19, %15
  br i1 %20, label %21, label %92

21:                                               ; preds = %18
  tail call fastcc void @_title_blank(ptr noundef %0, ptr noundef %1, i16 noundef %11, i16 noundef %15) #13
  %22 = sub nsw i16 %19, %15
  %23 = trunc i16 %22 to i8
  %24 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %25 = icmp eq i8 %23, 0
  br i1 %25, label %91, label %26

26:                                               ; preds = %21
  %27 = sub nsw i16 %5, %3
  %28 = and i16 %22, 255
  %29 = trunc i16 %27 to i8
  %30 = lshr i16 %27, 8
  %31 = trunc nuw i16 %30 to i8
  br label %32

32:                                               ; preds = %40, %26
  %33 = phi i16 [ %28, %26 ], [ %57, %40 ]
  %34 = load i8, ptr %24, align 1, !tbaa !126
  %35 = icmp ult i8 %34, 22
  br i1 %35, label %36, label %59

36:                                               ; preds = %32
  %37 = icmp ugt i16 %33, 127
  br i1 %37, label %40, label %38

38:                                               ; preds = %36
  %39 = trunc nuw nsw i16 %33 to i8
  br label %40

40:                                               ; preds = %38, %36
  %41 = phi i8 [ %39, %38 ], [ 127, %36 ]
  %42 = load ptr, ptr %0, align 1, !tbaa !124
  %43 = add nuw nsw i8 %34, 1
  store i8 %43, ptr %24, align 1, !tbaa !126
  %44 = zext nneg i8 %34 to i16
  %45 = getelementptr inbounds nuw i8, ptr %42, i16 %44
  store i8 %41, ptr %45, align 1, !tbaa !6
  %46 = load ptr, ptr %0, align 1, !tbaa !124
  %47 = load i8, ptr %24, align 1, !tbaa !126
  %48 = add i8 %47, 1
  store i8 %48, ptr %24, align 1, !tbaa !126
  %49 = zext i8 %47 to i16
  %50 = getelementptr inbounds nuw i8, ptr %46, i16 %49
  store i8 %29, ptr %50, align 1, !tbaa !6
  %51 = load ptr, ptr %0, align 1, !tbaa !124
  %52 = load i8, ptr %24, align 1, !tbaa !126
  %53 = add i8 %52, 1
  store i8 %53, ptr %24, align 1, !tbaa !126
  %54 = zext i8 %52 to i16
  %55 = getelementptr inbounds nuw i8, ptr %51, i16 %54
  store i8 %31, ptr %55, align 1, !tbaa !6
  %56 = zext nneg i8 %41 to i16
  %57 = sub i16 %33, %56
  %58 = icmp eq i16 %57, 0
  br i1 %58, label %59, label %32, !llvm.loop !127

59:                                               ; preds = %32, %40
  %60 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %61 = trunc i16 %6 to i8
  %62 = lshr i16 %6, 8
  %63 = trunc nuw i16 %62 to i8
  br label %64

64:                                               ; preds = %72, %59
  %65 = phi i16 [ %28, %59 ], [ %89, %72 ]
  %66 = load i8, ptr %60, align 1, !tbaa !126
  %67 = icmp ult i8 %66, 22
  br i1 %67, label %68, label %91

68:                                               ; preds = %64
  %69 = icmp ugt i16 %65, 127
  br i1 %69, label %72, label %70

70:                                               ; preds = %68
  %71 = trunc nuw nsw i16 %65 to i8
  br label %72

72:                                               ; preds = %70, %68
  %73 = phi i8 [ %71, %70 ], [ 127, %68 ]
  %74 = load ptr, ptr %1, align 1, !tbaa !124
  %75 = add nuw nsw i8 %66, 1
  store i8 %75, ptr %60, align 1, !tbaa !126
  %76 = zext nneg i8 %66 to i16
  %77 = getelementptr inbounds nuw i8, ptr %74, i16 %76
  store i8 %73, ptr %77, align 1, !tbaa !6
  %78 = load ptr, ptr %1, align 1, !tbaa !124
  %79 = load i8, ptr %60, align 1, !tbaa !126
  %80 = add i8 %79, 1
  store i8 %80, ptr %60, align 1, !tbaa !126
  %81 = zext i8 %79 to i16
  %82 = getelementptr inbounds nuw i8, ptr %78, i16 %81
  store i8 %61, ptr %82, align 1, !tbaa !6
  %83 = load ptr, ptr %1, align 1, !tbaa !124
  %84 = load i8, ptr %60, align 1, !tbaa !126
  %85 = add i8 %84, 1
  store i8 %85, ptr %60, align 1, !tbaa !126
  %86 = zext i8 %84 to i16
  %87 = getelementptr inbounds nuw i8, ptr %83, i16 %86
  store i8 %63, ptr %87, align 1, !tbaa !6
  %88 = zext nneg i8 %73 to i16
  %89 = sub i16 %65, %88
  %90 = icmp eq i16 %89, 0
  br i1 %90, label %91, label %64, !llvm.loop !127

91:                                               ; preds = %64, %72, %21
  store i16 %19, ptr %2, align 1, !tbaa !2
  br label %92

92:                                               ; preds = %18, %91
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_blank(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, i16 noundef %2, i16 noundef range(i16 -2050, 225) %3) unnamed_addr #5 {
  %5 = icmp sgt i16 %3, %2
  br i1 %5, label %6, label %83

6:                                                ; preds = %4
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 2
  br label %9

9:                                                ; preds = %6, %79
  %10 = phi i16 [ %2, %6 ], [ %81, %79 ]
  %11 = sub nsw i16 %3, %10
  %12 = icmp sgt i16 %11, 112
  br i1 %12, label %16, label %13

13:                                               ; preds = %9
  %14 = trunc i16 %11 to i8
  %15 = icmp eq i8 %14, 0
  br i1 %15, label %79, label %16

16:                                               ; preds = %9, %13
  %17 = phi i8 [ %14, %13 ], [ 112, %9 ]
  %18 = phi i16 [ %11, %13 ], [ 112, %9 ]
  %19 = sub nsw i16 144, %10
  %20 = zext i8 %17 to i16
  %21 = trunc i16 %19 to i8
  %22 = lshr i16 %19, 8
  %23 = trunc nuw i16 %22 to i8
  br label %24

24:                                               ; preds = %32, %16
  %25 = phi i16 [ %20, %16 ], [ %49, %32 ]
  %26 = load i8, ptr %7, align 1, !tbaa !126
  %27 = icmp ult i8 %26, 22
  br i1 %27, label %28, label %51

28:                                               ; preds = %24
  %29 = icmp ugt i16 %25, 127
  br i1 %29, label %32, label %30

30:                                               ; preds = %28
  %31 = trunc nuw nsw i16 %25 to i8
  br label %32

32:                                               ; preds = %30, %28
  %33 = phi i8 [ %31, %30 ], [ 127, %28 ]
  %34 = load ptr, ptr %0, align 1, !tbaa !124
  %35 = add nuw nsw i8 %26, 1
  store i8 %35, ptr %7, align 1, !tbaa !126
  %36 = zext nneg i8 %26 to i16
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 %36
  store i8 %33, ptr %37, align 1, !tbaa !6
  %38 = load ptr, ptr %0, align 1, !tbaa !124
  %39 = load i8, ptr %7, align 1, !tbaa !126
  %40 = add i8 %39, 1
  store i8 %40, ptr %7, align 1, !tbaa !126
  %41 = zext i8 %39 to i16
  %42 = getelementptr inbounds nuw i8, ptr %38, i16 %41
  store i8 %21, ptr %42, align 1, !tbaa !6
  %43 = load ptr, ptr %0, align 1, !tbaa !124
  %44 = load i8, ptr %7, align 1, !tbaa !126
  %45 = add i8 %44, 1
  store i8 %45, ptr %7, align 1, !tbaa !126
  %46 = zext i8 %44 to i16
  %47 = getelementptr inbounds nuw i8, ptr %43, i16 %46
  store i8 %23, ptr %47, align 1, !tbaa !6
  %48 = zext nneg i8 %33 to i16
  %49 = sub i16 %25, %48
  %50 = icmp eq i16 %49, 0
  br i1 %50, label %51, label %24, !llvm.loop !127

51:                                               ; preds = %24, %32
  br label %52

52:                                               ; preds = %51, %60
  %53 = phi i16 [ %77, %60 ], [ %20, %51 ]
  %54 = load i8, ptr %8, align 1, !tbaa !126
  %55 = icmp ult i8 %54, 22
  br i1 %55, label %56, label %79

56:                                               ; preds = %52
  %57 = icmp ugt i16 %53, 127
  br i1 %57, label %60, label %58

58:                                               ; preds = %56
  %59 = trunc nuw nsw i16 %53 to i8
  br label %60

60:                                               ; preds = %58, %56
  %61 = phi i8 [ %59, %58 ], [ 127, %56 ]
  %62 = load ptr, ptr %1, align 1, !tbaa !124
  %63 = add nuw nsw i8 %54, 1
  store i8 %63, ptr %8, align 1, !tbaa !126
  %64 = zext nneg i8 %54 to i16
  %65 = getelementptr inbounds nuw i8, ptr %62, i16 %64
  store i8 %61, ptr %65, align 1, !tbaa !6
  %66 = load ptr, ptr %1, align 1, !tbaa !124
  %67 = load i8, ptr %8, align 1, !tbaa !126
  %68 = add i8 %67, 1
  store i8 %68, ptr %8, align 1, !tbaa !126
  %69 = zext i8 %67 to i16
  %70 = getelementptr inbounds nuw i8, ptr %66, i16 %69
  store i8 0, ptr %70, align 1, !tbaa !6
  %71 = load ptr, ptr %1, align 1, !tbaa !124
  %72 = load i8, ptr %8, align 1, !tbaa !126
  %73 = add i8 %72, 1
  store i8 %73, ptr %8, align 1, !tbaa !126
  %74 = zext i8 %72 to i16
  %75 = getelementptr inbounds nuw i8, ptr %71, i16 %74
  store i8 0, ptr %75, align 1, !tbaa !6
  %76 = zext nneg i8 %61 to i16
  %77 = sub i16 %53, %76
  %78 = icmp eq i16 %77, 0
  br i1 %78, label %79, label %52, !llvm.loop !127

79:                                               ; preds = %52, %60, %13
  %80 = phi i16 [ %11, %13 ], [ %18, %60 ], [ %18, %52 ]
  %81 = add nsw i16 %80, %10
  %82 = icmp sgt i16 %3, %81
  br i1 %82, label %9, label %83, !llvm.loop !128

83:                                               ; preds = %79, %4
  ret void
}

; Function Attrs: inlinehint nofree norecurse nosync nounwind optsize memory(argmem: write)
define internal fastcc void @db_dct8x8(i16 noundef %0, ptr noundef nonnull writeonly captures(none) %1) unnamed_addr #6 {
  %3 = alloca [8 x [8 x i16]], align 1
  %4 = alloca [8 x i16], align 1
  %5 = alloca [8 x i16], align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #14
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #14
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #14
  br label %6

6:                                                ; preds = %2, %74
  %7 = phi i8 [ 0, %2 ], [ %77, %74 ]
  %8 = phi i8 [ 0, %2 ], [ %75, %74 ]
  %9 = zext nneg i8 %8 to i16
  %10 = zext i8 %7 to i16
  %11 = getelementptr i8, ptr %3, i16 %10
  %12 = mul nuw nsw i16 %9, 24
  %13 = sub nsw i16 %12, %0
  %14 = and i16 %13, 255
  br label %15

15:                                               ; preds = %6, %35
  %16 = phi i8 [ 0, %6 ], [ %41, %35 ]
  %17 = phi i8 [ 0, %6 ], [ %39, %35 ]
  %18 = zext nneg i8 %17 to i16
  %19 = mul nuw nsw i16 %18, 40
  %20 = add nsw i16 %19, %0
  %21 = and i16 %20, 255
  %22 = add nuw nsw i16 %21, %14
  %23 = add nsw i16 %22, -256
  %24 = xor i16 %9, %18
  %25 = and i16 %24, 1
  %26 = icmp eq i16 %25, 0
  br i1 %26, label %29, label %27

27:                                               ; preds = %15
  %28 = add nsw i16 %22, -216
  br label %29

29:                                               ; preds = %27, %15
  %30 = phi i16 [ %28, %27 ], [ %23, %15 ]
  %31 = icmp sgt i16 %30, 127
  br i1 %31, label %35, label %32

32:                                               ; preds = %29
  %33 = icmp slt i16 %30, -128
  br i1 %33, label %34, label %35

34:                                               ; preds = %32
  br label %35

35:                                               ; preds = %29, %32, %34
  %36 = phi i16 [ -128, %34 ], [ %30, %32 ], [ 127, %29 ]
  %37 = zext nneg i8 %16 to i16
  %38 = getelementptr i8, ptr %4, i16 %37
  store i16 %36, ptr %38, align 1, !tbaa !2
  %39 = add nuw nsw i8 %17, 1
  %40 = icmp eq i8 %39, 8
  %41 = add nuw nsw i8 %16, 2
  br i1 %40, label %42, label %15, !llvm.loop !129

42:                                               ; preds = %35, %63
  %43 = phi i8 [ %73, %63 ], [ 0, %35 ]
  %44 = phi ptr [ %70, %63 ], [ @DCT_M, %35 ]
  %45 = phi i8 [ %72, %63 ], [ 0, %35 ]
  %46 = phi i8 [ %68, %63 ], [ 0, %35 ]
  br label %47

47:                                               ; preds = %47, %42
  %48 = phi i8 [ 0, %42 ], [ %62, %47 ]
  %49 = phi i32 [ 0, %42 ], [ %59, %47 ]
  %50 = phi i8 [ 0, %42 ], [ %60, %47 ]
  %51 = zext nneg i8 %48 to i16
  %52 = getelementptr i8, ptr %44, i16 %51
  %53 = load i16, ptr %52, align 1, !tbaa !2
  %54 = sext i16 %53 to i32
  %55 = getelementptr i8, ptr %4, i16 %51
  %56 = load i16, ptr %55, align 1, !tbaa !2
  %57 = sext i16 %56 to i32
  %58 = mul nsw i32 %57, %54
  %59 = add nsw i32 %58, %49
  %60 = add nuw nsw i8 %50, 1
  %61 = icmp eq i8 %60, 8
  %62 = add nuw nsw i8 %48, 2
  br i1 %61, label %63, label %47, !llvm.loop !130

63:                                               ; preds = %47
  %64 = lshr i32 %59, 8
  %65 = trunc i32 %64 to i16
  %66 = zext nneg i8 %45 to i16
  %67 = getelementptr i8, ptr %5, i16 %66
  store i16 %65, ptr %67, align 1, !tbaa !2
  %68 = add nuw nsw i8 %46, 1
  %69 = zext i8 %43 to i16
  %70 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @DCT_M, i16 16), i16 %69
  %71 = icmp eq i8 %68, 8
  %72 = add nuw nsw i8 %45, 2
  %73 = add nuw i8 %43, 16
  br i1 %71, label %74, label %42, !llvm.loop !131

74:                                               ; preds = %63
  call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(16) %11, ptr noundef nonnull align 1 dereferenceable(16) %5, i16 16, i1 false), !tbaa !2
  %75 = add nuw nsw i8 %8, 1
  %76 = icmp eq i8 %75, 8
  %77 = add nuw i8 %7, 16
  br i1 %76, label %78, label %6, !llvm.loop !132

78:                                               ; preds = %74
  %79 = getelementptr inbounds nuw i8, ptr %3, i16 2
  %80 = getelementptr i8, ptr %1, i16 2
  br label %81

81:                                               ; preds = %78, %144
  %82 = phi i8 [ 0, %78 ], [ %150, %144 ]
  %83 = phi ptr [ %1, %78 ], [ %148, %144 ]
  %84 = phi ptr [ %3, %78 ], [ %147, %144 ]
  %85 = phi i8 [ 0, %78 ], [ %145, %144 ]
  br label %86

86:                                               ; preds = %81, %86
  %87 = phi i8 [ 0, %81 ], [ %98, %86 ]
  %88 = phi i8 [ 0, %81 ], [ %97, %86 ]
  %89 = phi i8 [ 0, %81 ], [ %95, %86 ]
  %90 = zext i8 %88 to i16
  %91 = getelementptr i8, ptr %84, i16 %90
  %92 = load i16, ptr %91, align 1, !tbaa !2
  %93 = zext nneg i8 %87 to i16
  %94 = getelementptr i8, ptr %4, i16 %93
  store i16 %92, ptr %94, align 1, !tbaa !2
  %95 = add nuw nsw i8 %89, 1
  %96 = icmp eq i8 %95, 8
  %97 = add nuw i8 %88, 16
  %98 = add nuw nsw i8 %87, 2
  br i1 %96, label %99, label %86, !llvm.loop !133

99:                                               ; preds = %86, %120
  %100 = phi i8 [ %130, %120 ], [ 0, %86 ]
  %101 = phi ptr [ %127, %120 ], [ @DCT_M, %86 ]
  %102 = phi i8 [ %129, %120 ], [ 0, %86 ]
  %103 = phi i8 [ %125, %120 ], [ 0, %86 ]
  br label %104

104:                                              ; preds = %104, %99
  %105 = phi i8 [ 0, %99 ], [ %119, %104 ]
  %106 = phi i32 [ 0, %99 ], [ %116, %104 ]
  %107 = phi i8 [ 0, %99 ], [ %117, %104 ]
  %108 = zext nneg i8 %105 to i16
  %109 = getelementptr i8, ptr %101, i16 %108
  %110 = load i16, ptr %109, align 1, !tbaa !2
  %111 = sext i16 %110 to i32
  %112 = getelementptr i8, ptr %4, i16 %108
  %113 = load i16, ptr %112, align 1, !tbaa !2
  %114 = sext i16 %113 to i32
  %115 = mul nsw i32 %114, %111
  %116 = add nsw i32 %115, %106
  %117 = add nuw nsw i8 %107, 1
  %118 = icmp eq i8 %117, 8
  %119 = add nuw nsw i8 %105, 2
  br i1 %118, label %120, label %104, !llvm.loop !130

120:                                              ; preds = %104
  %121 = lshr i32 %116, 8
  %122 = trunc i32 %121 to i16
  %123 = zext nneg i8 %102 to i16
  %124 = getelementptr i8, ptr %5, i16 %123
  store i16 %122, ptr %124, align 1, !tbaa !2
  %125 = add nuw nsw i8 %103, 1
  %126 = zext i8 %100 to i16
  %127 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @DCT_M, i16 16), i16 %126
  %128 = icmp eq i8 %125, 8
  %129 = add nuw nsw i8 %102, 2
  %130 = add nuw i8 %100, 16
  br i1 %128, label %131, label %99, !llvm.loop !131

131:                                              ; preds = %120, %131
  %132 = phi i8 [ %143, %131 ], [ 0, %120 ]
  %133 = phi i8 [ %142, %131 ], [ 0, %120 ]
  %134 = phi i8 [ %140, %131 ], [ 0, %120 ]
  %135 = zext nneg i8 %133 to i16
  %136 = getelementptr i8, ptr %5, i16 %135
  %137 = load i16, ptr %136, align 1, !tbaa !2
  %138 = zext i8 %132 to i16
  %139 = getelementptr i8, ptr %83, i16 %138
  store i16 %137, ptr %139, align 1, !tbaa !2
  %140 = add nuw nsw i8 %134, 1
  %141 = icmp eq i8 %140, 8
  %142 = add nuw nsw i8 %133, 2
  %143 = add nuw i8 %132, 16
  br i1 %141, label %144, label %131, !llvm.loop !134

144:                                              ; preds = %131
  %145 = add nuw nsw i8 %85, 1
  %146 = zext nneg i8 %82 to i16
  %147 = getelementptr i8, ptr %79, i16 %146
  %148 = getelementptr i8, ptr %80, i16 %146
  %149 = icmp eq i8 %145, 8
  %150 = add nuw nsw i8 %82, 2
  br i1 %149, label %151, label %81, !llvm.loop !135

151:                                              ; preds = %144
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #14
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #14
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #14
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none)
define internal fastcc void @fill_cell(i8 noundef zeroext range(i8 4, 73) %0, i8 noundef zeroext %1, i8 noundef zeroext %2, i8 noundef zeroext range(i8 0, 4) %3) unnamed_addr #7 {
  %5 = mul i8 %1, 7
  %6 = add i8 %5, %0
  %7 = mul i8 %2, 7
  %8 = add i8 %7, 4
  %9 = zext i8 %6 to i16
  %10 = zext i8 %8 to i16
  %11 = and i8 %3, 1
  %12 = icmp eq i8 %11, 0
  %13 = icmp samesign ult i8 %3, 2
  %14 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1
  %15 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1
  br label %16

16:                                               ; preds = %4, %69
  %17 = phi i8 [ 0, %4 ], [ %70, %69 ]
  %18 = phi i16 [ %14, %4 ], [ %64, %69 ]
  %19 = phi i16 [ %15, %4 ], [ %63, %69 ]
  %20 = zext nneg i8 %17 to i16
  %21 = add nuw nsw i16 %20, %10
  %22 = icmp samesign ugt i16 %21, 127
  %23 = shl nuw nsw i16 %21, 1
  %24 = and i16 %23, 240
  %25 = and i16 %23, 14
  %26 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %25
  br label %27

27:                                               ; preds = %16, %62
  %28 = phi i16 [ %19, %16 ], [ %63, %62 ]
  %29 = phi i16 [ %18, %16 ], [ %64, %62 ]
  %30 = phi i8 [ 0, %16 ], [ %67, %62 ]
  %31 = phi i16 [ %18, %16 ], [ %66, %62 ]
  %32 = phi i16 [ %19, %16 ], [ %65, %62 ]
  %33 = zext nneg i8 %30 to i16
  %34 = add nuw nsw i16 %33, %9
  %35 = icmp samesign ugt i16 %34, 127
  br i1 %35, label %62, label %36

36:                                               ; preds = %27
  br i1 %22, label %62, label %37

37:                                               ; preds = %36
  %38 = lshr i16 %34, 3
  %39 = or disjoint i16 %38, %24
  %40 = shl nuw nsw i16 %39, 4
  %41 = getelementptr inbounds nuw i8, ptr %26, i16 %40
  %42 = and i16 %34, 7
  %43 = lshr exact i16 128, %42
  br i1 %12, label %48, label %44

44:                                               ; preds = %37
  %45 = load i8, ptr %41, align 1, !tbaa !6
  %46 = trunc nuw i16 %43 to i8
  %47 = or i8 %45, %46
  store i8 %47, ptr %41, align 1, !tbaa !6
  br label %48

48:                                               ; preds = %44, %37
  br i1 %13, label %54, label %49

49:                                               ; preds = %48
  %50 = getelementptr inbounds nuw i8, ptr %41, i16 1
  %51 = load i8, ptr %50, align 1, !tbaa !6
  %52 = trunc nuw i16 %43 to i8
  %53 = or i8 %51, %52
  store i8 %53, ptr %50, align 1, !tbaa !6
  br label %54

54:                                               ; preds = %49, %48
  %55 = icmp ult i16 %39, %31
  br i1 %55, label %56, label %57

56:                                               ; preds = %54
  store i16 %39, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %57

57:                                               ; preds = %56, %54
  %58 = phi i16 [ %39, %56 ], [ %29, %54 ]
  %59 = phi i16 [ %39, %56 ], [ %31, %54 ]
  %60 = icmp ugt i16 %39, %32
  br i1 %60, label %61, label %62

61:                                               ; preds = %57
  store i16 %39, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %62

62:                                               ; preds = %27, %36, %57, %61
  %63 = phi i16 [ %28, %27 ], [ %28, %36 ], [ %28, %57 ], [ %39, %61 ]
  %64 = phi i16 [ %29, %27 ], [ %29, %36 ], [ %58, %57 ], [ %58, %61 ]
  %65 = phi i16 [ %32, %27 ], [ %32, %36 ], [ %32, %57 ], [ %39, %61 ]
  %66 = phi i16 [ %31, %27 ], [ %31, %36 ], [ %59, %57 ], [ %59, %61 ]
  %67 = add nuw nsw i8 %30, 1
  %68 = icmp eq i8 %67, 7
  br i1 %68, label %69, label %27, !llvm.loop !136

69:                                               ; preds = %62
  %70 = add nuw nsw i8 %17, 1
  %71 = icmp eq i8 %70, 7
  br i1 %71, label %72, label %16, !llvm.loop !137

72:                                               ; preds = %69
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @upq_flush() unnamed_addr #8 {
  %1 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 177), align 1, !tbaa !138
  %2 = zext i8 %1 to i16
  %3 = shl nuw nsw i16 %2, 4
  %4 = add nuw nsw i16 %3, 17152
  %5 = inttoptr i16 %4 to ptr
  %6 = shl nuw i16 1, %2
  %7 = trunc i16 %6 to i8
  %8 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %108, label %10

10:                                               ; preds = %0
  %11 = getelementptr inbounds nuw i8, ptr %5, i16 1
  %12 = getelementptr inbounds nuw i8, ptr %5, i16 2
  %13 = getelementptr inbounds nuw i8, ptr %5, i16 3
  %14 = getelementptr inbounds nuw i8, ptr %5, i16 4
  %15 = getelementptr inbounds nuw i8, ptr %5, i16 5
  %16 = getelementptr inbounds nuw i8, ptr %5, i16 6
  br label %17

17:                                               ; preds = %10, %86
  %18 = phi i8 [ %8, %10 ], [ %89, %86 ]
  %19 = phi i16 [ 0, %10 ], [ %87, %86 ]
  %20 = phi i8 [ 0, %10 ], [ %88, %86 ]
  %21 = zext i8 %20 to i16
  %22 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %21
  %23 = getelementptr inbounds nuw i8, ptr %22, i16 10
  %24 = load i8, ptr %23, align 1, !tbaa !45
  switch i8 %24, label %44 [
    i8 3, label %25
    i8 4, label %34
  ]

25:                                               ; preds = %17
  %26 = load i16, ptr %22, align 1, !tbaa !47
  %27 = inttoptr i16 %26 to ptr
  %28 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %29 = load i16, ptr %28, align 1, !tbaa !51
  %30 = trunc i16 %29 to i8
  store volatile i8 %30, ptr %27, align 1, !tbaa !6
  %31 = load i16, ptr %28, align 1, !tbaa !51
  %32 = lshr i16 %31, 8
  %33 = trunc nuw i16 %32 to i8
  store volatile i8 %33, ptr %27, align 1, !tbaa !6
  br label %86

34:                                               ; preds = %17
  %35 = load i16, ptr %22, align 1, !tbaa !47
  %36 = inttoptr i16 %35 to ptr
  %37 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %38 = load i16, ptr %37, align 1, !tbaa !51
  %39 = trunc i16 %38 to i8
  store volatile i8 %39, ptr %36, align 1, !tbaa !6
  %40 = load i16, ptr %37, align 1, !tbaa !51
  %41 = lshr i16 %40, 8
  %42 = trunc nuw i16 %41 to i8
  %43 = getelementptr inbounds nuw i8, ptr %36, i16 1
  store volatile i8 %42, ptr %43, align 1, !tbaa !6
  br label %86

44:                                               ; preds = %17
  %45 = icmp eq i16 %19, 0
  br i1 %45, label %51, label %46

46:                                               ; preds = %44
  %47 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %48 = load i16, ptr %47, align 1, !tbaa !53
  %49 = add i16 %48, %19
  %50 = icmp ugt i16 %49, 5100
  br i1 %50, label %91, label %51

51:                                               ; preds = %46, %44
  switch i8 %24, label %59 [
    i8 0, label %52
    i8 1, label %56
  ]

52:                                               ; preds = %51
  %53 = getelementptr inbounds nuw i8, ptr %22, i16 9
  %54 = load i8, ptr %53, align 1, !tbaa !48
  store volatile i8 %54, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  %55 = load i16, ptr %22, align 1, !tbaa !47
  store volatile i16 %55, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %65

56:                                               ; preds = %51
  %57 = load i16, ptr %22, align 1, !tbaa !47
  %58 = trunc i16 %57 to i8
  store volatile i8 %58, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  br label %65

59:                                               ; preds = %51
  %60 = load i16, ptr %22, align 1, !tbaa !47
  %61 = trunc i16 %60 to i8
  store volatile i8 %61, ptr inttoptr (i16 8450 to ptr), align 2, !tbaa !6
  %62 = load i16, ptr %22, align 1, !tbaa !47
  %63 = lshr i16 %62, 8
  %64 = trunc nuw i16 %63 to i8
  store volatile i8 %64, ptr inttoptr (i16 8451 to ptr), align 1, !tbaa !6
  br label %65

65:                                               ; preds = %56, %59, %52
  %66 = getelementptr inbounds nuw i8, ptr %22, i16 8
  %67 = load i8, ptr %66, align 1, !tbaa !50
  store volatile i8 %67, ptr %5, align 16, !tbaa !6
  %68 = getelementptr inbounds nuw i8, ptr %22, i16 7
  %69 = load i8, ptr %68, align 1, !tbaa !49
  store volatile i8 %69, ptr %11, align 1, !tbaa !6
  %70 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %71 = load i16, ptr %70, align 1, !tbaa !51
  %72 = trunc i16 %71 to i8
  store volatile i8 %72, ptr %12, align 2, !tbaa !6
  %73 = load i16, ptr %70, align 1, !tbaa !51
  %74 = lshr i16 %73, 8
  %75 = trunc nuw i16 %74 to i8
  store volatile i8 %75, ptr %13, align 1, !tbaa !6
  %76 = getelementptr inbounds nuw i8, ptr %22, i16 6
  %77 = load i8, ptr %76, align 1, !tbaa !52
  store volatile i8 %77, ptr %14, align 4, !tbaa !6
  %78 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %79 = load i16, ptr %78, align 1, !tbaa !53
  %80 = trunc i16 %79 to i8
  store volatile i8 %80, ptr %15, align 1, !tbaa !6
  %81 = load i16, ptr %78, align 1, !tbaa !53
  %82 = lshr i16 %81, 8
  %83 = trunc nuw i16 %82 to i8
  store volatile i8 %83, ptr %16, align 2, !tbaa !6
  store volatile i8 %7, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !6
  %84 = load i16, ptr %78, align 1, !tbaa !53
  %85 = add i16 %84, %19
  br label %86

86:                                               ; preds = %65, %34, %25
  %87 = phi i16 [ %19, %25 ], [ %19, %34 ], [ %85, %65 ]
  %88 = add nuw i8 %20, 1
  %89 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %90 = icmp ult i8 %88, %89
  br i1 %90, label %17, label %91

91:                                               ; preds = %86, %46
  %92 = phi i8 [ %89, %86 ], [ %18, %46 ]
  %93 = phi i8 [ %88, %86 ], [ %20, %46 ]
  %94 = icmp ult i8 %93, %92
  br i1 %94, label %95, label %108

95:                                               ; preds = %91
  %96 = icmp eq i8 %93, 0
  br i1 %96, label %110, label %97

97:                                               ; preds = %95, %97
  %98 = phi i8 [ %101, %97 ], [ 0, %95 ]
  %99 = phi i8 [ %104, %97 ], [ %93, %95 ]
  %100 = zext i8 %99 to i16
  %101 = add i8 %98, 1
  %102 = zext i8 %98 to i16
  %103 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %102
  %104 = add nuw i8 %99, 1
  %105 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %100
  tail call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(11) %103, ptr noundef nonnull align 1 dereferenceable(11) %105, i16 11, i1 false), !tbaa.struct !139
  %106 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %107 = icmp ult i8 %104, %106
  br i1 %107, label %97, label %108, !llvm.loop !140

108:                                              ; preds = %97, %91, %0
  %109 = phi i8 [ 0, %91 ], [ 0, %0 ], [ %101, %97 ]
  store i8 %109, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  br label %110

110:                                              ; preds = %108, %95
  ret void
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #10

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #11

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #11

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #3 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #4 = { nofree norecurse nosync nounwind optsize memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #5 = { nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #6 = { inlinehint nofree norecurse nosync nounwind optsize memory(argmem: write) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #7 = { nofree norecurse nosync nounwind optsize memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #8 = { nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #9 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #10 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #12 = { nounwind optsize }
attributes #13 = { optsize }
attributes #14 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!10, !4, i64 194}
!10 = !{!"", !11, i64 0, !12, i64 178, !13, i64 182, !4, i64 191, !4, i64 192, !4, i64 193, !4, i64 194, !4, i64 195}
!11 = !{!"", !4, i64 0, !4, i64 176, !4, i64 177}
!12 = !{!"", !3, i64 0, !3, i64 2}
!13 = !{!"", !4, i64 0, !4, i64 8}
!14 = !{!10, !4, i64 195}
!15 = !{!16, !18, i64 0}
!16 = !{!"", !17, i64 0, !4, i64 3, !3, i64 4099, !3, i64 4101, !3, i64 4103, !3, i64 4105, !4, i64 4107, !4, i64 4108}
!17 = !{!"Drawable", !18, i64 0, !4, i64 2}
!18 = !{!"any pointer", !4, i64 0}
!19 = !{!16, !4, i64 2}
!20 = !{!16, !3, i64 4103}
!21 = !{!16, !3, i64 4105}
!22 = !{!16, !4, i64 4107}
!23 = !{!16, !4, i64 4108}
!24 = !{!16, !3, i64 4099}
!25 = !{!16, !3, i64 4101}
!26 = !{!27, !18, i64 0}
!27 = !{!"", !17, i64 0, !3, i64 3, !4, i64 5, !4, i64 7, !4, i64 135}
!28 = !{!27, !4, i64 2}
!29 = !{!27, !3, i64 3}
!30 = distinct !{!30, !8}
!31 = !{!27, !4, i64 135}
!32 = !{!10, !4, i64 192}
!33 = !{!10, !4, i64 193}
!34 = !{!13, !4, i64 8}
!35 = !{!36, !36, i64 0}
!36 = !{!"p1 _ZTS8Drawable", !18, i64 0}
!37 = distinct !{null, null}
!38 = !{!10, !4, i64 191}
!39 = !{!17, !4, i64 2}
!40 = !{!17, !18, i64 0}
!41 = !{!42, !18, i64 0}
!42 = !{!"", !18, i64 0, !18, i64 2}
!43 = distinct !{null, null, null}
!44 = !{!11, !4, i64 176}
!45 = !{!46, !4, i64 10}
!46 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !4, i64 6, !4, i64 7, !4, i64 8, !4, i64 9, !4, i64 10}
!47 = !{!46, !3, i64 0}
!48 = !{!46, !4, i64 9}
!49 = !{!46, !4, i64 7}
!50 = !{!46, !4, i64 8}
!51 = !{!46, !3, i64 2}
!52 = !{!46, !4, i64 6}
!53 = !{!46, !3, i64 4}
!54 = !{!55, !3, i64 4441}
!55 = !{!"", !10, i64 0, !16, i64 196, !27, i64 4305, !3, i64 4441, !3, i64 4443}
!56 = !{!55, !3, i64 4443}
!57 = distinct !{!57, !8}
!58 = !{!59, !18, i64 0}
!59 = !{!"", !17, i64 0, !60, i64 3, !60, i64 5, !60, i64 7, !60, i64 9, !4, i64 11, !4, i64 12, !3, i64 13, !3, i64 15, !3, i64 17, !3, i64 19, !3, i64 21, !3, i64 23, !4, i64 25, !3, i64 26, !4, i64 28, !4, i64 29, !4, i64 30, !4, i64 31, !4, i64 32, !4, i64 33, !3, i64 34, !3, i64 36, !61, i64 38, !61, i64 89}
!60 = !{!"p1 omnipotent char", !18, i64 0}
!61 = !{!"", !4, i64 0, !4, i64 50}
!62 = !{!59, !4, i64 2}
!63 = !{!59, !60, i64 3}
!64 = !{!59, !60, i64 5}
!65 = !{!59, !60, i64 7}
!66 = !{!59, !4, i64 11}
!67 = !{!59, !60, i64 9}
!68 = !{!59, !4, i64 12}
!69 = !{!59, !3, i64 13}
!70 = !{!59, !3, i64 15}
!71 = !{!59, !3, i64 17}
!72 = !{!59, !4, i64 28}
!73 = !{!59, !4, i64 29}
!74 = !{!59, !4, i64 31}
!75 = !{!59, !4, i64 32}
!76 = !{!59, !4, i64 30}
!77 = !{!59, !4, i64 25}
!78 = !{!59, !3, i64 34}
!79 = !{!59, !3, i64 36}
!80 = !{!59, !4, i64 33}
!81 = !{!42, !18, i64 2}
!82 = distinct !{null, null, null, null, null}
!83 = distinct !{!83, !8}
!84 = distinct !{!84, !8}
!85 = distinct !{!85, !8}
!86 = distinct !{null, null, null, null}
!87 = distinct !{!87, !8}
!88 = distinct !{!88, !8}
!89 = distinct !{!89, !8}
!90 = distinct !{!90, !8}
!91 = distinct !{null, null, null, null, null}
!92 = distinct !{!92, !8}
!93 = distinct !{!93, !8}
!94 = distinct !{null, null, null, null}
!95 = !{!59, !3, i64 19}
!96 = distinct !{null, null, null, null, null}
!97 = distinct !{!97, !8}
!98 = distinct !{!98, !8}
!99 = distinct !{!99, !8}
!100 = distinct !{!100, !8}
!101 = distinct !{null, null, null}
!102 = distinct !{!102, !8}
!103 = distinct !{!103, !8}
!104 = distinct !{!104, !8}
!105 = distinct !{!105, !8}
!106 = distinct !{!106, !8}
!107 = distinct !{!107, !8}
!108 = distinct !{!108, !8}
!109 = distinct !{!109, !8}
!110 = distinct !{!110, !8}
!111 = distinct !{!111, !8}
!112 = distinct !{!112, !8}
!113 = distinct !{!113, !8}
!114 = distinct !{!114, !8}
!115 = distinct !{!115, !8}
!116 = distinct !{!116, !8}
!117 = !{!59, !3, i64 21}
!118 = !{!59, !3, i64 23}
!119 = distinct !{!119, !8}
!120 = !{!59, !3, i64 26}
!121 = !{!61, !4, i64 50}
!122 = distinct !{!122, !8}
!123 = distinct !{!123, !8}
!124 = !{!125, !18, i64 0}
!125 = !{!"", !18, i64 0, !4, i64 2}
!126 = !{!125, !4, i64 2}
!127 = distinct !{!127, !8}
!128 = distinct !{!128, !8}
!129 = distinct !{!129, !8}
!130 = distinct !{!130, !8}
!131 = distinct !{!131, !8}
!132 = distinct !{!132, !8}
!133 = distinct !{!133, !8}
!134 = distinct !{!134, !8}
!135 = distinct !{!135, !8}
!136 = distinct !{!136, !8}
!137 = distinct !{!137, !8}
!138 = !{!11, !4, i64 177}
!139 = !{i64 0, i64 2, !2, i64 2, i64 2, !2, i64 4, i64 2, !2, i64 6, i64 1, !6, i64 7, i64 1, !6, i64 8, i64 1, !6, i64 9, i64 1, !6, i64 10, i64 1, !6}
!140 = distinct !{!140, !8}
