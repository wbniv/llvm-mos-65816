; ModuleID = '/work/examples/snes/corpus/mandel-double_sim.c'
source_filename = "/work/examples/snes/corpus/mandel-double_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1
@md_gate_crc.dbuf = internal unnamed_addr global [25 x i8] zeroinitializer, align 1
@md_gate_crc.fbuf = internal unnamed_addr global [25 x i8] zeroinitializer, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %8, %0
  %2 = phi i8 [ %13, %8 ], [ 0, %0 ]
  %3 = phi ptr [ %11, %8 ], [ @md_gate_crc.dbuf, %0 ]
  %4 = phi i8 [ %9, %8 ], [ 0, %0 ]
  %5 = uitofp nneg i8 %4 to double
  %6 = fmul nnan double %5, 0x3FE1EB851EB851EB
  %7 = fadd double %6, -1.400000e+00
  br label %14

8:                                                ; preds = %14
  %9 = add nuw nsw i8 %4, 1
  %10 = zext nneg i8 %2 to i16
  %11 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @md_gate_crc.dbuf, i16 5), i16 %10
  %12 = icmp eq i8 %9, 5
  %13 = add nuw nsw i8 %2, 5
  br i1 %12, label %24, label %1, !llvm.loop !6

14:                                               ; preds = %14, %1
  %15 = phi i8 [ 0, %1 ], [ %22, %14 ]
  %16 = uitofp nneg i8 %15 to double
  %17 = fmul nnan double %16, 6.400000e-01
  %18 = fadd double %17, -2.200000e+00
  %19 = tail call fastcc zeroext i8 @md_cell_double(double noundef %18, double noundef %7) #3
  %20 = zext nneg i8 %15 to i16
  %21 = getelementptr i8, ptr %3, i16 %20
  store i8 %19, ptr %21, align 1, !tbaa !8
  %22 = add nuw nsw i8 %15, 1
  %23 = icmp eq i8 %22, 5
  br i1 %23, label %8, label %14, !llvm.loop !9

24:                                               ; preds = %8, %33
  %25 = phi i8 [ %34, %33 ], [ 0, %8 ]
  %26 = phi i16 [ %44, %33 ], [ -1, %8 ]
  %27 = zext nneg i8 %25 to i16
  %28 = getelementptr i8, ptr @md_gate_crc.dbuf, i16 %27
  %29 = load i8, ptr %28, align 1, !tbaa !8
  %30 = zext i8 %29 to i16
  %31 = shl nuw i16 %30, 8
  %32 = xor i16 %31, %26
  br label %36

33:                                               ; preds = %43
  %34 = add nuw nsw i8 %25, 1
  %35 = icmp eq i8 %34, 25
  br i1 %35, label %47, label %24, !llvm.loop !10

36:                                               ; preds = %43, %24
  %37 = phi i8 [ 0, %24 ], [ %45, %43 ]
  %38 = phi i16 [ %32, %24 ], [ %44, %43 ]
  %39 = icmp sgt i16 %38, -1
  %40 = shl i16 %38, 1
  br i1 %39, label %43, label %41

41:                                               ; preds = %36
  %42 = xor i16 %40, 4129
  br label %43

43:                                               ; preds = %41, %36
  %44 = phi i16 [ %42, %41 ], [ %40, %36 ]
  %45 = add nuw nsw i8 %37, 1
  %46 = icmp eq i8 %45, 8
  br i1 %46, label %33, label %36, !llvm.loop !11

47:                                               ; preds = %33, %54
  %48 = phi i8 [ %59, %54 ], [ 0, %33 ]
  %49 = phi ptr [ %57, %54 ], [ @md_gate_crc.fbuf, %33 ]
  %50 = phi i8 [ %55, %54 ], [ 0, %33 ]
  %51 = uitofp nneg i8 %50 to float
  %52 = fmul nnan float %51, 0x3FE1EB8520000000
  %53 = fadd float %52, 0xBFF6666660000000
  br label %60

54:                                               ; preds = %60
  %55 = add nuw nsw i8 %50, 1
  %56 = zext nneg i8 %48 to i16
  %57 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @md_gate_crc.fbuf, i16 5), i16 %56
  %58 = icmp eq i8 %55, 5
  %59 = add nuw nsw i8 %48, 5
  br i1 %58, label %70, label %47, !llvm.loop !12

60:                                               ; preds = %60, %47
  %61 = phi i8 [ 0, %47 ], [ %68, %60 ]
  %62 = uitofp nneg i8 %61 to float
  %63 = fmul nnan float %62, 0x3FE47AE140000000
  %64 = fadd float %63, 0xC0019999A0000000
  %65 = tail call fastcc zeroext i8 @md_cell_float(float noundef %64, float noundef %53) #3
  %66 = zext nneg i8 %61 to i16
  %67 = getelementptr i8, ptr %49, i16 %66
  store i8 %65, ptr %67, align 1, !tbaa !8
  %68 = add nuw nsw i8 %61, 1
  %69 = icmp eq i8 %68, 5
  br i1 %69, label %54, label %60, !llvm.loop !13

70:                                               ; preds = %54, %79
  %71 = phi i8 [ %80, %79 ], [ 0, %54 ]
  %72 = phi i16 [ %90, %79 ], [ -1, %54 ]
  %73 = zext nneg i8 %71 to i16
  %74 = getelementptr i8, ptr @md_gate_crc.fbuf, i16 %73
  %75 = load i8, ptr %74, align 1, !tbaa !8
  %76 = zext i8 %75 to i16
  %77 = shl nuw i16 %76, 8
  %78 = xor i16 %77, %72
  br label %82

79:                                               ; preds = %89
  %80 = add nuw nsw i8 %71, 1
  %81 = icmp eq i8 %80, 25
  br i1 %81, label %93, label %70, !llvm.loop !10

82:                                               ; preds = %89, %70
  %83 = phi i8 [ 0, %70 ], [ %91, %89 ]
  %84 = phi i16 [ %78, %70 ], [ %90, %89 ]
  %85 = icmp sgt i16 %84, -1
  %86 = shl i16 %84, 1
  br i1 %85, label %89, label %87

87:                                               ; preds = %82
  %88 = xor i16 %86, 4129
  br label %89

89:                                               ; preds = %87, %82
  %90 = phi i16 [ %88, %87 ], [ %86, %82 ]
  %91 = add nuw nsw i8 %83, 1
  %92 = icmp eq i8 %91, 8
  br i1 %92, label %79, label %82, !llvm.loop !11

93:                                               ; preds = %79, %93
  %94 = phi double [ %110, %93 ], [ 0.000000e+00, %79 ]
  %95 = phi double [ %113, %93 ], [ 0.000000e+00, %79 ]
  %96 = phi i32 [ %108, %93 ], [ -2128831035, %79 ]
  %97 = phi i8 [ %114, %93 ], [ 0, %79 ]
  %98 = fmul double %94, %94
  %99 = fmul double %95, %95
  %100 = fadd double %98, %99
  %101 = bitcast double %100 to i64
  %102 = trunc i64 %101 to i32
  %103 = lshr i64 %101, 32
  %104 = trunc nuw i64 %103 to i32
  %105 = xor i32 %96, %102
  %106 = mul i32 %105, 16777619
  %107 = xor i32 %106, %104
  %108 = mul i32 %107, 16777619
  %109 = fsub double %98, %99
  %110 = fadd double %109, -5.000000e-01
  %111 = fmul double %94, %95
  %112 = fadd double %111, %111
  %113 = fadd double %112, 0.000000e+00
  %114 = add nuw nsw i8 %97, 1
  %115 = icmp eq i8 %114, 12
  br i1 %115, label %116, label %93, !llvm.loop !14

116:                                              ; preds = %93
  %117 = tail call i16 @llvm.fshl.i16(i16 %44, i16 %44, i16 1)
  %118 = trunc i32 %108 to i16
  %119 = xor i16 %117, %118
  %120 = xor i16 %119, %90
  %121 = tail call i16 @llvm.fshl.i16(i16 %120, i16 %120, i16 1)
  %122 = lshr i32 %108, 16
  %123 = trunc nuw i32 %122 to i16
  %124 = xor i16 %121, %123
  %125 = xor i16 %124, 13214
  %126 = tail call i16 @llvm.fshl.i16(i16 %125, i16 %125, i16 1)
  %127 = xor i16 %126, 11334
  store volatile i16 %127, ptr @corpus_result, align 1, !tbaa !2
  br label %128

128:                                              ; preds = %128, %116
  tail call void asm sideeffect "wai", ""() #4, !srcloc !15
  br label %128
}

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(none)
define internal fastcc zeroext i8 @md_cell_double(double noundef %0, double noundef %1) unnamed_addr #1 {
  br label %3

3:                                                ; preds = %2, %11
  %4 = phi double [ 0.000000e+00, %2 ], [ %13, %11 ]
  %5 = phi double [ 0.000000e+00, %2 ], [ %16, %11 ]
  %6 = phi i8 [ 0, %2 ], [ %17, %11 ]
  %7 = fmul double %4, %4
  %8 = fmul double %5, %5
  %9 = fadd double %8, %7
  %10 = fcmp ogt double %9, 4.000000e+00
  br i1 %10, label %19, label %11

11:                                               ; preds = %3
  %12 = fsub double %7, %8
  %13 = fadd double %0, %12
  %14 = fmul double %5, %4
  %15 = fadd double %14, %14
  %16 = fadd double %1, %15
  %17 = add nuw nsw i8 %6, 1
  %18 = icmp eq i8 %17, 6
  br i1 %18, label %19, label %3, !llvm.loop !16

19:                                               ; preds = %3, %11
  %20 = phi i8 [ %6, %3 ], [ 6, %11 ]
  ret i8 %20
}

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(none)
define internal fastcc zeroext i8 @md_cell_float(float noundef %0, float noundef %1) unnamed_addr #1 {
  br label %3

3:                                                ; preds = %2, %11
  %4 = phi float [ 0.000000e+00, %2 ], [ %13, %11 ]
  %5 = phi float [ 0.000000e+00, %2 ], [ %16, %11 ]
  %6 = phi i8 [ 0, %2 ], [ %17, %11 ]
  %7 = fmul float %4, %4
  %8 = fmul float %5, %5
  %9 = fadd float %8, %7
  %10 = fcmp ogt float %9, 4.000000e+00
  br i1 %10, label %19, label %11

11:                                               ; preds = %3
  %12 = fsub float %7, %8
  %13 = fadd float %0, %12
  %14 = fmul float %5, %4
  %15 = fadd float %14, %14
  %16 = fadd float %1, %15
  %17 = add nuw nsw i8 %6, 1
  %18 = icmp eq i8 %17, 6
  br i1 %18, label %19, label %3, !llvm.loop !17

19:                                               ; preds = %3, %11
  %20 = phi i8 [ %6, %3 ], [ 6, %11 ]
  ret i8 %20
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #2

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { nofree noinline norecurse nosync nounwind optsize memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { optsize }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{!4, !4, i64 0}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
!15 = !{i64 1115}
!16 = distinct !{!16, !7}
!17 = distinct !{!17, !7}
