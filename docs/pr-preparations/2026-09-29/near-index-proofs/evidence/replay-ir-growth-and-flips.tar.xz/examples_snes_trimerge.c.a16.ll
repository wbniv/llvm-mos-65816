; ModuleID = '/work/examples/snes/trimerge.c'
source_filename = "/work/examples/snes/trimerge.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.App = type { %struct.Display, %struct.BitmapCanvas, %struct.TextLayer, %struct.HScrollDB, [4 x i16], i16, i16, i8 }
%struct.Display = type { %struct.UploadQueue, %struct.VramAlloc, %struct.Scene, i8, i8, i8, i8, i8 }
%struct.UploadQueue = type { [16 x %struct.UpqJob], i8, i8 }
%struct.UpqJob = type { i16, i16, i16, i8, i8, i8, i8, i8 }
%struct.VramAlloc = type { i16, i16 }
%struct.Scene = type { [4 x ptr], i8 }
%struct.BitmapCanvas = type { %struct.Drawable, [4096 x i8], i16, i16, i16, i16, i8, i8 }
%struct.Drawable = type { ptr, i8 }
%struct.TextLayer = type { %struct.Drawable, i16, [2 x i8], [64 x i16], i8 }
%struct.HScrollDB = type { [2 x %struct.HScrollN], i8 }
%struct.HScrollN = type { [25 x i8] }
%struct.TitleLayer = type { %struct.Drawable, ptr, ptr, ptr, ptr, i8, i8, i16, i16, i16, i16, i16, i16, i8, i16, i8, i8, i8, i8, i8, i8, i16, i16, %struct.HScrollDB, %struct.HScrollDB }
%struct.DrawableVT = type { ptr, ptr }
%struct.HScrollW = type { ptr, i8 }

@main.a = internal global %struct.App zeroinitializer, align 1
@main.title = internal global %struct.TitleLayer zeroinitializer, align 1
@.str = private unnamed_addr constant [9 x i8] c"TRIMERGE\00", align 1
@.str.1 = private unnamed_addr constant [26 x i8] c"SPACESHIP AS CONTROL FLOW\00", align 1
@corpus_result = dso_local global i16 0, align 1
@grad_tab = internal constant [141 x i8] c"\08\00\00 \14\08\00\00 \18\08\00\00A \08\00\00A$\08\00\00a(\08\00\00b0\08\00\00b4\08\00\00\828\08\00\00\82<\08\00\00\83D\08\00\00\A3H\08\00\00\A3L\08\00\00\C4T\08\00\00\C4X\08\00\00\C4X\08\00\00\C4T\08\00\00\A3L\08\00\00\A3H\08\00\00\83D\08\00\00\82<\08\00\00\828\08\00\00b4\08\00\00b0\08\00\00a(\08\00\00A$\08\00\00A \08\00\00 \18\08\00\00 \14\00", align 1
@bg3_pal = internal constant [4 x i16] [i16 16514, i16 17028, i16 2458, i16 11166], align 1
@.str.2 = private unnamed_addr constant [21 x i8] c"THREE-WAY MERGE DIFF\00", align 1
@CANVAS_VT = internal constant %struct.DrawableVT { ptr @_canvas_reserve, ptr @_canvas_emit }, align 1
@TEXT_VT = internal constant %struct.DrawableVT { ptr @_text_reserve, ptr @_text_emit }, align 1
@FONT8 = internal unnamed_addr constant [512 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 32, i16 0, i16 80, i16 80, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 80, i16 80, i16 248, i16 80, i16 248, i16 80, i16 80, i16 0, i16 32, i16 120, i16 160, i16 112, i16 40, i16 240, i16 32, i16 0, i16 196, i16 200, i16 16, i16 32, i16 64, i16 152, i16 12, i16 0, i16 96, i16 144, i16 160, i16 64, i16 168, i16 144, i16 104, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 16, i16 32, i16 64, i16 64, i16 64, i16 32, i16 16, i16 0, i16 64, i16 32, i16 16, i16 16, i16 16, i16 32, i16 64, i16 0, i16 0, i16 32, i16 168, i16 112, i16 168, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 248, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 64, i16 0, i16 0, i16 0, i16 248, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 0, i16 8, i16 8, i16 16, i16 32, i16 64, i16 128, i16 128, i16 0, i16 112, i16 136, i16 152, i16 168, i16 200, i16 136, i16 112, i16 0, i16 32, i16 96, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 64, i16 248, i16 0, i16 112, i16 136, i16 8, i16 48, i16 8, i16 136, i16 112, i16 0, i16 16, i16 48, i16 80, i16 144, i16 248, i16 16, i16 16, i16 0, i16 248, i16 128, i16 240, i16 8, i16 8, i16 136, i16 112, i16 0, i16 112, i16 136, i16 128, i16 240, i16 136, i16 136, i16 112, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 64, i16 64, i16 0, i16 112, i16 136, i16 136, i16 112, i16 136, i16 136, i16 112, i16 0, i16 112, i16 136, i16 136, i16 120, i16 8, i16 136, i16 112, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 64, i16 0, i16 16, i16 32, i16 64, i16 128, i16 64, i16 32, i16 16, i16 0, i16 0, i16 0, i16 248, i16 0, i16 248, i16 0, i16 0, i16 0, i16 128, i16 64, i16 32, i16 16, i16 32, i16 64, i16 128, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 0, i16 32, i16 0, i16 112, i16 136, i16 184, i16 168, i16 184, i16 128, i16 112, i16 0, i16 112, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 240, i16 136, i16 136, i16 240, i16 136, i16 136, i16 240, i16 0, i16 112, i16 136, i16 128, i16 128, i16 128, i16 136, i16 112, i16 0, i16 224, i16 144, i16 136, i16 136, i16 136, i16 144, i16 224, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 248, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 128, i16 176, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 112, i16 32, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 56, i16 16, i16 16, i16 16, i16 144, i16 144, i16 96, i16 0, i16 136, i16 144, i16 160, i16 192, i16 160, i16 144, i16 136, i16 0, i16 128, i16 128, i16 128, i16 128, i16 128, i16 128, i16 248, i16 0, i16 136, i16 216, i16 168, i16 136, i16 136, i16 136, i16 136, i16 0, i16 136, i16 200, i16 168, i16 152, i16 136, i16 136, i16 136, i16 0, i16 112, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 240, i16 136, i16 136, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 136, i16 136, i16 168, i16 144, i16 104, i16 0, i16 240, i16 136, i16 136, i16 240, i16 160, i16 144, i16 136, i16 0, i16 112, i16 136, i16 128, i16 112, i16 8, i16 136, i16 112, i16 0, i16 248, i16 32, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 80, i16 32, i16 0, i16 136, i16 136, i16 136, i16 168, i16 168, i16 216, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 80, i16 136, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 32, i16 32, i16 32, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 128, i16 248, i16 0, i16 48, i16 32, i16 32, i16 32, i16 32, i16 32, i16 48, i16 0, i16 128, i16 128, i16 64, i16 32, i16 16, i16 8, i16 8, i16 0, i16 48, i16 16, i16 16, i16 16, i16 16, i16 16, i16 48, i16 0, i16 32, i16 80, i16 136, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248], align 1
@TITLE_VT = internal constant %struct.DrawableVT { ptr @_title_reserve, ptr @_title_emit }, align 1
@FONT16 = internal unnamed_addr constant [2048 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 192, i16 192, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 768, i16 768, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 -4096, i16 -4096, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3840, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 3312, i16 15360, i16 15360, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 28, i16 28, i16 796, i16 127, i16 127, i16 796, i16 796, i16 127, i16 112, i16 112, i16 3184, i16 252, i16 252, i16 -28816, i16 -28816, i16 252, i16 127, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 0, i16 0, i16 252, i16 -28816, i16 -28816, i16 3184, i16 7168, i16 7168, i16 0, i16 0, i16 3, i16 63, i16 123, i16 1147, i16 63, i16 4111, i16 3075, i16 123, i16 192, i16 248, i16 8414, i16 16064, i16 2040, i16 248, i16 8414, i16 8414, i16 63, i16 7171, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 2040, i16 14272, i16 -512, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3585, i16 3, i16 7, i16 28, i16 56, i16 1904, i16 3808, i16 7392, i16 14528, i16 14464, i16 28672, i16 14, i16 284, i16 824, i16 1792, i16 3584, i16 0, i16 0, i16 0, i16 -8162, i16 -16354, i16 -32482, i16 286, i16 1792, i16 1792, i16 0, i16 0, i16 15, i16 31, i16 828, i16 828, i16 573, i16 31, i16 31, i16 63, i16 192, i16 224, i16 240, i16 2288, i16 7392, i16 15488, i16 30720, i16 -32648, i16 382, i16 3060, i16 3825, i16 1275, i16 127, i16 63, i16 7936, i16 3840, i16 248, i16 3824, i16 7904, i16 7392, i16 4332, i16 12492, i16 -1280, i16 -3328, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 7, i16 15, i16 15, i16 15, i16 15, i16 15, i16 240, i16 192, i16 15488, i16 -4096, i16 -8192, i16 -16384, i16 -16384, i16 -16384, i16 15, i16 7, i16 3, i16 256, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 16512, i16 192, i16 240, i16 -4096, i16 15360, i16 0, i16 0, i16 15, i16 3, i16 513, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 224, i16 240, i16 2288, i16 3312, i16 3312, i16 3312, i16 0, i16 1, i16 3, i16 15, i16 0, i16 768, i16 0, i16 0, i16 3312, i16 7392, i16 15552, i16 30720, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 51, i16 31, i16 15, i16 1027, i16 0, i16 0, i16 192, i16 192, i16 12492, i16 252, i16 1016, i16 16320, i16 15, i16 31, i16 51, i16 1027, i16 3072, i16 0, i16 0, i16 0, i16 1784, i16 252, i16 13004, i16 16320, i16 -3328, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 3, i16 63, i16 63, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 248, i16 248, i16 63, i16 3075, i16 3075, i16 3, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 16064, i16 16064, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 286, i16 828, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 28800, i16 -4096, i16 -8192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 -512, i16 -512, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7360, i16 14464, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7168, i16 14336, i16 28672, i16 -8192, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 828, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 15, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 1, i16 3, i16 15, i16 15, i16 513, i16 513, i16 1, i16 1, i16 240, i16 240, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 1, i16 1, i16 1, i16 1, i16 1, i16 1, i16 0, i16 0, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 31744, i16 31744, i16 15, i16 31, i16 318, i16 828, i16 3840, i16 3840, i16 3, i16 15, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 63, i16 510, i16 4080, i16 31, i16 318, i16 318, i16 318, i16 63, i16 63, i16 3840, i16 3840, i16 32640, i16 -1024, i16 -8192, i16 -32768, i16 255, i16 255, i16 -256, i16 -256, i16 15, i16 63, i16 824, i16 3840, i16 2055, i16 7, i16 256, i16 256, i16 252, i16 254, i16 -8161, i16 -4081, i16 510, i16 1020, i16 -7906, i16 -4081, i16 0, i16 0, i16 56, i16 60, i16 63, i16 31, i16 3840, i16 1792, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 15, i16 286, i16 62, i16 126, i16 510, i16 510, i16 8670, i16 24990, i16 -7906, i16 -7906, i16 828, i16 828, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 -16098, i16 -32482, i16 255, i16 255, i16 -7906, i16 -7906, i16 1792, i16 1792, i16 31, i16 63, i16 828, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 254, i16 254, i16 -256, i16 -256, i16 252, i16 254, i16 -8161, i16 -4081, i16 0, i16 0, i16 60, i16 62, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 63, i16 63, i16 318, i16 828, i16 254, i16 255, i16 -2041, i16 -256, i16 508, i16 254, i16 -4081, i16 -2041, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 -32761, i16 7, i16 7, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 31, i16 318, i16 892, i16 0, i16 1, i16 3, i16 7, i16 7, i16 7, i16 256, i16 256, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 28800, i16 -8192, i16 -8192, i16 15, i16 31, i16 828, i16 828, i16 828, i16 31, i16 15, i16 796, i16 252, i16 254, i16 -4081, i16 -4081, i16 15, i16 510, i16 1020, i16 -3826, i16 828, i16 828, i16 828, i16 828, i16 31, i16 15, i16 1792, i16 768, i16 -4081, i16 15, i16 15, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 318, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 31, i16 31, i16 15, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 270, i16 796, i16 824, i16 1792, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 15, i16 60, i16 828, i16 0, i16 0, i16 60, i16 240, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 15360, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 60, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 60, i16 0, i16 3, i16 15, i16 60, i16 768, i16 3840, i16 0, i16 0, i16 4080, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 31, i16 63, i16 828, i16 3840, i16 3840, i16 7, i16 7, i16 7, i16 240, i16 248, i16 -32644, i16 -32132, i16 2040, i16 4080, i16 16064, i16 31872, i16 256, i16 256, i16 7, i16 7, i16 7, i16 256, i16 256, i16 0, i16 -4096, i16 -8192, i16 128, i16 128, i16 24704, i16 -8192, i16 -8192, i16 0, i16 31, i16 63, i16 828, i16 573, i16 573, i16 573, i16 573, i16 573, i16 248, i16 252, i16 -15812, i16 4590, i16 494, i16 4590, i16 1020, i16 1016, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 0, i16 0, i16 0, i16 32512, i16 764, i16 248, i16 -256, i16 -512, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 892, i16 1020, i16 1020, i16 255, i16 255, i16 224, i16 240, i16 -32648, i16 -16324, i16 -32196, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -28928, i16 1792, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 0, i16 0, i16 28, i16 60, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -8164, i16 -3572, i16 -30976, i16 768, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 8988, i16 8988, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 60, i16 60, i16 828, i16 828, i16 828, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 255, i16 255, i16 16128, i16 16128, i16 12480, i16 12480, i16 12480, i16 12480, i16 252, i16 252, i16 -256, i16 -256, i16 63, i16 63, i16 3075, i16 3075, i16 3, i16 3, i16 51, i16 51, i16 252, i16 252, i16 4080, i16 4080, i16 3312, i16 3312, i16 3312, i16 3312, i16 3123, i16 3123, i16 63, i16 63, i16 31, i16 15, i16 1792, i16 768, i16 3312, i16 3312, i16 3312, i16 3312, i16 7392, i16 15552, i16 -2048, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 765, i16 255, i16 255, i16 255, i16 28, i16 60, i16 1912, i16 4080, i16 7904, i16 15552, i16 30848, i16 12480, i16 255, i16 765, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 224, i16 240, i16 248, i16 124, i16 572, i16 828, i16 3840, i16 3840, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 0, i16 0, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 248, i16 252, i16 254, i16 2295, i16 3315, i16 3315, i16 3315, i16 3315, i16 60, i16 124, i16 1020, i16 988, i16 9116, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 15360, i16 15360, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 -6400, i16 -6400, i16 240, i16 248, i16 252, i16 254, i16 255, i16 255, i16 2295, i16 3315, i16 60, i16 60, i16 828, i16 828, i16 828, i16 956, i16 1020, i16 1020, i16 3313, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 15360, i16 15360, i16 1020, i16 1020, i16 892, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -31972, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -512, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 224, i16 240, i16 -32648, i16 -15304, i16 -31176, i16 1592, i16 1592, i16 1592, i16 765, i16 765, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 1784, i16 1784, i16 17976, i16 1656, i16 764, i16 764, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 63, i16 127, i16 2040, i16 4080, i16 1784, i16 255, i16 127, i16 63, i16 248, i16 252, i16 -15812, i16 -256, i16 3840, i16 240, i16 248, i16 252, i16 7936, i16 3840, i16 224, i16 255, i16 255, i16 127, i16 16128, i16 7936, i16 -32132, i16 -15556, i16 892, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 -4096, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 28, i16 28, i16 796, i16 796, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 510, i16 255, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 828, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 248, i16 248, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 124, i16 124, i16 1912, i16 1912, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 572, i16 63, i16 31, i16 15, i16 7, i16 768, i16 256, i16 1656, i16 3824, i16 3824, i16 7392, i16 15552, i16 30848, i16 -4096, i16 -8192, i16 243, i16 243, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 156, i16 156, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 2295, i16 255, i16 510, i16 892, i16 16128, i16 7936, i16 25500, i16 25500, i16 9180, i16 1020, i16 1020, i16 -30856, i16 -16640, i16 7680, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 15, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 14528, i16 31, i16 63, i16 892, i16 2040, i16 4080, i16 3824, i16 15360, i16 15360, i16 4320, i16 240, i16 248, i16 -32644, i16 572, i16 828, i16 3840, i16 3840, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 7, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 7, i16 7, i16 7, i16 7, i16 7, i16 7, i16 256, i16 256, i16 28800, i16 24704, i16 24704, i16 24704, i16 24704, i16 24704, i16 -8192, i16 -8192, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 1, i16 3, i16 7, i16 252, i16 252, i16 1020, i16 -31876, i16 2040, i16 4080, i16 7904, i16 15552, i16 15, i16 31, i16 318, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 30848, i16 -4096, i16 -8192, i16 252, i16 252, i16 1020, i16 -256, i16 -256, i16 31, i16 31, i16 286, i16 286, i16 286, i16 286, i16 286, i16 286, i16 224, i16 224, i16 -2048, i16 -2048, i16 -32768, i16 -32768, i16 -32768, i16 -32768, i16 286, i16 286, i16 286, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 -32768, i16 -32768, i16 -32768, i16 224, i16 224, i16 -2048, i16 -2048, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 3, i16 1, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 128, i16 192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 768, i16 256, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 0, i16 0, i16 0, i16 224, i16 224, i16 2288, i16 2288, i16 3312, i16 3312, i16 3312, i16 3312, i16 0, i16 0, i16 0, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 3312, i16 3312, i16 3312, i16 7392, i16 7392, i16 -2048, i16 -2048, i16 0, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1840, i16 3584, i16 3072, i16 192, i16 224, i16 -32656, i16 -16328, i16 -32740, i16 524, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 127, i16 127, i16 7936, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 -512], align 1
@_tm_l32 = internal unnamed_addr global [20 x i32] zeroinitializer, align 1
@_tm_r32 = internal unnamed_addr global [20 x i32] zeroinitializer, align 1
@_tm_o32 = internal unnamed_addr global [40 x i32] zeroinitializer, align 1
@_tm_l64 = internal unnamed_addr global [20 x i64] zeroinitializer, align 8
@_tm_r64 = internal unnamed_addr global [20 x i64] zeroinitializer, align 8
@_tm_o64 = internal unnamed_addr global [40 x i64] zeroinitializer, align 8
@title_end._title_bg_black = internal constant i16 0, align 1
@update_hud.H = internal unnamed_addr constant [17 x i8] c"0123456789ABCDEF\00", align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [21 x i8], align 1
  store volatile i8 -113, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  br label %2

2:                                                ; preds = %6, %0
  %3 = phi i16 [ 8449, %0 ], [ %7, %6 ]
  switch i16 %3, label %4 [
    i16 8452, label %6
    i16 8470, label %6
    i16 8471, label %6
    i16 8472, label %6
    i16 8473, label %6
    i16 8481, label %6
    i16 8482, label %6
  ]

4:                                                ; preds = %2
  %5 = inttoptr i16 %3 to ptr
  store volatile i8 0, ptr %5, align 1, !tbaa !6
  br label %6

6:                                                ; preds = %4, %2, %2, %2, %2, %2, %2, %2
  %7 = add nuw nsw i16 %3, 1
  %8 = icmp eq i16 %7, 8500
  br i1 %8, label %9, label %2, !llvm.loop !7

9:                                                ; preds = %6
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) getelementptr inbounds nuw (i8, ptr @main.a, i16 176), i8 0, i64 6, i1 false)
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  store volatile i8 1, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 -127, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !6
  store ptr @CANVAS_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), align 1, !tbaa !15
  store i8 4, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !19
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4299), align 1, !tbaa !20
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4301), align 1, !tbaa !21
  store i8 8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4303), align 1, !tbaa !22
  store i8 6, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4304), align 1, !tbaa !23
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(4096) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i16 4096, i1 false), !tbaa !6
  store i16 -1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  store ptr @TEXT_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !26
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !28
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4308), align 1, !tbaa !29
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4310), align 1, !tbaa !6
  store i8 26, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4311), align 1, !tbaa !6
  br label %10

10:                                               ; preds = %10, %9
  %11 = phi i8 [ 0, %9 ], [ %17, %10 ]
  %12 = phi i16 [ 0, %9 ], [ %15, %10 ]
  %13 = zext i8 %11 to i16
  %14 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4312), i16 %13
  store i16 256, ptr %14, align 1, !tbaa !2
  %15 = add nuw nsw i16 %12, 1
  %16 = icmp eq i16 %15, 64
  %17 = add nuw i8 %11, 2
  br i1 %16, label %18, label %10, !llvm.loop !30

18:                                               ; preds = %10
  store i8 3, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %19 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %20 = icmp eq i8 %19, 0
  br i1 %20, label %22, label %21

21:                                               ; preds = %18
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %22

22:                                               ; preds = %21, %18
  %23 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %24 = icmp ult i8 %23, 4
  br i1 %24, label %25, label %29

25:                                               ; preds = %22
  %26 = zext nneg i8 %23 to i16
  %27 = add nuw nsw i8 %23, 1
  store i8 %27, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %28 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %26
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr %28, align 1, !tbaa !35
  br label %29

29:                                               ; preds = %25, %22
  tail call void @_canvas_reserve(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr nonnull poison) #13, !inline_history !37
  %30 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %31 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !39
  %32 = or i8 %31, %30
  store i8 %32, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %32, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %33 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %34 = icmp eq i8 %33, 0
  br i1 %34, label %36, label %35

35:                                               ; preds = %29
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %36

36:                                               ; preds = %35, %29
  %37 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %38 = icmp ult i8 %37, 4
  br i1 %38, label %39, label %43

39:                                               ; preds = %36
  %40 = zext nneg i8 %37 to i16
  %41 = add nuw nsw i8 %37, 1
  store i8 %41, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %42 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %40
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr %42, align 1, !tbaa !35
  br label %43

43:                                               ; preds = %39, %36
  %44 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !40
  %45 = load ptr, ptr %44, align 1, !tbaa !41
  tail call void %45(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 178)) #13, !inline_history !43
  %46 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %47 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !39
  %48 = or i8 %47, %46
  store i8 %48, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %48, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %49 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %50 = icmp ugt i8 %49, 15
  br i1 %50, label %62, label %51

51:                                               ; preds = %43
  %52 = zext nneg i8 %49 to i16
  %53 = add nuw nsw i8 %49, 1
  store i8 %53, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %54 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %52
  %55 = getelementptr inbounds nuw i8, ptr %54, i16 10
  store i8 1, ptr %55, align 1, !tbaa !45
  store i16 0, ptr %54, align 1, !tbaa !47
  %56 = getelementptr inbounds nuw i8, ptr %54, i16 9
  store i8 0, ptr %56, align 1, !tbaa !48
  %57 = getelementptr inbounds nuw i8, ptr %54, i16 7
  store i8 34, ptr %57, align 1, !tbaa !49
  %58 = getelementptr inbounds nuw i8, ptr %54, i16 8
  store i8 0, ptr %58, align 1, !tbaa !50
  %59 = getelementptr inbounds nuw i8, ptr %54, i16 2
  store i16 ptrtoint (ptr @bg3_pal to i16), ptr %59, align 1, !tbaa !51
  %60 = getelementptr inbounds nuw i8, ptr %54, i16 6
  store i8 0, ptr %60, align 1, !tbaa !52
  %61 = getelementptr inbounds nuw i8, ptr %54, i16 4
  store i16 8, ptr %61, align 1, !tbaa !53
  br label %62

62:                                               ; preds = %51, %43
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4500), align 1, !tbaa !54
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4502), align 1, !tbaa !57
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4504), align 1, !tbaa !58
  br label %83

63:                                               ; preds = %83, %73
  %64 = phi i8 [ %81, %73 ], [ 0, %83 ]
  %65 = phi i8 [ %80, %73 ], [ 0, %83 ]
  %66 = phi i8 [ %79, %73 ], [ 84, %83 ]
  %67 = zext i8 %66 to i16
  %68 = icmp ugt i8 %66, 31
  br i1 %68, label %69, label %73

69:                                               ; preds = %63
  %70 = icmp ult i8 %66, 96
  br i1 %70, label %71, label %73

71:                                               ; preds = %69
  %72 = add nuw nsw i16 %67, 224
  br label %73

73:                                               ; preds = %71, %69, %63
  %74 = phi i16 [ %72, %71 ], [ 256, %69 ], [ 256, %63 ]
  %75 = zext nneg i8 %65 to i16
  %76 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4316), i16 %75
  store i16 %74, ptr %76, align 1, !tbaa !2
  %77 = zext nneg i8 %64 to i16
  %78 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @.str.2, i16 1), i16 %77
  %79 = load i8, ptr %78, align 1, !tbaa !6
  %80 = add nuw nsw i8 %65, 2
  %81 = add nuw nsw i8 %64, 1
  %82 = icmp eq i8 %81, 20
  br i1 %82, label %87, label %63, !llvm.loop !59

83:                                               ; preds = %83, %62
  %84 = phi i8 [ 15, %62 ], [ %85, %83 ]
  tail call fastcc void @paint_row(i8 noundef zeroext %84) #14
  %85 = add nsw i8 %84, -1
  %86 = icmp eq i8 %84, 0
  br i1 %86, label %63, label %83, !llvm.loop !60

87:                                               ; preds = %73
  %88 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %89 = or i8 %88, 1
  store i8 %89, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  store ptr @TITLE_VT, ptr @main.title, align 1, !tbaa !61
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !64
  store ptr @.str, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 3), align 1, !tbaa !65
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 5), align 1, !tbaa !66
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 7), align 1, !tbaa !67
  store i8 12, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 11), align 1, !tbaa !68
  store ptr getelementptr inbounds nuw (i8, ptr @.str.1, i16 13), ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 9), align 1, !tbaa !69
  store i8 12, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 12), align 1, !tbaa !70
  store i16 88, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 13), align 1, !tbaa !71
  store i16 104, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 15), align 1, !tbaa !72
  store i16 32, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 17), align 1, !tbaa !73
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 28), align 1, !tbaa !74
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !75
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !76
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !77
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !78
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !79
  store i16 32767, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 34), align 1, !tbaa !80
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 36), align 1, !tbaa !81
  %90 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %91 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %92 = icmp eq i8 %91, 0
  br i1 %92, label %94, label %93

93:                                               ; preds = %87
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %94

94:                                               ; preds = %93, %87
  %95 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %96 = icmp ult i8 %95, 4
  br i1 %96, label %97, label %101

97:                                               ; preds = %94
  %98 = zext nneg i8 %95 to i16
  %99 = add nuw nsw i8 %95, 1
  store i8 %99, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %100 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %98
  store ptr @main.title, ptr %100, align 1, !tbaa !35
  br label %101

101:                                              ; preds = %97, %94
  tail call void @_title_reserve(ptr noundef nonnull @main.title, ptr nonnull poison) #13, !inline_history !37
  %102 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %103 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %104 = or i8 %103, %102
  store volatile i8 %104, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store i8 %90, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !82
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 2, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 24, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  br label %105

105:                                              ; preds = %133, %101
  %106 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %107 = icmp eq i8 %106, 0
  br i1 %107, label %119, label %108

108:                                              ; preds = %105, %108
  %109 = phi i8 [ %116, %108 ], [ 0, %105 ]
  %110 = zext i8 %109 to i16
  %111 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %110
  %112 = load ptr, ptr %111, align 1, !tbaa !35
  %113 = load ptr, ptr %112, align 1, !tbaa !40
  %114 = getelementptr inbounds nuw i8, ptr %113, i16 2
  %115 = load ptr, ptr %114, align 1, !tbaa !83
  tail call void %115(ptr noundef nonnull %112, ptr noundef nonnull @main.a) #13, !inline_history !84
  %116 = add nuw i8 %109, 1
  %117 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %118 = icmp ult i8 %116, %117
  br i1 %118, label %108, label %119, !llvm.loop !85

119:                                              ; preds = %108, %105
  %120 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %121

121:                                              ; preds = %121, %119
  %122 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %123 = icmp sgt i8 %122, -1
  br i1 %123, label %121, label %124, !llvm.loop !86

124:                                              ; preds = %121
  tail call fastcc void @upq_flush() #14
  %125 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %126 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %127 = icmp ult i8 %125, %126
  br i1 %127, label %130, label %128

128:                                              ; preds = %124
  %129 = icmp ugt i8 %125, %126
  br i1 %129, label %130, label %133

130:                                              ; preds = %128, %124
  %131 = phi i8 [ 1, %124 ], [ -1, %128 ]
  %132 = add i8 %131, %125
  store i8 %132, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %133

133:                                              ; preds = %130, %128
  %134 = phi i8 [ %125, %128 ], [ %132, %130 ]
  %135 = and i8 %134, 15
  store volatile i8 %135, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %136 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %137 = icmp eq i8 %136, 15
  br i1 %137, label %138, label %105, !llvm.loop !87

138:                                              ; preds = %133
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !78
  %139 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !79
  %140 = icmp eq i8 %139, -1
  br i1 %140, label %178, label %141

141:                                              ; preds = %138, %170
  %142 = phi i8 [ %173, %170 ], [ 0, %138 ]
  %143 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %144 = icmp eq i8 %143, 0
  br i1 %144, label %156, label %145

145:                                              ; preds = %141, %145
  %146 = phi i8 [ %153, %145 ], [ 0, %141 ]
  %147 = zext i8 %146 to i16
  %148 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %147
  %149 = load ptr, ptr %148, align 1, !tbaa !35
  %150 = load ptr, ptr %149, align 1, !tbaa !40
  %151 = getelementptr inbounds nuw i8, ptr %150, i16 2
  %152 = load ptr, ptr %151, align 1, !tbaa !83
  tail call void %152(ptr noundef nonnull %149, ptr noundef nonnull @main.a) #13, !inline_history !88
  %153 = add nuw i8 %146, 1
  %154 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %155 = icmp ult i8 %153, %154
  br i1 %155, label %145, label %156, !llvm.loop !85

156:                                              ; preds = %145, %141
  %157 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %158

158:                                              ; preds = %158, %156
  %159 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %160 = icmp sgt i8 %159, -1
  br i1 %160, label %158, label %161, !llvm.loop !86

161:                                              ; preds = %158
  tail call fastcc void @upq_flush() #14
  %162 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %163 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %164 = icmp ult i8 %162, %163
  br i1 %164, label %167, label %165

165:                                              ; preds = %161
  %166 = icmp ugt i8 %162, %163
  br i1 %166, label %167, label %170

167:                                              ; preds = %165, %161
  %168 = phi i8 [ 1, %161 ], [ -1, %165 ]
  %169 = add i8 %168, %162
  store i8 %169, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %170

170:                                              ; preds = %167, %165
  %171 = phi i8 [ %162, %165 ], [ %169, %167 ]
  %172 = and i8 %171, 15
  store volatile i8 %172, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %173 = add nuw i8 %142, 1
  %174 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !79
  %175 = icmp ne i8 %174, -1
  %176 = icmp ult i8 %142, -57
  %177 = select i1 %175, i1 %176, i1 false
  br i1 %177, label %141, label %178, !llvm.loop !89

178:                                              ; preds = %170, %138
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !78
  br label %179

179:                                              ; preds = %370, %178
  %180 = phi i16 [ 0, %178 ], [ %371, %370 ]
  %181 = phi i16 [ 0, %178 ], [ %372, %370 ]
  %182 = mul nuw nsw i16 %181, 7
  %183 = zext nneg i16 %182 to i32
  %184 = add nuw nsw i32 %183, -1966126
  br label %185

185:                                              ; preds = %185, %179
  %186 = phi i8 [ 0, %179 ], [ %195, %185 ]
  %187 = phi i16 [ 0, %179 ], [ %193, %185 ]
  %188 = zext nneg i16 %187 to i32
  %189 = mul i32 %188, 196611
  %190 = add i32 %184, %189
  %191 = zext nneg i8 %186 to i16
  %192 = getelementptr i8, ptr @_tm_l32, i16 %191
  store i32 %190, ptr %192, align 1, !tbaa !90
  %193 = add nuw nsw i16 %187, 1
  %194 = icmp eq i16 %193, 20
  %195 = add nuw nsw i8 %186, 4
  br i1 %194, label %196, label %185, !llvm.loop !92

196:                                              ; preds = %185
  %197 = sub i32 -1310724, %183
  br label %198

198:                                              ; preds = %196, %198
  %199 = phi i8 [ %208, %198 ], [ 0, %196 ]
  %200 = phi i16 [ %206, %198 ], [ 0, %196 ]
  %201 = zext nneg i16 %200 to i32
  %202 = mul nuw i32 %201, 131074
  %203 = add i32 %202, %197
  %204 = zext nneg i8 %199 to i16
  %205 = getelementptr i8, ptr @_tm_r32, i16 %204
  store i32 %203, ptr %205, align 1, !tbaa !90
  %206 = add nuw nsw i16 %200, 1
  %207 = icmp eq i16 %206, 20
  %208 = add nuw nsw i8 %199, 4
  br i1 %207, label %209, label %198, !llvm.loop !92

209:                                              ; preds = %198, %235
  %210 = phi i16 [ %238, %235 ], [ 0, %198 ]
  %211 = phi i16 [ %237, %235 ], [ 0, %198 ]
  %212 = phi i16 [ %236, %235 ], [ 0, %198 ]
  %213 = getelementptr inbounds nuw [4 x i8], ptr @_tm_l32, i16 %210
  %214 = load i32, ptr %213, align 1, !tbaa !90
  %215 = getelementptr inbounds nuw [4 x i8], ptr @_tm_r32, i16 %212
  %216 = load i32, ptr %215, align 1, !tbaa !90
  %217 = tail call fastcc i16 @tm_cmp32(i32 noundef %214, i32 noundef %216) #14
  %218 = icmp slt i16 %217, 0
  br i1 %218, label %219, label %223

219:                                              ; preds = %209
  %220 = add nuw nsw i16 %210, 1
  %221 = add i16 %211, 1
  %222 = getelementptr inbounds nuw [4 x i8], ptr @_tm_o32, i16 %211
  store i32 %214, ptr %222, align 1, !tbaa !90
  br label %235

223:                                              ; preds = %209
  %224 = icmp eq i16 %217, 0
  br i1 %224, label %229, label %225

225:                                              ; preds = %223
  %226 = add nuw nsw i16 %212, 1
  %227 = add i16 %211, 1
  %228 = getelementptr inbounds nuw [4 x i8], ptr @_tm_o32, i16 %211
  store i32 %216, ptr %228, align 1, !tbaa !90
  br label %235

229:                                              ; preds = %223
  %230 = add nuw nsw i16 %210, 1
  %231 = getelementptr inbounds nuw [4 x i8], ptr @_tm_o32, i16 %211
  store i32 %214, ptr %231, align 1, !tbaa !90
  %232 = add nuw nsw i16 %212, 1
  %233 = add i16 %211, 2
  %234 = getelementptr i8, ptr %231, i16 4
  store i32 %216, ptr %234, align 1, !tbaa !90
  br label %235

235:                                              ; preds = %229, %225, %219
  %236 = phi i16 [ %212, %219 ], [ %226, %225 ], [ %232, %229 ]
  %237 = phi i16 [ %221, %219 ], [ %227, %225 ], [ %233, %229 ]
  %238 = phi i16 [ %220, %219 ], [ %210, %225 ], [ %230, %229 ]
  %239 = icmp ult i16 %238, 20
  %240 = icmp ult i16 %236, 20
  %241 = select i1 %239, i1 %240, i1 false
  br i1 %241, label %209, label %242, !llvm.loop !93

242:                                              ; preds = %235
  %243 = add nsw i32 %183, -16
  %244 = sub nsw i32 16, %183
  br i1 %239, label %245, label %253

245:                                              ; preds = %242
  %246 = shl i16 %237, 2
  %247 = getelementptr i8, ptr @_tm_o32, i16 %246
  %248 = shl nuw nsw i16 %238, 2
  %249 = getelementptr i8, ptr @_tm_l32, i16 %248
  %250 = sub nuw nsw i16 80, %248
  tail call void @llvm.memcpy.p0.p0.i16(ptr align 1 %247, ptr align 1 %249, i16 %250, i1 false), !tbaa !90
  %251 = add i16 %237, 20
  %252 = sub i16 %251, %238
  br label %253

253:                                              ; preds = %245, %242
  %254 = phi i16 [ %237, %242 ], [ %252, %245 ]
  br i1 %240, label %255, label %266

255:                                              ; preds = %253
  %256 = shl i16 %254, 2
  %257 = getelementptr i8, ptr @_tm_o32, i16 %256
  %258 = shl nuw nsw i16 %236, 2
  %259 = getelementptr i8, ptr @_tm_r32, i16 %258
  %260 = sub nuw nsw i16 80, %258
  tail call void @llvm.memcpy.p0.p0.i16(ptr align 1 %257, ptr align 1 %259, i16 %260, i1 false), !tbaa !90
  %261 = tail call i16 @llvm.umax.i16(i16 %238, i16 20)
  %262 = add i16 %237, 20
  %263 = add i16 %236, %238
  %264 = sub i16 %262, %263
  %265 = add i16 %264, %261
  br label %266

266:                                              ; preds = %255, %253
  %267 = phi i16 [ %254, %253 ], [ %265, %255 ]
  %268 = icmp eq i16 %267, 0
  br i1 %268, label %269, label %358

269:                                              ; preds = %358, %266
  %270 = phi i16 [ %180, %266 ], [ %367, %358 ]
  %271 = sext i32 %243 to i64
  br label %272

272:                                              ; preds = %272, %269
  %273 = phi i8 [ 0, %269 ], [ %284, %272 ]
  %274 = phi i16 [ 0, %269 ], [ %282, %272 ]
  %275 = zext nneg i16 %274 to i32
  %276 = add nsw i32 %275, -10
  %277 = sext i32 %276 to i64
  %278 = mul i64 %277, 844437815230467
  %279 = add nsw i64 %278, %271
  %280 = zext i8 %273 to i16
  %281 = getelementptr i8, ptr @_tm_l64, i16 %280
  store i64 %279, ptr %281, align 8, !tbaa !94
  %282 = add nuw nsw i16 %274, 1
  %283 = icmp eq i16 %282, 20
  %284 = add nuw i8 %273, 8
  br i1 %283, label %285, label %272, !llvm.loop !96

285:                                              ; preds = %272
  %286 = sext i32 %244 to i64
  br label %287

287:                                              ; preds = %287, %285
  %288 = phi i8 [ 0, %285 ], [ %299, %287 ]
  %289 = phi i16 [ 0, %285 ], [ %297, %287 ]
  %290 = zext nneg i16 %289 to i32
  %291 = add nsw i32 %290, -10
  %292 = sext i32 %291 to i64
  %293 = mul i64 %292, 562958543486978
  %294 = add nsw i64 %293, %286
  %295 = zext i8 %288 to i16
  %296 = getelementptr i8, ptr @_tm_r64, i16 %295
  store i64 %294, ptr %296, align 8, !tbaa !94
  %297 = add nuw nsw i16 %289, 1
  %298 = icmp eq i16 %297, 20
  %299 = add nuw i8 %288, 8
  br i1 %298, label %300, label %287, !llvm.loop !96

300:                                              ; preds = %287, %326
  %301 = phi i16 [ %329, %326 ], [ 0, %287 ]
  %302 = phi i16 [ %328, %326 ], [ 0, %287 ]
  %303 = phi i16 [ %327, %326 ], [ 0, %287 ]
  %304 = getelementptr inbounds nuw [8 x i8], ptr @_tm_l64, i16 %301
  %305 = load i64, ptr %304, align 8, !tbaa !94
  %306 = getelementptr inbounds nuw [8 x i8], ptr @_tm_r64, i16 %303
  %307 = load i64, ptr %306, align 8, !tbaa !94
  %308 = tail call fastcc i16 @tm_cmp64(i64 noundef %305, i64 noundef %307) #14
  %309 = icmp slt i16 %308, 0
  br i1 %309, label %310, label %314

310:                                              ; preds = %300
  %311 = add nuw nsw i16 %301, 1
  %312 = add i16 %302, 1
  %313 = getelementptr inbounds nuw [8 x i8], ptr @_tm_o64, i16 %302
  store i64 %305, ptr %313, align 8, !tbaa !94
  br label %326

314:                                              ; preds = %300
  %315 = icmp eq i16 %308, 0
  br i1 %315, label %320, label %316

316:                                              ; preds = %314
  %317 = add nuw nsw i16 %303, 1
  %318 = add i16 %302, 1
  %319 = getelementptr inbounds nuw [8 x i8], ptr @_tm_o64, i16 %302
  store i64 %307, ptr %319, align 8, !tbaa !94
  br label %326

320:                                              ; preds = %314
  %321 = add nuw nsw i16 %301, 1
  %322 = getelementptr inbounds nuw [8 x i8], ptr @_tm_o64, i16 %302
  store i64 %305, ptr %322, align 8, !tbaa !94
  %323 = add nuw nsw i16 %303, 1
  %324 = add i16 %302, 2
  %325 = getelementptr i8, ptr %322, i16 8
  store i64 %307, ptr %325, align 8, !tbaa !94
  br label %326

326:                                              ; preds = %320, %316, %310
  %327 = phi i16 [ %303, %310 ], [ %317, %316 ], [ %323, %320 ]
  %328 = phi i16 [ %312, %310 ], [ %318, %316 ], [ %324, %320 ]
  %329 = phi i16 [ %311, %310 ], [ %301, %316 ], [ %321, %320 ]
  %330 = icmp ult i16 %329, 20
  %331 = icmp ult i16 %327, 20
  %332 = select i1 %330, i1 %331, i1 false
  br i1 %332, label %300, label %333, !llvm.loop !97

333:                                              ; preds = %326
  br i1 %330, label %334, label %342

334:                                              ; preds = %333
  %335 = shl i16 %328, 3
  %336 = getelementptr i8, ptr @_tm_o64, i16 %335
  %337 = shl nuw nsw i16 %329, 3
  %338 = getelementptr i8, ptr @_tm_l64, i16 %337
  %339 = sub nuw nsw i16 160, %337
  tail call void @llvm.memcpy.p0.p0.i16(ptr align 8 %336, ptr align 8 %338, i16 %339, i1 false), !tbaa !94
  %340 = add i16 %328, 20
  %341 = sub i16 %340, %329
  br label %342

342:                                              ; preds = %334, %333
  %343 = phi i16 [ %328, %333 ], [ %341, %334 ]
  br i1 %331, label %344, label %355

344:                                              ; preds = %342
  %345 = shl i16 %343, 3
  %346 = getelementptr i8, ptr @_tm_o64, i16 %345
  %347 = shl nuw nsw i16 %327, 3
  %348 = getelementptr i8, ptr @_tm_r64, i16 %347
  %349 = sub nuw nsw i16 160, %347
  tail call void @llvm.memcpy.p0.p0.i16(ptr align 8 %346, ptr align 8 %348, i16 %349, i1 false), !tbaa !94
  %350 = tail call i16 @llvm.umax.i16(i16 %329, i16 20)
  %351 = add i16 %328, 20
  %352 = add i16 %327, %329
  %353 = sub i16 %351, %352
  %354 = add i16 %353, %350
  br label %355

355:                                              ; preds = %344, %342
  %356 = phi i16 [ %343, %342 ], [ %354, %344 ]
  %357 = icmp eq i16 %356, 0
  br i1 %357, label %370, label %374

358:                                              ; preds = %266, %358
  %359 = phi i16 [ %367, %358 ], [ %180, %266 ]
  %360 = phi i16 [ %368, %358 ], [ 0, %266 ]
  %361 = getelementptr inbounds nuw [4 x i8], ptr @_tm_o32, i16 %360
  %362 = load i32, ptr %361, align 1, !tbaa !90
  %363 = lshr i32 %362, 16
  %364 = xor i32 %363, %362
  %365 = trunc i32 %364 to i16
  %366 = tail call i16 @llvm.fshl.i16(i16 %359, i16 %359, i16 1)
  %367 = xor i16 %366, %365
  %368 = add nuw i16 %360, 1
  %369 = icmp eq i16 %368, %267
  br i1 %369, label %269, label %358, !llvm.loop !98

370:                                              ; preds = %374, %355
  %371 = phi i16 [ %270, %355 ], [ %387, %374 ]
  %372 = add nuw nsw i16 %181, 1
  %373 = icmp eq i16 %372, 8
  br i1 %373, label %390, label %179, !llvm.loop !99

374:                                              ; preds = %355, %374
  %375 = phi i16 [ %387, %374 ], [ %270, %355 ]
  %376 = phi i16 [ %388, %374 ], [ 0, %355 ]
  %377 = getelementptr inbounds nuw [8 x i8], ptr @_tm_o64, i16 %376
  %378 = load i64, ptr %377, align 8, !tbaa !94
  %379 = lshr i64 %378, 16
  %380 = lshr i64 %378, 32
  %381 = lshr i64 %378, 48
  %382 = xor i64 %379, %380
  %383 = xor i64 %382, %381
  %384 = xor i64 %383, %378
  %385 = trunc i64 %384 to i16
  %386 = tail call i16 @llvm.fshl.i16(i16 %375, i16 %375, i16 1)
  %387 = xor i16 %386, %385
  %388 = add nuw i16 %376, 1
  %389 = icmp eq i16 %388, %356
  br i1 %389, label %370, label %374, !llvm.loop !100

390:                                              ; preds = %370
  store volatile i16 %371, ptr @corpus_result, align 1, !tbaa !2
  br label %391

391:                                              ; preds = %421, %390
  %392 = phi i16 [ 90, %390 ], [ %393, %421 ]
  %393 = add nsw i16 %392, -1
  %394 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %395 = icmp eq i8 %394, 0
  br i1 %395, label %407, label %396

396:                                              ; preds = %391, %396
  %397 = phi i8 [ %404, %396 ], [ 0, %391 ]
  %398 = zext i8 %397 to i16
  %399 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %398
  %400 = load ptr, ptr %399, align 1, !tbaa !35
  %401 = load ptr, ptr %400, align 1, !tbaa !40
  %402 = getelementptr inbounds nuw i8, ptr %401, i16 2
  %403 = load ptr, ptr %402, align 1, !tbaa !83
  tail call void %403(ptr noundef nonnull %400, ptr noundef nonnull @main.a) #13, !inline_history !101
  %404 = add nuw i8 %397, 1
  %405 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %406 = icmp ult i8 %404, %405
  br i1 %406, label %396, label %407, !llvm.loop !85

407:                                              ; preds = %396, %391
  %408 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %409

409:                                              ; preds = %409, %407
  %410 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %411 = icmp sgt i8 %410, -1
  br i1 %411, label %409, label %412, !llvm.loop !86

412:                                              ; preds = %409
  tail call fastcc void @upq_flush() #14
  %413 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %414 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %415 = icmp ult i8 %413, %414
  br i1 %415, label %418, label %416

416:                                              ; preds = %412
  %417 = icmp ugt i8 %413, %414
  br i1 %417, label %418, label %421

418:                                              ; preds = %416, %412
  %419 = phi i8 [ 1, %412 ], [ -1, %416 ]
  %420 = add i8 %419, %413
  store i8 %420, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %421

421:                                              ; preds = %418, %416
  %422 = phi i8 [ %413, %416 ], [ %420, %418 ]
  %423 = and i8 %422, 15
  store volatile i8 %423, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %424 = icmp eq i16 %393, 0
  br i1 %424, label %425, label %391, !llvm.loop !102

425:                                              ; preds = %421
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !76
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !77
  br label %429

426:                                              ; preds = %458
  %427 = add nuw nsw i8 %430, 1
  %428 = icmp eq i8 %427, 90
  br i1 %428, label %463, label %429, !llvm.loop !103

429:                                              ; preds = %426, %425
  %430 = phi i8 [ 0, %425 ], [ %427, %426 ]
  %431 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %432 = icmp eq i8 %431, 0
  br i1 %432, label %444, label %433

433:                                              ; preds = %429, %433
  %434 = phi i8 [ %441, %433 ], [ 0, %429 ]
  %435 = zext i8 %434 to i16
  %436 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %435
  %437 = load ptr, ptr %436, align 1, !tbaa !35
  %438 = load ptr, ptr %437, align 1, !tbaa !40
  %439 = getelementptr inbounds nuw i8, ptr %438, i16 2
  %440 = load ptr, ptr %439, align 1, !tbaa !83
  tail call void %440(ptr noundef nonnull %437, ptr noundef nonnull @main.a) #13, !inline_history !104
  %441 = add nuw i8 %434, 1
  %442 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %443 = icmp ult i8 %441, %442
  br i1 %443, label %433, label %444, !llvm.loop !85

444:                                              ; preds = %433, %429
  %445 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %446

446:                                              ; preds = %446, %444
  %447 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %448 = icmp sgt i8 %447, -1
  br i1 %448, label %446, label %449, !llvm.loop !86

449:                                              ; preds = %446
  tail call fastcc void @upq_flush() #14
  %450 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %451 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %452 = icmp ult i8 %450, %451
  br i1 %452, label %455, label %453

453:                                              ; preds = %449
  %454 = icmp ugt i8 %450, %451
  br i1 %454, label %455, label %458

455:                                              ; preds = %453, %449
  %456 = phi i8 [ 1, %449 ], [ -1, %453 ]
  %457 = add i8 %456, %450
  store i8 %457, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %458

458:                                              ; preds = %455, %453
  %459 = phi i8 [ %450, %453 ], [ %457, %455 ]
  %460 = and i8 %459, 15
  store volatile i8 %460, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %461 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 19), align 1, !tbaa !105
  %462 = icmp sgt i16 %461, 3583
  br i1 %462, label %463, label %426

463:                                              ; preds = %458, %426
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !76
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %464 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %465 = icmp eq i8 %464, 0
  br i1 %465, label %499, label %466

466:                                              ; preds = %463, %494
  %467 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %468 = icmp eq i8 %467, 0
  br i1 %468, label %480, label %469

469:                                              ; preds = %466, %469
  %470 = phi i8 [ %477, %469 ], [ 0, %466 ]
  %471 = zext i8 %470 to i16
  %472 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %471
  %473 = load ptr, ptr %472, align 1, !tbaa !35
  %474 = load ptr, ptr %473, align 1, !tbaa !40
  %475 = getelementptr inbounds nuw i8, ptr %474, i16 2
  %476 = load ptr, ptr %475, align 1, !tbaa !83
  tail call void %476(ptr noundef nonnull %473, ptr noundef nonnull @main.a) #13, !inline_history !106
  %477 = add nuw i8 %470, 1
  %478 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %479 = icmp ult i8 %477, %478
  br i1 %479, label %469, label %480, !llvm.loop !85

480:                                              ; preds = %469, %466
  %481 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %482

482:                                              ; preds = %482, %480
  %483 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %484 = icmp sgt i8 %483, -1
  br i1 %484, label %482, label %485, !llvm.loop !86

485:                                              ; preds = %482
  tail call fastcc void @upq_flush() #14
  %486 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %487 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %488 = icmp ult i8 %486, %487
  br i1 %488, label %491, label %489

489:                                              ; preds = %485
  %490 = icmp ugt i8 %486, %487
  br i1 %490, label %491, label %494

491:                                              ; preds = %489, %485
  %492 = phi i8 [ 1, %485 ], [ -1, %489 ]
  %493 = add i8 %492, %486
  store i8 %493, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %494

494:                                              ; preds = %491, %489
  %495 = phi i8 [ %486, %489 ], [ %493, %491 ]
  %496 = and i8 %495, 15
  store volatile i8 %496, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %497 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %498 = icmp eq i8 %497, 0
  br i1 %498, label %499, label %466, !llvm.loop !87

499:                                              ; preds = %494, %463
  %500 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !82
  %501 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %502 = or i8 %501, %500
  %503 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %504 = xor i8 %503, -1
  %505 = and i8 %502, %504
  store i8 %505, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %505, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !75
  %506 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %507 = icmp ugt i8 %506, 15
  br i1 %507, label %519, label %508

508:                                              ; preds = %499
  %509 = zext nneg i8 %506 to i16
  %510 = add nuw nsw i8 %506, 1
  store i8 %510, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %511 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %509
  %512 = getelementptr inbounds nuw i8, ptr %511, i16 10
  store i8 1, ptr %512, align 1, !tbaa !45
  store i16 0, ptr %511, align 1, !tbaa !47
  %513 = getelementptr inbounds nuw i8, ptr %511, i16 9
  store i8 0, ptr %513, align 1, !tbaa !48
  %514 = getelementptr inbounds nuw i8, ptr %511, i16 7
  store i8 34, ptr %514, align 1, !tbaa !49
  %515 = getelementptr inbounds nuw i8, ptr %511, i16 8
  store i8 0, ptr %515, align 1, !tbaa !50
  %516 = getelementptr inbounds nuw i8, ptr %511, i16 2
  store i16 ptrtoint (ptr @title_end._title_bg_black to i16), ptr %516, align 1, !tbaa !51
  %517 = getelementptr inbounds nuw i8, ptr %511, i16 6
  store i8 0, ptr %517, align 1, !tbaa !52
  %518 = getelementptr inbounds nuw i8, ptr %511, i16 4
  store i16 2, ptr %518, align 1, !tbaa !53
  br label %519

519:                                              ; preds = %499, %508
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  tail call fastcc void @build_bands(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 4441)) #14
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4491), align 1, !tbaa !107
  store volatile i8 2, ptr inttoptr (i16 17248 to ptr), align 32, !tbaa !6
  store volatile i8 18, ptr inttoptr (i16 17249 to ptr), align 1, !tbaa !6
  store volatile i8 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441) to i8), ptr inttoptr (i16 17250 to ptr), align 2, !tbaa !6
  %520 = lshr i16 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441) to i16), 8
  %521 = trunc nuw i16 %520 to i8
  store volatile i8 %521, ptr inttoptr (i16 17251 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17252 to ptr), align 4, !tbaa !6
  store volatile i8 3, ptr inttoptr (i16 17264 to ptr), align 16, !tbaa !6
  store volatile i8 33, ptr inttoptr (i16 17265 to ptr), align 1, !tbaa !6
  store volatile i8 ptrtoint (ptr @grad_tab to i8), ptr inttoptr (i16 17266 to ptr), align 2, !tbaa !6
  %522 = lshr i16 ptrtoint (ptr @grad_tab to i16), 8
  %523 = trunc nuw i16 %522 to i8
  store volatile i8 %523, ptr inttoptr (i16 17267 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17268 to ptr), align 4, !tbaa !6
  store volatile i8 -64, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  %524 = getelementptr inbounds nuw i8, ptr %1, i16 1
  %525 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %526 = getelementptr inbounds nuw i8, ptr %1, i16 3
  %527 = getelementptr inbounds nuw i8, ptr %1, i16 4
  %528 = getelementptr inbounds nuw i8, ptr %1, i16 5
  %529 = getelementptr inbounds nuw i8, ptr %1, i16 6
  %530 = getelementptr inbounds nuw i8, ptr %1, i16 7
  %531 = getelementptr inbounds nuw i8, ptr %1, i16 8
  %532 = getelementptr inbounds nuw i8, ptr %1, i16 9
  %533 = getelementptr inbounds nuw i8, ptr %1, i16 10
  %534 = getelementptr inbounds nuw i8, ptr %1, i16 11
  %535 = getelementptr inbounds nuw i8, ptr %1, i16 12
  %536 = getelementptr inbounds nuw i8, ptr %1, i16 13
  %537 = getelementptr inbounds nuw i8, ptr %1, i16 14
  %538 = getelementptr inbounds nuw i8, ptr %1, i16 15
  %539 = getelementptr inbounds nuw i8, ptr %1, i16 20
  br label %540

540:                                              ; preds = %718, %519
  %541 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4491), align 1, !tbaa !107
  %542 = xor i8 %541, 1
  %543 = zext i8 %542 to i16
  %544 = getelementptr inbounds nuw [25 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %543
  tail call fastcc void @build_bands(ptr noundef nonnull %544) #14
  %545 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %546 = icmp ugt i8 %545, 15
  br i1 %546, label %559, label %547

547:                                              ; preds = %540
  %548 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4491), align 1, !tbaa !107
  %549 = xor i8 %548, 1
  %550 = zext i8 %549 to i16
  %551 = getelementptr inbounds nuw [25 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %550
  %552 = ptrtoint ptr %551 to i16
  %553 = zext nneg i8 %545 to i16
  %554 = add nuw nsw i8 %545, 1
  store i8 %554, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %555 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %553
  %556 = getelementptr inbounds nuw i8, ptr %555, i16 10
  store i8 4, ptr %556, align 1, !tbaa !45
  store i16 17250, ptr %555, align 1, !tbaa !47
  %557 = getelementptr inbounds nuw i8, ptr %555, i16 2
  store i16 %552, ptr %557, align 1, !tbaa !51
  %558 = getelementptr inbounds nuw i8, ptr %555, i16 4
  store i16 0, ptr %558, align 1, !tbaa !53
  store i8 %549, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4491), align 1, !tbaa !107
  br label %559

559:                                              ; preds = %540, %547
  %560 = phi i8 [ %545, %540 ], [ %554, %547 ]
  %561 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4504), align 1, !tbaa !58
  %562 = and i8 %561, 7
  switch i8 %562, label %683 [
    i8 0, label %563
    i8 4, label %569
  ]

563:                                              ; preds = %559
  %564 = lshr exact i8 %561, 3
  %565 = add nuw nsw i8 %564, 15
  %566 = and i8 %565, 15
  tail call fastcc void @paint_row(i8 noundef zeroext %566) #14
  %567 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4502), align 1, !tbaa !57
  %568 = add i16 %567, 1
  store i16 %568, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4502), align 1, !tbaa !57
  br label %683

569:                                              ; preds = %559
  %570 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4502), align 1, !tbaa !57
  %571 = and i16 %570, 31
  %572 = icmp samesign ult i16 %571, 17
  %573 = trunc nuw nsw i16 %571 to i8
  br i1 %572, label %576, label %574

574:                                              ; preds = %569
  %575 = sub nuw nsw i8 32, %573
  br label %576

576:                                              ; preds = %574, %569
  %577 = phi i8 [ %575, %574 ], [ %573, %569 ]
  %578 = lshr i8 %577, 2
  %579 = add nsw i8 %578, -2
  br label %593

580:                                              ; preds = %618
  %581 = icmp ugt i8 %560, 15
  br i1 %581, label %623, label %582

582:                                              ; preds = %580
  %583 = zext nneg i8 %560 to i16
  %584 = add nuw nsw i8 %560, 1
  store i8 %584, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %585 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %583
  %586 = getelementptr inbounds nuw i8, ptr %585, i16 10
  store i8 1, ptr %586, align 1, !tbaa !45
  store i16 1, ptr %585, align 1, !tbaa !47
  %587 = getelementptr inbounds nuw i8, ptr %585, i16 9
  store i8 0, ptr %587, align 1, !tbaa !48
  %588 = getelementptr inbounds nuw i8, ptr %585, i16 7
  store i8 34, ptr %588, align 1, !tbaa !49
  %589 = getelementptr inbounds nuw i8, ptr %585, i16 8
  store i8 0, ptr %589, align 1, !tbaa !50
  %590 = getelementptr inbounds nuw i8, ptr %585, i16 2
  store i16 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4494) to i16), ptr %590, align 1, !tbaa !51
  %591 = getelementptr inbounds nuw i8, ptr %585, i16 6
  store i8 0, ptr %591, align 1, !tbaa !52
  %592 = getelementptr inbounds nuw i8, ptr %585, i16 4
  store i16 6, ptr %592, align 1, !tbaa !53
  br label %623

593:                                              ; preds = %618, %576
  %594 = phi i8 [ 0, %576 ], [ %622, %618 ]
  %595 = phi i8 [ 1, %576 ], [ %620, %618 ]
  %596 = zext nneg i8 %594 to i16
  %597 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @bg3_pal, i16 2), i16 %596
  %598 = load i16, ptr %597, align 1, !tbaa !2
  br label %599

599:                                              ; preds = %611, %593
  %600 = phi i8 [ 0, %593 ], [ %616, %611 ]
  %601 = phi i16 [ 0, %593 ], [ %615, %611 ]
  %602 = zext nneg i8 %600 to i16
  %603 = lshr i16 %598, %602
  %604 = trunc i16 %603 to i8
  %605 = and i8 %604, 31
  %606 = add nsw i8 %579, %605
  %607 = icmp slt i8 %606, 0
  br i1 %607, label %611, label %608

608:                                              ; preds = %599
  %609 = icmp samesign ugt i8 %606, 31
  br i1 %609, label %610, label %611

610:                                              ; preds = %608
  br label %611

611:                                              ; preds = %610, %608, %599
  %612 = phi i8 [ 31, %610 ], [ %606, %608 ], [ 0, %599 ]
  %613 = zext nneg i8 %612 to i16
  %614 = shl i16 %613, %602
  %615 = or i16 %614, %601
  %616 = add nuw nsw i8 %600, 5
  %617 = icmp samesign ult i8 %600, 10
  br i1 %617, label %599, label %618, !llvm.loop !108

618:                                              ; preds = %611
  %619 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4494), i16 %596
  store i16 %615, ptr %619, align 1, !tbaa !2
  %620 = add nuw nsw i8 %595, 1
  %621 = icmp eq i8 %620, 4
  %622 = add nuw nsw i8 %594, 2
  br i1 %621, label %580, label %593, !llvm.loop !109

623:                                              ; preds = %580, %582
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #15
  store i8 61, ptr %524, align 1, !tbaa !6
  %624 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4502), align 1, !tbaa !57
  %625 = lshr i16 %624, 12
  %626 = getelementptr inbounds nuw i8, ptr @update_hud.H, i16 %625
  %627 = load i8, ptr %626, align 1, !tbaa !6
  store i8 %627, ptr %525, align 1, !tbaa !6
  %628 = lshr i16 %624, 8
  %629 = and i16 %628, 15
  %630 = getelementptr inbounds nuw i8, ptr @update_hud.H, i16 %629
  %631 = load i8, ptr %630, align 1, !tbaa !6
  store i8 %631, ptr %526, align 1, !tbaa !6
  %632 = lshr i16 %624, 4
  %633 = and i16 %632, 15
  %634 = getelementptr inbounds nuw i8, ptr @update_hud.H, i16 %633
  %635 = load i8, ptr %634, align 1, !tbaa !6
  store i8 %635, ptr %527, align 1, !tbaa !6
  %636 = and i16 %624, 15
  %637 = getelementptr inbounds nuw i8, ptr @update_hud.H, i16 %636
  %638 = load i8, ptr %637, align 1, !tbaa !6
  store i8 %638, ptr %528, align 1, !tbaa !6
  store i8 32, ptr %529, align 1, !tbaa !6
  store i8 67, ptr %530, align 1, !tbaa !6
  store i8 82, ptr %531, align 1, !tbaa !6
  store i8 67, ptr %532, align 1, !tbaa !6
  store i8 61, ptr %533, align 1, !tbaa !6
  %639 = load volatile i16, ptr @corpus_result, align 1, !tbaa !2
  %640 = lshr i16 %639, 12
  %641 = getelementptr inbounds nuw i8, ptr @update_hud.H, i16 %640
  %642 = load i8, ptr %641, align 1, !tbaa !6
  store i8 %642, ptr %534, align 1, !tbaa !6
  %643 = load volatile i16, ptr @corpus_result, align 1, !tbaa !2
  %644 = lshr i16 %643, 8
  %645 = and i16 %644, 15
  %646 = getelementptr inbounds nuw i8, ptr @update_hud.H, i16 %645
  %647 = load i8, ptr %646, align 1, !tbaa !6
  store i8 %647, ptr %535, align 1, !tbaa !6
  %648 = load volatile i16, ptr @corpus_result, align 1, !tbaa !2
  %649 = lshr i16 %648, 4
  %650 = and i16 %649, 15
  %651 = getelementptr inbounds nuw i8, ptr @update_hud.H, i16 %650
  %652 = load i8, ptr %651, align 1, !tbaa !6
  store i8 %652, ptr %536, align 1, !tbaa !6
  %653 = load volatile i16, ptr @corpus_result, align 1, !tbaa !2
  %654 = and i16 %653, 15
  %655 = getelementptr inbounds nuw i8, ptr @update_hud.H, i16 %654
  %656 = load i8, ptr %655, align 1, !tbaa !6
  store i8 %656, ptr %537, align 1, !tbaa !6
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %538, i8 32, i64 5, i1 false)
  store i8 0, ptr %539, align 1, !tbaa !6
  br label %662

657:                                              ; preds = %672
  %658 = add nuw nsw i8 %665, 2
  %659 = add nuw nsw i8 %666, 1
  %660 = zext i8 %678 to i16
  %661 = icmp eq i8 %659, 32
  br i1 %661, label %680, label %662, !llvm.loop !59

662:                                              ; preds = %623, %657
  %663 = phi i16 [ 84, %623 ], [ %660, %657 ]
  %664 = phi i8 [ 84, %623 ], [ %678, %657 ]
  %665 = phi i8 [ 0, %623 ], [ %658, %657 ]
  %666 = phi i8 [ 0, %623 ], [ %659, %657 ]
  %667 = icmp ugt i8 %664, 31
  br i1 %667, label %668, label %672

668:                                              ; preds = %662
  %669 = icmp ult i8 %664, 96
  br i1 %669, label %670, label %672

670:                                              ; preds = %668
  %671 = add nuw nsw i16 %663, 224
  br label %672

672:                                              ; preds = %670, %668, %662
  %673 = phi i16 [ %671, %670 ], [ 256, %668 ], [ 256, %662 ]
  %674 = zext nneg i8 %665 to i16
  %675 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4376), i16 %674
  store i16 %673, ptr %675, align 1, !tbaa !2
  %676 = zext nneg i8 %666 to i16
  %677 = getelementptr i8, ptr %524, i16 %676
  %678 = load i8, ptr %677, align 1, !tbaa !6
  %679 = icmp eq i8 %678, 0
  br i1 %679, label %680, label %657, !llvm.loop !59

680:                                              ; preds = %657, %672
  %681 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %682 = or i8 %681, 2
  store i8 %682, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #15
  br label %683

683:                                              ; preds = %559, %680, %563
  %684 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %685 = icmp eq i8 %684, 0
  br i1 %685, label %697, label %686

686:                                              ; preds = %683, %686
  %687 = phi i8 [ %694, %686 ], [ 0, %683 ]
  %688 = zext i8 %687 to i16
  %689 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %688
  %690 = load ptr, ptr %689, align 1, !tbaa !35
  %691 = load ptr, ptr %690, align 1, !tbaa !40
  %692 = getelementptr inbounds nuw i8, ptr %691, i16 2
  %693 = load ptr, ptr %692, align 1, !tbaa !83
  tail call void %693(ptr noundef nonnull %690, ptr noundef nonnull @main.a) #13, !inline_history !110
  %694 = add nuw i8 %687, 1
  %695 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %696 = icmp ult i8 %694, %695
  br i1 %696, label %686, label %697, !llvm.loop !85

697:                                              ; preds = %686, %683
  %698 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %699

699:                                              ; preds = %699, %697
  %700 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %701 = icmp sgt i8 %700, -1
  br i1 %701, label %699, label %702, !llvm.loop !86

702:                                              ; preds = %699
  tail call fastcc void @upq_flush() #14
  %703 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %704 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %705 = icmp ult i8 %703, %704
  br i1 %705, label %708, label %706

706:                                              ; preds = %702
  %707 = icmp ugt i8 %703, %704
  br i1 %707, label %708, label %711

708:                                              ; preds = %706, %702
  %709 = phi i8 [ 1, %702 ], [ -1, %706 ]
  %710 = add i8 %709, %703
  store i8 %710, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %711

711:                                              ; preds = %706, %708
  %712 = phi i8 [ %703, %706 ], [ %710, %708 ]
  %713 = and i8 %712, 15
  store volatile i8 %713, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %714 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4504), align 1, !tbaa !58
  %715 = icmp eq i8 %714, 0
  br i1 %715, label %718, label %716

716:                                              ; preds = %711
  %717 = add i8 %714, -1
  br label %718

718:                                              ; preds = %711, %716
  %719 = phi i8 [ %717, %716 ], [ 127, %711 ]
  store i8 %719, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4504), align 1, !tbaa !58
  br label %540
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(read, argmem: write, inaccessiblemem: none, target_mem: none)
define internal fastcc void @build_bands(ptr noundef writeonly captures(none) initializes((0, 3)) %0) unnamed_addr #1 {
  %2 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4504), align 1, !tbaa !58
  %3 = getelementptr i8, ptr %0, i16 1
  %4 = getelementptr i8, ptr %0, i16 2
  store i8 48, ptr %0, align 1, !tbaa !6
  store i8 0, ptr %3, align 1, !tbaa !6
  store i8 0, ptr %4, align 1, !tbaa !6
  %5 = zext i8 %2 to i16
  %6 = icmp ult i8 %2, 9
  br i1 %6, label %71, label %7

7:                                                ; preds = %1
  %8 = icmp eq i8 %2, -128
  br i1 %8, label %35, label %9

9:                                                ; preds = %7
  %10 = sub i8 -128, %2
  %11 = zext i8 %10 to i16
  %12 = getelementptr i8, ptr %0, i16 3
  %13 = getelementptr i8, ptr %0, i16 4
  %14 = getelementptr i8, ptr %0, i16 5
  br label %18

15:                                               ; preds = %25
  %16 = add nuw nsw i8 %21, 3
  %17 = icmp samesign ult i8 %20, 19
  br i1 %17, label %18, label %35, !llvm.loop !111

18:                                               ; preds = %9, %15
  %19 = phi i16 [ %11, %9 ], [ %33, %15 ]
  %20 = phi i8 [ 3, %9 ], [ %30, %15 ]
  %21 = phi i8 [ 0, %9 ], [ %16, %15 ]
  %22 = icmp ugt i16 %19, 127
  br i1 %22, label %25, label %23

23:                                               ; preds = %18
  %24 = trunc nuw nsw i16 %19 to i8
  br label %25

25:                                               ; preds = %23, %18
  %26 = phi i8 [ %24, %23 ], [ 127, %18 ]
  %27 = zext nneg i8 %21 to i16
  %28 = getelementptr i8, ptr %12, i16 %27
  store i8 %26, ptr %28, align 1, !tbaa !6
  %29 = getelementptr i8, ptr %13, i16 %27
  store i8 %2, ptr %29, align 1, !tbaa !6
  %30 = add nuw nsw i8 %20, 3
  %31 = getelementptr i8, ptr %14, i16 %27
  store i8 0, ptr %31, align 1, !tbaa !6
  %32 = zext nneg i8 %26 to i16
  %33 = sub i16 %19, %32
  %34 = icmp eq i16 %33, 0
  br i1 %34, label %35, label %15, !llvm.loop !111

35:                                               ; preds = %25, %15, %7
  %36 = phi i8 [ 3, %7 ], [ %30, %15 ], [ %30, %25 ]
  %37 = add nsw i16 %5, -128
  %38 = trunc nsw i16 %37 to i8
  %39 = lshr i16 %37, 8
  %40 = trunc nuw i16 %39 to i8
  %41 = zext i8 %36 to i16
  %42 = getelementptr i8, ptr %0, i16 %41
  %43 = getelementptr i8, ptr %0, i16 %41
  %44 = getelementptr i8, ptr %43, i16 1
  %45 = getelementptr i8, ptr %0, i16 %41
  %46 = getelementptr i8, ptr %45, i16 2
  %47 = icmp samesign ult i8 %36, 22
  br i1 %47, label %48, label %92

48:                                               ; preds = %35
  %49 = add i8 %2, -8
  %50 = zext i8 %49 to i16
  br label %54

51:                                               ; preds = %61
  %52 = add nuw nsw i8 %57, 3
  %53 = icmp ult i8 %56, 19
  br i1 %53, label %54, label %92, !llvm.loop !111

54:                                               ; preds = %48, %51
  %55 = phi i16 [ %50, %48 ], [ %69, %51 ]
  %56 = phi i8 [ %36, %48 ], [ %66, %51 ]
  %57 = phi i8 [ 0, %48 ], [ %52, %51 ]
  %58 = icmp ugt i16 %55, 127
  br i1 %58, label %61, label %59

59:                                               ; preds = %54
  %60 = trunc nuw nsw i16 %55 to i8
  br label %61

61:                                               ; preds = %59, %54
  %62 = phi i8 [ %60, %59 ], [ 127, %54 ]
  %63 = zext nneg i8 %57 to i16
  %64 = getelementptr i8, ptr %42, i16 %63
  store i8 %62, ptr %64, align 1, !tbaa !6
  %65 = getelementptr i8, ptr %44, i16 %63
  store i8 %38, ptr %65, align 1, !tbaa !6
  %66 = add nuw nsw i8 %56, 3
  %67 = getelementptr i8, ptr %46, i16 %63
  store i8 %40, ptr %67, align 1, !tbaa !6
  %68 = zext nneg i8 %62 to i16
  %69 = sub i16 %55, %68
  %70 = icmp eq i16 %69, 0
  br i1 %70, label %78, label %51, !llvm.loop !111

71:                                               ; preds = %1
  %72 = getelementptr i8, ptr %0, i16 3
  %73 = getelementptr i8, ptr %0, i16 4
  %74 = getelementptr i8, ptr %0, i16 5
  store i8 120, ptr %72, align 1, !tbaa !6
  store i8 %2, ptr %73, align 1, !tbaa !6
  store i8 0, ptr %74, align 1, !tbaa !6
  %75 = getelementptr i8, ptr %0, i16 6
  %76 = getelementptr i8, ptr %0, i16 7
  %77 = getelementptr i8, ptr %0, i16 8
  br label %86

78:                                               ; preds = %61
  %79 = zext nneg i8 %66 to i16
  %80 = getelementptr i8, ptr %0, i16 %79
  %81 = getelementptr i8, ptr %0, i16 %79
  %82 = getelementptr i8, ptr %81, i16 1
  %83 = getelementptr i8, ptr %0, i16 %79
  %84 = getelementptr i8, ptr %83, i16 2
  %85 = icmp ult i8 %56, 19
  br i1 %85, label %86, label %92

86:                                               ; preds = %71, %78
  %87 = phi ptr [ %77, %71 ], [ %84, %78 ]
  %88 = phi ptr [ %76, %71 ], [ %82, %78 ]
  %89 = phi ptr [ %75, %71 ], [ %80, %78 ]
  %90 = phi i8 [ 6, %71 ], [ %66, %78 ]
  store i8 56, ptr %89, align 1, !tbaa !6
  store i8 8, ptr %88, align 1, !tbaa !6
  %91 = add nuw nsw i8 %90, 3
  store i8 0, ptr %87, align 1, !tbaa !6
  br label %92

92:                                               ; preds = %51, %35, %86, %78
  %93 = phi i8 [ %91, %86 ], [ %66, %78 ], [ %36, %35 ], [ %66, %51 ]
  %94 = zext i8 %93 to i16
  %95 = getelementptr inbounds nuw i8, ptr %0, i16 %94
  store i8 0, ptr %95, align 1, !tbaa !6
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #2

; Function Attrs: nofree norecurse nosync nounwind optsize memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none)
define internal fastcc void @paint_row(i8 noundef zeroext %0) unnamed_addr #3 {
  %2 = alloca [16 x i8], align 1
  %3 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4500), align 1, !tbaa !54
  %4 = and i16 %3, 63
  %5 = zext nneg i16 %4 to i32
  %6 = mul nuw nsw i32 %5, 65537
  %7 = add nsw i32 %6, -4063294
  br label %8

8:                                                ; preds = %8, %1
  %9 = phi i8 [ 0, %1 ], [ %17, %8 ]
  %10 = phi i16 [ 0, %1 ], [ %15, %8 ]
  %11 = phi i32 [ %7, %1 ], [ %14, %8 ]
  %12 = zext nneg i8 %9 to i16
  %13 = getelementptr i8, ptr @_tm_l32, i16 %12
  store i32 %11, ptr %13, align 1, !tbaa !90
  %14 = add nsw i32 %11, 196611
  %15 = add nuw nsw i16 %10, 1
  %16 = icmp eq i16 %15, 20
  %17 = add nuw nsw i8 %9, 4
  br i1 %16, label %18, label %8, !llvm.loop !112

18:                                               ; preds = %8
  %19 = sub nsw i32 786444, %6
  br label %20

20:                                               ; preds = %20, %18
  %21 = phi i8 [ 0, %18 ], [ %29, %20 ]
  %22 = phi i16 [ 0, %18 ], [ %27, %20 ]
  %23 = phi i32 [ %19, %18 ], [ %26, %20 ]
  %24 = zext nneg i8 %21 to i16
  %25 = getelementptr i8, ptr @_tm_r32, i16 %24
  store i32 %23, ptr %25, align 1, !tbaa !90
  %26 = add nsw i32 %23, 131074
  %27 = add nuw nsw i16 %22, 1
  %28 = icmp eq i16 %27, 20
  %29 = add nuw nsw i8 %21, 4
  br i1 %28, label %30, label %20, !llvm.loop !112

30:                                               ; preds = %20
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #15
  br label %31

31:                                               ; preds = %30, %64
  %32 = phi i16 [ 0, %30 ], [ %67, %64 ]
  %33 = phi i16 [ 0, %30 ], [ %66, %64 ]
  %34 = phi i8 [ 0, %30 ], [ %65, %64 ]
  %35 = zext i8 %34 to i16
  %36 = icmp ult i8 %34, 16
  br i1 %36, label %37, label %79

37:                                               ; preds = %31
  %38 = getelementptr inbounds nuw [4 x i8], ptr @_tm_l32, i16 %32
  %39 = load i32, ptr %38, align 1, !tbaa !90
  %40 = getelementptr inbounds nuw [4 x i8], ptr @_tm_r32, i16 %33
  %41 = load i32, ptr %40, align 1, !tbaa !90
  %42 = tail call fastcc i16 @tm_cmp32(i32 noundef %39, i32 noundef %41) #14
  %43 = icmp slt i16 %42, 0
  br i1 %43, label %44, label %48

44:                                               ; preds = %37
  %45 = add nuw nsw i8 %34, 1
  %46 = getelementptr inbounds nuw i8, ptr %2, i16 %35
  store i8 1, ptr %46, align 1, !tbaa !6
  %47 = add nuw nsw i16 %32, 1
  br label %64

48:                                               ; preds = %37
  %49 = icmp eq i16 %42, 0
  br i1 %49, label %54, label %50

50:                                               ; preds = %48
  %51 = add nuw nsw i8 %34, 1
  %52 = getelementptr inbounds nuw i8, ptr %2, i16 %35
  store i8 2, ptr %52, align 1, !tbaa !6
  %53 = add nuw nsw i16 %33, 1
  br label %64

54:                                               ; preds = %48
  %55 = getelementptr inbounds nuw i8, ptr %2, i16 %35
  store i8 3, ptr %55, align 1, !tbaa !6
  %56 = icmp eq i8 %34, 15
  br i1 %56, label %60, label %57

57:                                               ; preds = %54
  %58 = add nuw nsw i8 %34, 2
  %59 = getelementptr inbounds nuw i8, ptr %55, i16 1
  store i8 3, ptr %59, align 1, !tbaa !6
  br label %60

60:                                               ; preds = %57, %54
  %61 = phi i8 [ %58, %57 ], [ 16, %54 ]
  %62 = add nuw nsw i16 %32, 1
  %63 = add nuw nsw i16 %33, 1
  br label %64

64:                                               ; preds = %50, %60, %44
  %65 = phi i8 [ %45, %44 ], [ %51, %50 ], [ %61, %60 ]
  %66 = phi i16 [ %33, %44 ], [ %53, %50 ], [ %63, %60 ]
  %67 = phi i16 [ %47, %44 ], [ %32, %50 ], [ %62, %60 ]
  %68 = icmp ult i16 %67, 20
  %69 = icmp ult i16 %66, 20
  %70 = select i1 %68, i1 %69, i1 false
  br i1 %70, label %31, label %71, !llvm.loop !113

71:                                               ; preds = %64
  %72 = icmp samesign ult i8 %65, 16
  br i1 %72, label %73, label %79

73:                                               ; preds = %71
  %74 = select i1 %68, i8 1, i8 2
  %75 = zext nneg i8 %65 to i16
  %76 = getelementptr i8, ptr %2, i16 %75
  %77 = sub nuw nsw i8 16, %65
  %78 = zext nneg i8 %77 to i16
  call void @llvm.memset.p0.i16(ptr align 1 %76, i8 %74, i16 %78, i1 false), !tbaa !6
  br label %79

79:                                               ; preds = %31, %73, %71
  %80 = zext i8 %0 to i16
  %81 = shl nuw i16 %80, 8
  %82 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %81
  %83 = getelementptr i8, ptr @main.a, i16 %81
  %84 = getelementptr i8, ptr %83, i16 200
  %85 = getelementptr i8, ptr @main.a, i16 %81
  %86 = getelementptr i8, ptr %85, i16 215
  %87 = getelementptr i8, ptr @main.a, i16 %81
  %88 = getelementptr i8, ptr %87, i16 216
  br label %94

89:                                               ; preds = %115
  %90 = shl nuw nsw i16 %80, 4
  %91 = or disjoint i16 %90, 15
  %92 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !114
  %93 = icmp ugt i16 %92, %90
  br i1 %93, label %122, label %123

94:                                               ; preds = %79, %115
  %95 = phi i8 [ 0, %79 ], [ %121, %115 ]
  %96 = phi ptr [ %84, %79 ], [ %119, %115 ]
  %97 = phi ptr [ %82, %79 ], [ %118, %115 ]
  %98 = phi i8 [ 0, %79 ], [ %117, %115 ]
  %99 = zext nneg i8 %98 to i16
  %100 = getelementptr i8, ptr %2, i16 %99
  %101 = load i8, ptr %100, align 1, !tbaa !6
  %102 = and i8 %101, 1
  %103 = sub nsw i8 0, %102
  %104 = shl i8 %101, 6
  %105 = ashr i8 %104, 7
  br label %106

106:                                              ; preds = %106, %94
  %107 = phi i8 [ 0, %94 ], [ %114, %106 ]
  %108 = phi i8 [ 0, %94 ], [ %112, %106 ]
  %109 = zext nneg i8 %107 to i16
  %110 = getelementptr i8, ptr %97, i16 %109
  store i8 %103, ptr %110, align 1, !tbaa !6
  %111 = getelementptr i8, ptr %96, i16 %109
  store i8 %105, ptr %111, align 1, !tbaa !6
  %112 = add nuw nsw i8 %108, 1
  %113 = icmp eq i8 %112, 8
  %114 = add nuw nsw i8 %107, 2
  br i1 %113, label %115, label %106, !llvm.loop !115

115:                                              ; preds = %106
  %116 = zext i8 %95 to i16
  %117 = add nuw nsw i8 %98, 1
  %118 = getelementptr i8, ptr %86, i16 %116
  %119 = getelementptr i8, ptr %88, i16 %116
  %120 = icmp eq i8 %117, 16
  %121 = add i8 %95, 16
  br i1 %120, label %89, label %94, !llvm.loop !116

122:                                              ; preds = %89
  store i16 %90, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !114
  br label %123

123:                                              ; preds = %122, %89
  %124 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !117
  %125 = icmp ult i16 %124, %91
  br i1 %125, label %126, label %127

126:                                              ; preds = %123
  store i16 %91, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !117
  br label %127

127:                                              ; preds = %126, %123
  %128 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4500), align 1, !tbaa !54
  %129 = add i16 %128, 1
  store i16 %129, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4500), align 1, !tbaa !54
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #15
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #2

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_canvas_reserve(ptr noundef readonly captures(none) %0, ptr readnone captures(none) %1) #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4105
  %4 = load i16, ptr %3, align 1, !tbaa !21
  %5 = lshr i16 %4, 8
  %6 = trunc nuw i16 %5 to i8
  %7 = and i8 %6, -4
  store volatile i8 %7, ptr inttoptr (i16 8457 to ptr), align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %9 = load i16, ptr %8, align 1, !tbaa !20
  %10 = lshr i16 %9, 12
  %11 = trunc nuw nsw i16 %10 to i8
  store volatile i8 %11, ptr inttoptr (i16 8460 to ptr), align 4, !tbaa !6
  %12 = load i16, ptr %8, align 1, !tbaa !20
  %13 = lshr i16 %12, 3
  %14 = add nuw nsw i16 %13, 256
  %15 = load i16, ptr %3, align 1, !tbaa !21
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %15, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %16 = getelementptr inbounds nuw i8, ptr %0, i16 4107
  %17 = load i8, ptr %16, align 1, !tbaa !22
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 4108
  br label %19

19:                                               ; preds = %2, %23
  %20 = phi i8 [ 0, %2 ], [ %24, %23 ]
  br label %26

21:                                               ; preds = %23
  %22 = load i16, ptr %8, align 1, !tbaa !20
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %22, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %45

23:                                               ; preds = %40
  %24 = add nuw nsw i8 %20, 1
  %25 = icmp eq i8 %24, 32
  br i1 %25, label %21, label %19, !llvm.loop !118

26:                                               ; preds = %19, %40
  %27 = phi i8 [ 0, %19 ], [ %42, %40 ]
  %28 = sub i8 %27, %17
  %29 = zext i8 %28 to i16
  %30 = icmp ult i8 %28, 16
  br i1 %30, label %31, label %40

31:                                               ; preds = %26
  %32 = load i8, ptr %18, align 1, !tbaa !23
  %33 = sub i8 %20, %32
  %34 = icmp ult i8 %33, 16
  br i1 %34, label %35, label %40

35:                                               ; preds = %31
  %36 = shl nuw i8 %33, 4
  %37 = zext i8 %36 to i16
  %38 = add nuw nsw i16 %13, %29
  %39 = add nuw nsw i16 %38, %37
  br label %40

40:                                               ; preds = %26, %31, %35
  %41 = phi i16 [ %39, %35 ], [ %14, %31 ], [ %14, %26 ]
  store volatile i16 %41, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %42 = add nuw nsw i8 %27, 1
  %43 = icmp eq i8 %42, 32
  br i1 %43, label %23, label %26, !llvm.loop !119

44:                                               ; preds = %45
  ret void

45:                                               ; preds = %21, %45
  %46 = phi i16 [ 0, %21 ], [ %47, %45 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %47 = add nuw nsw i16 %46, 1
  %48 = icmp eq i16 %47, 2056
  br i1 %48, label %44, label %45, !llvm.loop !120
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal void @_canvas_emit(ptr noundef %0, ptr noundef captures(none) %1) #5 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4099
  %4 = load i16, ptr %3, align 1, !tbaa !24
  %5 = getelementptr inbounds nuw i8, ptr %0, i16 4101
  %6 = load i16, ptr %5, align 1, !tbaa !25
  %7 = icmp ugt i16 %4, %6
  br i1 %7, label %48, label %8

8:                                                ; preds = %2
  %9 = sub nuw i16 %6, %4
  %10 = add i16 %9, -256
  %11 = icmp ult i16 %10, -257
  br i1 %11, label %12, label %14

12:                                               ; preds = %8
  %13 = add i16 %4, 255
  br label %14

14:                                               ; preds = %12, %8
  %15 = phi i16 [ 255, %12 ], [ %9, %8 ]
  %16 = phi i16 [ %13, %12 ], [ %6, %8 ]
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %18 = load i16, ptr %17, align 1, !tbaa !20
  %19 = shl i16 %4, 3
  %20 = add i16 %18, %19
  %21 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %22 = shl i16 %4, 4
  %23 = getelementptr inbounds nuw i8, ptr %21, i16 %22
  %24 = shl nsw i16 %15, 4
  %25 = add nsw i16 %24, 16
  %26 = icmp eq i16 %25, 0
  br i1 %26, label %43, label %27

27:                                               ; preds = %14
  %28 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %29 = load i8, ptr %28, align 1, !tbaa !44
  %30 = icmp ugt i8 %29, 15
  br i1 %30, label %43, label %31

31:                                               ; preds = %27
  %32 = zext nneg i8 %29 to i16
  %33 = add nuw nsw i8 %29, 1
  store i8 %33, ptr %28, align 1, !tbaa !44
  %34 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %32
  %35 = getelementptr inbounds nuw i8, ptr %34, i16 10
  store i8 0, ptr %35, align 1, !tbaa !45
  store i16 %20, ptr %34, align 1, !tbaa !47
  %36 = getelementptr inbounds nuw i8, ptr %34, i16 9
  store i8 -128, ptr %36, align 1, !tbaa !48
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 7
  store i8 24, ptr %37, align 1, !tbaa !49
  %38 = getelementptr inbounds nuw i8, ptr %34, i16 8
  store i8 1, ptr %38, align 1, !tbaa !50
  %39 = ptrtoint ptr %23 to i16
  %40 = getelementptr inbounds nuw i8, ptr %34, i16 2
  store i16 %39, ptr %40, align 1, !tbaa !51
  %41 = getelementptr inbounds nuw i8, ptr %34, i16 6
  store i8 0, ptr %41, align 1, !tbaa !52
  %42 = getelementptr inbounds nuw i8, ptr %34, i16 4
  store i16 %25, ptr %42, align 1, !tbaa !53
  br label %43

43:                                               ; preds = %14, %27, %31
  %44 = icmp ult i16 %16, %6
  br i1 %44, label %46, label %45

45:                                               ; preds = %43
  store i16 -1, ptr %3, align 1, !tbaa !24
  store i16 0, ptr %5, align 1, !tbaa !25
  br label %48

46:                                               ; preds = %43
  %47 = add nuw i16 %16, 1
  store i16 %47, ptr %3, align 1, !tbaa !24
  br label %48

48:                                               ; preds = %45, %46, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_text_reserve(ptr readnone captures(none) %0, ptr readnone captures(none) %1) #4 {
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 2048, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %4

3:                                                ; preds = %4
  ret void

4:                                                ; preds = %2, %4
  %5 = phi i16 [ 0, %2 ], [ %8, %4 ]
  %6 = getelementptr inbounds nuw [2 x i8], ptr @FONT8, i16 %5
  %7 = load i16, ptr %6, align 1, !tbaa !2
  store volatile i16 %7, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %8 = add nuw nsw i16 %5, 1
  %9 = icmp eq i16 %8, 512
  br i1 %9, label %3, label %4, !llvm.loop !121
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(argmem: readwrite)
define internal void @_text_emit(ptr noundef %0, ptr noundef captures(none) %1) #6 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 135
  %4 = load i8, ptr %3, align 1, !tbaa !31
  %5 = zext i8 %4 to i16
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %7 = getelementptr i8, ptr %0, i16 7
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %9 = getelementptr i8, ptr %0, i16 5
  br label %11

10:                                               ; preds = %42
  store i8 0, ptr %3, align 1, !tbaa !31
  ret void

11:                                               ; preds = %2, %42
  %12 = phi i8 [ 0, %2 ], [ %43, %42 ]
  %13 = phi i1 [ true, %2 ], [ false, %42 ]
  %14 = phi i8 [ 0, %2 ], [ 1, %42 ]
  %15 = zext nneg i8 %14 to i16
  %16 = shl nuw nsw i16 1, %15
  %17 = and i16 %16, %5
  %18 = icmp eq i16 %17, 0
  br i1 %18, label %42, label %19

19:                                               ; preds = %11
  %20 = load i8, ptr %6, align 1, !tbaa !44
  %21 = icmp ugt i8 %20, 15
  br i1 %21, label %42, label %22

22:                                               ; preds = %19
  %23 = zext i8 %12 to i16
  %24 = getelementptr i8, ptr %7, i16 %23
  %25 = load i16, ptr %8, align 1, !tbaa !29
  %26 = getelementptr i8, ptr %9, i16 %15
  %27 = load i8, ptr %26, align 1, !tbaa !6
  %28 = zext i8 %27 to i16
  %29 = shl nuw nsw i16 %28, 5
  %30 = add i16 %29, %25
  %31 = zext nneg i8 %20 to i16
  %32 = add nuw nsw i8 %20, 1
  store i8 %32, ptr %6, align 1, !tbaa !44
  %33 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %31
  %34 = getelementptr inbounds nuw i8, ptr %33, i16 10
  store i8 0, ptr %34, align 1, !tbaa !45
  store i16 %30, ptr %33, align 1, !tbaa !47
  %35 = getelementptr inbounds nuw i8, ptr %33, i16 9
  store i8 -128, ptr %35, align 1, !tbaa !48
  %36 = getelementptr inbounds nuw i8, ptr %33, i16 7
  store i8 24, ptr %36, align 1, !tbaa !49
  %37 = getelementptr inbounds nuw i8, ptr %33, i16 8
  store i8 1, ptr %37, align 1, !tbaa !50
  %38 = ptrtoint ptr %24 to i16
  %39 = getelementptr inbounds nuw i8, ptr %33, i16 2
  store i16 %38, ptr %39, align 1, !tbaa !51
  %40 = getelementptr inbounds nuw i8, ptr %33, i16 6
  store i8 0, ptr %40, align 1, !tbaa !52
  %41 = getelementptr inbounds nuw i8, ptr %33, i16 4
  store i16 64, ptr %41, align 1, !tbaa !53
  br label %42

42:                                               ; preds = %22, %19, %11
  %43 = add nuw i8 %12, 64
  br i1 %13, label %11, label %10, !llvm.loop !122
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_title_reserve(ptr noundef %0, ptr readnone captures(none) %1) #4 {
  store volatile i8 80, ptr inttoptr (i16 8456 to ptr), align 8, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !6
  store volatile i8 112, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -1, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 127, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -124, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 4096, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %3

3:                                                ; preds = %2, %16
  %4 = phi ptr [ @FONT8, %2 ], [ %18, %16 ]
  %5 = phi i16 [ 0, %2 ], [ %17, %16 ]
  br label %7

6:                                                ; preds = %16
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 5120, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %24

7:                                                ; preds = %3, %7
  %8 = phi i8 [ 0, %3 ], [ %15, %7 ]
  %9 = phi i8 [ 0, %3 ], [ %13, %7 ]
  %10 = zext nneg i8 %8 to i16
  %11 = getelementptr i8, ptr %4, i16 %10
  %12 = load i16, ptr %11, align 1, !tbaa !2
  store volatile i16 %12, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %13 = add nuw nsw i8 %9, 1
  %14 = icmp eq i8 %13, 8
  %15 = add nuw nsw i8 %8, 2
  br i1 %14, label %20, label %7, !llvm.loop !123

16:                                               ; preds = %20
  %17 = add nuw nsw i16 %5, 1
  %18 = getelementptr i8, ptr %4, i16 16
  %19 = icmp eq i16 %17, 64
  br i1 %19, label %6, label %3, !llvm.loop !124

20:                                               ; preds = %7, %20
  %21 = phi i8 [ %22, %20 ], [ 0, %7 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %22 = add nuw nsw i8 %21, 1
  %23 = icmp eq i8 %22, 8
  br i1 %23, label %16, label %20, !llvm.loop !125

24:                                               ; preds = %6, %33
  %25 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 16), %6 ], [ %36, %33 ]
  %26 = phi ptr [ @FONT16, %6 ], [ %35, %33 ]
  %27 = phi i16 [ 0, %6 ], [ %34, %33 ]
  br label %29

28:                                               ; preds = %33
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 20480, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %66

29:                                               ; preds = %24, %47
  %30 = phi i8 [ 0, %24 ], [ %52, %47 ]
  %31 = phi ptr [ %26, %24 ], [ %50, %47 ]
  %32 = phi i8 [ 0, %24 ], [ %48, %47 ]
  br label %38

33:                                               ; preds = %47
  %34 = add nuw nsw i16 %27, 1
  %35 = getelementptr i8, ptr %26, i16 64
  %36 = getelementptr i8, ptr %25, i16 64
  %37 = icmp eq i16 %34, 64
  br i1 %37, label %28, label %24, !llvm.loop !126

38:                                               ; preds = %29, %38
  %39 = phi i8 [ 0, %29 ], [ %46, %38 ]
  %40 = phi i8 [ 0, %29 ], [ %44, %38 ]
  %41 = zext nneg i8 %39 to i16
  %42 = getelementptr i8, ptr %31, i16 %41
  %43 = load i16, ptr %42, align 1, !tbaa !2
  store volatile i16 %43, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %44 = add nuw nsw i8 %40, 1
  %45 = icmp eq i8 %44, 8
  %46 = add nuw nsw i8 %39, 2
  br i1 %45, label %53, label %38, !llvm.loop !127

47:                                               ; preds = %53
  %48 = add nuw nsw i8 %32, 1
  %49 = zext nneg i8 %30 to i16
  %50 = getelementptr i8, ptr %25, i16 %49
  %51 = icmp eq i8 %48, 4
  %52 = add nuw nsw i8 %30, 16
  br i1 %51, label %33, label %29, !llvm.loop !128

53:                                               ; preds = %38, %53
  %54 = phi i8 [ %55, %53 ], [ 0, %38 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %55 = add nuw nsw i8 %54, 1
  %56 = icmp eq i8 %55, 8
  br i1 %56, label %47, label %53, !llvm.loop !129

57:                                               ; preds = %66
  %58 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %59 = load ptr, ptr %58, align 1, !tbaa !65
  %60 = icmp eq ptr %59, null
  br i1 %60, label %79, label %61

61:                                               ; preds = %57
  %62 = load i8, ptr %59, align 1, !tbaa !6
  %63 = icmp eq i8 %62, 0
  br i1 %63, label %79, label %64

64:                                               ; preds = %61
  %65 = getelementptr i8, ptr %59, i16 1
  br label %70

66:                                               ; preds = %28, %66
  %67 = phi i16 [ 0, %28 ], [ %68, %66 ]
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %68 = add nuw nsw i16 %67, 1
  %69 = icmp eq i16 %68, 1024
  br i1 %69, label %57, label %66, !llvm.loop !130

70:                                               ; preds = %64, %70
  %71 = phi i8 [ %72, %70 ], [ 0, %64 ]
  %72 = add nuw nsw i8 %71, 1
  %73 = zext nneg i8 %71 to i16
  %74 = getelementptr i8, ptr %65, i16 %73
  %75 = load i8, ptr %74, align 1, !tbaa !6
  %76 = icmp ne i8 %75, 0
  %77 = icmp samesign ult i8 %71, 31
  %78 = select i1 %76, i1 %77, i1 false
  br i1 %78, label %70, label %79, !llvm.loop !131

79:                                               ; preds = %70, %61, %57
  %80 = phi i8 [ 0, %57 ], [ 0, %61 ], [ %72, %70 ]
  %81 = zext nneg i8 %80 to i16
  %82 = sub nuw nsw i16 32, %81
  %83 = lshr i16 %82, 1
  %84 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %85 = load i16, ptr %84, align 1, !tbaa !71
  %86 = shl i16 %85, 2
  %87 = and i16 %86, -32
  %88 = add i16 %87, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %88, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %89 = trunc nuw nsw i16 %83 to i8
  %90 = add nuw nsw i8 %80, %89
  %91 = sub nsw i16 0, %83
  %92 = getelementptr i8, ptr %59, i16 %91
  br label %105

93:                                               ; preds = %128
  %94 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %95 = load ptr, ptr %94, align 1, !tbaa !67
  %96 = getelementptr inbounds nuw i8, ptr %0, i16 11
  %97 = load i8, ptr %96, align 1, !tbaa !68
  %98 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %99 = load i16, ptr %98, align 1, !tbaa !72
  %100 = lshr i16 %99, 3
  %101 = trunc i16 %100 to i8
  tail call fastcc void @_title_write16(ptr noundef %95, i8 noundef zeroext %97, i8 noundef zeroext %101) #14
  %102 = getelementptr inbounds nuw i8, ptr %0, i16 9
  %103 = load ptr, ptr %102, align 1, !tbaa !69
  %104 = icmp eq ptr %103, null
  br i1 %104, label %139, label %132

105:                                              ; preds = %79, %128
  %106 = phi i8 [ 0, %79 ], [ %130, %128 ]
  %107 = zext nneg i8 %106 to i16
  br i1 %60, label %128, label %108

108:                                              ; preds = %105
  %109 = icmp samesign ugt i16 %83, %107
  br i1 %109, label %128, label %110

110:                                              ; preds = %108
  %111 = icmp ult i8 %106, %90
  br i1 %111, label %112, label %128

112:                                              ; preds = %110
  %113 = getelementptr i8, ptr %92, i16 %107
  %114 = load i8, ptr %113, align 1, !tbaa !6
  %115 = icmp ugt i8 %114, 96
  br i1 %115, label %116, label %120

116:                                              ; preds = %112
  %117 = icmp ult i8 %114, 123
  br i1 %117, label %118, label %128

118:                                              ; preds = %116
  %119 = add nsw i8 %114, -32
  br label %124

120:                                              ; preds = %112
  %121 = icmp samesign ugt i8 %114, 31
  br i1 %121, label %122, label %128

122:                                              ; preds = %120
  %123 = icmp eq i8 %114, 96
  br i1 %123, label %128, label %124

124:                                              ; preds = %122, %118
  %125 = phi i8 [ %119, %118 ], [ %114, %122 ]
  %126 = zext nneg i8 %125 to i16
  %127 = add nuw nsw i16 %126, 7136
  br label %128

128:                                              ; preds = %124, %122, %120, %116, %105, %108, %110
  %129 = phi i16 [ 7168, %105 ], [ 7168, %110 ], [ 7168, %108 ], [ %127, %124 ], [ 7168, %122 ], [ 7168, %120 ], [ 7168, %116 ]
  store volatile i16 %129, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %130 = add nuw nsw i8 %106, 1
  %131 = icmp eq i8 %130, 32
  br i1 %131, label %93, label %105, !llvm.loop !132

132:                                              ; preds = %93
  %133 = getelementptr inbounds nuw i8, ptr %0, i16 12
  %134 = load i8, ptr %133, align 1, !tbaa !70
  %135 = load i16, ptr %98, align 1, !tbaa !72
  %136 = lshr i16 %135, 3
  %137 = trunc i16 %136 to i8
  %138 = add i8 %137, 2
  tail call fastcc void @_title_write16(ptr noundef nonnull %103, i8 noundef zeroext %134, i8 noundef zeroext %138) #14
  br label %139

139:                                              ; preds = %132, %93
  %140 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 -128, ptr %140, align 1, !tbaa !105
  %141 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 3584, ptr %141, align 1, !tbaa !133
  %142 = getelementptr inbounds nuw i8, ptr %0, i16 23
  store i16 0, ptr %142, align 1, !tbaa !134
  %143 = load ptr, ptr %58, align 1, !tbaa !65
  %144 = icmp eq ptr %143, null
  br i1 %144, label %167, label %145

145:                                              ; preds = %139
  %146 = load i8, ptr %143, align 1, !tbaa !6
  %147 = icmp eq i8 %146, 0
  br i1 %147, label %150, label %148

148:                                              ; preds = %145
  %149 = getelementptr i8, ptr %143, i16 1
  br label %158

150:                                              ; preds = %158, %145
  %151 = phi i8 [ 0, %145 ], [ %160, %158 ]
  %152 = zext nneg i8 %151 to i16
  %153 = shl nuw nsw i16 %152, 2
  %154 = sub nuw nsw i16 128, %153
  %155 = and i16 %154, 248
  %156 = add nsw i16 %153, -128
  %157 = add nsw i16 %156, %155
  br label %167

158:                                              ; preds = %158, %148
  %159 = phi i8 [ %160, %158 ], [ 0, %148 ]
  %160 = add nuw nsw i8 %159, 1
  %161 = zext nneg i8 %159 to i16
  %162 = getelementptr i8, ptr %149, i16 %161
  %163 = load i8, ptr %162, align 1, !tbaa !6
  %164 = icmp ne i8 %163, 0
  %165 = icmp samesign ult i8 %159, 31
  %166 = select i1 %164, i1 %165, i1 false
  br i1 %166, label %158, label %150, !llvm.loop !135

167:                                              ; preds = %139, %150
  %168 = phi i16 [ %157, %150 ], [ 0, %139 ]
  %169 = getelementptr inbounds nuw i8, ptr %0, i16 26
  store i16 %168, ptr %169, align 1, !tbaa !136
  store volatile i8 -112, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  %170 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %171 = getelementptr inbounds nuw i8, ptr %0, i16 89
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef -8, i16 noundef 224, ptr noundef nonnull %170, ptr noundef nonnull %171) #14
  %172 = getelementptr inbounds nuw i8, ptr %0, i16 88
  store i8 0, ptr %172, align 1, !tbaa !107
  store volatile i8 2, ptr inttoptr (i16 17200 to ptr), align 16, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 17201 to ptr), align 1, !tbaa !6
  %173 = ptrtoint ptr %170 to i16
  %174 = trunc i16 %173 to i8
  store volatile i8 %174, ptr inttoptr (i16 17202 to ptr), align 2, !tbaa !6
  %175 = lshr i16 %173, 8
  %176 = trunc nuw i16 %175 to i8
  store volatile i8 %176, ptr inttoptr (i16 17203 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17204 to ptr), align 4, !tbaa !6
  %177 = getelementptr inbounds nuw i8, ptr %0, i16 139
  store i8 0, ptr %177, align 1, !tbaa !107
  store volatile i8 2, ptr inttoptr (i16 17216 to ptr), align 64, !tbaa !6
  store volatile i8 15, ptr inttoptr (i16 17217 to ptr), align 1, !tbaa !6
  %178 = ptrtoint ptr %171 to i16
  %179 = trunc i16 %178 to i8
  store volatile i8 %179, ptr inttoptr (i16 17218 to ptr), align 2, !tbaa !6
  %180 = lshr i16 %178, 8
  %181 = trunc nuw i16 %180 to i8
  store volatile i8 %181, ptr inttoptr (i16 17219 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17220 to ptr), align 4, !tbaa !6
  %182 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 2, ptr %182, align 1, !tbaa !64
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal void @_title_emit(ptr noundef %0, ptr noundef captures(none) %1) #7 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 29
  %4 = load i8, ptr %3, align 1, !tbaa !75
  %5 = icmp eq i8 %4, 0
  br i1 %5, label %188, label %6

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 30
  %8 = load i8, ptr %7, align 1, !tbaa !78
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %39, label %10

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 25
  %12 = load i8, ptr %11, align 1, !tbaa !79
  %13 = icmp ugt i8 %12, -6
  br i1 %13, label %16, label %14

14:                                               ; preds = %10
  %15 = add nuw i8 %12, 4
  br label %16

16:                                               ; preds = %10, %14
  %17 = phi i8 [ %15, %14 ], [ -1, %10 ]
  store i8 %17, ptr %11, align 1, !tbaa !79
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %19 = load i16, ptr %18, align 1, !tbaa !71
  %20 = xor i8 %17, -1
  %21 = zext i8 %20 to i16
  %22 = mul nuw i16 %21, %21
  %23 = lshr i16 %22, 8
  %24 = sub nuw nsw i16 256, %23
  %25 = add nsw i16 %19, 8
  %26 = mul nsw i16 %24, %25
  %27 = ashr i16 %26, 4
  %28 = and i16 %27, -16
  %29 = add nsw i16 %28, -128
  %30 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 %29, ptr %30, align 1, !tbaa !105
  %31 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %32 = load i16, ptr %31, align 1, !tbaa !72
  %33 = add nsw i16 %32, -224
  %34 = mul nsw i16 %33, %24
  %35 = ashr i16 %34, 4
  %36 = and i16 %35, -16
  %37 = add nsw i16 %36, 3584
  %38 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 %37, ptr %38, align 1, !tbaa !133
  br label %64

39:                                               ; preds = %6
  %40 = getelementptr inbounds nuw i8, ptr %0, i16 31
  %41 = load i8, ptr %40, align 1, !tbaa !76
  %42 = icmp eq i8 %41, 0
  br i1 %42, label %43, label %48

43:                                               ; preds = %39
  %44 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %45 = load i16, ptr %44, align 1, !tbaa !105
  %46 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %47 = load i16, ptr %46, align 1, !tbaa !133
  br label %64

48:                                               ; preds = %39
  %49 = getelementptr inbounds nuw i8, ptr %0, i16 23
  %50 = load i16, ptr %49, align 1, !tbaa !134
  %51 = add nsw i16 %50, 2
  store i16 %51, ptr %49, align 1, !tbaa !134
  %52 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %53 = load i16, ptr %52, align 1, !tbaa !105
  %54 = add nsw i16 %53, %51
  store i16 %54, ptr %52, align 1, !tbaa !105
  %55 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %56 = load i16, ptr %55, align 1, !tbaa !133
  %57 = add nsw i16 %56, %51
  store i16 %57, ptr %55, align 1, !tbaa !133
  %58 = icmp sgt i16 %54, 4480
  br i1 %58, label %59, label %60

59:                                               ; preds = %48
  store i16 4480, ptr %52, align 1, !tbaa !105
  br label %60

60:                                               ; preds = %59, %48
  %61 = phi i16 [ 4480, %59 ], [ %54, %48 ]
  %62 = icmp sgt i16 %57, 4736
  br i1 %62, label %63, label %64

63:                                               ; preds = %60
  store i16 4736, ptr %55, align 1, !tbaa !133
  br label %64

64:                                               ; preds = %43, %63, %60, %16
  %65 = phi i16 [ %47, %43 ], [ 4736, %63 ], [ %57, %60 ], [ %37, %16 ]
  %66 = phi i16 [ %45, %43 ], [ %61, %63 ], [ %61, %60 ], [ %29, %16 ]
  %67 = ashr i16 %66, 4
  %68 = ashr i16 %65, 4
  %69 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %70 = getelementptr inbounds nuw i8, ptr %0, i16 88
  %71 = load i8, ptr %70, align 1, !tbaa !107
  %72 = xor i8 %71, 1
  %73 = zext i8 %72 to i16
  %74 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %73
  %75 = getelementptr inbounds nuw i8, ptr %0, i16 89
  %76 = getelementptr inbounds nuw i8, ptr %0, i16 139
  %77 = load i8, ptr %76, align 1, !tbaa !107
  %78 = xor i8 %77, 1
  %79 = zext i8 %78 to i16
  %80 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %79
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef %67, i16 noundef %68, ptr noundef nonnull %74, ptr noundef nonnull %80) #14
  %81 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %82 = load i8, ptr %81, align 1, !tbaa !44
  %83 = icmp ugt i8 %82, 15
  br i1 %83, label %109, label %84

84:                                               ; preds = %64
  %85 = load i8, ptr %70, align 1, !tbaa !107
  %86 = xor i8 %85, 1
  %87 = zext i8 %86 to i16
  %88 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %87
  %89 = ptrtoint ptr %88 to i16
  %90 = zext nneg i8 %82 to i16
  %91 = add nuw nsw i8 %82, 1
  store i8 %91, ptr %81, align 1, !tbaa !44
  %92 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %90
  %93 = getelementptr inbounds nuw i8, ptr %92, i16 10
  store i8 4, ptr %93, align 1, !tbaa !45
  store i16 17202, ptr %92, align 1, !tbaa !47
  %94 = getelementptr inbounds nuw i8, ptr %92, i16 2
  store i16 %89, ptr %94, align 1, !tbaa !51
  %95 = getelementptr inbounds nuw i8, ptr %92, i16 4
  store i16 0, ptr %95, align 1, !tbaa !53
  store i8 %86, ptr %70, align 1, !tbaa !107
  %96 = icmp eq i8 %82, 15
  br i1 %96, label %109, label %97

97:                                               ; preds = %84
  %98 = load i8, ptr %76, align 1, !tbaa !107
  %99 = xor i8 %98, 1
  %100 = zext i8 %99 to i16
  %101 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %100
  %102 = ptrtoint ptr %101 to i16
  %103 = zext nneg i8 %91 to i16
  %104 = add nuw nsw i8 %82, 2
  store i8 %104, ptr %81, align 1, !tbaa !44
  %105 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %103
  %106 = getelementptr inbounds nuw i8, ptr %105, i16 10
  store i8 4, ptr %106, align 1, !tbaa !45
  store i16 17218, ptr %105, align 1, !tbaa !47
  %107 = getelementptr inbounds nuw i8, ptr %105, i16 2
  store i16 %102, ptr %107, align 1, !tbaa !51
  %108 = getelementptr inbounds nuw i8, ptr %105, i16 4
  store i16 0, ptr %108, align 1, !tbaa !53
  store i8 %99, ptr %76, align 1, !tbaa !107
  br label %109

109:                                              ; preds = %64, %84, %97
  %110 = phi i8 [ %82, %64 ], [ 16, %84 ], [ %104, %97 ]
  %111 = getelementptr inbounds nuw i8, ptr %0, i16 28
  %112 = load i8, ptr %111, align 1, !tbaa !74
  %113 = add i8 %112, 1
  store i8 %113, ptr %111, align 1, !tbaa !74
  %114 = getelementptr inbounds nuw i8, ptr %0, i16 32
  %115 = load i8, ptr %114, align 1, !tbaa !77
  %116 = icmp eq i8 %115, 0
  br i1 %116, label %117, label %155

117:                                              ; preds = %109
  %118 = shl i8 %113, 1
  %119 = icmp sgt i8 %118, -1
  br i1 %119, label %122, label %120

120:                                              ; preds = %117
  %121 = xor i8 %118, -1
  br label %122

122:                                              ; preds = %117, %120
  %123 = phi i8 [ %121, %120 ], [ %118, %117 ]
  %124 = lshr i8 %123, 4
  %125 = add nuw nsw i8 %124, 24
  %126 = zext nneg i8 %125 to i16
  %127 = mul nuw nsw i16 %126, 1057
  %128 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 %127, ptr %128, align 1, !tbaa !80
  %129 = add i8 %118, -86
  %130 = icmp sgt i8 %129, -1
  br i1 %130, label %133, label %131

131:                                              ; preds = %122
  %132 = sub nsw i8 85, %118
  br label %133

133:                                              ; preds = %122, %131
  %134 = phi i8 [ %132, %131 ], [ %129, %122 ]
  %135 = lshr i8 %134, 2
  %136 = zext nneg i8 %135 to i16
  %137 = shl nuw nsw i16 %136, 10
  %138 = add i8 %118, 85
  %139 = icmp sgt i8 %138, -1
  br i1 %139, label %142, label %140

140:                                              ; preds = %133
  %141 = sub nuw i8 -86, %118
  br label %142

142:                                              ; preds = %133, %140
  %143 = phi i8 [ %141, %140 ], [ %138, %133 ]
  %144 = lshr i8 %143, 2
  %145 = zext nneg i8 %144 to i16
  %146 = shl nuw nsw i16 %145, 5
  %147 = add nuw nsw i16 %146, %137
  br i1 %119, label %150, label %148

148:                                              ; preds = %142
  %149 = xor i8 %118, -1
  br label %150

150:                                              ; preds = %142, %148
  %151 = phi i8 [ %149, %148 ], [ %118, %142 ]
  %152 = lshr i8 %151, 2
  %153 = zext nneg i8 %152 to i16
  %154 = add nuw nsw i16 %147, %153
  br label %157

155:                                              ; preds = %109
  %156 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 29596, ptr %156, align 1, !tbaa !80
  br label %157

157:                                              ; preds = %155, %150
  %158 = phi i16 [ 0, %155 ], [ %154, %150 ]
  %159 = getelementptr inbounds nuw i8, ptr %0, i16 36
  store i16 %158, ptr %159, align 1, !tbaa !81
  %160 = icmp ugt i8 %110, 15
  br i1 %160, label %188, label %161

161:                                              ; preds = %157
  %162 = getelementptr inbounds nuw i8, ptr %0, i16 34
  %163 = zext nneg i8 %110 to i16
  %164 = add nuw nsw i8 %110, 1
  store i8 %164, ptr %81, align 1, !tbaa !44
  %165 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %163
  %166 = getelementptr inbounds nuw i8, ptr %165, i16 10
  store i8 1, ptr %166, align 1, !tbaa !45
  store i16 113, ptr %165, align 1, !tbaa !47
  %167 = getelementptr inbounds nuw i8, ptr %165, i16 9
  store i8 0, ptr %167, align 1, !tbaa !48
  %168 = getelementptr inbounds nuw i8, ptr %165, i16 7
  store i8 34, ptr %168, align 1, !tbaa !49
  %169 = getelementptr inbounds nuw i8, ptr %165, i16 8
  store i8 0, ptr %169, align 1, !tbaa !50
  %170 = ptrtoint ptr %162 to i16
  %171 = getelementptr inbounds nuw i8, ptr %165, i16 2
  store i16 %170, ptr %171, align 1, !tbaa !51
  %172 = getelementptr inbounds nuw i8, ptr %165, i16 6
  store i8 0, ptr %172, align 1, !tbaa !52
  %173 = getelementptr inbounds nuw i8, ptr %165, i16 4
  store i16 2, ptr %173, align 1, !tbaa !53
  %174 = icmp eq i8 %110, 15
  br i1 %174, label %188, label %175

175:                                              ; preds = %161
  %176 = getelementptr inbounds nuw i8, ptr %0, i16 36
  %177 = zext nneg i8 %164 to i16
  %178 = add nuw nsw i8 %110, 2
  store i8 %178, ptr %81, align 1, !tbaa !44
  %179 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %177
  %180 = getelementptr inbounds nuw i8, ptr %179, i16 10
  store i8 1, ptr %180, align 1, !tbaa !45
  store i16 0, ptr %179, align 1, !tbaa !47
  %181 = getelementptr inbounds nuw i8, ptr %179, i16 9
  store i8 0, ptr %181, align 1, !tbaa !48
  %182 = getelementptr inbounds nuw i8, ptr %179, i16 7
  store i8 34, ptr %182, align 1, !tbaa !49
  %183 = getelementptr inbounds nuw i8, ptr %179, i16 8
  store i8 0, ptr %183, align 1, !tbaa !50
  %184 = ptrtoint ptr %176 to i16
  %185 = getelementptr inbounds nuw i8, ptr %179, i16 2
  store i16 %184, ptr %185, align 1, !tbaa !51
  %186 = getelementptr inbounds nuw i8, ptr %179, i16 6
  store i8 0, ptr %186, align 1, !tbaa !52
  %187 = getelementptr inbounds nuw i8, ptr %179, i16 4
  store i16 2, ptr %187, align 1, !tbaa !53
  br label %188

188:                                              ; preds = %157, %175, %161, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @_title_write16(ptr noundef readonly captures(address_is_null) %0, i8 noundef zeroext %1, i8 noundef zeroext %2) unnamed_addr #4 {
  %4 = zext i8 %1 to i16
  %5 = shl nuw nsw i16 %4, 1
  %6 = and i16 %5, 254
  %7 = sub nsw i16 32, %6
  %8 = lshr exact i16 %7, 1
  %9 = zext i8 %2 to i16
  %10 = icmp eq ptr %0, null
  %11 = and i16 %8, 255
  %12 = add nuw i16 %8, %5
  %13 = and i16 %12, 255
  br label %15

14:                                               ; preds = %23
  ret void

15:                                               ; preds = %3, %23
  %16 = phi i1 [ true, %3 ], [ false, %23 ]
  %17 = phi i8 [ 0, %3 ], [ 1, %23 ]
  %18 = zext nneg i8 %17 to i16
  %19 = add nuw nsw i16 %18, %9
  %20 = shl nuw nsw i16 %19, 5
  %21 = add nuw nsw i16 %20, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %21, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %22 = select i1 %16, i16 7168, i16 7170
  br label %24

23:                                               ; preds = %56
  br i1 %16, label %15, label %14, !llvm.loop !137

24:                                               ; preds = %15, %56
  %25 = phi i8 [ 0, %15 ], [ %58, %56 ]
  %26 = zext nneg i8 %25 to i16
  br i1 %10, label %56, label %27

27:                                               ; preds = %24
  %28 = icmp samesign ugt i16 %11, %26
  br i1 %28, label %56, label %29

29:                                               ; preds = %27
  %30 = icmp samesign ugt i16 %13, %26
  br i1 %30, label %31, label %56

31:                                               ; preds = %29
  %32 = sub nsw i16 %26, %11
  %33 = lshr i16 %32, 1
  %34 = and i16 %33, 255
  %35 = getelementptr inbounds nuw i8, ptr %0, i16 %34
  %36 = load i8, ptr %35, align 1, !tbaa !6
  %37 = icmp ugt i8 %36, 96
  br i1 %37, label %38, label %42

38:                                               ; preds = %31
  %39 = icmp ult i8 %36, 123
  br i1 %39, label %40, label %51

40:                                               ; preds = %38
  %41 = add nsw i8 %36, -32
  br label %46

42:                                               ; preds = %31
  %43 = icmp samesign ugt i8 %36, 31
  br i1 %43, label %44, label %51

44:                                               ; preds = %42
  %45 = icmp eq i8 %36, 96
  br i1 %45, label %51, label %46

46:                                               ; preds = %44, %40
  %47 = phi i8 [ %41, %40 ], [ %36, %44 ]
  %48 = zext nneg i8 %47 to i16
  %49 = shl nuw nsw i16 %48, 2
  %50 = add nsw i16 %49, -64
  br label %51

51:                                               ; preds = %38, %42, %44, %46
  %52 = phi i16 [ %50, %46 ], [ 64, %44 ], [ 64, %42 ], [ 64, %38 ]
  %53 = and i16 %32, 1
  %54 = or disjoint i16 %22, %53
  %55 = or disjoint i16 %54, %52
  br label %56

56:                                               ; preds = %51, %29, %27, %24
  %57 = phi i16 [ %55, %51 ], [ 7168, %29 ], [ 7168, %27 ], [ 7168, %24 ]
  store volatile i16 %57, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %58 = add nuw nsw i8 %25, 1
  %59 = icmp eq i8 %58, 32
  br i1 %59, label %23, label %24, !llvm.loop !138
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_build(ptr noundef readonly captures(none) %0, i16 noundef range(i16 -2048, 2048) %1, i16 noundef range(i16 -2048, 2048) %2, ptr noundef %3, ptr noundef %4) unnamed_addr #7 {
  %6 = alloca %struct.HScrollW, align 1
  %7 = alloca %struct.HScrollW, align 1
  %8 = alloca i16, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #15
  store i16 0, ptr %8, align 1, !tbaa !2
  store ptr %3, ptr %6, align 1, !tbaa !139
  %9 = getelementptr inbounds nuw i8, ptr %6, i16 2
  store i8 0, ptr %9, align 1, !tbaa !141
  store ptr %4, ptr %7, align 1, !tbaa !139
  %10 = getelementptr inbounds nuw i8, ptr %7, i16 2
  store i8 0, ptr %10, align 1, !tbaa !141
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %12 = load i16, ptr %11, align 1, !tbaa !71
  %13 = getelementptr inbounds nuw i8, ptr %0, i16 26
  %14 = load i16, ptr %13, align 1, !tbaa !136
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %1, i16 noundef 8, i16 noundef %12, i16 noundef %14) #14
  %15 = getelementptr inbounds nuw i8, ptr %0, i16 17
  %16 = load i16, ptr %15, align 1, !tbaa !73
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %18 = load i16, ptr %17, align 1, !tbaa !72
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %2, i16 noundef %16, i16 noundef %18, i16 noundef 0) #14
  %19 = load i16, ptr %8, align 1, !tbaa !2
  call fastcc void @_title_blank(ptr noundef %6, ptr noundef %7, i16 noundef %19, i16 noundef 224) #14
  %20 = load ptr, ptr %6, align 1, !tbaa !139
  %21 = load i8, ptr %9, align 1, !tbaa !141
  %22 = zext i8 %21 to i16
  %23 = getelementptr inbounds nuw i8, ptr %20, i16 %22
  store i8 0, ptr %23, align 1, !tbaa !6
  %24 = load ptr, ptr %7, align 1, !tbaa !139
  %25 = load i8, ptr %10, align 1, !tbaa !141
  %26 = zext i8 %25 to i16
  %27 = getelementptr inbounds nuw i8, ptr %24, i16 %26
  store i8 0, ptr %27, align 1, !tbaa !6
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #15
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #15
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #15
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_glyph_band(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, ptr noundef nonnull captures(none) %2, i16 noundef range(i16 -2048, 2048) %3, i16 noundef %4, i16 noundef %5, i16 noundef %6) unnamed_addr #7 {
  %8 = add nsw i16 %3, -2
  %9 = add nsw i16 %4, %3
  %10 = add nsw i16 %9, 2
  %11 = load i16, ptr %2, align 1, !tbaa !2
  %12 = icmp slt i16 %8, %11
  br i1 %12, label %13, label %14

13:                                               ; preds = %7
  br label %14

14:                                               ; preds = %13, %7
  %15 = phi i16 [ %11, %13 ], [ %8, %7 ]
  %16 = icmp sgt i16 %9, 222
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  br label %18

18:                                               ; preds = %17, %14
  %19 = phi i16 [ 224, %17 ], [ %10, %14 ]
  %20 = icmp sgt i16 %19, %15
  br i1 %20, label %21, label %92

21:                                               ; preds = %18
  tail call fastcc void @_title_blank(ptr noundef %0, ptr noundef %1, i16 noundef %11, i16 noundef %15) #14
  %22 = sub nsw i16 %19, %15
  %23 = trunc i16 %22 to i8
  %24 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %25 = icmp eq i8 %23, 0
  br i1 %25, label %91, label %26

26:                                               ; preds = %21
  %27 = sub nsw i16 %5, %3
  %28 = and i16 %22, 255
  %29 = trunc i16 %27 to i8
  %30 = lshr i16 %27, 8
  %31 = trunc nuw i16 %30 to i8
  br label %32

32:                                               ; preds = %40, %26
  %33 = phi i16 [ %28, %26 ], [ %57, %40 ]
  %34 = load i8, ptr %24, align 1, !tbaa !141
  %35 = icmp ult i8 %34, 22
  br i1 %35, label %36, label %59

36:                                               ; preds = %32
  %37 = icmp ugt i16 %33, 127
  br i1 %37, label %40, label %38

38:                                               ; preds = %36
  %39 = trunc nuw nsw i16 %33 to i8
  br label %40

40:                                               ; preds = %38, %36
  %41 = phi i8 [ %39, %38 ], [ 127, %36 ]
  %42 = load ptr, ptr %0, align 1, !tbaa !139
  %43 = add nuw nsw i8 %34, 1
  store i8 %43, ptr %24, align 1, !tbaa !141
  %44 = zext nneg i8 %34 to i16
  %45 = getelementptr inbounds nuw i8, ptr %42, i16 %44
  store i8 %41, ptr %45, align 1, !tbaa !6
  %46 = load ptr, ptr %0, align 1, !tbaa !139
  %47 = load i8, ptr %24, align 1, !tbaa !141
  %48 = add i8 %47, 1
  store i8 %48, ptr %24, align 1, !tbaa !141
  %49 = zext i8 %47 to i16
  %50 = getelementptr inbounds nuw i8, ptr %46, i16 %49
  store i8 %29, ptr %50, align 1, !tbaa !6
  %51 = load ptr, ptr %0, align 1, !tbaa !139
  %52 = load i8, ptr %24, align 1, !tbaa !141
  %53 = add i8 %52, 1
  store i8 %53, ptr %24, align 1, !tbaa !141
  %54 = zext i8 %52 to i16
  %55 = getelementptr inbounds nuw i8, ptr %51, i16 %54
  store i8 %31, ptr %55, align 1, !tbaa !6
  %56 = zext nneg i8 %41 to i16
  %57 = sub i16 %33, %56
  %58 = icmp eq i16 %57, 0
  br i1 %58, label %59, label %32, !llvm.loop !111

59:                                               ; preds = %32, %40
  %60 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %61 = trunc i16 %6 to i8
  %62 = lshr i16 %6, 8
  %63 = trunc nuw i16 %62 to i8
  br label %64

64:                                               ; preds = %72, %59
  %65 = phi i16 [ %28, %59 ], [ %89, %72 ]
  %66 = load i8, ptr %60, align 1, !tbaa !141
  %67 = icmp ult i8 %66, 22
  br i1 %67, label %68, label %91

68:                                               ; preds = %64
  %69 = icmp ugt i16 %65, 127
  br i1 %69, label %72, label %70

70:                                               ; preds = %68
  %71 = trunc nuw nsw i16 %65 to i8
  br label %72

72:                                               ; preds = %70, %68
  %73 = phi i8 [ %71, %70 ], [ 127, %68 ]
  %74 = load ptr, ptr %1, align 1, !tbaa !139
  %75 = add nuw nsw i8 %66, 1
  store i8 %75, ptr %60, align 1, !tbaa !141
  %76 = zext nneg i8 %66 to i16
  %77 = getelementptr inbounds nuw i8, ptr %74, i16 %76
  store i8 %73, ptr %77, align 1, !tbaa !6
  %78 = load ptr, ptr %1, align 1, !tbaa !139
  %79 = load i8, ptr %60, align 1, !tbaa !141
  %80 = add i8 %79, 1
  store i8 %80, ptr %60, align 1, !tbaa !141
  %81 = zext i8 %79 to i16
  %82 = getelementptr inbounds nuw i8, ptr %78, i16 %81
  store i8 %61, ptr %82, align 1, !tbaa !6
  %83 = load ptr, ptr %1, align 1, !tbaa !139
  %84 = load i8, ptr %60, align 1, !tbaa !141
  %85 = add i8 %84, 1
  store i8 %85, ptr %60, align 1, !tbaa !141
  %86 = zext i8 %84 to i16
  %87 = getelementptr inbounds nuw i8, ptr %83, i16 %86
  store i8 %63, ptr %87, align 1, !tbaa !6
  %88 = zext nneg i8 %73 to i16
  %89 = sub i16 %65, %88
  %90 = icmp eq i16 %89, 0
  br i1 %90, label %91, label %64, !llvm.loop !111

91:                                               ; preds = %64, %72, %21
  store i16 %19, ptr %2, align 1, !tbaa !2
  br label %92

92:                                               ; preds = %18, %91
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_blank(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, i16 noundef %2, i16 noundef range(i16 -2050, 225) %3) unnamed_addr #7 {
  %5 = icmp sgt i16 %3, %2
  br i1 %5, label %6, label %83

6:                                                ; preds = %4
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 2
  br label %9

9:                                                ; preds = %6, %79
  %10 = phi i16 [ %2, %6 ], [ %81, %79 ]
  %11 = sub nsw i16 %3, %10
  %12 = icmp sgt i16 %11, 112
  br i1 %12, label %16, label %13

13:                                               ; preds = %9
  %14 = trunc i16 %11 to i8
  %15 = icmp eq i8 %14, 0
  br i1 %15, label %79, label %16

16:                                               ; preds = %9, %13
  %17 = phi i8 [ %14, %13 ], [ 112, %9 ]
  %18 = phi i16 [ %11, %13 ], [ 112, %9 ]
  %19 = sub nsw i16 144, %10
  %20 = zext i8 %17 to i16
  %21 = trunc i16 %19 to i8
  %22 = lshr i16 %19, 8
  %23 = trunc nuw i16 %22 to i8
  br label %24

24:                                               ; preds = %32, %16
  %25 = phi i16 [ %20, %16 ], [ %49, %32 ]
  %26 = load i8, ptr %7, align 1, !tbaa !141
  %27 = icmp ult i8 %26, 22
  br i1 %27, label %28, label %51

28:                                               ; preds = %24
  %29 = icmp ugt i16 %25, 127
  br i1 %29, label %32, label %30

30:                                               ; preds = %28
  %31 = trunc nuw nsw i16 %25 to i8
  br label %32

32:                                               ; preds = %30, %28
  %33 = phi i8 [ %31, %30 ], [ 127, %28 ]
  %34 = load ptr, ptr %0, align 1, !tbaa !139
  %35 = add nuw nsw i8 %26, 1
  store i8 %35, ptr %7, align 1, !tbaa !141
  %36 = zext nneg i8 %26 to i16
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 %36
  store i8 %33, ptr %37, align 1, !tbaa !6
  %38 = load ptr, ptr %0, align 1, !tbaa !139
  %39 = load i8, ptr %7, align 1, !tbaa !141
  %40 = add i8 %39, 1
  store i8 %40, ptr %7, align 1, !tbaa !141
  %41 = zext i8 %39 to i16
  %42 = getelementptr inbounds nuw i8, ptr %38, i16 %41
  store i8 %21, ptr %42, align 1, !tbaa !6
  %43 = load ptr, ptr %0, align 1, !tbaa !139
  %44 = load i8, ptr %7, align 1, !tbaa !141
  %45 = add i8 %44, 1
  store i8 %45, ptr %7, align 1, !tbaa !141
  %46 = zext i8 %44 to i16
  %47 = getelementptr inbounds nuw i8, ptr %43, i16 %46
  store i8 %23, ptr %47, align 1, !tbaa !6
  %48 = zext nneg i8 %33 to i16
  %49 = sub i16 %25, %48
  %50 = icmp eq i16 %49, 0
  br i1 %50, label %51, label %24, !llvm.loop !111

51:                                               ; preds = %24, %32
  br label %52

52:                                               ; preds = %51, %60
  %53 = phi i16 [ %77, %60 ], [ %20, %51 ]
  %54 = load i8, ptr %8, align 1, !tbaa !141
  %55 = icmp ult i8 %54, 22
  br i1 %55, label %56, label %79

56:                                               ; preds = %52
  %57 = icmp ugt i16 %53, 127
  br i1 %57, label %60, label %58

58:                                               ; preds = %56
  %59 = trunc nuw nsw i16 %53 to i8
  br label %60

60:                                               ; preds = %58, %56
  %61 = phi i8 [ %59, %58 ], [ 127, %56 ]
  %62 = load ptr, ptr %1, align 1, !tbaa !139
  %63 = add nuw nsw i8 %54, 1
  store i8 %63, ptr %8, align 1, !tbaa !141
  %64 = zext nneg i8 %54 to i16
  %65 = getelementptr inbounds nuw i8, ptr %62, i16 %64
  store i8 %61, ptr %65, align 1, !tbaa !6
  %66 = load ptr, ptr %1, align 1, !tbaa !139
  %67 = load i8, ptr %8, align 1, !tbaa !141
  %68 = add i8 %67, 1
  store i8 %68, ptr %8, align 1, !tbaa !141
  %69 = zext i8 %67 to i16
  %70 = getelementptr inbounds nuw i8, ptr %66, i16 %69
  store i8 0, ptr %70, align 1, !tbaa !6
  %71 = load ptr, ptr %1, align 1, !tbaa !139
  %72 = load i8, ptr %8, align 1, !tbaa !141
  %73 = add i8 %72, 1
  store i8 %73, ptr %8, align 1, !tbaa !141
  %74 = zext i8 %72 to i16
  %75 = getelementptr inbounds nuw i8, ptr %71, i16 %74
  store i8 0, ptr %75, align 1, !tbaa !6
  %76 = zext nneg i8 %61 to i16
  %77 = sub i16 %53, %76
  %78 = icmp eq i16 %77, 0
  br i1 %78, label %79, label %52, !llvm.loop !111

79:                                               ; preds = %52, %60, %13
  %80 = phi i16 [ %11, %13 ], [ %18, %60 ], [ %18, %52 ]
  %81 = add nsw i16 %80, %10
  %82 = icmp sgt i16 %3, %81
  br i1 %82, label %9, label %83, !llvm.loop !142

83:                                               ; preds = %79, %4
  ret void
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none)
define internal fastcc noundef range(i16 -1, 2) i16 @tm_cmp32(i32 noundef %0, i32 noundef %1) unnamed_addr #8 {
  %3 = tail call i16 @llvm.scmp.i16.i32(i32 %0, i32 %1)
  ret i16 %3
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none)
define internal fastcc noundef range(i16 -1, 2) i16 @tm_cmp64(i64 noundef %0, i64 noundef %1) unnamed_addr #8 {
  %3 = tail call i16 @llvm.scmp.i16.i64(i64 %0, i64 %1)
  ret i16 %3
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @upq_flush() unnamed_addr #9 {
  %1 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 177), align 1, !tbaa !143
  %2 = zext i8 %1 to i16
  %3 = shl nuw nsw i16 %2, 4
  %4 = add nuw nsw i16 %3, 17152
  %5 = inttoptr i16 %4 to ptr
  %6 = shl nuw i16 1, %2
  %7 = trunc i16 %6 to i8
  %8 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %108, label %10

10:                                               ; preds = %0
  %11 = getelementptr inbounds nuw i8, ptr %5, i16 1
  %12 = getelementptr inbounds nuw i8, ptr %5, i16 2
  %13 = getelementptr inbounds nuw i8, ptr %5, i16 3
  %14 = getelementptr inbounds nuw i8, ptr %5, i16 4
  %15 = getelementptr inbounds nuw i8, ptr %5, i16 5
  %16 = getelementptr inbounds nuw i8, ptr %5, i16 6
  br label %17

17:                                               ; preds = %10, %86
  %18 = phi i8 [ %8, %10 ], [ %89, %86 ]
  %19 = phi i16 [ 0, %10 ], [ %87, %86 ]
  %20 = phi i8 [ 0, %10 ], [ %88, %86 ]
  %21 = zext i8 %20 to i16
  %22 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %21
  %23 = getelementptr inbounds nuw i8, ptr %22, i16 10
  %24 = load i8, ptr %23, align 1, !tbaa !45
  switch i8 %24, label %44 [
    i8 3, label %25
    i8 4, label %34
  ]

25:                                               ; preds = %17
  %26 = load i16, ptr %22, align 1, !tbaa !47
  %27 = inttoptr i16 %26 to ptr
  %28 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %29 = load i16, ptr %28, align 1, !tbaa !51
  %30 = trunc i16 %29 to i8
  store volatile i8 %30, ptr %27, align 1, !tbaa !6
  %31 = load i16, ptr %28, align 1, !tbaa !51
  %32 = lshr i16 %31, 8
  %33 = trunc nuw i16 %32 to i8
  store volatile i8 %33, ptr %27, align 1, !tbaa !6
  br label %86

34:                                               ; preds = %17
  %35 = load i16, ptr %22, align 1, !tbaa !47
  %36 = inttoptr i16 %35 to ptr
  %37 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %38 = load i16, ptr %37, align 1, !tbaa !51
  %39 = trunc i16 %38 to i8
  store volatile i8 %39, ptr %36, align 1, !tbaa !6
  %40 = load i16, ptr %37, align 1, !tbaa !51
  %41 = lshr i16 %40, 8
  %42 = trunc nuw i16 %41 to i8
  %43 = getelementptr inbounds nuw i8, ptr %36, i16 1
  store volatile i8 %42, ptr %43, align 1, !tbaa !6
  br label %86

44:                                               ; preds = %17
  %45 = icmp eq i16 %19, 0
  br i1 %45, label %51, label %46

46:                                               ; preds = %44
  %47 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %48 = load i16, ptr %47, align 1, !tbaa !53
  %49 = add i16 %48, %19
  %50 = icmp ugt i16 %49, 5100
  br i1 %50, label %91, label %51

51:                                               ; preds = %46, %44
  switch i8 %24, label %59 [
    i8 0, label %52
    i8 1, label %56
  ]

52:                                               ; preds = %51
  %53 = getelementptr inbounds nuw i8, ptr %22, i16 9
  %54 = load i8, ptr %53, align 1, !tbaa !48
  store volatile i8 %54, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  %55 = load i16, ptr %22, align 1, !tbaa !47
  store volatile i16 %55, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %65

56:                                               ; preds = %51
  %57 = load i16, ptr %22, align 1, !tbaa !47
  %58 = trunc i16 %57 to i8
  store volatile i8 %58, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  br label %65

59:                                               ; preds = %51
  %60 = load i16, ptr %22, align 1, !tbaa !47
  %61 = trunc i16 %60 to i8
  store volatile i8 %61, ptr inttoptr (i16 8450 to ptr), align 2, !tbaa !6
  %62 = load i16, ptr %22, align 1, !tbaa !47
  %63 = lshr i16 %62, 8
  %64 = trunc nuw i16 %63 to i8
  store volatile i8 %64, ptr inttoptr (i16 8451 to ptr), align 1, !tbaa !6
  br label %65

65:                                               ; preds = %56, %59, %52
  %66 = getelementptr inbounds nuw i8, ptr %22, i16 8
  %67 = load i8, ptr %66, align 1, !tbaa !50
  store volatile i8 %67, ptr %5, align 16, !tbaa !6
  %68 = getelementptr inbounds nuw i8, ptr %22, i16 7
  %69 = load i8, ptr %68, align 1, !tbaa !49
  store volatile i8 %69, ptr %11, align 1, !tbaa !6
  %70 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %71 = load i16, ptr %70, align 1, !tbaa !51
  %72 = trunc i16 %71 to i8
  store volatile i8 %72, ptr %12, align 2, !tbaa !6
  %73 = load i16, ptr %70, align 1, !tbaa !51
  %74 = lshr i16 %73, 8
  %75 = trunc nuw i16 %74 to i8
  store volatile i8 %75, ptr %13, align 1, !tbaa !6
  %76 = getelementptr inbounds nuw i8, ptr %22, i16 6
  %77 = load i8, ptr %76, align 1, !tbaa !52
  store volatile i8 %77, ptr %14, align 4, !tbaa !6
  %78 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %79 = load i16, ptr %78, align 1, !tbaa !53
  %80 = trunc i16 %79 to i8
  store volatile i8 %80, ptr %15, align 1, !tbaa !6
  %81 = load i16, ptr %78, align 1, !tbaa !53
  %82 = lshr i16 %81, 8
  %83 = trunc nuw i16 %82 to i8
  store volatile i8 %83, ptr %16, align 2, !tbaa !6
  store volatile i8 %7, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !6
  %84 = load i16, ptr %78, align 1, !tbaa !53
  %85 = add i16 %84, %19
  br label %86

86:                                               ; preds = %65, %34, %25
  %87 = phi i16 [ %19, %25 ], [ %19, %34 ], [ %85, %65 ]
  %88 = add nuw i8 %20, 1
  %89 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %90 = icmp ult i8 %88, %89
  br i1 %90, label %17, label %91

91:                                               ; preds = %86, %46
  %92 = phi i8 [ %89, %86 ], [ %18, %46 ]
  %93 = phi i8 [ %88, %86 ], [ %20, %46 ]
  %94 = icmp ult i8 %93, %92
  br i1 %94, label %95, label %108

95:                                               ; preds = %91
  %96 = icmp eq i8 %93, 0
  br i1 %96, label %110, label %97

97:                                               ; preds = %95, %97
  %98 = phi i8 [ %101, %97 ], [ 0, %95 ]
  %99 = phi i8 [ %104, %97 ], [ %93, %95 ]
  %100 = zext i8 %99 to i16
  %101 = add i8 %98, 1
  %102 = zext i8 %98 to i16
  %103 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %102
  %104 = add nuw i8 %99, 1
  %105 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %100
  tail call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(11) %103, ptr noundef nonnull align 1 dereferenceable(11) %105, i16 11, i1 false), !tbaa.struct !144
  %106 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %107 = icmp ult i8 %104, %106
  br i1 %107, label %97, label %108, !llvm.loop !145

108:                                              ; preds = %97, %91, %0
  %109 = phi i8 [ 0, %91 ], [ 0, %0 ], [ %101, %97 ]
  store i8 %109, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  br label %110

110:                                              ; preds = %108, %95
  ret void
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare range(i16 -1, 2) i16 @llvm.scmp.i16.i32(i32, i32) #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare range(i16 -1, 2) i16 @llvm.scmp.i16.i64(i64, i64) #11

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #12

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.umax.i16(i16, i16) #11

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #1 = { nofree norecurse nosync nounwind optsize memory(read, argmem: write, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { nofree norecurse nosync nounwind optsize memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #4 = { nofree norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #5 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #6 = { nofree norecurse nosync nounwind optsize memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #7 = { nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #8 = { mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #9 = { nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #10 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #11 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #13 = { nounwind optsize }
attributes #14 = { optsize }
attributes #15 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!10, !4, i64 194}
!10 = !{!"", !11, i64 0, !12, i64 178, !13, i64 182, !4, i64 191, !4, i64 192, !4, i64 193, !4, i64 194, !4, i64 195}
!11 = !{!"", !4, i64 0, !4, i64 176, !4, i64 177}
!12 = !{!"", !3, i64 0, !3, i64 2}
!13 = !{!"", !4, i64 0, !4, i64 8}
!14 = !{!10, !4, i64 195}
!15 = !{!16, !18, i64 0}
!16 = !{!"", !17, i64 0, !4, i64 3, !3, i64 4099, !3, i64 4101, !3, i64 4103, !3, i64 4105, !4, i64 4107, !4, i64 4108}
!17 = !{!"Drawable", !18, i64 0, !4, i64 2}
!18 = !{!"any pointer", !4, i64 0}
!19 = !{!16, !4, i64 2}
!20 = !{!16, !3, i64 4103}
!21 = !{!16, !3, i64 4105}
!22 = !{!16, !4, i64 4107}
!23 = !{!16, !4, i64 4108}
!24 = !{!16, !3, i64 4099}
!25 = !{!16, !3, i64 4101}
!26 = !{!27, !18, i64 0}
!27 = !{!"", !17, i64 0, !3, i64 3, !4, i64 5, !4, i64 7, !4, i64 135}
!28 = !{!27, !4, i64 2}
!29 = !{!27, !3, i64 3}
!30 = distinct !{!30, !8}
!31 = !{!27, !4, i64 135}
!32 = !{!10, !4, i64 192}
!33 = !{!10, !4, i64 193}
!34 = !{!13, !4, i64 8}
!35 = !{!36, !36, i64 0}
!36 = !{!"p1 _ZTS8Drawable", !18, i64 0}
!37 = distinct !{null, null}
!38 = !{!10, !4, i64 191}
!39 = !{!17, !4, i64 2}
!40 = !{!17, !18, i64 0}
!41 = !{!42, !18, i64 0}
!42 = !{!"", !18, i64 0, !18, i64 2}
!43 = distinct !{null, null, null}
!44 = !{!11, !4, i64 176}
!45 = !{!46, !4, i64 10}
!46 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !4, i64 6, !4, i64 7, !4, i64 8, !4, i64 9, !4, i64 10}
!47 = !{!46, !3, i64 0}
!48 = !{!46, !4, i64 9}
!49 = !{!46, !4, i64 7}
!50 = !{!46, !4, i64 8}
!51 = !{!46, !3, i64 2}
!52 = !{!46, !4, i64 6}
!53 = !{!46, !3, i64 4}
!54 = !{!55, !3, i64 4500}
!55 = !{!"", !10, i64 0, !16, i64 196, !27, i64 4305, !56, i64 4441, !4, i64 4492, !3, i64 4500, !3, i64 4502, !4, i64 4504}
!56 = !{!"", !4, i64 0, !4, i64 50}
!57 = !{!55, !3, i64 4502}
!58 = !{!55, !4, i64 4504}
!59 = distinct !{!59, !8}
!60 = distinct !{!60, !8}
!61 = !{!62, !18, i64 0}
!62 = !{!"", !17, i64 0, !63, i64 3, !63, i64 5, !63, i64 7, !63, i64 9, !4, i64 11, !4, i64 12, !3, i64 13, !3, i64 15, !3, i64 17, !3, i64 19, !3, i64 21, !3, i64 23, !4, i64 25, !3, i64 26, !4, i64 28, !4, i64 29, !4, i64 30, !4, i64 31, !4, i64 32, !4, i64 33, !3, i64 34, !3, i64 36, !56, i64 38, !56, i64 89}
!63 = !{!"p1 omnipotent char", !18, i64 0}
!64 = !{!62, !4, i64 2}
!65 = !{!62, !63, i64 3}
!66 = !{!62, !63, i64 5}
!67 = !{!62, !63, i64 7}
!68 = !{!62, !4, i64 11}
!69 = !{!62, !63, i64 9}
!70 = !{!62, !4, i64 12}
!71 = !{!62, !3, i64 13}
!72 = !{!62, !3, i64 15}
!73 = !{!62, !3, i64 17}
!74 = !{!62, !4, i64 28}
!75 = !{!62, !4, i64 29}
!76 = !{!62, !4, i64 31}
!77 = !{!62, !4, i64 32}
!78 = !{!62, !4, i64 30}
!79 = !{!62, !4, i64 25}
!80 = !{!62, !3, i64 34}
!81 = !{!62, !3, i64 36}
!82 = !{!62, !4, i64 33}
!83 = !{!42, !18, i64 2}
!84 = distinct !{null, null, null, null, null}
!85 = distinct !{!85, !8}
!86 = distinct !{!86, !8}
!87 = distinct !{!87, !8}
!88 = distinct !{null, null, null, null}
!89 = distinct !{!89, !8}
!90 = !{!91, !91, i64 0}
!91 = !{!"long", !4, i64 0}
!92 = distinct !{!92, !8}
!93 = distinct !{!93, !8}
!94 = !{!95, !95, i64 0}
!95 = !{!"long long", !4, i64 0}
!96 = distinct !{!96, !8}
!97 = distinct !{!97, !8}
!98 = distinct !{!98, !8}
!99 = distinct !{!99, !8}
!100 = distinct !{!100, !8}
!101 = distinct !{null, null, null, null, null}
!102 = distinct !{!102, !8}
!103 = distinct !{!103, !8}
!104 = distinct !{null, null, null, null}
!105 = !{!62, !3, i64 19}
!106 = distinct !{null, null, null, null, null}
!107 = !{!56, !4, i64 50}
!108 = distinct !{!108, !8}
!109 = distinct !{!109, !8}
!110 = distinct !{null, null, null}
!111 = distinct !{!111, !8}
!112 = distinct !{!112, !8}
!113 = distinct !{!113, !8}
!114 = !{!55, !3, i64 4295}
!115 = distinct !{!115, !8}
!116 = distinct !{!116, !8}
!117 = !{!55, !3, i64 4297}
!118 = distinct !{!118, !8}
!119 = distinct !{!119, !8}
!120 = distinct !{!120, !8}
!121 = distinct !{!121, !8}
!122 = distinct !{!122, !8}
!123 = distinct !{!123, !8}
!124 = distinct !{!124, !8}
!125 = distinct !{!125, !8}
!126 = distinct !{!126, !8}
!127 = distinct !{!127, !8}
!128 = distinct !{!128, !8}
!129 = distinct !{!129, !8}
!130 = distinct !{!130, !8}
!131 = distinct !{!131, !8}
!132 = distinct !{!132, !8}
!133 = !{!62, !3, i64 21}
!134 = !{!62, !3, i64 23}
!135 = distinct !{!135, !8}
!136 = !{!62, !3, i64 26}
!137 = distinct !{!137, !8}
!138 = distinct !{!138, !8}
!139 = !{!140, !18, i64 0}
!140 = !{!"", !18, i64 0, !4, i64 2}
!141 = !{!140, !4, i64 2}
!142 = distinct !{!142, !8}
!143 = !{!11, !4, i64 177}
!144 = !{i64 0, i64 2, !2, i64 2, i64 2, !2, i64 4, i64 2, !2, i64 6, i64 1, !6, i64 7, i64 1, !6, i64 8, i64 1, !6, i64 9, i64 1, !6, i64 10, i64 1, !6}
!145 = distinct !{!145, !8}
