; ModuleID = '/work/examples/snes/corpus/keycmp64_sim.c'
source_filename = "/work/examples/snes/corpus/keycmp64_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.KCRec = type { i64, i64, i16 }

@corpus_result = dso_local global i16 0, align 1
@_kc = internal global [24 x %struct.KCRec] zeroinitializer, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %1, %0
  %2 = phi i16 [ 31324, %0 ], [ %7, %1 ]
  %3 = phi i16 [ 0, %0 ], [ %27, %1 ]
  %4 = mul i16 %2, 25173
  %5 = add i16 %4, 13849
  %6 = mul i16 %5, 25173
  %7 = add i16 %6, 13849
  %8 = urem i16 %5, 7
  %9 = zext nneg i16 %8 to i32
  %10 = add nsw i32 %9, -3
  %11 = sext i32 %10 to i64
  %12 = getelementptr inbounds nuw [18 x i8], ptr @_kc, i16 %3
  store i64 %11, ptr %12, align 1, !tbaa !6
  %13 = zext i16 %5 to i64
  %14 = shl nuw i64 %13, 48
  %15 = zext i16 %7 to i64
  %16 = shl nuw nsw i64 %15, 32
  %17 = or disjoint i64 %16, %14
  %18 = xor i16 %7, %5
  %19 = zext i16 %18 to i64
  %20 = shl nuw nsw i64 %19, 16
  %21 = or disjoint i64 %17, %20
  %22 = add i16 %7, %5
  %23 = zext i16 %22 to i64
  %24 = or disjoint i64 %21, %23
  %25 = getelementptr inbounds nuw i8, ptr %12, i16 8
  store i64 %24, ptr %25, align 1, !tbaa !9
  %26 = getelementptr inbounds nuw i8, ptr %12, i16 16
  store i16 %3, ptr %26, align 1, !tbaa !10
  %27 = add nuw nsw i16 %3, 1
  %28 = icmp eq i16 %27, 24
  br i1 %28, label %29, label %1, !llvm.loop !11

29:                                               ; preds = %1
  tail call void @qsort(ptr noundef nonnull @_kc, i16 noundef 24, i16 noundef 18, ptr noundef nonnull @kc_cmp) #4
  br label %30

30:                                               ; preds = %30, %29
  %31 = phi i16 [ 0, %29 ], [ %54, %30 ]
  %32 = phi i16 [ 0, %29 ], [ %55, %30 ]
  %33 = getelementptr inbounds nuw [18 x i8], ptr @_kc, i16 %32
  %34 = load i64, ptr %33, align 1, !tbaa !6
  %35 = getelementptr inbounds nuw i8, ptr %33, i16 8
  %36 = load i64, ptr %35, align 1, !tbaa !9
  %37 = lshr i64 %34, 16
  %38 = lshr i64 %34, 32
  %39 = lshr i64 %34, 48
  %40 = xor i64 %37, %38
  %41 = xor i64 %40, %39
  %42 = xor i64 %41, %34
  %43 = trunc i64 %42 to i16
  %44 = tail call i16 @llvm.fshl.i16(i16 %31, i16 %31, i16 1)
  %45 = xor i16 %44, %43
  %46 = lshr i64 %36, 16
  %47 = lshr i64 %36, 32
  %48 = lshr i64 %36, 48
  %49 = xor i64 %46, %47
  %50 = xor i64 %49, %48
  %51 = xor i64 %50, %36
  %52 = trunc i64 %51 to i16
  %53 = tail call i16 @llvm.fshl.i16(i16 %45, i16 %45, i16 1)
  %54 = xor i16 %53, %52
  %55 = add nuw nsw i16 %32, 1
  %56 = icmp eq i16 %55, 24
  br i1 %56, label %57, label %30, !llvm.loop !13

57:                                               ; preds = %30
  store volatile i16 %54, ptr @corpus_result, align 1, !tbaa !2
  br label %58

58:                                               ; preds = %58, %57
  tail call void asm sideeffect "wai", ""() #5, !srcloc !14
  br label %58
}

; Function Attrs: optsize
declare dso_local void @qsort(ptr noundef, i16 noundef, i16 noundef, ptr noundef) local_unnamed_addr #1

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: read)
define internal range(i16 -1, 2) i16 @kc_cmp(ptr noundef readonly captures(none) %0, ptr noundef readonly captures(none) %1) #2 {
  %3 = load i64, ptr %0, align 1, !tbaa !6
  %4 = load i64, ptr %1, align 1, !tbaa !6
  %5 = icmp eq i64 %3, %4
  br i1 %5, label %8, label %6

6:                                                ; preds = %2
  %7 = tail call i16 @llvm.scmp.i16.i64(i64 %3, i64 %4)
  br label %14

8:                                                ; preds = %2
  %9 = getelementptr inbounds nuw i8, ptr %0, i16 8
  %10 = load i64, ptr %9, align 1, !tbaa !9
  %11 = getelementptr inbounds nuw i8, ptr %1, i16 8
  %12 = load i64, ptr %11, align 1, !tbaa !9
  %13 = tail call i16 @llvm.scmp.i16.i64(i64 %10, i64 %12)
  br label %14

14:                                               ; preds = %8, %6
  %15 = phi i16 [ %7, %6 ], [ %13, %8 ]
  ret i16 %15
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare range(i16 -1, 2) i16 @llvm.scmp.i16.i64(i64, i64) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #3

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #2 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: read) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind optsize }
attributes #5 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !8, i64 0}
!7 = !{!"", !8, i64 0, !8, i64 8, !3, i64 16}
!8 = !{!"long long", !4, i64 0}
!9 = !{!7, !8, i64 8}
!10 = !{!7, !3, i64 16}
!11 = distinct !{!11, !12}
!12 = !{!"llvm.loop.mustprogress"}
!13 = distinct !{!13, !12}
!14 = !{i64 644}
