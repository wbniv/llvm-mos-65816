; ModuleID = '/work/examples/snes/mulov64.c'
source_filename = "/work/examples/snes/mulov64.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.App = type { %struct.Display, %struct.BitmapCanvas, %struct.TextLayer, [6 x %struct.MOrbiter], i16 }
%struct.Display = type { %struct.UploadQueue, %struct.VramAlloc, %struct.Scene, i8, i8, i8, i8, i8 }
%struct.UploadQueue = type { [16 x %struct.UpqJob], i8, i8 }
%struct.UpqJob = type { i16, i16, i16, i8, i8, i8, i8, i8 }
%struct.VramAlloc = type { i16, i16 }
%struct.Scene = type { [4 x ptr], i8 }
%struct.BitmapCanvas = type { %struct.Drawable, [4096 x i8], i16, i16, i16, i16, i8, i8 }
%struct.Drawable = type { ptr, i8 }
%struct.TextLayer = type { %struct.Drawable, i16, [2 x i8], [64 x i16], i8 }
%struct.MOrbiter = type { i8, i8, i8, i8, i8, i64 }
%struct.TitleLayer = type { %struct.Drawable, ptr, ptr, ptr, ptr, i8, i8, i16, i16, i16, i16, i16, i16, i8, i16, i8, i8, i8, i8, i8, i8, i16, i16, %struct.HScrollDB, %struct.HScrollDB }
%struct.HScrollDB = type { [2 x %struct.HScrollN], i8 }
%struct.HScrollN = type { [25 x i8] }
%struct.DrawableVT = type { ptr, ptr }
%struct.HScrollW = type { ptr, i8 }

@main.a = internal global %struct.App zeroinitializer, align 1
@main.title = internal global %struct.TitleLayer zeroinitializer, align 1
@.str = private unnamed_addr constant [8 x i8] c"MULO 64\00", align 1
@.str.1 = private unnamed_addr constant [20 x i8] c"64-BIT MUL OVERFLOW\00", align 1
@corpus_result = dso_local global i16 0, align 1
@bg3_pal = internal constant [4 x i16] [i16 0, i16 18564, i16 29126, i16 2655], align 1
@.str.2 = private unnamed_addr constant [22 x i8] c"MULO64  G_UMULH/SMULH\00", align 1
@CANVAS_VT = internal constant %struct.DrawableVT { ptr @_canvas_reserve, ptr @_canvas_emit }, align 1
@TEXT_VT = internal constant %struct.DrawableVT { ptr @_text_reserve, ptr @_text_emit }, align 1
@FONT8 = internal unnamed_addr constant [512 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 32, i16 0, i16 80, i16 80, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 80, i16 80, i16 248, i16 80, i16 248, i16 80, i16 80, i16 0, i16 32, i16 120, i16 160, i16 112, i16 40, i16 240, i16 32, i16 0, i16 196, i16 200, i16 16, i16 32, i16 64, i16 152, i16 12, i16 0, i16 96, i16 144, i16 160, i16 64, i16 168, i16 144, i16 104, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 16, i16 32, i16 64, i16 64, i16 64, i16 32, i16 16, i16 0, i16 64, i16 32, i16 16, i16 16, i16 16, i16 32, i16 64, i16 0, i16 0, i16 32, i16 168, i16 112, i16 168, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 248, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 64, i16 0, i16 0, i16 0, i16 248, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 0, i16 8, i16 8, i16 16, i16 32, i16 64, i16 128, i16 128, i16 0, i16 112, i16 136, i16 152, i16 168, i16 200, i16 136, i16 112, i16 0, i16 32, i16 96, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 64, i16 248, i16 0, i16 112, i16 136, i16 8, i16 48, i16 8, i16 136, i16 112, i16 0, i16 16, i16 48, i16 80, i16 144, i16 248, i16 16, i16 16, i16 0, i16 248, i16 128, i16 240, i16 8, i16 8, i16 136, i16 112, i16 0, i16 112, i16 136, i16 128, i16 240, i16 136, i16 136, i16 112, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 64, i16 64, i16 0, i16 112, i16 136, i16 136, i16 112, i16 136, i16 136, i16 112, i16 0, i16 112, i16 136, i16 136, i16 120, i16 8, i16 136, i16 112, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 64, i16 0, i16 16, i16 32, i16 64, i16 128, i16 64, i16 32, i16 16, i16 0, i16 0, i16 0, i16 248, i16 0, i16 248, i16 0, i16 0, i16 0, i16 128, i16 64, i16 32, i16 16, i16 32, i16 64, i16 128, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 0, i16 32, i16 0, i16 112, i16 136, i16 184, i16 168, i16 184, i16 128, i16 112, i16 0, i16 112, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 240, i16 136, i16 136, i16 240, i16 136, i16 136, i16 240, i16 0, i16 112, i16 136, i16 128, i16 128, i16 128, i16 136, i16 112, i16 0, i16 224, i16 144, i16 136, i16 136, i16 136, i16 144, i16 224, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 248, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 128, i16 176, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 112, i16 32, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 56, i16 16, i16 16, i16 16, i16 144, i16 144, i16 96, i16 0, i16 136, i16 144, i16 160, i16 192, i16 160, i16 144, i16 136, i16 0, i16 128, i16 128, i16 128, i16 128, i16 128, i16 128, i16 248, i16 0, i16 136, i16 216, i16 168, i16 136, i16 136, i16 136, i16 136, i16 0, i16 136, i16 200, i16 168, i16 152, i16 136, i16 136, i16 136, i16 0, i16 112, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 240, i16 136, i16 136, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 136, i16 136, i16 168, i16 144, i16 104, i16 0, i16 240, i16 136, i16 136, i16 240, i16 160, i16 144, i16 136, i16 0, i16 112, i16 136, i16 128, i16 112, i16 8, i16 136, i16 112, i16 0, i16 248, i16 32, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 80, i16 32, i16 0, i16 136, i16 136, i16 136, i16 168, i16 168, i16 216, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 80, i16 136, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 32, i16 32, i16 32, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 128, i16 248, i16 0, i16 48, i16 32, i16 32, i16 32, i16 32, i16 32, i16 48, i16 0, i16 128, i16 128, i16 64, i16 32, i16 16, i16 8, i16 8, i16 0, i16 48, i16 16, i16 16, i16 16, i16 16, i16 16, i16 48, i16 0, i16 32, i16 80, i16 136, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248], align 1
@TITLE_VT = internal constant %struct.DrawableVT { ptr @_title_reserve, ptr @_title_emit }, align 1
@FONT16 = internal unnamed_addr constant [2048 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 192, i16 192, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 768, i16 768, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 -4096, i16 -4096, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3840, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 3312, i16 15360, i16 15360, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 28, i16 28, i16 796, i16 127, i16 127, i16 796, i16 796, i16 127, i16 112, i16 112, i16 3184, i16 252, i16 252, i16 -28816, i16 -28816, i16 252, i16 127, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 0, i16 0, i16 252, i16 -28816, i16 -28816, i16 3184, i16 7168, i16 7168, i16 0, i16 0, i16 3, i16 63, i16 123, i16 1147, i16 63, i16 4111, i16 3075, i16 123, i16 192, i16 248, i16 8414, i16 16064, i16 2040, i16 248, i16 8414, i16 8414, i16 63, i16 7171, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 2040, i16 14272, i16 -512, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3585, i16 3, i16 7, i16 28, i16 56, i16 1904, i16 3808, i16 7392, i16 14528, i16 14464, i16 28672, i16 14, i16 284, i16 824, i16 1792, i16 3584, i16 0, i16 0, i16 0, i16 -8162, i16 -16354, i16 -32482, i16 286, i16 1792, i16 1792, i16 0, i16 0, i16 15, i16 31, i16 828, i16 828, i16 573, i16 31, i16 31, i16 63, i16 192, i16 224, i16 240, i16 2288, i16 7392, i16 15488, i16 30720, i16 -32648, i16 382, i16 3060, i16 3825, i16 1275, i16 127, i16 63, i16 7936, i16 3840, i16 248, i16 3824, i16 7904, i16 7392, i16 4332, i16 12492, i16 -1280, i16 -3328, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 7, i16 15, i16 15, i16 15, i16 15, i16 15, i16 240, i16 192, i16 15488, i16 -4096, i16 -8192, i16 -16384, i16 -16384, i16 -16384, i16 15, i16 7, i16 3, i16 256, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 16512, i16 192, i16 240, i16 -4096, i16 15360, i16 0, i16 0, i16 15, i16 3, i16 513, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 224, i16 240, i16 2288, i16 3312, i16 3312, i16 3312, i16 0, i16 1, i16 3, i16 15, i16 0, i16 768, i16 0, i16 0, i16 3312, i16 7392, i16 15552, i16 30720, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 51, i16 31, i16 15, i16 1027, i16 0, i16 0, i16 192, i16 192, i16 12492, i16 252, i16 1016, i16 16320, i16 15, i16 31, i16 51, i16 1027, i16 3072, i16 0, i16 0, i16 0, i16 1784, i16 252, i16 13004, i16 16320, i16 -3328, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 3, i16 63, i16 63, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 248, i16 248, i16 63, i16 3075, i16 3075, i16 3, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 16064, i16 16064, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 286, i16 828, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 28800, i16 -4096, i16 -8192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 -512, i16 -512, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7360, i16 14464, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7168, i16 14336, i16 28672, i16 -8192, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 828, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 15, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 1, i16 3, i16 15, i16 15, i16 513, i16 513, i16 1, i16 1, i16 240, i16 240, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 1, i16 1, i16 1, i16 1, i16 1, i16 1, i16 0, i16 0, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 31744, i16 31744, i16 15, i16 31, i16 318, i16 828, i16 3840, i16 3840, i16 3, i16 15, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 63, i16 510, i16 4080, i16 31, i16 318, i16 318, i16 318, i16 63, i16 63, i16 3840, i16 3840, i16 32640, i16 -1024, i16 -8192, i16 -32768, i16 255, i16 255, i16 -256, i16 -256, i16 15, i16 63, i16 824, i16 3840, i16 2055, i16 7, i16 256, i16 256, i16 252, i16 254, i16 -8161, i16 -4081, i16 510, i16 1020, i16 -7906, i16 -4081, i16 0, i16 0, i16 56, i16 60, i16 63, i16 31, i16 3840, i16 1792, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 15, i16 286, i16 62, i16 126, i16 510, i16 510, i16 8670, i16 24990, i16 -7906, i16 -7906, i16 828, i16 828, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 -16098, i16 -32482, i16 255, i16 255, i16 -7906, i16 -7906, i16 1792, i16 1792, i16 31, i16 63, i16 828, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 254, i16 254, i16 -256, i16 -256, i16 252, i16 254, i16 -8161, i16 -4081, i16 0, i16 0, i16 60, i16 62, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 63, i16 63, i16 318, i16 828, i16 254, i16 255, i16 -2041, i16 -256, i16 508, i16 254, i16 -4081, i16 -2041, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 -32761, i16 7, i16 7, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 31, i16 318, i16 892, i16 0, i16 1, i16 3, i16 7, i16 7, i16 7, i16 256, i16 256, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 28800, i16 -8192, i16 -8192, i16 15, i16 31, i16 828, i16 828, i16 828, i16 31, i16 15, i16 796, i16 252, i16 254, i16 -4081, i16 -4081, i16 15, i16 510, i16 1020, i16 -3826, i16 828, i16 828, i16 828, i16 828, i16 31, i16 15, i16 1792, i16 768, i16 -4081, i16 15, i16 15, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 318, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 31, i16 31, i16 15, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 270, i16 796, i16 824, i16 1792, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 15, i16 60, i16 828, i16 0, i16 0, i16 60, i16 240, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 15360, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 60, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 60, i16 0, i16 3, i16 15, i16 60, i16 768, i16 3840, i16 0, i16 0, i16 4080, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 31, i16 63, i16 828, i16 3840, i16 3840, i16 7, i16 7, i16 7, i16 240, i16 248, i16 -32644, i16 -32132, i16 2040, i16 4080, i16 16064, i16 31872, i16 256, i16 256, i16 7, i16 7, i16 7, i16 256, i16 256, i16 0, i16 -4096, i16 -8192, i16 128, i16 128, i16 24704, i16 -8192, i16 -8192, i16 0, i16 31, i16 63, i16 828, i16 573, i16 573, i16 573, i16 573, i16 573, i16 248, i16 252, i16 -15812, i16 4590, i16 494, i16 4590, i16 1020, i16 1016, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 0, i16 0, i16 0, i16 32512, i16 764, i16 248, i16 -256, i16 -512, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 892, i16 1020, i16 1020, i16 255, i16 255, i16 224, i16 240, i16 -32648, i16 -16324, i16 -32196, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -28928, i16 1792, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 0, i16 0, i16 28, i16 60, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -8164, i16 -3572, i16 -30976, i16 768, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 8988, i16 8988, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 60, i16 60, i16 828, i16 828, i16 828, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 255, i16 255, i16 16128, i16 16128, i16 12480, i16 12480, i16 12480, i16 12480, i16 252, i16 252, i16 -256, i16 -256, i16 63, i16 63, i16 3075, i16 3075, i16 3, i16 3, i16 51, i16 51, i16 252, i16 252, i16 4080, i16 4080, i16 3312, i16 3312, i16 3312, i16 3312, i16 3123, i16 3123, i16 63, i16 63, i16 31, i16 15, i16 1792, i16 768, i16 3312, i16 3312, i16 3312, i16 3312, i16 7392, i16 15552, i16 -2048, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 765, i16 255, i16 255, i16 255, i16 28, i16 60, i16 1912, i16 4080, i16 7904, i16 15552, i16 30848, i16 12480, i16 255, i16 765, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 224, i16 240, i16 248, i16 124, i16 572, i16 828, i16 3840, i16 3840, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 0, i16 0, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 248, i16 252, i16 254, i16 2295, i16 3315, i16 3315, i16 3315, i16 3315, i16 60, i16 124, i16 1020, i16 988, i16 9116, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 15360, i16 15360, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 -6400, i16 -6400, i16 240, i16 248, i16 252, i16 254, i16 255, i16 255, i16 2295, i16 3315, i16 60, i16 60, i16 828, i16 828, i16 828, i16 956, i16 1020, i16 1020, i16 3313, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 15360, i16 15360, i16 1020, i16 1020, i16 892, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -31972, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -512, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 224, i16 240, i16 -32648, i16 -15304, i16 -31176, i16 1592, i16 1592, i16 1592, i16 765, i16 765, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 1784, i16 1784, i16 17976, i16 1656, i16 764, i16 764, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 63, i16 127, i16 2040, i16 4080, i16 1784, i16 255, i16 127, i16 63, i16 248, i16 252, i16 -15812, i16 -256, i16 3840, i16 240, i16 248, i16 252, i16 7936, i16 3840, i16 224, i16 255, i16 255, i16 127, i16 16128, i16 7936, i16 -32132, i16 -15556, i16 892, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 -4096, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 28, i16 28, i16 796, i16 796, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 510, i16 255, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 828, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 248, i16 248, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 124, i16 124, i16 1912, i16 1912, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 572, i16 63, i16 31, i16 15, i16 7, i16 768, i16 256, i16 1656, i16 3824, i16 3824, i16 7392, i16 15552, i16 30848, i16 -4096, i16 -8192, i16 243, i16 243, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 156, i16 156, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 2295, i16 255, i16 510, i16 892, i16 16128, i16 7936, i16 25500, i16 25500, i16 9180, i16 1020, i16 1020, i16 -30856, i16 -16640, i16 7680, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 15, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 14528, i16 31, i16 63, i16 892, i16 2040, i16 4080, i16 3824, i16 15360, i16 15360, i16 4320, i16 240, i16 248, i16 -32644, i16 572, i16 828, i16 3840, i16 3840, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 7, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 7, i16 7, i16 7, i16 7, i16 7, i16 7, i16 256, i16 256, i16 28800, i16 24704, i16 24704, i16 24704, i16 24704, i16 24704, i16 -8192, i16 -8192, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 1, i16 3, i16 7, i16 252, i16 252, i16 1020, i16 -31876, i16 2040, i16 4080, i16 7904, i16 15552, i16 15, i16 31, i16 318, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 30848, i16 -4096, i16 -8192, i16 252, i16 252, i16 1020, i16 -256, i16 -256, i16 31, i16 31, i16 286, i16 286, i16 286, i16 286, i16 286, i16 286, i16 224, i16 224, i16 -2048, i16 -2048, i16 -32768, i16 -32768, i16 -32768, i16 -32768, i16 286, i16 286, i16 286, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 -32768, i16 -32768, i16 -32768, i16 224, i16 224, i16 -2048, i16 -2048, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 3, i16 1, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 128, i16 192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 768, i16 256, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 0, i16 0, i16 0, i16 224, i16 224, i16 2288, i16 2288, i16 3312, i16 3312, i16 3312, i16 3312, i16 0, i16 0, i16 0, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 3312, i16 3312, i16 3312, i16 7392, i16 7392, i16 -2048, i16 -2048, i16 0, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1840, i16 3584, i16 3072, i16 192, i16 224, i16 -32656, i16 -16328, i16 -32740, i16 524, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 127, i16 127, i16 7936, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 -512], align 1
@title_end._title_bg_black = internal constant i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [21 x i8], align 1
  store volatile i8 -113, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  br label %2

2:                                                ; preds = %6, %0
  %3 = phi i16 [ 8449, %0 ], [ %7, %6 ]
  switch i16 %3, label %4 [
    i16 8452, label %6
    i16 8470, label %6
    i16 8471, label %6
    i16 8472, label %6
    i16 8473, label %6
    i16 8481, label %6
    i16 8482, label %6
  ]

4:                                                ; preds = %2
  %5 = inttoptr i16 %3 to ptr
  store volatile i8 0, ptr %5, align 1, !tbaa !6
  br label %6

6:                                                ; preds = %4, %2, %2, %2, %2, %2, %2, %2
  %7 = add nuw nsw i16 %3, 1
  %8 = icmp eq i16 %7, 8500
  br i1 %8, label %9, label %2, !llvm.loop !7

9:                                                ; preds = %6
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) getelementptr inbounds nuw (i8, ptr @main.a, i16 176), i8 0, i64 6, i1 false)
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  store volatile i8 1, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 -127, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !6
  store ptr @CANVAS_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), align 1, !tbaa !15
  store i8 4, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !19
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4299), align 1, !tbaa !20
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4301), align 1, !tbaa !21
  store i8 8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4303), align 1, !tbaa !22
  store i8 6, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4304), align 1, !tbaa !23
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(4096) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i16 4096, i1 false), !tbaa !6
  store i16 -1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  store ptr @TEXT_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !26
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !28
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4308), align 1, !tbaa !29
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4310), align 1, !tbaa !6
  store i8 25, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4311), align 1, !tbaa !6
  br label %10

10:                                               ; preds = %10, %9
  %11 = phi i8 [ 0, %9 ], [ %17, %10 ]
  %12 = phi i16 [ 0, %9 ], [ %15, %10 ]
  %13 = zext i8 %11 to i16
  %14 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4312), i16 %13
  store i16 256, ptr %14, align 1, !tbaa !2
  %15 = add nuw nsw i16 %12, 1
  %16 = icmp eq i16 %15, 64
  %17 = add nuw i8 %11, 2
  br i1 %16, label %18, label %10, !llvm.loop !30

18:                                               ; preds = %10
  store i8 3, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %19 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %20 = icmp eq i8 %19, 0
  br i1 %20, label %22, label %21

21:                                               ; preds = %18
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %22

22:                                               ; preds = %21, %18
  %23 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %24 = icmp ult i8 %23, 4
  br i1 %24, label %25, label %29

25:                                               ; preds = %22
  %26 = zext nneg i8 %23 to i16
  %27 = add nuw nsw i8 %23, 1
  store i8 %27, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %28 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %26
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr %28, align 1, !tbaa !35
  br label %29

29:                                               ; preds = %25, %22
  tail call void @_canvas_reserve(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr nonnull poison) #12, !inline_history !37
  %30 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %31 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !39
  %32 = or i8 %31, %30
  store i8 %32, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %32, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %33 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %34 = icmp eq i8 %33, 0
  br i1 %34, label %36, label %35

35:                                               ; preds = %29
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %36

36:                                               ; preds = %35, %29
  %37 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %38 = icmp ult i8 %37, 4
  br i1 %38, label %39, label %43

39:                                               ; preds = %36
  %40 = zext nneg i8 %37 to i16
  %41 = add nuw nsw i8 %37, 1
  store i8 %41, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %42 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %40
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr %42, align 1, !tbaa !35
  br label %43

43:                                               ; preds = %39, %36
  %44 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !40
  %45 = load ptr, ptr %44, align 1, !tbaa !41
  tail call void %45(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 178)) #12, !inline_history !43
  %46 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %47 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !39
  %48 = or i8 %47, %46
  store i8 %48, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %48, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %49 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %50 = icmp ugt i8 %49, 15
  br i1 %50, label %62, label %51

51:                                               ; preds = %43
  %52 = zext nneg i8 %49 to i16
  %53 = add nuw nsw i8 %49, 1
  store i8 %53, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %54 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %52
  %55 = getelementptr inbounds nuw i8, ptr %54, i16 10
  store i8 1, ptr %55, align 1, !tbaa !45
  store i16 0, ptr %54, align 1, !tbaa !47
  %56 = getelementptr inbounds nuw i8, ptr %54, i16 9
  store i8 0, ptr %56, align 1, !tbaa !48
  %57 = getelementptr inbounds nuw i8, ptr %54, i16 7
  store i8 34, ptr %57, align 1, !tbaa !49
  %58 = getelementptr inbounds nuw i8, ptr %54, i16 8
  store i8 0, ptr %58, align 1, !tbaa !50
  %59 = getelementptr inbounds nuw i8, ptr %54, i16 2
  store i16 ptrtoint (ptr @bg3_pal to i16), ptr %59, align 1, !tbaa !51
  %60 = getelementptr inbounds nuw i8, ptr %54, i16 6
  store i8 0, ptr %60, align 1, !tbaa !52
  %61 = getelementptr inbounds nuw i8, ptr %54, i16 4
  store i16 8, ptr %61, align 1, !tbaa !53
  br label %62

62:                                               ; preds = %51, %43
  br label %63

63:                                               ; preds = %62, %63
  %64 = phi i8 [ %86, %63 ], [ 0, %62 ]
  %65 = phi i8 [ %84, %63 ], [ 0, %62 ]
  %66 = mul nuw nsw i8 %65, 20
  %67 = add nuw nsw i8 %66, 8
  %68 = zext nneg i8 %64 to i16
  %69 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %68
  store i8 %67, ptr %69, align 1, !tbaa !54
  %70 = mul nuw nsw i8 %65, 15
  %71 = add nuw nsw i8 %70, 16
  %72 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4442), i16 %68
  store i8 %71, ptr %72, align 1, !tbaa !57
  %73 = and i8 %65, 3
  %74 = add nuw nsw i8 %73, 1
  %75 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), i16 %68
  store i8 %74, ptr %75, align 1, !tbaa !58
  %76 = lshr i8 %65, 1
  %77 = add nuw nsw i8 %76, 1
  %78 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4444), i16 %68
  store i8 %77, ptr %78, align 1, !tbaa !59
  %79 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4445), i16 %68
  store i8 0, ptr %79, align 1, !tbaa !60
  %80 = zext nneg i8 %65 to i64
  %81 = shl nuw nsw i64 %80, 20
  %82 = or disjoint i64 %81, 1099511627776
  %83 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4446), i16 %68
  store i64 %82, ptr %83, align 1, !tbaa !61
  %84 = add nuw nsw i8 %65, 1
  %85 = icmp eq i8 %84, 6
  %86 = add nuw nsw i8 %64, 13
  br i1 %85, label %87, label %63, !llvm.loop !62

87:                                               ; preds = %63
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4519), align 1, !tbaa !63
  br label %88

88:                                               ; preds = %98, %87
  %89 = phi i8 [ 0, %87 ], [ %106, %98 ]
  %90 = phi i8 [ 0, %87 ], [ %105, %98 ]
  %91 = phi i8 [ 77, %87 ], [ %104, %98 ]
  %92 = zext i8 %91 to i16
  %93 = icmp ugt i8 %91, 31
  br i1 %93, label %94, label %98

94:                                               ; preds = %88
  %95 = icmp ult i8 %91, 96
  br i1 %95, label %96, label %98

96:                                               ; preds = %94
  %97 = add nuw nsw i16 %92, 224
  br label %98

98:                                               ; preds = %96, %94, %88
  %99 = phi i16 [ %97, %96 ], [ 256, %94 ], [ 256, %88 ]
  %100 = zext nneg i8 %90 to i16
  %101 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4316), i16 %100
  store i16 %99, ptr %101, align 1, !tbaa !2
  %102 = zext nneg i8 %89 to i16
  %103 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @.str.2, i16 1), i16 %102
  %104 = load i8, ptr %103, align 1, !tbaa !6
  %105 = add nuw nsw i8 %90, 2
  %106 = add nuw nsw i8 %89, 1
  %107 = icmp eq i8 %106, 21
  br i1 %107, label %108, label %88, !llvm.loop !65

108:                                              ; preds = %98
  %109 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %110 = or i8 %109, 1
  store i8 %110, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  store ptr @TITLE_VT, ptr @main.title, align 1, !tbaa !66
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !70
  store ptr @.str, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 3), align 1, !tbaa !71
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 5), align 1, !tbaa !72
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 7), align 1, !tbaa !73
  br label %111

111:                                              ; preds = %113, %108
  %112 = phi i8 [ %114, %113 ], [ 16, %108 ]
  switch i8 %112, label %113 [
    i8 10, label %116
    i8 6, label %116
  ]

113:                                              ; preds = %111
  %114 = add nsw i8 %112, -1
  %115 = icmp eq i8 %114, 0
  br i1 %115, label %120, label %111, !llvm.loop !74

116:                                              ; preds = %111, %111
  %117 = zext nneg i8 %112 to i16
  %118 = getelementptr inbounds nuw i8, ptr @.str.1, i16 %117
  store i8 %112, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 11), align 1, !tbaa !75
  %119 = getelementptr inbounds nuw i8, ptr %118, i16 1
  br label %121

120:                                              ; preds = %113
  store i8 16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 11), align 1, !tbaa !75
  br label %121

121:                                              ; preds = %120, %116
  %122 = phi ptr [ getelementptr inbounds nuw (i8, ptr @.str.1, i16 16), %120 ], [ %119, %116 ]
  store ptr %122, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 9), align 1, !tbaa !76
  %123 = ptrtoint ptr %122 to i16
  %124 = trunc i16 %123 to i8
  %125 = sub i8 add (i8 ptrtoint (ptr @.str.1 to i8), i8 19), %124
  %126 = icmp ugt i8 %125, 16
  br i1 %126, label %128, label %127

127:                                              ; preds = %121
  br label %128

128:                                              ; preds = %127, %121
  %129 = phi i8 [ %125, %127 ], [ 16, %121 ]
  store i8 %129, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 12), align 1, !tbaa !77
  store i16 88, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 13), align 1, !tbaa !78
  store i16 104, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 15), align 1, !tbaa !79
  store i16 32, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 17), align 1, !tbaa !80
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 28), align 1, !tbaa !81
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !82
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !83
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !84
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !85
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !86
  store i16 32767, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 34), align 1, !tbaa !87
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 36), align 1, !tbaa !88
  %130 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %131 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %132 = icmp eq i8 %131, 0
  br i1 %132, label %134, label %133

133:                                              ; preds = %128
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %134

134:                                              ; preds = %133, %128
  %135 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %136 = icmp ult i8 %135, 4
  br i1 %136, label %137, label %141

137:                                              ; preds = %134
  %138 = zext nneg i8 %135 to i16
  %139 = add nuw nsw i8 %135, 1
  store i8 %139, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %140 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %138
  store ptr @main.title, ptr %140, align 1, !tbaa !35
  br label %141

141:                                              ; preds = %137, %134
  tail call void @_title_reserve(ptr noundef nonnull @main.title, ptr nonnull poison) #12, !inline_history !37
  %142 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %143 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %144 = or i8 %143, %142
  store volatile i8 %144, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store i8 %130, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !89
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 2, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 24, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  br label %145

145:                                              ; preds = %173, %141
  %146 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %147 = icmp eq i8 %146, 0
  br i1 %147, label %159, label %148

148:                                              ; preds = %145, %148
  %149 = phi i8 [ %156, %148 ], [ 0, %145 ]
  %150 = zext i8 %149 to i16
  %151 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %150
  %152 = load ptr, ptr %151, align 1, !tbaa !35
  %153 = load ptr, ptr %152, align 1, !tbaa !40
  %154 = getelementptr inbounds nuw i8, ptr %153, i16 2
  %155 = load ptr, ptr %154, align 1, !tbaa !90
  tail call void %155(ptr noundef nonnull %152, ptr noundef nonnull @main.a) #12, !inline_history !91
  %156 = add nuw i8 %149, 1
  %157 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %158 = icmp ult i8 %156, %157
  br i1 %158, label %148, label %159, !llvm.loop !92

159:                                              ; preds = %148, %145
  %160 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %161

161:                                              ; preds = %161, %159
  %162 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %163 = icmp sgt i8 %162, -1
  br i1 %163, label %161, label %164, !llvm.loop !93

164:                                              ; preds = %161
  tail call fastcc void @upq_flush() #13
  %165 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %166 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %167 = icmp ult i8 %165, %166
  br i1 %167, label %170, label %168

168:                                              ; preds = %164
  %169 = icmp ugt i8 %165, %166
  br i1 %169, label %170, label %173

170:                                              ; preds = %168, %164
  %171 = phi i8 [ 1, %164 ], [ -1, %168 ]
  %172 = add i8 %171, %165
  store i8 %172, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %173

173:                                              ; preds = %170, %168
  %174 = phi i8 [ %165, %168 ], [ %172, %170 ]
  %175 = and i8 %174, 15
  store volatile i8 %175, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %176 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %177 = icmp eq i8 %176, 15
  br i1 %177, label %178, label %145, !llvm.loop !94

178:                                              ; preds = %173
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !85
  %179 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !86
  %180 = icmp eq i8 %179, -1
  br i1 %180, label %218, label %181

181:                                              ; preds = %178, %210
  %182 = phi i8 [ %213, %210 ], [ 0, %178 ]
  %183 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %184 = icmp eq i8 %183, 0
  br i1 %184, label %196, label %185

185:                                              ; preds = %181, %185
  %186 = phi i8 [ %193, %185 ], [ 0, %181 ]
  %187 = zext i8 %186 to i16
  %188 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %187
  %189 = load ptr, ptr %188, align 1, !tbaa !35
  %190 = load ptr, ptr %189, align 1, !tbaa !40
  %191 = getelementptr inbounds nuw i8, ptr %190, i16 2
  %192 = load ptr, ptr %191, align 1, !tbaa !90
  tail call void %192(ptr noundef nonnull %189, ptr noundef nonnull @main.a) #12, !inline_history !95
  %193 = add nuw i8 %186, 1
  %194 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %195 = icmp ult i8 %193, %194
  br i1 %195, label %185, label %196, !llvm.loop !92

196:                                              ; preds = %185, %181
  %197 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %198

198:                                              ; preds = %198, %196
  %199 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %200 = icmp sgt i8 %199, -1
  br i1 %200, label %198, label %201, !llvm.loop !93

201:                                              ; preds = %198
  tail call fastcc void @upq_flush() #13
  %202 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %203 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %204 = icmp ult i8 %202, %203
  br i1 %204, label %207, label %205

205:                                              ; preds = %201
  %206 = icmp ugt i8 %202, %203
  br i1 %206, label %207, label %210

207:                                              ; preds = %205, %201
  %208 = phi i8 [ 1, %201 ], [ -1, %205 ]
  %209 = add i8 %208, %202
  store i8 %209, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %210

210:                                              ; preds = %207, %205
  %211 = phi i8 [ %202, %205 ], [ %209, %207 ]
  %212 = and i8 %211, 15
  store volatile i8 %212, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %213 = add nuw i8 %182, 1
  %214 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !86
  %215 = icmp ne i8 %214, -1
  %216 = icmp ult i8 %182, -57
  %217 = select i1 %215, i1 %216, i1 false
  br i1 %217, label %181, label %218, !llvm.loop !96

218:                                              ; preds = %210, %178
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !85
  br label %219

219:                                              ; preds = %243, %218
  %220 = phi i16 [ 0, %218 ], [ %250, %243 ]
  %221 = phi i16 [ 0, %218 ], [ %244, %243 ]
  %222 = phi i16 [ 0, %218 ], [ %251, %243 ]
  %223 = zext nneg i16 %222 to i64
  %224 = shl nuw nsw i64 %223, 25
  %225 = add nuw nsw i64 %224, 2147483648
  %226 = shl nuw nsw i64 %223, 26
  %227 = add nuw nsw i64 %226, 1073741824
  %228 = tail call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %225, i64 %227)
  %229 = extractvalue { i64, i1 } %228, 1
  %230 = extractvalue { i64, i1 } %228, 0
  %231 = shl nuw nsw i64 %223, 23
  %232 = sub nuw nsw i64 1879048192, %231
  %233 = shl nuw nsw i64 %223, 27
  %234 = add nuw nsw i64 %233, 536870912
  %235 = tail call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %232, i64 %234)
  %236 = extractvalue { i64, i1 } %235, 1
  br i1 %229, label %237, label %239

237:                                              ; preds = %219
  %238 = add i16 %221, 1
  br label %239

239:                                              ; preds = %237, %219
  %240 = phi i16 [ %238, %237 ], [ %221, %219 ]
  br i1 %236, label %241, label %243

241:                                              ; preds = %239
  %242 = add i16 %240, 1
  br label %243

243:                                              ; preds = %241, %239
  %244 = phi i16 [ %242, %241 ], [ %240, %239 ]
  %245 = lshr exact i64 %230, 48
  %246 = trunc nuw i64 %245 to i16
  %247 = mul i16 %244, 3
  %248 = tail call i16 @llvm.fshl.i16(i16 %220, i16 %220, i16 1)
  %249 = xor i16 %248, %246
  %250 = xor i16 %249, %247
  %251 = add nuw nsw i16 %222, 1
  %252 = icmp eq i16 %251, 121
  br i1 %252, label %253, label %219, !llvm.loop !97

253:                                              ; preds = %243
  store volatile i16 %250, ptr @corpus_result, align 1, !tbaa !2
  br label %254

254:                                              ; preds = %284, %253
  %255 = phi i16 [ 90, %253 ], [ %256, %284 ]
  %256 = add nsw i16 %255, -1
  %257 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %258 = icmp eq i8 %257, 0
  br i1 %258, label %270, label %259

259:                                              ; preds = %254, %259
  %260 = phi i8 [ %267, %259 ], [ 0, %254 ]
  %261 = zext i8 %260 to i16
  %262 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %261
  %263 = load ptr, ptr %262, align 1, !tbaa !35
  %264 = load ptr, ptr %263, align 1, !tbaa !40
  %265 = getelementptr inbounds nuw i8, ptr %264, i16 2
  %266 = load ptr, ptr %265, align 1, !tbaa !90
  tail call void %266(ptr noundef nonnull %263, ptr noundef nonnull @main.a) #12, !inline_history !98
  %267 = add nuw i8 %260, 1
  %268 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %269 = icmp ult i8 %267, %268
  br i1 %269, label %259, label %270, !llvm.loop !92

270:                                              ; preds = %259, %254
  %271 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %272

272:                                              ; preds = %272, %270
  %273 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %274 = icmp sgt i8 %273, -1
  br i1 %274, label %272, label %275, !llvm.loop !93

275:                                              ; preds = %272
  tail call fastcc void @upq_flush() #13
  %276 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %277 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %278 = icmp ult i8 %276, %277
  br i1 %278, label %281, label %279

279:                                              ; preds = %275
  %280 = icmp ugt i8 %276, %277
  br i1 %280, label %281, label %284

281:                                              ; preds = %279, %275
  %282 = phi i8 [ 1, %275 ], [ -1, %279 ]
  %283 = add i8 %282, %276
  store i8 %283, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %284

284:                                              ; preds = %281, %279
  %285 = phi i8 [ %276, %279 ], [ %283, %281 ]
  %286 = and i8 %285, 15
  store volatile i8 %286, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %287 = icmp eq i16 %256, 0
  br i1 %287, label %288, label %254, !llvm.loop !99

288:                                              ; preds = %284
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !83
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !84
  br label %292

289:                                              ; preds = %321
  %290 = add nuw nsw i8 %293, 1
  %291 = icmp eq i8 %290, 90
  br i1 %291, label %326, label %292, !llvm.loop !100

292:                                              ; preds = %289, %288
  %293 = phi i8 [ 0, %288 ], [ %290, %289 ]
  %294 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %295 = icmp eq i8 %294, 0
  br i1 %295, label %307, label %296

296:                                              ; preds = %292, %296
  %297 = phi i8 [ %304, %296 ], [ 0, %292 ]
  %298 = zext i8 %297 to i16
  %299 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %298
  %300 = load ptr, ptr %299, align 1, !tbaa !35
  %301 = load ptr, ptr %300, align 1, !tbaa !40
  %302 = getelementptr inbounds nuw i8, ptr %301, i16 2
  %303 = load ptr, ptr %302, align 1, !tbaa !90
  tail call void %303(ptr noundef nonnull %300, ptr noundef nonnull @main.a) #12, !inline_history !101
  %304 = add nuw i8 %297, 1
  %305 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %306 = icmp ult i8 %304, %305
  br i1 %306, label %296, label %307, !llvm.loop !92

307:                                              ; preds = %296, %292
  %308 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %309

309:                                              ; preds = %309, %307
  %310 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %311 = icmp sgt i8 %310, -1
  br i1 %311, label %309, label %312, !llvm.loop !93

312:                                              ; preds = %309
  tail call fastcc void @upq_flush() #13
  %313 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %314 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %315 = icmp ult i8 %313, %314
  br i1 %315, label %318, label %316

316:                                              ; preds = %312
  %317 = icmp ugt i8 %313, %314
  br i1 %317, label %318, label %321

318:                                              ; preds = %316, %312
  %319 = phi i8 [ 1, %312 ], [ -1, %316 ]
  %320 = add i8 %319, %313
  store i8 %320, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %321

321:                                              ; preds = %318, %316
  %322 = phi i8 [ %313, %316 ], [ %320, %318 ]
  %323 = and i8 %322, 15
  store volatile i8 %323, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %324 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 19), align 1, !tbaa !102
  %325 = icmp sgt i16 %324, 3583
  br i1 %325, label %326, label %289

326:                                              ; preds = %321, %289
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !83
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %327 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %328 = icmp eq i8 %327, 0
  br i1 %328, label %362, label %329

329:                                              ; preds = %326, %357
  %330 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %331 = icmp eq i8 %330, 0
  br i1 %331, label %343, label %332

332:                                              ; preds = %329, %332
  %333 = phi i8 [ %340, %332 ], [ 0, %329 ]
  %334 = zext i8 %333 to i16
  %335 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %334
  %336 = load ptr, ptr %335, align 1, !tbaa !35
  %337 = load ptr, ptr %336, align 1, !tbaa !40
  %338 = getelementptr inbounds nuw i8, ptr %337, i16 2
  %339 = load ptr, ptr %338, align 1, !tbaa !90
  tail call void %339(ptr noundef nonnull %336, ptr noundef nonnull @main.a) #12, !inline_history !103
  %340 = add nuw i8 %333, 1
  %341 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %342 = icmp ult i8 %340, %341
  br i1 %342, label %332, label %343, !llvm.loop !92

343:                                              ; preds = %332, %329
  %344 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %345

345:                                              ; preds = %345, %343
  %346 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %347 = icmp sgt i8 %346, -1
  br i1 %347, label %345, label %348, !llvm.loop !93

348:                                              ; preds = %345
  tail call fastcc void @upq_flush() #13
  %349 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %350 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %351 = icmp ult i8 %349, %350
  br i1 %351, label %354, label %352

352:                                              ; preds = %348
  %353 = icmp ugt i8 %349, %350
  br i1 %353, label %354, label %357

354:                                              ; preds = %352, %348
  %355 = phi i8 [ 1, %348 ], [ -1, %352 ]
  %356 = add i8 %355, %349
  store i8 %356, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %357

357:                                              ; preds = %354, %352
  %358 = phi i8 [ %349, %352 ], [ %356, %354 ]
  %359 = and i8 %358, 15
  store volatile i8 %359, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %360 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %361 = icmp eq i8 %360, 0
  br i1 %361, label %362, label %329, !llvm.loop !94

362:                                              ; preds = %357, %326
  %363 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !89
  %364 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %365 = or i8 %364, %363
  %366 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %367 = xor i8 %366, -1
  %368 = and i8 %365, %367
  store i8 %368, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %368, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !82
  %369 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %370 = icmp ugt i8 %369, 15
  br i1 %370, label %382, label %371

371:                                              ; preds = %362
  %372 = zext nneg i8 %369 to i16
  %373 = add nuw nsw i8 %369, 1
  store i8 %373, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %374 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %372
  %375 = getelementptr inbounds nuw i8, ptr %374, i16 10
  store i8 1, ptr %375, align 1, !tbaa !45
  store i16 0, ptr %374, align 1, !tbaa !47
  %376 = getelementptr inbounds nuw i8, ptr %374, i16 9
  store i8 0, ptr %376, align 1, !tbaa !48
  %377 = getelementptr inbounds nuw i8, ptr %374, i16 7
  store i8 34, ptr %377, align 1, !tbaa !49
  %378 = getelementptr inbounds nuw i8, ptr %374, i16 8
  store i8 0, ptr %378, align 1, !tbaa !50
  %379 = getelementptr inbounds nuw i8, ptr %374, i16 2
  store i16 ptrtoint (ptr @title_end._title_bg_black to i16), ptr %379, align 1, !tbaa !51
  %380 = getelementptr inbounds nuw i8, ptr %374, i16 6
  store i8 0, ptr %380, align 1, !tbaa !52
  %381 = getelementptr inbounds nuw i8, ptr %374, i16 4
  store i16 2, ptr %381, align 1, !tbaa !53
  br label %382

382:                                              ; preds = %362, %371
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %383 = getelementptr inbounds nuw i8, ptr %1, i16 1
  %384 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %385 = getelementptr inbounds nuw i8, ptr %1, i16 3
  %386 = getelementptr inbounds nuw i8, ptr %1, i16 4
  %387 = getelementptr inbounds nuw i8, ptr %1, i16 5
  %388 = getelementptr inbounds nuw i8, ptr %1, i16 6
  %389 = getelementptr inbounds nuw i8, ptr %1, i16 7
  %390 = getelementptr inbounds nuw i8, ptr %1, i16 8
  %391 = getelementptr inbounds nuw i8, ptr %1, i16 9
  %392 = getelementptr inbounds nuw i8, ptr %1, i16 10
  %393 = getelementptr inbounds nuw i8, ptr %1, i16 11
  %394 = getelementptr inbounds nuw i8, ptr %1, i16 12
  %395 = getelementptr inbounds nuw i8, ptr %1, i16 13
  %396 = getelementptr inbounds nuw i8, ptr %1, i16 20
  br label %397

397:                                              ; preds = %482, %382
  %398 = phi i16 [ 0, %382 ], [ %574, %482 ]
  %399 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4519), align 1, !tbaa !63
  %400 = add i16 %399, 1
  store i16 %400, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4519), align 1, !tbaa !63
  %401 = and i16 %400, 7
  %402 = icmp eq i16 %401, 0
  br i1 %402, label %403, label %405

403:                                              ; preds = %397
  tail call fastcc void @fade_canvas() #13
  %404 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4519), align 1, !tbaa !63
  br label %405

405:                                              ; preds = %403, %397
  %406 = phi i16 [ %404, %403 ], [ %400, %397 ]
  %407 = lshr i16 %406, 4
  %408 = and i16 %407, 31
  %409 = add nuw nsw i16 %408, 2
  %410 = zext nneg i16 %409 to i64
  %411 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1
  %412 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1
  br label %485

413:                                              ; preds = %573
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #14
  store i8 86, ptr %383, align 1, !tbaa !6
  store i8 70, ptr %384, align 1, !tbaa !6
  store i8 76, ptr %385, align 1, !tbaa !6
  store i8 79, ptr %386, align 1, !tbaa !6
  store i8 87, ptr %387, align 1, !tbaa !6
  store i8 83, ptr %388, align 1, !tbaa !6
  store i8 58, ptr %389, align 1, !tbaa !6
  store i8 32, ptr %390, align 1, !tbaa !6
  %414 = udiv i16 %574, 1000
  %415 = trunc nuw nsw i16 %414 to i8
  %416 = urem i8 %415, 10
  %417 = or disjoint i8 %416, 48
  store i8 %417, ptr %391, align 1, !tbaa !6
  %418 = udiv i16 %574, 100
  %419 = urem i16 %418, 10
  %420 = trunc nuw nsw i16 %419 to i8
  %421 = or disjoint i8 %420, 48
  store i8 %421, ptr %392, align 1, !tbaa !6
  %422 = udiv i16 %574, 10
  %423 = urem i16 %422, 10
  %424 = trunc nuw nsw i16 %423 to i8
  %425 = or disjoint i8 %424, 48
  store i8 %425, ptr %393, align 1, !tbaa !6
  %426 = urem i16 %574, 10
  %427 = trunc nuw nsw i16 %426 to i8
  %428 = or disjoint i8 %427, 48
  store i8 %428, ptr %394, align 1, !tbaa !6
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %395, i8 32, i64 7, i1 false)
  store i8 0, ptr %396, align 1, !tbaa !6
  br label %434

429:                                              ; preds = %444
  %430 = add nuw nsw i8 %437, 2
  %431 = add nuw nsw i8 %438, 1
  %432 = zext i8 %450 to i16
  %433 = icmp eq i8 %431, 32
  br i1 %433, label %452, label %434, !llvm.loop !65

434:                                              ; preds = %413, %429
  %435 = phi i16 [ 79, %413 ], [ %432, %429 ]
  %436 = phi i8 [ 79, %413 ], [ %450, %429 ]
  %437 = phi i8 [ 0, %413 ], [ %430, %429 ]
  %438 = phi i8 [ 0, %413 ], [ %431, %429 ]
  %439 = icmp ugt i8 %436, 31
  br i1 %439, label %440, label %444

440:                                              ; preds = %434
  %441 = icmp ult i8 %436, 96
  br i1 %441, label %442, label %444

442:                                              ; preds = %440
  %443 = add nuw nsw i16 %435, 224
  br label %444

444:                                              ; preds = %442, %440, %434
  %445 = phi i16 [ %443, %442 ], [ 256, %440 ], [ 256, %434 ]
  %446 = zext nneg i8 %437 to i16
  %447 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4376), i16 %446
  store i16 %445, ptr %447, align 1, !tbaa !2
  %448 = zext nneg i8 %438 to i16
  %449 = getelementptr i8, ptr %383, i16 %448
  %450 = load i8, ptr %449, align 1, !tbaa !6
  %451 = icmp eq i8 %450, 0
  br i1 %451, label %452, label %429, !llvm.loop !65

452:                                              ; preds = %429, %444
  %453 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %454 = or i8 %453, 2
  store i8 %454, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %455 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %456 = icmp eq i8 %455, 0
  br i1 %456, label %468, label %457

457:                                              ; preds = %452, %457
  %458 = phi i8 [ %465, %457 ], [ 0, %452 ]
  %459 = zext i8 %458 to i16
  %460 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %459
  %461 = load ptr, ptr %460, align 1, !tbaa !35
  %462 = load ptr, ptr %461, align 1, !tbaa !40
  %463 = getelementptr inbounds nuw i8, ptr %462, i16 2
  %464 = load ptr, ptr %463, align 1, !tbaa !90
  tail call void %464(ptr noundef nonnull %461, ptr noundef nonnull @main.a) #12, !inline_history !104
  %465 = add nuw i8 %458, 1
  %466 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %467 = icmp ult i8 %465, %466
  br i1 %467, label %457, label %468, !llvm.loop !92

468:                                              ; preds = %457, %452
  %469 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %470

470:                                              ; preds = %470, %468
  %471 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %472 = icmp sgt i8 %471, -1
  br i1 %472, label %470, label %473, !llvm.loop !93

473:                                              ; preds = %470
  tail call fastcc void @upq_flush() #13
  %474 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %475 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %476 = icmp ult i8 %474, %475
  br i1 %476, label %479, label %477

477:                                              ; preds = %473
  %478 = icmp ugt i8 %474, %475
  br i1 %478, label %479, label %482

479:                                              ; preds = %477, %473
  %480 = phi i8 [ 1, %473 ], [ -1, %477 ]
  %481 = add i8 %480, %474
  store i8 %481, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %482

482:                                              ; preds = %477, %479
  %483 = phi i8 [ %474, %477 ], [ %481, %479 ]
  %484 = and i8 %483, 15
  store volatile i8 %484, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #14
  br label %397

485:                                              ; preds = %405, %573
  %486 = phi i8 [ 0, %405 ], [ %579, %573 ]
  %487 = phi i16 [ %398, %405 ], [ %574, %573 ]
  %488 = phi i8 [ 0, %405 ], [ %577, %573 ]
  %489 = phi i16 [ %411, %405 ], [ %576, %573 ]
  %490 = phi i16 [ %412, %405 ], [ %575, %573 ]
  %491 = zext nneg i8 %486 to i16
  %492 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %491
  %493 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4446), i16 %491
  %494 = load i64, ptr %493, align 1, !tbaa !61
  %495 = tail call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %494, i64 %410)
  %496 = extractvalue { i64, i1 } %495, 1
  %497 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4444), i16 %491
  br i1 %496, label %518, label %498

498:                                              ; preds = %485
  %499 = extractvalue { i64, i1 } %495, 0
  %500 = or i64 %499, 1
  store i64 %500, ptr %493, align 1, !tbaa !61
  %501 = load i8, ptr %492, align 1, !tbaa !54
  %502 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), i16 %491
  %503 = load i8, ptr %502, align 1, !tbaa !58
  %504 = add i8 %503, %501
  %505 = and i8 %504, 127
  store i8 %505, ptr %492, align 1, !tbaa !54
  %506 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4442), i16 %491
  %507 = load i8, ptr %506, align 1, !tbaa !57
  %508 = load i8, ptr %497, align 1, !tbaa !59
  %509 = add i8 %508, %507
  %510 = and i8 %509, 127
  store i8 %510, ptr %506, align 1, !tbaa !57
  %511 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4445), i16 %491
  %512 = load i8, ptr %511, align 1, !tbaa !60
  %513 = icmp eq i8 %512, 0
  br i1 %513, label %536, label %514

514:                                              ; preds = %498
  %515 = add i8 %512, -1
  store i8 %515, ptr %511, align 1, !tbaa !60
  %516 = icmp eq i8 %515, 0
  %517 = select i1 %516, i8 1, i8 2
  br label %536

518:                                              ; preds = %485
  %519 = load i8, ptr %492, align 1, !tbaa !54
  %520 = sub i8 127, %519
  store i8 %520, ptr %492, align 1, !tbaa !54
  %521 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4442), i16 %491
  %522 = load i8, ptr %521, align 1, !tbaa !57
  %523 = sub i8 127, %522
  store i8 %523, ptr %521, align 1, !tbaa !57
  %524 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), i16 %491
  %525 = load i8, ptr %524, align 1, !tbaa !58
  %526 = sub i8 0, %525
  store i8 %526, ptr %524, align 1, !tbaa !58
  %527 = load i8, ptr %497, align 1, !tbaa !59
  %528 = sub i8 0, %527
  store i8 %528, ptr %497, align 1, !tbaa !59
  %529 = zext i8 %520 to i64
  %530 = or disjoint i64 %529, 1099511627776
  store i64 %530, ptr %493, align 1, !tbaa !61
  %531 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4445), i16 %491
  store i8 12, ptr %531, align 1, !tbaa !60
  %532 = add i16 %487, 1
  %533 = icmp slt i8 %520, 0
  br i1 %533, label %573, label %534

534:                                              ; preds = %518
  %535 = icmp slt i8 %523, 0
  br i1 %535, label %573, label %536

536:                                              ; preds = %498, %514, %534
  %537 = phi i8 [ %523, %534 ], [ %510, %514 ], [ %510, %498 ]
  %538 = phi i8 [ 3, %534 ], [ %517, %514 ], [ 1, %498 ]
  %539 = phi i16 [ %532, %534 ], [ %487, %514 ], [ %487, %498 ]
  %540 = phi i8 [ %520, %534 ], [ %505, %514 ], [ %505, %498 ]
  %541 = zext nneg i8 %540 to i16
  %542 = shl nuw i8 %537, 1
  %543 = zext i8 %542 to i16
  %544 = and i16 %543, 240
  %545 = lshr i16 %541, 3
  %546 = or disjoint i16 %544, %545
  %547 = shl nuw nsw i16 %546, 4
  %548 = and i16 %543, 14
  %549 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %547
  %550 = getelementptr inbounds nuw i8, ptr %549, i16 %548
  %551 = and i16 %541, 7
  %552 = lshr exact i16 128, %551
  %553 = and i8 %538, 1
  %554 = icmp eq i8 %553, 0
  br i1 %554, label %559, label %555

555:                                              ; preds = %536
  %556 = load i8, ptr %550, align 1, !tbaa !6
  %557 = trunc nuw i16 %552 to i8
  %558 = or i8 %556, %557
  store i8 %558, ptr %550, align 1, !tbaa !6
  br label %559

559:                                              ; preds = %555, %536
  %560 = icmp samesign ult i8 %538, 2
  br i1 %560, label %566, label %561

561:                                              ; preds = %559
  %562 = getelementptr inbounds nuw i8, ptr %550, i16 1
  %563 = load i8, ptr %562, align 1, !tbaa !6
  %564 = trunc nuw i16 %552 to i8
  %565 = or i8 %563, %564
  store i8 %565, ptr %562, align 1, !tbaa !6
  br label %566

566:                                              ; preds = %561, %559
  %567 = icmp ult i16 %546, %489
  br i1 %567, label %568, label %569

568:                                              ; preds = %566
  store i16 %546, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %569

569:                                              ; preds = %568, %566
  %570 = phi i16 [ %546, %568 ], [ %489, %566 ]
  %571 = icmp ugt i16 %546, %490
  br i1 %571, label %572, label %573

572:                                              ; preds = %569
  store i16 %546, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %573

573:                                              ; preds = %518, %534, %569, %572
  %574 = phi i16 [ %532, %518 ], [ %532, %534 ], [ %539, %569 ], [ %539, %572 ]
  %575 = phi i16 [ %490, %518 ], [ %490, %534 ], [ %490, %569 ], [ %546, %572 ]
  %576 = phi i16 [ %489, %518 ], [ %489, %534 ], [ %570, %569 ], [ %570, %572 ]
  %577 = add nuw nsw i8 %488, 1
  %578 = icmp eq i8 %577, 6
  %579 = add nuw nsw i8 %486, 13
  br i1 %578, label %413, label %485, !llvm.loop !105
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none)
define internal fastcc void @fade_canvas() unnamed_addr #2 {
  br label %2

1:                                                ; preds = %5
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  store i16 255, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  ret void

2:                                                ; preds = %0, %5
  %3 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 199), %0 ], [ %8, %5 ]
  %4 = phi i16 [ 0, %0 ], [ %6, %5 ]
  br label %9

5:                                                ; preds = %9
  %6 = add nuw nsw i16 %4, 4
  %7 = icmp samesign ult i16 %4, 252
  %8 = getelementptr i8, ptr %3, i16 64
  br i1 %7, label %2, label %1, !llvm.loop !106

9:                                                ; preds = %2, %9
  %10 = phi i8 [ 0, %2 ], [ %18, %9 ]
  %11 = phi i8 [ 0, %2 ], [ %16, %9 ]
  %12 = zext nneg i8 %10 to i16
  %13 = getelementptr i8, ptr %3, i16 %12
  %14 = load i8, ptr %13, align 1, !tbaa !6
  %15 = lshr i8 %14, 1
  store i8 %15, ptr %13, align 1, !tbaa !6
  %16 = add nuw nsw i8 %11, 1
  %17 = icmp eq i8 %16, 8
  %18 = add nuw nsw i8 %10, 2
  br i1 %17, label %5, label %9, !llvm.loop !107
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_canvas_reserve(ptr noundef readonly captures(none) %0, ptr readnone captures(none) %1) #3 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4105
  %4 = load i16, ptr %3, align 1, !tbaa !21
  %5 = lshr i16 %4, 8
  %6 = trunc nuw i16 %5 to i8
  %7 = and i8 %6, -4
  store volatile i8 %7, ptr inttoptr (i16 8457 to ptr), align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %9 = load i16, ptr %8, align 1, !tbaa !20
  %10 = lshr i16 %9, 12
  %11 = trunc nuw nsw i16 %10 to i8
  store volatile i8 %11, ptr inttoptr (i16 8460 to ptr), align 4, !tbaa !6
  %12 = load i16, ptr %8, align 1, !tbaa !20
  %13 = lshr i16 %12, 3
  %14 = add nuw nsw i16 %13, 256
  %15 = load i16, ptr %3, align 1, !tbaa !21
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %15, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %16 = getelementptr inbounds nuw i8, ptr %0, i16 4107
  %17 = load i8, ptr %16, align 1, !tbaa !22
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 4108
  br label %19

19:                                               ; preds = %2, %23
  %20 = phi i8 [ 0, %2 ], [ %24, %23 ]
  br label %26

21:                                               ; preds = %23
  %22 = load i16, ptr %8, align 1, !tbaa !20
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %22, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %45

23:                                               ; preds = %40
  %24 = add nuw nsw i8 %20, 1
  %25 = icmp eq i8 %24, 32
  br i1 %25, label %21, label %19, !llvm.loop !108

26:                                               ; preds = %19, %40
  %27 = phi i8 [ 0, %19 ], [ %42, %40 ]
  %28 = sub i8 %27, %17
  %29 = zext i8 %28 to i16
  %30 = icmp ult i8 %28, 16
  br i1 %30, label %31, label %40

31:                                               ; preds = %26
  %32 = load i8, ptr %18, align 1, !tbaa !23
  %33 = sub i8 %20, %32
  %34 = icmp ult i8 %33, 16
  br i1 %34, label %35, label %40

35:                                               ; preds = %31
  %36 = shl nuw i8 %33, 4
  %37 = zext i8 %36 to i16
  %38 = add nuw nsw i16 %13, %29
  %39 = add nuw nsw i16 %38, %37
  br label %40

40:                                               ; preds = %26, %31, %35
  %41 = phi i16 [ %39, %35 ], [ %14, %31 ], [ %14, %26 ]
  store volatile i16 %41, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %42 = add nuw nsw i8 %27, 1
  %43 = icmp eq i8 %42, 32
  br i1 %43, label %23, label %26, !llvm.loop !109

44:                                               ; preds = %45
  ret void

45:                                               ; preds = %21, %45
  %46 = phi i16 [ 0, %21 ], [ %47, %45 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %47 = add nuw nsw i16 %46, 1
  %48 = icmp eq i16 %47, 2056
  br i1 %48, label %44, label %45, !llvm.loop !110
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal void @_canvas_emit(ptr noundef %0, ptr noundef captures(none) %1) #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4099
  %4 = load i16, ptr %3, align 1, !tbaa !24
  %5 = getelementptr inbounds nuw i8, ptr %0, i16 4101
  %6 = load i16, ptr %5, align 1, !tbaa !25
  %7 = icmp ugt i16 %4, %6
  br i1 %7, label %48, label %8

8:                                                ; preds = %2
  %9 = sub nuw i16 %6, %4
  %10 = add i16 %9, -64
  %11 = icmp ult i16 %10, -65
  br i1 %11, label %12, label %14

12:                                               ; preds = %8
  %13 = add i16 %4, 63
  br label %14

14:                                               ; preds = %12, %8
  %15 = phi i16 [ 63, %12 ], [ %9, %8 ]
  %16 = phi i16 [ %13, %12 ], [ %6, %8 ]
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %18 = load i16, ptr %17, align 1, !tbaa !20
  %19 = shl i16 %4, 3
  %20 = add i16 %18, %19
  %21 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %22 = shl i16 %4, 4
  %23 = getelementptr inbounds nuw i8, ptr %21, i16 %22
  %24 = shl nsw i16 %15, 4
  %25 = add nsw i16 %24, 16
  %26 = icmp eq i16 %25, 0
  br i1 %26, label %43, label %27

27:                                               ; preds = %14
  %28 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %29 = load i8, ptr %28, align 1, !tbaa !44
  %30 = icmp ugt i8 %29, 15
  br i1 %30, label %43, label %31

31:                                               ; preds = %27
  %32 = zext nneg i8 %29 to i16
  %33 = add nuw nsw i8 %29, 1
  store i8 %33, ptr %28, align 1, !tbaa !44
  %34 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %32
  %35 = getelementptr inbounds nuw i8, ptr %34, i16 10
  store i8 0, ptr %35, align 1, !tbaa !45
  store i16 %20, ptr %34, align 1, !tbaa !47
  %36 = getelementptr inbounds nuw i8, ptr %34, i16 9
  store i8 -128, ptr %36, align 1, !tbaa !48
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 7
  store i8 24, ptr %37, align 1, !tbaa !49
  %38 = getelementptr inbounds nuw i8, ptr %34, i16 8
  store i8 1, ptr %38, align 1, !tbaa !50
  %39 = ptrtoint ptr %23 to i16
  %40 = getelementptr inbounds nuw i8, ptr %34, i16 2
  store i16 %39, ptr %40, align 1, !tbaa !51
  %41 = getelementptr inbounds nuw i8, ptr %34, i16 6
  store i8 0, ptr %41, align 1, !tbaa !52
  %42 = getelementptr inbounds nuw i8, ptr %34, i16 4
  store i16 %25, ptr %42, align 1, !tbaa !53
  br label %43

43:                                               ; preds = %14, %27, %31
  %44 = icmp ult i16 %16, %6
  br i1 %44, label %46, label %45

45:                                               ; preds = %43
  store i16 -1, ptr %3, align 1, !tbaa !24
  store i16 0, ptr %5, align 1, !tbaa !25
  br label %48

46:                                               ; preds = %43
  %47 = add nuw i16 %16, 1
  store i16 %47, ptr %3, align 1, !tbaa !24
  br label %48

48:                                               ; preds = %45, %46, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_text_reserve(ptr readnone captures(none) %0, ptr readnone captures(none) %1) #3 {
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 2048, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %4

3:                                                ; preds = %4
  ret void

4:                                                ; preds = %2, %4
  %5 = phi i16 [ 0, %2 ], [ %8, %4 ]
  %6 = getelementptr inbounds nuw [2 x i8], ptr @FONT8, i16 %5
  %7 = load i16, ptr %6, align 1, !tbaa !2
  store volatile i16 %7, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %8 = add nuw nsw i16 %5, 1
  %9 = icmp eq i16 %8, 512
  br i1 %9, label %3, label %4, !llvm.loop !111
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(argmem: readwrite)
define internal void @_text_emit(ptr noundef %0, ptr noundef captures(none) %1) #5 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 135
  %4 = load i8, ptr %3, align 1, !tbaa !31
  %5 = zext i8 %4 to i16
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %7 = getelementptr i8, ptr %0, i16 7
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %9 = getelementptr i8, ptr %0, i16 5
  br label %11

10:                                               ; preds = %42
  store i8 0, ptr %3, align 1, !tbaa !31
  ret void

11:                                               ; preds = %2, %42
  %12 = phi i8 [ 0, %2 ], [ %43, %42 ]
  %13 = phi i1 [ true, %2 ], [ false, %42 ]
  %14 = phi i8 [ 0, %2 ], [ 1, %42 ]
  %15 = zext nneg i8 %14 to i16
  %16 = shl nuw nsw i16 1, %15
  %17 = and i16 %16, %5
  %18 = icmp eq i16 %17, 0
  br i1 %18, label %42, label %19

19:                                               ; preds = %11
  %20 = load i8, ptr %6, align 1, !tbaa !44
  %21 = icmp ugt i8 %20, 15
  br i1 %21, label %42, label %22

22:                                               ; preds = %19
  %23 = zext i8 %12 to i16
  %24 = getelementptr i8, ptr %7, i16 %23
  %25 = load i16, ptr %8, align 1, !tbaa !29
  %26 = getelementptr i8, ptr %9, i16 %15
  %27 = load i8, ptr %26, align 1, !tbaa !6
  %28 = zext i8 %27 to i16
  %29 = shl nuw nsw i16 %28, 5
  %30 = add i16 %29, %25
  %31 = zext nneg i8 %20 to i16
  %32 = add nuw nsw i8 %20, 1
  store i8 %32, ptr %6, align 1, !tbaa !44
  %33 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %31
  %34 = getelementptr inbounds nuw i8, ptr %33, i16 10
  store i8 0, ptr %34, align 1, !tbaa !45
  store i16 %30, ptr %33, align 1, !tbaa !47
  %35 = getelementptr inbounds nuw i8, ptr %33, i16 9
  store i8 -128, ptr %35, align 1, !tbaa !48
  %36 = getelementptr inbounds nuw i8, ptr %33, i16 7
  store i8 24, ptr %36, align 1, !tbaa !49
  %37 = getelementptr inbounds nuw i8, ptr %33, i16 8
  store i8 1, ptr %37, align 1, !tbaa !50
  %38 = ptrtoint ptr %24 to i16
  %39 = getelementptr inbounds nuw i8, ptr %33, i16 2
  store i16 %38, ptr %39, align 1, !tbaa !51
  %40 = getelementptr inbounds nuw i8, ptr %33, i16 6
  store i8 0, ptr %40, align 1, !tbaa !52
  %41 = getelementptr inbounds nuw i8, ptr %33, i16 4
  store i16 64, ptr %41, align 1, !tbaa !53
  br label %42

42:                                               ; preds = %22, %19, %11
  %43 = add nuw i8 %12, 64
  br i1 %13, label %11, label %10, !llvm.loop !112
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_title_reserve(ptr noundef %0, ptr readnone captures(none) %1) #3 {
  store volatile i8 80, ptr inttoptr (i16 8456 to ptr), align 8, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !6
  store volatile i8 112, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -1, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 127, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -124, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 4096, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %3

3:                                                ; preds = %2, %16
  %4 = phi ptr [ @FONT8, %2 ], [ %18, %16 ]
  %5 = phi i16 [ 0, %2 ], [ %17, %16 ]
  br label %7

6:                                                ; preds = %16
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 5120, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %24

7:                                                ; preds = %3, %7
  %8 = phi i8 [ 0, %3 ], [ %15, %7 ]
  %9 = phi i8 [ 0, %3 ], [ %13, %7 ]
  %10 = zext nneg i8 %8 to i16
  %11 = getelementptr i8, ptr %4, i16 %10
  %12 = load i16, ptr %11, align 1, !tbaa !2
  store volatile i16 %12, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %13 = add nuw nsw i8 %9, 1
  %14 = icmp eq i8 %13, 8
  %15 = add nuw nsw i8 %8, 2
  br i1 %14, label %20, label %7, !llvm.loop !113

16:                                               ; preds = %20
  %17 = add nuw nsw i16 %5, 1
  %18 = getelementptr i8, ptr %4, i16 16
  %19 = icmp eq i16 %17, 64
  br i1 %19, label %6, label %3, !llvm.loop !114

20:                                               ; preds = %7, %20
  %21 = phi i8 [ %22, %20 ], [ 0, %7 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %22 = add nuw nsw i8 %21, 1
  %23 = icmp eq i8 %22, 8
  br i1 %23, label %16, label %20, !llvm.loop !115

24:                                               ; preds = %6, %33
  %25 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 16), %6 ], [ %36, %33 ]
  %26 = phi ptr [ @FONT16, %6 ], [ %35, %33 ]
  %27 = phi i16 [ 0, %6 ], [ %34, %33 ]
  br label %29

28:                                               ; preds = %33
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 20480, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %66

29:                                               ; preds = %24, %47
  %30 = phi i8 [ 0, %24 ], [ %52, %47 ]
  %31 = phi ptr [ %26, %24 ], [ %50, %47 ]
  %32 = phi i8 [ 0, %24 ], [ %48, %47 ]
  br label %38

33:                                               ; preds = %47
  %34 = add nuw nsw i16 %27, 1
  %35 = getelementptr i8, ptr %26, i16 64
  %36 = getelementptr i8, ptr %25, i16 64
  %37 = icmp eq i16 %34, 64
  br i1 %37, label %28, label %24, !llvm.loop !116

38:                                               ; preds = %29, %38
  %39 = phi i8 [ 0, %29 ], [ %46, %38 ]
  %40 = phi i8 [ 0, %29 ], [ %44, %38 ]
  %41 = zext nneg i8 %39 to i16
  %42 = getelementptr i8, ptr %31, i16 %41
  %43 = load i16, ptr %42, align 1, !tbaa !2
  store volatile i16 %43, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %44 = add nuw nsw i8 %40, 1
  %45 = icmp eq i8 %44, 8
  %46 = add nuw nsw i8 %39, 2
  br i1 %45, label %53, label %38, !llvm.loop !117

47:                                               ; preds = %53
  %48 = add nuw nsw i8 %32, 1
  %49 = zext nneg i8 %30 to i16
  %50 = getelementptr i8, ptr %25, i16 %49
  %51 = icmp eq i8 %48, 4
  %52 = add nuw nsw i8 %30, 16
  br i1 %51, label %33, label %29, !llvm.loop !118

53:                                               ; preds = %38, %53
  %54 = phi i8 [ %55, %53 ], [ 0, %38 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %55 = add nuw nsw i8 %54, 1
  %56 = icmp eq i8 %55, 8
  br i1 %56, label %47, label %53, !llvm.loop !119

57:                                               ; preds = %66
  %58 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %59 = load ptr, ptr %58, align 1, !tbaa !71
  %60 = icmp eq ptr %59, null
  br i1 %60, label %79, label %61

61:                                               ; preds = %57
  %62 = load i8, ptr %59, align 1, !tbaa !6
  %63 = icmp eq i8 %62, 0
  br i1 %63, label %79, label %64

64:                                               ; preds = %61
  %65 = getelementptr i8, ptr %59, i16 1
  br label %70

66:                                               ; preds = %28, %66
  %67 = phi i16 [ 0, %28 ], [ %68, %66 ]
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %68 = add nuw nsw i16 %67, 1
  %69 = icmp eq i16 %68, 1024
  br i1 %69, label %57, label %66, !llvm.loop !120

70:                                               ; preds = %64, %70
  %71 = phi i8 [ %72, %70 ], [ 0, %64 ]
  %72 = add nuw nsw i8 %71, 1
  %73 = zext nneg i8 %71 to i16
  %74 = getelementptr i8, ptr %65, i16 %73
  %75 = load i8, ptr %74, align 1, !tbaa !6
  %76 = icmp ne i8 %75, 0
  %77 = icmp samesign ult i8 %71, 31
  %78 = select i1 %76, i1 %77, i1 false
  br i1 %78, label %70, label %79, !llvm.loop !121

79:                                               ; preds = %70, %61, %57
  %80 = phi i8 [ 0, %57 ], [ 0, %61 ], [ %72, %70 ]
  %81 = zext nneg i8 %80 to i16
  %82 = sub nuw nsw i16 32, %81
  %83 = lshr i16 %82, 1
  %84 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %85 = load i16, ptr %84, align 1, !tbaa !78
  %86 = shl i16 %85, 2
  %87 = and i16 %86, -32
  %88 = add i16 %87, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %88, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %89 = trunc nuw nsw i16 %83 to i8
  %90 = add nuw nsw i8 %80, %89
  %91 = sub nsw i16 0, %83
  %92 = getelementptr i8, ptr %59, i16 %91
  br label %105

93:                                               ; preds = %128
  %94 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %95 = load ptr, ptr %94, align 1, !tbaa !73
  %96 = getelementptr inbounds nuw i8, ptr %0, i16 11
  %97 = load i8, ptr %96, align 1, !tbaa !75
  %98 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %99 = load i16, ptr %98, align 1, !tbaa !79
  %100 = lshr i16 %99, 3
  %101 = trunc i16 %100 to i8
  tail call fastcc void @_title_write16(ptr noundef %95, i8 noundef zeroext %97, i8 noundef zeroext %101) #13
  %102 = getelementptr inbounds nuw i8, ptr %0, i16 9
  %103 = load ptr, ptr %102, align 1, !tbaa !76
  %104 = icmp eq ptr %103, null
  br i1 %104, label %139, label %132

105:                                              ; preds = %79, %128
  %106 = phi i8 [ 0, %79 ], [ %130, %128 ]
  %107 = zext nneg i8 %106 to i16
  br i1 %60, label %128, label %108

108:                                              ; preds = %105
  %109 = icmp samesign ugt i16 %83, %107
  br i1 %109, label %128, label %110

110:                                              ; preds = %108
  %111 = icmp ult i8 %106, %90
  br i1 %111, label %112, label %128

112:                                              ; preds = %110
  %113 = getelementptr i8, ptr %92, i16 %107
  %114 = load i8, ptr %113, align 1, !tbaa !6
  %115 = icmp ugt i8 %114, 96
  br i1 %115, label %116, label %120

116:                                              ; preds = %112
  %117 = icmp ult i8 %114, 123
  br i1 %117, label %118, label %128

118:                                              ; preds = %116
  %119 = add nsw i8 %114, -32
  br label %124

120:                                              ; preds = %112
  %121 = icmp samesign ugt i8 %114, 31
  br i1 %121, label %122, label %128

122:                                              ; preds = %120
  %123 = icmp eq i8 %114, 96
  br i1 %123, label %128, label %124

124:                                              ; preds = %122, %118
  %125 = phi i8 [ %119, %118 ], [ %114, %122 ]
  %126 = zext nneg i8 %125 to i16
  %127 = add nuw nsw i16 %126, 7136
  br label %128

128:                                              ; preds = %124, %122, %120, %116, %105, %108, %110
  %129 = phi i16 [ 7168, %105 ], [ 7168, %110 ], [ 7168, %108 ], [ %127, %124 ], [ 7168, %122 ], [ 7168, %120 ], [ 7168, %116 ]
  store volatile i16 %129, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %130 = add nuw nsw i8 %106, 1
  %131 = icmp eq i8 %130, 32
  br i1 %131, label %93, label %105, !llvm.loop !122

132:                                              ; preds = %93
  %133 = getelementptr inbounds nuw i8, ptr %0, i16 12
  %134 = load i8, ptr %133, align 1, !tbaa !77
  %135 = load i16, ptr %98, align 1, !tbaa !79
  %136 = lshr i16 %135, 3
  %137 = trunc i16 %136 to i8
  %138 = add i8 %137, 2
  tail call fastcc void @_title_write16(ptr noundef nonnull %103, i8 noundef zeroext %134, i8 noundef zeroext %138) #13
  br label %139

139:                                              ; preds = %132, %93
  %140 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 -128, ptr %140, align 1, !tbaa !102
  %141 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 3584, ptr %141, align 1, !tbaa !123
  %142 = getelementptr inbounds nuw i8, ptr %0, i16 23
  store i16 0, ptr %142, align 1, !tbaa !124
  %143 = load ptr, ptr %58, align 1, !tbaa !71
  %144 = icmp eq ptr %143, null
  br i1 %144, label %167, label %145

145:                                              ; preds = %139
  %146 = load i8, ptr %143, align 1, !tbaa !6
  %147 = icmp eq i8 %146, 0
  br i1 %147, label %150, label %148

148:                                              ; preds = %145
  %149 = getelementptr i8, ptr %143, i16 1
  br label %158

150:                                              ; preds = %158, %145
  %151 = phi i8 [ 0, %145 ], [ %160, %158 ]
  %152 = zext nneg i8 %151 to i16
  %153 = shl nuw nsw i16 %152, 2
  %154 = sub nuw nsw i16 128, %153
  %155 = and i16 %154, 248
  %156 = add nsw i16 %153, -128
  %157 = add nsw i16 %156, %155
  br label %167

158:                                              ; preds = %158, %148
  %159 = phi i8 [ %160, %158 ], [ 0, %148 ]
  %160 = add nuw nsw i8 %159, 1
  %161 = zext nneg i8 %159 to i16
  %162 = getelementptr i8, ptr %149, i16 %161
  %163 = load i8, ptr %162, align 1, !tbaa !6
  %164 = icmp ne i8 %163, 0
  %165 = icmp samesign ult i8 %159, 31
  %166 = select i1 %164, i1 %165, i1 false
  br i1 %166, label %158, label %150, !llvm.loop !125

167:                                              ; preds = %139, %150
  %168 = phi i16 [ %157, %150 ], [ 0, %139 ]
  %169 = getelementptr inbounds nuw i8, ptr %0, i16 26
  store i16 %168, ptr %169, align 1, !tbaa !126
  store volatile i8 -112, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  %170 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %171 = getelementptr inbounds nuw i8, ptr %0, i16 89
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef -8, i16 noundef 224, ptr noundef nonnull %170, ptr noundef nonnull %171) #13
  %172 = getelementptr inbounds nuw i8, ptr %0, i16 88
  store i8 0, ptr %172, align 1, !tbaa !127
  store volatile i8 2, ptr inttoptr (i16 17200 to ptr), align 16, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 17201 to ptr), align 1, !tbaa !6
  %173 = ptrtoint ptr %170 to i16
  %174 = trunc i16 %173 to i8
  store volatile i8 %174, ptr inttoptr (i16 17202 to ptr), align 2, !tbaa !6
  %175 = lshr i16 %173, 8
  %176 = trunc nuw i16 %175 to i8
  store volatile i8 %176, ptr inttoptr (i16 17203 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17204 to ptr), align 4, !tbaa !6
  %177 = getelementptr inbounds nuw i8, ptr %0, i16 139
  store i8 0, ptr %177, align 1, !tbaa !127
  store volatile i8 2, ptr inttoptr (i16 17216 to ptr), align 64, !tbaa !6
  store volatile i8 15, ptr inttoptr (i16 17217 to ptr), align 1, !tbaa !6
  %178 = ptrtoint ptr %171 to i16
  %179 = trunc i16 %178 to i8
  store volatile i8 %179, ptr inttoptr (i16 17218 to ptr), align 2, !tbaa !6
  %180 = lshr i16 %178, 8
  %181 = trunc nuw i16 %180 to i8
  store volatile i8 %181, ptr inttoptr (i16 17219 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17220 to ptr), align 4, !tbaa !6
  %182 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 2, ptr %182, align 1, !tbaa !70
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal void @_title_emit(ptr noundef %0, ptr noundef captures(none) %1) #6 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 29
  %4 = load i8, ptr %3, align 1, !tbaa !82
  %5 = icmp eq i8 %4, 0
  br i1 %5, label %188, label %6

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 30
  %8 = load i8, ptr %7, align 1, !tbaa !85
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %39, label %10

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 25
  %12 = load i8, ptr %11, align 1, !tbaa !86
  %13 = icmp ugt i8 %12, -6
  br i1 %13, label %16, label %14

14:                                               ; preds = %10
  %15 = add nuw i8 %12, 4
  br label %16

16:                                               ; preds = %10, %14
  %17 = phi i8 [ %15, %14 ], [ -1, %10 ]
  store i8 %17, ptr %11, align 1, !tbaa !86
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %19 = load i16, ptr %18, align 1, !tbaa !78
  %20 = xor i8 %17, -1
  %21 = zext i8 %20 to i16
  %22 = mul nuw i16 %21, %21
  %23 = lshr i16 %22, 8
  %24 = sub nuw nsw i16 256, %23
  %25 = add nsw i16 %19, 8
  %26 = mul nsw i16 %24, %25
  %27 = ashr i16 %26, 4
  %28 = and i16 %27, -16
  %29 = add nsw i16 %28, -128
  %30 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 %29, ptr %30, align 1, !tbaa !102
  %31 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %32 = load i16, ptr %31, align 1, !tbaa !79
  %33 = add nsw i16 %32, -224
  %34 = mul nsw i16 %33, %24
  %35 = ashr i16 %34, 4
  %36 = and i16 %35, -16
  %37 = add nsw i16 %36, 3584
  %38 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 %37, ptr %38, align 1, !tbaa !123
  br label %64

39:                                               ; preds = %6
  %40 = getelementptr inbounds nuw i8, ptr %0, i16 31
  %41 = load i8, ptr %40, align 1, !tbaa !83
  %42 = icmp eq i8 %41, 0
  br i1 %42, label %43, label %48

43:                                               ; preds = %39
  %44 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %45 = load i16, ptr %44, align 1, !tbaa !102
  %46 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %47 = load i16, ptr %46, align 1, !tbaa !123
  br label %64

48:                                               ; preds = %39
  %49 = getelementptr inbounds nuw i8, ptr %0, i16 23
  %50 = load i16, ptr %49, align 1, !tbaa !124
  %51 = add nsw i16 %50, 2
  store i16 %51, ptr %49, align 1, !tbaa !124
  %52 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %53 = load i16, ptr %52, align 1, !tbaa !102
  %54 = add nsw i16 %53, %51
  store i16 %54, ptr %52, align 1, !tbaa !102
  %55 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %56 = load i16, ptr %55, align 1, !tbaa !123
  %57 = add nsw i16 %56, %51
  store i16 %57, ptr %55, align 1, !tbaa !123
  %58 = icmp sgt i16 %54, 4480
  br i1 %58, label %59, label %60

59:                                               ; preds = %48
  store i16 4480, ptr %52, align 1, !tbaa !102
  br label %60

60:                                               ; preds = %59, %48
  %61 = phi i16 [ 4480, %59 ], [ %54, %48 ]
  %62 = icmp sgt i16 %57, 4736
  br i1 %62, label %63, label %64

63:                                               ; preds = %60
  store i16 4736, ptr %55, align 1, !tbaa !123
  br label %64

64:                                               ; preds = %43, %63, %60, %16
  %65 = phi i16 [ %47, %43 ], [ 4736, %63 ], [ %57, %60 ], [ %37, %16 ]
  %66 = phi i16 [ %45, %43 ], [ %61, %63 ], [ %61, %60 ], [ %29, %16 ]
  %67 = ashr i16 %66, 4
  %68 = ashr i16 %65, 4
  %69 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %70 = getelementptr inbounds nuw i8, ptr %0, i16 88
  %71 = load i8, ptr %70, align 1, !tbaa !127
  %72 = xor i8 %71, 1
  %73 = zext i8 %72 to i16
  %74 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %73
  %75 = getelementptr inbounds nuw i8, ptr %0, i16 89
  %76 = getelementptr inbounds nuw i8, ptr %0, i16 139
  %77 = load i8, ptr %76, align 1, !tbaa !127
  %78 = xor i8 %77, 1
  %79 = zext i8 %78 to i16
  %80 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %79
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef %67, i16 noundef %68, ptr noundef nonnull %74, ptr noundef nonnull %80) #13
  %81 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %82 = load i8, ptr %81, align 1, !tbaa !44
  %83 = icmp ugt i8 %82, 15
  br i1 %83, label %109, label %84

84:                                               ; preds = %64
  %85 = load i8, ptr %70, align 1, !tbaa !127
  %86 = xor i8 %85, 1
  %87 = zext i8 %86 to i16
  %88 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %87
  %89 = ptrtoint ptr %88 to i16
  %90 = zext nneg i8 %82 to i16
  %91 = add nuw nsw i8 %82, 1
  store i8 %91, ptr %81, align 1, !tbaa !44
  %92 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %90
  %93 = getelementptr inbounds nuw i8, ptr %92, i16 10
  store i8 4, ptr %93, align 1, !tbaa !45
  store i16 17202, ptr %92, align 1, !tbaa !47
  %94 = getelementptr inbounds nuw i8, ptr %92, i16 2
  store i16 %89, ptr %94, align 1, !tbaa !51
  %95 = getelementptr inbounds nuw i8, ptr %92, i16 4
  store i16 0, ptr %95, align 1, !tbaa !53
  store i8 %86, ptr %70, align 1, !tbaa !127
  %96 = icmp eq i8 %82, 15
  br i1 %96, label %109, label %97

97:                                               ; preds = %84
  %98 = load i8, ptr %76, align 1, !tbaa !127
  %99 = xor i8 %98, 1
  %100 = zext i8 %99 to i16
  %101 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %100
  %102 = ptrtoint ptr %101 to i16
  %103 = zext nneg i8 %91 to i16
  %104 = add nuw nsw i8 %82, 2
  store i8 %104, ptr %81, align 1, !tbaa !44
  %105 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %103
  %106 = getelementptr inbounds nuw i8, ptr %105, i16 10
  store i8 4, ptr %106, align 1, !tbaa !45
  store i16 17218, ptr %105, align 1, !tbaa !47
  %107 = getelementptr inbounds nuw i8, ptr %105, i16 2
  store i16 %102, ptr %107, align 1, !tbaa !51
  %108 = getelementptr inbounds nuw i8, ptr %105, i16 4
  store i16 0, ptr %108, align 1, !tbaa !53
  store i8 %99, ptr %76, align 1, !tbaa !127
  br label %109

109:                                              ; preds = %64, %84, %97
  %110 = phi i8 [ %82, %64 ], [ 16, %84 ], [ %104, %97 ]
  %111 = getelementptr inbounds nuw i8, ptr %0, i16 28
  %112 = load i8, ptr %111, align 1, !tbaa !81
  %113 = add i8 %112, 1
  store i8 %113, ptr %111, align 1, !tbaa !81
  %114 = getelementptr inbounds nuw i8, ptr %0, i16 32
  %115 = load i8, ptr %114, align 1, !tbaa !84
  %116 = icmp eq i8 %115, 0
  br i1 %116, label %117, label %155

117:                                              ; preds = %109
  %118 = shl i8 %113, 1
  %119 = icmp sgt i8 %118, -1
  br i1 %119, label %122, label %120

120:                                              ; preds = %117
  %121 = xor i8 %118, -1
  br label %122

122:                                              ; preds = %117, %120
  %123 = phi i8 [ %121, %120 ], [ %118, %117 ]
  %124 = lshr i8 %123, 4
  %125 = add nuw nsw i8 %124, 24
  %126 = zext nneg i8 %125 to i16
  %127 = mul nuw nsw i16 %126, 1057
  %128 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 %127, ptr %128, align 1, !tbaa !87
  %129 = add i8 %118, -86
  %130 = icmp sgt i8 %129, -1
  br i1 %130, label %133, label %131

131:                                              ; preds = %122
  %132 = sub nsw i8 85, %118
  br label %133

133:                                              ; preds = %122, %131
  %134 = phi i8 [ %132, %131 ], [ %129, %122 ]
  %135 = lshr i8 %134, 2
  %136 = zext nneg i8 %135 to i16
  %137 = shl nuw nsw i16 %136, 10
  %138 = add i8 %118, 85
  %139 = icmp sgt i8 %138, -1
  br i1 %139, label %142, label %140

140:                                              ; preds = %133
  %141 = sub nuw i8 -86, %118
  br label %142

142:                                              ; preds = %133, %140
  %143 = phi i8 [ %141, %140 ], [ %138, %133 ]
  %144 = lshr i8 %143, 2
  %145 = zext nneg i8 %144 to i16
  %146 = shl nuw nsw i16 %145, 5
  %147 = add nuw nsw i16 %146, %137
  br i1 %119, label %150, label %148

148:                                              ; preds = %142
  %149 = xor i8 %118, -1
  br label %150

150:                                              ; preds = %142, %148
  %151 = phi i8 [ %149, %148 ], [ %118, %142 ]
  %152 = lshr i8 %151, 2
  %153 = zext nneg i8 %152 to i16
  %154 = add nuw nsw i16 %147, %153
  br label %157

155:                                              ; preds = %109
  %156 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 29596, ptr %156, align 1, !tbaa !87
  br label %157

157:                                              ; preds = %155, %150
  %158 = phi i16 [ 0, %155 ], [ %154, %150 ]
  %159 = getelementptr inbounds nuw i8, ptr %0, i16 36
  store i16 %158, ptr %159, align 1, !tbaa !88
  %160 = icmp ugt i8 %110, 15
  br i1 %160, label %188, label %161

161:                                              ; preds = %157
  %162 = getelementptr inbounds nuw i8, ptr %0, i16 34
  %163 = zext nneg i8 %110 to i16
  %164 = add nuw nsw i8 %110, 1
  store i8 %164, ptr %81, align 1, !tbaa !44
  %165 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %163
  %166 = getelementptr inbounds nuw i8, ptr %165, i16 10
  store i8 1, ptr %166, align 1, !tbaa !45
  store i16 113, ptr %165, align 1, !tbaa !47
  %167 = getelementptr inbounds nuw i8, ptr %165, i16 9
  store i8 0, ptr %167, align 1, !tbaa !48
  %168 = getelementptr inbounds nuw i8, ptr %165, i16 7
  store i8 34, ptr %168, align 1, !tbaa !49
  %169 = getelementptr inbounds nuw i8, ptr %165, i16 8
  store i8 0, ptr %169, align 1, !tbaa !50
  %170 = ptrtoint ptr %162 to i16
  %171 = getelementptr inbounds nuw i8, ptr %165, i16 2
  store i16 %170, ptr %171, align 1, !tbaa !51
  %172 = getelementptr inbounds nuw i8, ptr %165, i16 6
  store i8 0, ptr %172, align 1, !tbaa !52
  %173 = getelementptr inbounds nuw i8, ptr %165, i16 4
  store i16 2, ptr %173, align 1, !tbaa !53
  %174 = icmp eq i8 %110, 15
  br i1 %174, label %188, label %175

175:                                              ; preds = %161
  %176 = getelementptr inbounds nuw i8, ptr %0, i16 36
  %177 = zext nneg i8 %164 to i16
  %178 = add nuw nsw i8 %110, 2
  store i8 %178, ptr %81, align 1, !tbaa !44
  %179 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %177
  %180 = getelementptr inbounds nuw i8, ptr %179, i16 10
  store i8 1, ptr %180, align 1, !tbaa !45
  store i16 0, ptr %179, align 1, !tbaa !47
  %181 = getelementptr inbounds nuw i8, ptr %179, i16 9
  store i8 0, ptr %181, align 1, !tbaa !48
  %182 = getelementptr inbounds nuw i8, ptr %179, i16 7
  store i8 34, ptr %182, align 1, !tbaa !49
  %183 = getelementptr inbounds nuw i8, ptr %179, i16 8
  store i8 0, ptr %183, align 1, !tbaa !50
  %184 = ptrtoint ptr %176 to i16
  %185 = getelementptr inbounds nuw i8, ptr %179, i16 2
  store i16 %184, ptr %185, align 1, !tbaa !51
  %186 = getelementptr inbounds nuw i8, ptr %179, i16 6
  store i8 0, ptr %186, align 1, !tbaa !52
  %187 = getelementptr inbounds nuw i8, ptr %179, i16 4
  store i16 2, ptr %187, align 1, !tbaa !53
  br label %188

188:                                              ; preds = %157, %175, %161, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @_title_write16(ptr noundef readonly captures(address_is_null) %0, i8 noundef zeroext %1, i8 noundef zeroext %2) unnamed_addr #3 {
  %4 = zext i8 %1 to i16
  %5 = shl nuw nsw i16 %4, 1
  %6 = and i16 %5, 254
  %7 = sub nsw i16 32, %6
  %8 = lshr exact i16 %7, 1
  %9 = zext i8 %2 to i16
  %10 = icmp eq ptr %0, null
  %11 = and i16 %8, 255
  %12 = add nuw i16 %8, %5
  %13 = and i16 %12, 255
  br label %15

14:                                               ; preds = %23
  ret void

15:                                               ; preds = %3, %23
  %16 = phi i1 [ true, %3 ], [ false, %23 ]
  %17 = phi i8 [ 0, %3 ], [ 1, %23 ]
  %18 = zext nneg i8 %17 to i16
  %19 = add nuw nsw i16 %18, %9
  %20 = shl nuw nsw i16 %19, 5
  %21 = add nuw nsw i16 %20, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %21, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %22 = select i1 %16, i16 7168, i16 7170
  br label %24

23:                                               ; preds = %56
  br i1 %16, label %15, label %14, !llvm.loop !128

24:                                               ; preds = %15, %56
  %25 = phi i8 [ 0, %15 ], [ %58, %56 ]
  %26 = zext nneg i8 %25 to i16
  br i1 %10, label %56, label %27

27:                                               ; preds = %24
  %28 = icmp samesign ugt i16 %11, %26
  br i1 %28, label %56, label %29

29:                                               ; preds = %27
  %30 = icmp samesign ugt i16 %13, %26
  br i1 %30, label %31, label %56

31:                                               ; preds = %29
  %32 = sub nsw i16 %26, %11
  %33 = lshr i16 %32, 1
  %34 = and i16 %33, 255
  %35 = getelementptr inbounds nuw i8, ptr %0, i16 %34
  %36 = load i8, ptr %35, align 1, !tbaa !6
  %37 = icmp ugt i8 %36, 96
  br i1 %37, label %38, label %42

38:                                               ; preds = %31
  %39 = icmp ult i8 %36, 123
  br i1 %39, label %40, label %51

40:                                               ; preds = %38
  %41 = add nsw i8 %36, -32
  br label %46

42:                                               ; preds = %31
  %43 = icmp samesign ugt i8 %36, 31
  br i1 %43, label %44, label %51

44:                                               ; preds = %42
  %45 = icmp eq i8 %36, 96
  br i1 %45, label %51, label %46

46:                                               ; preds = %44, %40
  %47 = phi i8 [ %41, %40 ], [ %36, %44 ]
  %48 = zext nneg i8 %47 to i16
  %49 = shl nuw nsw i16 %48, 2
  %50 = add nsw i16 %49, -64
  br label %51

51:                                               ; preds = %38, %42, %44, %46
  %52 = phi i16 [ %50, %46 ], [ 64, %44 ], [ 64, %42 ], [ 64, %38 ]
  %53 = and i16 %32, 1
  %54 = or disjoint i16 %22, %53
  %55 = or disjoint i16 %54, %52
  br label %56

56:                                               ; preds = %51, %29, %27, %24
  %57 = phi i16 [ %55, %51 ], [ 7168, %29 ], [ 7168, %27 ], [ 7168, %24 ]
  store volatile i16 %57, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %58 = add nuw nsw i8 %25, 1
  %59 = icmp eq i8 %58, 32
  br i1 %59, label %23, label %24, !llvm.loop !129
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_build(ptr noundef readonly captures(none) %0, i16 noundef range(i16 -2048, 2048) %1, i16 noundef range(i16 -2048, 2048) %2, ptr noundef %3, ptr noundef %4) unnamed_addr #6 {
  %6 = alloca %struct.HScrollW, align 1
  %7 = alloca %struct.HScrollW, align 1
  %8 = alloca i16, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #14
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #14
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #14
  store i16 0, ptr %8, align 1, !tbaa !2
  store ptr %3, ptr %6, align 1, !tbaa !130
  %9 = getelementptr inbounds nuw i8, ptr %6, i16 2
  store i8 0, ptr %9, align 1, !tbaa !132
  store ptr %4, ptr %7, align 1, !tbaa !130
  %10 = getelementptr inbounds nuw i8, ptr %7, i16 2
  store i8 0, ptr %10, align 1, !tbaa !132
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %12 = load i16, ptr %11, align 1, !tbaa !78
  %13 = getelementptr inbounds nuw i8, ptr %0, i16 26
  %14 = load i16, ptr %13, align 1, !tbaa !126
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %1, i16 noundef 8, i16 noundef %12, i16 noundef %14) #13
  %15 = getelementptr inbounds nuw i8, ptr %0, i16 17
  %16 = load i16, ptr %15, align 1, !tbaa !80
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %18 = load i16, ptr %17, align 1, !tbaa !79
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %2, i16 noundef %16, i16 noundef %18, i16 noundef 0) #13
  %19 = load i16, ptr %8, align 1, !tbaa !2
  call fastcc void @_title_blank(ptr noundef %6, ptr noundef %7, i16 noundef %19, i16 noundef 224) #13
  %20 = load ptr, ptr %6, align 1, !tbaa !130
  %21 = load i8, ptr %9, align 1, !tbaa !132
  %22 = zext i8 %21 to i16
  %23 = getelementptr inbounds nuw i8, ptr %20, i16 %22
  store i8 0, ptr %23, align 1, !tbaa !6
  %24 = load ptr, ptr %7, align 1, !tbaa !130
  %25 = load i8, ptr %10, align 1, !tbaa !132
  %26 = zext i8 %25 to i16
  %27 = getelementptr inbounds nuw i8, ptr %24, i16 %26
  store i8 0, ptr %27, align 1, !tbaa !6
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #14
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #14
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #14
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_glyph_band(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, ptr noundef nonnull captures(none) %2, i16 noundef range(i16 -2048, 2048) %3, i16 noundef %4, i16 noundef %5, i16 noundef %6) unnamed_addr #6 {
  %8 = add nsw i16 %3, -2
  %9 = add nsw i16 %4, %3
  %10 = add nsw i16 %9, 2
  %11 = load i16, ptr %2, align 1, !tbaa !2
  %12 = icmp slt i16 %8, %11
  br i1 %12, label %13, label %14

13:                                               ; preds = %7
  br label %14

14:                                               ; preds = %13, %7
  %15 = phi i16 [ %11, %13 ], [ %8, %7 ]
  %16 = icmp sgt i16 %9, 222
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  br label %18

18:                                               ; preds = %17, %14
  %19 = phi i16 [ 224, %17 ], [ %10, %14 ]
  %20 = icmp sgt i16 %19, %15
  br i1 %20, label %21, label %92

21:                                               ; preds = %18
  tail call fastcc void @_title_blank(ptr noundef %0, ptr noundef %1, i16 noundef %11, i16 noundef %15) #13
  %22 = sub nsw i16 %19, %15
  %23 = trunc i16 %22 to i8
  %24 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %25 = icmp eq i8 %23, 0
  br i1 %25, label %91, label %26

26:                                               ; preds = %21
  %27 = sub nsw i16 %5, %3
  %28 = and i16 %22, 255
  %29 = trunc i16 %27 to i8
  %30 = lshr i16 %27, 8
  %31 = trunc nuw i16 %30 to i8
  br label %32

32:                                               ; preds = %40, %26
  %33 = phi i16 [ %28, %26 ], [ %57, %40 ]
  %34 = load i8, ptr %24, align 1, !tbaa !132
  %35 = icmp ult i8 %34, 22
  br i1 %35, label %36, label %59

36:                                               ; preds = %32
  %37 = icmp ugt i16 %33, 127
  br i1 %37, label %40, label %38

38:                                               ; preds = %36
  %39 = trunc nuw nsw i16 %33 to i8
  br label %40

40:                                               ; preds = %38, %36
  %41 = phi i8 [ %39, %38 ], [ 127, %36 ]
  %42 = load ptr, ptr %0, align 1, !tbaa !130
  %43 = add nuw nsw i8 %34, 1
  store i8 %43, ptr %24, align 1, !tbaa !132
  %44 = zext nneg i8 %34 to i16
  %45 = getelementptr inbounds nuw i8, ptr %42, i16 %44
  store i8 %41, ptr %45, align 1, !tbaa !6
  %46 = load ptr, ptr %0, align 1, !tbaa !130
  %47 = load i8, ptr %24, align 1, !tbaa !132
  %48 = add i8 %47, 1
  store i8 %48, ptr %24, align 1, !tbaa !132
  %49 = zext i8 %47 to i16
  %50 = getelementptr inbounds nuw i8, ptr %46, i16 %49
  store i8 %29, ptr %50, align 1, !tbaa !6
  %51 = load ptr, ptr %0, align 1, !tbaa !130
  %52 = load i8, ptr %24, align 1, !tbaa !132
  %53 = add i8 %52, 1
  store i8 %53, ptr %24, align 1, !tbaa !132
  %54 = zext i8 %52 to i16
  %55 = getelementptr inbounds nuw i8, ptr %51, i16 %54
  store i8 %31, ptr %55, align 1, !tbaa !6
  %56 = zext nneg i8 %41 to i16
  %57 = sub i16 %33, %56
  %58 = icmp eq i16 %57, 0
  br i1 %58, label %59, label %32, !llvm.loop !133

59:                                               ; preds = %32, %40
  %60 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %61 = trunc i16 %6 to i8
  %62 = lshr i16 %6, 8
  %63 = trunc nuw i16 %62 to i8
  br label %64

64:                                               ; preds = %72, %59
  %65 = phi i16 [ %28, %59 ], [ %89, %72 ]
  %66 = load i8, ptr %60, align 1, !tbaa !132
  %67 = icmp ult i8 %66, 22
  br i1 %67, label %68, label %91

68:                                               ; preds = %64
  %69 = icmp ugt i16 %65, 127
  br i1 %69, label %72, label %70

70:                                               ; preds = %68
  %71 = trunc nuw nsw i16 %65 to i8
  br label %72

72:                                               ; preds = %70, %68
  %73 = phi i8 [ %71, %70 ], [ 127, %68 ]
  %74 = load ptr, ptr %1, align 1, !tbaa !130
  %75 = add nuw nsw i8 %66, 1
  store i8 %75, ptr %60, align 1, !tbaa !132
  %76 = zext nneg i8 %66 to i16
  %77 = getelementptr inbounds nuw i8, ptr %74, i16 %76
  store i8 %73, ptr %77, align 1, !tbaa !6
  %78 = load ptr, ptr %1, align 1, !tbaa !130
  %79 = load i8, ptr %60, align 1, !tbaa !132
  %80 = add i8 %79, 1
  store i8 %80, ptr %60, align 1, !tbaa !132
  %81 = zext i8 %79 to i16
  %82 = getelementptr inbounds nuw i8, ptr %78, i16 %81
  store i8 %61, ptr %82, align 1, !tbaa !6
  %83 = load ptr, ptr %1, align 1, !tbaa !130
  %84 = load i8, ptr %60, align 1, !tbaa !132
  %85 = add i8 %84, 1
  store i8 %85, ptr %60, align 1, !tbaa !132
  %86 = zext i8 %84 to i16
  %87 = getelementptr inbounds nuw i8, ptr %83, i16 %86
  store i8 %63, ptr %87, align 1, !tbaa !6
  %88 = zext nneg i8 %73 to i16
  %89 = sub i16 %65, %88
  %90 = icmp eq i16 %89, 0
  br i1 %90, label %91, label %64, !llvm.loop !133

91:                                               ; preds = %64, %72, %21
  store i16 %19, ptr %2, align 1, !tbaa !2
  br label %92

92:                                               ; preds = %18, %91
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_blank(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, i16 noundef %2, i16 noundef range(i16 -2050, 225) %3) unnamed_addr #6 {
  %5 = icmp sgt i16 %3, %2
  br i1 %5, label %6, label %83

6:                                                ; preds = %4
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 2
  br label %9

9:                                                ; preds = %6, %79
  %10 = phi i16 [ %2, %6 ], [ %81, %79 ]
  %11 = sub nsw i16 %3, %10
  %12 = icmp sgt i16 %11, 112
  br i1 %12, label %16, label %13

13:                                               ; preds = %9
  %14 = trunc i16 %11 to i8
  %15 = icmp eq i8 %14, 0
  br i1 %15, label %79, label %16

16:                                               ; preds = %9, %13
  %17 = phi i8 [ %14, %13 ], [ 112, %9 ]
  %18 = phi i16 [ %11, %13 ], [ 112, %9 ]
  %19 = sub nsw i16 144, %10
  %20 = zext i8 %17 to i16
  %21 = trunc i16 %19 to i8
  %22 = lshr i16 %19, 8
  %23 = trunc nuw i16 %22 to i8
  br label %24

24:                                               ; preds = %32, %16
  %25 = phi i16 [ %20, %16 ], [ %49, %32 ]
  %26 = load i8, ptr %7, align 1, !tbaa !132
  %27 = icmp ult i8 %26, 22
  br i1 %27, label %28, label %51

28:                                               ; preds = %24
  %29 = icmp ugt i16 %25, 127
  br i1 %29, label %32, label %30

30:                                               ; preds = %28
  %31 = trunc nuw nsw i16 %25 to i8
  br label %32

32:                                               ; preds = %30, %28
  %33 = phi i8 [ %31, %30 ], [ 127, %28 ]
  %34 = load ptr, ptr %0, align 1, !tbaa !130
  %35 = add nuw nsw i8 %26, 1
  store i8 %35, ptr %7, align 1, !tbaa !132
  %36 = zext nneg i8 %26 to i16
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 %36
  store i8 %33, ptr %37, align 1, !tbaa !6
  %38 = load ptr, ptr %0, align 1, !tbaa !130
  %39 = load i8, ptr %7, align 1, !tbaa !132
  %40 = add i8 %39, 1
  store i8 %40, ptr %7, align 1, !tbaa !132
  %41 = zext i8 %39 to i16
  %42 = getelementptr inbounds nuw i8, ptr %38, i16 %41
  store i8 %21, ptr %42, align 1, !tbaa !6
  %43 = load ptr, ptr %0, align 1, !tbaa !130
  %44 = load i8, ptr %7, align 1, !tbaa !132
  %45 = add i8 %44, 1
  store i8 %45, ptr %7, align 1, !tbaa !132
  %46 = zext i8 %44 to i16
  %47 = getelementptr inbounds nuw i8, ptr %43, i16 %46
  store i8 %23, ptr %47, align 1, !tbaa !6
  %48 = zext nneg i8 %33 to i16
  %49 = sub i16 %25, %48
  %50 = icmp eq i16 %49, 0
  br i1 %50, label %51, label %24, !llvm.loop !133

51:                                               ; preds = %24, %32
  br label %52

52:                                               ; preds = %51, %60
  %53 = phi i16 [ %77, %60 ], [ %20, %51 ]
  %54 = load i8, ptr %8, align 1, !tbaa !132
  %55 = icmp ult i8 %54, 22
  br i1 %55, label %56, label %79

56:                                               ; preds = %52
  %57 = icmp ugt i16 %53, 127
  br i1 %57, label %60, label %58

58:                                               ; preds = %56
  %59 = trunc nuw nsw i16 %53 to i8
  br label %60

60:                                               ; preds = %58, %56
  %61 = phi i8 [ %59, %58 ], [ 127, %56 ]
  %62 = load ptr, ptr %1, align 1, !tbaa !130
  %63 = add nuw nsw i8 %54, 1
  store i8 %63, ptr %8, align 1, !tbaa !132
  %64 = zext nneg i8 %54 to i16
  %65 = getelementptr inbounds nuw i8, ptr %62, i16 %64
  store i8 %61, ptr %65, align 1, !tbaa !6
  %66 = load ptr, ptr %1, align 1, !tbaa !130
  %67 = load i8, ptr %8, align 1, !tbaa !132
  %68 = add i8 %67, 1
  store i8 %68, ptr %8, align 1, !tbaa !132
  %69 = zext i8 %67 to i16
  %70 = getelementptr inbounds nuw i8, ptr %66, i16 %69
  store i8 0, ptr %70, align 1, !tbaa !6
  %71 = load ptr, ptr %1, align 1, !tbaa !130
  %72 = load i8, ptr %8, align 1, !tbaa !132
  %73 = add i8 %72, 1
  store i8 %73, ptr %8, align 1, !tbaa !132
  %74 = zext i8 %72 to i16
  %75 = getelementptr inbounds nuw i8, ptr %71, i16 %74
  store i8 0, ptr %75, align 1, !tbaa !6
  %76 = zext nneg i8 %61 to i16
  %77 = sub i16 %53, %76
  %78 = icmp eq i16 %77, 0
  br i1 %78, label %79, label %52, !llvm.loop !133

79:                                               ; preds = %52, %60, %13
  %80 = phi i16 [ %11, %13 ], [ %18, %60 ], [ %18, %52 ]
  %81 = add nsw i16 %80, %10
  %82 = icmp sgt i16 %3, %81
  br i1 %82, label %9, label %83, !llvm.loop !134

83:                                               ; preds = %79, %4
  ret void
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #7

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64) #7

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @upq_flush() unnamed_addr #8 {
  %1 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 177), align 1, !tbaa !135
  %2 = zext i8 %1 to i16
  %3 = shl nuw nsw i16 %2, 4
  %4 = add nuw nsw i16 %3, 17152
  %5 = inttoptr i16 %4 to ptr
  %6 = shl nuw i16 1, %2
  %7 = trunc i16 %6 to i8
  %8 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %108, label %10

10:                                               ; preds = %0
  %11 = getelementptr inbounds nuw i8, ptr %5, i16 1
  %12 = getelementptr inbounds nuw i8, ptr %5, i16 2
  %13 = getelementptr inbounds nuw i8, ptr %5, i16 3
  %14 = getelementptr inbounds nuw i8, ptr %5, i16 4
  %15 = getelementptr inbounds nuw i8, ptr %5, i16 5
  %16 = getelementptr inbounds nuw i8, ptr %5, i16 6
  br label %17

17:                                               ; preds = %10, %86
  %18 = phi i8 [ %8, %10 ], [ %89, %86 ]
  %19 = phi i16 [ 0, %10 ], [ %87, %86 ]
  %20 = phi i8 [ 0, %10 ], [ %88, %86 ]
  %21 = zext i8 %20 to i16
  %22 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %21
  %23 = getelementptr inbounds nuw i8, ptr %22, i16 10
  %24 = load i8, ptr %23, align 1, !tbaa !45
  switch i8 %24, label %44 [
    i8 3, label %25
    i8 4, label %34
  ]

25:                                               ; preds = %17
  %26 = load i16, ptr %22, align 1, !tbaa !47
  %27 = inttoptr i16 %26 to ptr
  %28 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %29 = load i16, ptr %28, align 1, !tbaa !51
  %30 = trunc i16 %29 to i8
  store volatile i8 %30, ptr %27, align 1, !tbaa !6
  %31 = load i16, ptr %28, align 1, !tbaa !51
  %32 = lshr i16 %31, 8
  %33 = trunc nuw i16 %32 to i8
  store volatile i8 %33, ptr %27, align 1, !tbaa !6
  br label %86

34:                                               ; preds = %17
  %35 = load i16, ptr %22, align 1, !tbaa !47
  %36 = inttoptr i16 %35 to ptr
  %37 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %38 = load i16, ptr %37, align 1, !tbaa !51
  %39 = trunc i16 %38 to i8
  store volatile i8 %39, ptr %36, align 1, !tbaa !6
  %40 = load i16, ptr %37, align 1, !tbaa !51
  %41 = lshr i16 %40, 8
  %42 = trunc nuw i16 %41 to i8
  %43 = getelementptr inbounds nuw i8, ptr %36, i16 1
  store volatile i8 %42, ptr %43, align 1, !tbaa !6
  br label %86

44:                                               ; preds = %17
  %45 = icmp eq i16 %19, 0
  br i1 %45, label %51, label %46

46:                                               ; preds = %44
  %47 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %48 = load i16, ptr %47, align 1, !tbaa !53
  %49 = add i16 %48, %19
  %50 = icmp ugt i16 %49, 5100
  br i1 %50, label %91, label %51

51:                                               ; preds = %46, %44
  switch i8 %24, label %59 [
    i8 0, label %52
    i8 1, label %56
  ]

52:                                               ; preds = %51
  %53 = getelementptr inbounds nuw i8, ptr %22, i16 9
  %54 = load i8, ptr %53, align 1, !tbaa !48
  store volatile i8 %54, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  %55 = load i16, ptr %22, align 1, !tbaa !47
  store volatile i16 %55, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %65

56:                                               ; preds = %51
  %57 = load i16, ptr %22, align 1, !tbaa !47
  %58 = trunc i16 %57 to i8
  store volatile i8 %58, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  br label %65

59:                                               ; preds = %51
  %60 = load i16, ptr %22, align 1, !tbaa !47
  %61 = trunc i16 %60 to i8
  store volatile i8 %61, ptr inttoptr (i16 8450 to ptr), align 2, !tbaa !6
  %62 = load i16, ptr %22, align 1, !tbaa !47
  %63 = lshr i16 %62, 8
  %64 = trunc nuw i16 %63 to i8
  store volatile i8 %64, ptr inttoptr (i16 8451 to ptr), align 1, !tbaa !6
  br label %65

65:                                               ; preds = %56, %59, %52
  %66 = getelementptr inbounds nuw i8, ptr %22, i16 8
  %67 = load i8, ptr %66, align 1, !tbaa !50
  store volatile i8 %67, ptr %5, align 16, !tbaa !6
  %68 = getelementptr inbounds nuw i8, ptr %22, i16 7
  %69 = load i8, ptr %68, align 1, !tbaa !49
  store volatile i8 %69, ptr %11, align 1, !tbaa !6
  %70 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %71 = load i16, ptr %70, align 1, !tbaa !51
  %72 = trunc i16 %71 to i8
  store volatile i8 %72, ptr %12, align 2, !tbaa !6
  %73 = load i16, ptr %70, align 1, !tbaa !51
  %74 = lshr i16 %73, 8
  %75 = trunc nuw i16 %74 to i8
  store volatile i8 %75, ptr %13, align 1, !tbaa !6
  %76 = getelementptr inbounds nuw i8, ptr %22, i16 6
  %77 = load i8, ptr %76, align 1, !tbaa !52
  store volatile i8 %77, ptr %14, align 4, !tbaa !6
  %78 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %79 = load i16, ptr %78, align 1, !tbaa !53
  %80 = trunc i16 %79 to i8
  store volatile i8 %80, ptr %15, align 1, !tbaa !6
  %81 = load i16, ptr %78, align 1, !tbaa !53
  %82 = lshr i16 %81, 8
  %83 = trunc nuw i16 %82 to i8
  store volatile i8 %83, ptr %16, align 2, !tbaa !6
  store volatile i8 %7, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !6
  %84 = load i16, ptr %78, align 1, !tbaa !53
  %85 = add i16 %84, %19
  br label %86

86:                                               ; preds = %65, %34, %25
  %87 = phi i16 [ %19, %25 ], [ %19, %34 ], [ %85, %65 ]
  %88 = add nuw i8 %20, 1
  %89 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %90 = icmp ult i8 %88, %89
  br i1 %90, label %17, label %91

91:                                               ; preds = %86, %46
  %92 = phi i8 [ %89, %86 ], [ %18, %46 ]
  %93 = phi i8 [ %88, %86 ], [ %20, %46 ]
  %94 = icmp ult i8 %93, %92
  br i1 %94, label %95, label %108

95:                                               ; preds = %91
  %96 = icmp eq i8 %93, 0
  br i1 %96, label %110, label %97

97:                                               ; preds = %95, %97
  %98 = phi i8 [ %101, %97 ], [ 0, %95 ]
  %99 = phi i8 [ %104, %97 ], [ %93, %95 ]
  %100 = zext i8 %99 to i16
  %101 = add i8 %98, 1
  %102 = zext i8 %98 to i16
  %103 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %102
  %104 = add nuw i8 %99, 1
  %105 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %100
  tail call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(11) %103, ptr noundef nonnull align 1 dereferenceable(11) %105, i16 11, i1 false), !tbaa.struct !136
  %106 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %107 = icmp ult i8 %104, %106
  br i1 %107, label %97, label %108, !llvm.loop !137

108:                                              ; preds = %97, %91, %0
  %109 = phi i8 [ 0, %91 ], [ 0, %0 ], [ %101, %97 ]
  store i8 %109, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  br label %110

110:                                              ; preds = %108, %95
  ret void
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #10

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #11

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #11

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree noinline norecurse nosync nounwind optsize memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #3 = { nofree norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #4 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #5 = { nofree norecurse nosync nounwind optsize memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #6 = { nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #7 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #8 = { nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #9 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #10 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #12 = { nounwind optsize }
attributes #13 = { optsize }
attributes #14 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!10, !4, i64 194}
!10 = !{!"", !11, i64 0, !12, i64 178, !13, i64 182, !4, i64 191, !4, i64 192, !4, i64 193, !4, i64 194, !4, i64 195}
!11 = !{!"", !4, i64 0, !4, i64 176, !4, i64 177}
!12 = !{!"", !3, i64 0, !3, i64 2}
!13 = !{!"", !4, i64 0, !4, i64 8}
!14 = !{!10, !4, i64 195}
!15 = !{!16, !18, i64 0}
!16 = !{!"", !17, i64 0, !4, i64 3, !3, i64 4099, !3, i64 4101, !3, i64 4103, !3, i64 4105, !4, i64 4107, !4, i64 4108}
!17 = !{!"Drawable", !18, i64 0, !4, i64 2}
!18 = !{!"any pointer", !4, i64 0}
!19 = !{!16, !4, i64 2}
!20 = !{!16, !3, i64 4103}
!21 = !{!16, !3, i64 4105}
!22 = !{!16, !4, i64 4107}
!23 = !{!16, !4, i64 4108}
!24 = !{!16, !3, i64 4099}
!25 = !{!16, !3, i64 4101}
!26 = !{!27, !18, i64 0}
!27 = !{!"", !17, i64 0, !3, i64 3, !4, i64 5, !4, i64 7, !4, i64 135}
!28 = !{!27, !4, i64 2}
!29 = !{!27, !3, i64 3}
!30 = distinct !{!30, !8}
!31 = !{!27, !4, i64 135}
!32 = !{!10, !4, i64 192}
!33 = !{!10, !4, i64 193}
!34 = !{!13, !4, i64 8}
!35 = !{!36, !36, i64 0}
!36 = !{!"p1 _ZTS8Drawable", !18, i64 0}
!37 = distinct !{null, null}
!38 = !{!10, !4, i64 191}
!39 = !{!17, !4, i64 2}
!40 = !{!17, !18, i64 0}
!41 = !{!42, !18, i64 0}
!42 = !{!"", !18, i64 0, !18, i64 2}
!43 = distinct !{null, null, null}
!44 = !{!11, !4, i64 176}
!45 = !{!46, !4, i64 10}
!46 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !4, i64 6, !4, i64 7, !4, i64 8, !4, i64 9, !4, i64 10}
!47 = !{!46, !3, i64 0}
!48 = !{!46, !4, i64 9}
!49 = !{!46, !4, i64 7}
!50 = !{!46, !4, i64 8}
!51 = !{!46, !3, i64 2}
!52 = !{!46, !4, i64 6}
!53 = !{!46, !3, i64 4}
!54 = !{!55, !4, i64 0}
!55 = !{!"", !4, i64 0, !4, i64 1, !4, i64 2, !4, i64 3, !4, i64 4, !56, i64 5}
!56 = !{!"long long", !4, i64 0}
!57 = !{!55, !4, i64 1}
!58 = !{!55, !4, i64 2}
!59 = !{!55, !4, i64 3}
!60 = !{!55, !4, i64 4}
!61 = !{!55, !56, i64 5}
!62 = distinct !{!62, !8}
!63 = !{!64, !3, i64 4519}
!64 = !{!"", !10, i64 0, !16, i64 196, !27, i64 4305, !4, i64 4441, !3, i64 4519}
!65 = distinct !{!65, !8}
!66 = !{!67, !18, i64 0}
!67 = !{!"", !17, i64 0, !68, i64 3, !68, i64 5, !68, i64 7, !68, i64 9, !4, i64 11, !4, i64 12, !3, i64 13, !3, i64 15, !3, i64 17, !3, i64 19, !3, i64 21, !3, i64 23, !4, i64 25, !3, i64 26, !4, i64 28, !4, i64 29, !4, i64 30, !4, i64 31, !4, i64 32, !4, i64 33, !3, i64 34, !3, i64 36, !69, i64 38, !69, i64 89}
!68 = !{!"p1 omnipotent char", !18, i64 0}
!69 = !{!"", !4, i64 0, !4, i64 50}
!70 = !{!67, !4, i64 2}
!71 = !{!67, !68, i64 3}
!72 = !{!67, !68, i64 5}
!73 = !{!67, !68, i64 7}
!74 = distinct !{!74, !8}
!75 = !{!67, !4, i64 11}
!76 = !{!67, !68, i64 9}
!77 = !{!67, !4, i64 12}
!78 = !{!67, !3, i64 13}
!79 = !{!67, !3, i64 15}
!80 = !{!67, !3, i64 17}
!81 = !{!67, !4, i64 28}
!82 = !{!67, !4, i64 29}
!83 = !{!67, !4, i64 31}
!84 = !{!67, !4, i64 32}
!85 = !{!67, !4, i64 30}
!86 = !{!67, !4, i64 25}
!87 = !{!67, !3, i64 34}
!88 = !{!67, !3, i64 36}
!89 = !{!67, !4, i64 33}
!90 = !{!42, !18, i64 2}
!91 = distinct !{null, null, null, null, null}
!92 = distinct !{!92, !8}
!93 = distinct !{!93, !8}
!94 = distinct !{!94, !8}
!95 = distinct !{null, null, null, null}
!96 = distinct !{!96, !8}
!97 = distinct !{!97, !8}
!98 = distinct !{null, null, null, null, null}
!99 = distinct !{!99, !8}
!100 = distinct !{!100, !8}
!101 = distinct !{null, null, null, null}
!102 = !{!67, !3, i64 19}
!103 = distinct !{null, null, null, null, null}
!104 = distinct !{null, null, null}
!105 = distinct !{!105, !8}
!106 = distinct !{!106, !8}
!107 = distinct !{!107, !8}
!108 = distinct !{!108, !8}
!109 = distinct !{!109, !8}
!110 = distinct !{!110, !8}
!111 = distinct !{!111, !8}
!112 = distinct !{!112, !8}
!113 = distinct !{!113, !8}
!114 = distinct !{!114, !8}
!115 = distinct !{!115, !8}
!116 = distinct !{!116, !8}
!117 = distinct !{!117, !8}
!118 = distinct !{!118, !8}
!119 = distinct !{!119, !8}
!120 = distinct !{!120, !8}
!121 = distinct !{!121, !8}
!122 = distinct !{!122, !8}
!123 = !{!67, !3, i64 21}
!124 = !{!67, !3, i64 23}
!125 = distinct !{!125, !8}
!126 = !{!67, !3, i64 26}
!127 = !{!69, !4, i64 50}
!128 = distinct !{!128, !8}
!129 = distinct !{!129, !8}
!130 = !{!131, !18, i64 0}
!131 = !{!"", !18, i64 0, !4, i64 2}
!132 = !{!131, !4, i64 2}
!133 = distinct !{!133, !8}
!134 = distinct !{!134, !8}
!135 = !{!11, !4, i64 177}
!136 = !{i64 0, i64 2, !2, i64 2, i64 2, !2, i64 4, i64 2, !2, i64 6, i64 1, !6, i64 7, i64 1, !6, i64 8, i64 1, !6, i64 9, i64 1, !6, i64 10, i64 1, !6}
!137 = distinct !{!137, !8}
