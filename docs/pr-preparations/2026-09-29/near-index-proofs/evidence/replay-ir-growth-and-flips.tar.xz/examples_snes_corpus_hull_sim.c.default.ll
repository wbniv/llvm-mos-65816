; ModuleID = '/work/examples/snes/corpus/hull_sim.c'
source_filename = "/work/examples/snes/corpus/hull_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.HlPt = type { i16, i16 }

@corpus_result = dso_local global i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [14 x %struct.HlPt], align 1
  %2 = alloca [14 x i8], align 1
  %3 = getelementptr inbounds nuw i8, ptr %1, i16 4
  %4 = getelementptr inbounds nuw i8, ptr %1, i16 6
  %5 = getelementptr inbounds nuw i8, ptr %1, i16 2
  br label %6

6:                                                ; preds = %137, %0
  %7 = phi i16 [ 0, %0 ], [ %139, %137 ]
  %8 = phi i16 [ 0, %0 ], [ %140, %137 ]
  %9 = phi i16 [ 20973, %0 ], [ %131, %137 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #3
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #3
  br label %113

10:                                               ; preds = %113, %30
  %11 = phi i8 [ %34, %30 ], [ 0, %113 ]
  %12 = phi i8 [ %31, %30 ], [ 0, %113 ]
  %13 = phi i8 [ %32, %30 ], [ 1, %113 ]
  %14 = zext nneg i8 %11 to i16
  %15 = getelementptr i8, ptr %3, i16 %14
  %16 = load i16, ptr %15, align 1, !tbaa !6
  %17 = zext i8 %12 to i16
  %18 = getelementptr inbounds nuw [4 x i8], ptr %1, i16 %17
  %19 = load i16, ptr %18, align 1, !tbaa !6
  %20 = icmp slt i16 %16, %19
  br i1 %20, label %29, label %21

21:                                               ; preds = %10
  %22 = icmp eq i16 %16, %19
  br i1 %22, label %23, label %30

23:                                               ; preds = %21
  %24 = getelementptr i8, ptr %4, i16 %14
  %25 = load i16, ptr %24, align 1, !tbaa !8
  %26 = getelementptr inbounds nuw i8, ptr %18, i16 2
  %27 = load i16, ptr %26, align 1, !tbaa !8
  %28 = icmp slt i16 %25, %27
  br i1 %28, label %29, label %30

29:                                               ; preds = %23, %10
  br label %30

30:                                               ; preds = %29, %23, %21
  %31 = phi i8 [ %13, %29 ], [ %12, %23 ], [ %12, %21 ]
  %32 = add nuw nsw i8 %13, 1
  %33 = icmp eq i8 %32, 14
  %34 = add nuw nsw i8 %11, 4
  br i1 %33, label %35, label %10, !llvm.loop !9

35:                                               ; preds = %30, %47
  %36 = phi i8 [ %52, %47 ], [ 1, %30 ]
  %37 = phi i8 [ %105, %47 ], [ %31, %30 ]
  %38 = phi i8 [ %48, %47 ], [ 0, %30 ]
  %39 = zext nneg i8 %38 to i16
  %40 = getelementptr i8, ptr %2, i16 %39
  store i8 %37, ptr %40, align 1, !tbaa !11
  %41 = zext i8 %37 to i16
  %42 = add nuw nsw i16 %41, 1
  %43 = urem i16 %42, 14
  %44 = trunc nuw nsw i16 %43 to i8
  %45 = getelementptr inbounds nuw [4 x i8], ptr %1, i16 %41
  %46 = getelementptr inbounds nuw i8, ptr %45, i16 2
  br label %53

47:                                               ; preds = %104
  %48 = add nuw nsw i8 %38, 1
  %49 = icmp ne i8 %105, %31
  %50 = icmp samesign ult i8 %38, 13
  %51 = select i1 %49, i1 %50, i1 false
  %52 = add nuw nsw i8 %36, 1
  br i1 %51, label %35, label %109, !llvm.loop !12

53:                                               ; preds = %104, %35
  %54 = phi i8 [ 0, %35 ], [ %108, %104 ]
  %55 = phi i8 [ 0, %35 ], [ %106, %104 ]
  %56 = phi i8 [ %44, %35 ], [ %105, %104 ]
  %57 = icmp eq i8 %55, %37
  br i1 %57, label %104, label %58

58:                                               ; preds = %53
  %59 = zext i8 %56 to i16
  %60 = getelementptr inbounds nuw [4 x i8], ptr %1, i16 %59
  %61 = zext nneg i8 %54 to i16
  %62 = getelementptr i8, ptr %1, i16 %61
  %63 = load i16, ptr %45, align 1
  %64 = load i16, ptr %46, align 1
  %65 = load i16, ptr %60, align 1
  %66 = getelementptr inbounds nuw i8, ptr %60, i16 2
  %67 = load i16, ptr %66, align 1
  %68 = load i16, ptr %62, align 1
  %69 = getelementptr i8, ptr %5, i16 %61
  %70 = load i16, ptr %69, align 1
  %71 = sext i16 %65 to i32
  %72 = sext i16 %63 to i32
  %73 = sub nsw i32 %71, %72
  %74 = sext i16 %67 to i32
  %75 = sext i16 %64 to i32
  %76 = sub nsw i32 %74, %75
  %77 = sext i16 %68 to i32
  %78 = sub nsw i32 %72, %77
  %79 = sext i16 %70 to i32
  %80 = sub nsw i32 %79, %75
  %81 = mul nsw i32 %80, %73
  %82 = mul i32 %78, %76
  %83 = add i32 %81, %82
  %84 = icmp slt i32 %83, 0
  br i1 %84, label %104, label %85

85:                                               ; preds = %58
  %86 = icmp eq i32 %83, 0
  br i1 %86, label %87, label %104

87:                                               ; preds = %85
  %88 = sub nsw i16 %65, %63
  %89 = sext i16 %88 to i32
  %90 = mul nsw i32 %89, %89
  %91 = sub nsw i16 %67, %64
  %92 = sext i16 %91 to i32
  %93 = mul nsw i32 %92, %92
  %94 = add nuw nsw i32 %93, %90
  %95 = sub nsw i16 %68, %63
  %96 = sext i16 %95 to i32
  %97 = mul nsw i32 %96, %96
  %98 = sub nsw i16 %70, %64
  %99 = sext i16 %98 to i32
  %100 = mul nsw i32 %99, %99
  %101 = add nuw nsw i32 %100, %97
  %102 = icmp samesign ugt i32 %101, %94
  br i1 %102, label %103, label %104

103:                                              ; preds = %87
  br label %104

104:                                              ; preds = %103, %87, %85, %58, %53
  %105 = phi i8 [ %56, %53 ], [ %56, %85 ], [ %55, %58 ], [ %55, %103 ], [ %56, %87 ]
  %106 = add nuw nsw i8 %55, 1
  %107 = icmp eq i8 %106, 14
  %108 = add nuw nsw i8 %54, 4
  br i1 %107, label %47, label %53, !llvm.loop !13

109:                                              ; preds = %47
  %110 = zext nneg i8 %48 to i16
  %111 = tail call i16 @llvm.fshl.i16(i16 %7, i16 %7, i16 1)
  %112 = xor i16 %111, %110
  br label %142

113:                                              ; preds = %113, %6
  %114 = phi i8 [ 0, %6 ], [ %136, %113 ]
  %115 = phi i8 [ 0, %6 ], [ %134, %113 ]
  %116 = phi i16 [ %9, %6 ], [ %131, %113 ]
  %117 = shl i16 %116, 7
  %118 = xor i16 %117, %116
  %119 = lshr i16 %118, 9
  %120 = xor i16 %119, %118
  %121 = shl i16 %120, 8
  %122 = xor i16 %121, %120
  %123 = urem i16 %122, 100
  %124 = zext nneg i8 %114 to i16
  %125 = getelementptr i8, ptr %1, i16 %124
  store i16 %123, ptr %125, align 1, !tbaa !6
  %126 = shl i16 %122, 7
  %127 = xor i16 %126, %122
  %128 = lshr i16 %127, 9
  %129 = xor i16 %128, %127
  %130 = shl i16 %129, 8
  %131 = xor i16 %130, %129
  %132 = urem i16 %131, 100
  %133 = getelementptr i8, ptr %5, i16 %124
  store i16 %132, ptr %133, align 1, !tbaa !8
  %134 = add nuw nsw i8 %115, 1
  %135 = icmp eq i8 %134, 14
  %136 = add nuw nsw i8 %114, 4
  br i1 %135, label %10, label %113, !llvm.loop !14

137:                                              ; preds = %170
  %138 = tail call i16 @llvm.fshl.i16(i16 %172, i16 %172, i16 1)
  %139 = xor i16 %195, %138
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #3
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #3
  %140 = add nuw nsw i16 %8, 1
  %141 = icmp eq i16 %140, 12
  br i1 %141, label %199, label %6, !llvm.loop !15

142:                                              ; preds = %170, %109
  %143 = phi i16 [ %112, %109 ], [ %172, %170 ]
  %144 = phi i8 [ 0, %109 ], [ %173, %170 ]
  %145 = phi i16 [ 0, %109 ], [ %195, %170 ]
  %146 = zext nneg i8 %144 to i16
  %147 = getelementptr i8, ptr %2, i16 %146
  %148 = load i8, ptr %147, align 1, !tbaa !11
  %149 = zext i8 %148 to i16
  %150 = getelementptr inbounds nuw [4 x i8], ptr %1, i16 %149
  %151 = load i16, ptr %150, align 1, !tbaa !2
  %152 = getelementptr inbounds nuw i8, ptr %150, i16 2
  %153 = load i16, ptr %152, align 1, !tbaa !2
  %154 = add nuw nsw i16 %146, 1
  %155 = icmp eq i16 %154, %110
  %156 = select i1 %155, i16 0, i16 %154
  %157 = getelementptr inbounds nuw i8, ptr %2, i16 %156
  %158 = load i8, ptr %157, align 1, !tbaa !11
  %159 = zext i8 %158 to i16
  %160 = getelementptr inbounds nuw [4 x i8], ptr %1, i16 %159
  %161 = load i16, ptr %160, align 1, !tbaa !2
  %162 = getelementptr inbounds nuw i8, ptr %160, i16 2
  %163 = load i16, ptr %162, align 1, !tbaa !2
  %164 = sext i16 %161 to i32
  %165 = sext i16 %151 to i32
  %166 = sub nsw i32 %164, %165
  %167 = sext i16 %163 to i32
  %168 = sext i16 %153 to i32
  %169 = sub nsw i32 %167, %168
  br label %175

170:                                              ; preds = %194
  %171 = tail call i16 @llvm.fshl.i16(i16 %143, i16 %143, i16 1)
  %172 = xor i16 %171, %149
  %173 = add nuw nsw i8 %144, 1
  %174 = icmp eq i8 %173, %36
  br i1 %174, label %137, label %142, !llvm.loop !16

175:                                              ; preds = %194, %142
  %176 = phi i8 [ 0, %142 ], [ %198, %194 ]
  %177 = phi i8 [ 0, %142 ], [ %196, %194 ]
  %178 = phi i16 [ %145, %142 ], [ %195, %194 ]
  %179 = zext nneg i8 %176 to i16
  %180 = getelementptr i8, ptr %1, i16 %179
  %181 = load i16, ptr %180, align 1
  %182 = getelementptr i8, ptr %5, i16 %179
  %183 = load i16, ptr %182, align 1
  %184 = sext i16 %181 to i32
  %185 = sub nsw i32 %165, %184
  %186 = sext i16 %183 to i32
  %187 = sub nsw i32 %186, %168
  %188 = mul nsw i32 %187, %166
  %189 = mul i32 %185, %169
  %190 = add i32 %188, %189
  %191 = icmp slt i32 %190, 0
  br i1 %191, label %192, label %194

192:                                              ; preds = %175
  %193 = add i16 %178, 1
  br label %194

194:                                              ; preds = %192, %175
  %195 = phi i16 [ %193, %192 ], [ %178, %175 ]
  %196 = add nuw nsw i8 %177, 1
  %197 = icmp eq i8 %196, 14
  %198 = add nuw nsw i8 %176, 4
  br i1 %197, label %170, label %175, !llvm.loop !17

199:                                              ; preds = %137
  store volatile i16 %139, ptr @corpus_result, align 1, !tbaa !2
  br label %200

200:                                              ; preds = %200, %199
  tail call void asm sideeffect "wai", ""() #3, !srcloc !18
  br label %200
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #2

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !3, i64 0}
!7 = !{!"", !3, i64 0, !3, i64 2}
!8 = !{!7, !3, i64 2}
!9 = distinct !{!9, !10}
!10 = !{!"llvm.loop.mustprogress"}
!11 = !{!4, !4, i64 0}
!12 = distinct !{!12, !10}
!13 = distinct !{!13, !10}
!14 = distinct !{!14, !10}
!15 = distinct !{!15, !10}
!16 = distinct !{!16, !10}
!17 = distinct !{!17, !10}
!18 = !{i64 319}
