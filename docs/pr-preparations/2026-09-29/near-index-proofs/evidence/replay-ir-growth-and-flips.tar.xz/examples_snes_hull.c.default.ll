; ModuleID = '/work/examples/snes/hull.c'
source_filename = "/work/examples/snes/hull.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.App = type { %struct.Display, %struct.BitmapCanvas, %struct.TextLayer, [14 x %struct.HlPt], [14 x i8], [14 x i8], [14 x i8], i16 }
%struct.Display = type { %struct.UploadQueue, %struct.VramAlloc, %struct.Scene, i8, i8, i8, i8, i8 }
%struct.UploadQueue = type { [16 x %struct.UpqJob], i8, i8 }
%struct.UpqJob = type { i16, i16, i16, i8, i8, i8, i8, i8 }
%struct.VramAlloc = type { i16, i16 }
%struct.Scene = type { [4 x ptr], i8 }
%struct.BitmapCanvas = type { %struct.Drawable, [4096 x i8], i16, i16, i16, i16, i8, i8 }
%struct.Drawable = type { ptr, i8 }
%struct.TextLayer = type { %struct.Drawable, i16, [2 x i8], [64 x i16], i8 }
%struct.HlPt = type { i16, i16 }
%struct.TitleLayer = type { %struct.Drawable, ptr, ptr, ptr, ptr, i8, i8, i16, i16, i16, i16, i16, i16, i8, i16, i8, i8, i8, i8, i8, i8, i16, i16, %struct.HScrollDB, %struct.HScrollDB }
%struct.HScrollDB = type { [2 x %struct.HScrollN], i8 }
%struct.HScrollN = type { [25 x i8] }
%struct.DrawableVT = type { ptr, ptr }
%struct.HScrollW = type { ptr, i8 }

@main.a = internal global %struct.App zeroinitializer, align 1
@main.title = internal global %struct.TitleLayer zeroinitializer, align 1
@.str = private unnamed_addr constant [12 x i8] c"CONVEX HULL\00", align 1
@.str.1 = private unnamed_addr constant [17 x i8] c"GIFT-WRAP  CROSS\00", align 1
@corpus_result = dso_local global i16 0, align 1
@bg3_pal = internal constant [4 x i16] [i16 9314, i16 31558, i16 6879, i16 32767], align 1
@.str.2 = private unnamed_addr constant [37 x i8] c"GIFT-WRAP  CROSS-PRODUCT ORIENTATION\00", align 1
@CANVAS_VT = internal constant %struct.DrawableVT { ptr @_canvas_reserve, ptr @_canvas_emit }, align 1
@TEXT_VT = internal constant %struct.DrawableVT { ptr @_text_reserve, ptr @_text_emit }, align 1
@FONT8 = internal unnamed_addr constant [512 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 32, i16 0, i16 80, i16 80, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 80, i16 80, i16 248, i16 80, i16 248, i16 80, i16 80, i16 0, i16 32, i16 120, i16 160, i16 112, i16 40, i16 240, i16 32, i16 0, i16 196, i16 200, i16 16, i16 32, i16 64, i16 152, i16 12, i16 0, i16 96, i16 144, i16 160, i16 64, i16 168, i16 144, i16 104, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 16, i16 32, i16 64, i16 64, i16 64, i16 32, i16 16, i16 0, i16 64, i16 32, i16 16, i16 16, i16 16, i16 32, i16 64, i16 0, i16 0, i16 32, i16 168, i16 112, i16 168, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 248, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 64, i16 0, i16 0, i16 0, i16 248, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 0, i16 8, i16 8, i16 16, i16 32, i16 64, i16 128, i16 128, i16 0, i16 112, i16 136, i16 152, i16 168, i16 200, i16 136, i16 112, i16 0, i16 32, i16 96, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 64, i16 248, i16 0, i16 112, i16 136, i16 8, i16 48, i16 8, i16 136, i16 112, i16 0, i16 16, i16 48, i16 80, i16 144, i16 248, i16 16, i16 16, i16 0, i16 248, i16 128, i16 240, i16 8, i16 8, i16 136, i16 112, i16 0, i16 112, i16 136, i16 128, i16 240, i16 136, i16 136, i16 112, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 64, i16 64, i16 0, i16 112, i16 136, i16 136, i16 112, i16 136, i16 136, i16 112, i16 0, i16 112, i16 136, i16 136, i16 120, i16 8, i16 136, i16 112, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 64, i16 0, i16 16, i16 32, i16 64, i16 128, i16 64, i16 32, i16 16, i16 0, i16 0, i16 0, i16 248, i16 0, i16 248, i16 0, i16 0, i16 0, i16 128, i16 64, i16 32, i16 16, i16 32, i16 64, i16 128, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 0, i16 32, i16 0, i16 112, i16 136, i16 184, i16 168, i16 184, i16 128, i16 112, i16 0, i16 112, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 240, i16 136, i16 136, i16 240, i16 136, i16 136, i16 240, i16 0, i16 112, i16 136, i16 128, i16 128, i16 128, i16 136, i16 112, i16 0, i16 224, i16 144, i16 136, i16 136, i16 136, i16 144, i16 224, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 248, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 128, i16 176, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 112, i16 32, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 56, i16 16, i16 16, i16 16, i16 144, i16 144, i16 96, i16 0, i16 136, i16 144, i16 160, i16 192, i16 160, i16 144, i16 136, i16 0, i16 128, i16 128, i16 128, i16 128, i16 128, i16 128, i16 248, i16 0, i16 136, i16 216, i16 168, i16 136, i16 136, i16 136, i16 136, i16 0, i16 136, i16 200, i16 168, i16 152, i16 136, i16 136, i16 136, i16 0, i16 112, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 240, i16 136, i16 136, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 136, i16 136, i16 168, i16 144, i16 104, i16 0, i16 240, i16 136, i16 136, i16 240, i16 160, i16 144, i16 136, i16 0, i16 112, i16 136, i16 128, i16 112, i16 8, i16 136, i16 112, i16 0, i16 248, i16 32, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 80, i16 32, i16 0, i16 136, i16 136, i16 136, i16 168, i16 168, i16 216, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 80, i16 136, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 32, i16 32, i16 32, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 128, i16 248, i16 0, i16 48, i16 32, i16 32, i16 32, i16 32, i16 32, i16 48, i16 0, i16 128, i16 128, i16 64, i16 32, i16 16, i16 8, i16 8, i16 0, i16 48, i16 16, i16 16, i16 16, i16 16, i16 16, i16 48, i16 0, i16 32, i16 80, i16 136, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248], align 1
@TITLE_VT = internal constant %struct.DrawableVT { ptr @_title_reserve, ptr @_title_emit }, align 1
@FONT16 = internal unnamed_addr constant [2048 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 192, i16 192, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 768, i16 768, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 -4096, i16 -4096, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3840, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 3312, i16 15360, i16 15360, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 28, i16 28, i16 796, i16 127, i16 127, i16 796, i16 796, i16 127, i16 112, i16 112, i16 3184, i16 252, i16 252, i16 -28816, i16 -28816, i16 252, i16 127, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 0, i16 0, i16 252, i16 -28816, i16 -28816, i16 3184, i16 7168, i16 7168, i16 0, i16 0, i16 3, i16 63, i16 123, i16 1147, i16 63, i16 4111, i16 3075, i16 123, i16 192, i16 248, i16 8414, i16 16064, i16 2040, i16 248, i16 8414, i16 8414, i16 63, i16 7171, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 2040, i16 14272, i16 -512, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3585, i16 3, i16 7, i16 28, i16 56, i16 1904, i16 3808, i16 7392, i16 14528, i16 14464, i16 28672, i16 14, i16 284, i16 824, i16 1792, i16 3584, i16 0, i16 0, i16 0, i16 -8162, i16 -16354, i16 -32482, i16 286, i16 1792, i16 1792, i16 0, i16 0, i16 15, i16 31, i16 828, i16 828, i16 573, i16 31, i16 31, i16 63, i16 192, i16 224, i16 240, i16 2288, i16 7392, i16 15488, i16 30720, i16 -32648, i16 382, i16 3060, i16 3825, i16 1275, i16 127, i16 63, i16 7936, i16 3840, i16 248, i16 3824, i16 7904, i16 7392, i16 4332, i16 12492, i16 -1280, i16 -3328, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 7, i16 15, i16 15, i16 15, i16 15, i16 15, i16 240, i16 192, i16 15488, i16 -4096, i16 -8192, i16 -16384, i16 -16384, i16 -16384, i16 15, i16 7, i16 3, i16 256, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 16512, i16 192, i16 240, i16 -4096, i16 15360, i16 0, i16 0, i16 15, i16 3, i16 513, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 224, i16 240, i16 2288, i16 3312, i16 3312, i16 3312, i16 0, i16 1, i16 3, i16 15, i16 0, i16 768, i16 0, i16 0, i16 3312, i16 7392, i16 15552, i16 30720, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 51, i16 31, i16 15, i16 1027, i16 0, i16 0, i16 192, i16 192, i16 12492, i16 252, i16 1016, i16 16320, i16 15, i16 31, i16 51, i16 1027, i16 3072, i16 0, i16 0, i16 0, i16 1784, i16 252, i16 13004, i16 16320, i16 -3328, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 3, i16 63, i16 63, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 248, i16 248, i16 63, i16 3075, i16 3075, i16 3, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 16064, i16 16064, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 286, i16 828, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 28800, i16 -4096, i16 -8192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 -512, i16 -512, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7360, i16 14464, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7168, i16 14336, i16 28672, i16 -8192, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 828, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 15, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 1, i16 3, i16 15, i16 15, i16 513, i16 513, i16 1, i16 1, i16 240, i16 240, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 1, i16 1, i16 1, i16 1, i16 1, i16 1, i16 0, i16 0, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 31744, i16 31744, i16 15, i16 31, i16 318, i16 828, i16 3840, i16 3840, i16 3, i16 15, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 63, i16 510, i16 4080, i16 31, i16 318, i16 318, i16 318, i16 63, i16 63, i16 3840, i16 3840, i16 32640, i16 -1024, i16 -8192, i16 -32768, i16 255, i16 255, i16 -256, i16 -256, i16 15, i16 63, i16 824, i16 3840, i16 2055, i16 7, i16 256, i16 256, i16 252, i16 254, i16 -8161, i16 -4081, i16 510, i16 1020, i16 -7906, i16 -4081, i16 0, i16 0, i16 56, i16 60, i16 63, i16 31, i16 3840, i16 1792, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 15, i16 286, i16 62, i16 126, i16 510, i16 510, i16 8670, i16 24990, i16 -7906, i16 -7906, i16 828, i16 828, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 -16098, i16 -32482, i16 255, i16 255, i16 -7906, i16 -7906, i16 1792, i16 1792, i16 31, i16 63, i16 828, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 254, i16 254, i16 -256, i16 -256, i16 252, i16 254, i16 -8161, i16 -4081, i16 0, i16 0, i16 60, i16 62, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 63, i16 63, i16 318, i16 828, i16 254, i16 255, i16 -2041, i16 -256, i16 508, i16 254, i16 -4081, i16 -2041, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 -32761, i16 7, i16 7, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 31, i16 318, i16 892, i16 0, i16 1, i16 3, i16 7, i16 7, i16 7, i16 256, i16 256, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 28800, i16 -8192, i16 -8192, i16 15, i16 31, i16 828, i16 828, i16 828, i16 31, i16 15, i16 796, i16 252, i16 254, i16 -4081, i16 -4081, i16 15, i16 510, i16 1020, i16 -3826, i16 828, i16 828, i16 828, i16 828, i16 31, i16 15, i16 1792, i16 768, i16 -4081, i16 15, i16 15, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 318, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 31, i16 31, i16 15, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 270, i16 796, i16 824, i16 1792, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 15, i16 60, i16 828, i16 0, i16 0, i16 60, i16 240, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 15360, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 60, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 60, i16 0, i16 3, i16 15, i16 60, i16 768, i16 3840, i16 0, i16 0, i16 4080, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 31, i16 63, i16 828, i16 3840, i16 3840, i16 7, i16 7, i16 7, i16 240, i16 248, i16 -32644, i16 -32132, i16 2040, i16 4080, i16 16064, i16 31872, i16 256, i16 256, i16 7, i16 7, i16 7, i16 256, i16 256, i16 0, i16 -4096, i16 -8192, i16 128, i16 128, i16 24704, i16 -8192, i16 -8192, i16 0, i16 31, i16 63, i16 828, i16 573, i16 573, i16 573, i16 573, i16 573, i16 248, i16 252, i16 -15812, i16 4590, i16 494, i16 4590, i16 1020, i16 1016, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 0, i16 0, i16 0, i16 32512, i16 764, i16 248, i16 -256, i16 -512, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 892, i16 1020, i16 1020, i16 255, i16 255, i16 224, i16 240, i16 -32648, i16 -16324, i16 -32196, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -28928, i16 1792, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 0, i16 0, i16 28, i16 60, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -8164, i16 -3572, i16 -30976, i16 768, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 8988, i16 8988, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 60, i16 60, i16 828, i16 828, i16 828, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 255, i16 255, i16 16128, i16 16128, i16 12480, i16 12480, i16 12480, i16 12480, i16 252, i16 252, i16 -256, i16 -256, i16 63, i16 63, i16 3075, i16 3075, i16 3, i16 3, i16 51, i16 51, i16 252, i16 252, i16 4080, i16 4080, i16 3312, i16 3312, i16 3312, i16 3312, i16 3123, i16 3123, i16 63, i16 63, i16 31, i16 15, i16 1792, i16 768, i16 3312, i16 3312, i16 3312, i16 3312, i16 7392, i16 15552, i16 -2048, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 765, i16 255, i16 255, i16 255, i16 28, i16 60, i16 1912, i16 4080, i16 7904, i16 15552, i16 30848, i16 12480, i16 255, i16 765, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 224, i16 240, i16 248, i16 124, i16 572, i16 828, i16 3840, i16 3840, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 0, i16 0, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 248, i16 252, i16 254, i16 2295, i16 3315, i16 3315, i16 3315, i16 3315, i16 60, i16 124, i16 1020, i16 988, i16 9116, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 15360, i16 15360, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 -6400, i16 -6400, i16 240, i16 248, i16 252, i16 254, i16 255, i16 255, i16 2295, i16 3315, i16 60, i16 60, i16 828, i16 828, i16 828, i16 956, i16 1020, i16 1020, i16 3313, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 15360, i16 15360, i16 1020, i16 1020, i16 892, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -31972, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -512, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 224, i16 240, i16 -32648, i16 -15304, i16 -31176, i16 1592, i16 1592, i16 1592, i16 765, i16 765, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 1784, i16 1784, i16 17976, i16 1656, i16 764, i16 764, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 63, i16 127, i16 2040, i16 4080, i16 1784, i16 255, i16 127, i16 63, i16 248, i16 252, i16 -15812, i16 -256, i16 3840, i16 240, i16 248, i16 252, i16 7936, i16 3840, i16 224, i16 255, i16 255, i16 127, i16 16128, i16 7936, i16 -32132, i16 -15556, i16 892, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 -4096, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 28, i16 28, i16 796, i16 796, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 510, i16 255, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 828, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 248, i16 248, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 124, i16 124, i16 1912, i16 1912, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 572, i16 63, i16 31, i16 15, i16 7, i16 768, i16 256, i16 1656, i16 3824, i16 3824, i16 7392, i16 15552, i16 30848, i16 -4096, i16 -8192, i16 243, i16 243, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 156, i16 156, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 2295, i16 255, i16 510, i16 892, i16 16128, i16 7936, i16 25500, i16 25500, i16 9180, i16 1020, i16 1020, i16 -30856, i16 -16640, i16 7680, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 15, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 14528, i16 31, i16 63, i16 892, i16 2040, i16 4080, i16 3824, i16 15360, i16 15360, i16 4320, i16 240, i16 248, i16 -32644, i16 572, i16 828, i16 3840, i16 3840, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 7, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 7, i16 7, i16 7, i16 7, i16 7, i16 7, i16 256, i16 256, i16 28800, i16 24704, i16 24704, i16 24704, i16 24704, i16 24704, i16 -8192, i16 -8192, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 1, i16 3, i16 7, i16 252, i16 252, i16 1020, i16 -31876, i16 2040, i16 4080, i16 7904, i16 15552, i16 15, i16 31, i16 318, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 30848, i16 -4096, i16 -8192, i16 252, i16 252, i16 1020, i16 -256, i16 -256, i16 31, i16 31, i16 286, i16 286, i16 286, i16 286, i16 286, i16 286, i16 224, i16 224, i16 -2048, i16 -2048, i16 -32768, i16 -32768, i16 -32768, i16 -32768, i16 286, i16 286, i16 286, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 -32768, i16 -32768, i16 -32768, i16 224, i16 224, i16 -2048, i16 -2048, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 3, i16 1, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 128, i16 192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 768, i16 256, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 0, i16 0, i16 0, i16 224, i16 224, i16 2288, i16 2288, i16 3312, i16 3312, i16 3312, i16 3312, i16 0, i16 0, i16 0, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 3312, i16 3312, i16 3312, i16 7392, i16 7392, i16 -2048, i16 -2048, i16 0, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1840, i16 3584, i16 3072, i16 192, i16 224, i16 -32656, i16 -16328, i16 -32740, i16 524, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 127, i16 127, i16 7936, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 -512], align 1
@title_end._title_bg_black = internal constant i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [14 x %struct.HlPt], align 1
  %2 = alloca [14 x i8], align 1
  store volatile i8 -113, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  br label %3

3:                                                ; preds = %7, %0
  %4 = phi i16 [ 8449, %0 ], [ %8, %7 ]
  switch i16 %4, label %5 [
    i16 8452, label %7
    i16 8470, label %7
    i16 8471, label %7
    i16 8472, label %7
    i16 8473, label %7
    i16 8481, label %7
    i16 8482, label %7
  ]

5:                                                ; preds = %3
  %6 = inttoptr i16 %4 to ptr
  store volatile i8 0, ptr %6, align 1, !tbaa !6
  br label %7

7:                                                ; preds = %5, %3, %3, %3, %3, %3, %3, %3
  %8 = add nuw nsw i16 %4, 1
  %9 = icmp eq i16 %8, 8500
  br i1 %9, label %10, label %3, !llvm.loop !7

10:                                               ; preds = %7
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) getelementptr inbounds nuw (i8, ptr @main.a, i16 176), i8 0, i64 6, i1 false)
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  store volatile i8 1, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 -127, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !6
  store ptr @CANVAS_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), align 1, !tbaa !15
  store i8 4, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !19
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4299), align 1, !tbaa !20
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4301), align 1, !tbaa !21
  store i8 8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4303), align 1, !tbaa !22
  store i8 6, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4304), align 1, !tbaa !23
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(4096) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i16 4096, i1 false), !tbaa !6
  store i16 -1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  store ptr @TEXT_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !26
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !28
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4308), align 1, !tbaa !29
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4310), align 1, !tbaa !6
  store i8 25, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4311), align 1, !tbaa !6
  br label %11

11:                                               ; preds = %11, %10
  %12 = phi i8 [ 0, %10 ], [ %18, %11 ]
  %13 = phi i16 [ 0, %10 ], [ %16, %11 ]
  %14 = zext i8 %12 to i16
  %15 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4312), i16 %14
  store i16 256, ptr %15, align 1, !tbaa !2
  %16 = add nuw nsw i16 %13, 1
  %17 = icmp eq i16 %16, 64
  %18 = add nuw i8 %12, 2
  br i1 %17, label %19, label %11, !llvm.loop !30

19:                                               ; preds = %11
  store i8 3, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %20 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %21 = icmp eq i8 %20, 0
  br i1 %21, label %23, label %22

22:                                               ; preds = %19
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %23

23:                                               ; preds = %22, %19
  %24 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %25 = icmp ult i8 %24, 4
  br i1 %25, label %26, label %30

26:                                               ; preds = %23
  %27 = zext nneg i8 %24 to i16
  %28 = add nuw nsw i8 %24, 1
  store i8 %28, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %29 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %27
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr %29, align 1, !tbaa !35
  br label %30

30:                                               ; preds = %26, %23
  tail call void @_canvas_reserve(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr nonnull poison) #12, !inline_history !37
  %31 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %32 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !39
  %33 = or i8 %32, %31
  store i8 %33, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %33, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %34 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %35 = icmp eq i8 %34, 0
  br i1 %35, label %37, label %36

36:                                               ; preds = %30
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %37

37:                                               ; preds = %36, %30
  %38 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %39 = icmp ult i8 %38, 4
  br i1 %39, label %40, label %44

40:                                               ; preds = %37
  %41 = zext nneg i8 %38 to i16
  %42 = add nuw nsw i8 %38, 1
  store i8 %42, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %43 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %41
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr %43, align 1, !tbaa !35
  br label %44

44:                                               ; preds = %40, %37
  %45 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !40
  %46 = load ptr, ptr %45, align 1, !tbaa !41
  tail call void %46(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 178)) #12, !inline_history !43
  %47 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %48 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !39
  %49 = or i8 %48, %47
  store i8 %49, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %49, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %50 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %51 = icmp ugt i8 %50, 15
  br i1 %51, label %63, label %52

52:                                               ; preds = %44
  %53 = zext nneg i8 %50 to i16
  %54 = add nuw nsw i8 %50, 1
  store i8 %54, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %55 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %53
  %56 = getelementptr inbounds nuw i8, ptr %55, i16 10
  store i8 1, ptr %56, align 1, !tbaa !45
  store i16 0, ptr %55, align 1, !tbaa !47
  %57 = getelementptr inbounds nuw i8, ptr %55, i16 9
  store i8 0, ptr %57, align 1, !tbaa !48
  %58 = getelementptr inbounds nuw i8, ptr %55, i16 7
  store i8 34, ptr %58, align 1, !tbaa !49
  %59 = getelementptr inbounds nuw i8, ptr %55, i16 8
  store i8 0, ptr %59, align 1, !tbaa !50
  %60 = getelementptr inbounds nuw i8, ptr %55, i16 2
  store i16 ptrtoint (ptr @bg3_pal to i16), ptr %60, align 1, !tbaa !51
  %61 = getelementptr inbounds nuw i8, ptr %55, i16 6
  store i8 0, ptr %61, align 1, !tbaa !52
  %62 = getelementptr inbounds nuw i8, ptr %55, i16 4
  store i16 8, ptr %62, align 1, !tbaa !53
  br label %63

63:                                               ; preds = %52, %44
  store i16 4951, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4539), align 1, !tbaa !54
  br label %107

64:                                               ; preds = %157, %74
  %65 = phi i8 [ %82, %74 ], [ 0, %157 ]
  %66 = phi i8 [ %81, %74 ], [ 0, %157 ]
  %67 = phi i8 [ %80, %74 ], [ 67, %157 ]
  %68 = zext i8 %67 to i16
  %69 = icmp ugt i8 %67, 31
  br i1 %69, label %70, label %74

70:                                               ; preds = %64
  %71 = icmp ult i8 %67, 96
  br i1 %71, label %72, label %74

72:                                               ; preds = %70
  %73 = add nuw nsw i16 %68, 224
  br label %74

74:                                               ; preds = %72, %70, %64
  %75 = phi i16 [ %73, %72 ], [ 256, %70 ], [ 256, %64 ]
  %76 = zext nneg i8 %66 to i16
  %77 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4314), i16 %76
  store i16 %75, ptr %77, align 1, !tbaa !2
  %78 = zext nneg i8 %65 to i16
  %79 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @.str, i16 1), i16 %78
  %80 = load i8, ptr %79, align 1, !tbaa !6
  %81 = add nuw nsw i8 %66, 2
  %82 = add nuw nsw i8 %65, 1
  %83 = icmp eq i8 %82, 11
  br i1 %83, label %84, label %64, !llvm.loop !56

84:                                               ; preds = %74
  %85 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  br label %86

86:                                               ; preds = %84, %96
  %87 = phi i16 [ 71, %84 ], [ %105, %96 ]
  %88 = phi i8 [ 71, %84 ], [ %103, %96 ]
  %89 = phi i8 [ 0, %84 ], [ %104, %96 ]
  %90 = phi i8 [ 0, %84 ], [ %102, %96 ]
  %91 = icmp ugt i8 %88, 31
  br i1 %91, label %92, label %96

92:                                               ; preds = %86
  %93 = icmp ult i8 %88, 96
  br i1 %93, label %94, label %96

94:                                               ; preds = %92
  %95 = add nuw nsw i16 %87, 224
  br label %96

96:                                               ; preds = %94, %92, %86
  %97 = phi i16 [ %95, %94 ], [ 256, %92 ], [ 256, %86 ]
  %98 = zext nneg i8 %89 to i16
  %99 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4376), i16 %98
  store i16 %97, ptr %99, align 1, !tbaa !2
  %100 = zext nneg i8 %90 to i16
  %101 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @.str.2, i16 1), i16 %100
  %102 = add nuw nsw i8 %90, 1
  %103 = load i8, ptr %101, align 1, !tbaa !6
  %104 = add nuw nsw i8 %89, 2
  %105 = zext i8 %103 to i16
  %106 = icmp eq i8 %102, 32
  br i1 %106, label %161, label %86

107:                                              ; preds = %157, %63
  %108 = phi i8 [ 0, %63 ], [ %160, %157 ]
  %109 = phi i8 [ 0, %63 ], [ %158, %157 ]
  %110 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4539), align 1, !tbaa !54
  %111 = shl i16 %110, 7
  %112 = xor i16 %111, %110
  %113 = lshr i16 %112, 9
  %114 = xor i16 %113, %112
  %115 = shl i16 %114, 8
  %116 = xor i16 %115, %114
  %117 = urem i16 %116, 110
  %118 = add nuw nsw i16 %117, 8
  %119 = zext nneg i8 %108 to i16
  %120 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %119
  store i16 %118, ptr %120, align 1, !tbaa !57
  %121 = shl i16 %116, 7
  %122 = xor i16 %121, %116
  %123 = lshr i16 %122, 9
  %124 = xor i16 %123, %122
  %125 = shl i16 %124, 8
  %126 = xor i16 %125, %124
  %127 = urem i16 %126, 110
  %128 = add nuw nsw i16 %127, 8
  %129 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), i16 %119
  store i16 %128, ptr %129, align 1, !tbaa !58
  %130 = shl i16 %126, 7
  %131 = xor i16 %130, %126
  %132 = lshr i16 %131, 9
  %133 = xor i16 %132, %131
  %134 = shl i16 %133, 8
  %135 = xor i16 %134, %133
  store i16 %135, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4539), align 1, !tbaa !54
  %136 = trunc i16 %133 to i8
  %137 = and i8 %136, 3
  %138 = add nsw i8 %137, -1
  %139 = zext nneg i8 %109 to i16
  %140 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4497), i16 %139
  store i8 %138, ptr %140, align 1, !tbaa !6
  %141 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4539), align 1, !tbaa !54
  %142 = shl i16 %141, 7
  %143 = xor i16 %142, %141
  %144 = lshr i16 %143, 9
  %145 = xor i16 %144, %143
  %146 = shl i16 %145, 8
  %147 = xor i16 %146, %145
  store i16 %147, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4539), align 1, !tbaa !54
  %148 = trunc i16 %145 to i8
  %149 = and i8 %148, 3
  %150 = add nsw i8 %149, -1
  %151 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4511), i16 %139
  store i8 %150, ptr %151, align 1, !tbaa !6
  %152 = load i8, ptr %140, align 1, !tbaa !6
  %153 = icmp eq i8 %152, 0
  br i1 %153, label %154, label %157

154:                                              ; preds = %107
  %155 = icmp eq i8 %150, 0
  br i1 %155, label %156, label %157

156:                                              ; preds = %154
  store i8 1, ptr %140, align 1, !tbaa !6
  br label %157

157:                                              ; preds = %156, %154, %107
  %158 = add nuw nsw i8 %109, 1
  %159 = icmp eq i8 %158, 14
  %160 = add nuw nsw i8 %108, 4
  br i1 %159, label %64, label %107, !llvm.loop !59

161:                                              ; preds = %96
  %162 = or i8 %85, 3
  store i8 %162, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  store ptr @TITLE_VT, ptr @main.title, align 1, !tbaa !60
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !64
  store ptr @.str, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 3), align 1, !tbaa !65
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 5), align 1, !tbaa !66
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 7), align 1, !tbaa !67
  store i8 16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 11), align 1, !tbaa !68
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 9), align 1, !tbaa !69
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 12), align 1, !tbaa !70
  store i16 96, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 13), align 1, !tbaa !71
  store i16 112, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 15), align 1, !tbaa !72
  store i16 16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 17), align 1, !tbaa !73
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 28), align 1, !tbaa !74
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !75
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !76
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !77
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !78
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !79
  store i16 32767, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 34), align 1, !tbaa !80
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 36), align 1, !tbaa !81
  %163 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %164 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %165 = icmp eq i8 %164, 0
  br i1 %165, label %167, label %166

166:                                              ; preds = %161
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %167

167:                                              ; preds = %166, %161
  %168 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %169 = icmp ult i8 %168, 4
  br i1 %169, label %170, label %174

170:                                              ; preds = %167
  %171 = zext nneg i8 %168 to i16
  %172 = add nuw nsw i8 %168, 1
  store i8 %172, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %173 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %171
  store ptr @main.title, ptr %173, align 1, !tbaa !35
  br label %174

174:                                              ; preds = %170, %167
  tail call void @_title_reserve(ptr noundef nonnull @main.title, ptr nonnull poison) #12, !inline_history !37
  %175 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %176 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %177 = or i8 %176, %175
  store volatile i8 %177, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store i8 %163, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !82
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 2, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 24, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  br label %178

178:                                              ; preds = %206, %174
  %179 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %180 = icmp eq i8 %179, 0
  br i1 %180, label %192, label %181

181:                                              ; preds = %178, %181
  %182 = phi i8 [ %189, %181 ], [ 0, %178 ]
  %183 = zext i8 %182 to i16
  %184 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %183
  %185 = load ptr, ptr %184, align 1, !tbaa !35
  %186 = load ptr, ptr %185, align 1, !tbaa !40
  %187 = getelementptr inbounds nuw i8, ptr %186, i16 2
  %188 = load ptr, ptr %187, align 1, !tbaa !83
  tail call void %188(ptr noundef nonnull %185, ptr noundef nonnull @main.a) #12, !inline_history !84
  %189 = add nuw i8 %182, 1
  %190 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %191 = icmp ult i8 %189, %190
  br i1 %191, label %181, label %192, !llvm.loop !85

192:                                              ; preds = %181, %178
  %193 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %194

194:                                              ; preds = %194, %192
  %195 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %196 = icmp sgt i8 %195, -1
  br i1 %196, label %194, label %197, !llvm.loop !86

197:                                              ; preds = %194
  tail call fastcc void @upq_flush() #13
  %198 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %199 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %200 = icmp ult i8 %198, %199
  br i1 %200, label %203, label %201

201:                                              ; preds = %197
  %202 = icmp ugt i8 %198, %199
  br i1 %202, label %203, label %206

203:                                              ; preds = %201, %197
  %204 = phi i8 [ 1, %197 ], [ -1, %201 ]
  %205 = add i8 %204, %198
  store i8 %205, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %206

206:                                              ; preds = %203, %201
  %207 = phi i8 [ %198, %201 ], [ %205, %203 ]
  %208 = and i8 %207, 15
  store volatile i8 %208, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %209 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %210 = icmp eq i8 %209, 15
  br i1 %210, label %211, label %178, !llvm.loop !87

211:                                              ; preds = %206
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !78
  %212 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !79
  %213 = icmp eq i8 %212, -1
  br i1 %213, label %251, label %214

214:                                              ; preds = %211, %243
  %215 = phi i8 [ %246, %243 ], [ 0, %211 ]
  %216 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %217 = icmp eq i8 %216, 0
  br i1 %217, label %229, label %218

218:                                              ; preds = %214, %218
  %219 = phi i8 [ %226, %218 ], [ 0, %214 ]
  %220 = zext i8 %219 to i16
  %221 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %220
  %222 = load ptr, ptr %221, align 1, !tbaa !35
  %223 = load ptr, ptr %222, align 1, !tbaa !40
  %224 = getelementptr inbounds nuw i8, ptr %223, i16 2
  %225 = load ptr, ptr %224, align 1, !tbaa !83
  tail call void %225(ptr noundef nonnull %222, ptr noundef nonnull @main.a) #12, !inline_history !88
  %226 = add nuw i8 %219, 1
  %227 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %228 = icmp ult i8 %226, %227
  br i1 %228, label %218, label %229, !llvm.loop !85

229:                                              ; preds = %218, %214
  %230 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %231

231:                                              ; preds = %231, %229
  %232 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %233 = icmp sgt i8 %232, -1
  br i1 %233, label %231, label %234, !llvm.loop !86

234:                                              ; preds = %231
  tail call fastcc void @upq_flush() #13
  %235 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %236 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %237 = icmp ult i8 %235, %236
  br i1 %237, label %240, label %238

238:                                              ; preds = %234
  %239 = icmp ugt i8 %235, %236
  br i1 %239, label %240, label %243

240:                                              ; preds = %238, %234
  %241 = phi i8 [ 1, %234 ], [ -1, %238 ]
  %242 = add i8 %241, %235
  store i8 %242, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %243

243:                                              ; preds = %240, %238
  %244 = phi i8 [ %235, %238 ], [ %242, %240 ]
  %245 = and i8 %244, 15
  store volatile i8 %245, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %246 = add nuw i8 %215, 1
  %247 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !79
  %248 = icmp ne i8 %247, -1
  %249 = icmp ult i8 %215, -57
  %250 = select i1 %248, i1 %249, i1 false
  br i1 %250, label %214, label %251, !llvm.loop !89

251:                                              ; preds = %243, %211
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !78
  %252 = getelementptr inbounds nuw i8, ptr %1, i16 2
  br label %253

253:                                              ; preds = %286, %251
  %254 = phi i16 [ 0, %251 ], [ %288, %286 ]
  %255 = phi i16 [ 0, %251 ], [ %289, %286 ]
  %256 = phi i16 [ 20973, %251 ], [ %280, %286 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #14
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #14
  br label %262

257:                                              ; preds = %262
  %258 = call fastcc zeroext i8 @hl_giftwrap(ptr noundef nonnull %1, ptr noundef nonnull %2) #13
  %259 = zext i8 %258 to i16
  %260 = tail call i16 @llvm.fshl.i16(i16 %254, i16 %254, i16 1)
  %261 = xor i16 %260, %259
  br label %291

262:                                              ; preds = %262, %253
  %263 = phi i8 [ 0, %253 ], [ %285, %262 ]
  %264 = phi i8 [ 0, %253 ], [ %283, %262 ]
  %265 = phi i16 [ %256, %253 ], [ %280, %262 ]
  %266 = shl i16 %265, 7
  %267 = xor i16 %266, %265
  %268 = lshr i16 %267, 9
  %269 = xor i16 %268, %267
  %270 = shl i16 %269, 8
  %271 = xor i16 %270, %269
  %272 = urem i16 %271, 100
  %273 = zext nneg i8 %263 to i16
  %274 = getelementptr i8, ptr %1, i16 %273
  store i16 %272, ptr %274, align 1, !tbaa !57
  %275 = shl i16 %271, 7
  %276 = xor i16 %275, %271
  %277 = lshr i16 %276, 9
  %278 = xor i16 %277, %276
  %279 = shl i16 %278, 8
  %280 = xor i16 %279, %278
  %281 = urem i16 %280, 100
  %282 = getelementptr i8, ptr %252, i16 %273
  store i16 %281, ptr %282, align 1, !tbaa !58
  %283 = add nuw nsw i8 %264, 1
  %284 = icmp eq i8 %283, 14
  %285 = add nuw nsw i8 %263, 4
  br i1 %284, label %257, label %262, !llvm.loop !90

286:                                              ; preds = %319
  %287 = tail call i16 @llvm.fshl.i16(i16 %321, i16 %321, i16 1)
  %288 = xor i16 %344, %287
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #14
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #14
  %289 = add nuw nsw i16 %255, 1
  %290 = icmp eq i16 %289, 12
  br i1 %290, label %348, label %253, !llvm.loop !91

291:                                              ; preds = %319, %257
  %292 = phi i16 [ %261, %257 ], [ %321, %319 ]
  %293 = phi i8 [ 0, %257 ], [ %322, %319 ]
  %294 = phi i16 [ 0, %257 ], [ %344, %319 ]
  %295 = zext i8 %293 to i16
  %296 = getelementptr i8, ptr %2, i16 %295
  %297 = load i8, ptr %296, align 1, !tbaa !6
  %298 = zext i8 %297 to i16
  %299 = getelementptr inbounds nuw [4 x i8], ptr %1, i16 %298
  %300 = load i16, ptr %299, align 1, !tbaa !2
  %301 = getelementptr inbounds nuw i8, ptr %299, i16 2
  %302 = load i16, ptr %301, align 1, !tbaa !2
  %303 = add nuw nsw i16 %295, 1
  %304 = icmp eq i16 %303, %259
  %305 = select i1 %304, i16 0, i16 %303
  %306 = getelementptr inbounds nuw i8, ptr %2, i16 %305
  %307 = load i8, ptr %306, align 1, !tbaa !6
  %308 = zext i8 %307 to i16
  %309 = getelementptr inbounds nuw [4 x i8], ptr %1, i16 %308
  %310 = load i16, ptr %309, align 1, !tbaa !2
  %311 = getelementptr inbounds nuw i8, ptr %309, i16 2
  %312 = load i16, ptr %311, align 1, !tbaa !2
  %313 = sext i16 %310 to i32
  %314 = sext i16 %300 to i32
  %315 = sub nsw i32 %313, %314
  %316 = sext i16 %312 to i32
  %317 = sext i16 %302 to i32
  %318 = sub nsw i32 %316, %317
  br label %324

319:                                              ; preds = %343
  %320 = tail call i16 @llvm.fshl.i16(i16 %292, i16 %292, i16 1)
  %321 = xor i16 %320, %298
  %322 = add nuw i8 %293, 1
  %323 = icmp eq i8 %322, %258
  br i1 %323, label %286, label %291, !llvm.loop !92

324:                                              ; preds = %343, %291
  %325 = phi i8 [ 0, %291 ], [ %347, %343 ]
  %326 = phi i8 [ 0, %291 ], [ %345, %343 ]
  %327 = phi i16 [ %294, %291 ], [ %344, %343 ]
  %328 = zext nneg i8 %325 to i16
  %329 = getelementptr i8, ptr %1, i16 %328
  %330 = load i16, ptr %329, align 1
  %331 = getelementptr i8, ptr %252, i16 %328
  %332 = load i16, ptr %331, align 1
  %333 = sext i16 %330 to i32
  %334 = sub nsw i32 %314, %333
  %335 = sext i16 %332 to i32
  %336 = sub nsw i32 %335, %317
  %337 = mul nsw i32 %336, %315
  %338 = mul i32 %334, %318
  %339 = add i32 %337, %338
  %340 = icmp slt i32 %339, 0
  br i1 %340, label %341, label %343

341:                                              ; preds = %324
  %342 = add i16 %327, 1
  br label %343

343:                                              ; preds = %341, %324
  %344 = phi i16 [ %342, %341 ], [ %327, %324 ]
  %345 = add nuw nsw i8 %326, 1
  %346 = icmp eq i8 %345, 14
  %347 = add nuw nsw i8 %325, 4
  br i1 %346, label %319, label %324, !llvm.loop !93

348:                                              ; preds = %286
  store volatile i16 %288, ptr @corpus_result, align 1, !tbaa !2
  br label %349

349:                                              ; preds = %379, %348
  %350 = phi i16 [ 110, %348 ], [ %351, %379 ]
  %351 = add nsw i16 %350, -1
  %352 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %353 = icmp eq i8 %352, 0
  br i1 %353, label %365, label %354

354:                                              ; preds = %349, %354
  %355 = phi i8 [ %362, %354 ], [ 0, %349 ]
  %356 = zext i8 %355 to i16
  %357 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %356
  %358 = load ptr, ptr %357, align 1, !tbaa !35
  %359 = load ptr, ptr %358, align 1, !tbaa !40
  %360 = getelementptr inbounds nuw i8, ptr %359, i16 2
  %361 = load ptr, ptr %360, align 1, !tbaa !83
  tail call void %361(ptr noundef nonnull %358, ptr noundef nonnull @main.a) #12, !inline_history !94
  %362 = add nuw i8 %355, 1
  %363 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %364 = icmp ult i8 %362, %363
  br i1 %364, label %354, label %365, !llvm.loop !85

365:                                              ; preds = %354, %349
  %366 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %367

367:                                              ; preds = %367, %365
  %368 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %369 = icmp sgt i8 %368, -1
  br i1 %369, label %367, label %370, !llvm.loop !86

370:                                              ; preds = %367
  tail call fastcc void @upq_flush() #13
  %371 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %372 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %373 = icmp ult i8 %371, %372
  br i1 %373, label %376, label %374

374:                                              ; preds = %370
  %375 = icmp ugt i8 %371, %372
  br i1 %375, label %376, label %379

376:                                              ; preds = %374, %370
  %377 = phi i8 [ 1, %370 ], [ -1, %374 ]
  %378 = add i8 %377, %371
  store i8 %378, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %379

379:                                              ; preds = %376, %374
  %380 = phi i8 [ %371, %374 ], [ %378, %376 ]
  %381 = and i8 %380, 15
  store volatile i8 %381, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %382 = icmp eq i16 %351, 0
  br i1 %382, label %383, label %349, !llvm.loop !95

383:                                              ; preds = %379
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !76
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !77
  br label %387

384:                                              ; preds = %416
  %385 = add nuw nsw i8 %388, 1
  %386 = icmp eq i8 %385, 90
  br i1 %386, label %421, label %387, !llvm.loop !96

387:                                              ; preds = %384, %383
  %388 = phi i8 [ 0, %383 ], [ %385, %384 ]
  %389 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %390 = icmp eq i8 %389, 0
  br i1 %390, label %402, label %391

391:                                              ; preds = %387, %391
  %392 = phi i8 [ %399, %391 ], [ 0, %387 ]
  %393 = zext i8 %392 to i16
  %394 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %393
  %395 = load ptr, ptr %394, align 1, !tbaa !35
  %396 = load ptr, ptr %395, align 1, !tbaa !40
  %397 = getelementptr inbounds nuw i8, ptr %396, i16 2
  %398 = load ptr, ptr %397, align 1, !tbaa !83
  tail call void %398(ptr noundef nonnull %395, ptr noundef nonnull @main.a) #12, !inline_history !97
  %399 = add nuw i8 %392, 1
  %400 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %401 = icmp ult i8 %399, %400
  br i1 %401, label %391, label %402, !llvm.loop !85

402:                                              ; preds = %391, %387
  %403 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %404

404:                                              ; preds = %404, %402
  %405 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %406 = icmp sgt i8 %405, -1
  br i1 %406, label %404, label %407, !llvm.loop !86

407:                                              ; preds = %404
  tail call fastcc void @upq_flush() #13
  %408 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %409 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %410 = icmp ult i8 %408, %409
  br i1 %410, label %413, label %411

411:                                              ; preds = %407
  %412 = icmp ugt i8 %408, %409
  br i1 %412, label %413, label %416

413:                                              ; preds = %411, %407
  %414 = phi i8 [ 1, %407 ], [ -1, %411 ]
  %415 = add i8 %414, %408
  store i8 %415, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %416

416:                                              ; preds = %413, %411
  %417 = phi i8 [ %408, %411 ], [ %415, %413 ]
  %418 = and i8 %417, 15
  store volatile i8 %418, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %419 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 19), align 1, !tbaa !98
  %420 = icmp sgt i16 %419, 3583
  br i1 %420, label %421, label %384

421:                                              ; preds = %416, %384
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !76
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %422 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %423 = icmp eq i8 %422, 0
  br i1 %423, label %457, label %424

424:                                              ; preds = %421, %452
  %425 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %426 = icmp eq i8 %425, 0
  br i1 %426, label %438, label %427

427:                                              ; preds = %424, %427
  %428 = phi i8 [ %435, %427 ], [ 0, %424 ]
  %429 = zext i8 %428 to i16
  %430 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %429
  %431 = load ptr, ptr %430, align 1, !tbaa !35
  %432 = load ptr, ptr %431, align 1, !tbaa !40
  %433 = getelementptr inbounds nuw i8, ptr %432, i16 2
  %434 = load ptr, ptr %433, align 1, !tbaa !83
  tail call void %434(ptr noundef nonnull %431, ptr noundef nonnull @main.a) #12, !inline_history !99
  %435 = add nuw i8 %428, 1
  %436 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %437 = icmp ult i8 %435, %436
  br i1 %437, label %427, label %438, !llvm.loop !85

438:                                              ; preds = %427, %424
  %439 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %440

440:                                              ; preds = %440, %438
  %441 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %442 = icmp sgt i8 %441, -1
  br i1 %442, label %440, label %443, !llvm.loop !86

443:                                              ; preds = %440
  tail call fastcc void @upq_flush() #13
  %444 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %445 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %446 = icmp ult i8 %444, %445
  br i1 %446, label %449, label %447

447:                                              ; preds = %443
  %448 = icmp ugt i8 %444, %445
  br i1 %448, label %449, label %452

449:                                              ; preds = %447, %443
  %450 = phi i8 [ 1, %443 ], [ -1, %447 ]
  %451 = add i8 %450, %444
  store i8 %451, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %452

452:                                              ; preds = %449, %447
  %453 = phi i8 [ %444, %447 ], [ %451, %449 ]
  %454 = and i8 %453, 15
  store volatile i8 %454, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %455 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %456 = icmp eq i8 %455, 0
  br i1 %456, label %457, label %424, !llvm.loop !87

457:                                              ; preds = %452, %421
  %458 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !82
  %459 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %460 = or i8 %459, %458
  %461 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %462 = xor i8 %461, -1
  %463 = and i8 %460, %462
  store i8 %463, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %463, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !75
  %464 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %465 = icmp ugt i8 %464, 15
  br i1 %465, label %477, label %466

466:                                              ; preds = %457
  %467 = zext nneg i8 %464 to i16
  %468 = add nuw nsw i8 %464, 1
  store i8 %468, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %469 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %467
  %470 = getelementptr inbounds nuw i8, ptr %469, i16 10
  store i8 1, ptr %470, align 1, !tbaa !45
  store i16 0, ptr %469, align 1, !tbaa !47
  %471 = getelementptr inbounds nuw i8, ptr %469, i16 9
  store i8 0, ptr %471, align 1, !tbaa !48
  %472 = getelementptr inbounds nuw i8, ptr %469, i16 7
  store i8 34, ptr %472, align 1, !tbaa !49
  %473 = getelementptr inbounds nuw i8, ptr %469, i16 8
  store i8 0, ptr %473, align 1, !tbaa !50
  %474 = getelementptr inbounds nuw i8, ptr %469, i16 2
  store i16 ptrtoint (ptr @title_end._title_bg_black to i16), ptr %474, align 1, !tbaa !51
  %475 = getelementptr inbounds nuw i8, ptr %469, i16 6
  store i8 0, ptr %475, align 1, !tbaa !52
  %476 = getelementptr inbounds nuw i8, ptr %469, i16 4
  store i16 2, ptr %476, align 1, !tbaa !53
  br label %477

477:                                              ; preds = %457, %466
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  br label %478

478:                                              ; preds = %506, %477
  tail call fastcc void @step() #13
  %479 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %480 = icmp eq i8 %479, 0
  br i1 %480, label %492, label %481

481:                                              ; preds = %478, %481
  %482 = phi i8 [ %489, %481 ], [ 0, %478 ]
  %483 = zext i8 %482 to i16
  %484 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %483
  %485 = load ptr, ptr %484, align 1, !tbaa !35
  %486 = load ptr, ptr %485, align 1, !tbaa !40
  %487 = getelementptr inbounds nuw i8, ptr %486, i16 2
  %488 = load ptr, ptr %487, align 1, !tbaa !83
  tail call void %488(ptr noundef nonnull %485, ptr noundef nonnull @main.a) #12, !inline_history !100
  %489 = add nuw i8 %482, 1
  %490 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %491 = icmp ult i8 %489, %490
  br i1 %491, label %481, label %492, !llvm.loop !85

492:                                              ; preds = %481, %478
  %493 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %494

494:                                              ; preds = %494, %492
  %495 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %496 = icmp sgt i8 %495, -1
  br i1 %496, label %494, label %497, !llvm.loop !86

497:                                              ; preds = %494
  tail call fastcc void @upq_flush() #13
  %498 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %499 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %500 = icmp ult i8 %498, %499
  br i1 %500, label %503, label %501

501:                                              ; preds = %497
  %502 = icmp ugt i8 %498, %499
  br i1 %502, label %503, label %506

503:                                              ; preds = %501, %497
  %504 = phi i8 [ 1, %497 ], [ -1, %501 ]
  %505 = add i8 %504, %498
  store i8 %505, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %506

506:                                              ; preds = %501, %503
  %507 = phi i8 [ %498, %501 ], [ %505, %503 ]
  %508 = and i8 %507, 15
  store volatile i8 %508, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  br label %478
}

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @step() unnamed_addr #1 {
  br label %4

1:                                                ; preds = %35
  %2 = tail call fastcc zeroext i8 @hl_giftwrap(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 4525)) #13
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(4098) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i64 4098, i1 false)
  store i16 255, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %3 = zext i8 %2 to i16
  br label %40

4:                                                ; preds = %0, %35
  %5 = phi i8 [ 0, %0 ], [ %39, %35 ]
  %6 = phi i8 [ 0, %0 ], [ %37, %35 ]
  %7 = zext nneg i8 %5 to i16
  %8 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %7
  %9 = load i16, ptr %8, align 1, !tbaa !57
  %10 = zext nneg i8 %6 to i16
  %11 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4497), i16 %10
  %12 = load i8, ptr %11, align 1, !tbaa !6
  %13 = sext i8 %12 to i16
  %14 = add nsw i16 %9, %13
  %15 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), i16 %7
  %16 = load i16, ptr %15, align 1, !tbaa !58
  %17 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4511), i16 %10
  %18 = load i8, ptr %17, align 1, !tbaa !6
  %19 = sext i8 %18 to i16
  %20 = add nsw i16 %16, %19
  %21 = icmp slt i16 %14, 8
  br i1 %21, label %24, label %22

22:                                               ; preds = %4
  %23 = icmp samesign ugt i16 %14, 118
  br i1 %23, label %24, label %27

24:                                               ; preds = %22, %4
  %25 = phi i16 [ 8, %4 ], [ 118, %22 ]
  %26 = sub i8 0, %12
  store i8 %26, ptr %11, align 1, !tbaa !6
  br label %27

27:                                               ; preds = %24, %22
  %28 = phi i16 [ %14, %22 ], [ %25, %24 ]
  %29 = icmp slt i16 %20, 8
  br i1 %29, label %32, label %30

30:                                               ; preds = %27
  %31 = icmp samesign ugt i16 %20, 118
  br i1 %31, label %32, label %35

32:                                               ; preds = %30, %27
  %33 = phi i16 [ 8, %27 ], [ 118, %30 ]
  %34 = sub i8 0, %18
  store i8 %34, ptr %17, align 1, !tbaa !6
  br label %35

35:                                               ; preds = %32, %30
  %36 = phi i16 [ %20, %30 ], [ %33, %32 ]
  store i16 %28, ptr %8, align 1, !tbaa !57
  store i16 %36, ptr %15, align 1, !tbaa !58
  %37 = add nuw nsw i8 %6, 1
  %38 = icmp eq i8 %37, 14
  %39 = add nuw nsw i8 %5, 4
  br i1 %38, label %1, label %4, !llvm.loop !101

40:                                               ; preds = %1, %40
  %41 = phi i8 [ 0, %1 ], [ %60, %40 ]
  %42 = zext i8 %41 to i16
  %43 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4525), i16 %42
  %44 = load i8, ptr %43, align 1, !tbaa !6
  %45 = zext i8 %44 to i16
  %46 = getelementptr inbounds nuw [4 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %45
  %47 = load i16, ptr %46, align 1, !tbaa !2
  %48 = getelementptr inbounds nuw i8, ptr %46, i16 2
  %49 = load i16, ptr %48, align 1, !tbaa !2
  %50 = add nuw nsw i16 %42, 1
  %51 = icmp eq i16 %50, %3
  %52 = select i1 %51, i16 0, i16 %50
  %53 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4525), i16 %52
  %54 = load i8, ptr %53, align 1, !tbaa !6
  %55 = zext i8 %54 to i16
  %56 = getelementptr inbounds nuw [4 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %55
  %57 = load i16, ptr %56, align 1, !tbaa !2
  %58 = getelementptr inbounds nuw i8, ptr %56, i16 2
  %59 = load i16, ptr %58, align 1, !tbaa !2
  tail call fastcc void @canvas_line(i16 noundef %47, i16 noundef %49, i16 noundef %57, i16 noundef %59) #13
  %60 = add nuw i8 %41, 1
  %61 = icmp eq i8 %60, %2
  br i1 %61, label %62, label %40, !llvm.loop !102

62:                                               ; preds = %40, %195
  %63 = phi i8 [ %198, %195 ], [ 0, %40 ]
  %64 = phi i8 [ %196, %195 ], [ 0, %40 ]
  %65 = zext nneg i8 %63 to i16
  %66 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %65
  %67 = load i16, ptr %66, align 1, !tbaa !57
  %68 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), i16 %65
  %69 = load i16, ptr %68, align 1, !tbaa !58
  %70 = icmp ugt i16 %67, 127
  br i1 %70, label %94, label %71

71:                                               ; preds = %62
  %72 = icmp ugt i16 %69, 127
  br i1 %72, label %94, label %73

73:                                               ; preds = %71
  %74 = shl nuw nsw i16 %69, 1
  %75 = and i16 %74, 240
  %76 = lshr i16 %67, 3
  %77 = or disjoint i16 %75, %76
  %78 = shl nuw nsw i16 %77, 4
  %79 = and i16 %74, 14
  %80 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %78
  %81 = getelementptr inbounds nuw i8, ptr %80, i16 %79
  %82 = and i16 %67, 7
  %83 = lshr exact i16 128, %82
  %84 = load i8, ptr %81, align 1, !tbaa !6
  %85 = trunc nuw i16 %83 to i8
  %86 = or i8 %84, %85
  store i8 %86, ptr %81, align 1, !tbaa !6
  %87 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %88 = icmp ult i16 %77, %87
  br i1 %88, label %89, label %90

89:                                               ; preds = %73
  store i16 %77, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %90

90:                                               ; preds = %89, %73
  %91 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %92 = icmp ugt i16 %77, %91
  br i1 %92, label %93, label %94

93:                                               ; preds = %90
  store i16 %77, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %94

94:                                               ; preds = %62, %71, %90, %93
  %95 = add nsw i16 %67, 1
  %96 = icmp ugt i16 %95, 127
  br i1 %96, label %120, label %97

97:                                               ; preds = %94
  %98 = icmp ugt i16 %69, 127
  br i1 %98, label %120, label %99

99:                                               ; preds = %97
  %100 = shl nuw nsw i16 %69, 1
  %101 = and i16 %100, 240
  %102 = lshr i16 %95, 3
  %103 = or disjoint i16 %101, %102
  %104 = shl nuw nsw i16 %103, 4
  %105 = and i16 %100, 14
  %106 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %104
  %107 = getelementptr inbounds nuw i8, ptr %106, i16 %105
  %108 = and i16 %95, 7
  %109 = lshr exact i16 128, %108
  %110 = load i8, ptr %107, align 1, !tbaa !6
  %111 = trunc nuw i16 %109 to i8
  %112 = or i8 %110, %111
  store i8 %112, ptr %107, align 1, !tbaa !6
  %113 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %114 = icmp ult i16 %103, %113
  br i1 %114, label %115, label %116

115:                                              ; preds = %99
  store i16 %103, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %116

116:                                              ; preds = %115, %99
  %117 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %118 = icmp ugt i16 %103, %117
  br i1 %118, label %119, label %120

119:                                              ; preds = %116
  store i16 %103, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %120

120:                                              ; preds = %94, %97, %116, %119
  %121 = add nsw i16 %67, -1
  %122 = icmp ugt i16 %121, 127
  br i1 %122, label %146, label %123

123:                                              ; preds = %120
  %124 = icmp ugt i16 %69, 127
  br i1 %124, label %146, label %125

125:                                              ; preds = %123
  %126 = shl nuw nsw i16 %69, 1
  %127 = and i16 %126, 240
  %128 = lshr i16 %121, 3
  %129 = or disjoint i16 %127, %128
  %130 = shl nuw nsw i16 %129, 4
  %131 = and i16 %126, 14
  %132 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %130
  %133 = getelementptr inbounds nuw i8, ptr %132, i16 %131
  %134 = and i16 %121, 7
  %135 = lshr exact i16 128, %134
  %136 = load i8, ptr %133, align 1, !tbaa !6
  %137 = trunc nuw i16 %135 to i8
  %138 = or i8 %136, %137
  store i8 %138, ptr %133, align 1, !tbaa !6
  %139 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %140 = icmp ult i16 %129, %139
  br i1 %140, label %141, label %142

141:                                              ; preds = %125
  store i16 %129, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %142

142:                                              ; preds = %141, %125
  %143 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %144 = icmp ugt i16 %129, %143
  br i1 %144, label %145, label %146

145:                                              ; preds = %142
  store i16 %129, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %146

146:                                              ; preds = %120, %123, %142, %145
  %147 = add nsw i16 %69, 1
  br i1 %70, label %195, label %148

148:                                              ; preds = %146
  %149 = icmp ugt i16 %147, 127
  br i1 %149, label %171, label %150

150:                                              ; preds = %148
  %151 = shl nuw nsw i16 %147, 1
  %152 = and i16 %151, 240
  %153 = lshr i16 %67, 3
  %154 = or disjoint i16 %152, %153
  %155 = shl nuw nsw i16 %154, 4
  %156 = and i16 %151, 14
  %157 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %155
  %158 = getelementptr inbounds nuw i8, ptr %157, i16 %156
  %159 = and i16 %67, 7
  %160 = lshr exact i16 128, %159
  %161 = load i8, ptr %158, align 1, !tbaa !6
  %162 = trunc nuw i16 %160 to i8
  %163 = or i8 %161, %162
  store i8 %163, ptr %158, align 1, !tbaa !6
  %164 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %165 = icmp ult i16 %154, %164
  br i1 %165, label %166, label %167

166:                                              ; preds = %150
  store i16 %154, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %167

167:                                              ; preds = %166, %150
  %168 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %169 = icmp ugt i16 %154, %168
  br i1 %169, label %170, label %171

170:                                              ; preds = %167
  store i16 %154, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %171

171:                                              ; preds = %148, %167, %170
  %172 = add nsw i16 %69, -1
  %173 = icmp ugt i16 %172, 127
  br i1 %173, label %195, label %174

174:                                              ; preds = %171
  %175 = shl nuw nsw i16 %172, 1
  %176 = and i16 %175, 240
  %177 = lshr i16 %67, 3
  %178 = or disjoint i16 %176, %177
  %179 = shl nuw nsw i16 %178, 4
  %180 = and i16 %175, 14
  %181 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %179
  %182 = getelementptr inbounds nuw i8, ptr %181, i16 %180
  %183 = and i16 %67, 7
  %184 = lshr exact i16 128, %183
  %185 = load i8, ptr %182, align 1, !tbaa !6
  %186 = trunc nuw i16 %184 to i8
  %187 = or i8 %185, %186
  store i8 %187, ptr %182, align 1, !tbaa !6
  %188 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %189 = icmp ult i16 %178, %188
  br i1 %189, label %190, label %191

190:                                              ; preds = %174
  store i16 %178, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %191

191:                                              ; preds = %190, %174
  %192 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %193 = icmp ugt i16 %178, %192
  br i1 %193, label %194, label %195

194:                                              ; preds = %191
  store i16 %178, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %195

195:                                              ; preds = %146, %171, %191, %194
  %196 = add nuw nsw i8 %64, 1
  %197 = icmp eq i8 %196, 14
  %198 = add nuw nsw i8 %63, 4
  br i1 %197, label %200, label %62, !llvm.loop !103

199:                                              ; preds = %294
  ret void

200:                                              ; preds = %195, %294
  %201 = phi i8 [ %295, %294 ], [ 0, %195 ]
  %202 = zext i8 %201 to i16
  %203 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4525), i16 %202
  %204 = load i8, ptr %203, align 1, !tbaa !6
  %205 = zext i8 %204 to i16
  %206 = getelementptr inbounds nuw [4 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %205
  %207 = load i16, ptr %206, align 1, !tbaa !2
  %208 = getelementptr inbounds nuw i8, ptr %206, i16 2
  %209 = load i16, ptr %208, align 1, !tbaa !2
  %210 = icmp ugt i16 %207, 127
  br i1 %210, label %237, label %211

211:                                              ; preds = %200
  %212 = icmp ugt i16 %209, 127
  br i1 %212, label %237, label %213

213:                                              ; preds = %211
  %214 = shl nuw nsw i16 %209, 1
  %215 = and i16 %214, 240
  %216 = lshr i16 %207, 3
  %217 = or disjoint i16 %215, %216
  %218 = shl nuw nsw i16 %217, 4
  %219 = and i16 %214, 14
  %220 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %218
  %221 = getelementptr inbounds nuw i8, ptr %220, i16 %219
  %222 = and i16 %207, 7
  %223 = lshr exact i16 128, %222
  %224 = load i8, ptr %221, align 1, !tbaa !6
  %225 = trunc nuw i16 %223 to i8
  %226 = or i8 %224, %225
  store i8 %226, ptr %221, align 1, !tbaa !6
  %227 = getelementptr inbounds nuw i8, ptr %221, i16 1
  %228 = load i8, ptr %227, align 1, !tbaa !6
  %229 = or i8 %228, %225
  store i8 %229, ptr %227, align 1, !tbaa !6
  %230 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %231 = icmp ult i16 %217, %230
  br i1 %231, label %232, label %233

232:                                              ; preds = %213
  store i16 %217, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %233

233:                                              ; preds = %232, %213
  %234 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %235 = icmp ugt i16 %217, %234
  br i1 %235, label %236, label %237

236:                                              ; preds = %233
  store i16 %217, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %237

237:                                              ; preds = %200, %211, %233, %236
  %238 = add nsw i16 %207, 1
  %239 = icmp ugt i16 %238, 127
  br i1 %239, label %266, label %240

240:                                              ; preds = %237
  %241 = icmp ugt i16 %209, 127
  br i1 %241, label %266, label %242

242:                                              ; preds = %240
  %243 = shl nuw nsw i16 %209, 1
  %244 = and i16 %243, 240
  %245 = lshr i16 %238, 3
  %246 = or disjoint i16 %244, %245
  %247 = shl nuw nsw i16 %246, 4
  %248 = and i16 %243, 14
  %249 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %247
  %250 = getelementptr inbounds nuw i8, ptr %249, i16 %248
  %251 = and i16 %238, 7
  %252 = lshr exact i16 128, %251
  %253 = load i8, ptr %250, align 1, !tbaa !6
  %254 = trunc nuw i16 %252 to i8
  %255 = or i8 %253, %254
  store i8 %255, ptr %250, align 1, !tbaa !6
  %256 = getelementptr inbounds nuw i8, ptr %250, i16 1
  %257 = load i8, ptr %256, align 1, !tbaa !6
  %258 = or i8 %257, %254
  store i8 %258, ptr %256, align 1, !tbaa !6
  %259 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %260 = icmp ult i16 %246, %259
  br i1 %260, label %261, label %262

261:                                              ; preds = %242
  store i16 %246, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %262

262:                                              ; preds = %261, %242
  %263 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %264 = icmp ugt i16 %246, %263
  br i1 %264, label %265, label %266

265:                                              ; preds = %262
  store i16 %246, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %266

266:                                              ; preds = %237, %240, %262, %265
  %267 = add nsw i16 %209, 1
  br i1 %210, label %294, label %268

268:                                              ; preds = %266
  %269 = icmp ugt i16 %267, 127
  br i1 %269, label %294, label %270

270:                                              ; preds = %268
  %271 = shl nuw nsw i16 %267, 1
  %272 = and i16 %271, 240
  %273 = lshr i16 %207, 3
  %274 = or disjoint i16 %272, %273
  %275 = shl nuw nsw i16 %274, 4
  %276 = and i16 %271, 14
  %277 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %275
  %278 = getelementptr inbounds nuw i8, ptr %277, i16 %276
  %279 = and i16 %207, 7
  %280 = lshr exact i16 128, %279
  %281 = load i8, ptr %278, align 1, !tbaa !6
  %282 = trunc nuw i16 %280 to i8
  %283 = or i8 %281, %282
  store i8 %283, ptr %278, align 1, !tbaa !6
  %284 = getelementptr inbounds nuw i8, ptr %278, i16 1
  %285 = load i8, ptr %284, align 1, !tbaa !6
  %286 = or i8 %285, %282
  store i8 %286, ptr %284, align 1, !tbaa !6
  %287 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %288 = icmp ult i16 %274, %287
  br i1 %288, label %289, label %290

289:                                              ; preds = %270
  store i16 %274, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %290

290:                                              ; preds = %289, %270
  %291 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %292 = icmp ugt i16 %274, %291
  br i1 %292, label %293, label %294

293:                                              ; preds = %290
  store i16 %274, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %294

294:                                              ; preds = %266, %268, %290, %293
  %295 = add nuw i8 %201, 1
  %296 = icmp eq i8 %295, %2
  br i1 %296, label %199, label %200, !llvm.loop !104
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #2

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_canvas_reserve(ptr noundef readonly captures(none) %0, ptr readnone captures(none) %1) #3 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4105
  %4 = load i16, ptr %3, align 1, !tbaa !21
  %5 = lshr i16 %4, 8
  %6 = trunc nuw i16 %5 to i8
  %7 = and i8 %6, -4
  store volatile i8 %7, ptr inttoptr (i16 8457 to ptr), align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %9 = load i16, ptr %8, align 1, !tbaa !20
  %10 = lshr i16 %9, 12
  %11 = trunc nuw nsw i16 %10 to i8
  store volatile i8 %11, ptr inttoptr (i16 8460 to ptr), align 4, !tbaa !6
  %12 = load i16, ptr %8, align 1, !tbaa !20
  %13 = lshr i16 %12, 3
  %14 = add nuw nsw i16 %13, 256
  %15 = load i16, ptr %3, align 1, !tbaa !21
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %15, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %16 = getelementptr inbounds nuw i8, ptr %0, i16 4107
  %17 = load i8, ptr %16, align 1, !tbaa !22
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 4108
  br label %19

19:                                               ; preds = %2, %23
  %20 = phi i8 [ 0, %2 ], [ %24, %23 ]
  br label %26

21:                                               ; preds = %23
  %22 = load i16, ptr %8, align 1, !tbaa !20
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %22, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %45

23:                                               ; preds = %40
  %24 = add nuw nsw i8 %20, 1
  %25 = icmp eq i8 %24, 32
  br i1 %25, label %21, label %19, !llvm.loop !105

26:                                               ; preds = %19, %40
  %27 = phi i8 [ 0, %19 ], [ %42, %40 ]
  %28 = sub i8 %27, %17
  %29 = zext i8 %28 to i16
  %30 = icmp ult i8 %28, 16
  br i1 %30, label %31, label %40

31:                                               ; preds = %26
  %32 = load i8, ptr %18, align 1, !tbaa !23
  %33 = sub i8 %20, %32
  %34 = icmp ult i8 %33, 16
  br i1 %34, label %35, label %40

35:                                               ; preds = %31
  %36 = shl nuw i8 %33, 4
  %37 = zext i8 %36 to i16
  %38 = add nuw nsw i16 %13, %29
  %39 = add nuw nsw i16 %38, %37
  br label %40

40:                                               ; preds = %26, %31, %35
  %41 = phi i16 [ %39, %35 ], [ %14, %31 ], [ %14, %26 ]
  store volatile i16 %41, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %42 = add nuw nsw i8 %27, 1
  %43 = icmp eq i8 %42, 32
  br i1 %43, label %23, label %26, !llvm.loop !106

44:                                               ; preds = %45
  ret void

45:                                               ; preds = %21, %45
  %46 = phi i16 [ 0, %21 ], [ %47, %45 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %47 = add nuw nsw i16 %46, 1
  %48 = icmp eq i16 %47, 2056
  br i1 %48, label %44, label %45, !llvm.loop !107
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal void @_canvas_emit(ptr noundef %0, ptr noundef captures(none) %1) #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4099
  %4 = load i16, ptr %3, align 1, !tbaa !24
  %5 = getelementptr inbounds nuw i8, ptr %0, i16 4101
  %6 = load i16, ptr %5, align 1, !tbaa !25
  %7 = icmp ugt i16 %4, %6
  br i1 %7, label %48, label %8

8:                                                ; preds = %2
  %9 = sub nuw i16 %6, %4
  %10 = add i16 %9, -256
  %11 = icmp ult i16 %10, -257
  br i1 %11, label %12, label %14

12:                                               ; preds = %8
  %13 = add i16 %4, 255
  br label %14

14:                                               ; preds = %12, %8
  %15 = phi i16 [ 255, %12 ], [ %9, %8 ]
  %16 = phi i16 [ %13, %12 ], [ %6, %8 ]
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %18 = load i16, ptr %17, align 1, !tbaa !20
  %19 = shl i16 %4, 3
  %20 = add i16 %18, %19
  %21 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %22 = shl i16 %4, 4
  %23 = getelementptr inbounds nuw i8, ptr %21, i16 %22
  %24 = shl nsw i16 %15, 4
  %25 = add nsw i16 %24, 16
  %26 = icmp eq i16 %25, 0
  br i1 %26, label %43, label %27

27:                                               ; preds = %14
  %28 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %29 = load i8, ptr %28, align 1, !tbaa !44
  %30 = icmp ugt i8 %29, 15
  br i1 %30, label %43, label %31

31:                                               ; preds = %27
  %32 = zext nneg i8 %29 to i16
  %33 = add nuw nsw i8 %29, 1
  store i8 %33, ptr %28, align 1, !tbaa !44
  %34 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %32
  %35 = getelementptr inbounds nuw i8, ptr %34, i16 10
  store i8 0, ptr %35, align 1, !tbaa !45
  store i16 %20, ptr %34, align 1, !tbaa !47
  %36 = getelementptr inbounds nuw i8, ptr %34, i16 9
  store i8 -128, ptr %36, align 1, !tbaa !48
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 7
  store i8 24, ptr %37, align 1, !tbaa !49
  %38 = getelementptr inbounds nuw i8, ptr %34, i16 8
  store i8 1, ptr %38, align 1, !tbaa !50
  %39 = ptrtoint ptr %23 to i16
  %40 = getelementptr inbounds nuw i8, ptr %34, i16 2
  store i16 %39, ptr %40, align 1, !tbaa !51
  %41 = getelementptr inbounds nuw i8, ptr %34, i16 6
  store i8 0, ptr %41, align 1, !tbaa !52
  %42 = getelementptr inbounds nuw i8, ptr %34, i16 4
  store i16 %25, ptr %42, align 1, !tbaa !53
  br label %43

43:                                               ; preds = %14, %27, %31
  %44 = icmp ult i16 %16, %6
  br i1 %44, label %46, label %45

45:                                               ; preds = %43
  store i16 -1, ptr %3, align 1, !tbaa !24
  store i16 0, ptr %5, align 1, !tbaa !25
  br label %48

46:                                               ; preds = %43
  %47 = add nuw i16 %16, 1
  store i16 %47, ptr %3, align 1, !tbaa !24
  br label %48

48:                                               ; preds = %45, %46, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_text_reserve(ptr readnone captures(none) %0, ptr readnone captures(none) %1) #3 {
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 2048, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %4

3:                                                ; preds = %4
  ret void

4:                                                ; preds = %2, %4
  %5 = phi i16 [ 0, %2 ], [ %8, %4 ]
  %6 = getelementptr inbounds nuw [2 x i8], ptr @FONT8, i16 %5
  %7 = load i16, ptr %6, align 1, !tbaa !2
  store volatile i16 %7, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %8 = add nuw nsw i16 %5, 1
  %9 = icmp eq i16 %8, 512
  br i1 %9, label %3, label %4, !llvm.loop !108
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(argmem: readwrite)
define internal void @_text_emit(ptr noundef %0, ptr noundef captures(none) %1) #5 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 135
  %4 = load i8, ptr %3, align 1, !tbaa !31
  %5 = zext i8 %4 to i16
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %7 = getelementptr i8, ptr %0, i16 7
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %9 = getelementptr i8, ptr %0, i16 5
  br label %11

10:                                               ; preds = %42
  store i8 0, ptr %3, align 1, !tbaa !31
  ret void

11:                                               ; preds = %2, %42
  %12 = phi i8 [ 0, %2 ], [ %43, %42 ]
  %13 = phi i1 [ true, %2 ], [ false, %42 ]
  %14 = phi i8 [ 0, %2 ], [ 1, %42 ]
  %15 = zext nneg i8 %14 to i16
  %16 = shl nuw nsw i16 1, %15
  %17 = and i16 %16, %5
  %18 = icmp eq i16 %17, 0
  br i1 %18, label %42, label %19

19:                                               ; preds = %11
  %20 = load i8, ptr %6, align 1, !tbaa !44
  %21 = icmp ugt i8 %20, 15
  br i1 %21, label %42, label %22

22:                                               ; preds = %19
  %23 = zext i8 %12 to i16
  %24 = getelementptr i8, ptr %7, i16 %23
  %25 = load i16, ptr %8, align 1, !tbaa !29
  %26 = getelementptr i8, ptr %9, i16 %15
  %27 = load i8, ptr %26, align 1, !tbaa !6
  %28 = zext i8 %27 to i16
  %29 = shl nuw nsw i16 %28, 5
  %30 = add i16 %29, %25
  %31 = zext nneg i8 %20 to i16
  %32 = add nuw nsw i8 %20, 1
  store i8 %32, ptr %6, align 1, !tbaa !44
  %33 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %31
  %34 = getelementptr inbounds nuw i8, ptr %33, i16 10
  store i8 0, ptr %34, align 1, !tbaa !45
  store i16 %30, ptr %33, align 1, !tbaa !47
  %35 = getelementptr inbounds nuw i8, ptr %33, i16 9
  store i8 -128, ptr %35, align 1, !tbaa !48
  %36 = getelementptr inbounds nuw i8, ptr %33, i16 7
  store i8 24, ptr %36, align 1, !tbaa !49
  %37 = getelementptr inbounds nuw i8, ptr %33, i16 8
  store i8 1, ptr %37, align 1, !tbaa !50
  %38 = ptrtoint ptr %24 to i16
  %39 = getelementptr inbounds nuw i8, ptr %33, i16 2
  store i16 %38, ptr %39, align 1, !tbaa !51
  %40 = getelementptr inbounds nuw i8, ptr %33, i16 6
  store i8 0, ptr %40, align 1, !tbaa !52
  %41 = getelementptr inbounds nuw i8, ptr %33, i16 4
  store i16 64, ptr %41, align 1, !tbaa !53
  br label %42

42:                                               ; preds = %22, %19, %11
  %43 = add nuw i8 %12, 64
  br i1 %13, label %11, label %10, !llvm.loop !109
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_title_reserve(ptr noundef %0, ptr readnone captures(none) %1) #3 {
  store volatile i8 80, ptr inttoptr (i16 8456 to ptr), align 8, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !6
  store volatile i8 112, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -1, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 127, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -124, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 4096, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %3

3:                                                ; preds = %2, %16
  %4 = phi ptr [ @FONT8, %2 ], [ %18, %16 ]
  %5 = phi i16 [ 0, %2 ], [ %17, %16 ]
  br label %7

6:                                                ; preds = %16
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 5120, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %24

7:                                                ; preds = %3, %7
  %8 = phi i8 [ 0, %3 ], [ %15, %7 ]
  %9 = phi i8 [ 0, %3 ], [ %13, %7 ]
  %10 = zext nneg i8 %8 to i16
  %11 = getelementptr i8, ptr %4, i16 %10
  %12 = load i16, ptr %11, align 1, !tbaa !2
  store volatile i16 %12, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %13 = add nuw nsw i8 %9, 1
  %14 = icmp eq i8 %13, 8
  %15 = add nuw nsw i8 %8, 2
  br i1 %14, label %20, label %7, !llvm.loop !110

16:                                               ; preds = %20
  %17 = add nuw nsw i16 %5, 1
  %18 = getelementptr i8, ptr %4, i16 16
  %19 = icmp eq i16 %17, 64
  br i1 %19, label %6, label %3, !llvm.loop !111

20:                                               ; preds = %7, %20
  %21 = phi i8 [ %22, %20 ], [ 0, %7 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %22 = add nuw nsw i8 %21, 1
  %23 = icmp eq i8 %22, 8
  br i1 %23, label %16, label %20, !llvm.loop !112

24:                                               ; preds = %6, %33
  %25 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 16), %6 ], [ %36, %33 ]
  %26 = phi ptr [ @FONT16, %6 ], [ %35, %33 ]
  %27 = phi i16 [ 0, %6 ], [ %34, %33 ]
  br label %29

28:                                               ; preds = %33
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 20480, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %66

29:                                               ; preds = %24, %47
  %30 = phi i8 [ 0, %24 ], [ %52, %47 ]
  %31 = phi ptr [ %26, %24 ], [ %50, %47 ]
  %32 = phi i8 [ 0, %24 ], [ %48, %47 ]
  br label %38

33:                                               ; preds = %47
  %34 = add nuw nsw i16 %27, 1
  %35 = getelementptr i8, ptr %26, i16 64
  %36 = getelementptr i8, ptr %25, i16 64
  %37 = icmp eq i16 %34, 64
  br i1 %37, label %28, label %24, !llvm.loop !113

38:                                               ; preds = %29, %38
  %39 = phi i8 [ 0, %29 ], [ %46, %38 ]
  %40 = phi i8 [ 0, %29 ], [ %44, %38 ]
  %41 = zext nneg i8 %39 to i16
  %42 = getelementptr i8, ptr %31, i16 %41
  %43 = load i16, ptr %42, align 1, !tbaa !2
  store volatile i16 %43, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %44 = add nuw nsw i8 %40, 1
  %45 = icmp eq i8 %44, 8
  %46 = add nuw nsw i8 %39, 2
  br i1 %45, label %53, label %38, !llvm.loop !114

47:                                               ; preds = %53
  %48 = add nuw nsw i8 %32, 1
  %49 = zext nneg i8 %30 to i16
  %50 = getelementptr i8, ptr %25, i16 %49
  %51 = icmp eq i8 %48, 4
  %52 = add nuw nsw i8 %30, 16
  br i1 %51, label %33, label %29, !llvm.loop !115

53:                                               ; preds = %38, %53
  %54 = phi i8 [ %55, %53 ], [ 0, %38 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %55 = add nuw nsw i8 %54, 1
  %56 = icmp eq i8 %55, 8
  br i1 %56, label %47, label %53, !llvm.loop !116

57:                                               ; preds = %66
  %58 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %59 = load ptr, ptr %58, align 1, !tbaa !65
  %60 = icmp eq ptr %59, null
  br i1 %60, label %79, label %61

61:                                               ; preds = %57
  %62 = load i8, ptr %59, align 1, !tbaa !6
  %63 = icmp eq i8 %62, 0
  br i1 %63, label %79, label %64

64:                                               ; preds = %61
  %65 = getelementptr i8, ptr %59, i16 1
  br label %70

66:                                               ; preds = %28, %66
  %67 = phi i16 [ 0, %28 ], [ %68, %66 ]
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %68 = add nuw nsw i16 %67, 1
  %69 = icmp eq i16 %68, 1024
  br i1 %69, label %57, label %66, !llvm.loop !117

70:                                               ; preds = %64, %70
  %71 = phi i8 [ %72, %70 ], [ 0, %64 ]
  %72 = add nuw nsw i8 %71, 1
  %73 = zext nneg i8 %71 to i16
  %74 = getelementptr i8, ptr %65, i16 %73
  %75 = load i8, ptr %74, align 1, !tbaa !6
  %76 = icmp ne i8 %75, 0
  %77 = icmp samesign ult i8 %71, 31
  %78 = select i1 %76, i1 %77, i1 false
  br i1 %78, label %70, label %79, !llvm.loop !118

79:                                               ; preds = %70, %61, %57
  %80 = phi i8 [ 0, %57 ], [ 0, %61 ], [ %72, %70 ]
  %81 = zext nneg i8 %80 to i16
  %82 = sub nuw nsw i16 32, %81
  %83 = lshr i16 %82, 1
  %84 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %85 = load i16, ptr %84, align 1, !tbaa !71
  %86 = shl i16 %85, 2
  %87 = and i16 %86, -32
  %88 = add i16 %87, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %88, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %89 = trunc nuw nsw i16 %83 to i8
  %90 = add nuw nsw i8 %80, %89
  %91 = sub nsw i16 0, %83
  %92 = getelementptr i8, ptr %59, i16 %91
  br label %105

93:                                               ; preds = %128
  %94 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %95 = load ptr, ptr %94, align 1, !tbaa !67
  %96 = getelementptr inbounds nuw i8, ptr %0, i16 11
  %97 = load i8, ptr %96, align 1, !tbaa !68
  %98 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %99 = load i16, ptr %98, align 1, !tbaa !72
  %100 = lshr i16 %99, 3
  %101 = trunc i16 %100 to i8
  tail call fastcc void @_title_write16(ptr noundef %95, i8 noundef zeroext %97, i8 noundef zeroext %101) #13
  %102 = getelementptr inbounds nuw i8, ptr %0, i16 9
  %103 = load ptr, ptr %102, align 1, !tbaa !69
  %104 = icmp eq ptr %103, null
  br i1 %104, label %139, label %132

105:                                              ; preds = %79, %128
  %106 = phi i8 [ 0, %79 ], [ %130, %128 ]
  %107 = zext nneg i8 %106 to i16
  br i1 %60, label %128, label %108

108:                                              ; preds = %105
  %109 = icmp samesign ugt i16 %83, %107
  br i1 %109, label %128, label %110

110:                                              ; preds = %108
  %111 = icmp ult i8 %106, %90
  br i1 %111, label %112, label %128

112:                                              ; preds = %110
  %113 = getelementptr i8, ptr %92, i16 %107
  %114 = load i8, ptr %113, align 1, !tbaa !6
  %115 = icmp ugt i8 %114, 96
  br i1 %115, label %116, label %120

116:                                              ; preds = %112
  %117 = icmp ult i8 %114, 123
  br i1 %117, label %118, label %128

118:                                              ; preds = %116
  %119 = add nsw i8 %114, -32
  br label %124

120:                                              ; preds = %112
  %121 = icmp samesign ugt i8 %114, 31
  br i1 %121, label %122, label %128

122:                                              ; preds = %120
  %123 = icmp eq i8 %114, 96
  br i1 %123, label %128, label %124

124:                                              ; preds = %122, %118
  %125 = phi i8 [ %119, %118 ], [ %114, %122 ]
  %126 = zext nneg i8 %125 to i16
  %127 = add nuw nsw i16 %126, 7136
  br label %128

128:                                              ; preds = %124, %122, %120, %116, %105, %108, %110
  %129 = phi i16 [ 7168, %105 ], [ 7168, %110 ], [ 7168, %108 ], [ %127, %124 ], [ 7168, %122 ], [ 7168, %120 ], [ 7168, %116 ]
  store volatile i16 %129, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %130 = add nuw nsw i8 %106, 1
  %131 = icmp eq i8 %130, 32
  br i1 %131, label %93, label %105, !llvm.loop !119

132:                                              ; preds = %93
  %133 = getelementptr inbounds nuw i8, ptr %0, i16 12
  %134 = load i8, ptr %133, align 1, !tbaa !70
  %135 = load i16, ptr %98, align 1, !tbaa !72
  %136 = lshr i16 %135, 3
  %137 = trunc i16 %136 to i8
  %138 = add i8 %137, 2
  tail call fastcc void @_title_write16(ptr noundef nonnull %103, i8 noundef zeroext %134, i8 noundef zeroext %138) #13
  br label %139

139:                                              ; preds = %132, %93
  %140 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 -128, ptr %140, align 1, !tbaa !98
  %141 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 3584, ptr %141, align 1, !tbaa !120
  %142 = getelementptr inbounds nuw i8, ptr %0, i16 23
  store i16 0, ptr %142, align 1, !tbaa !121
  %143 = load ptr, ptr %58, align 1, !tbaa !65
  %144 = icmp eq ptr %143, null
  br i1 %144, label %167, label %145

145:                                              ; preds = %139
  %146 = load i8, ptr %143, align 1, !tbaa !6
  %147 = icmp eq i8 %146, 0
  br i1 %147, label %150, label %148

148:                                              ; preds = %145
  %149 = getelementptr i8, ptr %143, i16 1
  br label %158

150:                                              ; preds = %158, %145
  %151 = phi i8 [ 0, %145 ], [ %160, %158 ]
  %152 = zext nneg i8 %151 to i16
  %153 = shl nuw nsw i16 %152, 2
  %154 = sub nuw nsw i16 128, %153
  %155 = and i16 %154, 248
  %156 = add nsw i16 %153, -128
  %157 = add nsw i16 %156, %155
  br label %167

158:                                              ; preds = %158, %148
  %159 = phi i8 [ %160, %158 ], [ 0, %148 ]
  %160 = add nuw nsw i8 %159, 1
  %161 = zext nneg i8 %159 to i16
  %162 = getelementptr i8, ptr %149, i16 %161
  %163 = load i8, ptr %162, align 1, !tbaa !6
  %164 = icmp ne i8 %163, 0
  %165 = icmp samesign ult i8 %159, 31
  %166 = select i1 %164, i1 %165, i1 false
  br i1 %166, label %158, label %150, !llvm.loop !122

167:                                              ; preds = %139, %150
  %168 = phi i16 [ %157, %150 ], [ 0, %139 ]
  %169 = getelementptr inbounds nuw i8, ptr %0, i16 26
  store i16 %168, ptr %169, align 1, !tbaa !123
  store volatile i8 -112, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  %170 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %171 = getelementptr inbounds nuw i8, ptr %0, i16 89
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef -8, i16 noundef 224, ptr noundef nonnull %170, ptr noundef nonnull %171) #13
  %172 = getelementptr inbounds nuw i8, ptr %0, i16 88
  store i8 0, ptr %172, align 1, !tbaa !124
  store volatile i8 2, ptr inttoptr (i16 17200 to ptr), align 16, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 17201 to ptr), align 1, !tbaa !6
  %173 = ptrtoint ptr %170 to i16
  %174 = trunc i16 %173 to i8
  store volatile i8 %174, ptr inttoptr (i16 17202 to ptr), align 2, !tbaa !6
  %175 = lshr i16 %173, 8
  %176 = trunc nuw i16 %175 to i8
  store volatile i8 %176, ptr inttoptr (i16 17203 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17204 to ptr), align 4, !tbaa !6
  %177 = getelementptr inbounds nuw i8, ptr %0, i16 139
  store i8 0, ptr %177, align 1, !tbaa !124
  store volatile i8 2, ptr inttoptr (i16 17216 to ptr), align 64, !tbaa !6
  store volatile i8 15, ptr inttoptr (i16 17217 to ptr), align 1, !tbaa !6
  %178 = ptrtoint ptr %171 to i16
  %179 = trunc i16 %178 to i8
  store volatile i8 %179, ptr inttoptr (i16 17218 to ptr), align 2, !tbaa !6
  %180 = lshr i16 %178, 8
  %181 = trunc nuw i16 %180 to i8
  store volatile i8 %181, ptr inttoptr (i16 17219 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17220 to ptr), align 4, !tbaa !6
  %182 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 2, ptr %182, align 1, !tbaa !64
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal void @_title_emit(ptr noundef %0, ptr noundef captures(none) %1) #6 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 29
  %4 = load i8, ptr %3, align 1, !tbaa !75
  %5 = icmp eq i8 %4, 0
  br i1 %5, label %188, label %6

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 30
  %8 = load i8, ptr %7, align 1, !tbaa !78
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %39, label %10

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 25
  %12 = load i8, ptr %11, align 1, !tbaa !79
  %13 = icmp ugt i8 %12, -6
  br i1 %13, label %16, label %14

14:                                               ; preds = %10
  %15 = add nuw i8 %12, 4
  br label %16

16:                                               ; preds = %10, %14
  %17 = phi i8 [ %15, %14 ], [ -1, %10 ]
  store i8 %17, ptr %11, align 1, !tbaa !79
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %19 = load i16, ptr %18, align 1, !tbaa !71
  %20 = xor i8 %17, -1
  %21 = zext i8 %20 to i16
  %22 = mul nuw i16 %21, %21
  %23 = lshr i16 %22, 8
  %24 = sub nuw nsw i16 256, %23
  %25 = add nsw i16 %19, 8
  %26 = mul nsw i16 %24, %25
  %27 = ashr i16 %26, 4
  %28 = and i16 %27, -16
  %29 = add nsw i16 %28, -128
  %30 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 %29, ptr %30, align 1, !tbaa !98
  %31 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %32 = load i16, ptr %31, align 1, !tbaa !72
  %33 = add nsw i16 %32, -224
  %34 = mul nsw i16 %33, %24
  %35 = ashr i16 %34, 4
  %36 = and i16 %35, -16
  %37 = add nsw i16 %36, 3584
  %38 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 %37, ptr %38, align 1, !tbaa !120
  br label %64

39:                                               ; preds = %6
  %40 = getelementptr inbounds nuw i8, ptr %0, i16 31
  %41 = load i8, ptr %40, align 1, !tbaa !76
  %42 = icmp eq i8 %41, 0
  br i1 %42, label %43, label %48

43:                                               ; preds = %39
  %44 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %45 = load i16, ptr %44, align 1, !tbaa !98
  %46 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %47 = load i16, ptr %46, align 1, !tbaa !120
  br label %64

48:                                               ; preds = %39
  %49 = getelementptr inbounds nuw i8, ptr %0, i16 23
  %50 = load i16, ptr %49, align 1, !tbaa !121
  %51 = add nsw i16 %50, 2
  store i16 %51, ptr %49, align 1, !tbaa !121
  %52 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %53 = load i16, ptr %52, align 1, !tbaa !98
  %54 = add nsw i16 %53, %51
  store i16 %54, ptr %52, align 1, !tbaa !98
  %55 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %56 = load i16, ptr %55, align 1, !tbaa !120
  %57 = add nsw i16 %56, %51
  store i16 %57, ptr %55, align 1, !tbaa !120
  %58 = icmp sgt i16 %54, 4480
  br i1 %58, label %59, label %60

59:                                               ; preds = %48
  store i16 4480, ptr %52, align 1, !tbaa !98
  br label %60

60:                                               ; preds = %59, %48
  %61 = phi i16 [ 4480, %59 ], [ %54, %48 ]
  %62 = icmp sgt i16 %57, 4736
  br i1 %62, label %63, label %64

63:                                               ; preds = %60
  store i16 4736, ptr %55, align 1, !tbaa !120
  br label %64

64:                                               ; preds = %43, %63, %60, %16
  %65 = phi i16 [ %47, %43 ], [ 4736, %63 ], [ %57, %60 ], [ %37, %16 ]
  %66 = phi i16 [ %45, %43 ], [ %61, %63 ], [ %61, %60 ], [ %29, %16 ]
  %67 = ashr i16 %66, 4
  %68 = ashr i16 %65, 4
  %69 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %70 = getelementptr inbounds nuw i8, ptr %0, i16 88
  %71 = load i8, ptr %70, align 1, !tbaa !124
  %72 = xor i8 %71, 1
  %73 = zext i8 %72 to i16
  %74 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %73
  %75 = getelementptr inbounds nuw i8, ptr %0, i16 89
  %76 = getelementptr inbounds nuw i8, ptr %0, i16 139
  %77 = load i8, ptr %76, align 1, !tbaa !124
  %78 = xor i8 %77, 1
  %79 = zext i8 %78 to i16
  %80 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %79
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef %67, i16 noundef %68, ptr noundef nonnull %74, ptr noundef nonnull %80) #13
  %81 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %82 = load i8, ptr %81, align 1, !tbaa !44
  %83 = icmp ugt i8 %82, 15
  br i1 %83, label %109, label %84

84:                                               ; preds = %64
  %85 = load i8, ptr %70, align 1, !tbaa !124
  %86 = xor i8 %85, 1
  %87 = zext i8 %86 to i16
  %88 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %87
  %89 = ptrtoint ptr %88 to i16
  %90 = zext nneg i8 %82 to i16
  %91 = add nuw nsw i8 %82, 1
  store i8 %91, ptr %81, align 1, !tbaa !44
  %92 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %90
  %93 = getelementptr inbounds nuw i8, ptr %92, i16 10
  store i8 4, ptr %93, align 1, !tbaa !45
  store i16 17202, ptr %92, align 1, !tbaa !47
  %94 = getelementptr inbounds nuw i8, ptr %92, i16 2
  store i16 %89, ptr %94, align 1, !tbaa !51
  %95 = getelementptr inbounds nuw i8, ptr %92, i16 4
  store i16 0, ptr %95, align 1, !tbaa !53
  store i8 %86, ptr %70, align 1, !tbaa !124
  %96 = icmp eq i8 %82, 15
  br i1 %96, label %109, label %97

97:                                               ; preds = %84
  %98 = load i8, ptr %76, align 1, !tbaa !124
  %99 = xor i8 %98, 1
  %100 = zext i8 %99 to i16
  %101 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %100
  %102 = ptrtoint ptr %101 to i16
  %103 = zext nneg i8 %91 to i16
  %104 = add nuw nsw i8 %82, 2
  store i8 %104, ptr %81, align 1, !tbaa !44
  %105 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %103
  %106 = getelementptr inbounds nuw i8, ptr %105, i16 10
  store i8 4, ptr %106, align 1, !tbaa !45
  store i16 17218, ptr %105, align 1, !tbaa !47
  %107 = getelementptr inbounds nuw i8, ptr %105, i16 2
  store i16 %102, ptr %107, align 1, !tbaa !51
  %108 = getelementptr inbounds nuw i8, ptr %105, i16 4
  store i16 0, ptr %108, align 1, !tbaa !53
  store i8 %99, ptr %76, align 1, !tbaa !124
  br label %109

109:                                              ; preds = %64, %84, %97
  %110 = phi i8 [ %82, %64 ], [ 16, %84 ], [ %104, %97 ]
  %111 = getelementptr inbounds nuw i8, ptr %0, i16 28
  %112 = load i8, ptr %111, align 1, !tbaa !74
  %113 = add i8 %112, 1
  store i8 %113, ptr %111, align 1, !tbaa !74
  %114 = getelementptr inbounds nuw i8, ptr %0, i16 32
  %115 = load i8, ptr %114, align 1, !tbaa !77
  %116 = icmp eq i8 %115, 0
  br i1 %116, label %117, label %155

117:                                              ; preds = %109
  %118 = shl i8 %113, 1
  %119 = icmp sgt i8 %118, -1
  br i1 %119, label %122, label %120

120:                                              ; preds = %117
  %121 = xor i8 %118, -1
  br label %122

122:                                              ; preds = %117, %120
  %123 = phi i8 [ %121, %120 ], [ %118, %117 ]
  %124 = lshr i8 %123, 4
  %125 = add nuw nsw i8 %124, 24
  %126 = zext nneg i8 %125 to i16
  %127 = mul nuw nsw i16 %126, 1057
  %128 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 %127, ptr %128, align 1, !tbaa !80
  %129 = add i8 %118, -86
  %130 = icmp sgt i8 %129, -1
  br i1 %130, label %133, label %131

131:                                              ; preds = %122
  %132 = sub nsw i8 85, %118
  br label %133

133:                                              ; preds = %122, %131
  %134 = phi i8 [ %132, %131 ], [ %129, %122 ]
  %135 = lshr i8 %134, 2
  %136 = zext nneg i8 %135 to i16
  %137 = shl nuw nsw i16 %136, 10
  %138 = add i8 %118, 85
  %139 = icmp sgt i8 %138, -1
  br i1 %139, label %142, label %140

140:                                              ; preds = %133
  %141 = sub nuw i8 -86, %118
  br label %142

142:                                              ; preds = %133, %140
  %143 = phi i8 [ %141, %140 ], [ %138, %133 ]
  %144 = lshr i8 %143, 2
  %145 = zext nneg i8 %144 to i16
  %146 = shl nuw nsw i16 %145, 5
  %147 = add nuw nsw i16 %146, %137
  br i1 %119, label %150, label %148

148:                                              ; preds = %142
  %149 = xor i8 %118, -1
  br label %150

150:                                              ; preds = %142, %148
  %151 = phi i8 [ %149, %148 ], [ %118, %142 ]
  %152 = lshr i8 %151, 2
  %153 = zext nneg i8 %152 to i16
  %154 = add nuw nsw i16 %147, %153
  br label %157

155:                                              ; preds = %109
  %156 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 29596, ptr %156, align 1, !tbaa !80
  br label %157

157:                                              ; preds = %155, %150
  %158 = phi i16 [ 0, %155 ], [ %154, %150 ]
  %159 = getelementptr inbounds nuw i8, ptr %0, i16 36
  store i16 %158, ptr %159, align 1, !tbaa !81
  %160 = icmp ugt i8 %110, 15
  br i1 %160, label %188, label %161

161:                                              ; preds = %157
  %162 = getelementptr inbounds nuw i8, ptr %0, i16 34
  %163 = zext nneg i8 %110 to i16
  %164 = add nuw nsw i8 %110, 1
  store i8 %164, ptr %81, align 1, !tbaa !44
  %165 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %163
  %166 = getelementptr inbounds nuw i8, ptr %165, i16 10
  store i8 1, ptr %166, align 1, !tbaa !45
  store i16 113, ptr %165, align 1, !tbaa !47
  %167 = getelementptr inbounds nuw i8, ptr %165, i16 9
  store i8 0, ptr %167, align 1, !tbaa !48
  %168 = getelementptr inbounds nuw i8, ptr %165, i16 7
  store i8 34, ptr %168, align 1, !tbaa !49
  %169 = getelementptr inbounds nuw i8, ptr %165, i16 8
  store i8 0, ptr %169, align 1, !tbaa !50
  %170 = ptrtoint ptr %162 to i16
  %171 = getelementptr inbounds nuw i8, ptr %165, i16 2
  store i16 %170, ptr %171, align 1, !tbaa !51
  %172 = getelementptr inbounds nuw i8, ptr %165, i16 6
  store i8 0, ptr %172, align 1, !tbaa !52
  %173 = getelementptr inbounds nuw i8, ptr %165, i16 4
  store i16 2, ptr %173, align 1, !tbaa !53
  %174 = icmp eq i8 %110, 15
  br i1 %174, label %188, label %175

175:                                              ; preds = %161
  %176 = getelementptr inbounds nuw i8, ptr %0, i16 36
  %177 = zext nneg i8 %164 to i16
  %178 = add nuw nsw i8 %110, 2
  store i8 %178, ptr %81, align 1, !tbaa !44
  %179 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %177
  %180 = getelementptr inbounds nuw i8, ptr %179, i16 10
  store i8 1, ptr %180, align 1, !tbaa !45
  store i16 0, ptr %179, align 1, !tbaa !47
  %181 = getelementptr inbounds nuw i8, ptr %179, i16 9
  store i8 0, ptr %181, align 1, !tbaa !48
  %182 = getelementptr inbounds nuw i8, ptr %179, i16 7
  store i8 34, ptr %182, align 1, !tbaa !49
  %183 = getelementptr inbounds nuw i8, ptr %179, i16 8
  store i8 0, ptr %183, align 1, !tbaa !50
  %184 = ptrtoint ptr %176 to i16
  %185 = getelementptr inbounds nuw i8, ptr %179, i16 2
  store i16 %184, ptr %185, align 1, !tbaa !51
  %186 = getelementptr inbounds nuw i8, ptr %179, i16 6
  store i8 0, ptr %186, align 1, !tbaa !52
  %187 = getelementptr inbounds nuw i8, ptr %179, i16 4
  store i16 2, ptr %187, align 1, !tbaa !53
  br label %188

188:                                              ; preds = %157, %175, %161, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @_title_write16(ptr noundef readonly captures(address_is_null) %0, i8 noundef zeroext %1, i8 noundef zeroext %2) unnamed_addr #3 {
  %4 = zext i8 %1 to i16
  %5 = shl nuw nsw i16 %4, 1
  %6 = and i16 %5, 254
  %7 = sub nsw i16 32, %6
  %8 = lshr exact i16 %7, 1
  %9 = zext i8 %2 to i16
  %10 = icmp eq ptr %0, null
  %11 = and i16 %8, 255
  %12 = add nuw i16 %8, %5
  %13 = and i16 %12, 255
  br label %15

14:                                               ; preds = %23
  ret void

15:                                               ; preds = %3, %23
  %16 = phi i1 [ true, %3 ], [ false, %23 ]
  %17 = phi i8 [ 0, %3 ], [ 1, %23 ]
  %18 = zext nneg i8 %17 to i16
  %19 = add nuw nsw i16 %18, %9
  %20 = shl nuw nsw i16 %19, 5
  %21 = add nuw nsw i16 %20, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %21, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %22 = select i1 %16, i16 7168, i16 7170
  br label %24

23:                                               ; preds = %56
  br i1 %16, label %15, label %14, !llvm.loop !125

24:                                               ; preds = %15, %56
  %25 = phi i8 [ 0, %15 ], [ %58, %56 ]
  %26 = zext nneg i8 %25 to i16
  br i1 %10, label %56, label %27

27:                                               ; preds = %24
  %28 = icmp samesign ugt i16 %11, %26
  br i1 %28, label %56, label %29

29:                                               ; preds = %27
  %30 = icmp samesign ugt i16 %13, %26
  br i1 %30, label %31, label %56

31:                                               ; preds = %29
  %32 = sub nsw i16 %26, %11
  %33 = lshr i16 %32, 1
  %34 = and i16 %33, 255
  %35 = getelementptr inbounds nuw i8, ptr %0, i16 %34
  %36 = load i8, ptr %35, align 1, !tbaa !6
  %37 = icmp ugt i8 %36, 96
  br i1 %37, label %38, label %42

38:                                               ; preds = %31
  %39 = icmp ult i8 %36, 123
  br i1 %39, label %40, label %51

40:                                               ; preds = %38
  %41 = add nsw i8 %36, -32
  br label %46

42:                                               ; preds = %31
  %43 = icmp samesign ugt i8 %36, 31
  br i1 %43, label %44, label %51

44:                                               ; preds = %42
  %45 = icmp eq i8 %36, 96
  br i1 %45, label %51, label %46

46:                                               ; preds = %44, %40
  %47 = phi i8 [ %41, %40 ], [ %36, %44 ]
  %48 = zext nneg i8 %47 to i16
  %49 = shl nuw nsw i16 %48, 2
  %50 = add nsw i16 %49, -64
  br label %51

51:                                               ; preds = %38, %42, %44, %46
  %52 = phi i16 [ %50, %46 ], [ 64, %44 ], [ 64, %42 ], [ 64, %38 ]
  %53 = and i16 %32, 1
  %54 = or disjoint i16 %22, %53
  %55 = or disjoint i16 %54, %52
  br label %56

56:                                               ; preds = %51, %29, %27, %24
  %57 = phi i16 [ %55, %51 ], [ 7168, %29 ], [ 7168, %27 ], [ 7168, %24 ]
  store volatile i16 %57, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %58 = add nuw nsw i8 %25, 1
  %59 = icmp eq i8 %58, 32
  br i1 %59, label %23, label %24, !llvm.loop !126
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_build(ptr noundef readonly captures(none) %0, i16 noundef range(i16 -2048, 2048) %1, i16 noundef range(i16 -2048, 2048) %2, ptr noundef %3, ptr noundef %4) unnamed_addr #6 {
  %6 = alloca %struct.HScrollW, align 1
  %7 = alloca %struct.HScrollW, align 1
  %8 = alloca i16, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #14
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #14
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #14
  store i16 0, ptr %8, align 1, !tbaa !2
  store ptr %3, ptr %6, align 1, !tbaa !127
  %9 = getelementptr inbounds nuw i8, ptr %6, i16 2
  store i8 0, ptr %9, align 1, !tbaa !129
  store ptr %4, ptr %7, align 1, !tbaa !127
  %10 = getelementptr inbounds nuw i8, ptr %7, i16 2
  store i8 0, ptr %10, align 1, !tbaa !129
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %12 = load i16, ptr %11, align 1, !tbaa !71
  %13 = getelementptr inbounds nuw i8, ptr %0, i16 26
  %14 = load i16, ptr %13, align 1, !tbaa !123
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %1, i16 noundef 8, i16 noundef %12, i16 noundef %14) #13
  %15 = getelementptr inbounds nuw i8, ptr %0, i16 17
  %16 = load i16, ptr %15, align 1, !tbaa !73
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %18 = load i16, ptr %17, align 1, !tbaa !72
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %2, i16 noundef %16, i16 noundef %18, i16 noundef 0) #13
  %19 = load i16, ptr %8, align 1, !tbaa !2
  call fastcc void @_title_blank(ptr noundef %6, ptr noundef %7, i16 noundef %19, i16 noundef 224) #13
  %20 = load ptr, ptr %6, align 1, !tbaa !127
  %21 = load i8, ptr %9, align 1, !tbaa !129
  %22 = zext i8 %21 to i16
  %23 = getelementptr inbounds nuw i8, ptr %20, i16 %22
  store i8 0, ptr %23, align 1, !tbaa !6
  %24 = load ptr, ptr %7, align 1, !tbaa !127
  %25 = load i8, ptr %10, align 1, !tbaa !129
  %26 = zext i8 %25 to i16
  %27 = getelementptr inbounds nuw i8, ptr %24, i16 %26
  store i8 0, ptr %27, align 1, !tbaa !6
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #14
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #14
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #14
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_glyph_band(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, ptr noundef nonnull captures(none) %2, i16 noundef range(i16 -2048, 2048) %3, i16 noundef %4, i16 noundef %5, i16 noundef %6) unnamed_addr #6 {
  %8 = add nsw i16 %3, -2
  %9 = add nsw i16 %4, %3
  %10 = add nsw i16 %9, 2
  %11 = load i16, ptr %2, align 1, !tbaa !2
  %12 = icmp slt i16 %8, %11
  br i1 %12, label %13, label %14

13:                                               ; preds = %7
  br label %14

14:                                               ; preds = %13, %7
  %15 = phi i16 [ %11, %13 ], [ %8, %7 ]
  %16 = icmp sgt i16 %9, 222
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  br label %18

18:                                               ; preds = %17, %14
  %19 = phi i16 [ 224, %17 ], [ %10, %14 ]
  %20 = icmp sgt i16 %19, %15
  br i1 %20, label %21, label %92

21:                                               ; preds = %18
  tail call fastcc void @_title_blank(ptr noundef %0, ptr noundef %1, i16 noundef %11, i16 noundef %15) #13
  %22 = sub nsw i16 %19, %15
  %23 = trunc i16 %22 to i8
  %24 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %25 = icmp eq i8 %23, 0
  br i1 %25, label %91, label %26

26:                                               ; preds = %21
  %27 = sub nsw i16 %5, %3
  %28 = and i16 %22, 255
  %29 = trunc i16 %27 to i8
  %30 = lshr i16 %27, 8
  %31 = trunc nuw i16 %30 to i8
  br label %32

32:                                               ; preds = %40, %26
  %33 = phi i16 [ %28, %26 ], [ %57, %40 ]
  %34 = load i8, ptr %24, align 1, !tbaa !129
  %35 = icmp ult i8 %34, 22
  br i1 %35, label %36, label %59

36:                                               ; preds = %32
  %37 = icmp ugt i16 %33, 127
  br i1 %37, label %40, label %38

38:                                               ; preds = %36
  %39 = trunc nuw nsw i16 %33 to i8
  br label %40

40:                                               ; preds = %38, %36
  %41 = phi i8 [ %39, %38 ], [ 127, %36 ]
  %42 = load ptr, ptr %0, align 1, !tbaa !127
  %43 = add nuw nsw i8 %34, 1
  store i8 %43, ptr %24, align 1, !tbaa !129
  %44 = zext nneg i8 %34 to i16
  %45 = getelementptr inbounds nuw i8, ptr %42, i16 %44
  store i8 %41, ptr %45, align 1, !tbaa !6
  %46 = load ptr, ptr %0, align 1, !tbaa !127
  %47 = load i8, ptr %24, align 1, !tbaa !129
  %48 = add i8 %47, 1
  store i8 %48, ptr %24, align 1, !tbaa !129
  %49 = zext i8 %47 to i16
  %50 = getelementptr inbounds nuw i8, ptr %46, i16 %49
  store i8 %29, ptr %50, align 1, !tbaa !6
  %51 = load ptr, ptr %0, align 1, !tbaa !127
  %52 = load i8, ptr %24, align 1, !tbaa !129
  %53 = add i8 %52, 1
  store i8 %53, ptr %24, align 1, !tbaa !129
  %54 = zext i8 %52 to i16
  %55 = getelementptr inbounds nuw i8, ptr %51, i16 %54
  store i8 %31, ptr %55, align 1, !tbaa !6
  %56 = zext nneg i8 %41 to i16
  %57 = sub i16 %33, %56
  %58 = icmp eq i16 %57, 0
  br i1 %58, label %59, label %32, !llvm.loop !130

59:                                               ; preds = %32, %40
  %60 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %61 = trunc i16 %6 to i8
  %62 = lshr i16 %6, 8
  %63 = trunc nuw i16 %62 to i8
  br label %64

64:                                               ; preds = %72, %59
  %65 = phi i16 [ %28, %59 ], [ %89, %72 ]
  %66 = load i8, ptr %60, align 1, !tbaa !129
  %67 = icmp ult i8 %66, 22
  br i1 %67, label %68, label %91

68:                                               ; preds = %64
  %69 = icmp ugt i16 %65, 127
  br i1 %69, label %72, label %70

70:                                               ; preds = %68
  %71 = trunc nuw nsw i16 %65 to i8
  br label %72

72:                                               ; preds = %70, %68
  %73 = phi i8 [ %71, %70 ], [ 127, %68 ]
  %74 = load ptr, ptr %1, align 1, !tbaa !127
  %75 = add nuw nsw i8 %66, 1
  store i8 %75, ptr %60, align 1, !tbaa !129
  %76 = zext nneg i8 %66 to i16
  %77 = getelementptr inbounds nuw i8, ptr %74, i16 %76
  store i8 %73, ptr %77, align 1, !tbaa !6
  %78 = load ptr, ptr %1, align 1, !tbaa !127
  %79 = load i8, ptr %60, align 1, !tbaa !129
  %80 = add i8 %79, 1
  store i8 %80, ptr %60, align 1, !tbaa !129
  %81 = zext i8 %79 to i16
  %82 = getelementptr inbounds nuw i8, ptr %78, i16 %81
  store i8 %61, ptr %82, align 1, !tbaa !6
  %83 = load ptr, ptr %1, align 1, !tbaa !127
  %84 = load i8, ptr %60, align 1, !tbaa !129
  %85 = add i8 %84, 1
  store i8 %85, ptr %60, align 1, !tbaa !129
  %86 = zext i8 %84 to i16
  %87 = getelementptr inbounds nuw i8, ptr %83, i16 %86
  store i8 %63, ptr %87, align 1, !tbaa !6
  %88 = zext nneg i8 %73 to i16
  %89 = sub i16 %65, %88
  %90 = icmp eq i16 %89, 0
  br i1 %90, label %91, label %64, !llvm.loop !130

91:                                               ; preds = %64, %72, %21
  store i16 %19, ptr %2, align 1, !tbaa !2
  br label %92

92:                                               ; preds = %18, %91
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_blank(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, i16 noundef %2, i16 noundef range(i16 -2050, 225) %3) unnamed_addr #6 {
  %5 = icmp sgt i16 %3, %2
  br i1 %5, label %6, label %83

6:                                                ; preds = %4
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 2
  br label %9

9:                                                ; preds = %6, %79
  %10 = phi i16 [ %2, %6 ], [ %81, %79 ]
  %11 = sub nsw i16 %3, %10
  %12 = icmp sgt i16 %11, 112
  br i1 %12, label %16, label %13

13:                                               ; preds = %9
  %14 = trunc i16 %11 to i8
  %15 = icmp eq i8 %14, 0
  br i1 %15, label %79, label %16

16:                                               ; preds = %9, %13
  %17 = phi i8 [ %14, %13 ], [ 112, %9 ]
  %18 = phi i16 [ %11, %13 ], [ 112, %9 ]
  %19 = sub nsw i16 144, %10
  %20 = zext i8 %17 to i16
  %21 = trunc i16 %19 to i8
  %22 = lshr i16 %19, 8
  %23 = trunc nuw i16 %22 to i8
  br label %24

24:                                               ; preds = %32, %16
  %25 = phi i16 [ %20, %16 ], [ %49, %32 ]
  %26 = load i8, ptr %7, align 1, !tbaa !129
  %27 = icmp ult i8 %26, 22
  br i1 %27, label %28, label %51

28:                                               ; preds = %24
  %29 = icmp ugt i16 %25, 127
  br i1 %29, label %32, label %30

30:                                               ; preds = %28
  %31 = trunc nuw nsw i16 %25 to i8
  br label %32

32:                                               ; preds = %30, %28
  %33 = phi i8 [ %31, %30 ], [ 127, %28 ]
  %34 = load ptr, ptr %0, align 1, !tbaa !127
  %35 = add nuw nsw i8 %26, 1
  store i8 %35, ptr %7, align 1, !tbaa !129
  %36 = zext nneg i8 %26 to i16
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 %36
  store i8 %33, ptr %37, align 1, !tbaa !6
  %38 = load ptr, ptr %0, align 1, !tbaa !127
  %39 = load i8, ptr %7, align 1, !tbaa !129
  %40 = add i8 %39, 1
  store i8 %40, ptr %7, align 1, !tbaa !129
  %41 = zext i8 %39 to i16
  %42 = getelementptr inbounds nuw i8, ptr %38, i16 %41
  store i8 %21, ptr %42, align 1, !tbaa !6
  %43 = load ptr, ptr %0, align 1, !tbaa !127
  %44 = load i8, ptr %7, align 1, !tbaa !129
  %45 = add i8 %44, 1
  store i8 %45, ptr %7, align 1, !tbaa !129
  %46 = zext i8 %44 to i16
  %47 = getelementptr inbounds nuw i8, ptr %43, i16 %46
  store i8 %23, ptr %47, align 1, !tbaa !6
  %48 = zext nneg i8 %33 to i16
  %49 = sub i16 %25, %48
  %50 = icmp eq i16 %49, 0
  br i1 %50, label %51, label %24, !llvm.loop !130

51:                                               ; preds = %24, %32
  br label %52

52:                                               ; preds = %51, %60
  %53 = phi i16 [ %77, %60 ], [ %20, %51 ]
  %54 = load i8, ptr %8, align 1, !tbaa !129
  %55 = icmp ult i8 %54, 22
  br i1 %55, label %56, label %79

56:                                               ; preds = %52
  %57 = icmp ugt i16 %53, 127
  br i1 %57, label %60, label %58

58:                                               ; preds = %56
  %59 = trunc nuw nsw i16 %53 to i8
  br label %60

60:                                               ; preds = %58, %56
  %61 = phi i8 [ %59, %58 ], [ 127, %56 ]
  %62 = load ptr, ptr %1, align 1, !tbaa !127
  %63 = add nuw nsw i8 %54, 1
  store i8 %63, ptr %8, align 1, !tbaa !129
  %64 = zext nneg i8 %54 to i16
  %65 = getelementptr inbounds nuw i8, ptr %62, i16 %64
  store i8 %61, ptr %65, align 1, !tbaa !6
  %66 = load ptr, ptr %1, align 1, !tbaa !127
  %67 = load i8, ptr %8, align 1, !tbaa !129
  %68 = add i8 %67, 1
  store i8 %68, ptr %8, align 1, !tbaa !129
  %69 = zext i8 %67 to i16
  %70 = getelementptr inbounds nuw i8, ptr %66, i16 %69
  store i8 0, ptr %70, align 1, !tbaa !6
  %71 = load ptr, ptr %1, align 1, !tbaa !127
  %72 = load i8, ptr %8, align 1, !tbaa !129
  %73 = add i8 %72, 1
  store i8 %73, ptr %8, align 1, !tbaa !129
  %74 = zext i8 %72 to i16
  %75 = getelementptr inbounds nuw i8, ptr %71, i16 %74
  store i8 0, ptr %75, align 1, !tbaa !6
  %76 = zext nneg i8 %61 to i16
  %77 = sub i16 %53, %76
  %78 = icmp eq i16 %77, 0
  br i1 %78, label %79, label %52, !llvm.loop !130

79:                                               ; preds = %52, %60, %13
  %80 = phi i16 [ %11, %13 ], [ %18, %60 ], [ %18, %52 ]
  %81 = add nsw i16 %80, %10
  %82 = icmp sgt i16 %3, %81
  br i1 %82, label %9, label %83, !llvm.loop !131

83:                                               ; preds = %79, %4
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(argmem: readwrite)
define internal fastcc zeroext range(i8 1, 0) i8 @hl_giftwrap(ptr noundef readonly captures(none) %0, ptr noundef writeonly captures(none) %1) unnamed_addr #5 {
  %3 = getelementptr nuw i8, ptr %0, i16 4
  %4 = getelementptr i8, ptr %0, i16 6
  br label %7

5:                                                ; preds = %27
  %6 = getelementptr i8, ptr %0, i16 2
  br label %32

7:                                                ; preds = %2, %27
  %8 = phi i8 [ 0, %2 ], [ %31, %27 ]
  %9 = phi i8 [ 0, %2 ], [ %28, %27 ]
  %10 = phi i8 [ 1, %2 ], [ %29, %27 ]
  %11 = zext nneg i8 %8 to i16
  %12 = getelementptr i8, ptr %3, i16 %11
  %13 = load i16, ptr %12, align 1, !tbaa !57
  %14 = zext i8 %9 to i16
  %15 = getelementptr inbounds nuw [4 x i8], ptr %0, i16 %14
  %16 = load i16, ptr %15, align 1, !tbaa !57
  %17 = icmp slt i16 %13, %16
  br i1 %17, label %26, label %18

18:                                               ; preds = %7
  %19 = icmp eq i16 %13, %16
  br i1 %19, label %20, label %27

20:                                               ; preds = %18
  %21 = getelementptr i8, ptr %4, i16 %11
  %22 = load i16, ptr %21, align 1, !tbaa !58
  %23 = getelementptr inbounds nuw i8, ptr %15, i16 2
  %24 = load i16, ptr %23, align 1, !tbaa !58
  %25 = icmp slt i16 %22, %24
  br i1 %25, label %26, label %27

26:                                               ; preds = %20, %7
  br label %27

27:                                               ; preds = %18, %20, %26
  %28 = phi i8 [ %10, %26 ], [ %9, %20 ], [ %9, %18 ]
  %29 = add nuw nsw i8 %10, 1
  %30 = icmp eq i8 %29, 14
  %31 = add nuw nsw i8 %8, 4
  br i1 %30, label %5, label %7, !llvm.loop !132

32:                                               ; preds = %43, %5
  %33 = phi i8 [ %100, %43 ], [ %28, %5 ]
  %34 = phi i8 [ %44, %43 ], [ 0, %5 ]
  %35 = zext nneg i8 %34 to i16
  %36 = getelementptr i8, ptr %1, i16 %35
  store i8 %33, ptr %36, align 1, !tbaa !6
  %37 = zext i8 %33 to i16
  %38 = add nuw nsw i16 %37, 1
  %39 = urem i16 %38, 14
  %40 = trunc nuw nsw i16 %39 to i8
  %41 = getelementptr inbounds nuw [4 x i8], ptr %0, i16 %37
  %42 = getelementptr inbounds nuw i8, ptr %41, i16 2
  br label %48

43:                                               ; preds = %99
  %44 = add nuw nsw i8 %34, 1
  %45 = icmp ne i8 %100, %28
  %46 = icmp samesign ult i8 %34, 13
  %47 = select i1 %45, i1 %46, i1 false
  br i1 %47, label %32, label %104, !llvm.loop !133

48:                                               ; preds = %32, %99
  %49 = phi i8 [ 0, %32 ], [ %103, %99 ]
  %50 = phi i8 [ 0, %32 ], [ %101, %99 ]
  %51 = phi i8 [ %40, %32 ], [ %100, %99 ]
  %52 = icmp eq i8 %50, %33
  br i1 %52, label %99, label %53

53:                                               ; preds = %48
  %54 = zext i8 %51 to i16
  %55 = getelementptr inbounds nuw [4 x i8], ptr %0, i16 %54
  %56 = zext nneg i8 %49 to i16
  %57 = getelementptr i8, ptr %0, i16 %56
  %58 = load i16, ptr %41, align 1
  %59 = load i16, ptr %42, align 1
  %60 = load i16, ptr %55, align 1
  %61 = getelementptr inbounds nuw i8, ptr %55, i16 2
  %62 = load i16, ptr %61, align 1
  %63 = load i16, ptr %57, align 1
  %64 = getelementptr i8, ptr %6, i16 %56
  %65 = load i16, ptr %64, align 1
  %66 = sext i16 %60 to i32
  %67 = sext i16 %58 to i32
  %68 = sub nsw i32 %66, %67
  %69 = sext i16 %62 to i32
  %70 = sext i16 %59 to i32
  %71 = sub nsw i32 %69, %70
  %72 = sext i16 %63 to i32
  %73 = sub nsw i32 %67, %72
  %74 = sext i16 %65 to i32
  %75 = sub nsw i32 %74, %70
  %76 = mul nsw i32 %75, %68
  %77 = mul i32 %73, %71
  %78 = add i32 %76, %77
  %79 = icmp slt i32 %78, 0
  br i1 %79, label %99, label %80

80:                                               ; preds = %53
  %81 = icmp eq i32 %78, 0
  br i1 %81, label %82, label %99

82:                                               ; preds = %80
  %83 = sub nsw i16 %60, %58
  %84 = sext i16 %83 to i32
  %85 = mul nsw i32 %84, %84
  %86 = sub nsw i16 %62, %59
  %87 = sext i16 %86 to i32
  %88 = mul nsw i32 %87, %87
  %89 = add nuw nsw i32 %88, %85
  %90 = sub nsw i16 %63, %58
  %91 = sext i16 %90 to i32
  %92 = mul nsw i32 %91, %91
  %93 = sub nsw i16 %65, %59
  %94 = sext i16 %93 to i32
  %95 = mul nsw i32 %94, %94
  %96 = add nuw nsw i32 %95, %92
  %97 = icmp samesign ugt i32 %96, %89
  br i1 %97, label %98, label %99

98:                                               ; preds = %82
  br label %99

99:                                               ; preds = %80, %53, %98, %82, %48
  %100 = phi i8 [ %51, %48 ], [ %51, %80 ], [ %50, %53 ], [ %50, %98 ], [ %51, %82 ]
  %101 = add nuw nsw i8 %50, 1
  %102 = icmp eq i8 %101, 14
  %103 = add nuw nsw i8 %49, 4
  br i1 %102, label %43, label %48, !llvm.loop !134

104:                                              ; preds = %43
  ret i8 %44
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #7

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none)
define internal fastcc void @canvas_line(i16 noundef %0, i16 noundef %1, i16 noundef %2, i16 noundef %3) unnamed_addr #8 {
  %5 = icmp sgt i16 %2, %0
  br i1 %5, label %6, label %8

6:                                                ; preds = %4
  %7 = sub nsw i16 %2, %0
  br label %10

8:                                                ; preds = %4
  %9 = sub nsw i16 %0, %2
  br label %10

10:                                               ; preds = %8, %6
  %11 = phi i16 [ %7, %6 ], [ %9, %8 ]
  %12 = icmp sgt i16 %3, %1
  br i1 %12, label %13, label %15

13:                                               ; preds = %10
  %14 = sub nsw i16 %3, %1
  br label %17

15:                                               ; preds = %10
  %16 = sub nsw i16 %1, %3
  br label %17

17:                                               ; preds = %15, %13
  %18 = phi i16 [ 1, %13 ], [ -1, %15 ]
  %19 = phi i16 [ %14, %13 ], [ %16, %15 ]
  %20 = select i1 %5, i16 1, i16 -1
  %21 = sub nsw i16 %11, %19
  %22 = sub nsw i16 0, %19
  br label %23

23:                                               ; preds = %69, %17
  %24 = phi i16 [ %71, %69 ], [ %1, %17 ]
  %25 = phi i16 [ %70, %69 ], [ %21, %17 ]
  %26 = phi i16 [ %67, %69 ], [ %0, %17 ]
  %27 = icmp ugt i16 %24, 127
  %28 = shl nuw nsw i16 %24, 1
  %29 = and i16 %28, 240
  %30 = and i16 %28, 14
  %31 = getelementptr inbounds i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %30
  %32 = icmp eq i16 %24, %3
  br label %33

33:                                               ; preds = %23, %65
  %34 = phi i16 [ %66, %65 ], [ %25, %23 ]
  %35 = phi i16 [ %67, %65 ], [ %26, %23 ]
  %36 = icmp ugt i16 %35, 127
  %37 = select i1 %36, i1 true, i1 %27
  br i1 %37, label %56, label %38

38:                                               ; preds = %33
  %39 = lshr i16 %35, 3
  %40 = or disjoint i16 %39, %29
  %41 = shl nuw nsw i16 %40, 4
  %42 = getelementptr inbounds i8, ptr %31, i16 %41
  %43 = and i16 %35, 7
  %44 = lshr exact i16 128, %43
  %45 = getelementptr inbounds nuw i8, ptr %42, i16 1
  %46 = load i8, ptr %45, align 1, !tbaa !6
  %47 = trunc nuw i16 %44 to i8
  %48 = or i8 %46, %47
  store i8 %48, ptr %45, align 1, !tbaa !6
  %49 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %50 = icmp ult i16 %40, %49
  br i1 %50, label %51, label %52

51:                                               ; preds = %38
  store i16 %40, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %52

52:                                               ; preds = %51, %38
  %53 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %54 = icmp ugt i16 %40, %53
  br i1 %54, label %55, label %56

55:                                               ; preds = %52
  store i16 %40, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %56

56:                                               ; preds = %33, %52, %55
  %57 = icmp eq i16 %35, %2
  %58 = select i1 %57, i1 %32, i1 false
  br i1 %58, label %72, label %59

59:                                               ; preds = %56
  %60 = shl nsw i16 %34, 1
  %61 = icmp sgt i16 %60, %22
  br i1 %61, label %62, label %65

62:                                               ; preds = %59
  %63 = sub nsw i16 %34, %19
  %64 = add nsw i16 %35, %20
  br label %65

65:                                               ; preds = %62, %59
  %66 = phi i16 [ %63, %62 ], [ %34, %59 ]
  %67 = phi i16 [ %64, %62 ], [ %35, %59 ]
  %68 = icmp slt i16 %60, %11
  br i1 %68, label %69, label %33

69:                                               ; preds = %65
  %70 = add nsw i16 %66, %11
  %71 = add nsw i16 %24, %18
  br label %23

72:                                               ; preds = %56
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @upq_flush() unnamed_addr #9 {
  %1 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 177), align 1, !tbaa !135
  %2 = zext i8 %1 to i16
  %3 = shl nuw nsw i16 %2, 4
  %4 = add nuw nsw i16 %3, 17152
  %5 = inttoptr i16 %4 to ptr
  %6 = shl nuw i16 1, %2
  %7 = trunc i16 %6 to i8
  %8 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %108, label %10

10:                                               ; preds = %0
  %11 = getelementptr inbounds nuw i8, ptr %5, i16 1
  %12 = getelementptr inbounds nuw i8, ptr %5, i16 2
  %13 = getelementptr inbounds nuw i8, ptr %5, i16 3
  %14 = getelementptr inbounds nuw i8, ptr %5, i16 4
  %15 = getelementptr inbounds nuw i8, ptr %5, i16 5
  %16 = getelementptr inbounds nuw i8, ptr %5, i16 6
  br label %17

17:                                               ; preds = %10, %86
  %18 = phi i8 [ %8, %10 ], [ %89, %86 ]
  %19 = phi i16 [ 0, %10 ], [ %87, %86 ]
  %20 = phi i8 [ 0, %10 ], [ %88, %86 ]
  %21 = zext i8 %20 to i16
  %22 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %21
  %23 = getelementptr inbounds nuw i8, ptr %22, i16 10
  %24 = load i8, ptr %23, align 1, !tbaa !45
  switch i8 %24, label %44 [
    i8 3, label %25
    i8 4, label %34
  ]

25:                                               ; preds = %17
  %26 = load i16, ptr %22, align 1, !tbaa !47
  %27 = inttoptr i16 %26 to ptr
  %28 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %29 = load i16, ptr %28, align 1, !tbaa !51
  %30 = trunc i16 %29 to i8
  store volatile i8 %30, ptr %27, align 1, !tbaa !6
  %31 = load i16, ptr %28, align 1, !tbaa !51
  %32 = lshr i16 %31, 8
  %33 = trunc nuw i16 %32 to i8
  store volatile i8 %33, ptr %27, align 1, !tbaa !6
  br label %86

34:                                               ; preds = %17
  %35 = load i16, ptr %22, align 1, !tbaa !47
  %36 = inttoptr i16 %35 to ptr
  %37 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %38 = load i16, ptr %37, align 1, !tbaa !51
  %39 = trunc i16 %38 to i8
  store volatile i8 %39, ptr %36, align 1, !tbaa !6
  %40 = load i16, ptr %37, align 1, !tbaa !51
  %41 = lshr i16 %40, 8
  %42 = trunc nuw i16 %41 to i8
  %43 = getelementptr inbounds nuw i8, ptr %36, i16 1
  store volatile i8 %42, ptr %43, align 1, !tbaa !6
  br label %86

44:                                               ; preds = %17
  %45 = icmp eq i16 %19, 0
  br i1 %45, label %51, label %46

46:                                               ; preds = %44
  %47 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %48 = load i16, ptr %47, align 1, !tbaa !53
  %49 = add i16 %48, %19
  %50 = icmp ugt i16 %49, 5100
  br i1 %50, label %91, label %51

51:                                               ; preds = %46, %44
  switch i8 %24, label %59 [
    i8 0, label %52
    i8 1, label %56
  ]

52:                                               ; preds = %51
  %53 = getelementptr inbounds nuw i8, ptr %22, i16 9
  %54 = load i8, ptr %53, align 1, !tbaa !48
  store volatile i8 %54, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  %55 = load i16, ptr %22, align 1, !tbaa !47
  store volatile i16 %55, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %65

56:                                               ; preds = %51
  %57 = load i16, ptr %22, align 1, !tbaa !47
  %58 = trunc i16 %57 to i8
  store volatile i8 %58, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  br label %65

59:                                               ; preds = %51
  %60 = load i16, ptr %22, align 1, !tbaa !47
  %61 = trunc i16 %60 to i8
  store volatile i8 %61, ptr inttoptr (i16 8450 to ptr), align 2, !tbaa !6
  %62 = load i16, ptr %22, align 1, !tbaa !47
  %63 = lshr i16 %62, 8
  %64 = trunc nuw i16 %63 to i8
  store volatile i8 %64, ptr inttoptr (i16 8451 to ptr), align 1, !tbaa !6
  br label %65

65:                                               ; preds = %56, %59, %52
  %66 = getelementptr inbounds nuw i8, ptr %22, i16 8
  %67 = load i8, ptr %66, align 1, !tbaa !50
  store volatile i8 %67, ptr %5, align 16, !tbaa !6
  %68 = getelementptr inbounds nuw i8, ptr %22, i16 7
  %69 = load i8, ptr %68, align 1, !tbaa !49
  store volatile i8 %69, ptr %11, align 1, !tbaa !6
  %70 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %71 = load i16, ptr %70, align 1, !tbaa !51
  %72 = trunc i16 %71 to i8
  store volatile i8 %72, ptr %12, align 2, !tbaa !6
  %73 = load i16, ptr %70, align 1, !tbaa !51
  %74 = lshr i16 %73, 8
  %75 = trunc nuw i16 %74 to i8
  store volatile i8 %75, ptr %13, align 1, !tbaa !6
  %76 = getelementptr inbounds nuw i8, ptr %22, i16 6
  %77 = load i8, ptr %76, align 1, !tbaa !52
  store volatile i8 %77, ptr %14, align 4, !tbaa !6
  %78 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %79 = load i16, ptr %78, align 1, !tbaa !53
  %80 = trunc i16 %79 to i8
  store volatile i8 %80, ptr %15, align 1, !tbaa !6
  %81 = load i16, ptr %78, align 1, !tbaa !53
  %82 = lshr i16 %81, 8
  %83 = trunc nuw i16 %82 to i8
  store volatile i8 %83, ptr %16, align 2, !tbaa !6
  store volatile i8 %7, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !6
  %84 = load i16, ptr %78, align 1, !tbaa !53
  %85 = add i16 %84, %19
  br label %86

86:                                               ; preds = %65, %34, %25
  %87 = phi i16 [ %19, %25 ], [ %19, %34 ], [ %85, %65 ]
  %88 = add nuw i8 %20, 1
  %89 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %90 = icmp ult i8 %88, %89
  br i1 %90, label %17, label %91

91:                                               ; preds = %86, %46
  %92 = phi i8 [ %89, %86 ], [ %18, %46 ]
  %93 = phi i8 [ %88, %86 ], [ %20, %46 ]
  %94 = icmp ult i8 %93, %92
  br i1 %94, label %95, label %108

95:                                               ; preds = %91
  %96 = icmp eq i8 %93, 0
  br i1 %96, label %110, label %97

97:                                               ; preds = %95, %97
  %98 = phi i8 [ %101, %97 ], [ 0, %95 ]
  %99 = phi i8 [ %104, %97 ], [ %93, %95 ]
  %100 = zext i8 %99 to i16
  %101 = add i8 %98, 1
  %102 = zext i8 %98 to i16
  %103 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %102
  %104 = add nuw i8 %99, 1
  %105 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %100
  tail call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(11) %103, ptr noundef nonnull align 1 dereferenceable(11) %105, i16 11, i1 false), !tbaa.struct !136
  %106 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %107 = icmp ult i8 %104, %106
  br i1 %107, label %97, label %108, !llvm.loop !137

108:                                              ; preds = %97, %91, %0
  %109 = phi i8 [ 0, %91 ], [ 0, %0 ], [ %101, %97 ]
  store i8 %109, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  br label %110

110:                                              ; preds = %108, %95
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #10

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #11

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #11

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { nofree noinline norecurse nosync nounwind optsize memory(readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { nofree norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #4 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #5 = { nofree norecurse nosync nounwind optsize memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #6 = { nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #7 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { nofree noinline norecurse nosync nounwind optsize memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #9 = { nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #10 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #12 = { nounwind optsize }
attributes #13 = { optsize }
attributes #14 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!10, !4, i64 194}
!10 = !{!"", !11, i64 0, !12, i64 178, !13, i64 182, !4, i64 191, !4, i64 192, !4, i64 193, !4, i64 194, !4, i64 195}
!11 = !{!"", !4, i64 0, !4, i64 176, !4, i64 177}
!12 = !{!"", !3, i64 0, !3, i64 2}
!13 = !{!"", !4, i64 0, !4, i64 8}
!14 = !{!10, !4, i64 195}
!15 = !{!16, !18, i64 0}
!16 = !{!"", !17, i64 0, !4, i64 3, !3, i64 4099, !3, i64 4101, !3, i64 4103, !3, i64 4105, !4, i64 4107, !4, i64 4108}
!17 = !{!"Drawable", !18, i64 0, !4, i64 2}
!18 = !{!"any pointer", !4, i64 0}
!19 = !{!16, !4, i64 2}
!20 = !{!16, !3, i64 4103}
!21 = !{!16, !3, i64 4105}
!22 = !{!16, !4, i64 4107}
!23 = !{!16, !4, i64 4108}
!24 = !{!16, !3, i64 4099}
!25 = !{!16, !3, i64 4101}
!26 = !{!27, !18, i64 0}
!27 = !{!"", !17, i64 0, !3, i64 3, !4, i64 5, !4, i64 7, !4, i64 135}
!28 = !{!27, !4, i64 2}
!29 = !{!27, !3, i64 3}
!30 = distinct !{!30, !8}
!31 = !{!27, !4, i64 135}
!32 = !{!10, !4, i64 192}
!33 = !{!10, !4, i64 193}
!34 = !{!13, !4, i64 8}
!35 = !{!36, !36, i64 0}
!36 = !{!"p1 _ZTS8Drawable", !18, i64 0}
!37 = distinct !{null, null}
!38 = !{!10, !4, i64 191}
!39 = !{!17, !4, i64 2}
!40 = !{!17, !18, i64 0}
!41 = !{!42, !18, i64 0}
!42 = !{!"", !18, i64 0, !18, i64 2}
!43 = distinct !{null, null, null}
!44 = !{!11, !4, i64 176}
!45 = !{!46, !4, i64 10}
!46 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !4, i64 6, !4, i64 7, !4, i64 8, !4, i64 9, !4, i64 10}
!47 = !{!46, !3, i64 0}
!48 = !{!46, !4, i64 9}
!49 = !{!46, !4, i64 7}
!50 = !{!46, !4, i64 8}
!51 = !{!46, !3, i64 2}
!52 = !{!46, !4, i64 6}
!53 = !{!46, !3, i64 4}
!54 = !{!55, !3, i64 4539}
!55 = !{!"", !10, i64 0, !16, i64 196, !27, i64 4305, !4, i64 4441, !4, i64 4497, !4, i64 4511, !4, i64 4525, !3, i64 4539}
!56 = distinct !{!56, !8}
!57 = !{!12, !3, i64 0}
!58 = !{!12, !3, i64 2}
!59 = distinct !{!59, !8}
!60 = !{!61, !18, i64 0}
!61 = !{!"", !17, i64 0, !62, i64 3, !62, i64 5, !62, i64 7, !62, i64 9, !4, i64 11, !4, i64 12, !3, i64 13, !3, i64 15, !3, i64 17, !3, i64 19, !3, i64 21, !3, i64 23, !4, i64 25, !3, i64 26, !4, i64 28, !4, i64 29, !4, i64 30, !4, i64 31, !4, i64 32, !4, i64 33, !3, i64 34, !3, i64 36, !63, i64 38, !63, i64 89}
!62 = !{!"p1 omnipotent char", !18, i64 0}
!63 = !{!"", !4, i64 0, !4, i64 50}
!64 = !{!61, !4, i64 2}
!65 = !{!61, !62, i64 3}
!66 = !{!61, !62, i64 5}
!67 = !{!61, !62, i64 7}
!68 = !{!61, !4, i64 11}
!69 = !{!61, !62, i64 9}
!70 = !{!61, !4, i64 12}
!71 = !{!61, !3, i64 13}
!72 = !{!61, !3, i64 15}
!73 = !{!61, !3, i64 17}
!74 = !{!61, !4, i64 28}
!75 = !{!61, !4, i64 29}
!76 = !{!61, !4, i64 31}
!77 = !{!61, !4, i64 32}
!78 = !{!61, !4, i64 30}
!79 = !{!61, !4, i64 25}
!80 = !{!61, !3, i64 34}
!81 = !{!61, !3, i64 36}
!82 = !{!61, !4, i64 33}
!83 = !{!42, !18, i64 2}
!84 = distinct !{null, null, null, null, null}
!85 = distinct !{!85, !8}
!86 = distinct !{!86, !8}
!87 = distinct !{!87, !8}
!88 = distinct !{null, null, null, null}
!89 = distinct !{!89, !8}
!90 = distinct !{!90, !8}
!91 = distinct !{!91, !8}
!92 = distinct !{!92, !8}
!93 = distinct !{!93, !8}
!94 = distinct !{null, null, null, null, null}
!95 = distinct !{!95, !8}
!96 = distinct !{!96, !8}
!97 = distinct !{null, null, null, null}
!98 = !{!61, !3, i64 19}
!99 = distinct !{null, null, null, null, null}
!100 = distinct !{null, null, null}
!101 = distinct !{!101, !8}
!102 = distinct !{!102, !8}
!103 = distinct !{!103, !8}
!104 = distinct !{!104, !8}
!105 = distinct !{!105, !8}
!106 = distinct !{!106, !8}
!107 = distinct !{!107, !8}
!108 = distinct !{!108, !8}
!109 = distinct !{!109, !8}
!110 = distinct !{!110, !8}
!111 = distinct !{!111, !8}
!112 = distinct !{!112, !8}
!113 = distinct !{!113, !8}
!114 = distinct !{!114, !8}
!115 = distinct !{!115, !8}
!116 = distinct !{!116, !8}
!117 = distinct !{!117, !8}
!118 = distinct !{!118, !8}
!119 = distinct !{!119, !8}
!120 = !{!61, !3, i64 21}
!121 = !{!61, !3, i64 23}
!122 = distinct !{!122, !8}
!123 = !{!61, !3, i64 26}
!124 = !{!63, !4, i64 50}
!125 = distinct !{!125, !8}
!126 = distinct !{!126, !8}
!127 = !{!128, !18, i64 0}
!128 = !{!"", !18, i64 0, !4, i64 2}
!129 = !{!128, !4, i64 2}
!130 = distinct !{!130, !8}
!131 = distinct !{!131, !8}
!132 = distinct !{!132, !8}
!133 = distinct !{!133, !8}
!134 = distinct !{!134, !8}
!135 = !{!11, !4, i64 177}
!136 = !{i64 0, i64 2, !2, i64 2, i64 2, !2, i64 4, i64 2, !2, i64 6, i64 1, !6, i64 7, i64 1, !6, i64 8, i64 1, !6, i64 9, i64 1, !6, i64 10, i64 1, !6}
!137 = distinct !{!137, !8}
