; ModuleID = '/work/examples/snes/corpus/msquares_sim.c'
source_filename = "/work/examples/snes/corpus/msquares_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1
@msquares_gate_crc.vg = internal unnamed_addr global [289 x i16] zeroinitializer, align 1
@MS_SEG = internal unnamed_addr constant [16 x [4 x i8]] [[4 x i8] c"\FF\FF\FF\FF", [4 x i8] c"\03\02\FF\FF", [4 x i8] c"\01\02\FF\FF", [4 x i8] c"\03\01\FF\FF", [4 x i8] c"\00\01\FF\FF", [4 x i8] c"\00\03\01\02", [4 x i8] c"\00\02\FF\FF", [4 x i8] c"\00\03\FF\FF", [4 x i8] c"\00\03\FF\FF", [4 x i8] c"\00\02\FF\FF", [4 x i8] c"\00\01\03\02", [4 x i8] c"\00\01\FF\FF", [4 x i8] c"\03\01\FF\FF", [4 x i8] c"\01\02\FF\FF", [4 x i8] c"\03\02\FF\FF", [4 x i8] c"\FF\FF\FF\FF"], align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [3 x i16], align 1
  %2 = alloca [3 x i16], align 1
  %3 = alloca i16, align 1
  %4 = alloca i16, align 1
  %5 = alloca i16, align 1
  %6 = alloca i16, align 1
  %7 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %8 = getelementptr inbounds nuw i8, ptr %2, i16 2
  %9 = getelementptr inbounds nuw i8, ptr %1, i16 4
  %10 = getelementptr inbounds nuw i8, ptr %2, i16 4
  br label %11

11:                                               ; preds = %86, %0
  %12 = phi i16 [ 0, %0 ], [ %160, %86 ]
  %13 = phi i1 [ true, %0 ], [ false, %86 ]
  %14 = phi i16 [ 0, %0 ], [ 1, %86 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #4
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #4
  %15 = mul nuw nsw i16 %14, 87
  %16 = and i16 %15, 63
  %17 = or i16 %15, 64
  %18 = add nsw i16 %17, -32
  store i16 %18, ptr %1, align 1, !tbaa !2
  %19 = mul nuw nsw i16 %14, 58
  %20 = and i16 %19, 46
  %21 = add nuw nsw i16 %20, 36
  store i16 %21, ptr %2, align 1, !tbaa !2
  %22 = and i16 %19, 54
  %23 = sub nuw nsw i16 97, %22
  store i16 %23, ptr %7, align 1, !tbaa !2
  %24 = and i16 %15, 39
  %25 = add nuw nsw i16 %24, 44
  store i16 %25, ptr %8, align 1, !tbaa !2
  %26 = mul nuw nsw i16 %14, 52
  %27 = and i16 %26, 44
  %28 = add nuw nsw i16 %27, 36
  store i16 %28, ptr %9, align 1, !tbaa !2
  %29 = sub nuw nsw i16 102, %16
  store i16 %29, ptr %10, align 1, !tbaa !2
  br label %30

30:                                               ; preds = %36, %11
  %31 = phi ptr [ @msquares_gate_crc.vg, %11 ], [ %38, %36 ]
  %32 = phi i8 [ 0, %11 ], [ %37, %36 ]
  %33 = zext nneg i8 %32 to i16
  %34 = mul nuw nsw i16 %33, 6
  %35 = add nuw nsw i16 %34, 8
  br label %40

36:                                               ; preds = %71
  %37 = add nuw nsw i8 %32, 1
  %38 = getelementptr i8, ptr %31, i16 34
  %39 = icmp eq i8 %37, 17
  br i1 %39, label %78, label %30, !llvm.loop !6

40:                                               ; preds = %71, %30
  %41 = phi i8 [ 0, %30 ], [ %77, %71 ]
  %42 = phi i8 [ 0, %30 ], [ %75, %71 ]
  %43 = zext nneg i8 %42 to i16
  %44 = mul nuw nsw i16 %43, 6
  %45 = add nuw nsw i16 %44, 8
  br label %46

46:                                               ; preds = %66, %40
  %47 = phi i8 [ 0, %40 ], [ %70, %66 ]
  %48 = phi i32 [ 0, %40 ], [ %67, %66 ]
  %49 = phi i8 [ 0, %40 ], [ %68, %66 ]
  %50 = zext nneg i8 %47 to i16
  %51 = getelementptr i8, ptr %1, i16 %50
  %52 = load i16, ptr %51, align 1, !tbaa !2
  %53 = sub i16 %45, %52
  %54 = sext i16 %53 to i32
  %55 = getelementptr i8, ptr %2, i16 %50
  %56 = load i16, ptr %55, align 1, !tbaa !2
  %57 = sub i16 %35, %56
  %58 = sext i16 %57 to i32
  %59 = mul nsw i32 %54, %54
  %60 = mul nsw i32 %58, %58
  %61 = add nuw nsw i32 %60, %59
  %62 = icmp samesign ult i32 %61, 1600
  br i1 %62, label %63, label %66

63:                                               ; preds = %46
  %64 = add i32 %48, 1600
  %65 = sub i32 %64, %61
  br label %66

66:                                               ; preds = %63, %46
  %67 = phi i32 [ %65, %63 ], [ %48, %46 ]
  %68 = add nuw nsw i8 %49, 1
  %69 = icmp eq i8 %68, 3
  %70 = add nuw nsw i8 %47, 2
  br i1 %69, label %71, label %46, !llvm.loop !8

71:                                               ; preds = %66
  %72 = trunc i32 %67 to i16
  %73 = zext nneg i8 %41 to i16
  %74 = getelementptr i8, ptr %31, i16 %73
  store i16 %72, ptr %74, align 1, !tbaa !2
  %75 = add nuw nsw i8 %42, 1
  %76 = icmp eq i8 %75, 17
  %77 = add nuw nsw i8 %41, 2
  br i1 %76, label %36, label %40, !llvm.loop !9

78:                                               ; preds = %36, %87
  %79 = phi ptr [ %92, %87 ], [ getelementptr inbounds nuw (i8, ptr @msquares_gate_crc.vg, i16 36), %36 ]
  %80 = phi ptr [ %91, %87 ], [ getelementptr inbounds nuw (i8, ptr @msquares_gate_crc.vg, i16 34), %36 ]
  %81 = phi ptr [ %90, %87 ], [ getelementptr inbounds nuw (i8, ptr @msquares_gate_crc.vg, i16 2), %36 ]
  %82 = phi ptr [ %89, %87 ], [ @msquares_gate_crc.vg, %36 ]
  %83 = phi i16 [ %160, %87 ], [ %12, %36 ]
  %84 = phi i8 [ %88, %87 ], [ 0, %36 ]
  %85 = zext nneg i8 %84 to i16
  br label %94

86:                                               ; preds = %87
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #4
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #4
  br i1 %13, label %11, label %161, !llvm.loop !10

87:                                               ; preds = %132
  %88 = add nuw nsw i8 %84, 1
  %89 = getelementptr i8, ptr %82, i16 34
  %90 = getelementptr i8, ptr %81, i16 34
  %91 = getelementptr i8, ptr %80, i16 34
  %92 = getelementptr i8, ptr %79, i16 34
  %93 = icmp eq i8 %88, 16
  br i1 %93, label %86, label %78, !llvm.loop !11

94:                                               ; preds = %132, %78
  %95 = phi i8 [ 0, %78 ], [ %135, %132 ]
  %96 = phi i16 [ %83, %78 ], [ %160, %132 ]
  %97 = phi i8 [ 0, %78 ], [ %133, %132 ]
  %98 = zext nneg i8 %97 to i16
  %99 = zext nneg i8 %95 to i16
  %100 = getelementptr i8, ptr %82, i16 %99
  %101 = load i16, ptr %100, align 1, !tbaa !2
  %102 = sext i16 %101 to i32
  %103 = getelementptr i8, ptr %81, i16 %99
  %104 = load i16, ptr %103, align 1, !tbaa !2
  %105 = sext i16 %104 to i32
  %106 = getelementptr i8, ptr %80, i16 %99
  %107 = getelementptr i8, ptr %79, i16 %99
  %108 = load i16, ptr %107, align 1, !tbaa !2
  %109 = sext i16 %108 to i32
  %110 = load i16, ptr %106, align 1, !tbaa !2
  %111 = sext i16 %110 to i32
  %112 = icmp sgt i16 %101, 699
  %113 = select i1 %112, i8 8, i8 0
  %114 = icmp sgt i16 %104, 699
  %115 = select i1 %114, i8 4, i8 0
  %116 = or disjoint i8 %115, %113
  %117 = icmp sgt i16 %108, 699
  %118 = select i1 %117, i8 2, i8 0
  %119 = or disjoint i8 %116, %118
  %120 = icmp sgt i16 %110, 699
  %121 = zext i1 %120 to i8
  %122 = or disjoint i8 %119, %121
  %123 = zext nneg i8 %122 to i16
  %124 = shl nuw nsw i16 %98, 4
  %125 = add nuw nsw i16 %124, %85
  %126 = tail call i16 @llvm.fshl.i16(i16 %96, i16 %96, i16 1)
  %127 = xor i16 %125, %126
  %128 = xor i16 %127, %123
  %129 = getelementptr inbounds nuw [4 x i8], ptr @MS_SEG, i16 %123
  %130 = shl nuw nsw i16 %123, 2
  %131 = getelementptr nuw i8, ptr getelementptr inbounds nuw (i8, ptr @MS_SEG, i16 1), i16 %130
  br label %136

132:                                              ; preds = %159
  %133 = add nuw nsw i8 %97, 1
  %134 = icmp eq i8 %133, 16
  %135 = add nuw nsw i8 %95, 2
  br i1 %134, label %87, label %94, !llvm.loop !12

136:                                              ; preds = %159, %94
  %137 = phi i16 [ %128, %94 ], [ %160, %159 ]
  %138 = phi i1 [ true, %94 ], [ false, %159 ]
  %139 = phi i8 [ 0, %94 ], [ 2, %159 ]
  %140 = zext nneg i8 %139 to i16
  %141 = getelementptr i8, ptr %129, i16 %140
  %142 = load i8, ptr %141, align 1, !tbaa !13
  %143 = icmp eq i8 %142, -1
  br i1 %143, label %159, label %144

144:                                              ; preds = %136
  %145 = getelementptr i8, ptr %131, i16 %140
  %146 = load i8, ptr %145, align 1, !tbaa !13
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #4
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #4
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #4
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #4
  call fastcc void @ms_edge_point(i8 noundef zeroext %142, i16 noundef %98, i16 noundef %85, i32 noundef %102, i32 noundef %105, i32 noundef %109, i32 noundef %111, ptr noundef %3, ptr noundef %4) #5
  call fastcc void @ms_edge_point(i8 noundef zeroext %146, i16 noundef %98, i16 noundef %85, i32 noundef %102, i32 noundef %105, i32 noundef %109, i32 noundef %111, ptr noundef %5, ptr noundef %6) #5
  %147 = load i16, ptr %3, align 1, !tbaa !2
  %148 = load i16, ptr %4, align 1, !tbaa !2
  %149 = shl i16 %148, 8
  %150 = tail call i16 @llvm.fshl.i16(i16 %137, i16 %137, i16 1)
  %151 = xor i16 %147, %150
  %152 = xor i16 %151, %149
  %153 = load i16, ptr %5, align 1, !tbaa !2
  %154 = load i16, ptr %6, align 1, !tbaa !2
  %155 = shl i16 %154, 8
  %156 = xor i16 %155, %153
  %157 = tail call i16 @llvm.fshl.i16(i16 %152, i16 %152, i16 1)
  %158 = xor i16 %156, %157
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #4
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #4
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #4
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #4
  br label %159

159:                                              ; preds = %144, %136
  %160 = phi i16 [ %158, %144 ], [ %137, %136 ]
  br i1 %138, label %136, label %132, !llvm.loop !14

161:                                              ; preds = %86
  store volatile i16 %160, ptr @corpus_result, align 1, !tbaa !2
  br label %162

162:                                              ; preds = %162, %161
  tail call void asm sideeffect "wai", ""() #4, !srcloc !15
  br label %162
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal fastcc void @ms_edge_point(i8 noundef zeroext %0, i16 noundef range(i16 0, 16) %1, i16 noundef range(i16 0, 16) %2, i32 noundef range(i32 -32768, 32768) %3, i32 noundef range(i32 -32768, 32768) %4, i32 noundef range(i32 -32768, 32768) %5, i32 noundef range(i32 -32768, 32768) %6, ptr noundef nonnull writeonly captures(none) initializes((0, 2)) %7, ptr noundef nonnull writeonly captures(none) initializes((0, 2)) %8) unnamed_addr #2 {
  %10 = shl nuw nsw i16 %1, 4
  %11 = shl nuw nsw i16 %2, 4
  switch i8 %0, label %59 [
    i8 0, label %12
    i8 1, label %27
    i8 2, label %43
  ]

12:                                               ; preds = %9
  %13 = icmp eq i32 %4, %3
  br i1 %13, label %24, label %14

14:                                               ; preds = %12
  %15 = sub nsw i32 %4, %3
  %16 = shl nsw i32 %3, 4
  %17 = sub nsw i32 11200, %16
  %18 = sdiv i32 %17, %15
  %19 = icmp slt i32 %18, 0
  br i1 %19, label %24, label %20

20:                                               ; preds = %14
  %21 = icmp samesign ugt i32 %18, 16
  %22 = trunc nuw nsw i32 %18 to i16
  br i1 %21, label %23, label %24

23:                                               ; preds = %20
  br label %24

24:                                               ; preds = %12, %14, %20, %23
  %25 = phi i16 [ 8, %12 ], [ %22, %20 ], [ 16, %23 ], [ 0, %14 ]
  %26 = add nuw nsw i16 %25, %10
  store i16 %26, ptr %7, align 1, !tbaa !2
  br label %74

27:                                               ; preds = %9
  %28 = add nuw nsw i16 %10, 16
  store i16 %28, ptr %7, align 1, !tbaa !2
  %29 = icmp eq i32 %5, %4
  br i1 %29, label %40, label %30

30:                                               ; preds = %27
  %31 = sub nsw i32 %5, %4
  %32 = shl nsw i32 %4, 4
  %33 = sub nsw i32 11200, %32
  %34 = sdiv i32 %33, %31
  %35 = icmp slt i32 %34, 0
  br i1 %35, label %40, label %36

36:                                               ; preds = %30
  %37 = icmp samesign ugt i32 %34, 16
  %38 = trunc nuw nsw i32 %34 to i16
  br i1 %37, label %39, label %40

39:                                               ; preds = %36
  br label %40

40:                                               ; preds = %27, %30, %36, %39
  %41 = phi i16 [ 8, %27 ], [ %38, %36 ], [ 16, %39 ], [ 0, %30 ]
  %42 = add nuw nsw i16 %41, %11
  br label %74

43:                                               ; preds = %9
  %44 = icmp eq i32 %5, %6
  br i1 %44, label %55, label %45

45:                                               ; preds = %43
  %46 = sub nsw i32 %5, %6
  %47 = shl nsw i32 %6, 4
  %48 = sub nsw i32 11200, %47
  %49 = sdiv i32 %48, %46
  %50 = icmp slt i32 %49, 0
  br i1 %50, label %55, label %51

51:                                               ; preds = %45
  %52 = icmp samesign ugt i32 %49, 16
  %53 = trunc nuw nsw i32 %49 to i16
  br i1 %52, label %54, label %55

54:                                               ; preds = %51
  br label %55

55:                                               ; preds = %43, %45, %51, %54
  %56 = phi i16 [ 8, %43 ], [ %53, %51 ], [ 16, %54 ], [ 0, %45 ]
  %57 = add nuw nsw i16 %56, %10
  store i16 %57, ptr %7, align 1, !tbaa !2
  %58 = add nuw nsw i16 %11, 16
  br label %74

59:                                               ; preds = %9
  store i16 %10, ptr %7, align 1, !tbaa !2
  %60 = icmp eq i32 %6, %3
  br i1 %60, label %71, label %61

61:                                               ; preds = %59
  %62 = sub nsw i32 %6, %3
  %63 = shl nsw i32 %3, 4
  %64 = sub nsw i32 11200, %63
  %65 = sdiv i32 %64, %62
  %66 = icmp slt i32 %65, 0
  br i1 %66, label %71, label %67

67:                                               ; preds = %61
  %68 = icmp samesign ugt i32 %65, 16
  %69 = trunc nuw nsw i32 %65 to i16
  br i1 %68, label %70, label %71

70:                                               ; preds = %67
  br label %71

71:                                               ; preds = %59, %61, %67, %70
  %72 = phi i16 [ 8, %59 ], [ %69, %67 ], [ 16, %70 ], [ 0, %61 ]
  %73 = add nuw nsw i16 %72, %11
  br label %74

74:                                               ; preds = %71, %55, %40, %24
  %75 = phi i16 [ %73, %71 ], [ %58, %55 ], [ %42, %40 ], [ %11, %24 ]
  store i16 %75, ptr %8, align 1, !tbaa !2
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #3

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind }
attributes #5 = { optsize }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = !{!4, !4, i64 0}
!14 = distinct !{!14, !7}
!15 = !{i64 315}
