; ModuleID = '/work/examples/snes/corpus/percol_sim.c'
source_filename = "/work/examples/snes/corpus/percol_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.Percol = type { [256 x i16], [256 x i8], i16, i16 }

@corpus_result = dso_local global i16 0, align 1
@percol_gate_crc.p = internal unnamed_addr global %struct.Percol zeroinitializer, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %1, %0
  %2 = phi i16 [ 0, %0 ], [ %5, %1 ]
  %3 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %2
  store i16 %2, ptr %3, align 1, !tbaa !2
  %4 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @percol_gate_crc.p, i16 512), i16 %2
  store i8 0, ptr %4, align 1, !tbaa !6
  %5 = add nuw nsw i16 %2, 1
  %6 = icmp eq i16 %5, 256
  br i1 %6, label %7, label %1, !llvm.loop !7

7:                                                ; preds = %1
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @percol_gate_crc.p, i16 768), align 1, !tbaa !9
  store i16 -16161, ptr getelementptr inbounds nuw (i8, ptr @percol_gate_crc.p, i16 770), align 1, !tbaa !11
  br label %60

8:                                                ; preds = %155, %54
  %9 = phi i8 [ %57, %54 ], [ 0, %155 ]
  %10 = phi i16 [ %55, %54 ], [ 0, %155 ]
  br label %11

11:                                               ; preds = %11, %8
  %12 = phi i16 [ %14, %11 ], [ %10, %8 ]
  %13 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %12
  %14 = load i16, ptr %13, align 1, !tbaa !2
  %15 = icmp eq i16 %14, %12
  br i1 %15, label %16, label %11, !llvm.loop !12

16:                                               ; preds = %11
  %17 = zext nneg i8 %9 to i16
  %18 = getelementptr i8, ptr @percol_gate_crc.p, i16 %17
  %19 = load i16, ptr %18, align 1, !tbaa !2
  %20 = icmp eq i16 %19, %12
  br i1 %20, label %27, label %21

21:                                               ; preds = %16, %21
  %22 = phi i16 [ %25, %21 ], [ %19, %16 ]
  %23 = phi ptr [ %24, %21 ], [ %18, %16 ]
  store i16 %12, ptr %23, align 1, !tbaa !2
  %24 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %22
  %25 = load i16, ptr %24, align 1, !tbaa !2
  %26 = icmp eq i16 %25, %12
  br i1 %26, label %27, label %21, !llvm.loop !13

27:                                               ; preds = %21, %16
  br label %32

28:                                               ; preds = %52
  %29 = add nuw nsw i16 %34, 1
  %30 = icmp eq i16 %29, 16
  %31 = add nuw nsw i8 %33, 2
  br i1 %30, label %54, label %32, !llvm.loop !14

32:                                               ; preds = %27, %28
  %33 = phi i8 [ %31, %28 ], [ 0, %27 ]
  %34 = phi i16 [ %29, %28 ], [ 0, %27 ]
  %35 = or disjoint i16 %34, 240
  br label %36

36:                                               ; preds = %36, %32
  %37 = phi i16 [ %35, %32 ], [ %39, %36 ]
  %38 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %37
  %39 = load i16, ptr %38, align 1, !tbaa !2
  %40 = icmp eq i16 %39, %37
  br i1 %40, label %41, label %36, !llvm.loop !12

41:                                               ; preds = %36
  %42 = zext nneg i8 %33 to i16
  %43 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @percol_gate_crc.p, i16 480), i16 %42
  %44 = load i16, ptr %43, align 1, !tbaa !2
  %45 = icmp eq i16 %44, %37
  br i1 %45, label %52, label %46

46:                                               ; preds = %41, %46
  %47 = phi i16 [ %50, %46 ], [ %44, %41 ]
  %48 = phi ptr [ %49, %46 ], [ %43, %41 ]
  store i16 %37, ptr %48, align 1, !tbaa !2
  %49 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %47
  %50 = load i16, ptr %49, align 1, !tbaa !2
  %51 = icmp eq i16 %50, %37
  br i1 %51, label %52, label %46, !llvm.loop !13

52:                                               ; preds = %46, %41
  %53 = icmp eq i16 %37, %12
  br i1 %53, label %58, label %28

54:                                               ; preds = %28
  %55 = add nuw nsw i16 %10, 1
  %56 = icmp eq i16 %55, 16
  %57 = add nuw nsw i8 %9, 2
  br i1 %56, label %58, label %8, !llvm.loop !15

58:                                               ; preds = %54, %52
  %59 = phi i8 [ 1, %52 ], [ 0, %54 ]
  br label %160

60:                                               ; preds = %155, %7
  %61 = phi i16 [ 0, %7 ], [ %158, %155 ]
  %62 = phi i16 [ 0, %7 ], [ %157, %155 ]
  %63 = load i16, ptr getelementptr inbounds nuw (i8, ptr @percol_gate_crc.p, i16 770), align 1, !tbaa !11
  %64 = shl i16 %63, 7
  %65 = xor i16 %64, %63
  %66 = lshr i16 %65, 9
  %67 = xor i16 %66, %65
  %68 = shl i16 %67, 8
  %69 = xor i16 %68, %67
  store i16 %69, ptr getelementptr inbounds nuw (i8, ptr @percol_gate_crc.p, i16 770), align 1, !tbaa !11
  %70 = and i16 %67, 255
  %71 = icmp sgt i16 %69, -1
  br i1 %71, label %75, label %72

72:                                               ; preds = %60
  %73 = and i16 %67, 15
  %74 = icmp eq i16 %73, 15
  br i1 %74, label %135, label %78

75:                                               ; preds = %60
  %76 = and i16 %67, 240
  %77 = icmp eq i16 %76, 240
  br i1 %77, label %135, label %78

78:                                               ; preds = %75, %72
  %79 = phi i16 [ 1, %72 ], [ 16, %75 ]
  br label %80

80:                                               ; preds = %80, %78
  %81 = phi i16 [ %70, %78 ], [ %83, %80 ]
  %82 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %81
  %83 = load i16, ptr %82, align 1, !tbaa !2
  %84 = icmp eq i16 %83, %81
  br i1 %84, label %85, label %80, !llvm.loop !12

85:                                               ; preds = %80
  %86 = add nuw nsw i16 %79, %70
  %87 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %70
  %88 = load i16, ptr %87, align 1, !tbaa !2
  %89 = icmp eq i16 %88, %81
  br i1 %89, label %96, label %90

90:                                               ; preds = %85, %90
  %91 = phi i16 [ %94, %90 ], [ %88, %85 ]
  %92 = phi ptr [ %93, %90 ], [ %87, %85 ]
  store i16 %81, ptr %92, align 1, !tbaa !2
  %93 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %91
  %94 = load i16, ptr %93, align 1, !tbaa !2
  %95 = icmp eq i16 %94, %81
  br i1 %95, label %96, label %90, !llvm.loop !13

96:                                               ; preds = %90, %85
  br label %97

97:                                               ; preds = %96, %97
  %98 = phi i16 [ %100, %97 ], [ %86, %96 ]
  %99 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %98
  %100 = load i16, ptr %99, align 1, !tbaa !2
  %101 = icmp eq i16 %100, %98
  br i1 %101, label %102, label %97, !llvm.loop !12

102:                                              ; preds = %97
  %103 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %86
  %104 = load i16, ptr %103, align 1, !tbaa !2
  %105 = icmp eq i16 %104, %98
  br i1 %105, label %112, label %106

106:                                              ; preds = %102, %106
  %107 = phi i16 [ %110, %106 ], [ %104, %102 ]
  %108 = phi ptr [ %109, %106 ], [ %103, %102 ]
  store i16 %98, ptr %108, align 1, !tbaa !2
  %109 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %107
  %110 = load i16, ptr %109, align 1, !tbaa !2
  %111 = icmp eq i16 %110, %98
  br i1 %111, label %112, label %106, !llvm.loop !13

112:                                              ; preds = %106, %102
  %113 = icmp eq i16 %81, %98
  br i1 %113, label %135, label %114

114:                                              ; preds = %112
  %115 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @percol_gate_crc.p, i16 512), i16 %81
  %116 = load i8, ptr %115, align 1, !tbaa !6
  %117 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @percol_gate_crc.p, i16 512), i16 %98
  %118 = load i8, ptr %117, align 1, !tbaa !6
  %119 = icmp ult i8 %116, %118
  br i1 %119, label %120, label %121

120:                                              ; preds = %114
  br label %121

121:                                              ; preds = %120, %114
  %122 = phi i16 [ %98, %120 ], [ %81, %114 ]
  %123 = phi i16 [ %81, %120 ], [ %98, %114 ]
  %124 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %123
  store i16 %122, ptr %124, align 1, !tbaa !2
  %125 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @percol_gate_crc.p, i16 512), i16 %122
  %126 = load i8, ptr %125, align 1, !tbaa !6
  %127 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @percol_gate_crc.p, i16 512), i16 %123
  %128 = load i8, ptr %127, align 1, !tbaa !6
  %129 = icmp eq i8 %126, %128
  br i1 %129, label %130, label %132

130:                                              ; preds = %121
  %131 = add i8 %126, 1
  store i8 %131, ptr %125, align 1, !tbaa !6
  br label %132

132:                                              ; preds = %130, %121
  %133 = load i16, ptr getelementptr inbounds nuw (i8, ptr @percol_gate_crc.p, i16 768), align 1, !tbaa !9
  %134 = add i16 %133, -1
  store i16 %134, ptr getelementptr inbounds nuw (i8, ptr @percol_gate_crc.p, i16 768), align 1, !tbaa !9
  br label %135

135:                                              ; preds = %132, %112, %75, %72
  %136 = load i16, ptr getelementptr inbounds nuw (i8, ptr @percol_gate_crc.p, i16 768), align 1, !tbaa !9
  %137 = and i16 %61, 255
  br label %138

138:                                              ; preds = %138, %135
  %139 = phi i16 [ %137, %135 ], [ %141, %138 ]
  %140 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %139
  %141 = load i16, ptr %140, align 1, !tbaa !2
  %142 = icmp eq i16 %141, %139
  br i1 %142, label %143, label %138, !llvm.loop !12

143:                                              ; preds = %138
  %144 = tail call i16 @llvm.fshl.i16(i16 %62, i16 %62, i16 1)
  %145 = xor i16 %136, %144
  %146 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %137
  %147 = load i16, ptr %146, align 1, !tbaa !2
  %148 = icmp eq i16 %147, %139
  br i1 %148, label %155, label %149

149:                                              ; preds = %143, %149
  %150 = phi i16 [ %153, %149 ], [ %147, %143 ]
  %151 = phi ptr [ %152, %149 ], [ %146, %143 ]
  store i16 %139, ptr %151, align 1, !tbaa !2
  %152 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %150
  %153 = load i16, ptr %152, align 1, !tbaa !2
  %154 = icmp eq i16 %153, %139
  br i1 %154, label %155, label %149, !llvm.loop !13

155:                                              ; preds = %149, %143
  %156 = tail call i16 @llvm.fshl.i16(i16 %145, i16 %145, i16 1)
  %157 = xor i16 %139, %156
  %158 = add nuw nsw i16 %61, 1
  %159 = icmp eq i16 %158, 400
  br i1 %159, label %8, label %60, !llvm.loop !16

160:                                              ; preds = %160, %58
  %161 = phi i16 [ 0, %58 ], [ %165, %160 ]
  %162 = phi i16 [ 0, %58 ], [ %167, %160 ]
  %163 = getelementptr inbounds nuw [2 x i8], ptr @percol_gate_crc.p, i16 %161
  %164 = load i16, ptr %163, align 1, !tbaa !2
  %165 = add nuw nsw i16 %161, 1
  %166 = mul i16 %164, %165
  %167 = add i16 %166, %162
  %168 = icmp eq i16 %165, 256
  br i1 %168, label %169, label %160, !llvm.loop !17

169:                                              ; preds = %160
  %170 = tail call i16 @llvm.fshl.i16(i16 %157, i16 %157, i16 1)
  %171 = zext nneg i8 %59 to i16
  %172 = xor i16 %170, %171
  %173 = tail call i16 @llvm.fshl.i16(i16 %172, i16 %172, i16 1)
  %174 = xor i16 %167, %173
  store volatile i16 %174, ptr @corpus_result, align 1, !tbaa !2
  br label %175

175:                                              ; preds = %175, %169
  tail call void asm sideeffect "wai", ""() #2, !srcloc !18
  br label %175
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #1

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!10, !3, i64 768}
!10 = !{!"", !4, i64 0, !4, i64 512, !3, i64 768, !3, i64 770}
!11 = !{!10, !3, i64 770}
!12 = distinct !{!12, !8}
!13 = distinct !{!13, !8}
!14 = distinct !{!14, !8}
!15 = distinct !{!15, !8}
!16 = distinct !{!16, !8}
!17 = distinct !{!17, !8}
!18 = !{i64 337}
