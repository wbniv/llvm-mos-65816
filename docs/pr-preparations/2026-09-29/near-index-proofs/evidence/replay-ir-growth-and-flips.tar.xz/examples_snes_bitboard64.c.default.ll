; ModuleID = '/work/examples/snes/bitboard64.c'
source_filename = "/work/examples/snes/bitboard64.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.App = type { %struct.Display, %struct.BitmapCanvas, %struct.TextLayer, i16, i16 }
%struct.Display = type { %struct.UploadQueue, %struct.VramAlloc, %struct.Scene, i8, i8, i8, i8, i8 }
%struct.UploadQueue = type { [16 x %struct.UpqJob], i8, i8 }
%struct.UpqJob = type { i16, i16, i16, i8, i8, i8, i8, i8 }
%struct.VramAlloc = type { i16, i16 }
%struct.Scene = type { [4 x ptr], i8 }
%struct.BitmapCanvas = type { %struct.Drawable, [4096 x i8], i16, i16, i16, i16, i8, i8 }
%struct.Drawable = type { ptr, i8 }
%struct.TextLayer = type { %struct.Drawable, i16, [2 x i8], [64 x i16], i8 }
%struct.TitleLayer = type { %struct.Drawable, ptr, ptr, ptr, ptr, i8, i8, i16, i16, i16, i16, i16, i16, i8, i16, i8, i8, i8, i8, i8, i8, i16, i16, %struct.HScrollDB, %struct.HScrollDB }
%struct.HScrollDB = type { [2 x %struct.HScrollN], i8 }
%struct.HScrollN = type { [25 x i8] }
%struct.DrawableVT = type { ptr, ptr }
%struct.HScrollW = type { ptr, i8 }

@main.a = internal global %struct.App zeroinitializer, align 1
@main.title = internal global %struct.TitleLayer zeroinitializer, align 1
@pal = internal constant [4 x i16] [i16 6209, i16 17700, i16 28452, i16 8031], align 1
@.str = private unnamed_addr constant [21 x i8] c"BITBOARD KNIGHT TOUR\00", align 1
@.str.1 = private unnamed_addr constant [11 x i8] c"BITBOARD64\00", align 1
@.str.2 = private unnamed_addr constant [12 x i8] c"POP CLZ CTZ\00", align 1
@corpus_result = dso_local global i16 0, align 1
@CANVAS_VT = internal constant %struct.DrawableVT { ptr @_canvas_reserve, ptr @_canvas_emit }, align 1
@TEXT_VT = internal constant %struct.DrawableVT { ptr @_text_reserve, ptr @_text_emit }, align 1
@FONT8 = internal unnamed_addr constant [512 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 32, i16 0, i16 80, i16 80, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 80, i16 80, i16 248, i16 80, i16 248, i16 80, i16 80, i16 0, i16 32, i16 120, i16 160, i16 112, i16 40, i16 240, i16 32, i16 0, i16 196, i16 200, i16 16, i16 32, i16 64, i16 152, i16 12, i16 0, i16 96, i16 144, i16 160, i16 64, i16 168, i16 144, i16 104, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 16, i16 32, i16 64, i16 64, i16 64, i16 32, i16 16, i16 0, i16 64, i16 32, i16 16, i16 16, i16 16, i16 32, i16 64, i16 0, i16 0, i16 32, i16 168, i16 112, i16 168, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 248, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 64, i16 0, i16 0, i16 0, i16 248, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 0, i16 8, i16 8, i16 16, i16 32, i16 64, i16 128, i16 128, i16 0, i16 112, i16 136, i16 152, i16 168, i16 200, i16 136, i16 112, i16 0, i16 32, i16 96, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 64, i16 248, i16 0, i16 112, i16 136, i16 8, i16 48, i16 8, i16 136, i16 112, i16 0, i16 16, i16 48, i16 80, i16 144, i16 248, i16 16, i16 16, i16 0, i16 248, i16 128, i16 240, i16 8, i16 8, i16 136, i16 112, i16 0, i16 112, i16 136, i16 128, i16 240, i16 136, i16 136, i16 112, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 64, i16 64, i16 0, i16 112, i16 136, i16 136, i16 112, i16 136, i16 136, i16 112, i16 0, i16 112, i16 136, i16 136, i16 120, i16 8, i16 136, i16 112, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 64, i16 0, i16 16, i16 32, i16 64, i16 128, i16 64, i16 32, i16 16, i16 0, i16 0, i16 0, i16 248, i16 0, i16 248, i16 0, i16 0, i16 0, i16 128, i16 64, i16 32, i16 16, i16 32, i16 64, i16 128, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 0, i16 32, i16 0, i16 112, i16 136, i16 184, i16 168, i16 184, i16 128, i16 112, i16 0, i16 112, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 240, i16 136, i16 136, i16 240, i16 136, i16 136, i16 240, i16 0, i16 112, i16 136, i16 128, i16 128, i16 128, i16 136, i16 112, i16 0, i16 224, i16 144, i16 136, i16 136, i16 136, i16 144, i16 224, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 248, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 128, i16 176, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 112, i16 32, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 56, i16 16, i16 16, i16 16, i16 144, i16 144, i16 96, i16 0, i16 136, i16 144, i16 160, i16 192, i16 160, i16 144, i16 136, i16 0, i16 128, i16 128, i16 128, i16 128, i16 128, i16 128, i16 248, i16 0, i16 136, i16 216, i16 168, i16 136, i16 136, i16 136, i16 136, i16 0, i16 136, i16 200, i16 168, i16 152, i16 136, i16 136, i16 136, i16 0, i16 112, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 240, i16 136, i16 136, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 136, i16 136, i16 168, i16 144, i16 104, i16 0, i16 240, i16 136, i16 136, i16 240, i16 160, i16 144, i16 136, i16 0, i16 112, i16 136, i16 128, i16 112, i16 8, i16 136, i16 112, i16 0, i16 248, i16 32, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 80, i16 32, i16 0, i16 136, i16 136, i16 136, i16 168, i16 168, i16 216, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 80, i16 136, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 32, i16 32, i16 32, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 128, i16 248, i16 0, i16 48, i16 32, i16 32, i16 32, i16 32, i16 32, i16 48, i16 0, i16 128, i16 128, i16 64, i16 32, i16 16, i16 8, i16 8, i16 0, i16 48, i16 16, i16 16, i16 16, i16 16, i16 16, i16 48, i16 0, i16 32, i16 80, i16 136, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248], align 1
@TITLE_VT = internal constant %struct.DrawableVT { ptr @_title_reserve, ptr @_title_emit }, align 1
@FONT16 = internal unnamed_addr constant [2048 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 192, i16 192, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 768, i16 768, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 -4096, i16 -4096, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3840, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 3312, i16 15360, i16 15360, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 28, i16 28, i16 796, i16 127, i16 127, i16 796, i16 796, i16 127, i16 112, i16 112, i16 3184, i16 252, i16 252, i16 -28816, i16 -28816, i16 252, i16 127, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 0, i16 0, i16 252, i16 -28816, i16 -28816, i16 3184, i16 7168, i16 7168, i16 0, i16 0, i16 3, i16 63, i16 123, i16 1147, i16 63, i16 4111, i16 3075, i16 123, i16 192, i16 248, i16 8414, i16 16064, i16 2040, i16 248, i16 8414, i16 8414, i16 63, i16 7171, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 2040, i16 14272, i16 -512, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3585, i16 3, i16 7, i16 28, i16 56, i16 1904, i16 3808, i16 7392, i16 14528, i16 14464, i16 28672, i16 14, i16 284, i16 824, i16 1792, i16 3584, i16 0, i16 0, i16 0, i16 -8162, i16 -16354, i16 -32482, i16 286, i16 1792, i16 1792, i16 0, i16 0, i16 15, i16 31, i16 828, i16 828, i16 573, i16 31, i16 31, i16 63, i16 192, i16 224, i16 240, i16 2288, i16 7392, i16 15488, i16 30720, i16 -32648, i16 382, i16 3060, i16 3825, i16 1275, i16 127, i16 63, i16 7936, i16 3840, i16 248, i16 3824, i16 7904, i16 7392, i16 4332, i16 12492, i16 -1280, i16 -3328, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 7, i16 15, i16 15, i16 15, i16 15, i16 15, i16 240, i16 192, i16 15488, i16 -4096, i16 -8192, i16 -16384, i16 -16384, i16 -16384, i16 15, i16 7, i16 3, i16 256, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 16512, i16 192, i16 240, i16 -4096, i16 15360, i16 0, i16 0, i16 15, i16 3, i16 513, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 224, i16 240, i16 2288, i16 3312, i16 3312, i16 3312, i16 0, i16 1, i16 3, i16 15, i16 0, i16 768, i16 0, i16 0, i16 3312, i16 7392, i16 15552, i16 30720, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 51, i16 31, i16 15, i16 1027, i16 0, i16 0, i16 192, i16 192, i16 12492, i16 252, i16 1016, i16 16320, i16 15, i16 31, i16 51, i16 1027, i16 3072, i16 0, i16 0, i16 0, i16 1784, i16 252, i16 13004, i16 16320, i16 -3328, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 3, i16 63, i16 63, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 248, i16 248, i16 63, i16 3075, i16 3075, i16 3, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 16064, i16 16064, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 286, i16 828, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 28800, i16 -4096, i16 -8192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 -512, i16 -512, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7360, i16 14464, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7168, i16 14336, i16 28672, i16 -8192, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 828, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 15, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 1, i16 3, i16 15, i16 15, i16 513, i16 513, i16 1, i16 1, i16 240, i16 240, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 1, i16 1, i16 1, i16 1, i16 1, i16 1, i16 0, i16 0, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 31744, i16 31744, i16 15, i16 31, i16 318, i16 828, i16 3840, i16 3840, i16 3, i16 15, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 63, i16 510, i16 4080, i16 31, i16 318, i16 318, i16 318, i16 63, i16 63, i16 3840, i16 3840, i16 32640, i16 -1024, i16 -8192, i16 -32768, i16 255, i16 255, i16 -256, i16 -256, i16 15, i16 63, i16 824, i16 3840, i16 2055, i16 7, i16 256, i16 256, i16 252, i16 254, i16 -8161, i16 -4081, i16 510, i16 1020, i16 -7906, i16 -4081, i16 0, i16 0, i16 56, i16 60, i16 63, i16 31, i16 3840, i16 1792, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 15, i16 286, i16 62, i16 126, i16 510, i16 510, i16 8670, i16 24990, i16 -7906, i16 -7906, i16 828, i16 828, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 -16098, i16 -32482, i16 255, i16 255, i16 -7906, i16 -7906, i16 1792, i16 1792, i16 31, i16 63, i16 828, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 254, i16 254, i16 -256, i16 -256, i16 252, i16 254, i16 -8161, i16 -4081, i16 0, i16 0, i16 60, i16 62, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 63, i16 63, i16 318, i16 828, i16 254, i16 255, i16 -2041, i16 -256, i16 508, i16 254, i16 -4081, i16 -2041, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 -32761, i16 7, i16 7, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 31, i16 318, i16 892, i16 0, i16 1, i16 3, i16 7, i16 7, i16 7, i16 256, i16 256, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 28800, i16 -8192, i16 -8192, i16 15, i16 31, i16 828, i16 828, i16 828, i16 31, i16 15, i16 796, i16 252, i16 254, i16 -4081, i16 -4081, i16 15, i16 510, i16 1020, i16 -3826, i16 828, i16 828, i16 828, i16 828, i16 31, i16 15, i16 1792, i16 768, i16 -4081, i16 15, i16 15, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 318, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 31, i16 31, i16 15, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 270, i16 796, i16 824, i16 1792, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 15, i16 60, i16 828, i16 0, i16 0, i16 60, i16 240, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 15360, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 60, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 60, i16 0, i16 3, i16 15, i16 60, i16 768, i16 3840, i16 0, i16 0, i16 4080, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 31, i16 63, i16 828, i16 3840, i16 3840, i16 7, i16 7, i16 7, i16 240, i16 248, i16 -32644, i16 -32132, i16 2040, i16 4080, i16 16064, i16 31872, i16 256, i16 256, i16 7, i16 7, i16 7, i16 256, i16 256, i16 0, i16 -4096, i16 -8192, i16 128, i16 128, i16 24704, i16 -8192, i16 -8192, i16 0, i16 31, i16 63, i16 828, i16 573, i16 573, i16 573, i16 573, i16 573, i16 248, i16 252, i16 -15812, i16 4590, i16 494, i16 4590, i16 1020, i16 1016, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 0, i16 0, i16 0, i16 32512, i16 764, i16 248, i16 -256, i16 -512, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 892, i16 1020, i16 1020, i16 255, i16 255, i16 224, i16 240, i16 -32648, i16 -16324, i16 -32196, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -28928, i16 1792, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 0, i16 0, i16 28, i16 60, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -8164, i16 -3572, i16 -30976, i16 768, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 8988, i16 8988, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 60, i16 60, i16 828, i16 828, i16 828, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 255, i16 255, i16 16128, i16 16128, i16 12480, i16 12480, i16 12480, i16 12480, i16 252, i16 252, i16 -256, i16 -256, i16 63, i16 63, i16 3075, i16 3075, i16 3, i16 3, i16 51, i16 51, i16 252, i16 252, i16 4080, i16 4080, i16 3312, i16 3312, i16 3312, i16 3312, i16 3123, i16 3123, i16 63, i16 63, i16 31, i16 15, i16 1792, i16 768, i16 3312, i16 3312, i16 3312, i16 3312, i16 7392, i16 15552, i16 -2048, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 765, i16 255, i16 255, i16 255, i16 28, i16 60, i16 1912, i16 4080, i16 7904, i16 15552, i16 30848, i16 12480, i16 255, i16 765, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 224, i16 240, i16 248, i16 124, i16 572, i16 828, i16 3840, i16 3840, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 0, i16 0, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 248, i16 252, i16 254, i16 2295, i16 3315, i16 3315, i16 3315, i16 3315, i16 60, i16 124, i16 1020, i16 988, i16 9116, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 15360, i16 15360, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 -6400, i16 -6400, i16 240, i16 248, i16 252, i16 254, i16 255, i16 255, i16 2295, i16 3315, i16 60, i16 60, i16 828, i16 828, i16 828, i16 956, i16 1020, i16 1020, i16 3313, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 15360, i16 15360, i16 1020, i16 1020, i16 892, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -31972, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -512, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 224, i16 240, i16 -32648, i16 -15304, i16 -31176, i16 1592, i16 1592, i16 1592, i16 765, i16 765, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 1784, i16 1784, i16 17976, i16 1656, i16 764, i16 764, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 63, i16 127, i16 2040, i16 4080, i16 1784, i16 255, i16 127, i16 63, i16 248, i16 252, i16 -15812, i16 -256, i16 3840, i16 240, i16 248, i16 252, i16 7936, i16 3840, i16 224, i16 255, i16 255, i16 127, i16 16128, i16 7936, i16 -32132, i16 -15556, i16 892, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 -4096, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 28, i16 28, i16 796, i16 796, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 510, i16 255, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 828, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 248, i16 248, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 124, i16 124, i16 1912, i16 1912, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 572, i16 63, i16 31, i16 15, i16 7, i16 768, i16 256, i16 1656, i16 3824, i16 3824, i16 7392, i16 15552, i16 30848, i16 -4096, i16 -8192, i16 243, i16 243, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 156, i16 156, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 2295, i16 255, i16 510, i16 892, i16 16128, i16 7936, i16 25500, i16 25500, i16 9180, i16 1020, i16 1020, i16 -30856, i16 -16640, i16 7680, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 15, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 14528, i16 31, i16 63, i16 892, i16 2040, i16 4080, i16 3824, i16 15360, i16 15360, i16 4320, i16 240, i16 248, i16 -32644, i16 572, i16 828, i16 3840, i16 3840, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 7, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 7, i16 7, i16 7, i16 7, i16 7, i16 7, i16 256, i16 256, i16 28800, i16 24704, i16 24704, i16 24704, i16 24704, i16 24704, i16 -8192, i16 -8192, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 1, i16 3, i16 7, i16 252, i16 252, i16 1020, i16 -31876, i16 2040, i16 4080, i16 7904, i16 15552, i16 15, i16 31, i16 318, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 30848, i16 -4096, i16 -8192, i16 252, i16 252, i16 1020, i16 -256, i16 -256, i16 31, i16 31, i16 286, i16 286, i16 286, i16 286, i16 286, i16 286, i16 224, i16 224, i16 -2048, i16 -2048, i16 -32768, i16 -32768, i16 -32768, i16 -32768, i16 286, i16 286, i16 286, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 -32768, i16 -32768, i16 -32768, i16 224, i16 224, i16 -2048, i16 -2048, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 3, i16 1, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 128, i16 192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 768, i16 256, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 0, i16 0, i16 0, i16 224, i16 224, i16 2288, i16 2288, i16 3312, i16 3312, i16 3312, i16 3312, i16 0, i16 0, i16 0, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 3312, i16 3312, i16 3312, i16 7392, i16 7392, i16 -2048, i16 -2048, i16 0, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1840, i16 3584, i16 3072, i16 192, i16 224, i16 -32656, i16 -16328, i16 -32740, i16 524, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 127, i16 127, i16 7936, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 -512], align 1
@title_end._title_bg_black = internal constant i16 0, align 1
@bitboard64_state.0 = internal unnamed_addr global i64 0, align 1
@bitboard64_state.1 = internal unnamed_addr global i64 0, align 1
@bitboard64_state.2 = internal unnamed_addr global i64 0, align 1
@bitboard64_opaque = internal global i64 0, align 8
@put_hex.H = internal unnamed_addr constant [17 x i8] c"0123456789ABCDEF\00", align 1
@__const.put_hex.b = private unnamed_addr constant [9 x i8] c"CRC=\00\00\00\00\00", align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [9 x i8], align 1
  store volatile i8 -113, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  br label %2

2:                                                ; preds = %6, %0
  %3 = phi i16 [ 8449, %0 ], [ %7, %6 ]
  switch i16 %3, label %4 [
    i16 8452, label %6
    i16 8470, label %6
    i16 8471, label %6
    i16 8472, label %6
    i16 8473, label %6
    i16 8481, label %6
    i16 8482, label %6
  ]

4:                                                ; preds = %2
  %5 = inttoptr i16 %3 to ptr
  store volatile i8 0, ptr %5, align 1, !tbaa !6
  br label %6

6:                                                ; preds = %4, %2, %2, %2, %2, %2, %2, %2
  %7 = add nuw nsw i16 %3, 1
  %8 = icmp eq i16 %7, 8500
  br i1 %8, label %9, label %2, !llvm.loop !7

9:                                                ; preds = %6
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) getelementptr inbounds nuw (i8, ptr @main.a, i16 176), i8 0, i64 6, i1 false)
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  store volatile i8 1, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 -127, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !6
  store ptr @CANVAS_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), align 1, !tbaa !15
  store i8 4, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !19
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4299), align 1, !tbaa !20
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4301), align 1, !tbaa !21
  store i8 8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4303), align 1, !tbaa !22
  store i8 6, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4304), align 1, !tbaa !23
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(4096) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i16 4096, i1 false), !tbaa !6
  store i16 -1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  store ptr @TEXT_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !26
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !28
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4308), align 1, !tbaa !29
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4310), align 1, !tbaa !6
  store i8 25, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4311), align 1, !tbaa !6
  br label %10

10:                                               ; preds = %10, %9
  %11 = phi i8 [ 0, %9 ], [ %17, %10 ]
  %12 = phi i16 [ 0, %9 ], [ %15, %10 ]
  %13 = zext i8 %11 to i16
  %14 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4312), i16 %13
  store i16 256, ptr %14, align 1, !tbaa !2
  %15 = add nuw nsw i16 %12, 1
  %16 = icmp eq i16 %15, 64
  %17 = add nuw i8 %11, 2
  br i1 %16, label %18, label %10, !llvm.loop !30

18:                                               ; preds = %10
  store i8 3, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %19 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %20 = icmp eq i8 %19, 0
  br i1 %20, label %22, label %21

21:                                               ; preds = %18
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %22

22:                                               ; preds = %21, %18
  %23 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %24 = icmp ult i8 %23, 4
  br i1 %24, label %25, label %29

25:                                               ; preds = %22
  %26 = zext nneg i8 %23 to i16
  %27 = add nuw nsw i8 %23, 1
  store i8 %27, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %28 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %26
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr %28, align 1, !tbaa !35
  br label %29

29:                                               ; preds = %22, %25
  tail call void @_canvas_reserve(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr nonnull poison) #14, !inline_history !37
  %30 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %31 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !39
  %32 = or i8 %31, %30
  store i8 %32, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %32, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %33 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %34 = icmp eq i8 %33, 0
  br i1 %34, label %36, label %35

35:                                               ; preds = %29
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %36

36:                                               ; preds = %35, %29
  %37 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %38 = icmp ult i8 %37, 4
  br i1 %38, label %39, label %43

39:                                               ; preds = %36
  %40 = zext nneg i8 %37 to i16
  %41 = add nuw nsw i8 %37, 1
  store i8 %41, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %42 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %40
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr %42, align 1, !tbaa !35
  br label %43

43:                                               ; preds = %36, %39
  %44 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !40
  %45 = load ptr, ptr %44, align 1, !tbaa !41
  tail call void %45(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 178)) #14, !inline_history !37
  %46 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %47 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !39
  %48 = or i8 %47, %46
  store i8 %48, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %48, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %49 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %50 = icmp ugt i8 %49, 15
  br i1 %50, label %62, label %51

51:                                               ; preds = %43
  %52 = zext nneg i8 %49 to i16
  %53 = add nuw nsw i8 %49, 1
  store i8 %53, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %54 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %52
  %55 = getelementptr inbounds nuw i8, ptr %54, i16 10
  store i8 1, ptr %55, align 1, !tbaa !44
  store i16 0, ptr %54, align 1, !tbaa !46
  %56 = getelementptr inbounds nuw i8, ptr %54, i16 9
  store i8 0, ptr %56, align 1, !tbaa !47
  %57 = getelementptr inbounds nuw i8, ptr %54, i16 7
  store i8 34, ptr %57, align 1, !tbaa !48
  %58 = getelementptr inbounds nuw i8, ptr %54, i16 8
  store i8 0, ptr %58, align 1, !tbaa !49
  %59 = getelementptr inbounds nuw i8, ptr %54, i16 2
  store i16 ptrtoint (ptr @pal to i16), ptr %59, align 1, !tbaa !50
  %60 = getelementptr inbounds nuw i8, ptr %54, i16 6
  store i8 0, ptr %60, align 1, !tbaa !51
  %61 = getelementptr inbounds nuw i8, ptr %54, i16 4
  store i16 8, ptr %61, align 1, !tbaa !52
  br label %62

62:                                               ; preds = %43, %51
  br label %63

63:                                               ; preds = %62, %73
  %64 = phi i8 [ %81, %73 ], [ 0, %62 ]
  %65 = phi i8 [ %80, %73 ], [ 0, %62 ]
  %66 = phi i8 [ %79, %73 ], [ 66, %62 ]
  %67 = zext i8 %66 to i16
  %68 = icmp ugt i8 %66, 31
  br i1 %68, label %69, label %73

69:                                               ; preds = %63
  %70 = icmp ult i8 %66, 96
  br i1 %70, label %71, label %73

71:                                               ; preds = %69
  %72 = add nuw nsw i16 %67, 224
  br label %73

73:                                               ; preds = %71, %69, %63
  %74 = phi i16 [ %72, %71 ], [ 256, %69 ], [ 256, %63 ]
  %75 = zext nneg i8 %65 to i16
  %76 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4316), i16 %75
  store i16 %74, ptr %76, align 1, !tbaa !2
  %77 = zext nneg i8 %64 to i16
  %78 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @.str, i16 1), i16 %77
  %79 = load i8, ptr %78, align 1, !tbaa !6
  %80 = add nuw nsw i8 %65, 2
  %81 = add nuw nsw i8 %64, 1
  %82 = icmp eq i8 %81, 20
  br i1 %82, label %83, label %63, !llvm.loop !53

83:                                               ; preds = %73
  %84 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %85 = or i8 %84, 1
  store i8 %85, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  store ptr @TITLE_VT, ptr @main.title, align 1, !tbaa !54
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !58
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 3), align 1, !tbaa !59
  store ptr @.str.2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 5), align 1, !tbaa !60
  store ptr @.str.2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 7), align 1, !tbaa !61
  store i8 11, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 11), align 1, !tbaa !62
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 9), align 1, !tbaa !63
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 12), align 1, !tbaa !64
  store i16 96, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 13), align 1, !tbaa !65
  store i16 112, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 15), align 1, !tbaa !66
  store i16 16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 17), align 1, !tbaa !67
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 28), align 1, !tbaa !68
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !69
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !70
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !71
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !72
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !73
  store i16 32767, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 34), align 1, !tbaa !74
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 36), align 1, !tbaa !75
  %86 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %87 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %88 = icmp eq i8 %87, 0
  br i1 %88, label %90, label %89

89:                                               ; preds = %83
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %90

90:                                               ; preds = %89, %83
  %91 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %92 = icmp ult i8 %91, 4
  br i1 %92, label %93, label %97

93:                                               ; preds = %90
  %94 = zext nneg i8 %91 to i16
  %95 = add nuw nsw i8 %91, 1
  store i8 %95, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %96 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %94
  store ptr @main.title, ptr %96, align 1, !tbaa !35
  br label %97

97:                                               ; preds = %93, %90
  tail call void @_title_reserve(ptr noundef nonnull @main.title, ptr nonnull poison) #14, !inline_history !37
  %98 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %99 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %100 = or i8 %99, %98
  store volatile i8 %100, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store i8 %86, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !76
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 2, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 24, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  br label %101

101:                                              ; preds = %129, %97
  %102 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %103 = icmp eq i8 %102, 0
  br i1 %103, label %115, label %104

104:                                              ; preds = %101, %104
  %105 = phi i8 [ %112, %104 ], [ 0, %101 ]
  %106 = zext i8 %105 to i16
  %107 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %106
  %108 = load ptr, ptr %107, align 1, !tbaa !35
  %109 = load ptr, ptr %108, align 1, !tbaa !40
  %110 = getelementptr inbounds nuw i8, ptr %109, i16 2
  %111 = load ptr, ptr %110, align 1, !tbaa !77
  tail call void %111(ptr noundef nonnull %108, ptr noundef nonnull @main.a) #14, !inline_history !78
  %112 = add nuw i8 %105, 1
  %113 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %114 = icmp ult i8 %112, %113
  br i1 %114, label %104, label %115, !llvm.loop !79

115:                                              ; preds = %104, %101
  %116 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %117

117:                                              ; preds = %117, %115
  %118 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %119 = icmp sgt i8 %118, -1
  br i1 %119, label %117, label %120, !llvm.loop !80

120:                                              ; preds = %117
  tail call fastcc void @upq_flush() #15
  %121 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %122 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %123 = icmp ult i8 %121, %122
  br i1 %123, label %126, label %124

124:                                              ; preds = %120
  %125 = icmp ugt i8 %121, %122
  br i1 %125, label %126, label %129

126:                                              ; preds = %124, %120
  %127 = phi i8 [ 1, %120 ], [ -1, %124 ]
  %128 = add i8 %127, %121
  store i8 %128, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %129

129:                                              ; preds = %126, %124
  %130 = phi i8 [ %121, %124 ], [ %128, %126 ]
  %131 = and i8 %130, 15
  store volatile i8 %131, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %132 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %133 = icmp eq i8 %132, 15
  br i1 %133, label %134, label %101, !llvm.loop !81

134:                                              ; preds = %129
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !72
  %135 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !73
  %136 = icmp eq i8 %135, -1
  br i1 %136, label %174, label %137

137:                                              ; preds = %134, %166
  %138 = phi i8 [ %169, %166 ], [ 0, %134 ]
  %139 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %140 = icmp eq i8 %139, 0
  br i1 %140, label %152, label %141

141:                                              ; preds = %137, %141
  %142 = phi i8 [ %149, %141 ], [ 0, %137 ]
  %143 = zext i8 %142 to i16
  %144 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %143
  %145 = load ptr, ptr %144, align 1, !tbaa !35
  %146 = load ptr, ptr %145, align 1, !tbaa !40
  %147 = getelementptr inbounds nuw i8, ptr %146, i16 2
  %148 = load ptr, ptr %147, align 1, !tbaa !77
  tail call void %148(ptr noundef nonnull %145, ptr noundef nonnull @main.a) #14, !inline_history !82
  %149 = add nuw i8 %142, 1
  %150 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %151 = icmp ult i8 %149, %150
  br i1 %151, label %141, label %152, !llvm.loop !79

152:                                              ; preds = %141, %137
  %153 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %154

154:                                              ; preds = %154, %152
  %155 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %156 = icmp sgt i8 %155, -1
  br i1 %156, label %154, label %157, !llvm.loop !80

157:                                              ; preds = %154
  tail call fastcc void @upq_flush() #15
  %158 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %159 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %160 = icmp ult i8 %158, %159
  br i1 %160, label %163, label %161

161:                                              ; preds = %157
  %162 = icmp ugt i8 %158, %159
  br i1 %162, label %163, label %166

163:                                              ; preds = %161, %157
  %164 = phi i8 [ 1, %157 ], [ -1, %161 ]
  %165 = add i8 %164, %158
  store i8 %165, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %166

166:                                              ; preds = %163, %161
  %167 = phi i8 [ %158, %161 ], [ %165, %163 ]
  %168 = and i8 %167, 15
  store volatile i8 %168, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %169 = add nuw i8 %138, 1
  %170 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !73
  %171 = icmp ne i8 %170, -1
  %172 = icmp ult i8 %138, -57
  %173 = select i1 %171, i1 %172, i1 false
  br i1 %173, label %137, label %174, !llvm.loop !83

174:                                              ; preds = %166, %134
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !72
  br label %175

175:                                              ; preds = %205, %174
  %176 = phi i16 [ 30, %174 ], [ %177, %205 ]
  %177 = add nsw i16 %176, -1
  %178 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %179 = icmp eq i8 %178, 0
  br i1 %179, label %191, label %180

180:                                              ; preds = %175, %180
  %181 = phi i8 [ %188, %180 ], [ 0, %175 ]
  %182 = zext i8 %181 to i16
  %183 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %182
  %184 = load ptr, ptr %183, align 1, !tbaa !35
  %185 = load ptr, ptr %184, align 1, !tbaa !40
  %186 = getelementptr inbounds nuw i8, ptr %185, i16 2
  %187 = load ptr, ptr %186, align 1, !tbaa !77
  tail call void %187(ptr noundef nonnull %184, ptr noundef nonnull @main.a) #14, !inline_history !84
  %188 = add nuw i8 %181, 1
  %189 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %190 = icmp ult i8 %188, %189
  br i1 %190, label %180, label %191, !llvm.loop !79

191:                                              ; preds = %180, %175
  %192 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %193

193:                                              ; preds = %193, %191
  %194 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %195 = icmp sgt i8 %194, -1
  br i1 %195, label %193, label %196, !llvm.loop !80

196:                                              ; preds = %193
  tail call fastcc void @upq_flush() #15
  %197 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %198 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %199 = icmp ult i8 %197, %198
  br i1 %199, label %202, label %200

200:                                              ; preds = %196
  %201 = icmp ugt i8 %197, %198
  br i1 %201, label %202, label %205

202:                                              ; preds = %200, %196
  %203 = phi i8 [ 1, %196 ], [ -1, %200 ]
  %204 = add i8 %203, %197
  store i8 %204, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %205

205:                                              ; preds = %202, %200
  %206 = phi i8 [ %197, %200 ], [ %204, %202 ]
  %207 = and i8 %206, 15
  store volatile i8 %207, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %208 = icmp eq i16 %177, 0
  br i1 %208, label %209, label %175, !llvm.loop !85

209:                                              ; preds = %205
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !70
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !71
  br label %213

210:                                              ; preds = %242
  %211 = add nuw nsw i8 %214, 1
  %212 = icmp eq i8 %211, 90
  br i1 %212, label %247, label %213, !llvm.loop !86

213:                                              ; preds = %210, %209
  %214 = phi i8 [ 0, %209 ], [ %211, %210 ]
  %215 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %216 = icmp eq i8 %215, 0
  br i1 %216, label %228, label %217

217:                                              ; preds = %213, %217
  %218 = phi i8 [ %225, %217 ], [ 0, %213 ]
  %219 = zext i8 %218 to i16
  %220 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %219
  %221 = load ptr, ptr %220, align 1, !tbaa !35
  %222 = load ptr, ptr %221, align 1, !tbaa !40
  %223 = getelementptr inbounds nuw i8, ptr %222, i16 2
  %224 = load ptr, ptr %223, align 1, !tbaa !77
  tail call void %224(ptr noundef nonnull %221, ptr noundef nonnull @main.a) #14, !inline_history !87
  %225 = add nuw i8 %218, 1
  %226 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %227 = icmp ult i8 %225, %226
  br i1 %227, label %217, label %228, !llvm.loop !79

228:                                              ; preds = %217, %213
  %229 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %230

230:                                              ; preds = %230, %228
  %231 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %232 = icmp sgt i8 %231, -1
  br i1 %232, label %230, label %233, !llvm.loop !80

233:                                              ; preds = %230
  tail call fastcc void @upq_flush() #15
  %234 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %235 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %236 = icmp ult i8 %234, %235
  br i1 %236, label %239, label %237

237:                                              ; preds = %233
  %238 = icmp ugt i8 %234, %235
  br i1 %238, label %239, label %242

239:                                              ; preds = %237, %233
  %240 = phi i8 [ 1, %233 ], [ -1, %237 ]
  %241 = add i8 %240, %234
  store i8 %241, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %242

242:                                              ; preds = %239, %237
  %243 = phi i8 [ %234, %237 ], [ %241, %239 ]
  %244 = and i8 %243, 15
  store volatile i8 %244, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %245 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 19), align 1, !tbaa !88
  %246 = icmp sgt i16 %245, 3583
  br i1 %246, label %247, label %210

247:                                              ; preds = %242, %210
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !70
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %248 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %249 = icmp eq i8 %248, 0
  br i1 %249, label %283, label %250

250:                                              ; preds = %247, %278
  %251 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %252 = icmp eq i8 %251, 0
  br i1 %252, label %264, label %253

253:                                              ; preds = %250, %253
  %254 = phi i8 [ %261, %253 ], [ 0, %250 ]
  %255 = zext i8 %254 to i16
  %256 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %255
  %257 = load ptr, ptr %256, align 1, !tbaa !35
  %258 = load ptr, ptr %257, align 1, !tbaa !40
  %259 = getelementptr inbounds nuw i8, ptr %258, i16 2
  %260 = load ptr, ptr %259, align 1, !tbaa !77
  tail call void %260(ptr noundef nonnull %257, ptr noundef nonnull @main.a) #14, !inline_history !89
  %261 = add nuw i8 %254, 1
  %262 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %263 = icmp ult i8 %261, %262
  br i1 %263, label %253, label %264, !llvm.loop !79

264:                                              ; preds = %253, %250
  %265 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %266

266:                                              ; preds = %266, %264
  %267 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %268 = icmp sgt i8 %267, -1
  br i1 %268, label %266, label %269, !llvm.loop !80

269:                                              ; preds = %266
  tail call fastcc void @upq_flush() #15
  %270 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %271 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %272 = icmp ult i8 %270, %271
  br i1 %272, label %275, label %273

273:                                              ; preds = %269
  %274 = icmp ugt i8 %270, %271
  br i1 %274, label %275, label %278

275:                                              ; preds = %273, %269
  %276 = phi i8 [ 1, %269 ], [ -1, %273 ]
  %277 = add i8 %276, %270
  store i8 %277, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %278

278:                                              ; preds = %275, %273
  %279 = phi i8 [ %270, %273 ], [ %277, %275 ]
  %280 = and i8 %279, 15
  store volatile i8 %280, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %281 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %282 = icmp eq i8 %281, 0
  br i1 %282, label %283, label %250, !llvm.loop !81

283:                                              ; preds = %278, %247
  %284 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !76
  %285 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %286 = or i8 %285, %284
  %287 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %288 = xor i8 %287, -1
  %289 = and i8 %286, %288
  store i8 %289, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %289, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !69
  %290 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %291 = icmp ugt i8 %290, 15
  br i1 %291, label %303, label %292

292:                                              ; preds = %283
  %293 = zext nneg i8 %290 to i16
  %294 = add nuw nsw i8 %290, 1
  store i8 %294, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %295 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %293
  %296 = getelementptr inbounds nuw i8, ptr %295, i16 10
  store i8 1, ptr %296, align 1, !tbaa !44
  store i16 0, ptr %295, align 1, !tbaa !46
  %297 = getelementptr inbounds nuw i8, ptr %295, i16 9
  store i8 0, ptr %297, align 1, !tbaa !47
  %298 = getelementptr inbounds nuw i8, ptr %295, i16 7
  store i8 34, ptr %298, align 1, !tbaa !48
  %299 = getelementptr inbounds nuw i8, ptr %295, i16 8
  store i8 0, ptr %299, align 1, !tbaa !49
  %300 = getelementptr inbounds nuw i8, ptr %295, i16 2
  store i16 ptrtoint (ptr @title_end._title_bg_black to i16), ptr %300, align 1, !tbaa !50
  %301 = getelementptr inbounds nuw i8, ptr %295, i16 6
  store i8 0, ptr %301, align 1, !tbaa !51
  %302 = getelementptr inbounds nuw i8, ptr %295, i16 4
  store i16 2, ptr %302, align 1, !tbaa !52
  br label %303

303:                                              ; preds = %283, %292
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  store i64 1, ptr @bitboard64_state.0, align 1, !tbaa !90
  store i64 1, ptr @bitboard64_state.1, align 1, !tbaa !93
  br label %304

304:                                              ; preds = %304, %303
  %305 = phi i16 [ 0, %303 ], [ %308, %304 ]
  %306 = phi i16 [ -20192, %303 ], [ %307, %304 ]
  %307 = tail call fastcc i16 @bitboard64_step(i16 noundef %306, i16 noundef %305) #15
  %308 = add nuw nsw i16 %305, 1
  %309 = icmp eq i16 %308, 96
  br i1 %309, label %310, label %304, !llvm.loop !94

310:                                              ; preds = %304
  store volatile i16 %307, ptr @corpus_result, align 1, !tbaa !2
  %311 = load volatile i16, ptr @corpus_result, align 1, !tbaa !2
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #16
  call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(9) %1, ptr noundef nonnull align 1 dereferenceable(9) @__const.put_hex.b, i16 9, i1 false)
  %312 = lshr i16 %311, 12
  %313 = getelementptr inbounds nuw i8, ptr @put_hex.H, i16 %312
  %314 = load i8, ptr %313, align 1, !tbaa !6
  %315 = getelementptr inbounds nuw i8, ptr %1, i16 4
  store i8 %314, ptr %315, align 1, !tbaa !6
  %316 = lshr i16 %311, 8
  %317 = and i16 %316, 15
  %318 = getelementptr inbounds nuw i8, ptr @put_hex.H, i16 %317
  %319 = load i8, ptr %318, align 1, !tbaa !6
  %320 = getelementptr inbounds nuw i8, ptr %1, i16 5
  store i8 %319, ptr %320, align 1, !tbaa !6
  %321 = lshr i16 %311, 4
  %322 = and i16 %321, 15
  %323 = getelementptr inbounds nuw i8, ptr @put_hex.H, i16 %322
  %324 = load i8, ptr %323, align 1, !tbaa !6
  %325 = getelementptr inbounds nuw i8, ptr %1, i16 6
  store i8 %324, ptr %325, align 1, !tbaa !6
  %326 = and i16 %311, 15
  %327 = getelementptr inbounds nuw i8, ptr @put_hex.H, i16 %326
  %328 = load i8, ptr %327, align 1, !tbaa !6
  %329 = getelementptr inbounds nuw i8, ptr %1, i16 7
  store i8 %328, ptr %329, align 1, !tbaa !6
  %330 = getelementptr inbounds nuw i8, ptr %1, i16 1
  br label %337

331:                                              ; preds = %348
  %332 = add nuw nsw i8 %339, 1
  %333 = add nuw nsw i8 %341, 2
  %334 = add nuw nsw i8 %342, 1
  %335 = zext i8 %354 to i16
  %336 = icmp eq i8 %332, 32
  br i1 %336, label %356, label %337, !llvm.loop !53

337:                                              ; preds = %310, %331
  %338 = phi i16 [ 67, %310 ], [ %335, %331 ]
  %339 = phi i8 [ 1, %310 ], [ %332, %331 ]
  %340 = phi i8 [ 67, %310 ], [ %354, %331 ]
  %341 = phi i8 [ 0, %310 ], [ %333, %331 ]
  %342 = phi i8 [ 0, %310 ], [ %334, %331 ]
  %343 = icmp ugt i8 %340, 31
  br i1 %343, label %344, label %348

344:                                              ; preds = %337
  %345 = icmp ult i8 %340, 96
  br i1 %345, label %346, label %348

346:                                              ; preds = %344
  %347 = add nuw nsw i16 %338, 224
  br label %348

348:                                              ; preds = %346, %344, %337
  %349 = phi i16 [ %347, %346 ], [ 256, %344 ], [ 256, %337 ]
  %350 = zext nneg i8 %341 to i16
  %351 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4378), i16 %350
  store i16 %349, ptr %351, align 1, !tbaa !2
  %352 = zext nneg i8 %342 to i16
  %353 = getelementptr i8, ptr %330, i16 %352
  %354 = load i8, ptr %353, align 1, !tbaa !6
  %355 = icmp eq i8 %354, 0
  br i1 %355, label %356, label %331, !llvm.loop !53

356:                                              ; preds = %331, %348
  %357 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %358 = or i8 %357, 2
  store i8 %358, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #16
  store i64 1, ptr @bitboard64_state.0, align 1, !tbaa !90
  store i64 1, ptr @bitboard64_state.1, align 1, !tbaa !93
  store i64 132096, ptr @bitboard64_state.2, align 1, !tbaa !95
  store i16 -20192, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), align 1, !tbaa !96
  br label %359

359:                                              ; preds = %539, %356
  %360 = phi i16 [ %542, %539 ], [ -20192, %356 ]
  %361 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !98
  %362 = add i16 %361, 1
  store i16 %362, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !98
  %363 = tail call fastcc i16 @bitboard64_step(i16 noundef %360, i16 noundef %361) #15
  store i16 %363, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), align 1, !tbaa !96
  %364 = load i64, ptr @bitboard64_state.1, align 1, !tbaa !93
  %365 = load i64, ptr @bitboard64_state.2, align 1, !tbaa !95
  %366 = load i64, ptr @bitboard64_state.0, align 1, !tbaa !90
  br label %367

367:                                              ; preds = %402, %359
  %368 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 485), %359 ], [ %435, %402 ]
  %369 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 483), %359 ], [ %434, %402 ]
  %370 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 481), %359 ], [ %433, %402 ]
  %371 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 479), %359 ], [ %432, %402 ]
  %372 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 477), %359 ], [ %431, %402 ]
  %373 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 475), %359 ], [ %430, %402 ]
  %374 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 473), %359 ], [ %429, %402 ]
  %375 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 471), %359 ], [ %428, %402 ]
  %376 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 469), %359 ], [ %427, %402 ]
  %377 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 467), %359 ], [ %426, %402 ]
  %378 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 465), %359 ], [ %425, %402 ]
  %379 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 463), %359 ], [ %424, %402 ]
  %380 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 461), %359 ], [ %423, %402 ]
  %381 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 459), %359 ], [ %422, %402 ]
  %382 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 457), %359 ], [ %421, %402 ]
  %383 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 455), %359 ], [ %420, %402 ]
  %384 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 229), %359 ], [ %419, %402 ]
  %385 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 227), %359 ], [ %418, %402 ]
  %386 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 225), %359 ], [ %417, %402 ]
  %387 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 223), %359 ], [ %416, %402 ]
  %388 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 221), %359 ], [ %415, %402 ]
  %389 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 219), %359 ], [ %414, %402 ]
  %390 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 217), %359 ], [ %413, %402 ]
  %391 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 215), %359 ], [ %412, %402 ]
  %392 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 213), %359 ], [ %411, %402 ]
  %393 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 211), %359 ], [ %410, %402 ]
  %394 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 209), %359 ], [ %409, %402 ]
  %395 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 207), %359 ], [ %408, %402 ]
  %396 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 205), %359 ], [ %407, %402 ]
  %397 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 203), %359 ], [ %406, %402 ]
  %398 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 201), %359 ], [ %405, %402 ]
  %399 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 199), %359 ], [ %404, %402 ]
  %400 = phi i8 [ 0, %359 ], [ %403, %402 ]
  %401 = shl nuw nsw i8 %400, 3
  br label %437

402:                                              ; preds = %471
  %403 = add nuw nsw i8 %400, 1
  %404 = getelementptr i8, ptr %399, i16 512
  %405 = getelementptr i8, ptr %398, i16 512
  %406 = getelementptr i8, ptr %397, i16 512
  %407 = getelementptr i8, ptr %396, i16 512
  %408 = getelementptr i8, ptr %395, i16 512
  %409 = getelementptr i8, ptr %394, i16 512
  %410 = getelementptr i8, ptr %393, i16 512
  %411 = getelementptr i8, ptr %392, i16 512
  %412 = getelementptr i8, ptr %391, i16 512
  %413 = getelementptr i8, ptr %390, i16 512
  %414 = getelementptr i8, ptr %389, i16 512
  %415 = getelementptr i8, ptr %388, i16 512
  %416 = getelementptr i8, ptr %387, i16 512
  %417 = getelementptr i8, ptr %386, i16 512
  %418 = getelementptr i8, ptr %385, i16 512
  %419 = getelementptr i8, ptr %384, i16 512
  %420 = getelementptr i8, ptr %383, i16 512
  %421 = getelementptr i8, ptr %382, i16 512
  %422 = getelementptr i8, ptr %381, i16 512
  %423 = getelementptr i8, ptr %380, i16 512
  %424 = getelementptr i8, ptr %379, i16 512
  %425 = getelementptr i8, ptr %378, i16 512
  %426 = getelementptr i8, ptr %377, i16 512
  %427 = getelementptr i8, ptr %376, i16 512
  %428 = getelementptr i8, ptr %375, i16 512
  %429 = getelementptr i8, ptr %374, i16 512
  %430 = getelementptr i8, ptr %373, i16 512
  %431 = getelementptr i8, ptr %372, i16 512
  %432 = getelementptr i8, ptr %371, i16 512
  %433 = getelementptr i8, ptr %370, i16 512
  %434 = getelementptr i8, ptr %369, i16 512
  %435 = getelementptr i8, ptr %368, i16 512
  %436 = icmp eq i8 %403, 8
  br i1 %436, label %511, label %367, !llvm.loop !99

437:                                              ; preds = %471, %367
  %438 = phi i8 [ 0, %367 ], [ %510, %471 ]
  %439 = phi i8 [ 0, %367 ], [ %508, %471 ]
  %440 = add nuw nsw i8 %439, %401
  %441 = icmp eq i8 %440, 0
  br i1 %441, label %448, label %442

442:                                              ; preds = %437, %442
  %443 = phi i64 [ %446, %442 ], [ 1, %437 ]
  %444 = phi i8 [ %445, %442 ], [ %440, %437 ]
  %445 = add nsw i8 %444, -1
  %446 = shl i64 %443, 1
  %447 = icmp eq i8 %445, 0
  br i1 %447, label %448, label %442, !llvm.loop !100

448:                                              ; preds = %442, %437
  %449 = phi i64 [ 1, %437 ], [ %446, %442 ]
  %450 = xor i8 %439, %400
  %451 = and i8 %450, 1
  %452 = and i64 %449, %364
  %453 = icmp eq i64 %452, 0
  br i1 %453, label %455, label %454

454:                                              ; preds = %448
  br label %455

455:                                              ; preds = %454, %448
  %456 = phi i8 [ 1, %454 ], [ %451, %448 ]
  %457 = and i64 %449, %365
  %458 = icmp eq i64 %457, 0
  br i1 %458, label %460, label %459

459:                                              ; preds = %455
  br label %460

460:                                              ; preds = %459, %455
  %461 = phi i8 [ 2, %459 ], [ %456, %455 ]
  %462 = and i64 %449, %366
  %463 = icmp eq i64 %462, 0
  br i1 %463, label %464, label %471

464:                                              ; preds = %460
  %465 = freeze i8 %461
  %466 = and i8 %465, 1
  %467 = icmp eq i8 %466, 0
  %468 = select i1 %467, i16 0, i16 255
  %469 = icmp ult i8 %465, 2
  br i1 %469, label %470, label %471

470:                                              ; preds = %464
  br label %471

471:                                              ; preds = %460, %470, %464
  %472 = phi i16 [ %468, %470 ], [ %468, %464 ], [ 255, %460 ]
  %473 = phi i16 [ 0, %470 ], [ -256, %464 ], [ -256, %460 ]
  %474 = zext i8 %438 to i16
  %475 = getelementptr i8, ptr %399, i16 %474
  %476 = or disjoint i16 %473, %472
  store i16 %476, ptr %475, align 1, !tbaa !2
  %477 = getelementptr i8, ptr %398, i16 %474
  store i16 %476, ptr %477, align 1, !tbaa !2
  %478 = getelementptr i8, ptr %397, i16 %474
  store i16 %476, ptr %478, align 1, !tbaa !2
  %479 = getelementptr i8, ptr %396, i16 %474
  store i16 %476, ptr %479, align 1, !tbaa !2
  %480 = getelementptr i8, ptr %395, i16 %474
  store i16 %476, ptr %480, align 1, !tbaa !2
  %481 = getelementptr i8, ptr %394, i16 %474
  store i16 %476, ptr %481, align 1, !tbaa !2
  %482 = getelementptr i8, ptr %393, i16 %474
  store i16 %476, ptr %482, align 1, !tbaa !2
  %483 = getelementptr i8, ptr %392, i16 %474
  store i16 %476, ptr %483, align 1, !tbaa !2
  %484 = getelementptr i8, ptr %391, i16 %474
  store i16 %476, ptr %484, align 1, !tbaa !2
  %485 = getelementptr i8, ptr %390, i16 %474
  store i16 %476, ptr %485, align 1, !tbaa !2
  %486 = getelementptr i8, ptr %389, i16 %474
  store i16 %476, ptr %486, align 1, !tbaa !2
  %487 = getelementptr i8, ptr %388, i16 %474
  store i16 %476, ptr %487, align 1, !tbaa !2
  %488 = getelementptr i8, ptr %387, i16 %474
  store i16 %476, ptr %488, align 1, !tbaa !2
  %489 = getelementptr i8, ptr %386, i16 %474
  store i16 %476, ptr %489, align 1, !tbaa !2
  %490 = getelementptr i8, ptr %385, i16 %474
  store i16 %476, ptr %490, align 1, !tbaa !2
  %491 = getelementptr i8, ptr %384, i16 %474
  store i16 %476, ptr %491, align 1, !tbaa !2
  %492 = getelementptr i8, ptr %383, i16 %474
  store i16 %476, ptr %492, align 1, !tbaa !2
  %493 = getelementptr i8, ptr %382, i16 %474
  store i16 %476, ptr %493, align 1, !tbaa !2
  %494 = getelementptr i8, ptr %381, i16 %474
  store i16 %476, ptr %494, align 1, !tbaa !2
  %495 = getelementptr i8, ptr %380, i16 %474
  store i16 %476, ptr %495, align 1, !tbaa !2
  %496 = getelementptr i8, ptr %379, i16 %474
  store i16 %476, ptr %496, align 1, !tbaa !2
  %497 = getelementptr i8, ptr %378, i16 %474
  store i16 %476, ptr %497, align 1, !tbaa !2
  %498 = getelementptr i8, ptr %377, i16 %474
  store i16 %476, ptr %498, align 1, !tbaa !2
  %499 = getelementptr i8, ptr %376, i16 %474
  store i16 %476, ptr %499, align 1, !tbaa !2
  %500 = getelementptr i8, ptr %375, i16 %474
  store i16 %476, ptr %500, align 1, !tbaa !2
  %501 = getelementptr i8, ptr %374, i16 %474
  store i16 %476, ptr %501, align 1, !tbaa !2
  %502 = getelementptr i8, ptr %373, i16 %474
  store i16 %476, ptr %502, align 1, !tbaa !2
  %503 = getelementptr i8, ptr %372, i16 %474
  store i16 %476, ptr %503, align 1, !tbaa !2
  %504 = getelementptr i8, ptr %371, i16 %474
  store i16 %476, ptr %504, align 1, !tbaa !2
  %505 = getelementptr i8, ptr %370, i16 %474
  store i16 %476, ptr %505, align 1, !tbaa !2
  %506 = getelementptr i8, ptr %369, i16 %474
  store i16 %476, ptr %506, align 1, !tbaa !2
  %507 = getelementptr i8, ptr %368, i16 %474
  store i16 %476, ptr %507, align 1, !tbaa !2
  %508 = add nuw nsw i8 %439, 1
  %509 = icmp eq i8 %508, 8
  %510 = add i8 %438, 32
  br i1 %509, label %402, label %437, !llvm.loop !101

511:                                              ; preds = %402
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !102
  store i16 255, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !103
  %512 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %513 = icmp eq i8 %512, 0
  br i1 %513, label %525, label %514

514:                                              ; preds = %511, %514
  %515 = phi i8 [ %522, %514 ], [ 0, %511 ]
  %516 = zext i8 %515 to i16
  %517 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %516
  %518 = load ptr, ptr %517, align 1, !tbaa !35
  %519 = load ptr, ptr %518, align 1, !tbaa !40
  %520 = getelementptr inbounds nuw i8, ptr %519, i16 2
  %521 = load ptr, ptr %520, align 1, !tbaa !77
  tail call void %521(ptr noundef nonnull %518, ptr noundef nonnull @main.a) #14, !inline_history !104
  %522 = add nuw i8 %515, 1
  %523 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %524 = icmp ult i8 %522, %523
  br i1 %524, label %514, label %525, !llvm.loop !79

525:                                              ; preds = %514, %511
  %526 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %527

527:                                              ; preds = %527, %525
  %528 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %529 = icmp sgt i8 %528, -1
  br i1 %529, label %527, label %530, !llvm.loop !80

530:                                              ; preds = %527
  tail call fastcc void @upq_flush() #15
  %531 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %532 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %533 = icmp ult i8 %531, %532
  br i1 %533, label %536, label %534

534:                                              ; preds = %530
  %535 = icmp ugt i8 %531, %532
  br i1 %535, label %536, label %539

536:                                              ; preds = %534, %530
  %537 = phi i8 [ 1, %530 ], [ -1, %534 ]
  %538 = add i8 %537, %531
  store i8 %538, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %539

539:                                              ; preds = %534, %536
  %540 = phi i8 [ %531, %534 ], [ %538, %536 ]
  %541 = and i8 %540, 15
  store volatile i8 %541, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %542 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), align 1, !tbaa !96
  br label %359
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_canvas_reserve(ptr noundef readonly captures(none) %0, ptr readnone captures(none) %1) #2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4105
  %4 = load i16, ptr %3, align 1, !tbaa !21
  %5 = lshr i16 %4, 8
  %6 = trunc nuw i16 %5 to i8
  %7 = and i8 %6, -4
  store volatile i8 %7, ptr inttoptr (i16 8457 to ptr), align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %9 = load i16, ptr %8, align 1, !tbaa !20
  %10 = lshr i16 %9, 12
  %11 = trunc nuw nsw i16 %10 to i8
  store volatile i8 %11, ptr inttoptr (i16 8460 to ptr), align 4, !tbaa !6
  %12 = load i16, ptr %8, align 1, !tbaa !20
  %13 = lshr i16 %12, 3
  %14 = add nuw nsw i16 %13, 256
  %15 = load i16, ptr %3, align 1, !tbaa !21
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %15, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %16 = getelementptr inbounds nuw i8, ptr %0, i16 4107
  %17 = load i8, ptr %16, align 1, !tbaa !22
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 4108
  br label %19

19:                                               ; preds = %2, %23
  %20 = phi i8 [ 0, %2 ], [ %24, %23 ]
  br label %26

21:                                               ; preds = %23
  %22 = load i16, ptr %8, align 1, !tbaa !20
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %22, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %45

23:                                               ; preds = %40
  %24 = add nuw nsw i8 %20, 1
  %25 = icmp eq i8 %24, 32
  br i1 %25, label %21, label %19, !llvm.loop !105

26:                                               ; preds = %19, %40
  %27 = phi i8 [ 0, %19 ], [ %42, %40 ]
  %28 = sub i8 %27, %17
  %29 = zext i8 %28 to i16
  %30 = icmp ult i8 %28, 16
  br i1 %30, label %31, label %40

31:                                               ; preds = %26
  %32 = load i8, ptr %18, align 1, !tbaa !23
  %33 = sub i8 %20, %32
  %34 = icmp ult i8 %33, 16
  br i1 %34, label %35, label %40

35:                                               ; preds = %31
  %36 = shl nuw i8 %33, 4
  %37 = zext i8 %36 to i16
  %38 = add nuw nsw i16 %13, %29
  %39 = add nuw nsw i16 %38, %37
  br label %40

40:                                               ; preds = %26, %31, %35
  %41 = phi i16 [ %39, %35 ], [ %14, %31 ], [ %14, %26 ]
  store volatile i16 %41, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %42 = add nuw nsw i8 %27, 1
  %43 = icmp eq i8 %42, 32
  br i1 %43, label %23, label %26, !llvm.loop !106

44:                                               ; preds = %45
  ret void

45:                                               ; preds = %21, %45
  %46 = phi i16 [ 0, %21 ], [ %47, %45 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %47 = add nuw nsw i16 %46, 1
  %48 = icmp eq i16 %47, 2056
  br i1 %48, label %44, label %45, !llvm.loop !107
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal void @_canvas_emit(ptr noundef %0, ptr noundef captures(none) %1) #3 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4099
  %4 = load i16, ptr %3, align 1, !tbaa !24
  %5 = getelementptr inbounds nuw i8, ptr %0, i16 4101
  %6 = load i16, ptr %5, align 1, !tbaa !25
  %7 = icmp ugt i16 %4, %6
  br i1 %7, label %48, label %8

8:                                                ; preds = %2
  %9 = sub nuw i16 %6, %4
  %10 = add i16 %9, -256
  %11 = icmp ult i16 %10, -257
  br i1 %11, label %12, label %14

12:                                               ; preds = %8
  %13 = add i16 %4, 255
  br label %14

14:                                               ; preds = %12, %8
  %15 = phi i16 [ 255, %12 ], [ %9, %8 ]
  %16 = phi i16 [ %13, %12 ], [ %6, %8 ]
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %18 = load i16, ptr %17, align 1, !tbaa !20
  %19 = shl i16 %4, 3
  %20 = add i16 %18, %19
  %21 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %22 = shl i16 %4, 4
  %23 = getelementptr inbounds nuw i8, ptr %21, i16 %22
  %24 = shl nsw i16 %15, 4
  %25 = add nsw i16 %24, 16
  %26 = icmp eq i16 %25, 0
  br i1 %26, label %43, label %27

27:                                               ; preds = %14
  %28 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %29 = load i8, ptr %28, align 1, !tbaa !43
  %30 = icmp ugt i8 %29, 15
  br i1 %30, label %43, label %31

31:                                               ; preds = %27
  %32 = zext nneg i8 %29 to i16
  %33 = add nuw nsw i8 %29, 1
  store i8 %33, ptr %28, align 1, !tbaa !43
  %34 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %32
  %35 = getelementptr inbounds nuw i8, ptr %34, i16 10
  store i8 0, ptr %35, align 1, !tbaa !44
  store i16 %20, ptr %34, align 1, !tbaa !46
  %36 = getelementptr inbounds nuw i8, ptr %34, i16 9
  store i8 -128, ptr %36, align 1, !tbaa !47
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 7
  store i8 24, ptr %37, align 1, !tbaa !48
  %38 = getelementptr inbounds nuw i8, ptr %34, i16 8
  store i8 1, ptr %38, align 1, !tbaa !49
  %39 = ptrtoint ptr %23 to i16
  %40 = getelementptr inbounds nuw i8, ptr %34, i16 2
  store i16 %39, ptr %40, align 1, !tbaa !50
  %41 = getelementptr inbounds nuw i8, ptr %34, i16 6
  store i8 0, ptr %41, align 1, !tbaa !51
  %42 = getelementptr inbounds nuw i8, ptr %34, i16 4
  store i16 %25, ptr %42, align 1, !tbaa !52
  br label %43

43:                                               ; preds = %14, %27, %31
  %44 = icmp ult i16 %16, %6
  br i1 %44, label %46, label %45

45:                                               ; preds = %43
  store i16 -1, ptr %3, align 1, !tbaa !24
  store i16 0, ptr %5, align 1, !tbaa !25
  br label %48

46:                                               ; preds = %43
  %47 = add nuw i16 %16, 1
  store i16 %47, ptr %3, align 1, !tbaa !24
  br label %48

48:                                               ; preds = %45, %46, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_text_reserve(ptr readnone captures(none) %0, ptr readnone captures(none) %1) #2 {
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 2048, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %4

3:                                                ; preds = %4
  ret void

4:                                                ; preds = %2, %4
  %5 = phi i16 [ 0, %2 ], [ %8, %4 ]
  %6 = getelementptr inbounds nuw [2 x i8], ptr @FONT8, i16 %5
  %7 = load i16, ptr %6, align 1, !tbaa !2
  store volatile i16 %7, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %8 = add nuw nsw i16 %5, 1
  %9 = icmp eq i16 %8, 512
  br i1 %9, label %3, label %4, !llvm.loop !108
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(argmem: readwrite)
define internal void @_text_emit(ptr noundef %0, ptr noundef captures(none) %1) #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 135
  %4 = load i8, ptr %3, align 1, !tbaa !31
  %5 = zext i8 %4 to i16
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %7 = getelementptr i8, ptr %0, i16 7
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %9 = getelementptr i8, ptr %0, i16 5
  br label %11

10:                                               ; preds = %42
  store i8 0, ptr %3, align 1, !tbaa !31
  ret void

11:                                               ; preds = %2, %42
  %12 = phi i8 [ 0, %2 ], [ %43, %42 ]
  %13 = phi i1 [ true, %2 ], [ false, %42 ]
  %14 = phi i8 [ 0, %2 ], [ 1, %42 ]
  %15 = zext nneg i8 %14 to i16
  %16 = shl nuw nsw i16 1, %15
  %17 = and i16 %16, %5
  %18 = icmp eq i16 %17, 0
  br i1 %18, label %42, label %19

19:                                               ; preds = %11
  %20 = load i8, ptr %6, align 1, !tbaa !43
  %21 = icmp ugt i8 %20, 15
  br i1 %21, label %42, label %22

22:                                               ; preds = %19
  %23 = zext i8 %12 to i16
  %24 = getelementptr i8, ptr %7, i16 %23
  %25 = load i16, ptr %8, align 1, !tbaa !29
  %26 = getelementptr i8, ptr %9, i16 %15
  %27 = load i8, ptr %26, align 1, !tbaa !6
  %28 = zext i8 %27 to i16
  %29 = shl nuw nsw i16 %28, 5
  %30 = add i16 %29, %25
  %31 = zext nneg i8 %20 to i16
  %32 = add nuw nsw i8 %20, 1
  store i8 %32, ptr %6, align 1, !tbaa !43
  %33 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %31
  %34 = getelementptr inbounds nuw i8, ptr %33, i16 10
  store i8 0, ptr %34, align 1, !tbaa !44
  store i16 %30, ptr %33, align 1, !tbaa !46
  %35 = getelementptr inbounds nuw i8, ptr %33, i16 9
  store i8 -128, ptr %35, align 1, !tbaa !47
  %36 = getelementptr inbounds nuw i8, ptr %33, i16 7
  store i8 24, ptr %36, align 1, !tbaa !48
  %37 = getelementptr inbounds nuw i8, ptr %33, i16 8
  store i8 1, ptr %37, align 1, !tbaa !49
  %38 = ptrtoint ptr %24 to i16
  %39 = getelementptr inbounds nuw i8, ptr %33, i16 2
  store i16 %38, ptr %39, align 1, !tbaa !50
  %40 = getelementptr inbounds nuw i8, ptr %33, i16 6
  store i8 0, ptr %40, align 1, !tbaa !51
  %41 = getelementptr inbounds nuw i8, ptr %33, i16 4
  store i16 64, ptr %41, align 1, !tbaa !52
  br label %42

42:                                               ; preds = %22, %19, %11
  %43 = add nuw i8 %12, 64
  br i1 %13, label %11, label %10, !llvm.loop !109
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_title_reserve(ptr noundef %0, ptr readnone captures(none) %1) #2 {
  store volatile i8 80, ptr inttoptr (i16 8456 to ptr), align 8, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !6
  store volatile i8 112, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -1, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 127, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -124, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 4096, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %3

3:                                                ; preds = %2, %16
  %4 = phi ptr [ @FONT8, %2 ], [ %18, %16 ]
  %5 = phi i16 [ 0, %2 ], [ %17, %16 ]
  br label %7

6:                                                ; preds = %16
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 5120, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %24

7:                                                ; preds = %3, %7
  %8 = phi i8 [ 0, %3 ], [ %15, %7 ]
  %9 = phi i8 [ 0, %3 ], [ %13, %7 ]
  %10 = zext nneg i8 %8 to i16
  %11 = getelementptr i8, ptr %4, i16 %10
  %12 = load i16, ptr %11, align 1, !tbaa !2
  store volatile i16 %12, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %13 = add nuw nsw i8 %9, 1
  %14 = icmp eq i8 %13, 8
  %15 = add nuw nsw i8 %8, 2
  br i1 %14, label %20, label %7, !llvm.loop !110

16:                                               ; preds = %20
  %17 = add nuw nsw i16 %5, 1
  %18 = getelementptr i8, ptr %4, i16 16
  %19 = icmp eq i16 %17, 64
  br i1 %19, label %6, label %3, !llvm.loop !111

20:                                               ; preds = %7, %20
  %21 = phi i8 [ %22, %20 ], [ 0, %7 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %22 = add nuw nsw i8 %21, 1
  %23 = icmp eq i8 %22, 8
  br i1 %23, label %16, label %20, !llvm.loop !112

24:                                               ; preds = %6, %33
  %25 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 16), %6 ], [ %36, %33 ]
  %26 = phi ptr [ @FONT16, %6 ], [ %35, %33 ]
  %27 = phi i16 [ 0, %6 ], [ %34, %33 ]
  br label %29

28:                                               ; preds = %33
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 20480, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %66

29:                                               ; preds = %24, %47
  %30 = phi i8 [ 0, %24 ], [ %52, %47 ]
  %31 = phi ptr [ %26, %24 ], [ %50, %47 ]
  %32 = phi i8 [ 0, %24 ], [ %48, %47 ]
  br label %38

33:                                               ; preds = %47
  %34 = add nuw nsw i16 %27, 1
  %35 = getelementptr i8, ptr %26, i16 64
  %36 = getelementptr i8, ptr %25, i16 64
  %37 = icmp eq i16 %34, 64
  br i1 %37, label %28, label %24, !llvm.loop !113

38:                                               ; preds = %29, %38
  %39 = phi i8 [ 0, %29 ], [ %46, %38 ]
  %40 = phi i8 [ 0, %29 ], [ %44, %38 ]
  %41 = zext nneg i8 %39 to i16
  %42 = getelementptr i8, ptr %31, i16 %41
  %43 = load i16, ptr %42, align 1, !tbaa !2
  store volatile i16 %43, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %44 = add nuw nsw i8 %40, 1
  %45 = icmp eq i8 %44, 8
  %46 = add nuw nsw i8 %39, 2
  br i1 %45, label %53, label %38, !llvm.loop !114

47:                                               ; preds = %53
  %48 = add nuw nsw i8 %32, 1
  %49 = zext nneg i8 %30 to i16
  %50 = getelementptr i8, ptr %25, i16 %49
  %51 = icmp eq i8 %48, 4
  %52 = add nuw nsw i8 %30, 16
  br i1 %51, label %33, label %29, !llvm.loop !115

53:                                               ; preds = %38, %53
  %54 = phi i8 [ %55, %53 ], [ 0, %38 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %55 = add nuw nsw i8 %54, 1
  %56 = icmp eq i8 %55, 8
  br i1 %56, label %47, label %53, !llvm.loop !116

57:                                               ; preds = %66
  %58 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %59 = load ptr, ptr %58, align 1, !tbaa !59
  %60 = icmp eq ptr %59, null
  br i1 %60, label %79, label %61

61:                                               ; preds = %57
  %62 = load i8, ptr %59, align 1, !tbaa !6
  %63 = icmp eq i8 %62, 0
  br i1 %63, label %79, label %64

64:                                               ; preds = %61
  %65 = getelementptr i8, ptr %59, i16 1
  br label %70

66:                                               ; preds = %28, %66
  %67 = phi i16 [ 0, %28 ], [ %68, %66 ]
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %68 = add nuw nsw i16 %67, 1
  %69 = icmp eq i16 %68, 1024
  br i1 %69, label %57, label %66, !llvm.loop !117

70:                                               ; preds = %64, %70
  %71 = phi i8 [ %72, %70 ], [ 0, %64 ]
  %72 = add nuw nsw i8 %71, 1
  %73 = zext nneg i8 %71 to i16
  %74 = getelementptr i8, ptr %65, i16 %73
  %75 = load i8, ptr %74, align 1, !tbaa !6
  %76 = icmp ne i8 %75, 0
  %77 = icmp samesign ult i8 %71, 31
  %78 = select i1 %76, i1 %77, i1 false
  br i1 %78, label %70, label %79, !llvm.loop !118

79:                                               ; preds = %70, %61, %57
  %80 = phi i8 [ 0, %57 ], [ 0, %61 ], [ %72, %70 ]
  %81 = zext nneg i8 %80 to i16
  %82 = sub nuw nsw i16 32, %81
  %83 = lshr i16 %82, 1
  %84 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %85 = load i16, ptr %84, align 1, !tbaa !65
  %86 = shl i16 %85, 2
  %87 = and i16 %86, -32
  %88 = add i16 %87, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %88, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %89 = trunc nuw nsw i16 %83 to i8
  %90 = add nuw nsw i8 %80, %89
  %91 = sub nsw i16 0, %83
  %92 = getelementptr i8, ptr %59, i16 %91
  br label %105

93:                                               ; preds = %128
  %94 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %95 = load ptr, ptr %94, align 1, !tbaa !61
  %96 = getelementptr inbounds nuw i8, ptr %0, i16 11
  %97 = load i8, ptr %96, align 1, !tbaa !62
  %98 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %99 = load i16, ptr %98, align 1, !tbaa !66
  %100 = lshr i16 %99, 3
  %101 = trunc i16 %100 to i8
  tail call fastcc void @_title_write16(ptr noundef %95, i8 noundef zeroext %97, i8 noundef zeroext %101) #15
  %102 = getelementptr inbounds nuw i8, ptr %0, i16 9
  %103 = load ptr, ptr %102, align 1, !tbaa !63
  %104 = icmp eq ptr %103, null
  br i1 %104, label %139, label %132

105:                                              ; preds = %79, %128
  %106 = phi i8 [ 0, %79 ], [ %130, %128 ]
  %107 = zext nneg i8 %106 to i16
  br i1 %60, label %128, label %108

108:                                              ; preds = %105
  %109 = icmp samesign ugt i16 %83, %107
  br i1 %109, label %128, label %110

110:                                              ; preds = %108
  %111 = icmp ult i8 %106, %90
  br i1 %111, label %112, label %128

112:                                              ; preds = %110
  %113 = getelementptr i8, ptr %92, i16 %107
  %114 = load i8, ptr %113, align 1, !tbaa !6
  %115 = icmp ugt i8 %114, 96
  br i1 %115, label %116, label %120

116:                                              ; preds = %112
  %117 = icmp ult i8 %114, 123
  br i1 %117, label %118, label %128

118:                                              ; preds = %116
  %119 = add nsw i8 %114, -32
  br label %124

120:                                              ; preds = %112
  %121 = icmp samesign ugt i8 %114, 31
  br i1 %121, label %122, label %128

122:                                              ; preds = %120
  %123 = icmp eq i8 %114, 96
  br i1 %123, label %128, label %124

124:                                              ; preds = %122, %118
  %125 = phi i8 [ %119, %118 ], [ %114, %122 ]
  %126 = zext nneg i8 %125 to i16
  %127 = add nuw nsw i16 %126, 7136
  br label %128

128:                                              ; preds = %124, %122, %120, %116, %105, %108, %110
  %129 = phi i16 [ 7168, %105 ], [ 7168, %110 ], [ 7168, %108 ], [ %127, %124 ], [ 7168, %122 ], [ 7168, %120 ], [ 7168, %116 ]
  store volatile i16 %129, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %130 = add nuw nsw i8 %106, 1
  %131 = icmp eq i8 %130, 32
  br i1 %131, label %93, label %105, !llvm.loop !119

132:                                              ; preds = %93
  %133 = getelementptr inbounds nuw i8, ptr %0, i16 12
  %134 = load i8, ptr %133, align 1, !tbaa !64
  %135 = load i16, ptr %98, align 1, !tbaa !66
  %136 = lshr i16 %135, 3
  %137 = trunc i16 %136 to i8
  %138 = add i8 %137, 2
  tail call fastcc void @_title_write16(ptr noundef nonnull %103, i8 noundef zeroext %134, i8 noundef zeroext %138) #15
  br label %139

139:                                              ; preds = %132, %93
  %140 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 -128, ptr %140, align 1, !tbaa !88
  %141 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 3584, ptr %141, align 1, !tbaa !120
  %142 = getelementptr inbounds nuw i8, ptr %0, i16 23
  store i16 0, ptr %142, align 1, !tbaa !121
  %143 = load ptr, ptr %58, align 1, !tbaa !59
  %144 = icmp eq ptr %143, null
  br i1 %144, label %167, label %145

145:                                              ; preds = %139
  %146 = load i8, ptr %143, align 1, !tbaa !6
  %147 = icmp eq i8 %146, 0
  br i1 %147, label %150, label %148

148:                                              ; preds = %145
  %149 = getelementptr i8, ptr %143, i16 1
  br label %158

150:                                              ; preds = %158, %145
  %151 = phi i8 [ 0, %145 ], [ %160, %158 ]
  %152 = zext nneg i8 %151 to i16
  %153 = shl nuw nsw i16 %152, 2
  %154 = sub nuw nsw i16 128, %153
  %155 = and i16 %154, 248
  %156 = add nsw i16 %153, -128
  %157 = add nsw i16 %156, %155
  br label %167

158:                                              ; preds = %158, %148
  %159 = phi i8 [ %160, %158 ], [ 0, %148 ]
  %160 = add nuw nsw i8 %159, 1
  %161 = zext nneg i8 %159 to i16
  %162 = getelementptr i8, ptr %149, i16 %161
  %163 = load i8, ptr %162, align 1, !tbaa !6
  %164 = icmp ne i8 %163, 0
  %165 = icmp samesign ult i8 %159, 31
  %166 = select i1 %164, i1 %165, i1 false
  br i1 %166, label %158, label %150, !llvm.loop !122

167:                                              ; preds = %139, %150
  %168 = phi i16 [ %157, %150 ], [ 0, %139 ]
  %169 = getelementptr inbounds nuw i8, ptr %0, i16 26
  store i16 %168, ptr %169, align 1, !tbaa !123
  store volatile i8 -112, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  %170 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %171 = getelementptr inbounds nuw i8, ptr %0, i16 89
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef -8, i16 noundef 224, ptr noundef nonnull %170, ptr noundef nonnull %171) #15
  %172 = getelementptr inbounds nuw i8, ptr %0, i16 88
  store i8 0, ptr %172, align 1, !tbaa !124
  store volatile i8 2, ptr inttoptr (i16 17200 to ptr), align 16, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 17201 to ptr), align 1, !tbaa !6
  %173 = ptrtoint ptr %170 to i16
  %174 = trunc i16 %173 to i8
  store volatile i8 %174, ptr inttoptr (i16 17202 to ptr), align 2, !tbaa !6
  %175 = lshr i16 %173, 8
  %176 = trunc nuw i16 %175 to i8
  store volatile i8 %176, ptr inttoptr (i16 17203 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17204 to ptr), align 4, !tbaa !6
  %177 = getelementptr inbounds nuw i8, ptr %0, i16 139
  store i8 0, ptr %177, align 1, !tbaa !124
  store volatile i8 2, ptr inttoptr (i16 17216 to ptr), align 64, !tbaa !6
  store volatile i8 15, ptr inttoptr (i16 17217 to ptr), align 1, !tbaa !6
  %178 = ptrtoint ptr %171 to i16
  %179 = trunc i16 %178 to i8
  store volatile i8 %179, ptr inttoptr (i16 17218 to ptr), align 2, !tbaa !6
  %180 = lshr i16 %178, 8
  %181 = trunc nuw i16 %180 to i8
  store volatile i8 %181, ptr inttoptr (i16 17219 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17220 to ptr), align 4, !tbaa !6
  %182 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 2, ptr %182, align 1, !tbaa !58
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal void @_title_emit(ptr noundef %0, ptr noundef captures(none) %1) #5 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 29
  %4 = load i8, ptr %3, align 1, !tbaa !69
  %5 = icmp eq i8 %4, 0
  br i1 %5, label %188, label %6

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 30
  %8 = load i8, ptr %7, align 1, !tbaa !72
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %39, label %10

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 25
  %12 = load i8, ptr %11, align 1, !tbaa !73
  %13 = icmp ugt i8 %12, -6
  br i1 %13, label %16, label %14

14:                                               ; preds = %10
  %15 = add nuw i8 %12, 4
  br label %16

16:                                               ; preds = %10, %14
  %17 = phi i8 [ %15, %14 ], [ -1, %10 ]
  store i8 %17, ptr %11, align 1, !tbaa !73
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %19 = load i16, ptr %18, align 1, !tbaa !65
  %20 = xor i8 %17, -1
  %21 = zext i8 %20 to i16
  %22 = mul nuw i16 %21, %21
  %23 = lshr i16 %22, 8
  %24 = sub nuw nsw i16 256, %23
  %25 = add nsw i16 %19, 8
  %26 = mul nsw i16 %24, %25
  %27 = ashr i16 %26, 4
  %28 = and i16 %27, -16
  %29 = add nsw i16 %28, -128
  %30 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 %29, ptr %30, align 1, !tbaa !88
  %31 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %32 = load i16, ptr %31, align 1, !tbaa !66
  %33 = add nsw i16 %32, -224
  %34 = mul nsw i16 %33, %24
  %35 = ashr i16 %34, 4
  %36 = and i16 %35, -16
  %37 = add nsw i16 %36, 3584
  %38 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 %37, ptr %38, align 1, !tbaa !120
  br label %64

39:                                               ; preds = %6
  %40 = getelementptr inbounds nuw i8, ptr %0, i16 31
  %41 = load i8, ptr %40, align 1, !tbaa !70
  %42 = icmp eq i8 %41, 0
  br i1 %42, label %43, label %48

43:                                               ; preds = %39
  %44 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %45 = load i16, ptr %44, align 1, !tbaa !88
  %46 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %47 = load i16, ptr %46, align 1, !tbaa !120
  br label %64

48:                                               ; preds = %39
  %49 = getelementptr inbounds nuw i8, ptr %0, i16 23
  %50 = load i16, ptr %49, align 1, !tbaa !121
  %51 = add nsw i16 %50, 2
  store i16 %51, ptr %49, align 1, !tbaa !121
  %52 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %53 = load i16, ptr %52, align 1, !tbaa !88
  %54 = add nsw i16 %53, %51
  store i16 %54, ptr %52, align 1, !tbaa !88
  %55 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %56 = load i16, ptr %55, align 1, !tbaa !120
  %57 = add nsw i16 %56, %51
  store i16 %57, ptr %55, align 1, !tbaa !120
  %58 = icmp sgt i16 %54, 4480
  br i1 %58, label %59, label %60

59:                                               ; preds = %48
  store i16 4480, ptr %52, align 1, !tbaa !88
  br label %60

60:                                               ; preds = %59, %48
  %61 = phi i16 [ 4480, %59 ], [ %54, %48 ]
  %62 = icmp sgt i16 %57, 4736
  br i1 %62, label %63, label %64

63:                                               ; preds = %60
  store i16 4736, ptr %55, align 1, !tbaa !120
  br label %64

64:                                               ; preds = %43, %63, %60, %16
  %65 = phi i16 [ %47, %43 ], [ 4736, %63 ], [ %57, %60 ], [ %37, %16 ]
  %66 = phi i16 [ %45, %43 ], [ %61, %63 ], [ %61, %60 ], [ %29, %16 ]
  %67 = ashr i16 %66, 4
  %68 = ashr i16 %65, 4
  %69 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %70 = getelementptr inbounds nuw i8, ptr %0, i16 88
  %71 = load i8, ptr %70, align 1, !tbaa !124
  %72 = xor i8 %71, 1
  %73 = zext i8 %72 to i16
  %74 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %73
  %75 = getelementptr inbounds nuw i8, ptr %0, i16 89
  %76 = getelementptr inbounds nuw i8, ptr %0, i16 139
  %77 = load i8, ptr %76, align 1, !tbaa !124
  %78 = xor i8 %77, 1
  %79 = zext i8 %78 to i16
  %80 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %79
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef %67, i16 noundef %68, ptr noundef nonnull %74, ptr noundef nonnull %80) #15
  %81 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %82 = load i8, ptr %81, align 1, !tbaa !43
  %83 = icmp ugt i8 %82, 15
  br i1 %83, label %109, label %84

84:                                               ; preds = %64
  %85 = load i8, ptr %70, align 1, !tbaa !124
  %86 = xor i8 %85, 1
  %87 = zext i8 %86 to i16
  %88 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %87
  %89 = ptrtoint ptr %88 to i16
  %90 = zext nneg i8 %82 to i16
  %91 = add nuw nsw i8 %82, 1
  store i8 %91, ptr %81, align 1, !tbaa !43
  %92 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %90
  %93 = getelementptr inbounds nuw i8, ptr %92, i16 10
  store i8 4, ptr %93, align 1, !tbaa !44
  store i16 17202, ptr %92, align 1, !tbaa !46
  %94 = getelementptr inbounds nuw i8, ptr %92, i16 2
  store i16 %89, ptr %94, align 1, !tbaa !50
  %95 = getelementptr inbounds nuw i8, ptr %92, i16 4
  store i16 0, ptr %95, align 1, !tbaa !52
  store i8 %86, ptr %70, align 1, !tbaa !124
  %96 = icmp eq i8 %82, 15
  br i1 %96, label %109, label %97

97:                                               ; preds = %84
  %98 = load i8, ptr %76, align 1, !tbaa !124
  %99 = xor i8 %98, 1
  %100 = zext i8 %99 to i16
  %101 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %100
  %102 = ptrtoint ptr %101 to i16
  %103 = zext nneg i8 %91 to i16
  %104 = add nuw nsw i8 %82, 2
  store i8 %104, ptr %81, align 1, !tbaa !43
  %105 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %103
  %106 = getelementptr inbounds nuw i8, ptr %105, i16 10
  store i8 4, ptr %106, align 1, !tbaa !44
  store i16 17218, ptr %105, align 1, !tbaa !46
  %107 = getelementptr inbounds nuw i8, ptr %105, i16 2
  store i16 %102, ptr %107, align 1, !tbaa !50
  %108 = getelementptr inbounds nuw i8, ptr %105, i16 4
  store i16 0, ptr %108, align 1, !tbaa !52
  store i8 %99, ptr %76, align 1, !tbaa !124
  br label %109

109:                                              ; preds = %64, %84, %97
  %110 = phi i8 [ %82, %64 ], [ 16, %84 ], [ %104, %97 ]
  %111 = getelementptr inbounds nuw i8, ptr %0, i16 28
  %112 = load i8, ptr %111, align 1, !tbaa !68
  %113 = add i8 %112, 1
  store i8 %113, ptr %111, align 1, !tbaa !68
  %114 = getelementptr inbounds nuw i8, ptr %0, i16 32
  %115 = load i8, ptr %114, align 1, !tbaa !71
  %116 = icmp eq i8 %115, 0
  br i1 %116, label %117, label %155

117:                                              ; preds = %109
  %118 = shl i8 %113, 1
  %119 = icmp sgt i8 %118, -1
  br i1 %119, label %122, label %120

120:                                              ; preds = %117
  %121 = xor i8 %118, -1
  br label %122

122:                                              ; preds = %117, %120
  %123 = phi i8 [ %121, %120 ], [ %118, %117 ]
  %124 = lshr i8 %123, 4
  %125 = add nuw nsw i8 %124, 24
  %126 = zext nneg i8 %125 to i16
  %127 = mul nuw nsw i16 %126, 1057
  %128 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 %127, ptr %128, align 1, !tbaa !74
  %129 = add i8 %118, -86
  %130 = icmp sgt i8 %129, -1
  br i1 %130, label %133, label %131

131:                                              ; preds = %122
  %132 = sub nsw i8 85, %118
  br label %133

133:                                              ; preds = %122, %131
  %134 = phi i8 [ %132, %131 ], [ %129, %122 ]
  %135 = lshr i8 %134, 2
  %136 = zext nneg i8 %135 to i16
  %137 = shl nuw nsw i16 %136, 10
  %138 = add i8 %118, 85
  %139 = icmp sgt i8 %138, -1
  br i1 %139, label %142, label %140

140:                                              ; preds = %133
  %141 = sub nuw i8 -86, %118
  br label %142

142:                                              ; preds = %133, %140
  %143 = phi i8 [ %141, %140 ], [ %138, %133 ]
  %144 = lshr i8 %143, 2
  %145 = zext nneg i8 %144 to i16
  %146 = shl nuw nsw i16 %145, 5
  %147 = add nuw nsw i16 %146, %137
  br i1 %119, label %150, label %148

148:                                              ; preds = %142
  %149 = xor i8 %118, -1
  br label %150

150:                                              ; preds = %142, %148
  %151 = phi i8 [ %149, %148 ], [ %118, %142 ]
  %152 = lshr i8 %151, 2
  %153 = zext nneg i8 %152 to i16
  %154 = add nuw nsw i16 %147, %153
  br label %157

155:                                              ; preds = %109
  %156 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 29596, ptr %156, align 1, !tbaa !74
  br label %157

157:                                              ; preds = %155, %150
  %158 = phi i16 [ 0, %155 ], [ %154, %150 ]
  %159 = getelementptr inbounds nuw i8, ptr %0, i16 36
  store i16 %158, ptr %159, align 1, !tbaa !75
  %160 = icmp ugt i8 %110, 15
  br i1 %160, label %188, label %161

161:                                              ; preds = %157
  %162 = getelementptr inbounds nuw i8, ptr %0, i16 34
  %163 = zext nneg i8 %110 to i16
  %164 = add nuw nsw i8 %110, 1
  store i8 %164, ptr %81, align 1, !tbaa !43
  %165 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %163
  %166 = getelementptr inbounds nuw i8, ptr %165, i16 10
  store i8 1, ptr %166, align 1, !tbaa !44
  store i16 113, ptr %165, align 1, !tbaa !46
  %167 = getelementptr inbounds nuw i8, ptr %165, i16 9
  store i8 0, ptr %167, align 1, !tbaa !47
  %168 = getelementptr inbounds nuw i8, ptr %165, i16 7
  store i8 34, ptr %168, align 1, !tbaa !48
  %169 = getelementptr inbounds nuw i8, ptr %165, i16 8
  store i8 0, ptr %169, align 1, !tbaa !49
  %170 = ptrtoint ptr %162 to i16
  %171 = getelementptr inbounds nuw i8, ptr %165, i16 2
  store i16 %170, ptr %171, align 1, !tbaa !50
  %172 = getelementptr inbounds nuw i8, ptr %165, i16 6
  store i8 0, ptr %172, align 1, !tbaa !51
  %173 = getelementptr inbounds nuw i8, ptr %165, i16 4
  store i16 2, ptr %173, align 1, !tbaa !52
  %174 = icmp eq i8 %110, 15
  br i1 %174, label %188, label %175

175:                                              ; preds = %161
  %176 = getelementptr inbounds nuw i8, ptr %0, i16 36
  %177 = zext nneg i8 %164 to i16
  %178 = add nuw nsw i8 %110, 2
  store i8 %178, ptr %81, align 1, !tbaa !43
  %179 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %177
  %180 = getelementptr inbounds nuw i8, ptr %179, i16 10
  store i8 1, ptr %180, align 1, !tbaa !44
  store i16 0, ptr %179, align 1, !tbaa !46
  %181 = getelementptr inbounds nuw i8, ptr %179, i16 9
  store i8 0, ptr %181, align 1, !tbaa !47
  %182 = getelementptr inbounds nuw i8, ptr %179, i16 7
  store i8 34, ptr %182, align 1, !tbaa !48
  %183 = getelementptr inbounds nuw i8, ptr %179, i16 8
  store i8 0, ptr %183, align 1, !tbaa !49
  %184 = ptrtoint ptr %176 to i16
  %185 = getelementptr inbounds nuw i8, ptr %179, i16 2
  store i16 %184, ptr %185, align 1, !tbaa !50
  %186 = getelementptr inbounds nuw i8, ptr %179, i16 6
  store i8 0, ptr %186, align 1, !tbaa !51
  %187 = getelementptr inbounds nuw i8, ptr %179, i16 4
  store i16 2, ptr %187, align 1, !tbaa !52
  br label %188

188:                                              ; preds = %157, %175, %161, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @_title_write16(ptr noundef readonly captures(address_is_null) %0, i8 noundef zeroext %1, i8 noundef zeroext %2) unnamed_addr #2 {
  %4 = zext i8 %1 to i16
  %5 = shl nuw nsw i16 %4, 1
  %6 = and i16 %5, 254
  %7 = sub nsw i16 32, %6
  %8 = lshr exact i16 %7, 1
  %9 = zext i8 %2 to i16
  %10 = icmp eq ptr %0, null
  %11 = and i16 %8, 255
  %12 = add nuw i16 %8, %5
  %13 = and i16 %12, 255
  br label %15

14:                                               ; preds = %23
  ret void

15:                                               ; preds = %3, %23
  %16 = phi i1 [ true, %3 ], [ false, %23 ]
  %17 = phi i8 [ 0, %3 ], [ 1, %23 ]
  %18 = zext nneg i8 %17 to i16
  %19 = add nuw nsw i16 %18, %9
  %20 = shl nuw nsw i16 %19, 5
  %21 = add nuw nsw i16 %20, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %21, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %22 = select i1 %16, i16 7168, i16 7170
  br label %24

23:                                               ; preds = %56
  br i1 %16, label %15, label %14, !llvm.loop !125

24:                                               ; preds = %15, %56
  %25 = phi i8 [ 0, %15 ], [ %58, %56 ]
  %26 = zext nneg i8 %25 to i16
  br i1 %10, label %56, label %27

27:                                               ; preds = %24
  %28 = icmp samesign ugt i16 %11, %26
  br i1 %28, label %56, label %29

29:                                               ; preds = %27
  %30 = icmp samesign ugt i16 %13, %26
  br i1 %30, label %31, label %56

31:                                               ; preds = %29
  %32 = sub nsw i16 %26, %11
  %33 = lshr i16 %32, 1
  %34 = and i16 %33, 255
  %35 = getelementptr inbounds nuw i8, ptr %0, i16 %34
  %36 = load i8, ptr %35, align 1, !tbaa !6
  %37 = icmp ugt i8 %36, 96
  br i1 %37, label %38, label %42

38:                                               ; preds = %31
  %39 = icmp ult i8 %36, 123
  br i1 %39, label %40, label %51

40:                                               ; preds = %38
  %41 = add nsw i8 %36, -32
  br label %46

42:                                               ; preds = %31
  %43 = icmp samesign ugt i8 %36, 31
  br i1 %43, label %44, label %51

44:                                               ; preds = %42
  %45 = icmp eq i8 %36, 96
  br i1 %45, label %51, label %46

46:                                               ; preds = %44, %40
  %47 = phi i8 [ %41, %40 ], [ %36, %44 ]
  %48 = zext nneg i8 %47 to i16
  %49 = shl nuw nsw i16 %48, 2
  %50 = add nsw i16 %49, -64
  br label %51

51:                                               ; preds = %38, %42, %44, %46
  %52 = phi i16 [ %50, %46 ], [ 64, %44 ], [ 64, %42 ], [ 64, %38 ]
  %53 = and i16 %32, 1
  %54 = or disjoint i16 %22, %53
  %55 = or disjoint i16 %54, %52
  br label %56

56:                                               ; preds = %51, %29, %27, %24
  %57 = phi i16 [ %55, %51 ], [ 7168, %29 ], [ 7168, %27 ], [ 7168, %24 ]
  store volatile i16 %57, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %58 = add nuw nsw i8 %25, 1
  %59 = icmp eq i8 %58, 32
  br i1 %59, label %23, label %24, !llvm.loop !126
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_build(ptr noundef readonly captures(none) %0, i16 noundef range(i16 -2048, 2048) %1, i16 noundef range(i16 -2048, 2048) %2, ptr noundef %3, ptr noundef %4) unnamed_addr #5 {
  %6 = alloca %struct.HScrollW, align 1
  %7 = alloca %struct.HScrollW, align 1
  %8 = alloca i16, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #16
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #16
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #16
  store i16 0, ptr %8, align 1, !tbaa !2
  store ptr %3, ptr %6, align 1, !tbaa !127
  %9 = getelementptr inbounds nuw i8, ptr %6, i16 2
  store i8 0, ptr %9, align 1, !tbaa !129
  store ptr %4, ptr %7, align 1, !tbaa !127
  %10 = getelementptr inbounds nuw i8, ptr %7, i16 2
  store i8 0, ptr %10, align 1, !tbaa !129
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %12 = load i16, ptr %11, align 1, !tbaa !65
  %13 = getelementptr inbounds nuw i8, ptr %0, i16 26
  %14 = load i16, ptr %13, align 1, !tbaa !123
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %1, i16 noundef 8, i16 noundef %12, i16 noundef %14) #15
  %15 = getelementptr inbounds nuw i8, ptr %0, i16 17
  %16 = load i16, ptr %15, align 1, !tbaa !67
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %18 = load i16, ptr %17, align 1, !tbaa !66
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %2, i16 noundef %16, i16 noundef %18, i16 noundef 0) #15
  %19 = load i16, ptr %8, align 1, !tbaa !2
  call fastcc void @_title_blank(ptr noundef %6, ptr noundef %7, i16 noundef %19, i16 noundef 224) #15
  %20 = load ptr, ptr %6, align 1, !tbaa !127
  %21 = load i8, ptr %9, align 1, !tbaa !129
  %22 = zext i8 %21 to i16
  %23 = getelementptr inbounds nuw i8, ptr %20, i16 %22
  store i8 0, ptr %23, align 1, !tbaa !6
  %24 = load ptr, ptr %7, align 1, !tbaa !127
  %25 = load i8, ptr %10, align 1, !tbaa !129
  %26 = zext i8 %25 to i16
  %27 = getelementptr inbounds nuw i8, ptr %24, i16 %26
  store i8 0, ptr %27, align 1, !tbaa !6
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #16
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #16
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #16
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_glyph_band(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, ptr noundef nonnull captures(none) %2, i16 noundef range(i16 -2048, 2048) %3, i16 noundef %4, i16 noundef %5, i16 noundef %6) unnamed_addr #5 {
  %8 = add nsw i16 %3, -2
  %9 = add nsw i16 %4, %3
  %10 = add nsw i16 %9, 2
  %11 = load i16, ptr %2, align 1, !tbaa !2
  %12 = icmp slt i16 %8, %11
  br i1 %12, label %13, label %14

13:                                               ; preds = %7
  br label %14

14:                                               ; preds = %13, %7
  %15 = phi i16 [ %11, %13 ], [ %8, %7 ]
  %16 = icmp sgt i16 %9, 222
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  br label %18

18:                                               ; preds = %17, %14
  %19 = phi i16 [ 224, %17 ], [ %10, %14 ]
  %20 = icmp sgt i16 %19, %15
  br i1 %20, label %21, label %92

21:                                               ; preds = %18
  tail call fastcc void @_title_blank(ptr noundef %0, ptr noundef %1, i16 noundef %11, i16 noundef %15) #15
  %22 = sub nsw i16 %19, %15
  %23 = trunc i16 %22 to i8
  %24 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %25 = icmp eq i8 %23, 0
  br i1 %25, label %91, label %26

26:                                               ; preds = %21
  %27 = sub nsw i16 %5, %3
  %28 = and i16 %22, 255
  %29 = trunc i16 %27 to i8
  %30 = lshr i16 %27, 8
  %31 = trunc nuw i16 %30 to i8
  br label %32

32:                                               ; preds = %40, %26
  %33 = phi i16 [ %28, %26 ], [ %57, %40 ]
  %34 = load i8, ptr %24, align 1, !tbaa !129
  %35 = icmp ult i8 %34, 22
  br i1 %35, label %36, label %59

36:                                               ; preds = %32
  %37 = icmp ugt i16 %33, 127
  br i1 %37, label %40, label %38

38:                                               ; preds = %36
  %39 = trunc nuw nsw i16 %33 to i8
  br label %40

40:                                               ; preds = %38, %36
  %41 = phi i8 [ %39, %38 ], [ 127, %36 ]
  %42 = load ptr, ptr %0, align 1, !tbaa !127
  %43 = add nuw nsw i8 %34, 1
  store i8 %43, ptr %24, align 1, !tbaa !129
  %44 = zext nneg i8 %34 to i16
  %45 = getelementptr inbounds nuw i8, ptr %42, i16 %44
  store i8 %41, ptr %45, align 1, !tbaa !6
  %46 = load ptr, ptr %0, align 1, !tbaa !127
  %47 = load i8, ptr %24, align 1, !tbaa !129
  %48 = add i8 %47, 1
  store i8 %48, ptr %24, align 1, !tbaa !129
  %49 = zext i8 %47 to i16
  %50 = getelementptr inbounds nuw i8, ptr %46, i16 %49
  store i8 %29, ptr %50, align 1, !tbaa !6
  %51 = load ptr, ptr %0, align 1, !tbaa !127
  %52 = load i8, ptr %24, align 1, !tbaa !129
  %53 = add i8 %52, 1
  store i8 %53, ptr %24, align 1, !tbaa !129
  %54 = zext i8 %52 to i16
  %55 = getelementptr inbounds nuw i8, ptr %51, i16 %54
  store i8 %31, ptr %55, align 1, !tbaa !6
  %56 = zext nneg i8 %41 to i16
  %57 = sub i16 %33, %56
  %58 = icmp eq i16 %57, 0
  br i1 %58, label %59, label %32, !llvm.loop !130

59:                                               ; preds = %32, %40
  %60 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %61 = trunc i16 %6 to i8
  %62 = lshr i16 %6, 8
  %63 = trunc nuw i16 %62 to i8
  br label %64

64:                                               ; preds = %72, %59
  %65 = phi i16 [ %28, %59 ], [ %89, %72 ]
  %66 = load i8, ptr %60, align 1, !tbaa !129
  %67 = icmp ult i8 %66, 22
  br i1 %67, label %68, label %91

68:                                               ; preds = %64
  %69 = icmp ugt i16 %65, 127
  br i1 %69, label %72, label %70

70:                                               ; preds = %68
  %71 = trunc nuw nsw i16 %65 to i8
  br label %72

72:                                               ; preds = %70, %68
  %73 = phi i8 [ %71, %70 ], [ 127, %68 ]
  %74 = load ptr, ptr %1, align 1, !tbaa !127
  %75 = add nuw nsw i8 %66, 1
  store i8 %75, ptr %60, align 1, !tbaa !129
  %76 = zext nneg i8 %66 to i16
  %77 = getelementptr inbounds nuw i8, ptr %74, i16 %76
  store i8 %73, ptr %77, align 1, !tbaa !6
  %78 = load ptr, ptr %1, align 1, !tbaa !127
  %79 = load i8, ptr %60, align 1, !tbaa !129
  %80 = add i8 %79, 1
  store i8 %80, ptr %60, align 1, !tbaa !129
  %81 = zext i8 %79 to i16
  %82 = getelementptr inbounds nuw i8, ptr %78, i16 %81
  store i8 %61, ptr %82, align 1, !tbaa !6
  %83 = load ptr, ptr %1, align 1, !tbaa !127
  %84 = load i8, ptr %60, align 1, !tbaa !129
  %85 = add i8 %84, 1
  store i8 %85, ptr %60, align 1, !tbaa !129
  %86 = zext i8 %84 to i16
  %87 = getelementptr inbounds nuw i8, ptr %83, i16 %86
  store i8 %63, ptr %87, align 1, !tbaa !6
  %88 = zext nneg i8 %73 to i16
  %89 = sub i16 %65, %88
  %90 = icmp eq i16 %89, 0
  br i1 %90, label %91, label %64, !llvm.loop !130

91:                                               ; preds = %64, %72, %21
  store i16 %19, ptr %2, align 1, !tbaa !2
  br label %92

92:                                               ; preds = %18, %91
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_blank(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, i16 noundef %2, i16 noundef range(i16 -2050, 225) %3) unnamed_addr #5 {
  %5 = icmp sgt i16 %3, %2
  br i1 %5, label %6, label %83

6:                                                ; preds = %4
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 2
  br label %9

9:                                                ; preds = %6, %79
  %10 = phi i16 [ %2, %6 ], [ %81, %79 ]
  %11 = sub nsw i16 %3, %10
  %12 = icmp sgt i16 %11, 112
  br i1 %12, label %16, label %13

13:                                               ; preds = %9
  %14 = trunc i16 %11 to i8
  %15 = icmp eq i8 %14, 0
  br i1 %15, label %79, label %16

16:                                               ; preds = %9, %13
  %17 = phi i8 [ %14, %13 ], [ 112, %9 ]
  %18 = phi i16 [ %11, %13 ], [ 112, %9 ]
  %19 = sub nsw i16 144, %10
  %20 = zext i8 %17 to i16
  %21 = trunc i16 %19 to i8
  %22 = lshr i16 %19, 8
  %23 = trunc nuw i16 %22 to i8
  br label %24

24:                                               ; preds = %32, %16
  %25 = phi i16 [ %20, %16 ], [ %49, %32 ]
  %26 = load i8, ptr %7, align 1, !tbaa !129
  %27 = icmp ult i8 %26, 22
  br i1 %27, label %28, label %51

28:                                               ; preds = %24
  %29 = icmp ugt i16 %25, 127
  br i1 %29, label %32, label %30

30:                                               ; preds = %28
  %31 = trunc nuw nsw i16 %25 to i8
  br label %32

32:                                               ; preds = %30, %28
  %33 = phi i8 [ %31, %30 ], [ 127, %28 ]
  %34 = load ptr, ptr %0, align 1, !tbaa !127
  %35 = add nuw nsw i8 %26, 1
  store i8 %35, ptr %7, align 1, !tbaa !129
  %36 = zext nneg i8 %26 to i16
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 %36
  store i8 %33, ptr %37, align 1, !tbaa !6
  %38 = load ptr, ptr %0, align 1, !tbaa !127
  %39 = load i8, ptr %7, align 1, !tbaa !129
  %40 = add i8 %39, 1
  store i8 %40, ptr %7, align 1, !tbaa !129
  %41 = zext i8 %39 to i16
  %42 = getelementptr inbounds nuw i8, ptr %38, i16 %41
  store i8 %21, ptr %42, align 1, !tbaa !6
  %43 = load ptr, ptr %0, align 1, !tbaa !127
  %44 = load i8, ptr %7, align 1, !tbaa !129
  %45 = add i8 %44, 1
  store i8 %45, ptr %7, align 1, !tbaa !129
  %46 = zext i8 %44 to i16
  %47 = getelementptr inbounds nuw i8, ptr %43, i16 %46
  store i8 %23, ptr %47, align 1, !tbaa !6
  %48 = zext nneg i8 %33 to i16
  %49 = sub i16 %25, %48
  %50 = icmp eq i16 %49, 0
  br i1 %50, label %51, label %24, !llvm.loop !130

51:                                               ; preds = %24, %32
  br label %52

52:                                               ; preds = %51, %60
  %53 = phi i16 [ %77, %60 ], [ %20, %51 ]
  %54 = load i8, ptr %8, align 1, !tbaa !129
  %55 = icmp ult i8 %54, 22
  br i1 %55, label %56, label %79

56:                                               ; preds = %52
  %57 = icmp ugt i16 %53, 127
  br i1 %57, label %60, label %58

58:                                               ; preds = %56
  %59 = trunc nuw nsw i16 %53 to i8
  br label %60

60:                                               ; preds = %58, %56
  %61 = phi i8 [ %59, %58 ], [ 127, %56 ]
  %62 = load ptr, ptr %1, align 1, !tbaa !127
  %63 = add nuw nsw i8 %54, 1
  store i8 %63, ptr %8, align 1, !tbaa !129
  %64 = zext nneg i8 %54 to i16
  %65 = getelementptr inbounds nuw i8, ptr %62, i16 %64
  store i8 %61, ptr %65, align 1, !tbaa !6
  %66 = load ptr, ptr %1, align 1, !tbaa !127
  %67 = load i8, ptr %8, align 1, !tbaa !129
  %68 = add i8 %67, 1
  store i8 %68, ptr %8, align 1, !tbaa !129
  %69 = zext i8 %67 to i16
  %70 = getelementptr inbounds nuw i8, ptr %66, i16 %69
  store i8 0, ptr %70, align 1, !tbaa !6
  %71 = load ptr, ptr %1, align 1, !tbaa !127
  %72 = load i8, ptr %8, align 1, !tbaa !129
  %73 = add i8 %72, 1
  store i8 %73, ptr %8, align 1, !tbaa !129
  %74 = zext i8 %72 to i16
  %75 = getelementptr inbounds nuw i8, ptr %71, i16 %74
  store i8 0, ptr %75, align 1, !tbaa !6
  %76 = zext nneg i8 %61 to i16
  %77 = sub i16 %53, %76
  %78 = icmp eq i16 %77, 0
  br i1 %78, label %79, label %52, !llvm.loop !130

79:                                               ; preds = %52, %60, %13
  %80 = phi i16 [ %11, %13 ], [ %18, %60 ], [ %18, %52 ]
  %81 = add nsw i16 %80, %10
  %82 = icmp sgt i16 %3, %81
  br i1 %82, label %9, label %83, !llvm.loop !131

83:                                               ; preds = %79, %4
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, argmem: none, target_mem: none)
define internal fastcc i16 @bitboard64_step(i16 noundef %0, i16 noundef %1) unnamed_addr #6 {
  %3 = load i64, ptr @bitboard64_state.0, align 1, !tbaa !90
  %4 = lshr i64 %3, 1
  %5 = and i64 %4, 9187201950435737471
  %6 = lshr i64 %3, 2
  %7 = and i64 %6, 4557430888798830399
  %8 = shl i64 %3, 1
  %9 = and i64 %8, -72340172838076674
  %10 = shl i64 %3, 2
  %11 = and i64 %10, -217020518514230020
  %12 = or i64 %5, %9
  %13 = or i64 %7, %11
  %14 = shl i64 %12, 16
  %15 = lshr i64 %12, 16
  %16 = or i64 %14, %15
  %17 = shl i64 %13, 8
  %18 = or i64 %16, %17
  %19 = lshr i64 %13, 8
  %20 = or i64 %18, %19
  %21 = load i64, ptr @bitboard64_state.1, align 1, !tbaa !93
  %22 = xor i64 %21, -1
  %23 = and i64 %20, %22
  store volatile i64 %20, ptr @bitboard64_opaque, align 8, !tbaa !132
  %24 = load volatile i64, ptr @bitboard64_opaque, align 8, !tbaa !132
  %25 = tail call fastcc zeroext i8 @bitboard64_pop(i64 noundef %24) #15
  %26 = icmp eq i64 %23, 0
  br i1 %26, label %27, label %41

27:                                               ; preds = %2
  %28 = mul i16 %1, 13
  %29 = zext nneg i8 %25 to i16
  %30 = mul nuw nsw i16 %29, 7
  %31 = add i16 %30, %28
  %32 = trunc i16 %31 to i8
  %33 = and i8 %32, 63
  %34 = icmp eq i8 %33, 0
  br i1 %34, label %41, label %35

35:                                               ; preds = %27, %35
  %36 = phi i64 [ %39, %35 ], [ 1, %27 ]
  %37 = phi i8 [ %38, %35 ], [ %33, %27 ]
  %38 = add nsw i8 %37, -1
  %39 = shl i64 %36, 1
  %40 = icmp eq i8 %38, 0
  br i1 %40, label %41, label %35, !llvm.loop !100

41:                                               ; preds = %35, %27, %2
  %42 = phi i64 [ %23, %2 ], [ 1, %27 ], [ %39, %35 ]
  %43 = phi i64 [ %21, %2 ], [ 0, %27 ], [ 0, %35 ]
  store volatile i64 %42, ptr @bitboard64_opaque, align 8, !tbaa !132
  %44 = load volatile i64, ptr @bitboard64_opaque, align 8, !tbaa !132
  %45 = tail call fastcc zeroext i8 @bitboard64_ctz(i64 noundef %44) #15
  %46 = icmp eq i8 %45, 0
  br i1 %46, label %53, label %47

47:                                               ; preds = %41, %47
  %48 = phi i64 [ %51, %47 ], [ 1, %41 ]
  %49 = phi i8 [ %50, %47 ], [ %45, %41 ]
  %50 = add nsw i8 %49, -1
  %51 = shl i64 %48, 1
  %52 = icmp eq i8 %50, 0
  br i1 %52, label %53, label %47, !llvm.loop !100

53:                                               ; preds = %47, %41
  %54 = phi i64 [ 1, %41 ], [ %51, %47 ]
  store volatile i64 %54, ptr @bitboard64_opaque, align 8, !tbaa !132
  %55 = load volatile i64, ptr @bitboard64_opaque, align 8, !tbaa !132
  %56 = tail call fastcc zeroext i8 @bitboard64_clz(i64 noundef %55) #15
  store i64 %54, ptr @bitboard64_state.0, align 1, !tbaa !90
  %57 = or i64 %43, %54
  store i64 %57, ptr @bitboard64_state.1, align 1, !tbaa !93
  %58 = lshr i64 %54, 1
  %59 = and i64 %58, 9187201950435737471
  %60 = lshr i64 %54, 2
  %61 = and i64 %60, 4557430888798830399
  %62 = shl i64 %54, 1
  %63 = and i64 %62, -72340172838076674
  %64 = shl i64 %54, 2
  %65 = and i64 %64, -217020518514230020
  %66 = or i64 %59, %63
  %67 = or i64 %61, %65
  %68 = shl i64 %66, 16
  %69 = lshr i64 %66, 16
  %70 = or i64 %68, %69
  %71 = shl i64 %67, 8
  %72 = or i64 %70, %71
  %73 = lshr i64 %67, 8
  %74 = or i64 %72, %73
  store i64 %74, ptr @bitboard64_state.2, align 1, !tbaa !95
  %75 = tail call i16 @llvm.fshl.i16(i16 %0, i16 %0, i16 5)
  %76 = zext nneg i8 %45 to i16
  %77 = zext nneg i8 %25 to i16
  %78 = shl nuw nsw i16 %77, 8
  %79 = or disjoint i16 %78, %76
  %80 = xor i16 %79, %75
  %81 = zext nneg i8 %56 to i16
  %82 = add i16 %80, %81
  %83 = trunc i64 %57 to i16
  %84 = add i16 %82, %83
  %85 = lshr i64 %57, 32
  %86 = trunc i64 %85 to i16
  %87 = add i16 %84, %86
  ret i16 %87
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none)
define internal fastcc zeroext range(i8 0, 65) i8 @bitboard64_pop(i64 noundef %0) unnamed_addr #7 {
  %2 = tail call range(i64 0, 65) i64 @llvm.ctpop.i64(i64 %0)
  %3 = trunc nuw nsw i64 %2 to i8
  ret i8 %3
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none)
define internal fastcc zeroext range(i8 0, 64) i8 @bitboard64_ctz(i64 noundef %0) unnamed_addr #7 {
  %2 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %0, i1 true)
  %3 = trunc nuw nsw i64 %2 to i8
  ret i8 %3
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none)
define internal fastcc zeroext range(i8 0, 64) i8 @bitboard64_clz(i64 noundef %0) unnamed_addr #7 {
  %2 = tail call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %0, i1 true)
  %3 = trunc nuw nsw i64 %2 to i8
  ret i8 %3
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #8

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.cttz.i64(i64, i1 immarg) #9

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #9

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #10

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @upq_flush() unnamed_addr #11 {
  %1 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 177), align 1, !tbaa !133
  %2 = zext i8 %1 to i16
  %3 = shl nuw nsw i16 %2, 4
  %4 = add nuw nsw i16 %3, 17152
  %5 = inttoptr i16 %4 to ptr
  %6 = shl nuw i16 1, %2
  %7 = trunc i16 %6 to i8
  %8 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %108, label %10

10:                                               ; preds = %0
  %11 = getelementptr inbounds nuw i8, ptr %5, i16 1
  %12 = getelementptr inbounds nuw i8, ptr %5, i16 2
  %13 = getelementptr inbounds nuw i8, ptr %5, i16 3
  %14 = getelementptr inbounds nuw i8, ptr %5, i16 4
  %15 = getelementptr inbounds nuw i8, ptr %5, i16 5
  %16 = getelementptr inbounds nuw i8, ptr %5, i16 6
  br label %17

17:                                               ; preds = %10, %86
  %18 = phi i8 [ %8, %10 ], [ %89, %86 ]
  %19 = phi i16 [ 0, %10 ], [ %87, %86 ]
  %20 = phi i8 [ 0, %10 ], [ %88, %86 ]
  %21 = zext i8 %20 to i16
  %22 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %21
  %23 = getelementptr inbounds nuw i8, ptr %22, i16 10
  %24 = load i8, ptr %23, align 1, !tbaa !44
  switch i8 %24, label %44 [
    i8 3, label %25
    i8 4, label %34
  ]

25:                                               ; preds = %17
  %26 = load i16, ptr %22, align 1, !tbaa !46
  %27 = inttoptr i16 %26 to ptr
  %28 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %29 = load i16, ptr %28, align 1, !tbaa !50
  %30 = trunc i16 %29 to i8
  store volatile i8 %30, ptr %27, align 1, !tbaa !6
  %31 = load i16, ptr %28, align 1, !tbaa !50
  %32 = lshr i16 %31, 8
  %33 = trunc nuw i16 %32 to i8
  store volatile i8 %33, ptr %27, align 1, !tbaa !6
  br label %86

34:                                               ; preds = %17
  %35 = load i16, ptr %22, align 1, !tbaa !46
  %36 = inttoptr i16 %35 to ptr
  %37 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %38 = load i16, ptr %37, align 1, !tbaa !50
  %39 = trunc i16 %38 to i8
  store volatile i8 %39, ptr %36, align 1, !tbaa !6
  %40 = load i16, ptr %37, align 1, !tbaa !50
  %41 = lshr i16 %40, 8
  %42 = trunc nuw i16 %41 to i8
  %43 = getelementptr inbounds nuw i8, ptr %36, i16 1
  store volatile i8 %42, ptr %43, align 1, !tbaa !6
  br label %86

44:                                               ; preds = %17
  %45 = icmp eq i16 %19, 0
  br i1 %45, label %51, label %46

46:                                               ; preds = %44
  %47 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %48 = load i16, ptr %47, align 1, !tbaa !52
  %49 = add i16 %48, %19
  %50 = icmp ugt i16 %49, 5100
  br i1 %50, label %91, label %51

51:                                               ; preds = %46, %44
  switch i8 %24, label %59 [
    i8 0, label %52
    i8 1, label %56
  ]

52:                                               ; preds = %51
  %53 = getelementptr inbounds nuw i8, ptr %22, i16 9
  %54 = load i8, ptr %53, align 1, !tbaa !47
  store volatile i8 %54, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  %55 = load i16, ptr %22, align 1, !tbaa !46
  store volatile i16 %55, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %65

56:                                               ; preds = %51
  %57 = load i16, ptr %22, align 1, !tbaa !46
  %58 = trunc i16 %57 to i8
  store volatile i8 %58, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  br label %65

59:                                               ; preds = %51
  %60 = load i16, ptr %22, align 1, !tbaa !46
  %61 = trunc i16 %60 to i8
  store volatile i8 %61, ptr inttoptr (i16 8450 to ptr), align 2, !tbaa !6
  %62 = load i16, ptr %22, align 1, !tbaa !46
  %63 = lshr i16 %62, 8
  %64 = trunc nuw i16 %63 to i8
  store volatile i8 %64, ptr inttoptr (i16 8451 to ptr), align 1, !tbaa !6
  br label %65

65:                                               ; preds = %56, %59, %52
  %66 = getelementptr inbounds nuw i8, ptr %22, i16 8
  %67 = load i8, ptr %66, align 1, !tbaa !49
  store volatile i8 %67, ptr %5, align 16, !tbaa !6
  %68 = getelementptr inbounds nuw i8, ptr %22, i16 7
  %69 = load i8, ptr %68, align 1, !tbaa !48
  store volatile i8 %69, ptr %11, align 1, !tbaa !6
  %70 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %71 = load i16, ptr %70, align 1, !tbaa !50
  %72 = trunc i16 %71 to i8
  store volatile i8 %72, ptr %12, align 2, !tbaa !6
  %73 = load i16, ptr %70, align 1, !tbaa !50
  %74 = lshr i16 %73, 8
  %75 = trunc nuw i16 %74 to i8
  store volatile i8 %75, ptr %13, align 1, !tbaa !6
  %76 = getelementptr inbounds nuw i8, ptr %22, i16 6
  %77 = load i8, ptr %76, align 1, !tbaa !51
  store volatile i8 %77, ptr %14, align 4, !tbaa !6
  %78 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %79 = load i16, ptr %78, align 1, !tbaa !52
  %80 = trunc i16 %79 to i8
  store volatile i8 %80, ptr %15, align 1, !tbaa !6
  %81 = load i16, ptr %78, align 1, !tbaa !52
  %82 = lshr i16 %81, 8
  %83 = trunc nuw i16 %82 to i8
  store volatile i8 %83, ptr %16, align 2, !tbaa !6
  store volatile i8 %7, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !6
  %84 = load i16, ptr %78, align 1, !tbaa !52
  %85 = add i16 %84, %19
  br label %86

86:                                               ; preds = %65, %34, %25
  %87 = phi i16 [ %19, %25 ], [ %19, %34 ], [ %85, %65 ]
  %88 = add nuw i8 %20, 1
  %89 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %90 = icmp ult i8 %88, %89
  br i1 %90, label %17, label %91

91:                                               ; preds = %86, %46
  %92 = phi i8 [ %89, %86 ], [ %18, %46 ]
  %93 = phi i8 [ %88, %86 ], [ %20, %46 ]
  %94 = icmp ult i8 %93, %92
  br i1 %94, label %95, label %108

95:                                               ; preds = %91
  %96 = icmp eq i8 %93, 0
  br i1 %96, label %110, label %97

97:                                               ; preds = %95, %97
  %98 = phi i8 [ %101, %97 ], [ 0, %95 ]
  %99 = phi i8 [ %104, %97 ], [ %93, %95 ]
  %100 = zext i8 %99 to i16
  %101 = add i8 %98, 1
  %102 = zext i8 %98 to i16
  %103 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %102
  %104 = add nuw i8 %99, 1
  %105 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %100
  tail call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(11) %103, ptr noundef nonnull align 1 dereferenceable(11) %105, i16 11, i1 false), !tbaa.struct !134
  %106 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %107 = icmp ult i8 %104, %106
  br i1 %107, label %97, label %108, !llvm.loop !135

108:                                              ; preds = %97, %91, %0
  %109 = phi i8 [ 0, %91 ], [ 0, %0 ], [ %101, %97 ]
  store i8 %109, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  br label %110

110:                                              ; preds = %108, %95
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #12

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #13

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #13

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #3 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #4 = { nofree norecurse nosync nounwind optsize memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #5 = { nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #6 = { nofree noinline norecurse nounwind optsize memory(readwrite, argmem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #7 = { mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #8 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #11 = { nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #12 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #13 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #14 = { nounwind optsize }
attributes #15 = { optsize }
attributes #16 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!10, !4, i64 194}
!10 = !{!"", !11, i64 0, !12, i64 178, !13, i64 182, !4, i64 191, !4, i64 192, !4, i64 193, !4, i64 194, !4, i64 195}
!11 = !{!"", !4, i64 0, !4, i64 176, !4, i64 177}
!12 = !{!"", !3, i64 0, !3, i64 2}
!13 = !{!"", !4, i64 0, !4, i64 8}
!14 = !{!10, !4, i64 195}
!15 = !{!16, !18, i64 0}
!16 = !{!"", !17, i64 0, !4, i64 3, !3, i64 4099, !3, i64 4101, !3, i64 4103, !3, i64 4105, !4, i64 4107, !4, i64 4108}
!17 = !{!"Drawable", !18, i64 0, !4, i64 2}
!18 = !{!"any pointer", !4, i64 0}
!19 = !{!16, !4, i64 2}
!20 = !{!16, !3, i64 4103}
!21 = !{!16, !3, i64 4105}
!22 = !{!16, !4, i64 4107}
!23 = !{!16, !4, i64 4108}
!24 = !{!16, !3, i64 4099}
!25 = !{!16, !3, i64 4101}
!26 = !{!27, !18, i64 0}
!27 = !{!"", !17, i64 0, !3, i64 3, !4, i64 5, !4, i64 7, !4, i64 135}
!28 = !{!27, !4, i64 2}
!29 = !{!27, !3, i64 3}
!30 = distinct !{!30, !8}
!31 = !{!27, !4, i64 135}
!32 = !{!10, !4, i64 192}
!33 = !{!10, !4, i64 193}
!34 = !{!13, !4, i64 8}
!35 = !{!36, !36, i64 0}
!36 = !{!"p1 _ZTS8Drawable", !18, i64 0}
!37 = distinct !{null, null}
!38 = !{!10, !4, i64 191}
!39 = !{!17, !4, i64 2}
!40 = !{!17, !18, i64 0}
!41 = !{!42, !18, i64 0}
!42 = !{!"", !18, i64 0, !18, i64 2}
!43 = !{!11, !4, i64 176}
!44 = !{!45, !4, i64 10}
!45 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !4, i64 6, !4, i64 7, !4, i64 8, !4, i64 9, !4, i64 10}
!46 = !{!45, !3, i64 0}
!47 = !{!45, !4, i64 9}
!48 = !{!45, !4, i64 7}
!49 = !{!45, !4, i64 8}
!50 = !{!45, !3, i64 2}
!51 = !{!45, !4, i64 6}
!52 = !{!45, !3, i64 4}
!53 = distinct !{!53, !8}
!54 = !{!55, !18, i64 0}
!55 = !{!"", !17, i64 0, !56, i64 3, !56, i64 5, !56, i64 7, !56, i64 9, !4, i64 11, !4, i64 12, !3, i64 13, !3, i64 15, !3, i64 17, !3, i64 19, !3, i64 21, !3, i64 23, !4, i64 25, !3, i64 26, !4, i64 28, !4, i64 29, !4, i64 30, !4, i64 31, !4, i64 32, !4, i64 33, !3, i64 34, !3, i64 36, !57, i64 38, !57, i64 89}
!56 = !{!"p1 omnipotent char", !18, i64 0}
!57 = !{!"", !4, i64 0, !4, i64 50}
!58 = !{!55, !4, i64 2}
!59 = !{!55, !56, i64 3}
!60 = !{!55, !56, i64 5}
!61 = !{!55, !56, i64 7}
!62 = !{!55, !4, i64 11}
!63 = !{!55, !56, i64 9}
!64 = !{!55, !4, i64 12}
!65 = !{!55, !3, i64 13}
!66 = !{!55, !3, i64 15}
!67 = !{!55, !3, i64 17}
!68 = !{!55, !4, i64 28}
!69 = !{!55, !4, i64 29}
!70 = !{!55, !4, i64 31}
!71 = !{!55, !4, i64 32}
!72 = !{!55, !4, i64 30}
!73 = !{!55, !4, i64 25}
!74 = !{!55, !3, i64 34}
!75 = !{!55, !3, i64 36}
!76 = !{!55, !4, i64 33}
!77 = !{!42, !18, i64 2}
!78 = distinct !{null, null, null, null, null}
!79 = distinct !{!79, !8}
!80 = distinct !{!80, !8}
!81 = distinct !{!81, !8}
!82 = distinct !{null, null, null, null}
!83 = distinct !{!83, !8}
!84 = distinct !{null, null, null, null, null}
!85 = distinct !{!85, !8}
!86 = distinct !{!86, !8}
!87 = distinct !{null, null, null, null}
!88 = !{!55, !3, i64 19}
!89 = distinct !{null, null, null, null, null}
!90 = !{!91, !92, i64 0}
!91 = !{!"", !92, i64 0, !92, i64 8, !92, i64 16, !4, i64 24, !4, i64 25, !4, i64 26}
!92 = !{!"long long", !4, i64 0}
!93 = !{!91, !92, i64 8}
!94 = distinct !{!94, !8}
!95 = !{!91, !92, i64 16}
!96 = !{!97, !3, i64 4443}
!97 = !{!"", !10, i64 0, !16, i64 196, !27, i64 4305, !3, i64 4441, !3, i64 4443}
!98 = !{!97, !3, i64 4441}
!99 = distinct !{!99, !8}
!100 = distinct !{!100, !8}
!101 = distinct !{!101, !8}
!102 = !{!97, !3, i64 4295}
!103 = !{!97, !3, i64 4297}
!104 = distinct !{null, null, null}
!105 = distinct !{!105, !8}
!106 = distinct !{!106, !8}
!107 = distinct !{!107, !8}
!108 = distinct !{!108, !8}
!109 = distinct !{!109, !8}
!110 = distinct !{!110, !8}
!111 = distinct !{!111, !8}
!112 = distinct !{!112, !8}
!113 = distinct !{!113, !8}
!114 = distinct !{!114, !8}
!115 = distinct !{!115, !8}
!116 = distinct !{!116, !8}
!117 = distinct !{!117, !8}
!118 = distinct !{!118, !8}
!119 = distinct !{!119, !8}
!120 = !{!55, !3, i64 21}
!121 = !{!55, !3, i64 23}
!122 = distinct !{!122, !8}
!123 = !{!55, !3, i64 26}
!124 = !{!57, !4, i64 50}
!125 = distinct !{!125, !8}
!126 = distinct !{!126, !8}
!127 = !{!128, !18, i64 0}
!128 = !{!"", !18, i64 0, !4, i64 2}
!129 = !{!128, !4, i64 2}
!130 = distinct !{!130, !8}
!131 = distinct !{!131, !8}
!132 = !{!92, !92, i64 0}
!133 = !{!11, !4, i64 177}
!134 = !{i64 0, i64 2, !2, i64 2, i64 2, !2, i64 4, i64 2, !2, i64 6, i64 1, !6, i64 7, i64 1, !6, i64 8, i64 1, !6, i64 9, i64 1, !6, i64 10, i64 1, !6}
!135 = distinct !{!135, !8}
