; ModuleID = '/work/examples/snes/corpus/dblbridge_sim.c'
source_filename = "/work/examples/snes/corpus/dblbridge_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1
@db_ya = internal unnamed_addr global [6 x [64 x i8]] zeroinitializer, align 1
@db_yb = internal unnamed_addr global [6 x [64 x i8]] zeroinitializer, align 1
@db_div = internal unnamed_addr global [6 x i8] zeroinitializer, align 1
@db_dis = internal unnamed_addr global [6 x i16] zeroinitializer, align 1
@db_seeds = internal unnamed_addr constant [6 x float] [float 1.562500e-01, float 1.875000e-01, float 2.187500e-01, float 2.500000e-01, float 2.812500e-01, float 3.125000e-01], align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(6) @db_div, i8 64, i16 6, i1 false), !tbaa !6
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(12) @db_dis, i8 0, i16 12, i1 false), !tbaa !2
  br label %1

1:                                                ; preds = %15, %0
  %2 = phi i8 [ 0, %0 ], [ %32, %15 ]
  %3 = phi i8 [ 0, %0 ], [ %31, %15 ]
  %4 = phi ptr [ @db_yb, %0 ], [ %29, %15 ]
  %5 = phi ptr [ @db_ya, %0 ], [ %28, %15 ]
  %6 = phi i16 [ 20899, %0 ], [ %26, %15 ]
  %7 = phi i8 [ 0, %0 ], [ %27, %15 ]
  %8 = zext nneg i8 %3 to i16
  %9 = getelementptr i8, ptr @db_seeds, i16 %8
  %10 = load float, ptr %9, align 1, !tbaa !7
  %11 = zext nneg i8 %7 to i16
  %12 = getelementptr i8, ptr @db_div, i16 %11
  %13 = zext nneg i8 %2 to i16
  %14 = getelementptr i8, ptr @db_dis, i16 %13
  br label %33

15:                                               ; preds = %71
  %16 = load i8, ptr %12, align 1, !tbaa !6
  %17 = zext i8 %16 to i16
  %18 = xor i16 %101, %17
  %19 = tail call i16 @llvm.fshl.i16(i16 %18, i16 %18, i16 1)
  %20 = mul i16 %19, 25173
  %21 = add i16 %20, 13849
  %22 = load i16, ptr %14, align 1, !tbaa !2
  %23 = xor i16 %21, %22
  %24 = tail call i16 @llvm.fshl.i16(i16 %23, i16 %23, i16 1)
  %25 = mul i16 %24, 25173
  %26 = add i16 %25, 13849
  %27 = add nuw nsw i8 %7, 1
  %28 = getelementptr i8, ptr %5, i16 64
  %29 = getelementptr i8, ptr %4, i16 64
  %30 = icmp eq i8 %27, 6
  %31 = add nuw nsw i8 %3, 4
  %32 = add nuw nsw i8 %2, 2
  br i1 %30, label %104, label %1, !llvm.loop !9

33:                                               ; preds = %71, %1
  %34 = phi i16 [ %6, %1 ], [ %101, %71 ]
  %35 = phi i8 [ 0, %1 ], [ %102, %71 ]
  %36 = phi float [ %10, %1 ], [ %39, %71 ]
  %37 = phi float [ %10, %1 ], [ %38, %71 ]
  %38 = tail call fastcc float @db_step_f(float noundef %37) #4
  %39 = tail call fastcc float @db_step_d(float noundef %36) #4
  %40 = bitcast float %38 to i32
  %41 = bitcast float %39 to i32
  %42 = icmp sgt i32 %40, -1
  br i1 %42, label %43, label %49

43:                                               ; preds = %33
  %44 = fmul float %38, 9.600000e+01
  %45 = fptoui float %44 to i16
  %46 = icmp ugt i16 %45, 95
  %47 = trunc nuw nsw i16 %45 to i8
  br i1 %46, label %48, label %49

48:                                               ; preds = %43
  br label %49

49:                                               ; preds = %48, %43, %33
  %50 = phi i8 [ 0, %33 ], [ 95, %48 ], [ %47, %43 ]
  %51 = zext nneg i8 %35 to i16
  %52 = getelementptr i8, ptr %5, i16 %51
  store i8 %50, ptr %52, align 1, !tbaa !6
  %53 = icmp sgt i32 %41, -1
  br i1 %53, label %54, label %60

54:                                               ; preds = %49
  %55 = fmul float %39, 9.600000e+01
  %56 = fptoui float %55 to i16
  %57 = icmp ugt i16 %56, 95
  %58 = trunc nuw nsw i16 %56 to i8
  br i1 %57, label %59, label %60

59:                                               ; preds = %54
  br label %60

60:                                               ; preds = %59, %54, %49
  %61 = phi i8 [ 0, %49 ], [ 95, %59 ], [ %58, %54 ]
  %62 = getelementptr i8, ptr %4, i16 %51
  store i8 %61, ptr %62, align 1, !tbaa !6
  %63 = icmp eq i32 %40, %41
  br i1 %63, label %71, label %64

64:                                               ; preds = %60
  %65 = load i8, ptr %12, align 1, !tbaa !6
  %66 = icmp eq i8 %65, 64
  br i1 %66, label %67, label %68

67:                                               ; preds = %64
  store i8 %35, ptr %12, align 1, !tbaa !6
  br label %68

68:                                               ; preds = %67, %64
  %69 = load i16, ptr %14, align 1, !tbaa !2
  %70 = add i16 %69, 1
  store i16 %70, ptr %14, align 1, !tbaa !2
  br label %71

71:                                               ; preds = %68, %60
  %72 = trunc i32 %40 to i16
  %73 = xor i16 %34, %72
  %74 = tail call i16 @llvm.fshl.i16(i16 %73, i16 %73, i16 1)
  %75 = mul i16 %74, 25173
  %76 = add i16 %75, 13849
  %77 = lshr i32 %40, 16
  %78 = trunc nuw i32 %77 to i16
  %79 = xor i16 %76, %78
  %80 = tail call i16 @llvm.fshl.i16(i16 %79, i16 %79, i16 1)
  %81 = mul i16 %80, 25173
  %82 = add i16 %81, 13849
  %83 = trunc i32 %41 to i16
  %84 = xor i16 %82, %83
  %85 = tail call i16 @llvm.fshl.i16(i16 %84, i16 %84, i16 1)
  %86 = mul i16 %85, 25173
  %87 = add i16 %86, 13849
  %88 = lshr i32 %41, 16
  %89 = trunc nuw i32 %88 to i16
  %90 = xor i16 %87, %89
  %91 = tail call i16 @llvm.fshl.i16(i16 %90, i16 %90, i16 1)
  %92 = mul i16 %91, 25173
  %93 = add i16 %92, 13849
  %94 = zext nneg i8 %50 to i16
  %95 = zext nneg i8 %61 to i16
  %96 = shl nuw nsw i16 %95, 8
  %97 = or disjoint i16 %96, %94
  %98 = xor i16 %97, %93
  %99 = tail call i16 @llvm.fshl.i16(i16 %98, i16 %98, i16 1)
  %100 = mul i16 %99, 25173
  %101 = add i16 %100, 13849
  %102 = add nuw nsw i8 %35, 1
  %103 = icmp eq i8 %102, 64
  br i1 %103, label %15, label %33, !llvm.loop !11

104:                                              ; preds = %15
  %105 = xor i16 %26, 384
  %106 = tail call i16 @llvm.fshl.i16(i16 %105, i16 %105, i16 1)
  %107 = mul i16 %106, 25173
  %108 = add i16 %107, 13849
  store volatile i16 %108, ptr @corpus_result, align 1, !tbaa !2
  br label %109

109:                                              ; preds = %109, %104
  tail call void asm sideeffect "wai", ""() #5, !srcloc !12
  br label %109
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none)
define internal fastcc noundef float @db_step_f(float noundef %0) unnamed_addr #1 {
  %2 = fsub float 1.000000e+00, %0
  %3 = fmul float %0, %2
  %4 = fmul float %3, 3.906250e+00
  ret float %4
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none)
define internal fastcc noundef float @db_step_d(float noundef %0) unnamed_addr #1 {
  %2 = fpext float %0 to double
  %3 = fsub double 1.000000e+00, %2
  %4 = fmul double %3, %2
  %5 = fmul double %4, 3.906250e+00
  %6 = fptrunc double %5 to float
  ret float %6
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #2

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #3

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { optsize }
attributes #5 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = !{!8, !8, i64 0}
!8 = !{!"float", !4, i64 0}
!9 = distinct !{!9, !10}
!10 = !{!"llvm.loop.mustprogress"}
!11 = distinct !{!11, !10}
!12 = !{i64 1240}
