; ModuleID = '/work/examples/snes/corpus/dither_sim.c'
source_filename = "/work/examples/snes/corpus/dither_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1
@dither_gate_crc.out = internal unnamed_addr global [576 x i8] zeroinitializer, align 1
@DS_LV = internal unnamed_addr constant [4 x i16] [i16 0, i16 85, i16 170, i16 255], align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [66 x i16], align 1
  %2 = alloca [66 x i16], align 1
  %3 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %4 = getelementptr inbounds nuw i8, ptr %1, i16 4
  %5 = getelementptr inbounds nuw i8, ptr %2, i16 2
  %6 = getelementptr inbounds nuw i8, ptr %2, i16 4
  br label %7

7:                                                ; preds = %75, %0
  %8 = phi i16 [ 0, %0 ], [ %76, %75 ]
  %9 = phi i16 [ 0, %0 ], [ %87, %75 ]
  %10 = mul nuw nsw i16 %8, 37
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #5
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #5
  call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(52) %1, i8 0, i16 52, i1 false), !tbaa !2
  %11 = lshr i16 %10, 1
  %12 = lshr i16 %10, 2
  br label %13

13:                                               ; preds = %70, %7
  %14 = phi ptr [ @dither_gate_crc.out, %7 ], [ %72, %70 ]
  %15 = phi i8 [ 0, %7 ], [ %71, %70 ]
  %16 = zext nneg i8 %15 to i16
  call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(52) %2, i8 0, i16 52, i1 false), !tbaa !2
  %17 = mul nuw nsw i16 %16, 11
  %18 = add nuw nsw i16 %17, %12
  %19 = and i16 %18, 255
  %20 = load i16, ptr %3, align 1
  br label %21

21:                                               ; preds = %39, %13
  %22 = phi i16 [ %20, %13 ], [ %54, %39 ]
  %23 = phi i8 [ 0, %13 ], [ %69, %39 ]
  %24 = phi i8 [ 0, %13 ], [ %67, %39 ]
  %25 = zext nneg i8 %24 to i16
  %26 = mul nuw nsw i16 %25, 11
  %27 = add nuw nsw i16 %26, %11
  %28 = and i16 %27, 255
  %29 = add nuw nsw i16 %28, %19
  %30 = lshr i16 %29, 1
  %31 = zext nneg i8 %23 to i16
  %32 = add nsw i16 %30, %22
  %33 = icmp slt i16 %32, 43
  br i1 %33, label %39, label %34

34:                                               ; preds = %21
  %35 = icmp samesign ult i16 %32, 128
  br i1 %35, label %39, label %36

36:                                               ; preds = %34
  %37 = icmp samesign ult i16 %32, 213
  %38 = select i1 %37, i16 2, i16 3
  br label %39

39:                                               ; preds = %36, %34, %21
  %40 = phi i16 [ 0, %21 ], [ %38, %36 ], [ 1, %34 ]
  %41 = getelementptr inbounds nuw [2 x i8], ptr @DS_LV, i16 %40
  %42 = load i16, ptr %41, align 1, !tbaa !2
  %43 = sub nsw i16 %32, %42
  %44 = trunc nuw nsw i16 %40 to i8
  %45 = getelementptr i8, ptr %14, i16 %25
  store i8 %44, ptr %45, align 1, !tbaa !6
  %46 = mul nsw i16 %43, 7
  %47 = ashr i16 %46, 4
  %48 = mul nsw i16 %43, 3
  %49 = ashr i16 %48, 4
  %50 = mul nsw i16 %43, 5
  %51 = ashr i16 %50, 4
  %52 = getelementptr i8, ptr %4, i16 %31
  %53 = load i16, ptr %52, align 1, !tbaa !2
  %54 = add nsw i16 %47, %53
  store i16 %54, ptr %52, align 1, !tbaa !2
  %55 = getelementptr i8, ptr %2, i16 %31
  %56 = load i16, ptr %55, align 1, !tbaa !2
  %57 = add nsw i16 %56, %49
  store i16 %57, ptr %55, align 1, !tbaa !2
  %58 = getelementptr i8, ptr %5, i16 %31
  %59 = load i16, ptr %58, align 1, !tbaa !2
  %60 = add nsw i16 %59, %51
  store i16 %60, ptr %58, align 1, !tbaa !2
  %61 = getelementptr i8, ptr %6, i16 %31
  %62 = load i16, ptr %61, align 1, !tbaa !2
  %63 = add nsw i16 %49, %47
  %64 = add nsw i16 %63, %51
  %65 = sub i16 %43, %64
  %66 = add nsw i16 %65, %62
  store i16 %66, ptr %61, align 1, !tbaa !2
  %67 = add nuw nsw i8 %24, 1
  %68 = icmp eq i8 %67, 24
  %69 = add nuw nsw i8 %23, 2
  br i1 %68, label %70, label %21, !llvm.loop !7

70:                                               ; preds = %39
  call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(52) %1, ptr noundef nonnull align 1 dereferenceable(52) %2, i16 52, i1 false), !tbaa !2
  %71 = add nuw nsw i8 %15, 1
  %72 = getelementptr i8, ptr %14, i16 24
  %73 = icmp eq i8 %71, 24
  br i1 %73, label %74, label %13, !llvm.loop !9

74:                                               ; preds = %70
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #5
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #5
  br label %78

75:                                               ; preds = %78
  %76 = add nuw nsw i16 %8, 1
  %77 = icmp eq i16 %76, 3
  br i1 %77, label %90, label %7, !llvm.loop !10

78:                                               ; preds = %78, %74
  %79 = phi i16 [ 0, %74 ], [ %88, %78 ]
  %80 = phi i16 [ %9, %74 ], [ %87, %78 ]
  %81 = getelementptr inbounds nuw i8, ptr @dither_gate_crc.out, i16 %79
  %82 = load i8, ptr %81, align 1, !tbaa !6
  %83 = zext i8 %82 to i16
  %84 = shl nuw nsw i16 %79, 2
  %85 = tail call i16 @llvm.fshl.i16(i16 %80, i16 %80, i16 1)
  %86 = xor i16 %85, %84
  %87 = xor i16 %86, %83
  %88 = add nuw nsw i16 %79, 1
  %89 = icmp eq i16 %88, 576
  br i1 %89, label %75, label %78, !llvm.loop !11

90:                                               ; preds = %75
  store volatile i16 %87, ptr @corpus_result, align 1, !tbaa !2
  br label %91

91:                                               ; preds = %91, %90
  tail call void asm sideeffect "wai", ""() #5, !srcloc !12
  br label %91
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #2

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #4

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = distinct !{!9, !8}
!10 = distinct !{!10, !8}
!11 = distinct !{!11, !8}
!12 = !{i64 309}
