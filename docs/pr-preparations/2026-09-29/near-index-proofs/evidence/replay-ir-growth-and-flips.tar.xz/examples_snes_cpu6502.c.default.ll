; ModuleID = '/work/examples/snes/cpu6502.c'
source_filename = "/work/examples/snes/cpu6502.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.App = type { %struct.Display, %struct.TextGrid, %struct.CPU6502, i8, i8, [6 x i16], i8 }
%struct.Display = type { %struct.UploadQueue, %struct.VramAlloc, %struct.Scene, i8, i8, i8, i8, i8 }
%struct.UploadQueue = type { [16 x %struct.UpqJob], i8, i8 }
%struct.UpqJob = type { i16, i16, i16, i8, i8, i8, i8, i8 }
%struct.VramAlloc = type { i16, i16 }
%struct.Scene = type { [4 x ptr], i8 }
%struct.TextGrid = type { %struct.Drawable, [896 x i16], i8 }
%struct.Drawable = type { ptr, i8 }
%struct.CPU6502 = type { i8, i8, i8, i8, i8, i16, [256 x i8] }
%struct.TitleLayer = type { %struct.Drawable, ptr, ptr, ptr, ptr, i8, i8, i16, i16, i16, i16, i16, i16, i8, i16, i8, i8, i8, i8, i8, i8, i16, i16, %struct.HScrollDB, %struct.HScrollDB }
%struct.HScrollDB = type { [2 x %struct.HScrollN], i8 }
%struct.HScrollN = type { [25 x i8] }
%struct.DrawableVT = type { ptr, ptr }
%struct.OpcodeInfo = type { [4 x i8], i8, i8, i8 }
%struct.HScrollW = type { ptr, i8 }

@main.a = internal global %struct.App zeroinitializer, align 1
@main.title = internal global %struct.TitleLayer zeroinitializer, align 1
@.str = private unnamed_addr constant [19 x i8] c"DISASSEMBLER + ALU\00", align 1
@.str.1 = private unnamed_addr constant [15 x i8] c"6502 SIMULATOR\00", align 1
@corpus_result = dso_local global i16 0, align 1
@TG_VT = internal constant %struct.DrawableVT { ptr @_tg_reserve, ptr @_tg_emit }, align 1
@FONT16 = internal unnamed_addr constant [2048 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 192, i16 192, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 768, i16 768, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 -4096, i16 -4096, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3840, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 3312, i16 15360, i16 15360, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 28, i16 28, i16 796, i16 127, i16 127, i16 796, i16 796, i16 127, i16 112, i16 112, i16 3184, i16 252, i16 252, i16 -28816, i16 -28816, i16 252, i16 127, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 0, i16 0, i16 252, i16 -28816, i16 -28816, i16 3184, i16 7168, i16 7168, i16 0, i16 0, i16 3, i16 63, i16 123, i16 1147, i16 63, i16 4111, i16 3075, i16 123, i16 192, i16 248, i16 8414, i16 16064, i16 2040, i16 248, i16 8414, i16 8414, i16 63, i16 7171, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 2040, i16 14272, i16 -512, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3585, i16 3, i16 7, i16 28, i16 56, i16 1904, i16 3808, i16 7392, i16 14528, i16 14464, i16 28672, i16 14, i16 284, i16 824, i16 1792, i16 3584, i16 0, i16 0, i16 0, i16 -8162, i16 -16354, i16 -32482, i16 286, i16 1792, i16 1792, i16 0, i16 0, i16 15, i16 31, i16 828, i16 828, i16 573, i16 31, i16 31, i16 63, i16 192, i16 224, i16 240, i16 2288, i16 7392, i16 15488, i16 30720, i16 -32648, i16 382, i16 3060, i16 3825, i16 1275, i16 127, i16 63, i16 7936, i16 3840, i16 248, i16 3824, i16 7904, i16 7392, i16 4332, i16 12492, i16 -1280, i16 -3328, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 7, i16 15, i16 15, i16 15, i16 15, i16 15, i16 240, i16 192, i16 15488, i16 -4096, i16 -8192, i16 -16384, i16 -16384, i16 -16384, i16 15, i16 7, i16 3, i16 256, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 16512, i16 192, i16 240, i16 -4096, i16 15360, i16 0, i16 0, i16 15, i16 3, i16 513, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 224, i16 240, i16 2288, i16 3312, i16 3312, i16 3312, i16 0, i16 1, i16 3, i16 15, i16 0, i16 768, i16 0, i16 0, i16 3312, i16 7392, i16 15552, i16 30720, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 51, i16 31, i16 15, i16 1027, i16 0, i16 0, i16 192, i16 192, i16 12492, i16 252, i16 1016, i16 16320, i16 15, i16 31, i16 51, i16 1027, i16 3072, i16 0, i16 0, i16 0, i16 1784, i16 252, i16 13004, i16 16320, i16 -3328, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 3, i16 63, i16 63, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 248, i16 248, i16 63, i16 3075, i16 3075, i16 3, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 16064, i16 16064, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 286, i16 828, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 28800, i16 -4096, i16 -8192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 -512, i16 -512, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7360, i16 14464, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7168, i16 14336, i16 28672, i16 -8192, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 828, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 15, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 1, i16 3, i16 15, i16 15, i16 513, i16 513, i16 1, i16 1, i16 240, i16 240, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 1, i16 1, i16 1, i16 1, i16 1, i16 1, i16 0, i16 0, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 31744, i16 31744, i16 15, i16 31, i16 318, i16 828, i16 3840, i16 3840, i16 3, i16 15, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 63, i16 510, i16 4080, i16 31, i16 318, i16 318, i16 318, i16 63, i16 63, i16 3840, i16 3840, i16 32640, i16 -1024, i16 -8192, i16 -32768, i16 255, i16 255, i16 -256, i16 -256, i16 15, i16 63, i16 824, i16 3840, i16 2055, i16 7, i16 256, i16 256, i16 252, i16 254, i16 -8161, i16 -4081, i16 510, i16 1020, i16 -7906, i16 -4081, i16 0, i16 0, i16 56, i16 60, i16 63, i16 31, i16 3840, i16 1792, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 15, i16 286, i16 62, i16 126, i16 510, i16 510, i16 8670, i16 24990, i16 -7906, i16 -7906, i16 828, i16 828, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 -16098, i16 -32482, i16 255, i16 255, i16 -7906, i16 -7906, i16 1792, i16 1792, i16 31, i16 63, i16 828, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 254, i16 254, i16 -256, i16 -256, i16 252, i16 254, i16 -8161, i16 -4081, i16 0, i16 0, i16 60, i16 62, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 63, i16 63, i16 318, i16 828, i16 254, i16 255, i16 -2041, i16 -256, i16 508, i16 254, i16 -4081, i16 -2041, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 -32761, i16 7, i16 7, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 31, i16 318, i16 892, i16 0, i16 1, i16 3, i16 7, i16 7, i16 7, i16 256, i16 256, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 28800, i16 -8192, i16 -8192, i16 15, i16 31, i16 828, i16 828, i16 828, i16 31, i16 15, i16 796, i16 252, i16 254, i16 -4081, i16 -4081, i16 15, i16 510, i16 1020, i16 -3826, i16 828, i16 828, i16 828, i16 828, i16 31, i16 15, i16 1792, i16 768, i16 -4081, i16 15, i16 15, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 318, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 31, i16 31, i16 15, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 270, i16 796, i16 824, i16 1792, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 15, i16 60, i16 828, i16 0, i16 0, i16 60, i16 240, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 15360, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 60, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 60, i16 0, i16 3, i16 15, i16 60, i16 768, i16 3840, i16 0, i16 0, i16 4080, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 31, i16 63, i16 828, i16 3840, i16 3840, i16 7, i16 7, i16 7, i16 240, i16 248, i16 -32644, i16 -32132, i16 2040, i16 4080, i16 16064, i16 31872, i16 256, i16 256, i16 7, i16 7, i16 7, i16 256, i16 256, i16 0, i16 -4096, i16 -8192, i16 128, i16 128, i16 24704, i16 -8192, i16 -8192, i16 0, i16 31, i16 63, i16 828, i16 573, i16 573, i16 573, i16 573, i16 573, i16 248, i16 252, i16 -15812, i16 4590, i16 494, i16 4590, i16 1020, i16 1016, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 0, i16 0, i16 0, i16 32512, i16 764, i16 248, i16 -256, i16 -512, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 892, i16 1020, i16 1020, i16 255, i16 255, i16 224, i16 240, i16 -32648, i16 -16324, i16 -32196, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -28928, i16 1792, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 0, i16 0, i16 28, i16 60, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -8164, i16 -3572, i16 -30976, i16 768, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 8988, i16 8988, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 60, i16 60, i16 828, i16 828, i16 828, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 255, i16 255, i16 16128, i16 16128, i16 12480, i16 12480, i16 12480, i16 12480, i16 252, i16 252, i16 -256, i16 -256, i16 63, i16 63, i16 3075, i16 3075, i16 3, i16 3, i16 51, i16 51, i16 252, i16 252, i16 4080, i16 4080, i16 3312, i16 3312, i16 3312, i16 3312, i16 3123, i16 3123, i16 63, i16 63, i16 31, i16 15, i16 1792, i16 768, i16 3312, i16 3312, i16 3312, i16 3312, i16 7392, i16 15552, i16 -2048, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 765, i16 255, i16 255, i16 255, i16 28, i16 60, i16 1912, i16 4080, i16 7904, i16 15552, i16 30848, i16 12480, i16 255, i16 765, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 224, i16 240, i16 248, i16 124, i16 572, i16 828, i16 3840, i16 3840, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 0, i16 0, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 248, i16 252, i16 254, i16 2295, i16 3315, i16 3315, i16 3315, i16 3315, i16 60, i16 124, i16 1020, i16 988, i16 9116, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 15360, i16 15360, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 -6400, i16 -6400, i16 240, i16 248, i16 252, i16 254, i16 255, i16 255, i16 2295, i16 3315, i16 60, i16 60, i16 828, i16 828, i16 828, i16 956, i16 1020, i16 1020, i16 3313, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 15360, i16 15360, i16 1020, i16 1020, i16 892, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -31972, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -512, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 224, i16 240, i16 -32648, i16 -15304, i16 -31176, i16 1592, i16 1592, i16 1592, i16 765, i16 765, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 1784, i16 1784, i16 17976, i16 1656, i16 764, i16 764, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 63, i16 127, i16 2040, i16 4080, i16 1784, i16 255, i16 127, i16 63, i16 248, i16 252, i16 -15812, i16 -256, i16 3840, i16 240, i16 248, i16 252, i16 7936, i16 3840, i16 224, i16 255, i16 255, i16 127, i16 16128, i16 7936, i16 -32132, i16 -15556, i16 892, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 -4096, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 28, i16 28, i16 796, i16 796, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 510, i16 255, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 828, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 248, i16 248, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 124, i16 124, i16 1912, i16 1912, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 572, i16 63, i16 31, i16 15, i16 7, i16 768, i16 256, i16 1656, i16 3824, i16 3824, i16 7392, i16 15552, i16 30848, i16 -4096, i16 -8192, i16 243, i16 243, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 156, i16 156, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 2295, i16 255, i16 510, i16 892, i16 16128, i16 7936, i16 25500, i16 25500, i16 9180, i16 1020, i16 1020, i16 -30856, i16 -16640, i16 7680, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 15, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 14528, i16 31, i16 63, i16 892, i16 2040, i16 4080, i16 3824, i16 15360, i16 15360, i16 4320, i16 240, i16 248, i16 -32644, i16 572, i16 828, i16 3840, i16 3840, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 7, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 7, i16 7, i16 7, i16 7, i16 7, i16 7, i16 256, i16 256, i16 28800, i16 24704, i16 24704, i16 24704, i16 24704, i16 24704, i16 -8192, i16 -8192, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 1, i16 3, i16 7, i16 252, i16 252, i16 1020, i16 -31876, i16 2040, i16 4080, i16 7904, i16 15552, i16 15, i16 31, i16 318, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 30848, i16 -4096, i16 -8192, i16 252, i16 252, i16 1020, i16 -256, i16 -256, i16 31, i16 31, i16 286, i16 286, i16 286, i16 286, i16 286, i16 286, i16 224, i16 224, i16 -2048, i16 -2048, i16 -32768, i16 -32768, i16 -32768, i16 -32768, i16 286, i16 286, i16 286, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 -32768, i16 -32768, i16 -32768, i16 224, i16 224, i16 -2048, i16 -2048, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 3, i16 1, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 128, i16 192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 768, i16 256, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 0, i16 0, i16 0, i16 224, i16 224, i16 2288, i16 2288, i16 3312, i16 3312, i16 3312, i16 3312, i16 0, i16 0, i16 0, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 3312, i16 3312, i16 3312, i16 7392, i16 7392, i16 -2048, i16 -2048, i16 0, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1840, i16 3584, i16 3072, i16 192, i16 224, i16 -32656, i16 -16328, i16 -32740, i16 524, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 127, i16 127, i16 7936, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 -512], align 1
@FONT8 = internal unnamed_addr constant [512 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 32, i16 0, i16 80, i16 80, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 80, i16 80, i16 248, i16 80, i16 248, i16 80, i16 80, i16 0, i16 32, i16 120, i16 160, i16 112, i16 40, i16 240, i16 32, i16 0, i16 196, i16 200, i16 16, i16 32, i16 64, i16 152, i16 12, i16 0, i16 96, i16 144, i16 160, i16 64, i16 168, i16 144, i16 104, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 16, i16 32, i16 64, i16 64, i16 64, i16 32, i16 16, i16 0, i16 64, i16 32, i16 16, i16 16, i16 16, i16 32, i16 64, i16 0, i16 0, i16 32, i16 168, i16 112, i16 168, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 248, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 64, i16 0, i16 0, i16 0, i16 248, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 0, i16 8, i16 8, i16 16, i16 32, i16 64, i16 128, i16 128, i16 0, i16 112, i16 136, i16 152, i16 168, i16 200, i16 136, i16 112, i16 0, i16 32, i16 96, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 64, i16 248, i16 0, i16 112, i16 136, i16 8, i16 48, i16 8, i16 136, i16 112, i16 0, i16 16, i16 48, i16 80, i16 144, i16 248, i16 16, i16 16, i16 0, i16 248, i16 128, i16 240, i16 8, i16 8, i16 136, i16 112, i16 0, i16 112, i16 136, i16 128, i16 240, i16 136, i16 136, i16 112, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 64, i16 64, i16 0, i16 112, i16 136, i16 136, i16 112, i16 136, i16 136, i16 112, i16 0, i16 112, i16 136, i16 136, i16 120, i16 8, i16 136, i16 112, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 64, i16 0, i16 16, i16 32, i16 64, i16 128, i16 64, i16 32, i16 16, i16 0, i16 0, i16 0, i16 248, i16 0, i16 248, i16 0, i16 0, i16 0, i16 128, i16 64, i16 32, i16 16, i16 32, i16 64, i16 128, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 0, i16 32, i16 0, i16 112, i16 136, i16 184, i16 168, i16 184, i16 128, i16 112, i16 0, i16 112, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 240, i16 136, i16 136, i16 240, i16 136, i16 136, i16 240, i16 0, i16 112, i16 136, i16 128, i16 128, i16 128, i16 136, i16 112, i16 0, i16 224, i16 144, i16 136, i16 136, i16 136, i16 144, i16 224, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 248, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 128, i16 176, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 112, i16 32, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 56, i16 16, i16 16, i16 16, i16 144, i16 144, i16 96, i16 0, i16 136, i16 144, i16 160, i16 192, i16 160, i16 144, i16 136, i16 0, i16 128, i16 128, i16 128, i16 128, i16 128, i16 128, i16 248, i16 0, i16 136, i16 216, i16 168, i16 136, i16 136, i16 136, i16 136, i16 0, i16 136, i16 200, i16 168, i16 152, i16 136, i16 136, i16 136, i16 0, i16 112, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 240, i16 136, i16 136, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 136, i16 136, i16 168, i16 144, i16 104, i16 0, i16 240, i16 136, i16 136, i16 240, i16 160, i16 144, i16 136, i16 0, i16 112, i16 136, i16 128, i16 112, i16 8, i16 136, i16 112, i16 0, i16 248, i16 32, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 80, i16 32, i16 0, i16 136, i16 136, i16 136, i16 168, i16 168, i16 216, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 80, i16 136, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 32, i16 32, i16 32, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 128, i16 248, i16 0, i16 48, i16 32, i16 32, i16 32, i16 32, i16 32, i16 48, i16 0, i16 128, i16 128, i16 64, i16 32, i16 16, i16 8, i16 8, i16 0, i16 48, i16 16, i16 16, i16 16, i16 16, i16 16, i16 48, i16 0, i16 32, i16 80, i16 136, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248], align 1
@GLYPH_HASH = internal unnamed_addr constant [8 x i16] [i16 0, i16 36, i16 126, i16 36, i16 126, i16 36, i16 0, i16 0], align 1
@GLYPH_DOLLAR = internal unnamed_addr constant [8 x i16] [i16 16, i16 124, i16 208, i16 120, i16 22, i16 124, i16 16, i16 0], align 1
@gate_chr = internal unnamed_addr global [384 x i16] zeroinitializer, align 1
@cgram = internal unnamed_addr constant [16 x i16] [i16 5186, i16 29396, i16 16679, i16 0, i16 5186, i16 10175, i16 16679, i16 0, i16 5186, i16 31376, i16 0, i16 0, i16 5186, i16 10175, i16 0, i16 0], align 1
@HELLO6502 = internal unnamed_addr constant [33 x i8] c"\A9\E0\85\F0\A9\03\85\F1\A9B\85\FF\A2\08\18i\01%\FFE\FF\05\FF\0AJ\C5\FF\CA\D0\F0L\08\00", align 1
@TITLE_VT = internal constant %struct.DrawableVT { ptr @_title_reserve, ptr @_title_emit }, align 1
@title_end._title_bg_black = internal constant i16 0, align 1
@.str.2 = private unnamed_addr constant [19 x i8] c"6502/65C02 CPU SIM\00", align 1
@CPU6502_OPS = internal unnamed_addr constant [256 x %struct.OpcodeInfo] [%struct.OpcodeInfo { [4 x i8] c"BRK\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ORA\00", i8 9, i8 2, i8 2 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"TSB\00", i8 2, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ORA\00", i8 2, i8 2, i8 2 }, %struct.OpcodeInfo { [4 x i8] c"ASL\00", i8 2, i8 2, i8 6 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"PHP\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ORA\00", i8 1, i8 2, i8 2 }, %struct.OpcodeInfo { [4 x i8] c"ASL\00", i8 0, i8 1, i8 6 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"TSB\00", i8 5, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ORA\00", i8 5, i8 3, i8 2 }, %struct.OpcodeInfo { [4 x i8] c"ASL\00", i8 5, i8 3, i8 6 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"BPL\00", i8 11, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ORA\00", i8 10, i8 2, i8 2 }, %struct.OpcodeInfo { [4 x i8] c"ORA\00", i8 12, i8 2, i8 2 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"TRB\00", i8 2, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ORA\00", i8 3, i8 2, i8 2 }, %struct.OpcodeInfo { [4 x i8] c"ASL\00", i8 3, i8 2, i8 6 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"CLC\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ORA\00", i8 7, i8 3, i8 2 }, %struct.OpcodeInfo { [4 x i8] c"INC\00", i8 0, i8 1, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"TRB\00", i8 5, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ORA\00", i8 6, i8 3, i8 2 }, %struct.OpcodeInfo { [4 x i8] c"ASL\00", i8 6, i8 3, i8 6 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"JSR\00", i8 5, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"AND\00", i8 9, i8 2, i8 1 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"BIT\00", i8 2, i8 2, i8 1 }, %struct.OpcodeInfo { [4 x i8] c"AND\00", i8 2, i8 2, i8 1 }, %struct.OpcodeInfo { [4 x i8] c"ROL\00", i8 2, i8 2, i8 6 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"PLP\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"AND\00", i8 1, i8 2, i8 1 }, %struct.OpcodeInfo { [4 x i8] c"ROL\00", i8 0, i8 1, i8 6 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"BIT\00", i8 5, i8 3, i8 1 }, %struct.OpcodeInfo { [4 x i8] c"AND\00", i8 5, i8 3, i8 1 }, %struct.OpcodeInfo { [4 x i8] c"ROL\00", i8 5, i8 3, i8 6 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"BMI\00", i8 11, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"AND\00", i8 10, i8 2, i8 1 }, %struct.OpcodeInfo { [4 x i8] c"AND\00", i8 12, i8 2, i8 1 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"BIT\00", i8 3, i8 2, i8 1 }, %struct.OpcodeInfo { [4 x i8] c"AND\00", i8 3, i8 2, i8 1 }, %struct.OpcodeInfo { [4 x i8] c"ROL\00", i8 3, i8 2, i8 6 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"SEC\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"AND\00", i8 7, i8 3, i8 1 }, %struct.OpcodeInfo { [4 x i8] c"DEC\00", i8 0, i8 1, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"BIT\00", i8 6, i8 3, i8 1 }, %struct.OpcodeInfo { [4 x i8] c"AND\00", i8 6, i8 3, i8 1 }, %struct.OpcodeInfo { [4 x i8] c"ROL\00", i8 6, i8 3, i8 6 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"RTI\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"EOR\00", i8 9, i8 2, i8 3 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"EOR\00", i8 2, i8 2, i8 3 }, %struct.OpcodeInfo { [4 x i8] c"LSR\00", i8 2, i8 2, i8 7 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"PHA\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"EOR\00", i8 1, i8 2, i8 3 }, %struct.OpcodeInfo { [4 x i8] c"LSR\00", i8 0, i8 1, i8 7 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"JMP\00", i8 5, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"EOR\00", i8 5, i8 3, i8 3 }, %struct.OpcodeInfo { [4 x i8] c"LSR\00", i8 5, i8 3, i8 7 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"BVC\00", i8 11, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"EOR\00", i8 10, i8 2, i8 3 }, %struct.OpcodeInfo { [4 x i8] c"EOR\00", i8 12, i8 2, i8 3 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"EOR\00", i8 3, i8 2, i8 3 }, %struct.OpcodeInfo { [4 x i8] c"LSR\00", i8 3, i8 2, i8 7 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"CLI\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"EOR\00", i8 7, i8 3, i8 3 }, %struct.OpcodeInfo { [4 x i8] c"PHY\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"EOR\00", i8 6, i8 3, i8 3 }, %struct.OpcodeInfo { [4 x i8] c"LSR\00", i8 6, i8 3, i8 7 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"RTS\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ADC\00", i8 9, i8 2, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STZ\00", i8 2, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ADC\00", i8 2, i8 2, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"ROR\00", i8 2, i8 2, i8 7 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"PLA\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ADC\00", i8 1, i8 2, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"ROR\00", i8 0, i8 1, i8 7 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"JMP\00", i8 8, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ADC\00", i8 5, i8 3, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"ROR\00", i8 5, i8 3, i8 7 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"BVS\00", i8 11, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ADC\00", i8 10, i8 2, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"ADC\00", i8 12, i8 2, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STZ\00", i8 3, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ADC\00", i8 3, i8 2, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"ROR\00", i8 3, i8 2, i8 7 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"SEI\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ADC\00", i8 7, i8 3, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"PLY\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"JMP\00", i8 6, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"ADC\00", i8 6, i8 3, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"ROR\00", i8 6, i8 3, i8 7 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"BRA\00", i8 11, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STA\00", i8 9, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STY\00", i8 2, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STA\00", i8 2, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STX\00", i8 2, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"DEY\00", i8 0, i8 1, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"BIT\00", i8 1, i8 2, i8 1 }, %struct.OpcodeInfo { [4 x i8] c"TXA\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STY\00", i8 5, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STA\00", i8 5, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STX\00", i8 5, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"BCC\00", i8 11, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STA\00", i8 10, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STA\00", i8 12, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STY\00", i8 3, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STA\00", i8 3, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STX\00", i8 4, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"TYA\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STA\00", i8 7, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"TXS\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STZ\00", i8 5, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STA\00", i8 6, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"STZ\00", i8 6, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDY\00", i8 1, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDA\00", i8 9, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDX\00", i8 1, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDY\00", i8 2, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDA\00", i8 2, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDX\00", i8 2, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"TAY\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDA\00", i8 1, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"TAX\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDY\00", i8 5, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDA\00", i8 5, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDX\00", i8 5, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"BCS\00", i8 11, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDA\00", i8 10, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDA\00", i8 12, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDY\00", i8 3, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDA\00", i8 3, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDX\00", i8 4, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"CLV\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDA\00", i8 7, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"TSX\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDY\00", i8 6, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDA\00", i8 6, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"LDX\00", i8 7, i8 3, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"CPY\00", i8 1, i8 2, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"CMP\00", i8 9, i8 2, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"CPY\00", i8 2, i8 2, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"CMP\00", i8 2, i8 2, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"DEC\00", i8 2, i8 2, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"INY\00", i8 0, i8 1, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"CMP\00", i8 1, i8 2, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"DEX\00", i8 0, i8 1, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"CPY\00", i8 5, i8 3, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"CMP\00", i8 5, i8 3, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"DEC\00", i8 5, i8 3, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"BNE\00", i8 11, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"CMP\00", i8 10, i8 2, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"CMP\00", i8 12, i8 2, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"CMP\00", i8 3, i8 2, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"DEC\00", i8 3, i8 2, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"CLD\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"CMP\00", i8 7, i8 3, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"PHX\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"CMP\00", i8 6, i8 3, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"DEC\00", i8 6, i8 3, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"CPX\00", i8 1, i8 2, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"SBC\00", i8 9, i8 2, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"CPX\00", i8 2, i8 2, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"SBC\00", i8 2, i8 2, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"INC\00", i8 2, i8 2, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"INX\00", i8 0, i8 1, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"SBC\00", i8 1, i8 2, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"NOP\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"CPX\00", i8 5, i8 3, i8 8 }, %struct.OpcodeInfo { [4 x i8] c"SBC\00", i8 5, i8 3, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"INC\00", i8 5, i8 3, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"BEQ\00", i8 11, i8 2, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"SBC\00", i8 10, i8 2, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"SBC\00", i8 12, i8 2, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"SBC\00", i8 3, i8 2, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"INC\00", i8 3, i8 2, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"SED\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"SBC\00", i8 7, i8 3, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"PLX\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }, %struct.OpcodeInfo { [4 x i8] c"SBC\00", i8 6, i8 3, i8 5 }, %struct.OpcodeInfo { [4 x i8] c"INC\00", i8 6, i8 3, i8 4 }, %struct.OpcodeInfo { [4 x i8] c"???\00", i8 0, i8 1, i8 0 }], align 1
@GATE_TYPE = internal unnamed_addr constant [8 x i8] c"\01\02\03\04\05\06\07\08", align 1
@GATE_LABEL = internal unnamed_addr constant [8 x [4 x i8]] [[4 x i8] c"AND\00", [4 x i8] c"OR \00", [4 x i8] c"XOR\00", [4 x i8] c"ADD\00", [4 x i8] c"SUB\00", [4 x i8] c"SHL\00", [4 x i8] c"SHR\00", [4 x i8] c"CMP\00"], align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca %struct.CPU6502, align 1
  store volatile i8 -113, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  br label %2

2:                                                ; preds = %6, %0
  %3 = phi i16 [ 8449, %0 ], [ %7, %6 ]
  switch i16 %3, label %4 [
    i16 8452, label %6
    i16 8470, label %6
    i16 8471, label %6
    i16 8472, label %6
    i16 8473, label %6
    i16 8481, label %6
    i16 8482, label %6
  ]

4:                                                ; preds = %2
  %5 = inttoptr i16 %3 to ptr
  store volatile i8 0, ptr %5, align 1, !tbaa !6
  br label %6

6:                                                ; preds = %4, %2, %2, %2, %2, %2, %2, %2
  %7 = add nuw nsw i16 %3, 1
  %8 = icmp eq i16 %7, 8500
  br i1 %8, label %9, label %2, !llvm.loop !7

9:                                                ; preds = %6
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) getelementptr inbounds nuw (i8, ptr @main.a, i16 176), i8 0, i64 6, i1 false)
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  store volatile i8 1, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 -127, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !6
  store ptr @TG_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), align 1, !tbaa !15
  store i8 4, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !19
  br label %10

10:                                               ; preds = %10, %9
  %11 = phi i16 [ 0, %9 ], [ %13, %10 ]
  %12 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %11
  store i16 256, ptr %12, align 1, !tbaa !2
  %13 = add nuw nsw i16 %11, 1
  %14 = icmp eq i16 %13, 896
  br i1 %14, label %15, label %10, !llvm.loop !20

15:                                               ; preds = %10
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1991), align 1, !tbaa !21
  %16 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !22
  %17 = icmp eq i8 %16, 0
  br i1 %17, label %19, label %18

18:                                               ; preds = %15
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !23
  br label %19

19:                                               ; preds = %18, %15
  %20 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %21 = icmp ult i8 %20, 4
  br i1 %21, label %22, label %26

22:                                               ; preds = %19
  %23 = zext nneg i8 %20 to i16
  %24 = add nuw nsw i8 %20, 1
  store i8 %24, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %25 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %23
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr %25, align 1, !tbaa !25
  br label %26

26:                                               ; preds = %19, %22
  tail call void @_tg_reserve(ptr nonnull poison, ptr nonnull poison) #14, !inline_history !27
  %27 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !28
  %28 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !29
  %29 = or i8 %28, %27
  store i8 %29, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !28
  store volatile i8 %29, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(223) getelementptr inbounds nuw (i8, ptr @main.a, i16 2032), i8 0, i64 223, i1 false)
  tail call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(33) getelementptr inbounds nuw (i8, ptr @main.a, i16 1999), ptr noundef nonnull align 1 dereferenceable(33) @HELLO6502, i16 33, i1 false), !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1992), align 1, !tbaa !30
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1993), align 1, !tbaa !32
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1994), align 1, !tbaa !33
  store i8 -1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1995), align 1, !tbaa !34
  store i8 32, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1996), align 1, !tbaa !35
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1997), align 1, !tbaa !36
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(15) getelementptr inbounds nuw (i8, ptr @main.a, i16 2255), i8 0, i64 15, i1 false)
  store ptr @TITLE_VT, ptr @main.title, align 1, !tbaa !37
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !41
  store ptr @.str, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 3), align 1, !tbaa !42
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 5), align 1, !tbaa !43
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 7), align 1, !tbaa !44
  store i8 14, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 11), align 1, !tbaa !45
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 9), align 1, !tbaa !46
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 12), align 1, !tbaa !47
  store i16 96, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 13), align 1, !tbaa !48
  store i16 112, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 15), align 1, !tbaa !49
  store i16 16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 17), align 1, !tbaa !50
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 28), align 1, !tbaa !51
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !52
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !53
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !54
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !55
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !56
  store i16 32767, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 34), align 1, !tbaa !57
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 36), align 1, !tbaa !58
  %30 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !28
  %31 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !22
  %32 = icmp eq i8 %31, 0
  br i1 %32, label %34, label %33

33:                                               ; preds = %26
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !23
  br label %34

34:                                               ; preds = %33, %26
  %35 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %36 = icmp ult i8 %35, 4
  br i1 %36, label %37, label %41

37:                                               ; preds = %34
  %38 = zext nneg i8 %35 to i16
  %39 = add nuw nsw i8 %35, 1
  store i8 %39, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %40 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %38
  store ptr @main.title, ptr %40, align 1, !tbaa !25
  br label %41

41:                                               ; preds = %37, %34
  tail call void @_title_reserve(ptr noundef nonnull @main.title, ptr nonnull poison) #14, !inline_history !27
  %42 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !28
  %43 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !29
  %44 = or i8 %43, %42
  store volatile i8 %44, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store i8 %30, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !59
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !28
  store volatile i8 2, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 24, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  br label %45

45:                                               ; preds = %73, %41
  %46 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %47 = icmp eq i8 %46, 0
  br i1 %47, label %59, label %48

48:                                               ; preds = %45, %48
  %49 = phi i8 [ %56, %48 ], [ 0, %45 ]
  %50 = zext i8 %49 to i16
  %51 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %50
  %52 = load ptr, ptr %51, align 1, !tbaa !25
  %53 = load ptr, ptr %52, align 1, !tbaa !60
  %54 = getelementptr inbounds nuw i8, ptr %53, i16 2
  %55 = load ptr, ptr %54, align 1, !tbaa !61
  tail call void %55(ptr noundef nonnull %52, ptr noundef nonnull @main.a) #14, !inline_history !63
  %56 = add nuw i8 %49, 1
  %57 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %58 = icmp ult i8 %56, %57
  br i1 %58, label %48, label %59, !llvm.loop !64

59:                                               ; preds = %48, %45
  %60 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %61

61:                                               ; preds = %61, %59
  %62 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %63 = icmp sgt i8 %62, -1
  br i1 %63, label %61, label %64, !llvm.loop !65

64:                                               ; preds = %61
  tail call fastcc void @upq_flush() #15
  %65 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %66 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %67 = icmp ult i8 %65, %66
  br i1 %67, label %70, label %68

68:                                               ; preds = %64
  %69 = icmp ugt i8 %65, %66
  br i1 %69, label %70, label %73

70:                                               ; preds = %68, %64
  %71 = phi i8 [ 1, %64 ], [ -1, %68 ]
  %72 = add i8 %71, %65
  store i8 %72, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %73

73:                                               ; preds = %70, %68
  %74 = phi i8 [ %65, %68 ], [ %72, %70 ]
  %75 = and i8 %74, 15
  store volatile i8 %75, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !22
  %76 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %77 = icmp eq i8 %76, 15
  br i1 %77, label %78, label %45, !llvm.loop !66

78:                                               ; preds = %73
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !55
  %79 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !56
  %80 = icmp eq i8 %79, -1
  br i1 %80, label %118, label %81

81:                                               ; preds = %78, %110
  %82 = phi i8 [ %113, %110 ], [ 0, %78 ]
  %83 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %84 = icmp eq i8 %83, 0
  br i1 %84, label %96, label %85

85:                                               ; preds = %81, %85
  %86 = phi i8 [ %93, %85 ], [ 0, %81 ]
  %87 = zext i8 %86 to i16
  %88 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %87
  %89 = load ptr, ptr %88, align 1, !tbaa !25
  %90 = load ptr, ptr %89, align 1, !tbaa !60
  %91 = getelementptr inbounds nuw i8, ptr %90, i16 2
  %92 = load ptr, ptr %91, align 1, !tbaa !61
  tail call void %92(ptr noundef nonnull %89, ptr noundef nonnull @main.a) #14, !inline_history !67
  %93 = add nuw i8 %86, 1
  %94 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %95 = icmp ult i8 %93, %94
  br i1 %95, label %85, label %96, !llvm.loop !64

96:                                               ; preds = %85, %81
  %97 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %98

98:                                               ; preds = %98, %96
  %99 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %100 = icmp sgt i8 %99, -1
  br i1 %100, label %98, label %101, !llvm.loop !65

101:                                              ; preds = %98
  tail call fastcc void @upq_flush() #15
  %102 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %103 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %104 = icmp ult i8 %102, %103
  br i1 %104, label %107, label %105

105:                                              ; preds = %101
  %106 = icmp ugt i8 %102, %103
  br i1 %106, label %107, label %110

107:                                              ; preds = %105, %101
  %108 = phi i8 [ 1, %101 ], [ -1, %105 ]
  %109 = add i8 %108, %102
  store i8 %109, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %110

110:                                              ; preds = %107, %105
  %111 = phi i8 [ %102, %105 ], [ %109, %107 ]
  %112 = and i8 %111, 15
  store volatile i8 %112, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !22
  %113 = add nuw i8 %82, 1
  %114 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !56
  %115 = icmp ne i8 %114, -1
  %116 = icmp ult i8 %82, -57
  %117 = select i1 %115, i1 %116, i1 false
  br i1 %117, label %81, label %118, !llvm.loop !68

118:                                              ; preds = %110, %78
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !55
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #16
  %119 = getelementptr inbounds nuw i8, ptr %1, i16 7
  %120 = getelementptr inbounds nuw i8, ptr %1, i16 40
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(223) %120, i8 0, i64 223, i1 false)
  call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(33) %119, ptr noundef nonnull align 1 dereferenceable(33) @HELLO6502, i16 33, i1 false), !tbaa !6
  store i8 0, ptr %1, align 1, !tbaa !30
  %121 = getelementptr inbounds nuw i8, ptr %1, i16 1
  store i8 0, ptr %121, align 1, !tbaa !32
  %122 = getelementptr inbounds nuw i8, ptr %1, i16 2
  store i8 0, ptr %122, align 1, !tbaa !33
  %123 = getelementptr inbounds nuw i8, ptr %1, i16 3
  store i8 -1, ptr %123, align 1, !tbaa !34
  %124 = getelementptr inbounds nuw i8, ptr %1, i16 4
  store i8 32, ptr %124, align 1, !tbaa !35
  %125 = getelementptr inbounds nuw i8, ptr %1, i16 5
  store i16 0, ptr %125, align 1, !tbaa !36
  br label %126

126:                                              ; preds = %126, %118
  %127 = phi i16 [ 0, %118 ], [ %145, %126 ]
  %128 = phi i16 [ 0, %118 ], [ %144, %126 ]
  %129 = call fastcc zeroext i8 @cpu6502_step(ptr noundef nonnull %1) #15
  %130 = load i8, ptr %1, align 1, !tbaa !30
  %131 = zext i8 %130 to i16
  %132 = load i8, ptr %121, align 1, !tbaa !32
  %133 = zext i8 %132 to i16
  %134 = shl nuw i16 %133, 8
  %135 = or disjoint i16 %134, %131
  %136 = call i16 @llvm.fshl.i16(i16 %128, i16 %128, i16 1)
  %137 = xor i16 %135, %136
  %138 = load i16, ptr %125, align 1, !tbaa !36
  %139 = call i16 @llvm.fshl.i16(i16 %137, i16 %137, i16 1)
  %140 = xor i16 %139, %138
  %141 = load i8, ptr %124, align 1, !tbaa !35
  %142 = zext i8 %141 to i16
  %143 = call i16 @llvm.fshl.i16(i16 %140, i16 %140, i16 1)
  %144 = xor i16 %143, %142
  %145 = add nuw nsw i16 %127, 1
  %146 = icmp eq i16 %145, 256
  br i1 %146, label %147, label %126, !llvm.loop !69

147:                                              ; preds = %126
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #16
  store volatile i16 %144, ptr @corpus_result, align 1, !tbaa !2
  br label %148

148:                                              ; preds = %178, %147
  %149 = phi i16 [ 90, %147 ], [ %150, %178 ]
  %150 = add nsw i16 %149, -1
  %151 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %152 = icmp eq i8 %151, 0
  br i1 %152, label %164, label %153

153:                                              ; preds = %148, %153
  %154 = phi i8 [ %161, %153 ], [ 0, %148 ]
  %155 = zext i8 %154 to i16
  %156 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %155
  %157 = load ptr, ptr %156, align 1, !tbaa !25
  %158 = load ptr, ptr %157, align 1, !tbaa !60
  %159 = getelementptr inbounds nuw i8, ptr %158, i16 2
  %160 = load ptr, ptr %159, align 1, !tbaa !61
  call void %160(ptr noundef nonnull %157, ptr noundef nonnull @main.a) #14, !inline_history !70
  %161 = add nuw i8 %154, 1
  %162 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %163 = icmp ult i8 %161, %162
  br i1 %163, label %153, label %164, !llvm.loop !64

164:                                              ; preds = %153, %148
  %165 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %166

166:                                              ; preds = %166, %164
  %167 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %168 = icmp sgt i8 %167, -1
  br i1 %168, label %166, label %169, !llvm.loop !65

169:                                              ; preds = %166
  call fastcc void @upq_flush() #15
  %170 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %171 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %172 = icmp ult i8 %170, %171
  br i1 %172, label %175, label %173

173:                                              ; preds = %169
  %174 = icmp ugt i8 %170, %171
  br i1 %174, label %175, label %178

175:                                              ; preds = %173, %169
  %176 = phi i8 [ 1, %169 ], [ -1, %173 ]
  %177 = add i8 %176, %170
  store i8 %177, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %178

178:                                              ; preds = %175, %173
  %179 = phi i8 [ %170, %173 ], [ %177, %175 ]
  %180 = and i8 %179, 15
  store volatile i8 %180, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !22
  %181 = icmp eq i16 %150, 0
  br i1 %181, label %182, label %148, !llvm.loop !71

182:                                              ; preds = %178
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !53
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !54
  br label %186

183:                                              ; preds = %215
  %184 = add nuw nsw i8 %187, 1
  %185 = icmp eq i8 %184, 90
  br i1 %185, label %220, label %186, !llvm.loop !72

186:                                              ; preds = %183, %182
  %187 = phi i8 [ 0, %182 ], [ %184, %183 ]
  %188 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %189 = icmp eq i8 %188, 0
  br i1 %189, label %201, label %190

190:                                              ; preds = %186, %190
  %191 = phi i8 [ %198, %190 ], [ 0, %186 ]
  %192 = zext i8 %191 to i16
  %193 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %192
  %194 = load ptr, ptr %193, align 1, !tbaa !25
  %195 = load ptr, ptr %194, align 1, !tbaa !60
  %196 = getelementptr inbounds nuw i8, ptr %195, i16 2
  %197 = load ptr, ptr %196, align 1, !tbaa !61
  call void %197(ptr noundef nonnull %194, ptr noundef nonnull @main.a) #14, !inline_history !73
  %198 = add nuw i8 %191, 1
  %199 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %200 = icmp ult i8 %198, %199
  br i1 %200, label %190, label %201, !llvm.loop !64

201:                                              ; preds = %190, %186
  %202 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %203

203:                                              ; preds = %203, %201
  %204 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %205 = icmp sgt i8 %204, -1
  br i1 %205, label %203, label %206, !llvm.loop !65

206:                                              ; preds = %203
  call fastcc void @upq_flush() #15
  %207 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %208 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %209 = icmp ult i8 %207, %208
  br i1 %209, label %212, label %210

210:                                              ; preds = %206
  %211 = icmp ugt i8 %207, %208
  br i1 %211, label %212, label %215

212:                                              ; preds = %210, %206
  %213 = phi i8 [ 1, %206 ], [ -1, %210 ]
  %214 = add i8 %213, %207
  store i8 %214, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %215

215:                                              ; preds = %212, %210
  %216 = phi i8 [ %207, %210 ], [ %214, %212 ]
  %217 = and i8 %216, 15
  store volatile i8 %217, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !22
  %218 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 19), align 1, !tbaa !74
  %219 = icmp sgt i16 %218, 3583
  br i1 %219, label %220, label %183

220:                                              ; preds = %215, %183
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !53
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %221 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %222 = icmp eq i8 %221, 0
  br i1 %222, label %256, label %223

223:                                              ; preds = %220, %251
  %224 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %225 = icmp eq i8 %224, 0
  br i1 %225, label %237, label %226

226:                                              ; preds = %223, %226
  %227 = phi i8 [ %234, %226 ], [ 0, %223 ]
  %228 = zext i8 %227 to i16
  %229 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %228
  %230 = load ptr, ptr %229, align 1, !tbaa !25
  %231 = load ptr, ptr %230, align 1, !tbaa !60
  %232 = getelementptr inbounds nuw i8, ptr %231, i16 2
  %233 = load ptr, ptr %232, align 1, !tbaa !61
  call void %233(ptr noundef nonnull %230, ptr noundef nonnull @main.a) #14, !inline_history !75
  %234 = add nuw i8 %227, 1
  %235 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %236 = icmp ult i8 %234, %235
  br i1 %236, label %226, label %237, !llvm.loop !64

237:                                              ; preds = %226, %223
  %238 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %239

239:                                              ; preds = %239, %237
  %240 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %241 = icmp sgt i8 %240, -1
  br i1 %241, label %239, label %242, !llvm.loop !65

242:                                              ; preds = %239
  call fastcc void @upq_flush() #15
  %243 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %244 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %245 = icmp ult i8 %243, %244
  br i1 %245, label %248, label %246

246:                                              ; preds = %242
  %247 = icmp ugt i8 %243, %244
  br i1 %247, label %248, label %251

248:                                              ; preds = %246, %242
  %249 = phi i8 [ 1, %242 ], [ -1, %246 ]
  %250 = add i8 %249, %243
  store i8 %250, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %251

251:                                              ; preds = %248, %246
  %252 = phi i8 [ %243, %246 ], [ %250, %248 ]
  %253 = and i8 %252, 15
  store volatile i8 %253, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !22
  %254 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %255 = icmp eq i8 %254, 0
  br i1 %255, label %256, label %223, !llvm.loop !66

256:                                              ; preds = %251, %220
  %257 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !59
  %258 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !28
  %259 = or i8 %258, %257
  %260 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !29
  %261 = xor i8 %260, -1
  %262 = and i8 %259, %261
  store i8 %262, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !28
  store volatile i8 %262, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !52
  %263 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !76
  %264 = icmp ugt i8 %263, 15
  br i1 %264, label %276, label %265

265:                                              ; preds = %256
  %266 = zext nneg i8 %263 to i16
  %267 = add nuw nsw i8 %263, 1
  store i8 %267, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !76
  %268 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %266
  %269 = getelementptr inbounds nuw i8, ptr %268, i16 10
  store i8 1, ptr %269, align 1, !tbaa !77
  store i16 0, ptr %268, align 1, !tbaa !79
  %270 = getelementptr inbounds nuw i8, ptr %268, i16 9
  store i8 0, ptr %270, align 1, !tbaa !80
  %271 = getelementptr inbounds nuw i8, ptr %268, i16 7
  store i8 34, ptr %271, align 1, !tbaa !81
  %272 = getelementptr inbounds nuw i8, ptr %268, i16 8
  store i8 0, ptr %272, align 1, !tbaa !82
  %273 = getelementptr inbounds nuw i8, ptr %268, i16 2
  store i16 ptrtoint (ptr @title_end._title_bg_black to i16), ptr %273, align 1, !tbaa !83
  %274 = getelementptr inbounds nuw i8, ptr %268, i16 6
  store i8 0, ptr %274, align 1, !tbaa !84
  %275 = getelementptr inbounds nuw i8, ptr %268, i16 4
  store i16 2, ptr %275, align 1, !tbaa !85
  br label %276

276:                                              ; preds = %256, %265
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  call fastcc void @draw_all() #15
  br label %277

277:                                              ; preds = %323, %276
  %278 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 2256), align 1, !tbaa !86
  %279 = icmp eq i8 %278, 0
  br i1 %279, label %280, label %292

280:                                              ; preds = %277
  %281 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1997), align 1, !tbaa !88
  %282 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 2269), align 1, !tbaa !89
  %283 = urem i8 %282, 6
  %284 = zext nneg i8 %283 to i16
  %285 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 2257), i16 %284
  store i16 %281, ptr %285, align 1, !tbaa !2
  %286 = zext i8 %282 to i16
  %287 = add nuw nsw i16 %286, 1
  %288 = urem i16 %287, 6
  %289 = trunc nuw nsw i16 %288 to i8
  store i8 %289, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 2269), align 1, !tbaa !89
  %290 = call fastcc zeroext i8 @cpu6502_step(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 1992)) #15
  store i8 %290, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 2255), align 1, !tbaa !90
  call fastcc void @draw_all() #15
  %291 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 2256), align 1, !tbaa !86
  br label %292

292:                                              ; preds = %280, %277
  %293 = phi i8 [ %291, %280 ], [ %278, %277 ]
  %294 = add i8 %293, 1
  %295 = and i8 %294, 15
  store i8 %295, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 2256), align 1, !tbaa !86
  %296 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %297 = icmp eq i8 %296, 0
  br i1 %297, label %309, label %298

298:                                              ; preds = %292, %298
  %299 = phi i8 [ %306, %298 ], [ 0, %292 ]
  %300 = zext i8 %299 to i16
  %301 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %300
  %302 = load ptr, ptr %301, align 1, !tbaa !25
  %303 = load ptr, ptr %302, align 1, !tbaa !60
  %304 = getelementptr inbounds nuw i8, ptr %303, i16 2
  %305 = load ptr, ptr %304, align 1, !tbaa !61
  call void %305(ptr noundef nonnull %302, ptr noundef nonnull @main.a) #14, !inline_history !91
  %306 = add nuw i8 %299, 1
  %307 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !24
  %308 = icmp ult i8 %306, %307
  br i1 %308, label %298, label %309, !llvm.loop !64

309:                                              ; preds = %298, %292
  %310 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %311

311:                                              ; preds = %311, %309
  %312 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %313 = icmp sgt i8 %312, -1
  br i1 %313, label %311, label %314, !llvm.loop !65

314:                                              ; preds = %311
  call fastcc void @upq_flush() #15
  %315 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %316 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %317 = icmp ult i8 %315, %316
  br i1 %317, label %320, label %318

318:                                              ; preds = %314
  %319 = icmp ugt i8 %315, %316
  br i1 %319, label %320, label %323

320:                                              ; preds = %318, %314
  %321 = phi i8 [ 1, %314 ], [ -1, %318 ]
  %322 = add i8 %321, %315
  store i8 %322, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %323

323:                                              ; preds = %318, %320
  %324 = phi i8 [ %315, %318 ], [ %322, %320 ]
  %325 = and i8 %324, 15
  store volatile i8 %325, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !22
  br label %277
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nofree norecurse nosync nounwind optsize memory(readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @draw_all() unnamed_addr #2 {
  %1 = alloca [16 x i8], align 1
  %2 = alloca [5 x i8], align 1
  %3 = alloca [12 x i16], align 1
  %4 = alloca [4 x i8], align 1
  %5 = alloca [8 x i8], align 1
  %6 = alloca [9 x i8], align 1
  %7 = alloca [24 x i8], align 1
  %8 = alloca [8 x i8], align 1
  br label %9

9:                                                ; preds = %9, %0
  %10 = phi i16 [ 0, %0 ], [ %12, %9 ]
  %11 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %10
  store i16 256, ptr %11, align 1, !tbaa !2
  %12 = add nuw nsw i16 %10, 1
  %13 = icmp eq i16 %12, 896
  br i1 %13, label %14, label %9, !llvm.loop !92

14:                                               ; preds = %9
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #16
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #16
  br label %15

15:                                               ; preds = %23, %14
  %16 = phi i8 [ %34, %23 ], [ 0, %14 ]
  %17 = phi i8 [ %32, %23 ], [ 54, %14 ]
  %18 = phi i8 [ %31, %23 ], [ 0, %14 ]
  %19 = icmp ult i8 %17, 32
  br i1 %19, label %22, label %20

20:                                               ; preds = %15
  %21 = icmp ugt i8 %17, 95
  br i1 %21, label %22, label %23

22:                                               ; preds = %20, %15
  br label %23

23:                                               ; preds = %22, %20
  %24 = phi i8 [ 32, %22 ], [ %17, %20 ]
  %25 = zext nneg i8 %24 to i16
  %26 = add nuw nsw i16 %25, 224
  %27 = zext nneg i8 %16 to i16
  %28 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %27
  store i16 %26, ptr %28, align 1, !tbaa !2
  %29 = zext nneg i8 %18 to i16
  %30 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @.str.2, i16 1), i16 %29
  %31 = add nuw nsw i8 %18, 1
  %32 = load i8, ptr %30, align 1, !tbaa !6
  %33 = icmp eq i8 %31, 18
  %34 = add nuw nsw i8 %16, 2
  br i1 %33, label %35, label %15, !llvm.loop !93

35:                                               ; preds = %23
  %36 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1997), align 1, !tbaa !88
  call fastcc void @hx4(ptr noundef %2, i16 noundef %36) #15
  %37 = getelementptr inbounds nuw i8, ptr %1, i16 1
  store i8 67, ptr %37, align 1, !tbaa !6
  %38 = getelementptr inbounds nuw i8, ptr %1, i16 2
  store i8 32, ptr %38, align 1, !tbaa !6
  %39 = getelementptr inbounds nuw i8, ptr %1, i16 3
  store i8 36, ptr %39, align 1, !tbaa !6
  %40 = load i8, ptr %2, align 1, !tbaa !6
  %41 = getelementptr inbounds nuw i8, ptr %1, i16 4
  store i8 %40, ptr %41, align 1, !tbaa !6
  %42 = getelementptr inbounds nuw i8, ptr %2, i16 1
  %43 = load i8, ptr %42, align 1, !tbaa !6
  %44 = getelementptr inbounds nuw i8, ptr %1, i16 5
  store i8 %43, ptr %44, align 1, !tbaa !6
  %45 = getelementptr inbounds nuw i8, ptr %2, i16 2
  %46 = load i8, ptr %45, align 1, !tbaa !6
  %47 = getelementptr inbounds nuw i8, ptr %1, i16 6
  store i8 %46, ptr %47, align 1, !tbaa !6
  %48 = getelementptr inbounds nuw i8, ptr %2, i16 3
  %49 = load i8, ptr %48, align 1, !tbaa !6
  %50 = getelementptr inbounds nuw i8, ptr %1, i16 7
  store i8 %49, ptr %50, align 1, !tbaa !6
  %51 = getelementptr inbounds nuw i8, ptr %1, i16 8
  store i8 0, ptr %51, align 1, !tbaa !6
  br label %52

52:                                               ; preds = %68, %35
  %53 = phi i8 [ 80, %35 ], [ %71, %68 ]
  %54 = phi i8 [ 23, %35 ], [ %70, %68 ]
  %55 = phi ptr [ %1, %35 ], [ %69, %68 ]
  %56 = icmp ult i8 %53, 32
  br i1 %56, label %59, label %57

57:                                               ; preds = %52
  %58 = icmp ugt i8 %53, 95
  br i1 %58, label %59, label %60

59:                                               ; preds = %57, %52
  br label %60

60:                                               ; preds = %59, %57
  %61 = phi i8 [ 32, %59 ], [ %53, %57 ]
  %62 = icmp ugt i8 %54, 31
  br i1 %62, label %68, label %63

63:                                               ; preds = %60
  %64 = zext nneg i8 %61 to i16
  %65 = zext nneg i8 %54 to i16
  %66 = add nuw nsw i16 %64, 224
  %67 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %65
  store i16 %66, ptr %67, align 1, !tbaa !2
  br label %68

68:                                               ; preds = %63, %60
  %69 = getelementptr inbounds nuw i8, ptr %55, i16 1
  %70 = add i8 %54, 1
  %71 = load i8, ptr %69, align 1, !tbaa !6
  %72 = icmp eq i8 %71, 0
  br i1 %72, label %73, label %52, !llvm.loop !93

73:                                               ; preds = %68
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #16
  %74 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 2269), align 1, !tbaa !89
  %75 = zext i8 %74 to i16
  br label %76

76:                                               ; preds = %73, %76
  %77 = phi i8 [ 0, %73 ], [ %88, %76 ]
  %78 = phi i8 [ 0, %73 ], [ %86, %76 ]
  %79 = zext nneg i8 %78 to i16
  %80 = add nuw nsw i16 %75, %79
  %81 = urem i16 %80, 6
  %82 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 2257), i16 %81
  %83 = load i16, ptr %82, align 1, !tbaa !2
  %84 = zext nneg i8 %77 to i16
  %85 = getelementptr i8, ptr %3, i16 %84
  store i16 %83, ptr %85, align 1, !tbaa !2
  %86 = add nuw nsw i8 %78, 1
  %87 = icmp eq i8 %86, 6
  %88 = add nuw nsw i8 %77, 2
  br i1 %87, label %89, label %76, !llvm.loop !94

89:                                               ; preds = %76
  %90 = getelementptr inbounds nuw i8, ptr %3, i16 12
  br label %95

91:                                               ; preds = %126
  %92 = getelementptr inbounds nuw i8, ptr %4, i16 1
  %93 = getelementptr inbounds nuw i8, ptr %4, i16 2
  %94 = getelementptr inbounds nuw i8, ptr %4, i16 3
  br label %133

95:                                               ; preds = %89, %126
  %96 = phi i8 [ 0, %89 ], [ %130, %126 ]
  %97 = phi i8 [ 6, %89 ], [ %128, %126 ]
  %98 = phi i16 [ %36, %89 ], [ %127, %126 ]
  %99 = zext nneg i8 %96 to i16
  %100 = getelementptr i8, ptr %90, i16 %99
  store i16 %98, ptr %100, align 1, !tbaa !2
  %101 = and i16 %98, 255
  %102 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1999), i16 %101
  %103 = load i8, ptr %102, align 1, !tbaa !6
  %104 = icmp eq i8 %103, 76
  br i1 %104, label %105, label %119

105:                                              ; preds = %95
  %106 = trunc i16 %98 to i8
  %107 = add i8 %106, 2
  %108 = zext i8 %107 to i16
  %109 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1999), i16 %108
  %110 = load i8, ptr %109, align 1, !tbaa !6
  %111 = zext i8 %110 to i16
  %112 = shl nuw i16 %111, 8
  %113 = add i8 %106, 1
  %114 = zext i8 %113 to i16
  %115 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1999), i16 %114
  %116 = load i8, ptr %115, align 1, !tbaa !6
  %117 = zext i8 %116 to i16
  %118 = or disjoint i16 %112, %117
  br label %126

119:                                              ; preds = %95
  %120 = zext i8 %103 to i16
  %121 = getelementptr inbounds nuw [7 x i8], ptr @CPU6502_OPS, i16 %120
  %122 = getelementptr inbounds nuw i8, ptr %121, i16 5
  %123 = load i8, ptr %122, align 1, !tbaa !95
  %124 = zext i8 %123 to i16
  %125 = add i16 %98, %124
  br label %126

126:                                              ; preds = %119, %105
  %127 = phi i16 [ %118, %105 ], [ %125, %119 ]
  %128 = add nuw nsw i8 %97, 1
  %129 = icmp eq i8 %128, 12
  %130 = add nuw nsw i8 %96, 2
  br i1 %129, label %91, label %95, !llvm.loop !97

131:                                              ; preds = %182
  %132 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 2255), align 1, !tbaa !90
  br label %186

133:                                              ; preds = %91, %182
  %134 = phi i8 [ 0, %91 ], [ %185, %182 ]
  %135 = phi i8 [ 0, %91 ], [ %183, %182 ]
  %136 = zext nneg i8 %134 to i16
  %137 = getelementptr i8, ptr %3, i16 %136
  %138 = load i16, ptr %137, align 1, !tbaa !2
  %139 = trunc i16 %138 to i8
  %140 = and i16 %138, 255
  %141 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1999), i16 %140
  %142 = load i8, ptr %141, align 1, !tbaa !6
  %143 = shl nuw nsw i8 %135, 1
  %144 = add nuw nsw i8 %143, 2
  %145 = icmp eq i8 %135, 5
  %146 = zext i1 %145 to i8
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #16
  %147 = zext i8 %142 to i16
  %148 = getelementptr inbounds nuw [7 x i8], ptr @CPU6502_OPS, i16 %147
  %149 = load i8, ptr %148, align 1, !tbaa !6
  store i8 %149, ptr %4, align 1, !tbaa !6
  %150 = getelementptr inbounds nuw i8, ptr %148, i16 1
  %151 = load i8, ptr %150, align 1, !tbaa !6
  store i8 %151, ptr %92, align 1, !tbaa !6
  %152 = getelementptr inbounds nuw i8, ptr %148, i16 2
  %153 = load i8, ptr %152, align 1, !tbaa !6
  store i8 %153, ptr %93, align 1, !tbaa !6
  store i8 0, ptr %94, align 1, !tbaa !6
  call fastcc void @hx4(ptr noundef %2, i16 noundef %138) #15
  call fastcc void @tg_str16(i8 noundef zeroext 0, i8 noundef zeroext %144, ptr noundef %2, i8 noundef zeroext %146) #15
  call fastcc void @tg_str16(i8 noundef zeroext 9, i8 noundef zeroext %144, ptr noundef %4, i8 noundef zeroext %146) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #16
  call fastcc void @fmt_oper(ptr noundef %5, i8 noundef zeroext %142, i8 noundef zeroext %139) #15
  %154 = load i8, ptr %5, align 1, !tbaa !6
  %155 = icmp eq i8 %154, 0
  br i1 %155, label %182, label %156

156:                                              ; preds = %133
  %157 = zext nneg i8 %144 to i16
  %158 = select i1 %145, i16 1248, i16 224
  %159 = shl nuw nsw i16 %157, 6
  %160 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %159
  br label %161

161:                                              ; preds = %177, %156
  %162 = phi i8 [ %154, %156 ], [ %180, %177 ]
  %163 = phi i8 [ 16, %156 ], [ %179, %177 ]
  %164 = phi ptr [ %5, %156 ], [ %178, %177 ]
  %165 = icmp ult i8 %162, 32
  br i1 %165, label %168, label %166

166:                                              ; preds = %161
  %167 = icmp ugt i8 %162, 95
  br i1 %167, label %168, label %169

168:                                              ; preds = %166, %161
  br label %169

169:                                              ; preds = %168, %166
  %170 = phi i8 [ 32, %168 ], [ %162, %166 ]
  %171 = icmp ugt i8 %163, 31
  br i1 %171, label %177, label %172

172:                                              ; preds = %169
  %173 = zext nneg i8 %170 to i16
  %174 = zext nneg i8 %163 to i16
  %175 = add nuw nsw i16 %158, %173
  %176 = getelementptr inbounds nuw [2 x i8], ptr %160, i16 %174
  store i16 %175, ptr %176, align 1, !tbaa !2
  br label %177

177:                                              ; preds = %172, %169
  %178 = getelementptr inbounds nuw i8, ptr %164, i16 1
  %179 = add i8 %163, 1
  %180 = load i8, ptr %178, align 1, !tbaa !6
  %181 = icmp eq i8 %180, 0
  br i1 %181, label %182, label %161, !llvm.loop !93

182:                                              ; preds = %177, %133
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #16
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #16
  %183 = add nuw nsw i8 %135, 1
  %184 = icmp eq i8 %183, 12
  %185 = add nuw nsw i8 %134, 2
  br i1 %184, label %131, label %133, !llvm.loop !98

186:                                              ; preds = %131, %251
  %187 = phi i8 [ 0, %131 ], [ %257, %251 ]
  %188 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 439), %131 ], [ %255, %251 ]
  %189 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 379), %131 ], [ %254, %251 ]
  %190 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 377), %131 ], [ %253, %251 ]
  %191 = phi i8 [ 0, %131 ], [ %252, %251 ]
  %192 = zext nneg i8 %191 to i16
  %193 = mul nuw nsw i8 %191, 3
  %194 = add nuw nsw i8 %193, 2
  %195 = getelementptr i8, ptr @GATE_TYPE, i16 %192
  %196 = load i8, ptr %195, align 1, !tbaa !6
  %197 = icmp eq i8 %196, %132
  %198 = select i1 %197, i8 3, i8 2
  %199 = mul nuw nsw i16 %192, 6
  %200 = add nuw nsw i16 %199, 320
  %201 = zext nneg i8 %198 to i16
  %202 = shl nuw nsw i16 %201, 10
  %203 = zext nneg i8 %194 to i16
  %204 = shl nuw nsw i16 %203, 6
  %205 = getelementptr nuw i8, ptr @main.a, i16 %204
  %206 = getelementptr nuw i8, ptr %205, i16 247
  br label %207

207:                                              ; preds = %207, %186
  %208 = phi i8 [ 0, %186 ], [ %223, %207 ]
  %209 = phi ptr [ %206, %186 ], [ %222, %207 ]
  %210 = phi i1 [ true, %186 ], [ false, %207 ]
  %211 = phi i8 [ 0, %186 ], [ 3, %207 ]
  %212 = zext nneg i8 %211 to i16
  %213 = add nuw nsw i16 %200, %212
  %214 = or disjoint i16 %213, %202
  store i16 %214, ptr %209, align 1, !tbaa !2
  %215 = add nuw nsw i16 %213, 1
  %216 = or i16 %215, %202
  %217 = zext i8 %208 to i16
  %218 = getelementptr i8, ptr %190, i16 %217
  store i16 %216, ptr %218, align 1, !tbaa !2
  %219 = add nuw nsw i16 %213, 2
  %220 = or i16 %219, %202
  %221 = getelementptr i8, ptr %189, i16 %217
  store i16 %220, ptr %221, align 1, !tbaa !2
  %222 = getelementptr i8, ptr %188, i16 %217
  %223 = add nuw i8 %208, 64
  br i1 %210, label %207, label %224, !llvm.loop !99

224:                                              ; preds = %207
  %225 = zext nneg i8 %187 to i16
  %226 = getelementptr i8, ptr @GATE_LABEL, i16 %225
  %227 = load i8, ptr %226, align 1, !tbaa !6
  %228 = or disjoint i16 %202, 224
  %229 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %204
  br label %230

230:                                              ; preds = %246, %224
  %231 = phi i8 [ %227, %224 ], [ %249, %246 ]
  %232 = phi i8 [ 28, %224 ], [ %248, %246 ]
  %233 = phi ptr [ %226, %224 ], [ %247, %246 ]
  %234 = icmp ult i8 %231, 32
  br i1 %234, label %237, label %235

235:                                              ; preds = %230
  %236 = icmp ugt i8 %231, 95
  br i1 %236, label %237, label %238

237:                                              ; preds = %235, %230
  br label %238

238:                                              ; preds = %237, %235
  %239 = phi i8 [ 32, %237 ], [ %231, %235 ]
  %240 = icmp ugt i8 %232, 31
  br i1 %240, label %246, label %241

241:                                              ; preds = %238
  %242 = zext nneg i8 %239 to i16
  %243 = zext nneg i8 %232 to i16
  %244 = add nuw nsw i16 %228, %242
  %245 = getelementptr inbounds nuw [2 x i8], ptr %229, i16 %243
  store i16 %244, ptr %245, align 1, !tbaa !2
  br label %246

246:                                              ; preds = %241, %238
  %247 = getelementptr inbounds nuw i8, ptr %233, i16 1
  %248 = add i8 %232, 1
  %249 = load i8, ptr %247, align 1, !tbaa !6
  %250 = icmp eq i8 %249, 0
  br i1 %250, label %251, label %230, !llvm.loop !93

251:                                              ; preds = %246
  %252 = add nuw nsw i8 %191, 1
  %253 = getelementptr i8, ptr %190, i16 192
  %254 = getelementptr i8, ptr %189, i16 192
  %255 = getelementptr i8, ptr %188, i16 192
  %256 = icmp eq i8 %252, 8
  %257 = add nuw nsw i8 %187, 4
  br i1 %256, label %258, label %186, !llvm.loop !100

258:                                              ; preds = %251
  store i8 58, ptr %37, align 1, !tbaa !6
  %259 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1992), align 1, !tbaa !101
  %260 = lshr i8 %259, 4
  %261 = icmp ult i8 %259, -96
  br i1 %261, label %262, label %264

262:                                              ; preds = %258
  %263 = or disjoint i8 %260, 48
  br label %266

264:                                              ; preds = %258
  %265 = add nuw nsw i8 %260, 55
  br label %266

266:                                              ; preds = %264, %262
  %267 = phi i8 [ %263, %262 ], [ %265, %264 ]
  %268 = and i8 %259, 15
  %269 = icmp samesign ult i8 %268, 10
  br i1 %269, label %270, label %272

270:                                              ; preds = %266
  %271 = or disjoint i8 %268, 48
  br label %274

272:                                              ; preds = %266
  %273 = add nuw nsw i8 %268, 55
  br label %274

274:                                              ; preds = %270, %272
  %275 = phi i8 [ %271, %270 ], [ %273, %272 ]
  store i8 %267, ptr %38, align 1, !tbaa !6
  store i8 %275, ptr %39, align 1, !tbaa !6
  store i8 32, ptr %41, align 1, !tbaa !6
  store i8 88, ptr %44, align 1, !tbaa !6
  store i8 58, ptr %47, align 1, !tbaa !6
  %276 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1993), align 1, !tbaa !102
  %277 = lshr i8 %276, 4
  %278 = icmp ult i8 %276, -96
  br i1 %278, label %279, label %281

279:                                              ; preds = %274
  %280 = or disjoint i8 %277, 48
  br label %283

281:                                              ; preds = %274
  %282 = add nuw nsw i8 %277, 55
  br label %283

283:                                              ; preds = %281, %279
  %284 = phi i8 [ %280, %279 ], [ %282, %281 ]
  %285 = and i8 %276, 15
  %286 = icmp samesign ult i8 %285, 10
  br i1 %286, label %287, label %289

287:                                              ; preds = %283
  %288 = or disjoint i8 %285, 48
  br label %291

289:                                              ; preds = %283
  %290 = add nuw nsw i8 %285, 55
  br label %291

291:                                              ; preds = %287, %289
  %292 = phi i8 [ %288, %287 ], [ %290, %289 ]
  store i8 %284, ptr %50, align 1, !tbaa !6
  store i8 %292, ptr %51, align 1, !tbaa !6
  %293 = getelementptr inbounds nuw i8, ptr %1, i16 9
  store i8 32, ptr %293, align 1, !tbaa !6
  %294 = getelementptr inbounds nuw i8, ptr %1, i16 10
  store i8 89, ptr %294, align 1, !tbaa !6
  %295 = getelementptr inbounds nuw i8, ptr %1, i16 11
  store i8 58, ptr %295, align 1, !tbaa !6
  %296 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1994), align 1, !tbaa !103
  %297 = lshr i8 %296, 4
  %298 = icmp ult i8 %296, -96
  br i1 %298, label %299, label %301

299:                                              ; preds = %291
  %300 = or disjoint i8 %297, 48
  br label %303

301:                                              ; preds = %291
  %302 = add nuw nsw i8 %297, 55
  br label %303

303:                                              ; preds = %301, %299
  %304 = phi i8 [ %300, %299 ], [ %302, %301 ]
  %305 = and i8 %296, 15
  %306 = icmp samesign ult i8 %305, 10
  br i1 %306, label %307, label %309

307:                                              ; preds = %303
  %308 = or disjoint i8 %305, 48
  br label %311

309:                                              ; preds = %303
  %310 = add nuw nsw i8 %305, 55
  br label %311

311:                                              ; preds = %309, %307
  %312 = phi i8 [ %308, %307 ], [ %310, %309 ]
  %313 = getelementptr inbounds nuw i8, ptr %1, i16 12
  store i8 %304, ptr %313, align 1, !tbaa !6
  %314 = getelementptr inbounds nuw i8, ptr %1, i16 13
  store i8 %312, ptr %314, align 1, !tbaa !6
  %315 = getelementptr inbounds nuw i8, ptr %1, i16 14
  store i8 0, ptr %315, align 1, !tbaa !6
  br label %316

316:                                              ; preds = %332, %311
  %317 = phi i8 [ 65, %311 ], [ %335, %332 ]
  %318 = phi i8 [ 0, %311 ], [ %334, %332 ]
  %319 = phi ptr [ %1, %311 ], [ %333, %332 ]
  %320 = icmp ult i8 %317, 32
  br i1 %320, label %323, label %321

321:                                              ; preds = %316
  %322 = icmp ugt i8 %317, 95
  br i1 %322, label %323, label %324

323:                                              ; preds = %321, %316
  br label %324

324:                                              ; preds = %323, %321
  %325 = phi i8 [ 32, %323 ], [ %317, %321 ]
  %326 = icmp ugt i8 %318, 31
  br i1 %326, label %332, label %327

327:                                              ; preds = %324
  %328 = zext nneg i8 %325 to i16
  %329 = zext nneg i8 %318 to i16
  %330 = add nuw nsw i16 %328, 224
  %331 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1863), i16 %329
  store i16 %330, ptr %331, align 1, !tbaa !2
  br label %332

332:                                              ; preds = %327, %324
  %333 = getelementptr inbounds nuw i8, ptr %319, i16 1
  %334 = add i8 %318, 1
  %335 = load i8, ptr %333, align 1, !tbaa !6
  %336 = icmp eq i8 %335, 0
  br i1 %336, label %337, label %316, !llvm.loop !93

337:                                              ; preds = %332
  %338 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1996), align 1, !tbaa !104
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #16
  %339 = zext i8 %338 to i16
  %340 = icmp sgt i8 %338, -1
  %341 = select i1 %340, i8 46, i8 78
  %342 = and i16 %339, 64
  %343 = icmp eq i16 %342, 0
  %344 = select i1 %343, i8 46, i8 86
  %345 = getelementptr inbounds nuw i8, ptr %6, i16 1
  store i8 %344, ptr %345, align 1, !tbaa !6
  %346 = getelementptr inbounds nuw i8, ptr %6, i16 2
  store i8 45, ptr %346, align 1, !tbaa !6
  %347 = and i16 %339, 8
  %348 = icmp eq i16 %347, 0
  %349 = select i1 %348, i8 46, i8 68
  %350 = getelementptr inbounds nuw i8, ptr %6, i16 3
  store i8 %349, ptr %350, align 1, !tbaa !6
  %351 = and i16 %339, 4
  %352 = icmp eq i16 %351, 0
  %353 = select i1 %352, i8 46, i8 73
  %354 = getelementptr inbounds nuw i8, ptr %6, i16 4
  store i8 %353, ptr %354, align 1, !tbaa !6
  %355 = and i16 %339, 2
  %356 = icmp eq i16 %355, 0
  %357 = select i1 %356, i8 46, i8 90
  %358 = getelementptr inbounds nuw i8, ptr %6, i16 5
  store i8 %357, ptr %358, align 1, !tbaa !6
  %359 = and i16 %339, 1
  %360 = icmp eq i16 %359, 0
  %361 = select i1 %360, i8 46, i8 67
  %362 = getelementptr inbounds nuw i8, ptr %6, i16 6
  store i8 %361, ptr %362, align 1, !tbaa !6
  %363 = getelementptr inbounds nuw i8, ptr %6, i16 7
  store i8 0, ptr %363, align 1, !tbaa !6
  store i16 304, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1895), align 1, !tbaa !2
  br label %364

364:                                              ; preds = %337, %380
  %365 = phi i8 [ %383, %380 ], [ %341, %337 ]
  %366 = phi i8 [ %382, %380 ], [ 18, %337 ]
  %367 = phi ptr [ %381, %380 ], [ %6, %337 ]
  %368 = icmp ult i8 %365, 32
  br i1 %368, label %371, label %369

369:                                              ; preds = %364
  %370 = icmp ugt i8 %365, 95
  br i1 %370, label %371, label %372

371:                                              ; preds = %369, %364
  br label %372

372:                                              ; preds = %371, %369
  %373 = phi i8 [ 32, %371 ], [ %365, %369 ]
  %374 = icmp ugt i8 %366, 31
  br i1 %374, label %380, label %375

375:                                              ; preds = %372
  %376 = zext nneg i8 %373 to i16
  %377 = zext nneg i8 %366 to i16
  %378 = add nuw nsw i16 %376, 224
  %379 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1863), i16 %377
  store i16 %378, ptr %379, align 1, !tbaa !2
  br label %380

380:                                              ; preds = %375, %372
  %381 = getelementptr inbounds nuw i8, ptr %367, i16 1
  %382 = add i8 %366, 1
  %383 = load i8, ptr %381, align 1, !tbaa !6
  %384 = icmp eq i8 %383, 0
  br i1 %384, label %385, label %364, !llvm.loop !93

385:                                              ; preds = %380
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #16
  %386 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 2269), align 1, !tbaa !89
  %387 = zext i8 %386 to i16
  %388 = add nuw nsw i16 %387, 5
  %389 = urem i16 %388, 6
  %390 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 2257), i16 %389
  %391 = load i16, ptr %390, align 1, !tbaa !2
  %392 = trunc i16 %391 to i8
  %393 = and i16 %391, 255
  %394 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1999), i16 %393
  %395 = load i8, ptr %394, align 1, !tbaa !6
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #16
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #16
  %396 = zext i8 %395 to i16
  %397 = getelementptr inbounds nuw [7 x i8], ptr @CPU6502_OPS, i16 %396
  %398 = load i8, ptr %397, align 1, !tbaa !6
  store i8 %398, ptr %7, align 1, !tbaa !6
  %399 = getelementptr inbounds nuw i8, ptr %397, i16 1
  %400 = load i8, ptr %399, align 1, !tbaa !6
  %401 = getelementptr inbounds nuw i8, ptr %7, i16 1
  store i8 %400, ptr %401, align 1, !tbaa !6
  %402 = getelementptr inbounds nuw i8, ptr %397, i16 2
  %403 = load i8, ptr %402, align 1, !tbaa !6
  %404 = getelementptr inbounds nuw i8, ptr %7, i16 2
  store i8 %403, ptr %404, align 1, !tbaa !6
  %405 = getelementptr inbounds nuw i8, ptr %7, i16 3
  store i8 32, ptr %405, align 1, !tbaa !6
  call fastcc void @fmt_oper(ptr noundef %8, i8 noundef zeroext %395, i8 noundef zeroext %392) #15
  %406 = load i8, ptr %8, align 1, !tbaa !6
  %407 = icmp eq i8 %406, 0
  br i1 %407, label %420, label %408

408:                                              ; preds = %385, %408
  %409 = phi i8 [ %418, %408 ], [ %406, %385 ]
  %410 = phi i8 [ %412, %408 ], [ 0, %385 ]
  %411 = phi i8 [ %413, %408 ], [ 4, %385 ]
  %412 = add i8 %410, 1
  %413 = add i8 %411, 1
  %414 = zext i8 %411 to i16
  %415 = getelementptr inbounds nuw i8, ptr %7, i16 %414
  store i8 %409, ptr %415, align 1, !tbaa !6
  %416 = zext i8 %412 to i16
  %417 = getelementptr inbounds nuw i8, ptr %8, i16 %416
  %418 = load i8, ptr %417, align 1, !tbaa !6
  %419 = icmp eq i8 %418, 0
  br i1 %419, label %420, label %408, !llvm.loop !105

420:                                              ; preds = %408, %385
  %421 = phi i8 [ 4, %385 ], [ %413, %408 ]
  %422 = zext i8 %421 to i16
  %423 = getelementptr inbounds nuw i8, ptr %7, i16 %422
  store i8 0, ptr %423, align 1, !tbaa !6
  %424 = load i8, ptr %7, align 1, !tbaa !6
  %425 = icmp eq i8 %424, 0
  br i1 %425, label %447, label %426

426:                                              ; preds = %420, %442
  %427 = phi i8 [ %445, %442 ], [ %424, %420 ]
  %428 = phi i8 [ %444, %442 ], [ 0, %420 ]
  %429 = phi ptr [ %443, %442 ], [ %7, %420 ]
  %430 = icmp ult i8 %427, 32
  br i1 %430, label %433, label %431

431:                                              ; preds = %426
  %432 = icmp ugt i8 %427, 95
  br i1 %432, label %433, label %434

433:                                              ; preds = %431, %426
  br label %434

434:                                              ; preds = %433, %431
  %435 = phi i8 [ 32, %433 ], [ %427, %431 ]
  %436 = icmp ugt i8 %428, 31
  br i1 %436, label %442, label %437

437:                                              ; preds = %434
  %438 = zext nneg i8 %435 to i16
  %439 = zext nneg i8 %428 to i16
  %440 = add nuw nsw i16 %438, 1248
  %441 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1927), i16 %439
  store i16 %440, ptr %441, align 1, !tbaa !2
  br label %442

442:                                              ; preds = %437, %434
  %443 = getelementptr inbounds nuw i8, ptr %429, i16 1
  %444 = add i8 %428, 1
  %445 = load i8, ptr %443, align 1, !tbaa !6
  %446 = icmp eq i8 %445, 0
  br i1 %446, label %447, label %426, !llvm.loop !93

447:                                              ; preds = %442, %420
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #16
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #16
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1991), align 1, !tbaa !21
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #16
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #16
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #16
  ret void
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal fastcc zeroext i8 @cpu6502_step(ptr noundef %0) unnamed_addr #3 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 5
  %4 = load i16, ptr %3, align 1, !tbaa !36
  %5 = and i16 %4, 255
  %6 = getelementptr inbounds nuw i8, ptr %2, i16 %5
  %7 = load i8, ptr %6, align 1, !tbaa !6
  %8 = zext i8 %7 to i16
  %9 = getelementptr inbounds nuw [7 x i8], ptr @CPU6502_OPS, i16 %8
  %10 = getelementptr inbounds nuw i8, ptr %9, i16 6
  %11 = load i8, ptr %10, align 1, !tbaa !106
  %12 = getelementptr inbounds nuw i8, ptr %9, i16 5
  %13 = load i8, ptr %12, align 1, !tbaa !95
  %14 = zext i8 %13 to i16
  %15 = icmp ugt i8 %13, 1
  br i1 %15, label %16, label %22

16:                                               ; preds = %1
  %17 = trunc i16 %4 to i8
  %18 = add i8 %17, 1
  %19 = zext i8 %18 to i16
  %20 = getelementptr inbounds nuw i8, ptr %2, i16 %19
  %21 = load i8, ptr %20, align 1, !tbaa !6
  br label %22

22:                                               ; preds = %1, %16
  %23 = phi i8 [ %21, %16 ], [ 0, %1 ]
  switch i8 %7, label %572 [
    i8 -87, label %24
    i8 -94, label %33
    i8 -96, label %43
    i8 -91, label %53
    i8 -123, label %65
    i8 -122, label %69
    i8 -124, label %74
    i8 -86, label %79
    i8 -88, label %90
    i8 -118, label %101
    i8 -104, label %112
    i8 105, label %123
    i8 101, label %161
    i8 -24, label %202
    i8 -56, label %214
    i8 -54, label %226
    i8 -120, label %238
    i8 41, label %250
    i8 37, label %261
    i8 9, label %275
    i8 5, label %286
    i8 73, label %300
    i8 69, label %311
    i8 10, label %325
    i8 74, label %338
    i8 42, label %349
    i8 106, label %364
    i8 -55, label %377
    i8 -59, label %400
    i8 -32, label %426
    i8 -64, label %450
    i8 -48, label %474
    i8 -16, label %483
    i8 -112, label %492
    i8 -80, label %501
    i8 48, label %510
    i8 16, label %518
    i8 -128, label %526
    i8 76, label %530
    i8 24, label %544
    i8 56, label %548
    i8 88, label %552
    i8 120, label %556
    i8 -40, label %560
    i8 -8, label %564
    i8 -72, label %568
  ]

24:                                               ; preds = %22
  store i8 %23, ptr %0, align 1, !tbaa !30
  %25 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %26 = load i8, ptr %25, align 1, !tbaa !35
  %27 = and i8 %26, 125
  %28 = and i8 %23, -128
  %29 = icmp eq i8 %23, 0
  %30 = select i1 %29, i8 2, i8 0
  %31 = or disjoint i8 %30, %28
  %32 = or disjoint i8 %31, %27
  store i8 %32, ptr %25, align 1, !tbaa !35
  br label %572

33:                                               ; preds = %22
  %34 = getelementptr inbounds nuw i8, ptr %0, i16 1
  store i8 %23, ptr %34, align 1, !tbaa !32
  %35 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %36 = load i8, ptr %35, align 1, !tbaa !35
  %37 = and i8 %36, 125
  %38 = and i8 %23, -128
  %39 = icmp eq i8 %23, 0
  %40 = select i1 %39, i8 2, i8 0
  %41 = or disjoint i8 %40, %38
  %42 = or disjoint i8 %41, %37
  store i8 %42, ptr %35, align 1, !tbaa !35
  br label %572

43:                                               ; preds = %22
  %44 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 %23, ptr %44, align 1, !tbaa !33
  %45 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %46 = load i8, ptr %45, align 1, !tbaa !35
  %47 = and i8 %46, 125
  %48 = and i8 %23, -128
  %49 = icmp eq i8 %23, 0
  %50 = select i1 %49, i8 2, i8 0
  %51 = or disjoint i8 %50, %48
  %52 = or disjoint i8 %51, %47
  store i8 %52, ptr %45, align 1, !tbaa !35
  br label %572

53:                                               ; preds = %22
  %54 = zext i8 %23 to i16
  %55 = getelementptr inbounds nuw i8, ptr %2, i16 %54
  %56 = load i8, ptr %55, align 1, !tbaa !6
  store i8 %56, ptr %0, align 1, !tbaa !30
  %57 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %58 = load i8, ptr %57, align 1, !tbaa !35
  %59 = and i8 %58, 125
  %60 = and i8 %56, -128
  %61 = icmp eq i8 %56, 0
  %62 = select i1 %61, i8 2, i8 0
  %63 = or disjoint i8 %62, %60
  %64 = or disjoint i8 %63, %59
  store i8 %64, ptr %57, align 1, !tbaa !35
  br label %572

65:                                               ; preds = %22
  %66 = load i8, ptr %0, align 1, !tbaa !30
  %67 = zext i8 %23 to i16
  %68 = getelementptr inbounds nuw i8, ptr %2, i16 %67
  store i8 %66, ptr %68, align 1, !tbaa !6
  br label %572

69:                                               ; preds = %22
  %70 = getelementptr inbounds nuw i8, ptr %0, i16 1
  %71 = load i8, ptr %70, align 1, !tbaa !32
  %72 = zext i8 %23 to i16
  %73 = getelementptr inbounds nuw i8, ptr %2, i16 %72
  store i8 %71, ptr %73, align 1, !tbaa !6
  br label %572

74:                                               ; preds = %22
  %75 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %76 = load i8, ptr %75, align 1, !tbaa !33
  %77 = zext i8 %23 to i16
  %78 = getelementptr inbounds nuw i8, ptr %2, i16 %77
  store i8 %76, ptr %78, align 1, !tbaa !6
  br label %572

79:                                               ; preds = %22
  %80 = load i8, ptr %0, align 1, !tbaa !30
  %81 = getelementptr inbounds nuw i8, ptr %0, i16 1
  store i8 %80, ptr %81, align 1, !tbaa !32
  %82 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %83 = load i8, ptr %82, align 1, !tbaa !35
  %84 = and i8 %83, 125
  %85 = and i8 %80, -128
  %86 = icmp eq i8 %80, 0
  %87 = select i1 %86, i8 2, i8 0
  %88 = or disjoint i8 %87, %85
  %89 = or disjoint i8 %88, %84
  store i8 %89, ptr %82, align 1, !tbaa !35
  br label %572

90:                                               ; preds = %22
  %91 = load i8, ptr %0, align 1, !tbaa !30
  %92 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 %91, ptr %92, align 1, !tbaa !33
  %93 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %94 = load i8, ptr %93, align 1, !tbaa !35
  %95 = and i8 %94, 125
  %96 = and i8 %91, -128
  %97 = icmp eq i8 %91, 0
  %98 = select i1 %97, i8 2, i8 0
  %99 = or disjoint i8 %98, %96
  %100 = or disjoint i8 %99, %95
  store i8 %100, ptr %93, align 1, !tbaa !35
  br label %572

101:                                              ; preds = %22
  %102 = getelementptr inbounds nuw i8, ptr %0, i16 1
  %103 = load i8, ptr %102, align 1, !tbaa !32
  store i8 %103, ptr %0, align 1, !tbaa !30
  %104 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %105 = load i8, ptr %104, align 1, !tbaa !35
  %106 = and i8 %105, 125
  %107 = and i8 %103, -128
  %108 = icmp eq i8 %103, 0
  %109 = select i1 %108, i8 2, i8 0
  %110 = or disjoint i8 %109, %107
  %111 = or disjoint i8 %110, %106
  store i8 %111, ptr %104, align 1, !tbaa !35
  br label %572

112:                                              ; preds = %22
  %113 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %114 = load i8, ptr %113, align 1, !tbaa !33
  store i8 %114, ptr %0, align 1, !tbaa !30
  %115 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %116 = load i8, ptr %115, align 1, !tbaa !35
  %117 = and i8 %116, 125
  %118 = and i8 %114, -128
  %119 = icmp eq i8 %114, 0
  %120 = select i1 %119, i8 2, i8 0
  %121 = or disjoint i8 %120, %118
  %122 = or disjoint i8 %121, %117
  store i8 %122, ptr %115, align 1, !tbaa !35
  br label %572

123:                                              ; preds = %22
  %124 = load i8, ptr %0, align 1, !tbaa !30
  %125 = zext i8 %124 to i16
  %126 = zext i8 %23 to i16
  %127 = add nuw nsw i16 %125, %126
  %128 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %129 = load i8, ptr %128, align 1, !tbaa !35
  %130 = and i8 %129, 1
  %131 = zext nneg i8 %130 to i16
  %132 = add nuw nsw i16 %127, %131
  %133 = and i8 %129, 60
  %134 = icmp samesign ugt i16 %132, 255
  br i1 %134, label %135, label %137

135:                                              ; preds = %123
  %136 = or disjoint i8 %133, 1
  br label %137

137:                                              ; preds = %135, %123
  %138 = phi i8 [ %136, %135 ], [ %133, %123 ]
  %139 = trunc i16 %132 to i8
  %140 = icmp eq i8 %139, 0
  br i1 %140, label %141, label %143

141:                                              ; preds = %137
  %142 = or i8 %138, 2
  br label %143

143:                                              ; preds = %141, %137
  %144 = phi i8 [ %142, %141 ], [ %138, %137 ]
  %145 = and i16 %132, 128
  %146 = icmp eq i16 %145, 0
  br i1 %146, label %149, label %147

147:                                              ; preds = %143
  %148 = or i8 %144, -128
  br label %149

149:                                              ; preds = %147, %143
  %150 = phi i8 [ %148, %147 ], [ %144, %143 ]
  %151 = xor i16 %126, %125
  %152 = xor i16 %132, %125
  %153 = and i16 %151, 128
  %154 = xor i16 %153, 128
  %155 = and i16 %154, %152
  %156 = icmp eq i16 %155, 0
  br i1 %156, label %159, label %157

157:                                              ; preds = %149
  %158 = or i8 %150, 64
  br label %159

159:                                              ; preds = %157, %149
  %160 = phi i8 [ %158, %157 ], [ %150, %149 ]
  store i8 %160, ptr %128, align 1, !tbaa !35
  store i8 %139, ptr %0, align 1, !tbaa !30
  br label %572

161:                                              ; preds = %22
  %162 = zext i8 %23 to i16
  %163 = getelementptr inbounds nuw i8, ptr %2, i16 %162
  %164 = load i8, ptr %163, align 1, !tbaa !6
  %165 = load i8, ptr %0, align 1, !tbaa !30
  %166 = zext i8 %165 to i16
  %167 = zext i8 %164 to i16
  %168 = add nuw nsw i16 %166, %167
  %169 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %170 = load i8, ptr %169, align 1, !tbaa !35
  %171 = and i8 %170, 1
  %172 = zext nneg i8 %171 to i16
  %173 = add nuw nsw i16 %168, %172
  %174 = and i8 %170, 60
  %175 = icmp samesign ugt i16 %173, 255
  br i1 %175, label %176, label %178

176:                                              ; preds = %161
  %177 = or disjoint i8 %174, 1
  br label %178

178:                                              ; preds = %176, %161
  %179 = phi i8 [ %177, %176 ], [ %174, %161 ]
  %180 = trunc i16 %173 to i8
  %181 = icmp eq i8 %180, 0
  br i1 %181, label %182, label %184

182:                                              ; preds = %178
  %183 = or i8 %179, 2
  br label %184

184:                                              ; preds = %182, %178
  %185 = phi i8 [ %183, %182 ], [ %179, %178 ]
  %186 = and i16 %173, 128
  %187 = icmp eq i16 %186, 0
  br i1 %187, label %190, label %188

188:                                              ; preds = %184
  %189 = or i8 %185, -128
  br label %190

190:                                              ; preds = %188, %184
  %191 = phi i8 [ %189, %188 ], [ %185, %184 ]
  %192 = xor i16 %167, %166
  %193 = xor i16 %173, %166
  %194 = and i16 %192, 128
  %195 = xor i16 %194, 128
  %196 = and i16 %195, %193
  %197 = icmp eq i16 %196, 0
  br i1 %197, label %200, label %198

198:                                              ; preds = %190
  %199 = or i8 %191, 64
  br label %200

200:                                              ; preds = %198, %190
  %201 = phi i8 [ %199, %198 ], [ %191, %190 ]
  store i8 %201, ptr %169, align 1, !tbaa !35
  store i8 %180, ptr %0, align 1, !tbaa !30
  br label %572

202:                                              ; preds = %22
  %203 = getelementptr inbounds nuw i8, ptr %0, i16 1
  %204 = load i8, ptr %203, align 1, !tbaa !32
  %205 = add i8 %204, 1
  store i8 %205, ptr %203, align 1, !tbaa !32
  %206 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %207 = load i8, ptr %206, align 1, !tbaa !35
  %208 = and i8 %207, 125
  %209 = and i8 %205, -128
  %210 = icmp eq i8 %205, 0
  %211 = select i1 %210, i8 2, i8 0
  %212 = or disjoint i8 %211, %209
  %213 = or disjoint i8 %212, %208
  store i8 %213, ptr %206, align 1, !tbaa !35
  br label %572

214:                                              ; preds = %22
  %215 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %216 = load i8, ptr %215, align 1, !tbaa !33
  %217 = add i8 %216, 1
  store i8 %217, ptr %215, align 1, !tbaa !33
  %218 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %219 = load i8, ptr %218, align 1, !tbaa !35
  %220 = and i8 %219, 125
  %221 = and i8 %217, -128
  %222 = icmp eq i8 %217, 0
  %223 = select i1 %222, i8 2, i8 0
  %224 = or disjoint i8 %223, %221
  %225 = or disjoint i8 %224, %220
  store i8 %225, ptr %218, align 1, !tbaa !35
  br label %572

226:                                              ; preds = %22
  %227 = getelementptr inbounds nuw i8, ptr %0, i16 1
  %228 = load i8, ptr %227, align 1, !tbaa !32
  %229 = add i8 %228, -1
  store i8 %229, ptr %227, align 1, !tbaa !32
  %230 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %231 = load i8, ptr %230, align 1, !tbaa !35
  %232 = and i8 %231, 125
  %233 = and i8 %229, -128
  %234 = icmp eq i8 %229, 0
  %235 = select i1 %234, i8 2, i8 0
  %236 = or disjoint i8 %235, %233
  %237 = or disjoint i8 %236, %232
  store i8 %237, ptr %230, align 1, !tbaa !35
  br label %572

238:                                              ; preds = %22
  %239 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %240 = load i8, ptr %239, align 1, !tbaa !33
  %241 = add i8 %240, -1
  store i8 %241, ptr %239, align 1, !tbaa !33
  %242 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %243 = load i8, ptr %242, align 1, !tbaa !35
  %244 = and i8 %243, 125
  %245 = and i8 %241, -128
  %246 = icmp eq i8 %241, 0
  %247 = select i1 %246, i8 2, i8 0
  %248 = or disjoint i8 %247, %245
  %249 = or disjoint i8 %248, %244
  store i8 %249, ptr %242, align 1, !tbaa !35
  br label %572

250:                                              ; preds = %22
  %251 = load i8, ptr %0, align 1, !tbaa !30
  %252 = and i8 %251, %23
  store i8 %252, ptr %0, align 1, !tbaa !30
  %253 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %254 = load i8, ptr %253, align 1, !tbaa !35
  %255 = and i8 %254, 125
  %256 = and i8 %252, -128
  %257 = icmp eq i8 %252, 0
  %258 = select i1 %257, i8 2, i8 0
  %259 = or disjoint i8 %258, %256
  %260 = or disjoint i8 %259, %255
  store i8 %260, ptr %253, align 1, !tbaa !35
  br label %572

261:                                              ; preds = %22
  %262 = load i8, ptr %0, align 1, !tbaa !30
  %263 = zext i8 %23 to i16
  %264 = getelementptr inbounds nuw i8, ptr %2, i16 %263
  %265 = load i8, ptr %264, align 1, !tbaa !6
  %266 = and i8 %265, %262
  store i8 %266, ptr %0, align 1, !tbaa !30
  %267 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %268 = load i8, ptr %267, align 1, !tbaa !35
  %269 = and i8 %268, 125
  %270 = and i8 %266, -128
  %271 = icmp eq i8 %266, 0
  %272 = select i1 %271, i8 2, i8 0
  %273 = or disjoint i8 %272, %270
  %274 = or disjoint i8 %273, %269
  store i8 %274, ptr %267, align 1, !tbaa !35
  br label %572

275:                                              ; preds = %22
  %276 = load i8, ptr %0, align 1, !tbaa !30
  %277 = or i8 %276, %23
  store i8 %277, ptr %0, align 1, !tbaa !30
  %278 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %279 = load i8, ptr %278, align 1, !tbaa !35
  %280 = and i8 %279, 125
  %281 = and i8 %277, -128
  %282 = icmp eq i8 %277, 0
  %283 = select i1 %282, i8 2, i8 0
  %284 = or disjoint i8 %283, %281
  %285 = or disjoint i8 %284, %280
  store i8 %285, ptr %278, align 1, !tbaa !35
  br label %572

286:                                              ; preds = %22
  %287 = load i8, ptr %0, align 1, !tbaa !30
  %288 = zext i8 %23 to i16
  %289 = getelementptr inbounds nuw i8, ptr %2, i16 %288
  %290 = load i8, ptr %289, align 1, !tbaa !6
  %291 = or i8 %290, %287
  store i8 %291, ptr %0, align 1, !tbaa !30
  %292 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %293 = load i8, ptr %292, align 1, !tbaa !35
  %294 = and i8 %293, 125
  %295 = and i8 %291, -128
  %296 = icmp eq i8 %291, 0
  %297 = select i1 %296, i8 2, i8 0
  %298 = or disjoint i8 %297, %295
  %299 = or disjoint i8 %298, %294
  store i8 %299, ptr %292, align 1, !tbaa !35
  br label %572

300:                                              ; preds = %22
  %301 = load i8, ptr %0, align 1, !tbaa !30
  %302 = xor i8 %301, %23
  store i8 %302, ptr %0, align 1, !tbaa !30
  %303 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %304 = load i8, ptr %303, align 1, !tbaa !35
  %305 = and i8 %304, 125
  %306 = and i8 %302, -128
  %307 = icmp eq i8 %301, %23
  %308 = select i1 %307, i8 2, i8 0
  %309 = or disjoint i8 %308, %306
  %310 = or disjoint i8 %309, %305
  store i8 %310, ptr %303, align 1, !tbaa !35
  br label %572

311:                                              ; preds = %22
  %312 = load i8, ptr %0, align 1, !tbaa !30
  %313 = zext i8 %23 to i16
  %314 = getelementptr inbounds nuw i8, ptr %2, i16 %313
  %315 = load i8, ptr %314, align 1, !tbaa !6
  %316 = xor i8 %315, %312
  store i8 %316, ptr %0, align 1, !tbaa !30
  %317 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %318 = load i8, ptr %317, align 1, !tbaa !35
  %319 = and i8 %318, 125
  %320 = and i8 %316, -128
  %321 = icmp eq i8 %312, %315
  %322 = select i1 %321, i8 2, i8 0
  %323 = or disjoint i8 %322, %320
  %324 = or disjoint i8 %323, %319
  store i8 %324, ptr %317, align 1, !tbaa !35
  br label %572

325:                                              ; preds = %22
  %326 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %327 = load i8, ptr %326, align 1, !tbaa !35
  %328 = and i8 %327, 124
  %329 = load i8, ptr %0, align 1, !tbaa !30
  %330 = lshr i8 %329, 7
  %331 = or disjoint i8 %330, %328
  %332 = shl i8 %329, 1
  store i8 %332, ptr %0, align 1, !tbaa !30
  %333 = and i8 %332, -128
  %334 = icmp eq i8 %332, 0
  %335 = select i1 %334, i8 2, i8 0
  %336 = or disjoint i8 %335, %333
  %337 = or disjoint i8 %336, %331
  store i8 %337, ptr %326, align 1, !tbaa !35
  br label %572

338:                                              ; preds = %22
  %339 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %340 = load i8, ptr %339, align 1, !tbaa !35
  %341 = and i8 %340, 124
  %342 = load i8, ptr %0, align 1, !tbaa !30
  %343 = and i8 %342, 1
  %344 = or disjoint i8 %343, %341
  %345 = lshr i8 %342, 1
  store i8 %345, ptr %0, align 1, !tbaa !30
  %346 = icmp eq i8 %345, 0
  %347 = select i1 %346, i8 2, i8 0
  %348 = or disjoint i8 %347, %344
  store i8 %348, ptr %339, align 1, !tbaa !35
  br label %572

349:                                              ; preds = %22
  %350 = load i8, ptr %0, align 1, !tbaa !30
  %351 = shl i8 %350, 1
  %352 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %353 = load i8, ptr %352, align 1, !tbaa !35
  %354 = and i8 %353, 1
  %355 = or disjoint i8 %354, %351
  %356 = and i8 %353, 124
  %357 = lshr i8 %350, 7
  %358 = or disjoint i8 %356, %357
  store i8 %355, ptr %0, align 1, !tbaa !30
  %359 = and i8 %351, -128
  %360 = icmp eq i8 %355, 0
  %361 = select i1 %360, i8 2, i8 0
  %362 = or disjoint i8 %358, %359
  %363 = or disjoint i8 %362, %361
  store i8 %363, ptr %352, align 1, !tbaa !35
  br label %572

364:                                              ; preds = %22
  %365 = load i8, ptr %0, align 1, !tbaa !30
  %366 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %367 = load i8, ptr %366, align 1, !tbaa !35
  %368 = tail call i8 @llvm.fshl.i8(i8 %367, i8 %365, i8 7)
  %369 = and i8 %367, 124
  %370 = and i8 %365, 1
  %371 = or disjoint i8 %369, %370
  store i8 %368, ptr %0, align 1, !tbaa !30
  %372 = and i8 %368, -128
  %373 = icmp eq i8 %368, 0
  %374 = select i1 %373, i8 2, i8 0
  %375 = or disjoint i8 %374, %372
  %376 = or disjoint i8 %375, %371
  store i8 %376, ptr %366, align 1, !tbaa !35
  br label %572

377:                                              ; preds = %22
  %378 = load i8, ptr %0, align 1, !tbaa !30
  %379 = zext i8 %378 to i16
  %380 = zext i8 %23 to i16
  %381 = sub nsw i16 %379, %380
  %382 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %383 = load i8, ptr %382, align 1, !tbaa !35
  %384 = and i8 %383, 124
  %385 = icmp ult i8 %378, %23
  br i1 %385, label %388, label %386

386:                                              ; preds = %377
  %387 = or disjoint i8 %384, 1
  br label %388

388:                                              ; preds = %386, %377
  %389 = phi i8 [ %387, %386 ], [ %384, %377 ]
  %390 = and i16 %381, 255
  %391 = icmp eq i16 %390, 0
  br i1 %391, label %392, label %394

392:                                              ; preds = %388
  %393 = or i8 %389, 2
  br label %394

394:                                              ; preds = %392, %388
  %395 = phi i8 [ %393, %392 ], [ %389, %388 ]
  store i8 %395, ptr %382, align 1, !tbaa !35
  %396 = and i16 %381, 128
  %397 = icmp eq i16 %396, 0
  br i1 %397, label %572, label %398

398:                                              ; preds = %394
  %399 = or i8 %395, -128
  store i8 %399, ptr %382, align 1, !tbaa !35
  br label %572

400:                                              ; preds = %22
  %401 = zext i8 %23 to i16
  %402 = getelementptr inbounds nuw i8, ptr %2, i16 %401
  %403 = load i8, ptr %402, align 1, !tbaa !6
  %404 = load i8, ptr %0, align 1, !tbaa !30
  %405 = zext i8 %404 to i16
  %406 = zext i8 %403 to i16
  %407 = sub nsw i16 %405, %406
  %408 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %409 = load i8, ptr %408, align 1, !tbaa !35
  %410 = and i8 %409, 124
  %411 = icmp ult i8 %404, %403
  br i1 %411, label %414, label %412

412:                                              ; preds = %400
  %413 = or disjoint i8 %410, 1
  br label %414

414:                                              ; preds = %412, %400
  %415 = phi i8 [ %413, %412 ], [ %410, %400 ]
  %416 = and i16 %407, 255
  %417 = icmp eq i16 %416, 0
  br i1 %417, label %418, label %420

418:                                              ; preds = %414
  %419 = or i8 %415, 2
  br label %420

420:                                              ; preds = %418, %414
  %421 = phi i8 [ %419, %418 ], [ %415, %414 ]
  store i8 %421, ptr %408, align 1, !tbaa !35
  %422 = and i16 %407, 128
  %423 = icmp eq i16 %422, 0
  br i1 %423, label %572, label %424

424:                                              ; preds = %420
  %425 = or i8 %421, -128
  store i8 %425, ptr %408, align 1, !tbaa !35
  br label %572

426:                                              ; preds = %22
  %427 = getelementptr inbounds nuw i8, ptr %0, i16 1
  %428 = load i8, ptr %427, align 1, !tbaa !32
  %429 = zext i8 %428 to i16
  %430 = zext i8 %23 to i16
  %431 = sub nsw i16 %429, %430
  %432 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %433 = load i8, ptr %432, align 1, !tbaa !35
  %434 = and i8 %433, 124
  %435 = icmp ult i8 %428, %23
  br i1 %435, label %438, label %436

436:                                              ; preds = %426
  %437 = or disjoint i8 %434, 1
  br label %438

438:                                              ; preds = %436, %426
  %439 = phi i8 [ %437, %436 ], [ %434, %426 ]
  %440 = and i16 %431, 255
  %441 = icmp eq i16 %440, 0
  br i1 %441, label %442, label %444

442:                                              ; preds = %438
  %443 = or i8 %439, 2
  br label %444

444:                                              ; preds = %442, %438
  %445 = phi i8 [ %443, %442 ], [ %439, %438 ]
  store i8 %445, ptr %432, align 1, !tbaa !35
  %446 = and i16 %431, 128
  %447 = icmp eq i16 %446, 0
  br i1 %447, label %572, label %448

448:                                              ; preds = %444
  %449 = or i8 %445, -128
  store i8 %449, ptr %432, align 1, !tbaa !35
  br label %572

450:                                              ; preds = %22
  %451 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %452 = load i8, ptr %451, align 1, !tbaa !33
  %453 = zext i8 %452 to i16
  %454 = zext i8 %23 to i16
  %455 = sub nsw i16 %453, %454
  %456 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %457 = load i8, ptr %456, align 1, !tbaa !35
  %458 = and i8 %457, 124
  %459 = icmp ult i8 %452, %23
  br i1 %459, label %462, label %460

460:                                              ; preds = %450
  %461 = or disjoint i8 %458, 1
  br label %462

462:                                              ; preds = %460, %450
  %463 = phi i8 [ %461, %460 ], [ %458, %450 ]
  %464 = and i16 %455, 255
  %465 = icmp eq i16 %464, 0
  br i1 %465, label %466, label %468

466:                                              ; preds = %462
  %467 = or i8 %463, 2
  br label %468

468:                                              ; preds = %466, %462
  %469 = phi i8 [ %467, %466 ], [ %463, %462 ]
  store i8 %469, ptr %456, align 1, !tbaa !35
  %470 = and i16 %455, 128
  %471 = icmp eq i16 %470, 0
  br i1 %471, label %572, label %472

472:                                              ; preds = %468
  %473 = or i8 %469, -128
  store i8 %473, ptr %456, align 1, !tbaa !35
  br label %572

474:                                              ; preds = %22
  %475 = add i16 %4, %14
  store i16 %475, ptr %3, align 1, !tbaa !36
  %476 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %477 = load i8, ptr %476, align 1, !tbaa !35
  %478 = and i8 %477, 2
  %479 = icmp eq i8 %478, 0
  br i1 %479, label %480, label %576

480:                                              ; preds = %474
  %481 = sext i8 %23 to i16
  %482 = add nsw i16 %475, %481
  br label %574

483:                                              ; preds = %22
  %484 = add i16 %4, %14
  store i16 %484, ptr %3, align 1, !tbaa !36
  %485 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %486 = load i8, ptr %485, align 1, !tbaa !35
  %487 = and i8 %486, 2
  %488 = icmp eq i8 %487, 0
  br i1 %488, label %576, label %489

489:                                              ; preds = %483
  %490 = sext i8 %23 to i16
  %491 = add nsw i16 %484, %490
  br label %574

492:                                              ; preds = %22
  %493 = add i16 %4, %14
  store i16 %493, ptr %3, align 1, !tbaa !36
  %494 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %495 = load i8, ptr %494, align 1, !tbaa !35
  %496 = and i8 %495, 1
  %497 = icmp eq i8 %496, 0
  br i1 %497, label %498, label %576

498:                                              ; preds = %492
  %499 = sext i8 %23 to i16
  %500 = add nsw i16 %493, %499
  br label %574

501:                                              ; preds = %22
  %502 = add i16 %4, %14
  store i16 %502, ptr %3, align 1, !tbaa !36
  %503 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %504 = load i8, ptr %503, align 1, !tbaa !35
  %505 = and i8 %504, 1
  %506 = icmp eq i8 %505, 0
  br i1 %506, label %576, label %507

507:                                              ; preds = %501
  %508 = sext i8 %23 to i16
  %509 = add nsw i16 %502, %508
  br label %574

510:                                              ; preds = %22
  %511 = add i16 %4, %14
  store i16 %511, ptr %3, align 1, !tbaa !36
  %512 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %513 = load i8, ptr %512, align 1, !tbaa !35
  %514 = icmp sgt i8 %513, -1
  br i1 %514, label %576, label %515

515:                                              ; preds = %510
  %516 = sext i8 %23 to i16
  %517 = add nsw i16 %511, %516
  br label %574

518:                                              ; preds = %22
  %519 = add i16 %4, %14
  store i16 %519, ptr %3, align 1, !tbaa !36
  %520 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %521 = load i8, ptr %520, align 1, !tbaa !35
  %522 = icmp sgt i8 %521, -1
  br i1 %522, label %523, label %576

523:                                              ; preds = %518
  %524 = sext i8 %23 to i16
  %525 = add nsw i16 %519, %524
  br label %574

526:                                              ; preds = %22
  %527 = add i16 %4, %14
  %528 = sext i8 %23 to i16
  %529 = add nsw i16 %527, %528
  br label %574

530:                                              ; preds = %22
  %531 = trunc i16 %4 to i8
  %532 = add i8 %531, 1
  %533 = zext i8 %532 to i16
  %534 = getelementptr inbounds nuw i8, ptr %2, i16 %533
  %535 = load i8, ptr %534, align 1, !tbaa !6
  %536 = add i8 %531, 2
  %537 = zext i8 %536 to i16
  %538 = getelementptr inbounds nuw i8, ptr %2, i16 %537
  %539 = load i8, ptr %538, align 1, !tbaa !6
  %540 = zext i8 %539 to i16
  %541 = shl nuw i16 %540, 8
  %542 = zext i8 %535 to i16
  %543 = or disjoint i16 %541, %542
  br label %574

544:                                              ; preds = %22
  %545 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %546 = load i8, ptr %545, align 1, !tbaa !35
  %547 = and i8 %546, -2
  store i8 %547, ptr %545, align 1, !tbaa !35
  br label %572

548:                                              ; preds = %22
  %549 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %550 = load i8, ptr %549, align 1, !tbaa !35
  %551 = or i8 %550, 1
  store i8 %551, ptr %549, align 1, !tbaa !35
  br label %572

552:                                              ; preds = %22
  %553 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %554 = load i8, ptr %553, align 1, !tbaa !35
  %555 = and i8 %554, -5
  store i8 %555, ptr %553, align 1, !tbaa !35
  br label %572

556:                                              ; preds = %22
  %557 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %558 = load i8, ptr %557, align 1, !tbaa !35
  %559 = or i8 %558, 4
  store i8 %559, ptr %557, align 1, !tbaa !35
  br label %572

560:                                              ; preds = %22
  %561 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %562 = load i8, ptr %561, align 1, !tbaa !35
  %563 = and i8 %562, -9
  store i8 %563, ptr %561, align 1, !tbaa !35
  br label %572

564:                                              ; preds = %22
  %565 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %566 = load i8, ptr %565, align 1, !tbaa !35
  %567 = or i8 %566, 8
  store i8 %567, ptr %565, align 1, !tbaa !35
  br label %572

568:                                              ; preds = %22
  %569 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %570 = load i8, ptr %569, align 1, !tbaa !35
  %571 = and i8 %570, -65
  store i8 %571, ptr %569, align 1, !tbaa !35
  br label %572

572:                                              ; preds = %22, %468, %472, %444, %448, %420, %424, %394, %398, %568, %564, %560, %556, %552, %548, %544, %364, %349, %338, %325, %311, %300, %286, %275, %261, %250, %238, %226, %214, %202, %200, %159, %112, %101, %90, %79, %74, %69, %65, %53, %43, %33, %24
  %573 = add i16 %4, %14
  br label %574

574:                                              ; preds = %526, %530, %572, %480, %489, %498, %507, %515, %523
  %575 = phi i16 [ %525, %523 ], [ %517, %515 ], [ %509, %507 ], [ %500, %498 ], [ %491, %489 ], [ %482, %480 ], [ %573, %572 ], [ %543, %530 ], [ %529, %526 ]
  store i16 %575, ptr %3, align 1, !tbaa !36
  br label %576

576:                                              ; preds = %574, %518, %510, %501, %492, %483, %474
  ret i8 %11
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_tg_reserve(ptr readnone captures(none) %0, ptr readnone captures(none) %1) #4 {
  store volatile i8 64, ptr inttoptr (i16 8457 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8460 to ptr), align 4, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 0, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %4

3:                                                ; preds = %4
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 2048, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %11

4:                                                ; preds = %2, %4
  %5 = phi i16 [ 0, %2 ], [ %8, %4 ]
  %6 = getelementptr inbounds nuw [2 x i8], ptr @FONT16, i16 %5
  %7 = load i16, ptr %6, align 1, !tbaa !2
  store volatile i16 %7, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %8 = add nuw nsw i16 %5, 1
  %9 = icmp eq i16 %8, 2048
  br i1 %9, label %3, label %4, !llvm.loop !107

10:                                               ; preds = %11
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 2072, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %18

11:                                               ; preds = %3, %11
  %12 = phi i16 [ 0, %3 ], [ %15, %11 ]
  %13 = getelementptr inbounds nuw [2 x i8], ptr @FONT8, i16 %12
  %14 = load i16, ptr %13, align 1, !tbaa !2
  store volatile i16 %14, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %15 = add nuw nsw i16 %12, 1
  %16 = icmp eq i16 %15, 512
  br i1 %16, label %10, label %11, !llvm.loop !108

17:                                               ; preds = %18
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 2080, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %344

18:                                               ; preds = %10, %18
  %19 = phi i8 [ 0, %10 ], [ %26, %18 ]
  %20 = phi i8 [ 0, %10 ], [ %24, %18 ]
  %21 = zext nneg i8 %19 to i16
  %22 = getelementptr i8, ptr @GLYPH_HASH, i16 %21
  %23 = load i16, ptr %22, align 1, !tbaa !2
  store volatile i16 %23, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %24 = add nuw nsw i8 %20, 1
  %25 = icmp eq i8 %24, 8
  %26 = add nuw nsw i8 %19, 2
  br i1 %25, label %17, label %18, !llvm.loop !109

27:                                               ; preds = %344
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(768) @gate_chr, i8 0, i16 768, i1 false), !tbaa !2
  br label %28

28:                                               ; preds = %28, %27
  %29 = phi i8 [ %38, %28 ], [ 0, %27 ]
  %30 = zext nneg i8 %29 to i16
  %31 = and i16 %30, 7
  %32 = lshr exact i16 128, %31
  %33 = and i16 %30, 24
  %34 = getelementptr inbounds nuw [2 x i8], ptr @gate_chr, i16 %33
  %35 = getelementptr inbounds nuw i8, ptr %34, i16 4
  %36 = load i16, ptr %35, align 1, !tbaa !2
  %37 = or i16 %32, %36
  store i16 %37, ptr %35, align 1, !tbaa !2
  %38 = add nuw nsw i8 %29, 1
  %39 = icmp eq i8 %29, 10
  br i1 %39, label %40, label %28, !llvm.loop !110

40:                                               ; preds = %28, %40
  %41 = phi i8 [ %51, %40 ], [ 0, %28 ]
  %42 = zext nneg i8 %41 to i16
  %43 = and i16 %42, 7
  %44 = lshr exact i16 128, %43
  %45 = add nuw nsw i16 %42, 24
  %46 = and i16 %45, 56
  %47 = getelementptr inbounds nuw [2 x i8], ptr @gate_chr, i16 %46
  %48 = getelementptr inbounds nuw i8, ptr %47, i16 10
  %49 = load i16, ptr %48, align 1, !tbaa !2
  %50 = or i16 %44, %49
  store i16 %50, ptr %48, align 1, !tbaa !2
  %51 = add nuw nsw i8 %41, 1
  %52 = icmp eq i8 %41, 10
  br i1 %52, label %53, label %40, !llvm.loop !110

53:                                               ; preds = %40, %53
  %54 = phi i8 [ %63, %53 ], [ 2, %40 ]
  %55 = zext nneg i8 %54 to i16
  %56 = lshr i16 %55, 3
  %57 = and i16 %55, 7
  %58 = mul nuw nsw i16 %56, 48
  %59 = getelementptr inbounds nuw i8, ptr @gate_chr, i16 %58
  %60 = getelementptr inbounds nuw [2 x i8], ptr %59, i16 %57
  %61 = load i16, ptr %60, align 1, !tbaa !2
  %62 = or i16 %61, 128
  store i16 %62, ptr %60, align 1, !tbaa !2
  %63 = add nuw nsw i8 %54, 1
  %64 = icmp eq i8 %54, 13
  br i1 %64, label %65, label %53, !llvm.loop !111

65:                                               ; preds = %53
  %66 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 22), align 1, !tbaa !2
  %67 = or i16 %66, 16
  store i16 %67, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 22), align 1, !tbaa !2
  %68 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 24), align 1, !tbaa !2
  %69 = or i16 %68, 4
  store i16 %69, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 24), align 1, !tbaa !2
  %70 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 26), align 1, !tbaa !2
  %71 = or i16 %70, 1
  store i16 %71, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 26), align 1, !tbaa !2
  %72 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 44), align 1, !tbaa !2
  %73 = or i16 %72, 64
  store i16 %73, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 44), align 1, !tbaa !2
  %74 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 46), align 1, !tbaa !2
  %75 = or i16 %74, 32
  store i16 %75, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 46), align 1, !tbaa !2
  %76 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 80), align 1, !tbaa !2
  %77 = or i16 %76, 32
  store i16 %77, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 80), align 1, !tbaa !2
  %78 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 82), align 1, !tbaa !2
  %79 = or i16 %78, 64
  store i16 %79, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 82), align 1, !tbaa !2
  %80 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 68), align 1, !tbaa !2
  %81 = or i16 %80, 1
  store i16 %81, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 68), align 1, !tbaa !2
  %82 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 70), align 1, !tbaa !2
  %83 = or i16 %82, 4
  store i16 %83, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 70), align 1, !tbaa !2
  %84 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 72), align 1, !tbaa !2
  %85 = or i16 %84, 16
  store i16 %85, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 72), align 1, !tbaa !2
  br label %86

86:                                               ; preds = %86, %65
  %87 = phi i8 [ 0, %65 ], [ %97, %86 ]
  %88 = zext nneg i8 %87 to i16
  %89 = and i16 %88, 7
  %90 = lshr exact i16 128, %89
  %91 = add nuw nsw i16 %88, 48
  %92 = and i16 %91, 120
  %93 = getelementptr inbounds nuw [2 x i8], ptr @gate_chr, i16 %92
  %94 = getelementptr inbounds nuw i8, ptr %93, i16 4
  %95 = load i16, ptr %94, align 1, !tbaa !2
  %96 = or i16 %90, %95
  store i16 %96, ptr %94, align 1, !tbaa !2
  %97 = add nuw nsw i8 %87, 1
  %98 = icmp eq i8 %87, 12
  br i1 %98, label %99, label %86, !llvm.loop !110

99:                                               ; preds = %86, %99
  %100 = phi i8 [ %110, %99 ], [ 0, %86 ]
  %101 = zext nneg i8 %100 to i16
  %102 = and i16 %101, 7
  %103 = lshr exact i16 128, %102
  %104 = add nuw nsw i16 %101, 72
  %105 = and i16 %104, 120
  %106 = getelementptr inbounds nuw [2 x i8], ptr @gate_chr, i16 %105
  %107 = getelementptr inbounds nuw i8, ptr %106, i16 10
  %108 = load i16, ptr %107, align 1, !tbaa !2
  %109 = or i16 %103, %108
  store i16 %109, ptr %107, align 1, !tbaa !2
  %110 = add nuw nsw i8 %100, 1
  %111 = icmp eq i8 %100, 12
  br i1 %111, label %112, label %99, !llvm.loop !110

112:                                              ; preds = %99
  %113 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 118), align 1, !tbaa !2
  %114 = or i16 %113, 4
  store i16 %114, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 118), align 1, !tbaa !2
  %115 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 120), align 1, !tbaa !2
  %116 = or i16 %115, 1
  store i16 %116, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 120), align 1, !tbaa !2
  %117 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 138), align 1, !tbaa !2
  %118 = or i16 %117, 64
  store i16 %118, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 138), align 1, !tbaa !2
  %119 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 140), align 1, !tbaa !2
  %120 = or i16 %119, 16
  store i16 %120, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 140), align 1, !tbaa !2
  %121 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 142), align 1, !tbaa !2
  %122 = or i16 %121, 8
  store i16 %122, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 142), align 1, !tbaa !2
  %123 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 176), align 1, !tbaa !2
  %124 = or i16 %123, 16
  store i16 %124, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 176), align 1, !tbaa !2
  %125 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 178), align 1, !tbaa !2
  %126 = or i16 %125, 64
  store i16 %126, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 178), align 1, !tbaa !2
  %127 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 164), align 1, !tbaa !2
  %128 = or i16 %127, 1
  store i16 %128, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 164), align 1, !tbaa !2
  %129 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 166), align 1, !tbaa !2
  %130 = or i16 %129, 4
  store i16 %130, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 166), align 1, !tbaa !2
  %131 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 104), align 1, !tbaa !2
  %132 = or i16 %131, 64
  store i16 %132, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 104), align 1, !tbaa !2
  %133 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 110), align 1, !tbaa !2
  %134 = or i16 %133, 32
  store i16 %134, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 110), align 1, !tbaa !2
  %135 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 144), align 1, !tbaa !2
  %136 = or i16 %135, 32
  store i16 %136, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 144), align 1, !tbaa !2
  %137 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 150), align 1, !tbaa !2
  %138 = or i16 %137, 64
  store i16 %138, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 150), align 1, !tbaa !2
  br label %139

139:                                              ; preds = %139, %112
  %140 = phi i8 [ 2, %112 ], [ %149, %139 ]
  %141 = zext nneg i8 %140 to i16
  %142 = and i16 %141, 7
  %143 = lshr exact i16 128, %142
  %144 = and i16 %141, 24
  %145 = getelementptr inbounds nuw [2 x i8], ptr @gate_chr, i16 %144
  %146 = getelementptr inbounds nuw i8, ptr %145, i16 196
  %147 = load i16, ptr %146, align 1, !tbaa !2
  %148 = or i16 %143, %147
  store i16 %148, ptr %146, align 1, !tbaa !2
  %149 = add nuw nsw i8 %140, 1
  %150 = icmp eq i8 %140, 12
  br i1 %150, label %151, label %139, !llvm.loop !110

151:                                              ; preds = %139, %151
  %152 = phi i8 [ %162, %151 ], [ 2, %139 ]
  %153 = zext nneg i8 %152 to i16
  %154 = and i16 %153, 7
  %155 = lshr exact i16 128, %154
  %156 = add nuw nsw i16 %153, 120
  %157 = and i16 %156, 248
  %158 = getelementptr inbounds nuw [2 x i8], ptr @gate_chr, i16 %157
  %159 = getelementptr inbounds nuw i8, ptr %158, i16 10
  %160 = load i16, ptr %159, align 1, !tbaa !2
  %161 = or i16 %155, %160
  store i16 %161, ptr %159, align 1, !tbaa !2
  %162 = add nuw nsw i8 %152, 1
  %163 = icmp eq i8 %152, 12
  br i1 %163, label %164, label %151, !llvm.loop !110

164:                                              ; preds = %151
  %165 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 214), align 1, !tbaa !2
  %166 = or i16 %165, 4
  store i16 %166, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 214), align 1, !tbaa !2
  %167 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 216), align 1, !tbaa !2
  %168 = or i16 %167, 1
  store i16 %168, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 216), align 1, !tbaa !2
  %169 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 234), align 1, !tbaa !2
  %170 = or i16 %169, 64
  store i16 %170, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 234), align 1, !tbaa !2
  %171 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 236), align 1, !tbaa !2
  %172 = or i16 %171, 16
  store i16 %172, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 236), align 1, !tbaa !2
  %173 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 238), align 1, !tbaa !2
  %174 = or i16 %173, 8
  store i16 %174, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 238), align 1, !tbaa !2
  %175 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 272), align 1, !tbaa !2
  %176 = or i16 %175, 16
  store i16 %176, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 272), align 1, !tbaa !2
  %177 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 274), align 1, !tbaa !2
  %178 = or i16 %177, 64
  store i16 %178, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 274), align 1, !tbaa !2
  %179 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 260), align 1, !tbaa !2
  %180 = or i16 %179, 1
  store i16 %180, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 260), align 1, !tbaa !2
  %181 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 262), align 1, !tbaa !2
  %182 = or i16 %181, 4
  store i16 %182, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 262), align 1, !tbaa !2
  %183 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 200), align 1, !tbaa !2
  %184 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 206), align 1, !tbaa !2
  %185 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 240), align 1, !tbaa !2
  %186 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 246), align 1, !tbaa !2
  %187 = or i16 %183, 144
  store i16 %187, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 200), align 1, !tbaa !2
  %188 = or i16 %184, 72
  store i16 %188, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 206), align 1, !tbaa !2
  %189 = or i16 %185, 72
  store i16 %189, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 240), align 1, !tbaa !2
  %190 = or i16 %186, 144
  store i16 %190, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 246), align 1, !tbaa !2
  br label %191

191:                                              ; preds = %340, %164
  %192 = phi i8 [ 3, %164 ], [ %341, %340 ]
  %193 = mul nuw nsw i8 %192, 6
  %194 = zext nneg i8 %193 to i16
  %195 = shl nuw nsw i16 %194, 3
  br label %281

196:                                              ; preds = %340, %196
  %197 = phi i8 [ %207, %196 ], [ 6, %340 ]
  %198 = zext nneg i8 %197 to i16
  %199 = and i16 %198, 7
  %200 = lshr exact i16 128, %199
  %201 = add nuw nsw i16 %198, 144
  %202 = and i16 %201, 184
  %203 = getelementptr inbounds nuw [2 x i8], ptr @gate_chr, i16 %202
  %204 = getelementptr inbounds nuw i8, ptr %203, i16 14
  %205 = load i16, ptr %204, align 1, !tbaa !2
  %206 = or i16 %200, %205
  store i16 %206, ptr %204, align 1, !tbaa !2
  %207 = add nuw nsw i8 %197, 1
  %208 = icmp eq i8 %197, 11
  br i1 %208, label %209, label %196, !llvm.loop !110

209:                                              ; preds = %196, %209
  %210 = phi i8 [ %220, %209 ], [ 5, %196 ]
  %211 = zext nneg i8 %210 to i16
  %212 = lshr i16 %211, 3
  %213 = and i16 %211, 7
  %214 = mul nuw nsw i16 %212, 48
  %215 = getelementptr inbounds nuw i8, ptr @gate_chr, i16 %214
  %216 = getelementptr inbounds nuw i8, ptr %215, i16 304
  %217 = getelementptr inbounds nuw [2 x i8], ptr %216, i16 %213
  %218 = load i16, ptr %217, align 1, !tbaa !2
  %219 = or i16 %218, 128
  store i16 %219, ptr %217, align 1, !tbaa !2
  %220 = add nuw nsw i8 %210, 1
  %221 = icmp eq i8 %210, 10
  br i1 %221, label %222, label %209, !llvm.loop !111

222:                                              ; preds = %209, %222
  %223 = phi i8 [ %232, %222 ], [ 6, %209 ]
  %224 = zext nneg i8 %223 to i16
  %225 = and i16 %224, 7
  %226 = lshr exact i16 128, %225
  %227 = and i16 %224, 24
  %228 = getelementptr inbounds nuw [2 x i8], ptr @gate_chr, i16 %227
  %229 = getelementptr inbounds nuw i8, ptr %228, i16 398
  %230 = load i16, ptr %229, align 1, !tbaa !2
  %231 = or i16 %226, %230
  store i16 %231, ptr %229, align 1, !tbaa !2
  %232 = add nuw nsw i8 %223, 1
  %233 = icmp eq i8 %223, 11
  br i1 %233, label %234, label %222, !llvm.loop !110

234:                                              ; preds = %222
  %235 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 506), align 1, !tbaa !2
  %236 = or i16 %235, 32
  store i16 %236, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 506), align 1, !tbaa !2
  %237 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 508), align 1, !tbaa !2
  %238 = or i16 %237, 128
  store i16 %238, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 508), align 1, !tbaa !2
  %239 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 494), align 1, !tbaa !2
  %240 = or i16 %239, 2
  store i16 %240, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 494), align 1, !tbaa !2
  %241 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 544), align 1, !tbaa !2
  %242 = or i16 %241, 128
  store i16 %242, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 544), align 1, !tbaa !2
  %243 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 546), align 1, !tbaa !2
  %244 = or i16 %243, 32
  store i16 %244, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 546), align 1, !tbaa !2
  %245 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 586), align 1, !tbaa !2
  %246 = or i16 %245, 1
  store i16 %246, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 586), align 1, !tbaa !2
  %247 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 604), align 1, !tbaa !2
  %248 = or i16 %247, 64
  store i16 %248, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 604), align 1, !tbaa !2
  %249 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 606), align 1, !tbaa !2
  %250 = or i16 %249, 16
  store i16 %250, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 606), align 1, !tbaa !2
  %251 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 640), align 1, !tbaa !2
  %252 = or i16 %251, 64
  store i16 %252, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 640), align 1, !tbaa !2
  %253 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 626), align 1, !tbaa !2
  %254 = or i16 %253, 1
  store i16 %254, ptr getelementptr inbounds nuw (i8, ptr @gate_chr, i16 626), align 1, !tbaa !2
  br label %255

255:                                              ; preds = %255, %234
  %256 = phi i8 [ 6, %234 ], [ %266, %255 ]
  %257 = zext nneg i8 %256 to i16
  %258 = and i16 %257, 7
  %259 = lshr exact i16 128, %258
  %260 = add nuw nsw i16 %257, 336
  %261 = and i16 %260, 376
  %262 = getelementptr inbounds nuw [2 x i8], ptr @gate_chr, i16 %261
  %263 = getelementptr inbounds nuw i8, ptr %262, i16 10
  %264 = load i16, ptr %263, align 1, !tbaa !2
  %265 = or i16 %259, %264
  store i16 %265, ptr %263, align 1, !tbaa !2
  %266 = add nuw nsw i8 %256, 1
  %267 = icmp eq i8 %256, 11
  br i1 %267, label %268, label %255, !llvm.loop !110

268:                                              ; preds = %255, %268
  %269 = phi i8 [ %279, %268 ], [ 6, %255 ]
  %270 = zext nneg i8 %269 to i16
  %271 = and i16 %270, 7
  %272 = lshr exact i16 128, %271
  %273 = add nuw nsw i16 %270, 360
  %274 = and i16 %273, 504
  %275 = getelementptr inbounds nuw [2 x i8], ptr @gate_chr, i16 %274
  %276 = getelementptr inbounds nuw i8, ptr %275, i16 2
  %277 = load i16, ptr %276, align 1, !tbaa !2
  %278 = or i16 %272, %277
  store i16 %278, ptr %276, align 1, !tbaa !2
  %279 = add nuw nsw i8 %269, 1
  %280 = icmp eq i8 %269, 11
  br i1 %280, label %343, label %268, !llvm.loop !110

281:                                              ; preds = %281, %191
  %282 = phi i8 [ %292, %281 ], [ 0, %191 ]
  %283 = zext nneg i8 %282 to i16
  %284 = and i16 %283, 7
  %285 = lshr exact i16 128, %284
  %286 = add nuw nsw i16 %195, %283
  %287 = and i16 %286, 1016
  %288 = getelementptr inbounds nuw [2 x i8], ptr @gate_chr, i16 %287
  %289 = getelementptr inbounds nuw i8, ptr %288, i16 4
  %290 = load i16, ptr %289, align 1, !tbaa !2
  %291 = or i16 %285, %290
  store i16 %291, ptr %289, align 1, !tbaa !2
  %292 = add nuw nsw i8 %282, 1
  %293 = icmp eq i8 %282, 17
  br i1 %293, label %294, label %281, !llvm.loop !110

294:                                              ; preds = %281
  %295 = add nuw nsw i8 %193, 3
  %296 = zext nneg i8 %295 to i16
  %297 = shl nuw nsw i16 %296, 3
  br label %298

298:                                              ; preds = %298, %294
  %299 = phi i8 [ %309, %298 ], [ 0, %294 ]
  %300 = zext nneg i8 %299 to i16
  %301 = and i16 %300, 7
  %302 = lshr exact i16 128, %301
  %303 = add nuw nsw i16 %297, %300
  %304 = and i16 %303, 2040
  %305 = getelementptr inbounds nuw [2 x i8], ptr @gate_chr, i16 %304
  %306 = getelementptr inbounds nuw i8, ptr %305, i16 10
  %307 = load i16, ptr %306, align 1, !tbaa !2
  %308 = or i16 %302, %307
  store i16 %308, ptr %306, align 1, !tbaa !2
  %309 = add nuw nsw i8 %299, 1
  %310 = icmp eq i8 %299, 17
  br i1 %310, label %311, label %298, !llvm.loop !110

311:                                              ; preds = %298, %311
  %312 = phi i8 [ %323, %311 ], [ 2, %298 ]
  %313 = zext nneg i8 %312 to i16
  %314 = lshr i16 %313, 3
  %315 = mul nuw nsw i16 %314, 3
  %316 = add nuw nsw i16 %315, %194
  %317 = and i16 %313, 7
  %318 = shl nuw nsw i16 %316, 4
  %319 = getelementptr inbounds nuw i8, ptr @gate_chr, i16 %318
  %320 = getelementptr inbounds nuw [2 x i8], ptr %319, i16 %317
  %321 = load i16, ptr %320, align 1, !tbaa !2
  %322 = or i16 %321, 128
  store i16 %322, ptr %320, align 1, !tbaa !2
  %323 = add nuw nsw i8 %312, 1
  %324 = icmp eq i8 %312, 13
  br i1 %324, label %325, label %311, !llvm.loop !111

325:                                              ; preds = %311, %325
  %326 = phi i8 [ %338, %325 ], [ 2, %311 ]
  %327 = zext nneg i8 %326 to i16
  %328 = lshr i16 %327, 3
  %329 = mul nuw nsw i16 %328, 3
  %330 = add nuw nsw i16 %329, %194
  %331 = and i16 %327, 7
  %332 = shl nuw nsw i16 %330, 4
  %333 = getelementptr inbounds nuw i8, ptr @gate_chr, i16 %332
  %334 = getelementptr inbounds nuw i8, ptr %333, i16 32
  %335 = getelementptr inbounds nuw [2 x i8], ptr %334, i16 %331
  %336 = load i16, ptr %335, align 1, !tbaa !2
  %337 = or i16 %336, 64
  store i16 %337, ptr %335, align 1, !tbaa !2
  %338 = add nuw nsw i8 %326, 1
  %339 = icmp eq i8 %326, 13
  br i1 %339, label %340, label %325, !llvm.loop !111

340:                                              ; preds = %325
  %341 = add nuw nsw i8 %192, 1
  %342 = icmp eq i8 %341, 8
  br i1 %342, label %196, label %191, !llvm.loop !112

343:                                              ; preds = %268
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 2560, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %354

344:                                              ; preds = %17, %344
  %345 = phi i8 [ 0, %17 ], [ %352, %344 ]
  %346 = phi i8 [ 0, %17 ], [ %350, %344 ]
  %347 = zext nneg i8 %345 to i16
  %348 = getelementptr i8, ptr @GLYPH_DOLLAR, i16 %347
  %349 = load i16, ptr %348, align 1, !tbaa !2
  store volatile i16 %349, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %350 = add nuw nsw i8 %346, 1
  %351 = icmp eq i8 %350, 8
  %352 = add nuw nsw i8 %345, 2
  br i1 %351, label %27, label %344, !llvm.loop !113

353:                                              ; preds = %354
  store volatile i8 0, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  br label %361

354:                                              ; preds = %343, %354
  %355 = phi i16 [ 0, %343 ], [ %358, %354 ]
  %356 = getelementptr inbounds nuw [2 x i8], ptr @gate_chr, i16 %355
  %357 = load i16, ptr %356, align 1, !tbaa !2
  store volatile i16 %357, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %358 = add nuw nsw i16 %355, 1
  %359 = icmp eq i16 %358, 384
  br i1 %359, label %353, label %354, !llvm.loop !114

360:                                              ; preds = %361
  ret void

361:                                              ; preds = %353, %361
  %362 = phi i8 [ 0, %353 ], [ %372, %361 ]
  %363 = phi i8 [ 0, %353 ], [ %370, %361 ]
  %364 = zext nneg i8 %362 to i16
  %365 = getelementptr i8, ptr @cgram, i16 %364
  %366 = load i16, ptr %365, align 1, !tbaa !2
  %367 = trunc i16 %366 to i8
  store volatile i8 %367, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  %368 = lshr i16 %366, 8
  %369 = trunc nuw i16 %368 to i8
  store volatile i8 %369, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  %370 = add nuw nsw i8 %363, 1
  %371 = icmp eq i8 %370, 16
  %372 = add nuw nsw i8 %362, 2
  br i1 %371, label %360, label %361, !llvm.loop !115
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal void @_tg_emit(ptr noundef %0, ptr noundef captures(none) %1) #5 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 1795
  %4 = load i8, ptr %3, align 1, !tbaa !21
  %5 = icmp eq i8 %4, 0
  br i1 %5, label %24, label %6

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %8 = load i8, ptr %7, align 1, !tbaa !76
  %9 = icmp ugt i8 %8, 15
  br i1 %9, label %23, label %10

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %12 = zext nneg i8 %8 to i16
  %13 = add nuw nsw i8 %8, 1
  store i8 %13, ptr %7, align 1, !tbaa !76
  %14 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %12
  %15 = getelementptr inbounds nuw i8, ptr %14, i16 10
  store i8 0, ptr %15, align 1, !tbaa !77
  store i16 16384, ptr %14, align 1, !tbaa !79
  %16 = getelementptr inbounds nuw i8, ptr %14, i16 9
  store i8 -128, ptr %16, align 1, !tbaa !80
  %17 = getelementptr inbounds nuw i8, ptr %14, i16 7
  store i8 24, ptr %17, align 1, !tbaa !81
  %18 = getelementptr inbounds nuw i8, ptr %14, i16 8
  store i8 1, ptr %18, align 1, !tbaa !82
  %19 = ptrtoint ptr %11 to i16
  %20 = getelementptr inbounds nuw i8, ptr %14, i16 2
  store i16 %19, ptr %20, align 1, !tbaa !83
  %21 = getelementptr inbounds nuw i8, ptr %14, i16 6
  store i8 0, ptr %21, align 1, !tbaa !84
  %22 = getelementptr inbounds nuw i8, ptr %14, i16 4
  store i16 1792, ptr %22, align 1, !tbaa !85
  br label %23

23:                                               ; preds = %6, %10
  store i8 0, ptr %3, align 1, !tbaa !21
  br label %24

24:                                               ; preds = %2, %23
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_title_reserve(ptr noundef %0, ptr readnone captures(none) %1) #4 {
  store volatile i8 80, ptr inttoptr (i16 8456 to ptr), align 8, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !6
  store volatile i8 112, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -1, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 127, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -124, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 4096, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %3

3:                                                ; preds = %2, %16
  %4 = phi ptr [ @FONT8, %2 ], [ %18, %16 ]
  %5 = phi i16 [ 0, %2 ], [ %17, %16 ]
  br label %7

6:                                                ; preds = %16
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 5120, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %24

7:                                                ; preds = %3, %7
  %8 = phi i8 [ 0, %3 ], [ %15, %7 ]
  %9 = phi i8 [ 0, %3 ], [ %13, %7 ]
  %10 = zext nneg i8 %8 to i16
  %11 = getelementptr i8, ptr %4, i16 %10
  %12 = load i16, ptr %11, align 1, !tbaa !2
  store volatile i16 %12, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %13 = add nuw nsw i8 %9, 1
  %14 = icmp eq i8 %13, 8
  %15 = add nuw nsw i8 %8, 2
  br i1 %14, label %20, label %7, !llvm.loop !116

16:                                               ; preds = %20
  %17 = add nuw nsw i16 %5, 1
  %18 = getelementptr i8, ptr %4, i16 16
  %19 = icmp eq i16 %17, 64
  br i1 %19, label %6, label %3, !llvm.loop !117

20:                                               ; preds = %7, %20
  %21 = phi i8 [ %22, %20 ], [ 0, %7 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %22 = add nuw nsw i8 %21, 1
  %23 = icmp eq i8 %22, 8
  br i1 %23, label %16, label %20, !llvm.loop !118

24:                                               ; preds = %6, %33
  %25 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 16), %6 ], [ %36, %33 ]
  %26 = phi ptr [ @FONT16, %6 ], [ %35, %33 ]
  %27 = phi i16 [ 0, %6 ], [ %34, %33 ]
  br label %29

28:                                               ; preds = %33
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 20480, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %66

29:                                               ; preds = %24, %47
  %30 = phi i8 [ 0, %24 ], [ %52, %47 ]
  %31 = phi ptr [ %26, %24 ], [ %50, %47 ]
  %32 = phi i8 [ 0, %24 ], [ %48, %47 ]
  br label %38

33:                                               ; preds = %47
  %34 = add nuw nsw i16 %27, 1
  %35 = getelementptr i8, ptr %26, i16 64
  %36 = getelementptr i8, ptr %25, i16 64
  %37 = icmp eq i16 %34, 64
  br i1 %37, label %28, label %24, !llvm.loop !119

38:                                               ; preds = %29, %38
  %39 = phi i8 [ 0, %29 ], [ %46, %38 ]
  %40 = phi i8 [ 0, %29 ], [ %44, %38 ]
  %41 = zext nneg i8 %39 to i16
  %42 = getelementptr i8, ptr %31, i16 %41
  %43 = load i16, ptr %42, align 1, !tbaa !2
  store volatile i16 %43, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %44 = add nuw nsw i8 %40, 1
  %45 = icmp eq i8 %44, 8
  %46 = add nuw nsw i8 %39, 2
  br i1 %45, label %53, label %38, !llvm.loop !120

47:                                               ; preds = %53
  %48 = add nuw nsw i8 %32, 1
  %49 = zext nneg i8 %30 to i16
  %50 = getelementptr i8, ptr %25, i16 %49
  %51 = icmp eq i8 %48, 4
  %52 = add nuw nsw i8 %30, 16
  br i1 %51, label %33, label %29, !llvm.loop !121

53:                                               ; preds = %38, %53
  %54 = phi i8 [ %55, %53 ], [ 0, %38 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %55 = add nuw nsw i8 %54, 1
  %56 = icmp eq i8 %55, 8
  br i1 %56, label %47, label %53, !llvm.loop !122

57:                                               ; preds = %66
  %58 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %59 = load ptr, ptr %58, align 1, !tbaa !42
  %60 = icmp eq ptr %59, null
  br i1 %60, label %79, label %61

61:                                               ; preds = %57
  %62 = load i8, ptr %59, align 1, !tbaa !6
  %63 = icmp eq i8 %62, 0
  br i1 %63, label %79, label %64

64:                                               ; preds = %61
  %65 = getelementptr i8, ptr %59, i16 1
  br label %70

66:                                               ; preds = %28, %66
  %67 = phi i16 [ 0, %28 ], [ %68, %66 ]
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %68 = add nuw nsw i16 %67, 1
  %69 = icmp eq i16 %68, 1024
  br i1 %69, label %57, label %66, !llvm.loop !123

70:                                               ; preds = %64, %70
  %71 = phi i8 [ %72, %70 ], [ 0, %64 ]
  %72 = add nuw nsw i8 %71, 1
  %73 = zext nneg i8 %71 to i16
  %74 = getelementptr i8, ptr %65, i16 %73
  %75 = load i8, ptr %74, align 1, !tbaa !6
  %76 = icmp ne i8 %75, 0
  %77 = icmp samesign ult i8 %71, 31
  %78 = select i1 %76, i1 %77, i1 false
  br i1 %78, label %70, label %79, !llvm.loop !124

79:                                               ; preds = %70, %61, %57
  %80 = phi i8 [ 0, %57 ], [ 0, %61 ], [ %72, %70 ]
  %81 = zext nneg i8 %80 to i16
  %82 = sub nuw nsw i16 32, %81
  %83 = lshr i16 %82, 1
  %84 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %85 = load i16, ptr %84, align 1, !tbaa !48
  %86 = shl i16 %85, 2
  %87 = and i16 %86, -32
  %88 = add i16 %87, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %88, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %89 = trunc nuw nsw i16 %83 to i8
  %90 = add nuw nsw i8 %80, %89
  %91 = sub nsw i16 0, %83
  %92 = getelementptr i8, ptr %59, i16 %91
  br label %105

93:                                               ; preds = %128
  %94 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %95 = load ptr, ptr %94, align 1, !tbaa !44
  %96 = getelementptr inbounds nuw i8, ptr %0, i16 11
  %97 = load i8, ptr %96, align 1, !tbaa !45
  %98 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %99 = load i16, ptr %98, align 1, !tbaa !49
  %100 = lshr i16 %99, 3
  %101 = trunc i16 %100 to i8
  tail call fastcc void @_title_write16(ptr noundef %95, i8 noundef zeroext %97, i8 noundef zeroext %101) #15
  %102 = getelementptr inbounds nuw i8, ptr %0, i16 9
  %103 = load ptr, ptr %102, align 1, !tbaa !46
  %104 = icmp eq ptr %103, null
  br i1 %104, label %139, label %132

105:                                              ; preds = %79, %128
  %106 = phi i8 [ 0, %79 ], [ %130, %128 ]
  %107 = zext nneg i8 %106 to i16
  br i1 %60, label %128, label %108

108:                                              ; preds = %105
  %109 = icmp samesign ugt i16 %83, %107
  br i1 %109, label %128, label %110

110:                                              ; preds = %108
  %111 = icmp ult i8 %106, %90
  br i1 %111, label %112, label %128

112:                                              ; preds = %110
  %113 = getelementptr i8, ptr %92, i16 %107
  %114 = load i8, ptr %113, align 1, !tbaa !6
  %115 = icmp ugt i8 %114, 96
  br i1 %115, label %116, label %120

116:                                              ; preds = %112
  %117 = icmp ult i8 %114, 123
  br i1 %117, label %118, label %128

118:                                              ; preds = %116
  %119 = add nsw i8 %114, -32
  br label %124

120:                                              ; preds = %112
  %121 = icmp samesign ugt i8 %114, 31
  br i1 %121, label %122, label %128

122:                                              ; preds = %120
  %123 = icmp eq i8 %114, 96
  br i1 %123, label %128, label %124

124:                                              ; preds = %122, %118
  %125 = phi i8 [ %119, %118 ], [ %114, %122 ]
  %126 = zext nneg i8 %125 to i16
  %127 = add nuw nsw i16 %126, 7136
  br label %128

128:                                              ; preds = %124, %122, %120, %116, %105, %108, %110
  %129 = phi i16 [ 7168, %105 ], [ 7168, %110 ], [ 7168, %108 ], [ %127, %124 ], [ 7168, %122 ], [ 7168, %120 ], [ 7168, %116 ]
  store volatile i16 %129, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %130 = add nuw nsw i8 %106, 1
  %131 = icmp eq i8 %130, 32
  br i1 %131, label %93, label %105, !llvm.loop !125

132:                                              ; preds = %93
  %133 = getelementptr inbounds nuw i8, ptr %0, i16 12
  %134 = load i8, ptr %133, align 1, !tbaa !47
  %135 = load i16, ptr %98, align 1, !tbaa !49
  %136 = lshr i16 %135, 3
  %137 = trunc i16 %136 to i8
  %138 = add i8 %137, 2
  tail call fastcc void @_title_write16(ptr noundef nonnull %103, i8 noundef zeroext %134, i8 noundef zeroext %138) #15
  br label %139

139:                                              ; preds = %132, %93
  %140 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 -128, ptr %140, align 1, !tbaa !74
  %141 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 3584, ptr %141, align 1, !tbaa !126
  %142 = getelementptr inbounds nuw i8, ptr %0, i16 23
  store i16 0, ptr %142, align 1, !tbaa !127
  %143 = load ptr, ptr %58, align 1, !tbaa !42
  %144 = icmp eq ptr %143, null
  br i1 %144, label %167, label %145

145:                                              ; preds = %139
  %146 = load i8, ptr %143, align 1, !tbaa !6
  %147 = icmp eq i8 %146, 0
  br i1 %147, label %150, label %148

148:                                              ; preds = %145
  %149 = getelementptr i8, ptr %143, i16 1
  br label %158

150:                                              ; preds = %158, %145
  %151 = phi i8 [ 0, %145 ], [ %160, %158 ]
  %152 = zext nneg i8 %151 to i16
  %153 = shl nuw nsw i16 %152, 2
  %154 = sub nuw nsw i16 128, %153
  %155 = and i16 %154, 248
  %156 = add nsw i16 %153, -128
  %157 = add nsw i16 %156, %155
  br label %167

158:                                              ; preds = %158, %148
  %159 = phi i8 [ %160, %158 ], [ 0, %148 ]
  %160 = add nuw nsw i8 %159, 1
  %161 = zext nneg i8 %159 to i16
  %162 = getelementptr i8, ptr %149, i16 %161
  %163 = load i8, ptr %162, align 1, !tbaa !6
  %164 = icmp ne i8 %163, 0
  %165 = icmp samesign ult i8 %159, 31
  %166 = select i1 %164, i1 %165, i1 false
  br i1 %166, label %158, label %150, !llvm.loop !128

167:                                              ; preds = %139, %150
  %168 = phi i16 [ %157, %150 ], [ 0, %139 ]
  %169 = getelementptr inbounds nuw i8, ptr %0, i16 26
  store i16 %168, ptr %169, align 1, !tbaa !129
  store volatile i8 -112, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  %170 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %171 = getelementptr inbounds nuw i8, ptr %0, i16 89
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef -8, i16 noundef 224, ptr noundef nonnull %170, ptr noundef nonnull %171) #15
  %172 = getelementptr inbounds nuw i8, ptr %0, i16 88
  store i8 0, ptr %172, align 1, !tbaa !130
  store volatile i8 2, ptr inttoptr (i16 17200 to ptr), align 16, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 17201 to ptr), align 1, !tbaa !6
  %173 = ptrtoint ptr %170 to i16
  %174 = trunc i16 %173 to i8
  store volatile i8 %174, ptr inttoptr (i16 17202 to ptr), align 2, !tbaa !6
  %175 = lshr i16 %173, 8
  %176 = trunc nuw i16 %175 to i8
  store volatile i8 %176, ptr inttoptr (i16 17203 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17204 to ptr), align 4, !tbaa !6
  %177 = getelementptr inbounds nuw i8, ptr %0, i16 139
  store i8 0, ptr %177, align 1, !tbaa !130
  store volatile i8 2, ptr inttoptr (i16 17216 to ptr), align 64, !tbaa !6
  store volatile i8 15, ptr inttoptr (i16 17217 to ptr), align 1, !tbaa !6
  %178 = ptrtoint ptr %171 to i16
  %179 = trunc i16 %178 to i8
  store volatile i8 %179, ptr inttoptr (i16 17218 to ptr), align 2, !tbaa !6
  %180 = lshr i16 %178, 8
  %181 = trunc nuw i16 %180 to i8
  store volatile i8 %181, ptr inttoptr (i16 17219 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17220 to ptr), align 4, !tbaa !6
  %182 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 2, ptr %182, align 1, !tbaa !41
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal void @_title_emit(ptr noundef %0, ptr noundef captures(none) %1) #6 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 29
  %4 = load i8, ptr %3, align 1, !tbaa !52
  %5 = icmp eq i8 %4, 0
  br i1 %5, label %188, label %6

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 30
  %8 = load i8, ptr %7, align 1, !tbaa !55
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %39, label %10

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 25
  %12 = load i8, ptr %11, align 1, !tbaa !56
  %13 = icmp ugt i8 %12, -6
  br i1 %13, label %16, label %14

14:                                               ; preds = %10
  %15 = add nuw i8 %12, 4
  br label %16

16:                                               ; preds = %10, %14
  %17 = phi i8 [ %15, %14 ], [ -1, %10 ]
  store i8 %17, ptr %11, align 1, !tbaa !56
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %19 = load i16, ptr %18, align 1, !tbaa !48
  %20 = xor i8 %17, -1
  %21 = zext i8 %20 to i16
  %22 = mul nuw i16 %21, %21
  %23 = lshr i16 %22, 8
  %24 = sub nuw nsw i16 256, %23
  %25 = add nsw i16 %19, 8
  %26 = mul nsw i16 %24, %25
  %27 = ashr i16 %26, 4
  %28 = and i16 %27, -16
  %29 = add nsw i16 %28, -128
  %30 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 %29, ptr %30, align 1, !tbaa !74
  %31 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %32 = load i16, ptr %31, align 1, !tbaa !49
  %33 = add nsw i16 %32, -224
  %34 = mul nsw i16 %33, %24
  %35 = ashr i16 %34, 4
  %36 = and i16 %35, -16
  %37 = add nsw i16 %36, 3584
  %38 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 %37, ptr %38, align 1, !tbaa !126
  br label %64

39:                                               ; preds = %6
  %40 = getelementptr inbounds nuw i8, ptr %0, i16 31
  %41 = load i8, ptr %40, align 1, !tbaa !53
  %42 = icmp eq i8 %41, 0
  br i1 %42, label %43, label %48

43:                                               ; preds = %39
  %44 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %45 = load i16, ptr %44, align 1, !tbaa !74
  %46 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %47 = load i16, ptr %46, align 1, !tbaa !126
  br label %64

48:                                               ; preds = %39
  %49 = getelementptr inbounds nuw i8, ptr %0, i16 23
  %50 = load i16, ptr %49, align 1, !tbaa !127
  %51 = add nsw i16 %50, 2
  store i16 %51, ptr %49, align 1, !tbaa !127
  %52 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %53 = load i16, ptr %52, align 1, !tbaa !74
  %54 = add nsw i16 %53, %51
  store i16 %54, ptr %52, align 1, !tbaa !74
  %55 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %56 = load i16, ptr %55, align 1, !tbaa !126
  %57 = add nsw i16 %56, %51
  store i16 %57, ptr %55, align 1, !tbaa !126
  %58 = icmp sgt i16 %54, 4480
  br i1 %58, label %59, label %60

59:                                               ; preds = %48
  store i16 4480, ptr %52, align 1, !tbaa !74
  br label %60

60:                                               ; preds = %59, %48
  %61 = phi i16 [ 4480, %59 ], [ %54, %48 ]
  %62 = icmp sgt i16 %57, 4736
  br i1 %62, label %63, label %64

63:                                               ; preds = %60
  store i16 4736, ptr %55, align 1, !tbaa !126
  br label %64

64:                                               ; preds = %43, %63, %60, %16
  %65 = phi i16 [ %47, %43 ], [ 4736, %63 ], [ %57, %60 ], [ %37, %16 ]
  %66 = phi i16 [ %45, %43 ], [ %61, %63 ], [ %61, %60 ], [ %29, %16 ]
  %67 = ashr i16 %66, 4
  %68 = ashr i16 %65, 4
  %69 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %70 = getelementptr inbounds nuw i8, ptr %0, i16 88
  %71 = load i8, ptr %70, align 1, !tbaa !130
  %72 = xor i8 %71, 1
  %73 = zext i8 %72 to i16
  %74 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %73
  %75 = getelementptr inbounds nuw i8, ptr %0, i16 89
  %76 = getelementptr inbounds nuw i8, ptr %0, i16 139
  %77 = load i8, ptr %76, align 1, !tbaa !130
  %78 = xor i8 %77, 1
  %79 = zext i8 %78 to i16
  %80 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %79
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef %67, i16 noundef %68, ptr noundef nonnull %74, ptr noundef nonnull %80) #15
  %81 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %82 = load i8, ptr %81, align 1, !tbaa !76
  %83 = icmp ugt i8 %82, 15
  br i1 %83, label %109, label %84

84:                                               ; preds = %64
  %85 = load i8, ptr %70, align 1, !tbaa !130
  %86 = xor i8 %85, 1
  %87 = zext i8 %86 to i16
  %88 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %87
  %89 = ptrtoint ptr %88 to i16
  %90 = zext nneg i8 %82 to i16
  %91 = add nuw nsw i8 %82, 1
  store i8 %91, ptr %81, align 1, !tbaa !76
  %92 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %90
  %93 = getelementptr inbounds nuw i8, ptr %92, i16 10
  store i8 4, ptr %93, align 1, !tbaa !77
  store i16 17202, ptr %92, align 1, !tbaa !79
  %94 = getelementptr inbounds nuw i8, ptr %92, i16 2
  store i16 %89, ptr %94, align 1, !tbaa !83
  %95 = getelementptr inbounds nuw i8, ptr %92, i16 4
  store i16 0, ptr %95, align 1, !tbaa !85
  store i8 %86, ptr %70, align 1, !tbaa !130
  %96 = icmp eq i8 %82, 15
  br i1 %96, label %109, label %97

97:                                               ; preds = %84
  %98 = load i8, ptr %76, align 1, !tbaa !130
  %99 = xor i8 %98, 1
  %100 = zext i8 %99 to i16
  %101 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %100
  %102 = ptrtoint ptr %101 to i16
  %103 = zext nneg i8 %91 to i16
  %104 = add nuw nsw i8 %82, 2
  store i8 %104, ptr %81, align 1, !tbaa !76
  %105 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %103
  %106 = getelementptr inbounds nuw i8, ptr %105, i16 10
  store i8 4, ptr %106, align 1, !tbaa !77
  store i16 17218, ptr %105, align 1, !tbaa !79
  %107 = getelementptr inbounds nuw i8, ptr %105, i16 2
  store i16 %102, ptr %107, align 1, !tbaa !83
  %108 = getelementptr inbounds nuw i8, ptr %105, i16 4
  store i16 0, ptr %108, align 1, !tbaa !85
  store i8 %99, ptr %76, align 1, !tbaa !130
  br label %109

109:                                              ; preds = %64, %84, %97
  %110 = phi i8 [ %82, %64 ], [ 16, %84 ], [ %104, %97 ]
  %111 = getelementptr inbounds nuw i8, ptr %0, i16 28
  %112 = load i8, ptr %111, align 1, !tbaa !51
  %113 = add i8 %112, 1
  store i8 %113, ptr %111, align 1, !tbaa !51
  %114 = getelementptr inbounds nuw i8, ptr %0, i16 32
  %115 = load i8, ptr %114, align 1, !tbaa !54
  %116 = icmp eq i8 %115, 0
  br i1 %116, label %117, label %155

117:                                              ; preds = %109
  %118 = shl i8 %113, 1
  %119 = icmp sgt i8 %118, -1
  br i1 %119, label %122, label %120

120:                                              ; preds = %117
  %121 = xor i8 %118, -1
  br label %122

122:                                              ; preds = %117, %120
  %123 = phi i8 [ %121, %120 ], [ %118, %117 ]
  %124 = lshr i8 %123, 4
  %125 = add nuw nsw i8 %124, 24
  %126 = zext nneg i8 %125 to i16
  %127 = mul nuw nsw i16 %126, 1057
  %128 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 %127, ptr %128, align 1, !tbaa !57
  %129 = add i8 %118, -86
  %130 = icmp sgt i8 %129, -1
  br i1 %130, label %133, label %131

131:                                              ; preds = %122
  %132 = sub nsw i8 85, %118
  br label %133

133:                                              ; preds = %122, %131
  %134 = phi i8 [ %132, %131 ], [ %129, %122 ]
  %135 = lshr i8 %134, 2
  %136 = zext nneg i8 %135 to i16
  %137 = shl nuw nsw i16 %136, 10
  %138 = add i8 %118, 85
  %139 = icmp sgt i8 %138, -1
  br i1 %139, label %142, label %140

140:                                              ; preds = %133
  %141 = sub nuw i8 -86, %118
  br label %142

142:                                              ; preds = %133, %140
  %143 = phi i8 [ %141, %140 ], [ %138, %133 ]
  %144 = lshr i8 %143, 2
  %145 = zext nneg i8 %144 to i16
  %146 = shl nuw nsw i16 %145, 5
  %147 = add nuw nsw i16 %146, %137
  br i1 %119, label %150, label %148

148:                                              ; preds = %142
  %149 = xor i8 %118, -1
  br label %150

150:                                              ; preds = %142, %148
  %151 = phi i8 [ %149, %148 ], [ %118, %142 ]
  %152 = lshr i8 %151, 2
  %153 = zext nneg i8 %152 to i16
  %154 = add nuw nsw i16 %147, %153
  br label %157

155:                                              ; preds = %109
  %156 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 29596, ptr %156, align 1, !tbaa !57
  br label %157

157:                                              ; preds = %155, %150
  %158 = phi i16 [ 0, %155 ], [ %154, %150 ]
  %159 = getelementptr inbounds nuw i8, ptr %0, i16 36
  store i16 %158, ptr %159, align 1, !tbaa !58
  %160 = icmp ugt i8 %110, 15
  br i1 %160, label %188, label %161

161:                                              ; preds = %157
  %162 = getelementptr inbounds nuw i8, ptr %0, i16 34
  %163 = zext nneg i8 %110 to i16
  %164 = add nuw nsw i8 %110, 1
  store i8 %164, ptr %81, align 1, !tbaa !76
  %165 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %163
  %166 = getelementptr inbounds nuw i8, ptr %165, i16 10
  store i8 1, ptr %166, align 1, !tbaa !77
  store i16 113, ptr %165, align 1, !tbaa !79
  %167 = getelementptr inbounds nuw i8, ptr %165, i16 9
  store i8 0, ptr %167, align 1, !tbaa !80
  %168 = getelementptr inbounds nuw i8, ptr %165, i16 7
  store i8 34, ptr %168, align 1, !tbaa !81
  %169 = getelementptr inbounds nuw i8, ptr %165, i16 8
  store i8 0, ptr %169, align 1, !tbaa !82
  %170 = ptrtoint ptr %162 to i16
  %171 = getelementptr inbounds nuw i8, ptr %165, i16 2
  store i16 %170, ptr %171, align 1, !tbaa !83
  %172 = getelementptr inbounds nuw i8, ptr %165, i16 6
  store i8 0, ptr %172, align 1, !tbaa !84
  %173 = getelementptr inbounds nuw i8, ptr %165, i16 4
  store i16 2, ptr %173, align 1, !tbaa !85
  %174 = icmp eq i8 %110, 15
  br i1 %174, label %188, label %175

175:                                              ; preds = %161
  %176 = getelementptr inbounds nuw i8, ptr %0, i16 36
  %177 = zext nneg i8 %164 to i16
  %178 = add nuw nsw i8 %110, 2
  store i8 %178, ptr %81, align 1, !tbaa !76
  %179 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %177
  %180 = getelementptr inbounds nuw i8, ptr %179, i16 10
  store i8 1, ptr %180, align 1, !tbaa !77
  store i16 0, ptr %179, align 1, !tbaa !79
  %181 = getelementptr inbounds nuw i8, ptr %179, i16 9
  store i8 0, ptr %181, align 1, !tbaa !80
  %182 = getelementptr inbounds nuw i8, ptr %179, i16 7
  store i8 34, ptr %182, align 1, !tbaa !81
  %183 = getelementptr inbounds nuw i8, ptr %179, i16 8
  store i8 0, ptr %183, align 1, !tbaa !82
  %184 = ptrtoint ptr %176 to i16
  %185 = getelementptr inbounds nuw i8, ptr %179, i16 2
  store i16 %184, ptr %185, align 1, !tbaa !83
  %186 = getelementptr inbounds nuw i8, ptr %179, i16 6
  store i8 0, ptr %186, align 1, !tbaa !84
  %187 = getelementptr inbounds nuw i8, ptr %179, i16 4
  store i16 2, ptr %187, align 1, !tbaa !85
  br label %188

188:                                              ; preds = %157, %175, %161, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @_title_write16(ptr noundef readonly captures(address_is_null) %0, i8 noundef zeroext %1, i8 noundef zeroext %2) unnamed_addr #4 {
  %4 = zext i8 %1 to i16
  %5 = shl nuw nsw i16 %4, 1
  %6 = and i16 %5, 254
  %7 = sub nsw i16 32, %6
  %8 = lshr exact i16 %7, 1
  %9 = zext i8 %2 to i16
  %10 = icmp eq ptr %0, null
  %11 = and i16 %8, 255
  %12 = add nuw i16 %8, %5
  %13 = and i16 %12, 255
  br label %15

14:                                               ; preds = %23
  ret void

15:                                               ; preds = %3, %23
  %16 = phi i1 [ true, %3 ], [ false, %23 ]
  %17 = phi i8 [ 0, %3 ], [ 1, %23 ]
  %18 = zext nneg i8 %17 to i16
  %19 = add nuw nsw i16 %18, %9
  %20 = shl nuw nsw i16 %19, 5
  %21 = add nuw nsw i16 %20, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %21, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %22 = select i1 %16, i16 7168, i16 7170
  br label %24

23:                                               ; preds = %56
  br i1 %16, label %15, label %14, !llvm.loop !131

24:                                               ; preds = %15, %56
  %25 = phi i8 [ 0, %15 ], [ %58, %56 ]
  %26 = zext nneg i8 %25 to i16
  br i1 %10, label %56, label %27

27:                                               ; preds = %24
  %28 = icmp samesign ugt i16 %11, %26
  br i1 %28, label %56, label %29

29:                                               ; preds = %27
  %30 = icmp samesign ugt i16 %13, %26
  br i1 %30, label %31, label %56

31:                                               ; preds = %29
  %32 = sub nsw i16 %26, %11
  %33 = lshr i16 %32, 1
  %34 = and i16 %33, 255
  %35 = getelementptr inbounds nuw i8, ptr %0, i16 %34
  %36 = load i8, ptr %35, align 1, !tbaa !6
  %37 = icmp ugt i8 %36, 96
  br i1 %37, label %38, label %42

38:                                               ; preds = %31
  %39 = icmp ult i8 %36, 123
  br i1 %39, label %40, label %51

40:                                               ; preds = %38
  %41 = add nsw i8 %36, -32
  br label %46

42:                                               ; preds = %31
  %43 = icmp samesign ugt i8 %36, 31
  br i1 %43, label %44, label %51

44:                                               ; preds = %42
  %45 = icmp eq i8 %36, 96
  br i1 %45, label %51, label %46

46:                                               ; preds = %44, %40
  %47 = phi i8 [ %41, %40 ], [ %36, %44 ]
  %48 = zext nneg i8 %47 to i16
  %49 = shl nuw nsw i16 %48, 2
  %50 = add nsw i16 %49, -64
  br label %51

51:                                               ; preds = %38, %42, %44, %46
  %52 = phi i16 [ %50, %46 ], [ 64, %44 ], [ 64, %42 ], [ 64, %38 ]
  %53 = and i16 %32, 1
  %54 = or disjoint i16 %22, %53
  %55 = or disjoint i16 %54, %52
  br label %56

56:                                               ; preds = %51, %29, %27, %24
  %57 = phi i16 [ %55, %51 ], [ 7168, %29 ], [ 7168, %27 ], [ 7168, %24 ]
  store volatile i16 %57, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %58 = add nuw nsw i8 %25, 1
  %59 = icmp eq i8 %58, 32
  br i1 %59, label %23, label %24, !llvm.loop !132
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_build(ptr noundef readonly captures(none) %0, i16 noundef range(i16 -2048, 2048) %1, i16 noundef range(i16 -2048, 2048) %2, ptr noundef %3, ptr noundef %4) unnamed_addr #6 {
  %6 = alloca %struct.HScrollW, align 1
  %7 = alloca %struct.HScrollW, align 1
  %8 = alloca i16, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #16
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #16
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #16
  store i16 0, ptr %8, align 1, !tbaa !2
  store ptr %3, ptr %6, align 1, !tbaa !133
  %9 = getelementptr inbounds nuw i8, ptr %6, i16 2
  store i8 0, ptr %9, align 1, !tbaa !135
  store ptr %4, ptr %7, align 1, !tbaa !133
  %10 = getelementptr inbounds nuw i8, ptr %7, i16 2
  store i8 0, ptr %10, align 1, !tbaa !135
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %12 = load i16, ptr %11, align 1, !tbaa !48
  %13 = getelementptr inbounds nuw i8, ptr %0, i16 26
  %14 = load i16, ptr %13, align 1, !tbaa !129
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %1, i16 noundef 8, i16 noundef %12, i16 noundef %14) #15
  %15 = getelementptr inbounds nuw i8, ptr %0, i16 17
  %16 = load i16, ptr %15, align 1, !tbaa !50
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %18 = load i16, ptr %17, align 1, !tbaa !49
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %2, i16 noundef %16, i16 noundef %18, i16 noundef 0) #15
  %19 = load i16, ptr %8, align 1, !tbaa !2
  call fastcc void @_title_blank(ptr noundef %6, ptr noundef %7, i16 noundef %19, i16 noundef 224) #15
  %20 = load ptr, ptr %6, align 1, !tbaa !133
  %21 = load i8, ptr %9, align 1, !tbaa !135
  %22 = zext i8 %21 to i16
  %23 = getelementptr inbounds nuw i8, ptr %20, i16 %22
  store i8 0, ptr %23, align 1, !tbaa !6
  %24 = load ptr, ptr %7, align 1, !tbaa !133
  %25 = load i8, ptr %10, align 1, !tbaa !135
  %26 = zext i8 %25 to i16
  %27 = getelementptr inbounds nuw i8, ptr %24, i16 %26
  store i8 0, ptr %27, align 1, !tbaa !6
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #16
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #16
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #16
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_glyph_band(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, ptr noundef nonnull captures(none) %2, i16 noundef range(i16 -2048, 2048) %3, i16 noundef %4, i16 noundef %5, i16 noundef %6) unnamed_addr #6 {
  %8 = add nsw i16 %3, -2
  %9 = add nsw i16 %4, %3
  %10 = add nsw i16 %9, 2
  %11 = load i16, ptr %2, align 1, !tbaa !2
  %12 = icmp slt i16 %8, %11
  br i1 %12, label %13, label %14

13:                                               ; preds = %7
  br label %14

14:                                               ; preds = %13, %7
  %15 = phi i16 [ %11, %13 ], [ %8, %7 ]
  %16 = icmp sgt i16 %9, 222
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  br label %18

18:                                               ; preds = %17, %14
  %19 = phi i16 [ 224, %17 ], [ %10, %14 ]
  %20 = icmp sgt i16 %19, %15
  br i1 %20, label %21, label %92

21:                                               ; preds = %18
  tail call fastcc void @_title_blank(ptr noundef %0, ptr noundef %1, i16 noundef %11, i16 noundef %15) #15
  %22 = sub nsw i16 %19, %15
  %23 = trunc i16 %22 to i8
  %24 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %25 = icmp eq i8 %23, 0
  br i1 %25, label %91, label %26

26:                                               ; preds = %21
  %27 = sub nsw i16 %5, %3
  %28 = and i16 %22, 255
  %29 = trunc i16 %27 to i8
  %30 = lshr i16 %27, 8
  %31 = trunc nuw i16 %30 to i8
  br label %32

32:                                               ; preds = %40, %26
  %33 = phi i16 [ %28, %26 ], [ %57, %40 ]
  %34 = load i8, ptr %24, align 1, !tbaa !135
  %35 = icmp ult i8 %34, 22
  br i1 %35, label %36, label %59

36:                                               ; preds = %32
  %37 = icmp ugt i16 %33, 127
  br i1 %37, label %40, label %38

38:                                               ; preds = %36
  %39 = trunc nuw nsw i16 %33 to i8
  br label %40

40:                                               ; preds = %38, %36
  %41 = phi i8 [ %39, %38 ], [ 127, %36 ]
  %42 = load ptr, ptr %0, align 1, !tbaa !133
  %43 = add nuw nsw i8 %34, 1
  store i8 %43, ptr %24, align 1, !tbaa !135
  %44 = zext nneg i8 %34 to i16
  %45 = getelementptr inbounds nuw i8, ptr %42, i16 %44
  store i8 %41, ptr %45, align 1, !tbaa !6
  %46 = load ptr, ptr %0, align 1, !tbaa !133
  %47 = load i8, ptr %24, align 1, !tbaa !135
  %48 = add i8 %47, 1
  store i8 %48, ptr %24, align 1, !tbaa !135
  %49 = zext i8 %47 to i16
  %50 = getelementptr inbounds nuw i8, ptr %46, i16 %49
  store i8 %29, ptr %50, align 1, !tbaa !6
  %51 = load ptr, ptr %0, align 1, !tbaa !133
  %52 = load i8, ptr %24, align 1, !tbaa !135
  %53 = add i8 %52, 1
  store i8 %53, ptr %24, align 1, !tbaa !135
  %54 = zext i8 %52 to i16
  %55 = getelementptr inbounds nuw i8, ptr %51, i16 %54
  store i8 %31, ptr %55, align 1, !tbaa !6
  %56 = zext nneg i8 %41 to i16
  %57 = sub i16 %33, %56
  %58 = icmp eq i16 %57, 0
  br i1 %58, label %59, label %32, !llvm.loop !136

59:                                               ; preds = %32, %40
  %60 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %61 = trunc i16 %6 to i8
  %62 = lshr i16 %6, 8
  %63 = trunc nuw i16 %62 to i8
  br label %64

64:                                               ; preds = %72, %59
  %65 = phi i16 [ %28, %59 ], [ %89, %72 ]
  %66 = load i8, ptr %60, align 1, !tbaa !135
  %67 = icmp ult i8 %66, 22
  br i1 %67, label %68, label %91

68:                                               ; preds = %64
  %69 = icmp ugt i16 %65, 127
  br i1 %69, label %72, label %70

70:                                               ; preds = %68
  %71 = trunc nuw nsw i16 %65 to i8
  br label %72

72:                                               ; preds = %70, %68
  %73 = phi i8 [ %71, %70 ], [ 127, %68 ]
  %74 = load ptr, ptr %1, align 1, !tbaa !133
  %75 = add nuw nsw i8 %66, 1
  store i8 %75, ptr %60, align 1, !tbaa !135
  %76 = zext nneg i8 %66 to i16
  %77 = getelementptr inbounds nuw i8, ptr %74, i16 %76
  store i8 %73, ptr %77, align 1, !tbaa !6
  %78 = load ptr, ptr %1, align 1, !tbaa !133
  %79 = load i8, ptr %60, align 1, !tbaa !135
  %80 = add i8 %79, 1
  store i8 %80, ptr %60, align 1, !tbaa !135
  %81 = zext i8 %79 to i16
  %82 = getelementptr inbounds nuw i8, ptr %78, i16 %81
  store i8 %61, ptr %82, align 1, !tbaa !6
  %83 = load ptr, ptr %1, align 1, !tbaa !133
  %84 = load i8, ptr %60, align 1, !tbaa !135
  %85 = add i8 %84, 1
  store i8 %85, ptr %60, align 1, !tbaa !135
  %86 = zext i8 %84 to i16
  %87 = getelementptr inbounds nuw i8, ptr %83, i16 %86
  store i8 %63, ptr %87, align 1, !tbaa !6
  %88 = zext nneg i8 %73 to i16
  %89 = sub i16 %65, %88
  %90 = icmp eq i16 %89, 0
  br i1 %90, label %91, label %64, !llvm.loop !136

91:                                               ; preds = %64, %72, %21
  store i16 %19, ptr %2, align 1, !tbaa !2
  br label %92

92:                                               ; preds = %18, %91
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_blank(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, i16 noundef %2, i16 noundef range(i16 -2050, 225) %3) unnamed_addr #6 {
  %5 = icmp sgt i16 %3, %2
  br i1 %5, label %6, label %83

6:                                                ; preds = %4
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 2
  br label %9

9:                                                ; preds = %6, %79
  %10 = phi i16 [ %2, %6 ], [ %81, %79 ]
  %11 = sub nsw i16 %3, %10
  %12 = icmp sgt i16 %11, 112
  br i1 %12, label %16, label %13

13:                                               ; preds = %9
  %14 = trunc i16 %11 to i8
  %15 = icmp eq i8 %14, 0
  br i1 %15, label %79, label %16

16:                                               ; preds = %9, %13
  %17 = phi i8 [ %14, %13 ], [ 112, %9 ]
  %18 = phi i16 [ %11, %13 ], [ 112, %9 ]
  %19 = sub nsw i16 144, %10
  %20 = zext i8 %17 to i16
  %21 = trunc i16 %19 to i8
  %22 = lshr i16 %19, 8
  %23 = trunc nuw i16 %22 to i8
  br label %24

24:                                               ; preds = %32, %16
  %25 = phi i16 [ %20, %16 ], [ %49, %32 ]
  %26 = load i8, ptr %7, align 1, !tbaa !135
  %27 = icmp ult i8 %26, 22
  br i1 %27, label %28, label %51

28:                                               ; preds = %24
  %29 = icmp ugt i16 %25, 127
  br i1 %29, label %32, label %30

30:                                               ; preds = %28
  %31 = trunc nuw nsw i16 %25 to i8
  br label %32

32:                                               ; preds = %30, %28
  %33 = phi i8 [ %31, %30 ], [ 127, %28 ]
  %34 = load ptr, ptr %0, align 1, !tbaa !133
  %35 = add nuw nsw i8 %26, 1
  store i8 %35, ptr %7, align 1, !tbaa !135
  %36 = zext nneg i8 %26 to i16
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 %36
  store i8 %33, ptr %37, align 1, !tbaa !6
  %38 = load ptr, ptr %0, align 1, !tbaa !133
  %39 = load i8, ptr %7, align 1, !tbaa !135
  %40 = add i8 %39, 1
  store i8 %40, ptr %7, align 1, !tbaa !135
  %41 = zext i8 %39 to i16
  %42 = getelementptr inbounds nuw i8, ptr %38, i16 %41
  store i8 %21, ptr %42, align 1, !tbaa !6
  %43 = load ptr, ptr %0, align 1, !tbaa !133
  %44 = load i8, ptr %7, align 1, !tbaa !135
  %45 = add i8 %44, 1
  store i8 %45, ptr %7, align 1, !tbaa !135
  %46 = zext i8 %44 to i16
  %47 = getelementptr inbounds nuw i8, ptr %43, i16 %46
  store i8 %23, ptr %47, align 1, !tbaa !6
  %48 = zext nneg i8 %33 to i16
  %49 = sub i16 %25, %48
  %50 = icmp eq i16 %49, 0
  br i1 %50, label %51, label %24, !llvm.loop !136

51:                                               ; preds = %24, %32
  br label %52

52:                                               ; preds = %51, %60
  %53 = phi i16 [ %77, %60 ], [ %20, %51 ]
  %54 = load i8, ptr %8, align 1, !tbaa !135
  %55 = icmp ult i8 %54, 22
  br i1 %55, label %56, label %79

56:                                               ; preds = %52
  %57 = icmp ugt i16 %53, 127
  br i1 %57, label %60, label %58

58:                                               ; preds = %56
  %59 = trunc nuw nsw i16 %53 to i8
  br label %60

60:                                               ; preds = %58, %56
  %61 = phi i8 [ %59, %58 ], [ 127, %56 ]
  %62 = load ptr, ptr %1, align 1, !tbaa !133
  %63 = add nuw nsw i8 %54, 1
  store i8 %63, ptr %8, align 1, !tbaa !135
  %64 = zext nneg i8 %54 to i16
  %65 = getelementptr inbounds nuw i8, ptr %62, i16 %64
  store i8 %61, ptr %65, align 1, !tbaa !6
  %66 = load ptr, ptr %1, align 1, !tbaa !133
  %67 = load i8, ptr %8, align 1, !tbaa !135
  %68 = add i8 %67, 1
  store i8 %68, ptr %8, align 1, !tbaa !135
  %69 = zext i8 %67 to i16
  %70 = getelementptr inbounds nuw i8, ptr %66, i16 %69
  store i8 0, ptr %70, align 1, !tbaa !6
  %71 = load ptr, ptr %1, align 1, !tbaa !133
  %72 = load i8, ptr %8, align 1, !tbaa !135
  %73 = add i8 %72, 1
  store i8 %73, ptr %8, align 1, !tbaa !135
  %74 = zext i8 %72 to i16
  %75 = getelementptr inbounds nuw i8, ptr %71, i16 %74
  store i8 0, ptr %75, align 1, !tbaa !6
  %76 = zext nneg i8 %61 to i16
  %77 = sub i16 %53, %76
  %78 = icmp eq i16 %77, 0
  br i1 %78, label %79, label %52, !llvm.loop !136

79:                                               ; preds = %52, %60, %13
  %80 = phi i16 [ %11, %13 ], [ %18, %60 ], [ %18, %52 ]
  %81 = add nsw i16 %80, %10
  %82 = icmp sgt i16 %3, %81
  br i1 %82, label %9, label %83, !llvm.loop !137

83:                                               ; preds = %79, %4
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal fastcc void @hx4(ptr noundef nonnull writeonly captures(none) initializes((0, 5)) %0, i16 noundef %1) unnamed_addr #7 {
  %3 = lshr i16 %1, 12
  %4 = trunc nuw nsw i16 %3 to i8
  %5 = icmp samesign ult i8 %4, 10
  br i1 %5, label %6, label %8

6:                                                ; preds = %2
  %7 = or disjoint i8 %4, 48
  br label %10

8:                                                ; preds = %2
  %9 = add nuw nsw i8 %4, 55
  br label %10

10:                                               ; preds = %6, %8
  %11 = phi i8 [ %7, %6 ], [ %9, %8 ]
  store i8 %11, ptr %0, align 1, !tbaa !6
  %12 = lshr i16 %1, 8
  %13 = trunc nuw i16 %12 to i8
  %14 = and i8 %13, 15
  %15 = icmp samesign ult i8 %14, 10
  br i1 %15, label %16, label %18

16:                                               ; preds = %10
  %17 = or disjoint i8 %14, 48
  br label %20

18:                                               ; preds = %10
  %19 = add nuw nsw i8 %14, 55
  br label %20

20:                                               ; preds = %16, %18
  %21 = phi i8 [ %17, %16 ], [ %19, %18 ]
  %22 = getelementptr inbounds nuw i8, ptr %0, i16 1
  store i8 %21, ptr %22, align 1, !tbaa !6
  %23 = trunc i16 %1 to i8
  %24 = lshr i8 %23, 4
  %25 = icmp ult i8 %23, -96
  br i1 %25, label %26, label %28

26:                                               ; preds = %20
  %27 = or disjoint i8 %24, 48
  br label %30

28:                                               ; preds = %20
  %29 = add nuw nsw i8 %24, 55
  br label %30

30:                                               ; preds = %26, %28
  %31 = phi i8 [ %27, %26 ], [ %29, %28 ]
  %32 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 %31, ptr %32, align 1, !tbaa !6
  %33 = and i8 %23, 15
  %34 = icmp samesign ult i8 %33, 10
  br i1 %34, label %35, label %37

35:                                               ; preds = %30
  %36 = or disjoint i8 %33, 48
  br label %39

37:                                               ; preds = %30
  %38 = add nuw nsw i8 %33, 55
  br label %39

39:                                               ; preds = %35, %37
  %40 = phi i8 [ %36, %35 ], [ %38, %37 ]
  %41 = getelementptr inbounds nuw i8, ptr %0, i16 3
  store i8 %40, ptr %41, align 1, !tbaa !6
  %42 = getelementptr inbounds nuw i8, ptr %0, i16 4
  store i8 0, ptr %42, align 1, !tbaa !6
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: read, inaccessiblemem: none, target_mem: none)
define internal fastcc void @tg_str16(i8 noundef zeroext range(i8 0, 10) %0, i8 noundef zeroext range(i8 2, 25) %1, ptr noundef nonnull readonly captures(none) %2, i8 noundef zeroext range(i8 0, 2) %3) unnamed_addr #8 {
  %5 = load i8, ptr %2, align 1, !tbaa !6
  %6 = icmp eq i8 %5, 0
  br i1 %6, label %60, label %7

7:                                                ; preds = %4
  %8 = zext nneg i8 %1 to i16
  %9 = zext nneg i8 %3 to i16
  %10 = shl nuw nsw i16 %9, 10
  %11 = shl nuw nsw i16 %8, 6
  %12 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %11
  %13 = add nuw nsw i8 %1, 1
  %14 = zext nneg i8 %13 to i16
  %15 = shl nuw nsw i16 %14, 6
  %16 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %15
  br label %17

17:                                               ; preds = %7, %55
  %18 = phi i8 [ %5, %7 ], [ %58, %55 ]
  %19 = phi i8 [ %0, %7 ], [ %57, %55 ]
  %20 = phi ptr [ %2, %7 ], [ %56, %55 ]
  %21 = icmp ult i8 %18, 32
  br i1 %21, label %24, label %22

22:                                               ; preds = %17
  %23 = icmp ugt i8 %18, 95
  br i1 %23, label %24, label %25

24:                                               ; preds = %22, %17
  br label %25

25:                                               ; preds = %24, %22
  %26 = phi i8 [ 32, %24 ], [ %18, %22 ]
  %27 = zext nneg i8 %26 to i16
  %28 = shl nuw nsw i16 %27, 2
  %29 = icmp ugt i8 %19, 31
  br i1 %29, label %35, label %30

30:                                               ; preds = %25
  %31 = add nsw i16 %28, -128
  %32 = zext nneg i8 %19 to i16
  %33 = or i16 %31, %10
  %34 = getelementptr inbounds nuw [2 x i8], ptr %12, i16 %32
  store i16 %33, ptr %34, align 1, !tbaa !2
  br label %35

35:                                               ; preds = %25, %30
  %36 = add i8 %19, 1
  %37 = icmp ugt i8 %36, 31
  br i1 %37, label %43, label %38

38:                                               ; preds = %35
  %39 = add nsw i16 %28, -127
  %40 = zext nneg i8 %36 to i16
  %41 = or i16 %39, %10
  %42 = getelementptr inbounds nuw [2 x i8], ptr %12, i16 %40
  store i16 %41, ptr %42, align 1, !tbaa !2
  br label %43

43:                                               ; preds = %35, %38
  br i1 %29, label %49, label %44

44:                                               ; preds = %43
  %45 = add nsw i16 %28, -126
  %46 = zext nneg i8 %19 to i16
  %47 = or i16 %45, %10
  %48 = getelementptr inbounds nuw [2 x i8], ptr %16, i16 %46
  store i16 %47, ptr %48, align 1, !tbaa !2
  br label %49

49:                                               ; preds = %43, %44
  br i1 %37, label %55, label %50

50:                                               ; preds = %49
  %51 = add nsw i16 %28, -125
  %52 = zext nneg i8 %36 to i16
  %53 = or i16 %51, %10
  %54 = getelementptr inbounds nuw [2 x i8], ptr %16, i16 %52
  store i16 %53, ptr %54, align 1, !tbaa !2
  br label %55

55:                                               ; preds = %49, %50
  %56 = getelementptr inbounds nuw i8, ptr %20, i16 1
  %57 = add i8 %19, 2
  %58 = load i8, ptr %56, align 1, !tbaa !6
  %59 = icmp eq i8 %58, 0
  br i1 %59, label %60, label %17, !llvm.loop !138

60:                                               ; preds = %55, %4
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(read, argmem: write, inaccessiblemem: none, target_mem: none)
define internal fastcc void @fmt_oper(ptr noundef nonnull writeonly captures(none) initializes((0, 1)) %0, i8 noundef zeroext %1, i8 noundef zeroext %2) unnamed_addr #9 {
  %4 = alloca [5 x i8], align 1
  %5 = zext i8 %1 to i16
  %6 = getelementptr inbounds nuw [7 x i8], ptr @CPU6502_OPS, i16 %5
  %7 = zext i8 %2 to i16
  %8 = add i8 %2, 1
  %9 = zext i8 %8 to i16
  %10 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1999), i16 %9
  %11 = load i8, ptr %10, align 1, !tbaa !6
  %12 = add nuw nsw i16 %7, 2
  %13 = and i16 %12, 255
  %14 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 1999), i16 %13
  %15 = load i8, ptr %14, align 1, !tbaa !6
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #16
  %16 = getelementptr inbounds nuw i8, ptr %6, i16 4
  %17 = load i8, ptr %16, align 1, !tbaa !139
  switch i8 %17, label %113 [
    i8 1, label %18
    i8 2, label %39
    i8 3, label %59
    i8 5, label %81
    i8 11, label %98
  ]

18:                                               ; preds = %3
  store i8 35, ptr %0, align 1, !tbaa !6
  %19 = getelementptr inbounds nuw i8, ptr %0, i16 1
  store i8 36, ptr %19, align 1, !tbaa !6
  %20 = lshr i8 %11, 4
  %21 = icmp ult i8 %11, -96
  br i1 %21, label %22, label %24

22:                                               ; preds = %18
  %23 = or disjoint i8 %20, 48
  br label %26

24:                                               ; preds = %18
  %25 = add nuw nsw i8 %20, 55
  br label %26

26:                                               ; preds = %24, %22
  %27 = phi i8 [ %23, %22 ], [ %25, %24 ]
  %28 = and i8 %11, 15
  %29 = icmp samesign ult i8 %28, 10
  br i1 %29, label %30, label %32

30:                                               ; preds = %26
  %31 = or disjoint i8 %28, 48
  br label %34

32:                                               ; preds = %26
  %33 = add nuw nsw i8 %28, 55
  br label %34

34:                                               ; preds = %30, %32
  %35 = phi i8 [ %31, %30 ], [ %33, %32 ]
  %36 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 %27, ptr %36, align 1, !tbaa !6
  %37 = getelementptr inbounds nuw i8, ptr %0, i16 3
  store i8 %35, ptr %37, align 1, !tbaa !6
  %38 = getelementptr inbounds nuw i8, ptr %0, i16 4
  store i8 0, ptr %38, align 1, !tbaa !6
  br label %114

39:                                               ; preds = %3
  store i8 36, ptr %0, align 1, !tbaa !6
  %40 = lshr i8 %11, 4
  %41 = icmp ult i8 %11, -96
  br i1 %41, label %42, label %44

42:                                               ; preds = %39
  %43 = or disjoint i8 %40, 48
  br label %46

44:                                               ; preds = %39
  %45 = add nuw nsw i8 %40, 55
  br label %46

46:                                               ; preds = %44, %42
  %47 = phi i8 [ %43, %42 ], [ %45, %44 ]
  %48 = and i8 %11, 15
  %49 = icmp samesign ult i8 %48, 10
  br i1 %49, label %50, label %52

50:                                               ; preds = %46
  %51 = or disjoint i8 %48, 48
  br label %54

52:                                               ; preds = %46
  %53 = add nuw nsw i8 %48, 55
  br label %54

54:                                               ; preds = %50, %52
  %55 = phi i8 [ %51, %50 ], [ %53, %52 ]
  %56 = getelementptr inbounds nuw i8, ptr %0, i16 1
  store i8 %47, ptr %56, align 1, !tbaa !6
  %57 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 %55, ptr %57, align 1, !tbaa !6
  %58 = getelementptr inbounds nuw i8, ptr %0, i16 3
  store i8 0, ptr %58, align 1, !tbaa !6
  br label %114

59:                                               ; preds = %3
  store i8 36, ptr %0, align 1, !tbaa !6
  %60 = lshr i8 %11, 4
  %61 = icmp ult i8 %11, -96
  br i1 %61, label %62, label %64

62:                                               ; preds = %59
  %63 = or disjoint i8 %60, 48
  br label %66

64:                                               ; preds = %59
  %65 = add nuw nsw i8 %60, 55
  br label %66

66:                                               ; preds = %64, %62
  %67 = phi i8 [ %63, %62 ], [ %65, %64 ]
  %68 = and i8 %11, 15
  %69 = icmp samesign ult i8 %68, 10
  br i1 %69, label %70, label %72

70:                                               ; preds = %66
  %71 = or disjoint i8 %68, 48
  br label %74

72:                                               ; preds = %66
  %73 = add nuw nsw i8 %68, 55
  br label %74

74:                                               ; preds = %70, %72
  %75 = phi i8 [ %71, %70 ], [ %73, %72 ]
  %76 = getelementptr inbounds nuw i8, ptr %0, i16 1
  store i8 %67, ptr %76, align 1, !tbaa !6
  %77 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 %75, ptr %77, align 1, !tbaa !6
  %78 = getelementptr inbounds nuw i8, ptr %0, i16 3
  store i8 44, ptr %78, align 1, !tbaa !6
  %79 = getelementptr inbounds nuw i8, ptr %0, i16 4
  store i8 88, ptr %79, align 1, !tbaa !6
  %80 = getelementptr inbounds nuw i8, ptr %0, i16 5
  store i8 0, ptr %80, align 1, !tbaa !6
  br label %114

81:                                               ; preds = %3
  store i8 36, ptr %0, align 1, !tbaa !6
  %82 = zext i8 %15 to i16
  %83 = shl nuw i16 %82, 8
  %84 = zext i8 %11 to i16
  %85 = or disjoint i16 %83, %84
  call fastcc void @hx4(ptr noundef %4, i16 noundef %85) #15
  %86 = load i8, ptr %4, align 1, !tbaa !6
  %87 = getelementptr inbounds nuw i8, ptr %0, i16 1
  store i8 %86, ptr %87, align 1, !tbaa !6
  %88 = getelementptr inbounds nuw i8, ptr %4, i16 1
  %89 = load i8, ptr %88, align 1, !tbaa !6
  %90 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 %89, ptr %90, align 1, !tbaa !6
  %91 = getelementptr inbounds nuw i8, ptr %4, i16 2
  %92 = load i8, ptr %91, align 1, !tbaa !6
  %93 = getelementptr inbounds nuw i8, ptr %0, i16 3
  store i8 %92, ptr %93, align 1, !tbaa !6
  %94 = getelementptr inbounds nuw i8, ptr %4, i16 3
  %95 = load i8, ptr %94, align 1, !tbaa !6
  %96 = getelementptr inbounds nuw i8, ptr %0, i16 4
  store i8 %95, ptr %96, align 1, !tbaa !6
  %97 = getelementptr inbounds nuw i8, ptr %0, i16 5
  store i8 0, ptr %97, align 1, !tbaa !6
  br label %114

98:                                               ; preds = %3
  %99 = sext i8 %11 to i16
  %100 = add nsw i16 %12, %99
  store i8 36, ptr %0, align 1, !tbaa !6
  call fastcc void @hx4(ptr noundef %4, i16 noundef %100) #15
  %101 = load i8, ptr %4, align 1, !tbaa !6
  %102 = getelementptr inbounds nuw i8, ptr %0, i16 1
  store i8 %101, ptr %102, align 1, !tbaa !6
  %103 = getelementptr inbounds nuw i8, ptr %4, i16 1
  %104 = load i8, ptr %103, align 1, !tbaa !6
  %105 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 %104, ptr %105, align 1, !tbaa !6
  %106 = getelementptr inbounds nuw i8, ptr %4, i16 2
  %107 = load i8, ptr %106, align 1, !tbaa !6
  %108 = getelementptr inbounds nuw i8, ptr %0, i16 3
  store i8 %107, ptr %108, align 1, !tbaa !6
  %109 = getelementptr inbounds nuw i8, ptr %4, i16 3
  %110 = load i8, ptr %109, align 1, !tbaa !6
  %111 = getelementptr inbounds nuw i8, ptr %0, i16 4
  store i8 %110, ptr %111, align 1, !tbaa !6
  %112 = getelementptr inbounds nuw i8, ptr %0, i16 5
  store i8 0, ptr %112, align 1, !tbaa !6
  br label %114

113:                                              ; preds = %3
  store i8 0, ptr %0, align 1, !tbaa !6
  br label %114

114:                                              ; preds = %113, %98, %81, %74, %54, %34
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #16
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @upq_flush() unnamed_addr #10 {
  %1 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 177), align 1, !tbaa !140
  %2 = zext i8 %1 to i16
  %3 = shl nuw nsw i16 %2, 4
  %4 = add nuw nsw i16 %3, 17152
  %5 = inttoptr i16 %4 to ptr
  %6 = shl nuw i16 1, %2
  %7 = trunc i16 %6 to i8
  %8 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !76
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %108, label %10

10:                                               ; preds = %0
  %11 = getelementptr inbounds nuw i8, ptr %5, i16 1
  %12 = getelementptr inbounds nuw i8, ptr %5, i16 2
  %13 = getelementptr inbounds nuw i8, ptr %5, i16 3
  %14 = getelementptr inbounds nuw i8, ptr %5, i16 4
  %15 = getelementptr inbounds nuw i8, ptr %5, i16 5
  %16 = getelementptr inbounds nuw i8, ptr %5, i16 6
  br label %17

17:                                               ; preds = %10, %86
  %18 = phi i8 [ %8, %10 ], [ %89, %86 ]
  %19 = phi i16 [ 0, %10 ], [ %87, %86 ]
  %20 = phi i8 [ 0, %10 ], [ %88, %86 ]
  %21 = zext i8 %20 to i16
  %22 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %21
  %23 = getelementptr inbounds nuw i8, ptr %22, i16 10
  %24 = load i8, ptr %23, align 1, !tbaa !77
  switch i8 %24, label %44 [
    i8 3, label %25
    i8 4, label %34
  ]

25:                                               ; preds = %17
  %26 = load i16, ptr %22, align 1, !tbaa !79
  %27 = inttoptr i16 %26 to ptr
  %28 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %29 = load i16, ptr %28, align 1, !tbaa !83
  %30 = trunc i16 %29 to i8
  store volatile i8 %30, ptr %27, align 1, !tbaa !6
  %31 = load i16, ptr %28, align 1, !tbaa !83
  %32 = lshr i16 %31, 8
  %33 = trunc nuw i16 %32 to i8
  store volatile i8 %33, ptr %27, align 1, !tbaa !6
  br label %86

34:                                               ; preds = %17
  %35 = load i16, ptr %22, align 1, !tbaa !79
  %36 = inttoptr i16 %35 to ptr
  %37 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %38 = load i16, ptr %37, align 1, !tbaa !83
  %39 = trunc i16 %38 to i8
  store volatile i8 %39, ptr %36, align 1, !tbaa !6
  %40 = load i16, ptr %37, align 1, !tbaa !83
  %41 = lshr i16 %40, 8
  %42 = trunc nuw i16 %41 to i8
  %43 = getelementptr inbounds nuw i8, ptr %36, i16 1
  store volatile i8 %42, ptr %43, align 1, !tbaa !6
  br label %86

44:                                               ; preds = %17
  %45 = icmp eq i16 %19, 0
  br i1 %45, label %51, label %46

46:                                               ; preds = %44
  %47 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %48 = load i16, ptr %47, align 1, !tbaa !85
  %49 = add i16 %48, %19
  %50 = icmp ugt i16 %49, 5100
  br i1 %50, label %91, label %51

51:                                               ; preds = %46, %44
  switch i8 %24, label %59 [
    i8 0, label %52
    i8 1, label %56
  ]

52:                                               ; preds = %51
  %53 = getelementptr inbounds nuw i8, ptr %22, i16 9
  %54 = load i8, ptr %53, align 1, !tbaa !80
  store volatile i8 %54, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  %55 = load i16, ptr %22, align 1, !tbaa !79
  store volatile i16 %55, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %65

56:                                               ; preds = %51
  %57 = load i16, ptr %22, align 1, !tbaa !79
  %58 = trunc i16 %57 to i8
  store volatile i8 %58, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  br label %65

59:                                               ; preds = %51
  %60 = load i16, ptr %22, align 1, !tbaa !79
  %61 = trunc i16 %60 to i8
  store volatile i8 %61, ptr inttoptr (i16 8450 to ptr), align 2, !tbaa !6
  %62 = load i16, ptr %22, align 1, !tbaa !79
  %63 = lshr i16 %62, 8
  %64 = trunc nuw i16 %63 to i8
  store volatile i8 %64, ptr inttoptr (i16 8451 to ptr), align 1, !tbaa !6
  br label %65

65:                                               ; preds = %56, %59, %52
  %66 = getelementptr inbounds nuw i8, ptr %22, i16 8
  %67 = load i8, ptr %66, align 1, !tbaa !82
  store volatile i8 %67, ptr %5, align 16, !tbaa !6
  %68 = getelementptr inbounds nuw i8, ptr %22, i16 7
  %69 = load i8, ptr %68, align 1, !tbaa !81
  store volatile i8 %69, ptr %11, align 1, !tbaa !6
  %70 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %71 = load i16, ptr %70, align 1, !tbaa !83
  %72 = trunc i16 %71 to i8
  store volatile i8 %72, ptr %12, align 2, !tbaa !6
  %73 = load i16, ptr %70, align 1, !tbaa !83
  %74 = lshr i16 %73, 8
  %75 = trunc nuw i16 %74 to i8
  store volatile i8 %75, ptr %13, align 1, !tbaa !6
  %76 = getelementptr inbounds nuw i8, ptr %22, i16 6
  %77 = load i8, ptr %76, align 1, !tbaa !84
  store volatile i8 %77, ptr %14, align 4, !tbaa !6
  %78 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %79 = load i16, ptr %78, align 1, !tbaa !85
  %80 = trunc i16 %79 to i8
  store volatile i8 %80, ptr %15, align 1, !tbaa !6
  %81 = load i16, ptr %78, align 1, !tbaa !85
  %82 = lshr i16 %81, 8
  %83 = trunc nuw i16 %82 to i8
  store volatile i8 %83, ptr %16, align 2, !tbaa !6
  store volatile i8 %7, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !6
  %84 = load i16, ptr %78, align 1, !tbaa !85
  %85 = add i16 %84, %19
  br label %86

86:                                               ; preds = %65, %34, %25
  %87 = phi i16 [ %19, %25 ], [ %19, %34 ], [ %85, %65 ]
  %88 = add nuw i8 %20, 1
  %89 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !76
  %90 = icmp ult i8 %88, %89
  br i1 %90, label %17, label %91

91:                                               ; preds = %86, %46
  %92 = phi i8 [ %89, %86 ], [ %18, %46 ]
  %93 = phi i8 [ %88, %86 ], [ %20, %46 ]
  %94 = icmp ult i8 %93, %92
  br i1 %94, label %95, label %108

95:                                               ; preds = %91
  %96 = icmp eq i8 %93, 0
  br i1 %96, label %110, label %97

97:                                               ; preds = %95, %97
  %98 = phi i8 [ %101, %97 ], [ 0, %95 ]
  %99 = phi i8 [ %104, %97 ], [ %93, %95 ]
  %100 = zext i8 %99 to i16
  %101 = add i8 %98, 1
  %102 = zext i8 %98 to i16
  %103 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %102
  %104 = add nuw i8 %99, 1
  %105 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %100
  tail call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(11) %103, ptr noundef nonnull align 1 dereferenceable(11) %105, i16 11, i1 false), !tbaa.struct !141
  %106 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !76
  %107 = icmp ult i8 %104, %106
  br i1 %107, label %97, label %108, !llvm.loop !142

108:                                              ; preds = %97, %91, %0
  %109 = phi i8 [ 0, %91 ], [ 0, %0 ], [ %101, %97 ]
  store i8 %109, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !76
  br label %110

110:                                              ; preds = %108, %95
  ret void
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fshl.i8(i8, i8, i8) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #12

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #13

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #13

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree norecurse nosync nounwind optsize memory(readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #3 = { mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #4 = { nofree norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #5 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #6 = { nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #7 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #8 = { nofree norecurse nosync nounwind optsize memory(write, argmem: read, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #9 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(read, argmem: write, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #10 = { nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #11 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #12 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #13 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #14 = { nounwind optsize }
attributes #15 = { optsize }
attributes #16 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!10, !4, i64 194}
!10 = !{!"", !11, i64 0, !12, i64 178, !13, i64 182, !4, i64 191, !4, i64 192, !4, i64 193, !4, i64 194, !4, i64 195}
!11 = !{!"", !4, i64 0, !4, i64 176, !4, i64 177}
!12 = !{!"", !3, i64 0, !3, i64 2}
!13 = !{!"", !4, i64 0, !4, i64 8}
!14 = !{!10, !4, i64 195}
!15 = !{!16, !18, i64 0}
!16 = !{!"", !17, i64 0, !4, i64 3, !4, i64 1795}
!17 = !{!"Drawable", !18, i64 0, !4, i64 2}
!18 = !{!"any pointer", !4, i64 0}
!19 = !{!16, !4, i64 2}
!20 = distinct !{!20, !8}
!21 = !{!16, !4, i64 1795}
!22 = !{!10, !4, i64 192}
!23 = !{!10, !4, i64 193}
!24 = !{!13, !4, i64 8}
!25 = !{!26, !26, i64 0}
!26 = !{!"p1 _ZTS8Drawable", !18, i64 0}
!27 = distinct !{null, null}
!28 = !{!10, !4, i64 191}
!29 = !{!17, !4, i64 2}
!30 = !{!31, !4, i64 0}
!31 = !{!"", !4, i64 0, !4, i64 1, !4, i64 2, !4, i64 3, !4, i64 4, !3, i64 5, !4, i64 7}
!32 = !{!31, !4, i64 1}
!33 = !{!31, !4, i64 2}
!34 = !{!31, !4, i64 3}
!35 = !{!31, !4, i64 4}
!36 = !{!31, !3, i64 5}
!37 = !{!38, !18, i64 0}
!38 = !{!"", !17, i64 0, !39, i64 3, !39, i64 5, !39, i64 7, !39, i64 9, !4, i64 11, !4, i64 12, !3, i64 13, !3, i64 15, !3, i64 17, !3, i64 19, !3, i64 21, !3, i64 23, !4, i64 25, !3, i64 26, !4, i64 28, !4, i64 29, !4, i64 30, !4, i64 31, !4, i64 32, !4, i64 33, !3, i64 34, !3, i64 36, !40, i64 38, !40, i64 89}
!39 = !{!"p1 omnipotent char", !18, i64 0}
!40 = !{!"", !4, i64 0, !4, i64 50}
!41 = !{!38, !4, i64 2}
!42 = !{!38, !39, i64 3}
!43 = !{!38, !39, i64 5}
!44 = !{!38, !39, i64 7}
!45 = !{!38, !4, i64 11}
!46 = !{!38, !39, i64 9}
!47 = !{!38, !4, i64 12}
!48 = !{!38, !3, i64 13}
!49 = !{!38, !3, i64 15}
!50 = !{!38, !3, i64 17}
!51 = !{!38, !4, i64 28}
!52 = !{!38, !4, i64 29}
!53 = !{!38, !4, i64 31}
!54 = !{!38, !4, i64 32}
!55 = !{!38, !4, i64 30}
!56 = !{!38, !4, i64 25}
!57 = !{!38, !3, i64 34}
!58 = !{!38, !3, i64 36}
!59 = !{!38, !4, i64 33}
!60 = !{!17, !18, i64 0}
!61 = !{!62, !18, i64 2}
!62 = !{!"", !18, i64 0, !18, i64 2}
!63 = distinct !{null, null, null, null, null}
!64 = distinct !{!64, !8}
!65 = distinct !{!65, !8}
!66 = distinct !{!66, !8}
!67 = distinct !{null, null, null, null}
!68 = distinct !{!68, !8}
!69 = distinct !{!69, !8}
!70 = distinct !{null, null, null, null, null}
!71 = distinct !{!71, !8}
!72 = distinct !{!72, !8}
!73 = distinct !{null, null, null, null}
!74 = !{!38, !3, i64 19}
!75 = distinct !{null, null, null, null, null}
!76 = !{!11, !4, i64 176}
!77 = !{!78, !4, i64 10}
!78 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !4, i64 6, !4, i64 7, !4, i64 8, !4, i64 9, !4, i64 10}
!79 = !{!78, !3, i64 0}
!80 = !{!78, !4, i64 9}
!81 = !{!78, !4, i64 7}
!82 = !{!78, !4, i64 8}
!83 = !{!78, !3, i64 2}
!84 = !{!78, !4, i64 6}
!85 = !{!78, !3, i64 4}
!86 = !{!87, !4, i64 2256}
!87 = !{!"", !10, i64 0, !16, i64 196, !31, i64 1992, !4, i64 2255, !4, i64 2256, !4, i64 2257, !4, i64 2269}
!88 = !{!87, !3, i64 1997}
!89 = !{!87, !4, i64 2269}
!90 = !{!87, !4, i64 2255}
!91 = distinct !{null, null, null}
!92 = distinct !{!92, !8}
!93 = distinct !{!93, !8}
!94 = distinct !{!94, !8}
!95 = !{!96, !4, i64 5}
!96 = !{!"", !4, i64 0, !4, i64 4, !4, i64 5, !4, i64 6}
!97 = distinct !{!97, !8}
!98 = distinct !{!98, !8}
!99 = distinct !{!99, !8}
!100 = distinct !{!100, !8}
!101 = !{!87, !4, i64 1992}
!102 = !{!87, !4, i64 1993}
!103 = !{!87, !4, i64 1994}
!104 = !{!87, !4, i64 1996}
!105 = distinct !{!105, !8}
!106 = !{!96, !4, i64 6}
!107 = distinct !{!107, !8}
!108 = distinct !{!108, !8}
!109 = distinct !{!109, !8}
!110 = distinct !{!110, !8}
!111 = distinct !{!111, !8}
!112 = distinct !{!112, !8}
!113 = distinct !{!113, !8}
!114 = distinct !{!114, !8}
!115 = distinct !{!115, !8}
!116 = distinct !{!116, !8}
!117 = distinct !{!117, !8}
!118 = distinct !{!118, !8}
!119 = distinct !{!119, !8}
!120 = distinct !{!120, !8}
!121 = distinct !{!121, !8}
!122 = distinct !{!122, !8}
!123 = distinct !{!123, !8}
!124 = distinct !{!124, !8}
!125 = distinct !{!125, !8}
!126 = !{!38, !3, i64 21}
!127 = !{!38, !3, i64 23}
!128 = distinct !{!128, !8}
!129 = !{!38, !3, i64 26}
!130 = !{!40, !4, i64 50}
!131 = distinct !{!131, !8}
!132 = distinct !{!132, !8}
!133 = !{!134, !18, i64 0}
!134 = !{!"", !18, i64 0, !4, i64 2}
!135 = !{!134, !4, i64 2}
!136 = distinct !{!136, !8}
!137 = distinct !{!137, !8}
!138 = distinct !{!138, !8}
!139 = !{!96, !4, i64 4}
!140 = !{!11, !4, i64 177}
!141 = !{i64 0, i64 2, !2, i64 2, i64 2, !2, i64 4, i64 2, !2, i64 6, i64 1, !6, i64 7, i64 1, !6, i64 8, i64 1, !6, i64 9, i64 1, !6, i64 10, i64 1, !6}
!142 = distinct !{!142, !8}
