; ModuleID = '/work/examples/snes/corpus/mandel-float_sim.c'
source_filename = "/work/examples/snes/corpus/mandel-float_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1
@mf_gate_crc.buf = internal unnamed_addr global [36 x i8] zeroinitializer, align 1
@__const.mf_gate_crc.gw = private unnamed_addr constant [2 x i8] c"\00\02", align 1
@MF_WIN = internal unnamed_addr constant [6 x [4 x float]] [[4 x float] [float 0xC0019999A0000000, float 0xBFF6666660000000, float 0x40099999A0000000, float 0x4006666660000000], [4 x float] [float 0xBFF57F90E0000000, float 0xBFD9196100000000, float 0x3FF3333340000000, float 0x3FF0CCCCC0000000], [4 x float] [float 0xBFEE3254E0000000, float 0xBFA61AE700000000, float 0x3FD99999A0000000, float 0x3FD6666660000000], [4 x float] [float 0xBFE9B773A0000000, float 0x3FB44EB560000000, float 0x3FBEB851E0000000, float 0x3FBAE147A0000000], [4 x float] [float 0xBFE86FC580000000, float 0x3FBD447800000000, float 0x3FA47AE140000000, float 0x3FA1EB8520000000], [4 x float] [float 0xBFE80546A0000000, float 0x3FC016F860000000, float 0x3F8CAC0840000000, float 0x3F89168720000000]], align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %19

1:                                                ; preds = %83, %1
  %2 = phi float [ %13, %1 ], [ 0.000000e+00, %83 ]
  %3 = phi float [ %16, %1 ], [ 0.000000e+00, %83 ]
  %4 = phi i32 [ %11, %1 ], [ -2128831035, %83 ]
  %5 = phi i8 [ %17, %1 ], [ 0, %83 ]
  %6 = fmul float %2, %2
  %7 = fmul float %3, %3
  %8 = fadd float %6, %7
  %9 = bitcast float %8 to i32
  %10 = xor i32 %4, %9
  %11 = mul i32 %10, 16777619
  %12 = fsub float %6, %7
  %13 = fadd float %12, -5.000000e-01
  %14 = fmul float %2, %3
  %15 = fadd float %14, %14
  %16 = fadd float %15, 0.000000e+00
  %17 = add nuw nsw i8 %5, 1
  %18 = icmp eq i8 %17, 24
  br i1 %18, label %86, label %1, !llvm.loop !6

19:                                               ; preds = %83, %0
  %20 = phi i16 [ 0, %0 ], [ %85, %83 ]
  %21 = phi i1 [ true, %0 ], [ false, %83 ]
  %22 = phi i8 [ 0, %0 ], [ 1, %83 ]
  %23 = zext nneg i8 %22 to i16
  %24 = getelementptr i8, ptr @__const.mf_gate_crc.gw, i16 %23
  %25 = load i8, ptr %24, align 1, !tbaa !8
  %26 = zext i8 %25 to i16
  %27 = getelementptr inbounds nuw [16 x i8], ptr @MF_WIN, i16 %26
  %28 = load float, ptr %27, align 1, !tbaa !9
  %29 = getelementptr inbounds nuw i8, ptr %27, i16 4
  %30 = load float, ptr %29, align 1, !tbaa !9
  %31 = getelementptr inbounds nuw i8, ptr %27, i16 8
  %32 = load float, ptr %31, align 1, !tbaa !9
  %33 = fdiv float %32, 6.000000e+00
  %34 = getelementptr inbounds nuw i8, ptr %27, i16 12
  %35 = load float, ptr %34, align 1, !tbaa !9
  %36 = fdiv float %35, 6.000000e+00
  br label %37

37:                                               ; preds = %44, %19
  %38 = phi i8 [ %49, %44 ], [ 0, %19 ]
  %39 = phi ptr [ %47, %44 ], [ @mf_gate_crc.buf, %19 ]
  %40 = phi i8 [ %45, %44 ], [ 0, %19 ]
  %41 = uitofp nneg i8 %40 to float
  %42 = fmul float %36, %41
  %43 = fadd float %30, %42
  br label %50

44:                                               ; preds = %50
  %45 = add nuw nsw i8 %40, 1
  %46 = zext nneg i8 %38 to i16
  %47 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @mf_gate_crc.buf, i16 6), i16 %46
  %48 = icmp eq i8 %45, 6
  %49 = add nuw nsw i8 %38, 6
  br i1 %48, label %60, label %37, !llvm.loop !11

50:                                               ; preds = %50, %37
  %51 = phi i8 [ 0, %37 ], [ %58, %50 ]
  %52 = uitofp nneg i8 %51 to float
  %53 = fmul float %33, %52
  %54 = fadd float %28, %53
  %55 = tail call fastcc zeroext i8 @mf_cell(float noundef %54, float noundef %43) #3
  %56 = zext nneg i8 %51 to i16
  %57 = getelementptr i8, ptr %39, i16 %56
  store i8 %55, ptr %57, align 1, !tbaa !8
  %58 = add nuw nsw i8 %51, 1
  %59 = icmp eq i8 %58, 6
  br i1 %59, label %44, label %50, !llvm.loop !12

60:                                               ; preds = %44, %69
  %61 = phi i8 [ %70, %69 ], [ 0, %44 ]
  %62 = phi i16 [ %80, %69 ], [ -1, %44 ]
  %63 = zext nneg i8 %61 to i16
  %64 = getelementptr i8, ptr @mf_gate_crc.buf, i16 %63
  %65 = load i8, ptr %64, align 1, !tbaa !8
  %66 = zext i8 %65 to i16
  %67 = shl nuw i16 %66, 8
  %68 = xor i16 %67, %62
  br label %72

69:                                               ; preds = %79
  %70 = add nuw nsw i8 %61, 1
  %71 = icmp eq i8 %70, 36
  br i1 %71, label %83, label %60, !llvm.loop !13

72:                                               ; preds = %79, %60
  %73 = phi i8 [ 0, %60 ], [ %81, %79 ]
  %74 = phi i16 [ %68, %60 ], [ %80, %79 ]
  %75 = icmp sgt i16 %74, -1
  %76 = shl i16 %74, 1
  br i1 %75, label %79, label %77

77:                                               ; preds = %72
  %78 = xor i16 %76, 4129
  br label %79

79:                                               ; preds = %77, %72
  %80 = phi i16 [ %78, %77 ], [ %76, %72 ]
  %81 = add nuw nsw i8 %73, 1
  %82 = icmp eq i8 %81, 8
  br i1 %82, label %69, label %72, !llvm.loop !14

83:                                               ; preds = %69
  %84 = tail call i16 @llvm.fshl.i16(i16 %20, i16 %20, i16 1)
  %85 = xor i16 %80, %84
  br i1 %21, label %19, label %1, !llvm.loop !15

86:                                               ; preds = %1
  %87 = trunc i32 %11 to i16
  %88 = xor i16 %85, %87
  %89 = tail call i16 @llvm.fshl.i16(i16 %88, i16 %88, i16 1)
  %90 = lshr i32 %11, 16
  %91 = trunc nuw i32 %90 to i16
  %92 = xor i16 %89, %91
  store volatile i16 %92, ptr @corpus_result, align 1, !tbaa !2
  br label %93

93:                                               ; preds = %93, %86
  tail call void asm sideeffect "wai", ""() #4, !srcloc !16
  br label %93
}

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(none)
define internal fastcc zeroext i8 @mf_cell(float noundef %0, float noundef %1) unnamed_addr #1 {
  br label %3

3:                                                ; preds = %2, %11
  %4 = phi float [ 0.000000e+00, %2 ], [ %13, %11 ]
  %5 = phi float [ 0.000000e+00, %2 ], [ %16, %11 ]
  %6 = phi i8 [ 0, %2 ], [ %17, %11 ]
  %7 = fmul float %4, %4
  %8 = fmul float %5, %5
  %9 = fadd float %8, %7
  %10 = fcmp ogt float %9, 4.000000e+00
  br i1 %10, label %19, label %11

11:                                               ; preds = %3
  %12 = fsub float %7, %8
  %13 = fadd float %0, %12
  %14 = fmul float %5, %4
  %15 = fadd float %14, %14
  %16 = fadd float %1, %15
  %17 = add nuw nsw i8 %6, 1
  %18 = icmp eq i8 %17, 12
  br i1 %18, label %19, label %3, !llvm.loop !17

19:                                               ; preds = %3, %11
  %20 = phi i8 [ %6, %3 ], [ 12, %11 ]
  ret i8 %20
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #2

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { nofree noinline norecurse nosync nounwind optsize memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { optsize }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{!4, !4, i64 0}
!9 = !{!10, !10, i64 0}
!10 = !{!"float", !4, i64 0}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
!15 = distinct !{!15, !7}
!16 = !{i64 884}
!17 = distinct !{!17, !7}
