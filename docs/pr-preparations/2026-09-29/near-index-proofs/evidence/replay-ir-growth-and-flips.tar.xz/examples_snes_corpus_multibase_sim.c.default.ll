; ModuleID = '/work/examples/snes/corpus/multibase_sim.c'
source_filename = "/work/examples/snes/corpus/multibase_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.lldiv_t = type { i64, i64 }
%struct.div_t = type { i16, i16 }

@corpus_result = dso_local global i16 0, align 1
@MB_BASES = internal unnamed_addr constant [4 x i8] c"\0A\0C\10<", align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca %struct.lldiv_t, align 1
  %2 = alloca [6 x i8], align 1
  %3 = alloca [12 x i8], align 1
  %4 = getelementptr inbounds nuw i8, ptr %1, i16 8
  br label %5

5:                                                ; preds = %104, %0
  %6 = phi i16 [ 0, %0 ], [ %105, %104 ]
  %7 = phi i64 [ 1, %0 ], [ %67, %104 ]
  %8 = phi i16 [ 0, %0 ], [ %106, %104 ]
  %9 = mul nuw nsw i16 %8, 271
  %10 = add nuw nsw i16 %9, 13
  br label %15

11:                                               ; preds = %44
  %12 = mul i64 %7, 3
  %13 = add i64 %12, 7
  %14 = icmp ugt i64 %13, 999999999999999999
  br i1 %14, label %65, label %66

15:                                               ; preds = %44, %5
  %16 = phi i16 [ %6, %5 ], [ %46, %44 ]
  %17 = phi i8 [ 0, %5 ], [ %47, %44 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #6
  %18 = zext nneg i8 %17 to i16
  %19 = getelementptr i8, ptr @MB_BASES, i16 %18
  %20 = load i8, ptr %19, align 1, !tbaa !6
  %21 = zext i8 %20 to i16
  br label %24

22:                                               ; preds = %24
  %23 = icmp eq i8 %33, 6
  br i1 %23, label %42, label %24, !llvm.loop !7

24:                                               ; preds = %15, %22
  %25 = phi i16 [ %10, %15 ], [ %28, %22 ]
  %26 = phi i8 [ 0, %15 ], [ %33, %22 ]
  %27 = call fastcc { i16, i16 } @mb_div(i16 noundef %25, i16 noundef %21) #7
  %28 = extractvalue { i16, i16 } %27, 0
  %29 = extractvalue { i16, i16 } %27, 1
  %30 = trunc i16 %29 to i8
  %31 = zext nneg i8 %26 to i16
  %32 = getelementptr i8, ptr %2, i16 %31
  store i8 %30, ptr %32, align 1, !tbaa !6
  %33 = add nuw nsw i8 %26, 1
  %34 = icmp eq i16 %28, 0
  br i1 %34, label %35, label %22, !llvm.loop !7

35:                                               ; preds = %24
  %36 = icmp samesign ult i8 %26, 5
  br i1 %36, label %37, label %42

37:                                               ; preds = %35
  %38 = zext nneg i8 %33 to i16
  %39 = getelementptr i8, ptr %2, i16 %38
  %40 = sub nuw nsw i8 5, %26
  %41 = zext nneg i8 %40 to i16
  call void @llvm.memset.p0.i16(ptr align 1 %39, i8 0, i16 %41, i1 false), !tbaa !6
  br label %42

42:                                               ; preds = %22, %37, %35
  %43 = phi i8 [ %33, %35 ], [ %33, %37 ], [ 6, %22 ]
  br label %49

44:                                               ; preds = %49
  %45 = call i16 @llvm.fshl.i16(i16 %62, i16 %62, i16 1)
  %46 = xor i16 %45, %59
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #6
  %47 = add nuw nsw i8 %17, 1
  %48 = icmp eq i8 %47, 4
  br i1 %48, label %11, label %15, !llvm.loop !9

49:                                               ; preds = %49, %42
  %50 = phi i16 [ %16, %42 ], [ %62, %49 ]
  %51 = phi i8 [ 0, %42 ], [ %63, %49 ]
  %52 = phi i16 [ 1, %42 ], [ %60, %49 ]
  %53 = phi i16 [ 0, %42 ], [ %59, %49 ]
  %54 = zext i8 %51 to i16
  %55 = getelementptr i8, ptr %2, i16 %54
  %56 = load i8, ptr %55, align 1, !tbaa !6
  %57 = zext i8 %56 to i16
  %58 = mul i16 %52, %57
  %59 = add i16 %58, %53
  %60 = mul i16 %52, %21
  %61 = call i16 @llvm.fshl.i16(i16 %50, i16 %50, i16 1)
  %62 = xor i16 %61, %57
  %63 = add nuw i8 %51, 1
  %64 = icmp eq i8 %63, %43
  br i1 %64, label %44, label %49, !llvm.loop !10

65:                                               ; preds = %11
  br label %66

66:                                               ; preds = %65, %11
  %67 = phi i64 [ 1, %65 ], [ %13, %11 ]
  %68 = and i16 %8, 3
  %69 = icmp eq i16 %68, 0
  br i1 %69, label %70, label %104

70:                                               ; preds = %66
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #6
  br label %73

71:                                               ; preds = %73
  %72 = icmp eq i8 %81, 12
  br i1 %72, label %90, label %73, !llvm.loop !11

73:                                               ; preds = %70, %71
  %74 = phi i64 [ %67, %70 ], [ %80, %71 ]
  %75 = phi i8 [ 0, %70 ], [ %81, %71 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #6
  call void @lldiv(ptr dead_on_unwind nonnull writable sret(%struct.lldiv_t) align 1 %1, i64 noundef %74, i64 noundef 10) #8
  %76 = load i64, ptr %4, align 1, !tbaa !12
  %77 = trunc i64 %76 to i8
  %78 = zext nneg i8 %75 to i16
  %79 = getelementptr i8, ptr %3, i16 %78
  store i8 %77, ptr %79, align 1, !tbaa !6
  %80 = load i64, ptr %1, align 1, !tbaa !15
  %81 = add nuw nsw i8 %75, 1
  %82 = icmp eq i64 %80, 0
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #6
  br i1 %82, label %83, label %71, !llvm.loop !11

83:                                               ; preds = %73
  %84 = icmp samesign ult i8 %75, 11
  br i1 %84, label %85, label %90

85:                                               ; preds = %83
  %86 = zext nneg i8 %81 to i16
  %87 = getelementptr i8, ptr %3, i16 %86
  %88 = sub nuw nsw i8 11, %75
  %89 = zext nneg i8 %88 to i16
  call void @llvm.memset.p0.i16(ptr align 1 %87, i8 0, i16 %89, i1 false), !tbaa !6
  br label %90

90:                                               ; preds = %71, %85, %83
  %91 = phi i8 [ %81, %83 ], [ %81, %85 ], [ 12, %71 ]
  br label %93

92:                                               ; preds = %93
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #6
  br label %104

93:                                               ; preds = %93, %90
  %94 = phi i8 [ 0, %90 ], [ %102, %93 ]
  %95 = phi i16 [ %46, %90 ], [ %101, %93 ]
  %96 = zext i8 %94 to i16
  %97 = getelementptr i8, ptr %3, i16 %96
  %98 = load i8, ptr %97, align 1, !tbaa !6
  %99 = zext i8 %98 to i16
  %100 = call i16 @llvm.fshl.i16(i16 %95, i16 %95, i16 1)
  %101 = xor i16 %100, %99
  %102 = add nuw i8 %94, 1
  %103 = icmp eq i8 %102, %91
  br i1 %103, label %92, label %93, !llvm.loop !16

104:                                              ; preds = %92, %66
  %105 = phi i16 [ %101, %92 ], [ %46, %66 ]
  %106 = add nuw nsw i16 %8, 1
  %107 = icmp eq i16 %106, 60
  br i1 %107, label %108, label %5, !llvm.loop !17

108:                                              ; preds = %104
  store volatile i16 %105, ptr @corpus_result, align 1, !tbaa !2
  br label %109

109:                                              ; preds = %109, %108
  call void asm sideeffect "wai", ""() #6, !srcloc !18
  br label %109
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: noinline nounwind optsize
define internal fastcc { i16, i16 } @mb_div(i16 noundef %0, i16 noundef range(i16 0, 256) %1) unnamed_addr #2 {
  %3 = tail call %struct.div_t @div(i16 noundef %0, i16 noundef %1) #8
  %4 = extractvalue %struct.div_t %3, 0
  %5 = insertvalue { i16, i16 } poison, i16 %4, 0
  %6 = extractvalue %struct.div_t %3, 1
  %7 = insertvalue { i16, i16 } %5, i16 %6, 1
  ret { i16, i16 } %7
}

; Function Attrs: optsize
declare dso_local %struct.div_t @div(i16 noundef, i16 noundef) local_unnamed_addr #3

; Function Attrs: optsize
declare dso_local void @lldiv(ptr dead_on_unwind writable sret(%struct.lldiv_t) align 1, i64 noundef, i64 noundef) local_unnamed_addr #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #5

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noinline nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #3 = { optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #6 = { nounwind }
attributes #7 = { optsize }
attributes #8 = { nounwind optsize }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = distinct !{!9, !8}
!10 = distinct !{!10, !8}
!11 = distinct !{!11, !8}
!12 = !{!13, !14, i64 8}
!13 = !{!"", !14, i64 0, !14, i64 8}
!14 = !{!"long long", !4, i64 0}
!15 = !{!13, !14, i64 0}
!16 = distinct !{!16, !8}
!17 = distinct !{!17, !8}
!18 = !{i64 354}
