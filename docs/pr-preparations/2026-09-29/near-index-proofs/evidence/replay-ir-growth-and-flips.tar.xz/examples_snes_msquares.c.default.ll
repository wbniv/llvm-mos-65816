; ModuleID = '/work/examples/snes/msquares.c'
source_filename = "/work/examples/snes/msquares.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.App = type { %struct.Display, %struct.BitmapCanvas, %struct.TextLayer, i16, [1089 x i16] }
%struct.Display = type { %struct.UploadQueue, %struct.VramAlloc, %struct.Scene, i8, i8, i8, i8, i8 }
%struct.UploadQueue = type { [16 x %struct.UpqJob], i8, i8 }
%struct.UpqJob = type { i16, i16, i16, i8, i8, i8, i8, i8 }
%struct.VramAlloc = type { i16, i16 }
%struct.Scene = type { [4 x ptr], i8 }
%struct.BitmapCanvas = type { %struct.Drawable, [4096 x i8], i16, i16, i16, i16, i8, i8 }
%struct.Drawable = type { ptr, i8 }
%struct.TextLayer = type { %struct.Drawable, i16, [2 x i8], [64 x i16], i8 }
%struct.TitleLayer = type { %struct.Drawable, ptr, ptr, ptr, ptr, i8, i8, i16, i16, i16, i16, i16, i16, i8, i16, i8, i8, i8, i8, i8, i8, i16, i16, %struct.HScrollDB, %struct.HScrollDB }
%struct.HScrollDB = type { [2 x %struct.HScrollN], i8 }
%struct.HScrollN = type { [25 x i8] }
%struct.DrawableVT = type { ptr, ptr }
%struct.HScrollW = type { ptr, i8 }

@main.a = internal global %struct.App zeroinitializer, align 1
@main.title = internal global %struct.TitleLayer zeroinitializer, align 1
@.str = private unnamed_addr constant [9 x i8] c"CONTOURS\00", align 1
@.str.1 = private unnamed_addr constant [17 x i8] c"MARCHING SQUARES\00", align 1
@corpus_result = dso_local global i16 0, align 1
@bg3_pal = internal constant [4 x i16] [i16 6209, i16 22854, i16 29258, i16 21500], align 1
@.str.2 = private unnamed_addr constant [31 x i8] c"16-CASE EDGE LUT + EDGE INTERP\00", align 1
@CANVAS_VT = internal constant %struct.DrawableVT { ptr @_canvas_reserve, ptr @_canvas_emit }, align 1
@TEXT_VT = internal constant %struct.DrawableVT { ptr @_text_reserve, ptr @_text_emit }, align 1
@FONT8 = internal unnamed_addr constant [512 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 32, i16 0, i16 80, i16 80, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 80, i16 80, i16 248, i16 80, i16 248, i16 80, i16 80, i16 0, i16 32, i16 120, i16 160, i16 112, i16 40, i16 240, i16 32, i16 0, i16 196, i16 200, i16 16, i16 32, i16 64, i16 152, i16 12, i16 0, i16 96, i16 144, i16 160, i16 64, i16 168, i16 144, i16 104, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 16, i16 32, i16 64, i16 64, i16 64, i16 32, i16 16, i16 0, i16 64, i16 32, i16 16, i16 16, i16 16, i16 32, i16 64, i16 0, i16 0, i16 32, i16 168, i16 112, i16 168, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 248, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 64, i16 0, i16 0, i16 0, i16 248, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 0, i16 8, i16 8, i16 16, i16 32, i16 64, i16 128, i16 128, i16 0, i16 112, i16 136, i16 152, i16 168, i16 200, i16 136, i16 112, i16 0, i16 32, i16 96, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 64, i16 248, i16 0, i16 112, i16 136, i16 8, i16 48, i16 8, i16 136, i16 112, i16 0, i16 16, i16 48, i16 80, i16 144, i16 248, i16 16, i16 16, i16 0, i16 248, i16 128, i16 240, i16 8, i16 8, i16 136, i16 112, i16 0, i16 112, i16 136, i16 128, i16 240, i16 136, i16 136, i16 112, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 64, i16 64, i16 0, i16 112, i16 136, i16 136, i16 112, i16 136, i16 136, i16 112, i16 0, i16 112, i16 136, i16 136, i16 120, i16 8, i16 136, i16 112, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 64, i16 0, i16 16, i16 32, i16 64, i16 128, i16 64, i16 32, i16 16, i16 0, i16 0, i16 0, i16 248, i16 0, i16 248, i16 0, i16 0, i16 0, i16 128, i16 64, i16 32, i16 16, i16 32, i16 64, i16 128, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 0, i16 32, i16 0, i16 112, i16 136, i16 184, i16 168, i16 184, i16 128, i16 112, i16 0, i16 112, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 240, i16 136, i16 136, i16 240, i16 136, i16 136, i16 240, i16 0, i16 112, i16 136, i16 128, i16 128, i16 128, i16 136, i16 112, i16 0, i16 224, i16 144, i16 136, i16 136, i16 136, i16 144, i16 224, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 248, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 128, i16 176, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 112, i16 32, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 56, i16 16, i16 16, i16 16, i16 144, i16 144, i16 96, i16 0, i16 136, i16 144, i16 160, i16 192, i16 160, i16 144, i16 136, i16 0, i16 128, i16 128, i16 128, i16 128, i16 128, i16 128, i16 248, i16 0, i16 136, i16 216, i16 168, i16 136, i16 136, i16 136, i16 136, i16 0, i16 136, i16 200, i16 168, i16 152, i16 136, i16 136, i16 136, i16 0, i16 112, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 240, i16 136, i16 136, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 136, i16 136, i16 168, i16 144, i16 104, i16 0, i16 240, i16 136, i16 136, i16 240, i16 160, i16 144, i16 136, i16 0, i16 112, i16 136, i16 128, i16 112, i16 8, i16 136, i16 112, i16 0, i16 248, i16 32, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 80, i16 32, i16 0, i16 136, i16 136, i16 136, i16 168, i16 168, i16 216, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 80, i16 136, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 32, i16 32, i16 32, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 128, i16 248, i16 0, i16 48, i16 32, i16 32, i16 32, i16 32, i16 32, i16 48, i16 0, i16 128, i16 128, i16 64, i16 32, i16 16, i16 8, i16 8, i16 0, i16 48, i16 16, i16 16, i16 16, i16 16, i16 16, i16 48, i16 0, i16 32, i16 80, i16 136, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248], align 1
@TITLE_VT = internal constant %struct.DrawableVT { ptr @_title_reserve, ptr @_title_emit }, align 1
@FONT16 = internal unnamed_addr constant [2048 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 192, i16 192, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 768, i16 768, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 -4096, i16 -4096, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3840, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 3312, i16 15360, i16 15360, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 28, i16 28, i16 796, i16 127, i16 127, i16 796, i16 796, i16 127, i16 112, i16 112, i16 3184, i16 252, i16 252, i16 -28816, i16 -28816, i16 252, i16 127, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 0, i16 0, i16 252, i16 -28816, i16 -28816, i16 3184, i16 7168, i16 7168, i16 0, i16 0, i16 3, i16 63, i16 123, i16 1147, i16 63, i16 4111, i16 3075, i16 123, i16 192, i16 248, i16 8414, i16 16064, i16 2040, i16 248, i16 8414, i16 8414, i16 63, i16 7171, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 2040, i16 14272, i16 -512, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3585, i16 3, i16 7, i16 28, i16 56, i16 1904, i16 3808, i16 7392, i16 14528, i16 14464, i16 28672, i16 14, i16 284, i16 824, i16 1792, i16 3584, i16 0, i16 0, i16 0, i16 -8162, i16 -16354, i16 -32482, i16 286, i16 1792, i16 1792, i16 0, i16 0, i16 15, i16 31, i16 828, i16 828, i16 573, i16 31, i16 31, i16 63, i16 192, i16 224, i16 240, i16 2288, i16 7392, i16 15488, i16 30720, i16 -32648, i16 382, i16 3060, i16 3825, i16 1275, i16 127, i16 63, i16 7936, i16 3840, i16 248, i16 3824, i16 7904, i16 7392, i16 4332, i16 12492, i16 -1280, i16 -3328, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 7, i16 15, i16 15, i16 15, i16 15, i16 15, i16 240, i16 192, i16 15488, i16 -4096, i16 -8192, i16 -16384, i16 -16384, i16 -16384, i16 15, i16 7, i16 3, i16 256, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 16512, i16 192, i16 240, i16 -4096, i16 15360, i16 0, i16 0, i16 15, i16 3, i16 513, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 224, i16 240, i16 2288, i16 3312, i16 3312, i16 3312, i16 0, i16 1, i16 3, i16 15, i16 0, i16 768, i16 0, i16 0, i16 3312, i16 7392, i16 15552, i16 30720, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 51, i16 31, i16 15, i16 1027, i16 0, i16 0, i16 192, i16 192, i16 12492, i16 252, i16 1016, i16 16320, i16 15, i16 31, i16 51, i16 1027, i16 3072, i16 0, i16 0, i16 0, i16 1784, i16 252, i16 13004, i16 16320, i16 -3328, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 3, i16 63, i16 63, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 248, i16 248, i16 63, i16 3075, i16 3075, i16 3, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 16064, i16 16064, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 286, i16 828, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 28800, i16 -4096, i16 -8192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 -512, i16 -512, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7360, i16 14464, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7168, i16 14336, i16 28672, i16 -8192, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 828, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 15, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 1, i16 3, i16 15, i16 15, i16 513, i16 513, i16 1, i16 1, i16 240, i16 240, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 1, i16 1, i16 1, i16 1, i16 1, i16 1, i16 0, i16 0, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 31744, i16 31744, i16 15, i16 31, i16 318, i16 828, i16 3840, i16 3840, i16 3, i16 15, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 63, i16 510, i16 4080, i16 31, i16 318, i16 318, i16 318, i16 63, i16 63, i16 3840, i16 3840, i16 32640, i16 -1024, i16 -8192, i16 -32768, i16 255, i16 255, i16 -256, i16 -256, i16 15, i16 63, i16 824, i16 3840, i16 2055, i16 7, i16 256, i16 256, i16 252, i16 254, i16 -8161, i16 -4081, i16 510, i16 1020, i16 -7906, i16 -4081, i16 0, i16 0, i16 56, i16 60, i16 63, i16 31, i16 3840, i16 1792, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 15, i16 286, i16 62, i16 126, i16 510, i16 510, i16 8670, i16 24990, i16 -7906, i16 -7906, i16 828, i16 828, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 -16098, i16 -32482, i16 255, i16 255, i16 -7906, i16 -7906, i16 1792, i16 1792, i16 31, i16 63, i16 828, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 254, i16 254, i16 -256, i16 -256, i16 252, i16 254, i16 -8161, i16 -4081, i16 0, i16 0, i16 60, i16 62, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 63, i16 63, i16 318, i16 828, i16 254, i16 255, i16 -2041, i16 -256, i16 508, i16 254, i16 -4081, i16 -2041, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 -32761, i16 7, i16 7, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 31, i16 318, i16 892, i16 0, i16 1, i16 3, i16 7, i16 7, i16 7, i16 256, i16 256, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 28800, i16 -8192, i16 -8192, i16 15, i16 31, i16 828, i16 828, i16 828, i16 31, i16 15, i16 796, i16 252, i16 254, i16 -4081, i16 -4081, i16 15, i16 510, i16 1020, i16 -3826, i16 828, i16 828, i16 828, i16 828, i16 31, i16 15, i16 1792, i16 768, i16 -4081, i16 15, i16 15, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 318, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 31, i16 31, i16 15, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 270, i16 796, i16 824, i16 1792, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 15, i16 60, i16 828, i16 0, i16 0, i16 60, i16 240, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 15360, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 60, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 60, i16 0, i16 3, i16 15, i16 60, i16 768, i16 3840, i16 0, i16 0, i16 4080, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 31, i16 63, i16 828, i16 3840, i16 3840, i16 7, i16 7, i16 7, i16 240, i16 248, i16 -32644, i16 -32132, i16 2040, i16 4080, i16 16064, i16 31872, i16 256, i16 256, i16 7, i16 7, i16 7, i16 256, i16 256, i16 0, i16 -4096, i16 -8192, i16 128, i16 128, i16 24704, i16 -8192, i16 -8192, i16 0, i16 31, i16 63, i16 828, i16 573, i16 573, i16 573, i16 573, i16 573, i16 248, i16 252, i16 -15812, i16 4590, i16 494, i16 4590, i16 1020, i16 1016, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 0, i16 0, i16 0, i16 32512, i16 764, i16 248, i16 -256, i16 -512, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 892, i16 1020, i16 1020, i16 255, i16 255, i16 224, i16 240, i16 -32648, i16 -16324, i16 -32196, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -28928, i16 1792, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 0, i16 0, i16 28, i16 60, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -8164, i16 -3572, i16 -30976, i16 768, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 8988, i16 8988, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 60, i16 60, i16 828, i16 828, i16 828, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 255, i16 255, i16 16128, i16 16128, i16 12480, i16 12480, i16 12480, i16 12480, i16 252, i16 252, i16 -256, i16 -256, i16 63, i16 63, i16 3075, i16 3075, i16 3, i16 3, i16 51, i16 51, i16 252, i16 252, i16 4080, i16 4080, i16 3312, i16 3312, i16 3312, i16 3312, i16 3123, i16 3123, i16 63, i16 63, i16 31, i16 15, i16 1792, i16 768, i16 3312, i16 3312, i16 3312, i16 3312, i16 7392, i16 15552, i16 -2048, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 765, i16 255, i16 255, i16 255, i16 28, i16 60, i16 1912, i16 4080, i16 7904, i16 15552, i16 30848, i16 12480, i16 255, i16 765, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 224, i16 240, i16 248, i16 124, i16 572, i16 828, i16 3840, i16 3840, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 0, i16 0, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 248, i16 252, i16 254, i16 2295, i16 3315, i16 3315, i16 3315, i16 3315, i16 60, i16 124, i16 1020, i16 988, i16 9116, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 15360, i16 15360, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 -6400, i16 -6400, i16 240, i16 248, i16 252, i16 254, i16 255, i16 255, i16 2295, i16 3315, i16 60, i16 60, i16 828, i16 828, i16 828, i16 956, i16 1020, i16 1020, i16 3313, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 15360, i16 15360, i16 1020, i16 1020, i16 892, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -31972, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -512, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 224, i16 240, i16 -32648, i16 -15304, i16 -31176, i16 1592, i16 1592, i16 1592, i16 765, i16 765, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 1784, i16 1784, i16 17976, i16 1656, i16 764, i16 764, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 63, i16 127, i16 2040, i16 4080, i16 1784, i16 255, i16 127, i16 63, i16 248, i16 252, i16 -15812, i16 -256, i16 3840, i16 240, i16 248, i16 252, i16 7936, i16 3840, i16 224, i16 255, i16 255, i16 127, i16 16128, i16 7936, i16 -32132, i16 -15556, i16 892, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 -4096, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 28, i16 28, i16 796, i16 796, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 510, i16 255, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 828, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 248, i16 248, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 124, i16 124, i16 1912, i16 1912, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 572, i16 63, i16 31, i16 15, i16 7, i16 768, i16 256, i16 1656, i16 3824, i16 3824, i16 7392, i16 15552, i16 30848, i16 -4096, i16 -8192, i16 243, i16 243, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 156, i16 156, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 2295, i16 255, i16 510, i16 892, i16 16128, i16 7936, i16 25500, i16 25500, i16 9180, i16 1020, i16 1020, i16 -30856, i16 -16640, i16 7680, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 15, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 14528, i16 31, i16 63, i16 892, i16 2040, i16 4080, i16 3824, i16 15360, i16 15360, i16 4320, i16 240, i16 248, i16 -32644, i16 572, i16 828, i16 3840, i16 3840, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 7, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 7, i16 7, i16 7, i16 7, i16 7, i16 7, i16 256, i16 256, i16 28800, i16 24704, i16 24704, i16 24704, i16 24704, i16 24704, i16 -8192, i16 -8192, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 1, i16 3, i16 7, i16 252, i16 252, i16 1020, i16 -31876, i16 2040, i16 4080, i16 7904, i16 15552, i16 15, i16 31, i16 318, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 30848, i16 -4096, i16 -8192, i16 252, i16 252, i16 1020, i16 -256, i16 -256, i16 31, i16 31, i16 286, i16 286, i16 286, i16 286, i16 286, i16 286, i16 224, i16 224, i16 -2048, i16 -2048, i16 -32768, i16 -32768, i16 -32768, i16 -32768, i16 286, i16 286, i16 286, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 -32768, i16 -32768, i16 -32768, i16 224, i16 224, i16 -2048, i16 -2048, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 3, i16 1, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 128, i16 192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 768, i16 256, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 0, i16 0, i16 0, i16 224, i16 224, i16 2288, i16 2288, i16 3312, i16 3312, i16 3312, i16 3312, i16 0, i16 0, i16 0, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 3312, i16 3312, i16 3312, i16 7392, i16 7392, i16 -2048, i16 -2048, i16 0, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1840, i16 3584, i16 3072, i16 192, i16 224, i16 -32656, i16 -16328, i16 -32740, i16 524, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 127, i16 127, i16 7936, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 -512], align 1
@msquares_gate_crc.vg = internal unnamed_addr global [289 x i16] zeroinitializer, align 1
@MS_SEG = internal unnamed_addr constant [16 x [4 x i8]] [[4 x i8] c"\FF\FF\FF\FF", [4 x i8] c"\03\02\FF\FF", [4 x i8] c"\01\02\FF\FF", [4 x i8] c"\03\01\FF\FF", [4 x i8] c"\00\01\FF\FF", [4 x i8] c"\00\03\01\02", [4 x i8] c"\00\02\FF\FF", [4 x i8] c"\00\03\FF\FF", [4 x i8] c"\00\03\FF\FF", [4 x i8] c"\00\02\FF\FF", [4 x i8] c"\00\01\03\02", [4 x i8] c"\00\01\FF\FF", [4 x i8] c"\03\01\FF\FF", [4 x i8] c"\01\02\FF\FF", [4 x i8] c"\03\02\FF\FF", [4 x i8] c"\FF\FF\FF\FF"], align 1
@title_end._title_bg_black = internal constant i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [3 x i16], align 1
  %2 = alloca [3 x i16], align 1
  %3 = alloca i16, align 1
  %4 = alloca i16, align 1
  %5 = alloca i16, align 1
  %6 = alloca i16, align 1
  store volatile i8 -113, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  br label %7

7:                                                ; preds = %11, %0
  %8 = phi i16 [ 8449, %0 ], [ %12, %11 ]
  switch i16 %8, label %9 [
    i16 8452, label %11
    i16 8470, label %11
    i16 8471, label %11
    i16 8472, label %11
    i16 8473, label %11
    i16 8481, label %11
    i16 8482, label %11
  ]

9:                                                ; preds = %7
  %10 = inttoptr i16 %8 to ptr
  store volatile i8 0, ptr %10, align 1, !tbaa !6
  br label %11

11:                                               ; preds = %9, %7, %7, %7, %7, %7, %7, %7
  %12 = add nuw nsw i16 %8, 1
  %13 = icmp eq i16 %12, 8500
  br i1 %13, label %14, label %7, !llvm.loop !7

14:                                               ; preds = %11
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) getelementptr inbounds nuw (i8, ptr @main.a, i16 176), i8 0, i64 6, i1 false)
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  store volatile i8 1, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 -127, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !6
  store ptr @CANVAS_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), align 1, !tbaa !15
  store i8 4, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !19
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4299), align 1, !tbaa !20
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4301), align 1, !tbaa !21
  store i8 8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4303), align 1, !tbaa !22
  store i8 6, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4304), align 1, !tbaa !23
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(4096) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i16 4096, i1 false), !tbaa !6
  store i16 -1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  store ptr @TEXT_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !26
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !28
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4308), align 1, !tbaa !29
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4310), align 1, !tbaa !6
  store i8 25, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4311), align 1, !tbaa !6
  br label %15

15:                                               ; preds = %15, %14
  %16 = phi i8 [ 0, %14 ], [ %22, %15 ]
  %17 = phi i16 [ 0, %14 ], [ %20, %15 ]
  %18 = zext i8 %16 to i16
  %19 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4312), i16 %18
  store i16 256, ptr %19, align 1, !tbaa !2
  %20 = add nuw nsw i16 %17, 1
  %21 = icmp eq i16 %20, 64
  %22 = add nuw i8 %16, 2
  br i1 %21, label %23, label %15, !llvm.loop !30

23:                                               ; preds = %15
  store i8 3, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %24 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %25 = icmp eq i8 %24, 0
  br i1 %25, label %27, label %26

26:                                               ; preds = %23
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %27

27:                                               ; preds = %26, %23
  %28 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %29 = icmp ult i8 %28, 4
  br i1 %29, label %30, label %34

30:                                               ; preds = %27
  %31 = zext nneg i8 %28 to i16
  %32 = add nuw nsw i8 %28, 1
  store i8 %32, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %33 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %31
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr %33, align 1, !tbaa !35
  br label %34

34:                                               ; preds = %30, %27
  tail call void @_canvas_reserve(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr nonnull poison) #13, !inline_history !37
  %35 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %36 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !39
  %37 = or i8 %36, %35
  store i8 %37, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %37, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %38 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %39 = icmp eq i8 %38, 0
  br i1 %39, label %41, label %40

40:                                               ; preds = %34
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %41

41:                                               ; preds = %40, %34
  %42 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %43 = icmp ult i8 %42, 4
  br i1 %43, label %44, label %48

44:                                               ; preds = %41
  %45 = zext nneg i8 %42 to i16
  %46 = add nuw nsw i8 %42, 1
  store i8 %46, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %47 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %45
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr %47, align 1, !tbaa !35
  br label %48

48:                                               ; preds = %44, %41
  %49 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !40
  %50 = load ptr, ptr %49, align 1, !tbaa !41
  tail call void %50(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 178)) #13, !inline_history !43
  %51 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %52 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !39
  %53 = or i8 %52, %51
  store i8 %53, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %53, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %54 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %55 = icmp ugt i8 %54, 15
  br i1 %55, label %67, label %56

56:                                               ; preds = %48
  %57 = zext nneg i8 %54 to i16
  %58 = add nuw nsw i8 %54, 1
  store i8 %58, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %59 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %57
  %60 = getelementptr inbounds nuw i8, ptr %59, i16 10
  store i8 1, ptr %60, align 1, !tbaa !45
  store i16 0, ptr %59, align 1, !tbaa !47
  %61 = getelementptr inbounds nuw i8, ptr %59, i16 9
  store i8 0, ptr %61, align 1, !tbaa !48
  %62 = getelementptr inbounds nuw i8, ptr %59, i16 7
  store i8 34, ptr %62, align 1, !tbaa !49
  %63 = getelementptr inbounds nuw i8, ptr %59, i16 8
  store i8 0, ptr %63, align 1, !tbaa !50
  %64 = getelementptr inbounds nuw i8, ptr %59, i16 2
  store i16 ptrtoint (ptr @bg3_pal to i16), ptr %64, align 1, !tbaa !51
  %65 = getelementptr inbounds nuw i8, ptr %59, i16 6
  store i8 0, ptr %65, align 1, !tbaa !52
  %66 = getelementptr inbounds nuw i8, ptr %59, i16 4
  store i16 8, ptr %66, align 1, !tbaa !53
  br label %67

67:                                               ; preds = %56, %48
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !54
  br label %68

68:                                               ; preds = %78, %67
  %69 = phi i8 [ 0, %67 ], [ %86, %78 ]
  %70 = phi i8 [ 0, %67 ], [ %85, %78 ]
  %71 = phi i8 [ 77, %67 ], [ %84, %78 ]
  %72 = zext i8 %71 to i16
  %73 = icmp ugt i8 %71, 31
  br i1 %73, label %74, label %78

74:                                               ; preds = %68
  %75 = icmp ult i8 %71, 96
  br i1 %75, label %76, label %78

76:                                               ; preds = %74
  %77 = add nuw nsw i16 %72, 224
  br label %78

78:                                               ; preds = %76, %74, %68
  %79 = phi i16 [ %77, %76 ], [ 256, %74 ], [ 256, %68 ]
  %80 = zext nneg i8 %70 to i16
  %81 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4314), i16 %80
  store i16 %79, ptr %81, align 1, !tbaa !2
  %82 = zext nneg i8 %69 to i16
  %83 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @.str.1, i16 1), i16 %82
  %84 = load i8, ptr %83, align 1, !tbaa !6
  %85 = add nuw nsw i8 %70, 2
  %86 = add nuw nsw i8 %69, 1
  %87 = icmp eq i8 %86, 16
  br i1 %87, label %88, label %68, !llvm.loop !56

88:                                               ; preds = %78
  %89 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  br label %90

90:                                               ; preds = %100, %88
  %91 = phi i8 [ 0, %88 ], [ %106, %100 ]
  %92 = phi i8 [ 0, %88 ], [ %108, %100 ]
  %93 = phi i8 [ 49, %88 ], [ %107, %100 ]
  %94 = zext i8 %93 to i16
  %95 = icmp ugt i8 %93, 31
  br i1 %95, label %96, label %100

96:                                               ; preds = %90
  %97 = icmp ult i8 %93, 96
  br i1 %97, label %98, label %100

98:                                               ; preds = %96
  %99 = add nuw nsw i16 %94, 224
  br label %100

100:                                              ; preds = %98, %96, %90
  %101 = phi i16 [ %99, %98 ], [ 256, %96 ], [ 256, %90 ]
  %102 = zext nneg i8 %92 to i16
  %103 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4376), i16 %102
  store i16 %101, ptr %103, align 1, !tbaa !2
  %104 = zext nneg i8 %91 to i16
  %105 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @.str.2, i16 1), i16 %104
  %106 = add nuw nsw i8 %91, 1
  %107 = load i8, ptr %105, align 1, !tbaa !6
  %108 = add nuw nsw i8 %92, 2
  %109 = icmp eq i8 %106, 30
  br i1 %109, label %110, label %90, !llvm.loop !56

110:                                              ; preds = %100
  %111 = or i8 %89, 3
  store i8 %111, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  store ptr @TITLE_VT, ptr @main.title, align 1, !tbaa !57
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !61
  store ptr @.str, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 3), align 1, !tbaa !62
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 5), align 1, !tbaa !63
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 7), align 1, !tbaa !64
  store i8 16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 11), align 1, !tbaa !65
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 9), align 1, !tbaa !66
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 12), align 1, !tbaa !67
  store i16 96, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 13), align 1, !tbaa !68
  store i16 112, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 15), align 1, !tbaa !69
  store i16 16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 17), align 1, !tbaa !70
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 28), align 1, !tbaa !71
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !72
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !73
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !74
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !75
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !76
  store i16 32767, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 34), align 1, !tbaa !77
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 36), align 1, !tbaa !78
  %112 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %113 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %114 = icmp eq i8 %113, 0
  br i1 %114, label %116, label %115

115:                                              ; preds = %110
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %116

116:                                              ; preds = %115, %110
  %117 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %118 = icmp ult i8 %117, 4
  br i1 %118, label %119, label %123

119:                                              ; preds = %116
  %120 = zext nneg i8 %117 to i16
  %121 = add nuw nsw i8 %117, 1
  store i8 %121, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %122 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %120
  store ptr @main.title, ptr %122, align 1, !tbaa !35
  br label %123

123:                                              ; preds = %119, %116
  tail call void @_title_reserve(ptr noundef nonnull @main.title, ptr nonnull poison) #13, !inline_history !37
  %124 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %125 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %126 = or i8 %125, %124
  store volatile i8 %126, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store i8 %112, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !79
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 2, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 24, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  br label %127

127:                                              ; preds = %155, %123
  %128 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %129 = icmp eq i8 %128, 0
  br i1 %129, label %141, label %130

130:                                              ; preds = %127, %130
  %131 = phi i8 [ %138, %130 ], [ 0, %127 ]
  %132 = zext i8 %131 to i16
  %133 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %132
  %134 = load ptr, ptr %133, align 1, !tbaa !35
  %135 = load ptr, ptr %134, align 1, !tbaa !40
  %136 = getelementptr inbounds nuw i8, ptr %135, i16 2
  %137 = load ptr, ptr %136, align 1, !tbaa !80
  tail call void %137(ptr noundef nonnull %134, ptr noundef nonnull @main.a) #13, !inline_history !81
  %138 = add nuw i8 %131, 1
  %139 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %140 = icmp ult i8 %138, %139
  br i1 %140, label %130, label %141, !llvm.loop !82

141:                                              ; preds = %130, %127
  %142 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %143

143:                                              ; preds = %143, %141
  %144 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %145 = icmp sgt i8 %144, -1
  br i1 %145, label %143, label %146, !llvm.loop !83

146:                                              ; preds = %143
  tail call fastcc void @upq_flush() #14
  %147 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %148 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %149 = icmp ult i8 %147, %148
  br i1 %149, label %152, label %150

150:                                              ; preds = %146
  %151 = icmp ugt i8 %147, %148
  br i1 %151, label %152, label %155

152:                                              ; preds = %150, %146
  %153 = phi i8 [ 1, %146 ], [ -1, %150 ]
  %154 = add i8 %153, %147
  store i8 %154, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %155

155:                                              ; preds = %152, %150
  %156 = phi i8 [ %147, %150 ], [ %154, %152 ]
  %157 = and i8 %156, 15
  store volatile i8 %157, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %158 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %159 = icmp eq i8 %158, 15
  br i1 %159, label %160, label %127, !llvm.loop !84

160:                                              ; preds = %155
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !75
  %161 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !76
  %162 = icmp eq i8 %161, -1
  br i1 %162, label %200, label %163

163:                                              ; preds = %160, %192
  %164 = phi i8 [ %195, %192 ], [ 0, %160 ]
  %165 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %166 = icmp eq i8 %165, 0
  br i1 %166, label %178, label %167

167:                                              ; preds = %163, %167
  %168 = phi i8 [ %175, %167 ], [ 0, %163 ]
  %169 = zext i8 %168 to i16
  %170 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %169
  %171 = load ptr, ptr %170, align 1, !tbaa !35
  %172 = load ptr, ptr %171, align 1, !tbaa !40
  %173 = getelementptr inbounds nuw i8, ptr %172, i16 2
  %174 = load ptr, ptr %173, align 1, !tbaa !80
  tail call void %174(ptr noundef nonnull %171, ptr noundef nonnull @main.a) #13, !inline_history !85
  %175 = add nuw i8 %168, 1
  %176 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %177 = icmp ult i8 %175, %176
  br i1 %177, label %167, label %178, !llvm.loop !82

178:                                              ; preds = %167, %163
  %179 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %180

180:                                              ; preds = %180, %178
  %181 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %182 = icmp sgt i8 %181, -1
  br i1 %182, label %180, label %183, !llvm.loop !83

183:                                              ; preds = %180
  tail call fastcc void @upq_flush() #14
  %184 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %185 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %186 = icmp ult i8 %184, %185
  br i1 %186, label %189, label %187

187:                                              ; preds = %183
  %188 = icmp ugt i8 %184, %185
  br i1 %188, label %189, label %192

189:                                              ; preds = %187, %183
  %190 = phi i8 [ 1, %183 ], [ -1, %187 ]
  %191 = add i8 %190, %184
  store i8 %191, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %192

192:                                              ; preds = %189, %187
  %193 = phi i8 [ %184, %187 ], [ %191, %189 ]
  %194 = and i8 %193, 15
  store volatile i8 %194, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %195 = add nuw i8 %164, 1
  %196 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !76
  %197 = icmp ne i8 %196, -1
  %198 = icmp ult i8 %164, -57
  %199 = select i1 %197, i1 %198, i1 false
  br i1 %199, label %163, label %200, !llvm.loop !86

200:                                              ; preds = %192, %160
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !75
  %201 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %202 = getelementptr inbounds nuw i8, ptr %2, i16 2
  %203 = getelementptr inbounds nuw i8, ptr %1, i16 4
  %204 = getelementptr inbounds nuw i8, ptr %2, i16 4
  br label %205

205:                                              ; preds = %279, %200
  %206 = phi i16 [ 0, %200 ], [ %353, %279 ]
  %207 = phi i1 [ true, %200 ], [ false, %279 ]
  %208 = phi i16 [ 0, %200 ], [ 1, %279 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #15
  %209 = mul nuw nsw i16 %208, 87
  %210 = and i16 %209, 63
  %211 = add nuw nsw i16 %210, 32
  store i16 %211, ptr %1, align 1, !tbaa !2
  %212 = mul nuw nsw i16 %208, 58
  %213 = and i16 %212, 46
  %214 = add nuw nsw i16 %213, 36
  store i16 %214, ptr %2, align 1, !tbaa !2
  %215 = and i16 %212, 54
  %216 = sub nuw nsw i16 97, %215
  store i16 %216, ptr %201, align 1, !tbaa !2
  %217 = and i16 %209, 39
  %218 = add nuw nsw i16 %217, 44
  store i16 %218, ptr %202, align 1, !tbaa !2
  %219 = mul nuw nsw i16 %208, 52
  %220 = and i16 %219, 44
  %221 = add nuw nsw i16 %220, 36
  store i16 %221, ptr %203, align 1, !tbaa !2
  %222 = sub nuw nsw i16 102, %210
  store i16 %222, ptr %204, align 1, !tbaa !2
  br label %223

223:                                              ; preds = %229, %205
  %224 = phi ptr [ @msquares_gate_crc.vg, %205 ], [ %231, %229 ]
  %225 = phi i8 [ 0, %205 ], [ %230, %229 ]
  %226 = zext nneg i8 %225 to i16
  %227 = mul nuw nsw i16 %226, 6
  %228 = add nuw nsw i16 %227, 8
  br label %233

229:                                              ; preds = %264
  %230 = add nuw nsw i8 %225, 1
  %231 = getelementptr i8, ptr %224, i16 34
  %232 = icmp eq i8 %230, 17
  br i1 %232, label %271, label %223, !llvm.loop !87

233:                                              ; preds = %264, %223
  %234 = phi i8 [ 0, %223 ], [ %270, %264 ]
  %235 = phi i8 [ 0, %223 ], [ %268, %264 ]
  %236 = zext nneg i8 %235 to i16
  %237 = mul nuw nsw i16 %236, 6
  %238 = add nuw nsw i16 %237, 8
  br label %239

239:                                              ; preds = %259, %233
  %240 = phi i8 [ 0, %233 ], [ %263, %259 ]
  %241 = phi i32 [ 0, %233 ], [ %260, %259 ]
  %242 = phi i8 [ 0, %233 ], [ %261, %259 ]
  %243 = zext nneg i8 %240 to i16
  %244 = getelementptr i8, ptr %1, i16 %243
  %245 = load i16, ptr %244, align 1, !tbaa !2
  %246 = sub i16 %238, %245
  %247 = sext i16 %246 to i32
  %248 = getelementptr i8, ptr %2, i16 %243
  %249 = load i16, ptr %248, align 1, !tbaa !2
  %250 = sub i16 %228, %249
  %251 = sext i16 %250 to i32
  %252 = mul nsw i32 %247, %247
  %253 = mul nsw i32 %251, %251
  %254 = add nuw nsw i32 %253, %252
  %255 = icmp samesign ult i32 %254, 1600
  br i1 %255, label %256, label %259

256:                                              ; preds = %239
  %257 = add i32 %241, 1600
  %258 = sub i32 %257, %254
  br label %259

259:                                              ; preds = %256, %239
  %260 = phi i32 [ %258, %256 ], [ %241, %239 ]
  %261 = add nuw nsw i8 %242, 1
  %262 = icmp eq i8 %261, 3
  %263 = add nuw nsw i8 %240, 2
  br i1 %262, label %264, label %239, !llvm.loop !88

264:                                              ; preds = %259
  %265 = trunc i32 %260 to i16
  %266 = zext nneg i8 %234 to i16
  %267 = getelementptr i8, ptr %224, i16 %266
  store i16 %265, ptr %267, align 1, !tbaa !2
  %268 = add nuw nsw i8 %235, 1
  %269 = icmp eq i8 %268, 17
  %270 = add nuw nsw i8 %234, 2
  br i1 %269, label %229, label %233, !llvm.loop !89

271:                                              ; preds = %229, %280
  %272 = phi ptr [ %285, %280 ], [ getelementptr inbounds nuw (i8, ptr @msquares_gate_crc.vg, i16 36), %229 ]
  %273 = phi ptr [ %284, %280 ], [ getelementptr inbounds nuw (i8, ptr @msquares_gate_crc.vg, i16 34), %229 ]
  %274 = phi ptr [ %283, %280 ], [ getelementptr inbounds nuw (i8, ptr @msquares_gate_crc.vg, i16 2), %229 ]
  %275 = phi ptr [ %282, %280 ], [ @msquares_gate_crc.vg, %229 ]
  %276 = phi i16 [ %353, %280 ], [ %206, %229 ]
  %277 = phi i8 [ %281, %280 ], [ 0, %229 ]
  %278 = zext nneg i8 %277 to i16
  br label %287

279:                                              ; preds = %280
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #15
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #15
  br i1 %207, label %205, label %354, !llvm.loop !90

280:                                              ; preds = %325
  %281 = add nuw nsw i8 %277, 1
  %282 = getelementptr i8, ptr %275, i16 34
  %283 = getelementptr i8, ptr %274, i16 34
  %284 = getelementptr i8, ptr %273, i16 34
  %285 = getelementptr i8, ptr %272, i16 34
  %286 = icmp eq i8 %281, 16
  br i1 %286, label %279, label %271, !llvm.loop !91

287:                                              ; preds = %325, %271
  %288 = phi i8 [ 0, %271 ], [ %328, %325 ]
  %289 = phi i16 [ %276, %271 ], [ %353, %325 ]
  %290 = phi i8 [ 0, %271 ], [ %326, %325 ]
  %291 = zext nneg i8 %290 to i16
  %292 = zext nneg i8 %288 to i16
  %293 = getelementptr i8, ptr %275, i16 %292
  %294 = load i16, ptr %293, align 1, !tbaa !2
  %295 = sext i16 %294 to i32
  %296 = getelementptr i8, ptr %274, i16 %292
  %297 = load i16, ptr %296, align 1, !tbaa !2
  %298 = sext i16 %297 to i32
  %299 = getelementptr i8, ptr %273, i16 %292
  %300 = getelementptr i8, ptr %272, i16 %292
  %301 = load i16, ptr %300, align 1, !tbaa !2
  %302 = sext i16 %301 to i32
  %303 = load i16, ptr %299, align 1, !tbaa !2
  %304 = sext i16 %303 to i32
  %305 = icmp sgt i16 %294, 699
  %306 = select i1 %305, i8 8, i8 0
  %307 = icmp sgt i16 %297, 699
  %308 = select i1 %307, i8 4, i8 0
  %309 = or disjoint i8 %308, %306
  %310 = icmp sgt i16 %301, 699
  %311 = select i1 %310, i8 2, i8 0
  %312 = or disjoint i8 %309, %311
  %313 = icmp sgt i16 %303, 699
  %314 = zext i1 %313 to i8
  %315 = or disjoint i8 %312, %314
  %316 = zext nneg i8 %315 to i16
  %317 = shl nuw nsw i16 %291, 4
  %318 = add nuw nsw i16 %317, %278
  %319 = tail call i16 @llvm.fshl.i16(i16 %289, i16 %289, i16 1)
  %320 = xor i16 %318, %319
  %321 = xor i16 %320, %316
  %322 = getelementptr inbounds nuw [4 x i8], ptr @MS_SEG, i16 %316
  %323 = shl nuw nsw i16 %316, 2
  %324 = getelementptr nuw i8, ptr getelementptr inbounds nuw (i8, ptr @MS_SEG, i16 1), i16 %323
  br label %329

325:                                              ; preds = %352
  %326 = add nuw nsw i8 %290, 1
  %327 = icmp eq i8 %326, 16
  %328 = add nuw nsw i8 %288, 2
  br i1 %327, label %280, label %287, !llvm.loop !92

329:                                              ; preds = %352, %287
  %330 = phi i16 [ %321, %287 ], [ %353, %352 ]
  %331 = phi i1 [ true, %287 ], [ false, %352 ]
  %332 = phi i8 [ 0, %287 ], [ 2, %352 ]
  %333 = zext nneg i8 %332 to i16
  %334 = getelementptr i8, ptr %322, i16 %333
  %335 = load i8, ptr %334, align 1, !tbaa !6
  %336 = icmp eq i8 %335, -1
  br i1 %336, label %352, label %337

337:                                              ; preds = %329
  %338 = getelementptr i8, ptr %324, i16 %333
  %339 = load i8, ptr %338, align 1, !tbaa !6
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #15
  call fastcc void @ms_edge_point(i8 noundef zeroext %335, i16 noundef %291, i16 noundef %278, i32 noundef %295, i32 noundef %298, i32 noundef %302, i32 noundef %304, ptr noundef %3, ptr noundef %4) #14
  call fastcc void @ms_edge_point(i8 noundef zeroext %339, i16 noundef %291, i16 noundef %278, i32 noundef %295, i32 noundef %298, i32 noundef %302, i32 noundef %304, ptr noundef %5, ptr noundef %6) #14
  %340 = load i16, ptr %3, align 1, !tbaa !2
  %341 = load i16, ptr %4, align 1, !tbaa !2
  %342 = shl i16 %341, 8
  %343 = tail call i16 @llvm.fshl.i16(i16 %330, i16 %330, i16 1)
  %344 = xor i16 %340, %343
  %345 = xor i16 %344, %342
  %346 = load i16, ptr %5, align 1, !tbaa !2
  %347 = load i16, ptr %6, align 1, !tbaa !2
  %348 = shl i16 %347, 8
  %349 = xor i16 %348, %346
  %350 = tail call i16 @llvm.fshl.i16(i16 %345, i16 %345, i16 1)
  %351 = xor i16 %349, %350
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #15
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #15
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #15
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #15
  br label %352

352:                                              ; preds = %337, %329
  %353 = phi i16 [ %351, %337 ], [ %330, %329 ]
  br i1 %331, label %329, label %325, !llvm.loop !93

354:                                              ; preds = %279
  store volatile i16 %353, ptr @corpus_result, align 1, !tbaa !2
  br label %355

355:                                              ; preds = %385, %354
  %356 = phi i16 [ 110, %354 ], [ %357, %385 ]
  %357 = add nsw i16 %356, -1
  %358 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %359 = icmp eq i8 %358, 0
  br i1 %359, label %371, label %360

360:                                              ; preds = %355, %360
  %361 = phi i8 [ %368, %360 ], [ 0, %355 ]
  %362 = zext i8 %361 to i16
  %363 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %362
  %364 = load ptr, ptr %363, align 1, !tbaa !35
  %365 = load ptr, ptr %364, align 1, !tbaa !40
  %366 = getelementptr inbounds nuw i8, ptr %365, i16 2
  %367 = load ptr, ptr %366, align 1, !tbaa !80
  tail call void %367(ptr noundef nonnull %364, ptr noundef nonnull @main.a) #13, !inline_history !94
  %368 = add nuw i8 %361, 1
  %369 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %370 = icmp ult i8 %368, %369
  br i1 %370, label %360, label %371, !llvm.loop !82

371:                                              ; preds = %360, %355
  %372 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %373

373:                                              ; preds = %373, %371
  %374 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %375 = icmp sgt i8 %374, -1
  br i1 %375, label %373, label %376, !llvm.loop !83

376:                                              ; preds = %373
  tail call fastcc void @upq_flush() #14
  %377 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %378 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %379 = icmp ult i8 %377, %378
  br i1 %379, label %382, label %380

380:                                              ; preds = %376
  %381 = icmp ugt i8 %377, %378
  br i1 %381, label %382, label %385

382:                                              ; preds = %380, %376
  %383 = phi i8 [ 1, %376 ], [ -1, %380 ]
  %384 = add i8 %383, %377
  store i8 %384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %385

385:                                              ; preds = %382, %380
  %386 = phi i8 [ %377, %380 ], [ %384, %382 ]
  %387 = and i8 %386, 15
  store volatile i8 %387, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %388 = icmp eq i16 %357, 0
  br i1 %388, label %389, label %355, !llvm.loop !95

389:                                              ; preds = %385
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !73
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !74
  br label %393

390:                                              ; preds = %422
  %391 = add nuw nsw i8 %394, 1
  %392 = icmp eq i8 %391, 90
  br i1 %392, label %427, label %393, !llvm.loop !96

393:                                              ; preds = %390, %389
  %394 = phi i8 [ 0, %389 ], [ %391, %390 ]
  %395 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %396 = icmp eq i8 %395, 0
  br i1 %396, label %408, label %397

397:                                              ; preds = %393, %397
  %398 = phi i8 [ %405, %397 ], [ 0, %393 ]
  %399 = zext i8 %398 to i16
  %400 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %399
  %401 = load ptr, ptr %400, align 1, !tbaa !35
  %402 = load ptr, ptr %401, align 1, !tbaa !40
  %403 = getelementptr inbounds nuw i8, ptr %402, i16 2
  %404 = load ptr, ptr %403, align 1, !tbaa !80
  tail call void %404(ptr noundef nonnull %401, ptr noundef nonnull @main.a) #13, !inline_history !97
  %405 = add nuw i8 %398, 1
  %406 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %407 = icmp ult i8 %405, %406
  br i1 %407, label %397, label %408, !llvm.loop !82

408:                                              ; preds = %397, %393
  %409 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %410

410:                                              ; preds = %410, %408
  %411 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %412 = icmp sgt i8 %411, -1
  br i1 %412, label %410, label %413, !llvm.loop !83

413:                                              ; preds = %410
  tail call fastcc void @upq_flush() #14
  %414 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %415 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %416 = icmp ult i8 %414, %415
  br i1 %416, label %419, label %417

417:                                              ; preds = %413
  %418 = icmp ugt i8 %414, %415
  br i1 %418, label %419, label %422

419:                                              ; preds = %417, %413
  %420 = phi i8 [ 1, %413 ], [ -1, %417 ]
  %421 = add i8 %420, %414
  store i8 %421, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %422

422:                                              ; preds = %419, %417
  %423 = phi i8 [ %414, %417 ], [ %421, %419 ]
  %424 = and i8 %423, 15
  store volatile i8 %424, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %425 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 19), align 1, !tbaa !98
  %426 = icmp sgt i16 %425, 3583
  br i1 %426, label %427, label %390

427:                                              ; preds = %422, %390
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !73
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %428 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %429 = icmp eq i8 %428, 0
  br i1 %429, label %463, label %430

430:                                              ; preds = %427, %458
  %431 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %432 = icmp eq i8 %431, 0
  br i1 %432, label %444, label %433

433:                                              ; preds = %430, %433
  %434 = phi i8 [ %441, %433 ], [ 0, %430 ]
  %435 = zext i8 %434 to i16
  %436 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %435
  %437 = load ptr, ptr %436, align 1, !tbaa !35
  %438 = load ptr, ptr %437, align 1, !tbaa !40
  %439 = getelementptr inbounds nuw i8, ptr %438, i16 2
  %440 = load ptr, ptr %439, align 1, !tbaa !80
  tail call void %440(ptr noundef nonnull %437, ptr noundef nonnull @main.a) #13, !inline_history !99
  %441 = add nuw i8 %434, 1
  %442 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %443 = icmp ult i8 %441, %442
  br i1 %443, label %433, label %444, !llvm.loop !82

444:                                              ; preds = %433, %430
  %445 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %446

446:                                              ; preds = %446, %444
  %447 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %448 = icmp sgt i8 %447, -1
  br i1 %448, label %446, label %449, !llvm.loop !83

449:                                              ; preds = %446
  tail call fastcc void @upq_flush() #14
  %450 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %451 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %452 = icmp ult i8 %450, %451
  br i1 %452, label %455, label %453

453:                                              ; preds = %449
  %454 = icmp ugt i8 %450, %451
  br i1 %454, label %455, label %458

455:                                              ; preds = %453, %449
  %456 = phi i8 [ 1, %449 ], [ -1, %453 ]
  %457 = add i8 %456, %450
  store i8 %457, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %458

458:                                              ; preds = %455, %453
  %459 = phi i8 [ %450, %453 ], [ %457, %455 ]
  %460 = and i8 %459, 15
  store volatile i8 %460, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %461 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %462 = icmp eq i8 %461, 0
  br i1 %462, label %463, label %430, !llvm.loop !84

463:                                              ; preds = %458, %427
  %464 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !79
  %465 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %466 = or i8 %465, %464
  %467 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %468 = xor i8 %467, -1
  %469 = and i8 %466, %468
  store i8 %469, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %469, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !72
  %470 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %471 = icmp ugt i8 %470, 15
  br i1 %471, label %472, label %473

472:                                              ; preds = %463
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  br label %496

473:                                              ; preds = %463
  %474 = zext nneg i8 %470 to i16
  %475 = add nuw nsw i8 %470, 1
  store i8 %475, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %476 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %474
  %477 = getelementptr inbounds nuw i8, ptr %476, i16 10
  store i8 1, ptr %477, align 1, !tbaa !45
  store i16 0, ptr %476, align 1, !tbaa !47
  %478 = getelementptr inbounds nuw i8, ptr %476, i16 9
  store i8 0, ptr %478, align 1, !tbaa !48
  %479 = getelementptr inbounds nuw i8, ptr %476, i16 7
  store i8 34, ptr %479, align 1, !tbaa !49
  %480 = getelementptr inbounds nuw i8, ptr %476, i16 8
  store i8 0, ptr %480, align 1, !tbaa !50
  %481 = getelementptr inbounds nuw i8, ptr %476, i16 2
  store i16 ptrtoint (ptr @title_end._title_bg_black to i16), ptr %481, align 1, !tbaa !51
  %482 = getelementptr inbounds nuw i8, ptr %476, i16 6
  store i8 0, ptr %482, align 1, !tbaa !52
  %483 = getelementptr inbounds nuw i8, ptr %476, i16 4
  store i16 2, ptr %483, align 1, !tbaa !53
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %484 = icmp eq i8 %470, 15
  br i1 %484, label %496, label %485

485:                                              ; preds = %473
  %486 = zext nneg i8 %475 to i16
  %487 = add nuw nsw i8 %470, 2
  store i8 %487, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %488 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %486
  %489 = getelementptr inbounds nuw i8, ptr %488, i16 10
  store i8 1, ptr %489, align 1, !tbaa !45
  store i16 0, ptr %488, align 1, !tbaa !47
  %490 = getelementptr inbounds nuw i8, ptr %488, i16 9
  store i8 0, ptr %490, align 1, !tbaa !48
  %491 = getelementptr inbounds nuw i8, ptr %488, i16 7
  store i8 34, ptr %491, align 1, !tbaa !49
  %492 = getelementptr inbounds nuw i8, ptr %488, i16 8
  store i8 0, ptr %492, align 1, !tbaa !50
  %493 = getelementptr inbounds nuw i8, ptr %488, i16 2
  store i16 ptrtoint (ptr @bg3_pal to i16), ptr %493, align 1, !tbaa !51
  %494 = getelementptr inbounds nuw i8, ptr %488, i16 6
  store i8 0, ptr %494, align 1, !tbaa !52
  %495 = getelementptr inbounds nuw i8, ptr %488, i16 4
  store i16 8, ptr %495, align 1, !tbaa !53
  br label %496

496:                                              ; preds = %472, %473, %485
  br label %497

497:                                              ; preds = %496, %527
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(4098) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i64 4098, i1 false)
  store i16 255, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  tail call fastcc void @contour_frame() #14
  %498 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !54
  %499 = add i16 %498, 1
  store i16 %499, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !54
  %500 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %501 = icmp eq i8 %500, 0
  br i1 %501, label %513, label %502

502:                                              ; preds = %497, %502
  %503 = phi i8 [ %510, %502 ], [ 0, %497 ]
  %504 = zext i8 %503 to i16
  %505 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %504
  %506 = load ptr, ptr %505, align 1, !tbaa !35
  %507 = load ptr, ptr %506, align 1, !tbaa !40
  %508 = getelementptr inbounds nuw i8, ptr %507, i16 2
  %509 = load ptr, ptr %508, align 1, !tbaa !80
  tail call void %509(ptr noundef nonnull %506, ptr noundef nonnull @main.a) #13, !inline_history !100
  %510 = add nuw i8 %503, 1
  %511 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %512 = icmp ult i8 %510, %511
  br i1 %512, label %502, label %513, !llvm.loop !82

513:                                              ; preds = %502, %497
  %514 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %515

515:                                              ; preds = %515, %513
  %516 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %517 = icmp sgt i8 %516, -1
  br i1 %517, label %515, label %518, !llvm.loop !83

518:                                              ; preds = %515
  tail call fastcc void @upq_flush() #14
  %519 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %520 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %521 = icmp ult i8 %519, %520
  br i1 %521, label %524, label %522

522:                                              ; preds = %518
  %523 = icmp ugt i8 %519, %520
  br i1 %523, label %524, label %527

524:                                              ; preds = %522, %518
  %525 = phi i8 [ 1, %518 ], [ -1, %522 ]
  %526 = add i8 %525, %519
  store i8 %526, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %527

527:                                              ; preds = %522, %524
  %528 = phi i8 [ %519, %522 ], [ %526, %524 ]
  %529 = and i8 %528, 15
  store volatile i8 %529, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  br label %497
}

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @contour_frame() unnamed_addr #1 {
  %1 = alloca [3 x i16], align 1
  %2 = alloca [3 x i16], align 1
  %3 = alloca i16, align 1
  %4 = alloca i16, align 1
  %5 = alloca i16, align 1
  %6 = alloca i16, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #15
  %7 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !54
  %8 = mul i16 %7, 3
  %9 = and i16 %8, 63
  %10 = add nuw nsw i16 %9, 32
  store i16 %10, ptr %1, align 1, !tbaa !2
  %11 = shl i16 %7, 1
  %12 = and i16 %11, 46
  %13 = add nuw nsw i16 %12, 36
  store i16 %13, ptr %2, align 1, !tbaa !2
  %14 = and i16 %11, 54
  %15 = sub nuw nsw i16 97, %14
  %16 = getelementptr inbounds nuw i8, ptr %1, i16 2
  store i16 %15, ptr %16, align 1, !tbaa !2
  %17 = and i16 %8, 39
  %18 = add nuw nsw i16 %17, 44
  %19 = getelementptr inbounds nuw i8, ptr %2, i16 2
  store i16 %18, ptr %19, align 1, !tbaa !2
  %20 = shl i16 %7, 2
  %21 = and i16 %20, 44
  %22 = add nuw nsw i16 %21, 36
  %23 = getelementptr inbounds nuw i8, ptr %1, i16 4
  store i16 %22, ptr %23, align 1, !tbaa !2
  %24 = sub nuw nsw i16 102, %9
  %25 = getelementptr inbounds nuw i8, ptr %2, i16 4
  store i16 %24, ptr %25, align 1, !tbaa !2
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(2178) getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), i8 0, i16 2178, i1 false), !tbaa !2
  br label %26

26:                                               ; preds = %39, %0
  %27 = phi i8 [ 0, %0 ], [ %42, %39 ]
  %28 = phi i8 [ 0, %0 ], [ %40, %39 ]
  %29 = zext nneg i8 %27 to i16
  %30 = getelementptr i8, ptr %2, i16 %29
  %31 = getelementptr i8, ptr %1, i16 %29
  %32 = load i16, ptr %30, align 1, !tbaa !2
  %33 = load i16, ptr %31, align 1, !tbaa !2
  %34 = sub nsw i16 0, %33
  %35 = sext i16 %34 to i32
  %36 = mul nsw i32 %35, %35
  %37 = shl nsw i32 %35, 3
  %38 = add nsw i32 %37, 16
  br label %43

39:                                               ; preds = %51
  %40 = add nuw nsw i8 %28, 1
  %41 = icmp eq i8 %40, 3
  %42 = add nuw nsw i8 %27, 2
  br i1 %41, label %75, label %26, !llvm.loop !101

43:                                               ; preds = %51, %26
  %44 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), %26 ], [ %53, %51 ]
  %45 = phi i8 [ 0, %26 ], [ %52, %51 ]
  %46 = zext nneg i8 %45 to i16
  %47 = shl nuw nsw i16 %46, 2
  %48 = sub nsw i16 %47, %32
  %49 = sext i16 %48 to i32
  %50 = mul nsw i32 %49, %49
  br label %55

51:                                               ; preds = %69
  %52 = add nuw nsw i8 %45, 1
  %53 = getelementptr i8, ptr %44, i16 66
  %54 = icmp eq i8 %52, 33
  br i1 %54, label %39, label %43, !llvm.loop !102

55:                                               ; preds = %69, %43
  %56 = phi i8 [ 0, %43 ], [ %74, %69 ]
  %57 = phi i8 [ 0, %43 ], [ %72, %69 ]
  %58 = phi i32 [ %38, %43 ], [ %71, %69 ]
  %59 = phi i32 [ %36, %43 ], [ %70, %69 ]
  %60 = add i32 %50, %59
  %61 = sub i32 1600, %60
  %62 = icmp sgt i32 %61, 0
  br i1 %62, label %63, label %69

63:                                               ; preds = %55
  %64 = zext nneg i8 %56 to i16
  %65 = getelementptr i8, ptr %44, i16 %64
  %66 = load i16, ptr %65, align 1, !tbaa !2
  %67 = trunc i32 %61 to i16
  %68 = add i16 %66, %67
  store i16 %68, ptr %65, align 1, !tbaa !2
  br label %69

69:                                               ; preds = %63, %55
  %70 = add nsw i32 %59, %58
  %71 = add nsw i32 %58, 32
  %72 = add nuw nsw i8 %57, 1
  %73 = icmp eq i8 %72, 33
  %74 = add nuw nsw i8 %56, 2
  br i1 %73, label %51, label %55, !llvm.loop !103

75:                                               ; preds = %39, %84
  %76 = phi ptr [ %89, %84 ], [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4511), %39 ]
  %77 = phi ptr [ %88, %84 ], [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4509), %39 ]
  %78 = phi ptr [ %87, %84 ], [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4445), %39 ]
  %79 = phi ptr [ %86, %84 ], [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), %39 ]
  %80 = phi i8 [ %85, %84 ], [ 0, %39 ]
  %81 = zext nneg i8 %80 to i16
  %82 = shl nuw nsw i16 %81, 3
  br label %91

83:                                               ; preds = %84
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !104
  store i16 255, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !105
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #15
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #15
  ret void

84:                                               ; preds = %170
  %85 = add nuw nsw i8 %80, 1
  %86 = getelementptr i8, ptr %79, i16 66
  %87 = getelementptr i8, ptr %78, i16 66
  %88 = getelementptr i8, ptr %77, i16 66
  %89 = getelementptr i8, ptr %76, i16 66
  %90 = icmp eq i8 %85, 32
  br i1 %90, label %83, label %75, !llvm.loop !106

91:                                               ; preds = %75, %170
  %92 = phi i8 [ 0, %75 ], [ %173, %170 ]
  %93 = phi i8 [ 0, %75 ], [ %171, %170 ]
  %94 = zext nneg i8 %93 to i16
  %95 = zext nneg i8 %92 to i16
  %96 = getelementptr i8, ptr %79, i16 %95
  %97 = load i16, ptr %96, align 1, !tbaa !2
  %98 = sext i16 %97 to i32
  %99 = getelementptr i8, ptr %78, i16 %95
  %100 = load i16, ptr %99, align 1, !tbaa !2
  %101 = sext i16 %100 to i32
  %102 = getelementptr i8, ptr %77, i16 %95
  %103 = getelementptr i8, ptr %76, i16 %95
  %104 = load i16, ptr %103, align 1, !tbaa !2
  %105 = sext i16 %104 to i32
  %106 = load i16, ptr %102, align 1, !tbaa !2
  %107 = sext i16 %106 to i32
  %108 = icmp sgt i16 %97, 699
  %109 = select i1 %108, i8 8, i8 0
  %110 = icmp sgt i16 %100, 699
  %111 = select i1 %110, i8 4, i8 0
  %112 = or disjoint i8 %111, %109
  %113 = icmp sgt i16 %104, 699
  %114 = select i1 %113, i8 2, i8 0
  %115 = or disjoint i8 %112, %114
  %116 = icmp sgt i16 %106, 699
  %117 = zext i1 %116 to i8
  %118 = or disjoint i8 %115, %117
  %119 = zext nneg i8 %118 to i16
  %120 = icmp eq i8 %118, 15
  br i1 %120, label %121, label %166

121:                                              ; preds = %91
  %122 = shl nuw nsw i16 %94, 2
  %123 = lshr i16 %94, 1
  %124 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %125 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %126

126:                                              ; preds = %121, %139
  %127 = phi i16 [ 0, %121 ], [ %140, %139 ]
  %128 = phi i16 [ %124, %121 ], [ %157, %139 ]
  %129 = phi i16 [ %125, %121 ], [ %162, %139 ]
  %130 = shl nuw i16 %127, 1
  %131 = add nuw nsw i16 %82, %130
  %132 = and i16 %131, 240
  %133 = or disjoint i16 %132, %123
  %134 = shl nuw nsw i16 %133, 4
  %135 = and i16 %131, 14
  %136 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %134
  %137 = getelementptr inbounds nuw i8, ptr %136, i16 %135
  %138 = load i8, ptr %137, align 1, !tbaa !6
  br label %142

139:                                              ; preds = %161
  store i8 %153, ptr %137, align 1, !tbaa !6
  %140 = add nuw nsw i16 %127, 1
  %141 = icmp eq i16 %140, 4
  br i1 %141, label %166, label %126, !llvm.loop !107

142:                                              ; preds = %126, %161
  %143 = phi i16 [ %129, %126 ], [ %162, %161 ]
  %144 = phi i16 [ %128, %126 ], [ %157, %161 ]
  %145 = phi i16 [ 0, %126 ], [ %164, %161 ]
  %146 = phi i8 [ %138, %126 ], [ %153, %161 ]
  %147 = phi i16 [ %128, %126 ], [ %158, %161 ]
  %148 = phi i16 [ %129, %126 ], [ %163, %161 ]
  %149 = add nuw nsw i16 %145, %122
  %150 = and i16 %149, 7
  %151 = lshr exact i16 128, %150
  %152 = trunc nuw i16 %151 to i8
  %153 = or i8 %146, %152
  %154 = icmp ult i16 %133, %147
  br i1 %154, label %155, label %156

155:                                              ; preds = %142
  store i16 %133, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %156

156:                                              ; preds = %155, %142
  %157 = phi i16 [ %133, %155 ], [ %144, %142 ]
  %158 = phi i16 [ %133, %155 ], [ %147, %142 ]
  %159 = icmp ugt i16 %133, %148
  br i1 %159, label %160, label %161

160:                                              ; preds = %156
  store i16 %133, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %161

161:                                              ; preds = %156, %160
  %162 = phi i16 [ %143, %156 ], [ %133, %160 ]
  %163 = phi i16 [ %148, %156 ], [ %133, %160 ]
  %164 = add nuw nsw i16 %145, 1
  %165 = icmp eq i16 %164, 4
  br i1 %165, label %139, label %142, !llvm.loop !108

166:                                              ; preds = %139, %91
  %167 = getelementptr inbounds nuw [4 x i8], ptr @MS_SEG, i16 %119
  %168 = shl nuw nsw i16 %119, 2
  %169 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @MS_SEG, i16 1), i16 %168
  br label %174

170:                                              ; preds = %192
  %171 = add nuw nsw i8 %93, 1
  %172 = icmp eq i8 %171, 32
  %173 = add nuw nsw i8 %92, 2
  br i1 %172, label %84, label %91, !llvm.loop !109

174:                                              ; preds = %166, %192
  %175 = phi i1 [ true, %166 ], [ false, %192 ]
  %176 = phi i8 [ 0, %166 ], [ 2, %192 ]
  %177 = zext nneg i8 %176 to i16
  %178 = getelementptr i8, ptr %167, i16 %177
  %179 = load i8, ptr %178, align 1, !tbaa !6
  %180 = icmp eq i8 %179, -1
  br i1 %180, label %192, label %181

181:                                              ; preds = %174
  %182 = getelementptr i8, ptr %169, i16 %177
  %183 = load i8, ptr %182, align 1, !tbaa !6
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #15
  call fastcc void @ms_edge_point(i8 noundef zeroext %179, i16 noundef %94, i16 noundef %81, i32 noundef %98, i32 noundef %101, i32 noundef %105, i32 noundef %107, ptr noundef %3, ptr noundef %4) #14
  call fastcc void @ms_edge_point(i8 noundef zeroext %183, i16 noundef %94, i16 noundef %81, i32 noundef %98, i32 noundef %101, i32 noundef %105, i32 noundef %107, ptr noundef %5, ptr noundef %6) #14
  %184 = load i16, ptr %3, align 1, !tbaa !2
  %185 = ashr i16 %184, 2
  %186 = load i16, ptr %4, align 1, !tbaa !2
  %187 = ashr i16 %186, 2
  %188 = load i16, ptr %5, align 1, !tbaa !2
  %189 = ashr i16 %188, 2
  %190 = load i16, ptr %6, align 1, !tbaa !2
  %191 = ashr i16 %190, 2
  tail call fastcc void @canvas_line(i16 noundef %185, i16 noundef %187, i16 noundef %189, i16 noundef %191) #14
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #15
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #15
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #15
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #15
  br label %192

192:                                              ; preds = %174, %181
  br i1 %175, label %174, label %170, !llvm.loop !110
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #2

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_canvas_reserve(ptr noundef readonly captures(none) %0, ptr readnone captures(none) %1) #3 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4105
  %4 = load i16, ptr %3, align 1, !tbaa !21
  %5 = lshr i16 %4, 8
  %6 = trunc nuw i16 %5 to i8
  %7 = and i8 %6, -4
  store volatile i8 %7, ptr inttoptr (i16 8457 to ptr), align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %9 = load i16, ptr %8, align 1, !tbaa !20
  %10 = lshr i16 %9, 12
  %11 = trunc nuw nsw i16 %10 to i8
  store volatile i8 %11, ptr inttoptr (i16 8460 to ptr), align 4, !tbaa !6
  %12 = load i16, ptr %8, align 1, !tbaa !20
  %13 = lshr i16 %12, 3
  %14 = add nuw nsw i16 %13, 256
  %15 = load i16, ptr %3, align 1, !tbaa !21
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %15, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %16 = getelementptr inbounds nuw i8, ptr %0, i16 4107
  %17 = load i8, ptr %16, align 1, !tbaa !22
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 4108
  br label %19

19:                                               ; preds = %2, %23
  %20 = phi i8 [ 0, %2 ], [ %24, %23 ]
  br label %26

21:                                               ; preds = %23
  %22 = load i16, ptr %8, align 1, !tbaa !20
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %22, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %45

23:                                               ; preds = %40
  %24 = add nuw nsw i8 %20, 1
  %25 = icmp eq i8 %24, 32
  br i1 %25, label %21, label %19, !llvm.loop !111

26:                                               ; preds = %19, %40
  %27 = phi i8 [ 0, %19 ], [ %42, %40 ]
  %28 = sub i8 %27, %17
  %29 = zext i8 %28 to i16
  %30 = icmp ult i8 %28, 16
  br i1 %30, label %31, label %40

31:                                               ; preds = %26
  %32 = load i8, ptr %18, align 1, !tbaa !23
  %33 = sub i8 %20, %32
  %34 = icmp ult i8 %33, 16
  br i1 %34, label %35, label %40

35:                                               ; preds = %31
  %36 = shl nuw i8 %33, 4
  %37 = zext i8 %36 to i16
  %38 = add nuw nsw i16 %13, %29
  %39 = add nuw nsw i16 %38, %37
  br label %40

40:                                               ; preds = %26, %31, %35
  %41 = phi i16 [ %39, %35 ], [ %14, %31 ], [ %14, %26 ]
  store volatile i16 %41, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %42 = add nuw nsw i8 %27, 1
  %43 = icmp eq i8 %42, 32
  br i1 %43, label %23, label %26, !llvm.loop !112

44:                                               ; preds = %45
  ret void

45:                                               ; preds = %21, %45
  %46 = phi i16 [ 0, %21 ], [ %47, %45 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %47 = add nuw nsw i16 %46, 1
  %48 = icmp eq i16 %47, 2056
  br i1 %48, label %44, label %45, !llvm.loop !113
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal void @_canvas_emit(ptr noundef %0, ptr noundef captures(none) %1) #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4099
  %4 = load i16, ptr %3, align 1, !tbaa !24
  %5 = getelementptr inbounds nuw i8, ptr %0, i16 4101
  %6 = load i16, ptr %5, align 1, !tbaa !25
  %7 = icmp ugt i16 %4, %6
  br i1 %7, label %48, label %8

8:                                                ; preds = %2
  %9 = sub nuw i16 %6, %4
  %10 = add i16 %9, -256
  %11 = icmp ult i16 %10, -257
  br i1 %11, label %12, label %14

12:                                               ; preds = %8
  %13 = add i16 %4, 255
  br label %14

14:                                               ; preds = %12, %8
  %15 = phi i16 [ 255, %12 ], [ %9, %8 ]
  %16 = phi i16 [ %13, %12 ], [ %6, %8 ]
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %18 = load i16, ptr %17, align 1, !tbaa !20
  %19 = shl i16 %4, 3
  %20 = add i16 %18, %19
  %21 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %22 = shl i16 %4, 4
  %23 = getelementptr inbounds nuw i8, ptr %21, i16 %22
  %24 = shl nsw i16 %15, 4
  %25 = add nsw i16 %24, 16
  %26 = icmp eq i16 %25, 0
  br i1 %26, label %43, label %27

27:                                               ; preds = %14
  %28 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %29 = load i8, ptr %28, align 1, !tbaa !44
  %30 = icmp ugt i8 %29, 15
  br i1 %30, label %43, label %31

31:                                               ; preds = %27
  %32 = zext nneg i8 %29 to i16
  %33 = add nuw nsw i8 %29, 1
  store i8 %33, ptr %28, align 1, !tbaa !44
  %34 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %32
  %35 = getelementptr inbounds nuw i8, ptr %34, i16 10
  store i8 0, ptr %35, align 1, !tbaa !45
  store i16 %20, ptr %34, align 1, !tbaa !47
  %36 = getelementptr inbounds nuw i8, ptr %34, i16 9
  store i8 -128, ptr %36, align 1, !tbaa !48
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 7
  store i8 24, ptr %37, align 1, !tbaa !49
  %38 = getelementptr inbounds nuw i8, ptr %34, i16 8
  store i8 1, ptr %38, align 1, !tbaa !50
  %39 = ptrtoint ptr %23 to i16
  %40 = getelementptr inbounds nuw i8, ptr %34, i16 2
  store i16 %39, ptr %40, align 1, !tbaa !51
  %41 = getelementptr inbounds nuw i8, ptr %34, i16 6
  store i8 0, ptr %41, align 1, !tbaa !52
  %42 = getelementptr inbounds nuw i8, ptr %34, i16 4
  store i16 %25, ptr %42, align 1, !tbaa !53
  br label %43

43:                                               ; preds = %14, %27, %31
  %44 = icmp ult i16 %16, %6
  br i1 %44, label %46, label %45

45:                                               ; preds = %43
  store i16 -1, ptr %3, align 1, !tbaa !24
  store i16 0, ptr %5, align 1, !tbaa !25
  br label %48

46:                                               ; preds = %43
  %47 = add nuw i16 %16, 1
  store i16 %47, ptr %3, align 1, !tbaa !24
  br label %48

48:                                               ; preds = %45, %46, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_text_reserve(ptr readnone captures(none) %0, ptr readnone captures(none) %1) #3 {
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 2048, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %4

3:                                                ; preds = %4
  ret void

4:                                                ; preds = %2, %4
  %5 = phi i16 [ 0, %2 ], [ %8, %4 ]
  %6 = getelementptr inbounds nuw [2 x i8], ptr @FONT8, i16 %5
  %7 = load i16, ptr %6, align 1, !tbaa !2
  store volatile i16 %7, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %8 = add nuw nsw i16 %5, 1
  %9 = icmp eq i16 %8, 512
  br i1 %9, label %3, label %4, !llvm.loop !114
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(argmem: readwrite)
define internal void @_text_emit(ptr noundef %0, ptr noundef captures(none) %1) #5 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 135
  %4 = load i8, ptr %3, align 1, !tbaa !31
  %5 = zext i8 %4 to i16
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %7 = getelementptr i8, ptr %0, i16 7
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %9 = getelementptr i8, ptr %0, i16 5
  br label %11

10:                                               ; preds = %42
  store i8 0, ptr %3, align 1, !tbaa !31
  ret void

11:                                               ; preds = %2, %42
  %12 = phi i8 [ 0, %2 ], [ %43, %42 ]
  %13 = phi i1 [ true, %2 ], [ false, %42 ]
  %14 = phi i8 [ 0, %2 ], [ 1, %42 ]
  %15 = zext nneg i8 %14 to i16
  %16 = shl nuw nsw i16 1, %15
  %17 = and i16 %16, %5
  %18 = icmp eq i16 %17, 0
  br i1 %18, label %42, label %19

19:                                               ; preds = %11
  %20 = load i8, ptr %6, align 1, !tbaa !44
  %21 = icmp ugt i8 %20, 15
  br i1 %21, label %42, label %22

22:                                               ; preds = %19
  %23 = zext i8 %12 to i16
  %24 = getelementptr i8, ptr %7, i16 %23
  %25 = load i16, ptr %8, align 1, !tbaa !29
  %26 = getelementptr i8, ptr %9, i16 %15
  %27 = load i8, ptr %26, align 1, !tbaa !6
  %28 = zext i8 %27 to i16
  %29 = shl nuw nsw i16 %28, 5
  %30 = add i16 %29, %25
  %31 = zext nneg i8 %20 to i16
  %32 = add nuw nsw i8 %20, 1
  store i8 %32, ptr %6, align 1, !tbaa !44
  %33 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %31
  %34 = getelementptr inbounds nuw i8, ptr %33, i16 10
  store i8 0, ptr %34, align 1, !tbaa !45
  store i16 %30, ptr %33, align 1, !tbaa !47
  %35 = getelementptr inbounds nuw i8, ptr %33, i16 9
  store i8 -128, ptr %35, align 1, !tbaa !48
  %36 = getelementptr inbounds nuw i8, ptr %33, i16 7
  store i8 24, ptr %36, align 1, !tbaa !49
  %37 = getelementptr inbounds nuw i8, ptr %33, i16 8
  store i8 1, ptr %37, align 1, !tbaa !50
  %38 = ptrtoint ptr %24 to i16
  %39 = getelementptr inbounds nuw i8, ptr %33, i16 2
  store i16 %38, ptr %39, align 1, !tbaa !51
  %40 = getelementptr inbounds nuw i8, ptr %33, i16 6
  store i8 0, ptr %40, align 1, !tbaa !52
  %41 = getelementptr inbounds nuw i8, ptr %33, i16 4
  store i16 64, ptr %41, align 1, !tbaa !53
  br label %42

42:                                               ; preds = %22, %19, %11
  %43 = add nuw i8 %12, 64
  br i1 %13, label %11, label %10, !llvm.loop !115
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_title_reserve(ptr noundef %0, ptr readnone captures(none) %1) #3 {
  store volatile i8 80, ptr inttoptr (i16 8456 to ptr), align 8, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !6
  store volatile i8 112, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -1, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 127, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -124, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 4096, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %3

3:                                                ; preds = %2, %16
  %4 = phi ptr [ @FONT8, %2 ], [ %18, %16 ]
  %5 = phi i16 [ 0, %2 ], [ %17, %16 ]
  br label %7

6:                                                ; preds = %16
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 5120, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %24

7:                                                ; preds = %3, %7
  %8 = phi i8 [ 0, %3 ], [ %15, %7 ]
  %9 = phi i8 [ 0, %3 ], [ %13, %7 ]
  %10 = zext nneg i8 %8 to i16
  %11 = getelementptr i8, ptr %4, i16 %10
  %12 = load i16, ptr %11, align 1, !tbaa !2
  store volatile i16 %12, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %13 = add nuw nsw i8 %9, 1
  %14 = icmp eq i8 %13, 8
  %15 = add nuw nsw i8 %8, 2
  br i1 %14, label %20, label %7, !llvm.loop !116

16:                                               ; preds = %20
  %17 = add nuw nsw i16 %5, 1
  %18 = getelementptr i8, ptr %4, i16 16
  %19 = icmp eq i16 %17, 64
  br i1 %19, label %6, label %3, !llvm.loop !117

20:                                               ; preds = %7, %20
  %21 = phi i8 [ %22, %20 ], [ 0, %7 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %22 = add nuw nsw i8 %21, 1
  %23 = icmp eq i8 %22, 8
  br i1 %23, label %16, label %20, !llvm.loop !118

24:                                               ; preds = %6, %33
  %25 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 16), %6 ], [ %36, %33 ]
  %26 = phi ptr [ @FONT16, %6 ], [ %35, %33 ]
  %27 = phi i16 [ 0, %6 ], [ %34, %33 ]
  br label %29

28:                                               ; preds = %33
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 20480, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %66

29:                                               ; preds = %24, %47
  %30 = phi i8 [ 0, %24 ], [ %52, %47 ]
  %31 = phi ptr [ %26, %24 ], [ %50, %47 ]
  %32 = phi i8 [ 0, %24 ], [ %48, %47 ]
  br label %38

33:                                               ; preds = %47
  %34 = add nuw nsw i16 %27, 1
  %35 = getelementptr i8, ptr %26, i16 64
  %36 = getelementptr i8, ptr %25, i16 64
  %37 = icmp eq i16 %34, 64
  br i1 %37, label %28, label %24, !llvm.loop !119

38:                                               ; preds = %29, %38
  %39 = phi i8 [ 0, %29 ], [ %46, %38 ]
  %40 = phi i8 [ 0, %29 ], [ %44, %38 ]
  %41 = zext nneg i8 %39 to i16
  %42 = getelementptr i8, ptr %31, i16 %41
  %43 = load i16, ptr %42, align 1, !tbaa !2
  store volatile i16 %43, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %44 = add nuw nsw i8 %40, 1
  %45 = icmp eq i8 %44, 8
  %46 = add nuw nsw i8 %39, 2
  br i1 %45, label %53, label %38, !llvm.loop !120

47:                                               ; preds = %53
  %48 = add nuw nsw i8 %32, 1
  %49 = zext nneg i8 %30 to i16
  %50 = getelementptr i8, ptr %25, i16 %49
  %51 = icmp eq i8 %48, 4
  %52 = add nuw nsw i8 %30, 16
  br i1 %51, label %33, label %29, !llvm.loop !121

53:                                               ; preds = %38, %53
  %54 = phi i8 [ %55, %53 ], [ 0, %38 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %55 = add nuw nsw i8 %54, 1
  %56 = icmp eq i8 %55, 8
  br i1 %56, label %47, label %53, !llvm.loop !122

57:                                               ; preds = %66
  %58 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %59 = load ptr, ptr %58, align 1, !tbaa !62
  %60 = icmp eq ptr %59, null
  br i1 %60, label %79, label %61

61:                                               ; preds = %57
  %62 = load i8, ptr %59, align 1, !tbaa !6
  %63 = icmp eq i8 %62, 0
  br i1 %63, label %79, label %64

64:                                               ; preds = %61
  %65 = getelementptr i8, ptr %59, i16 1
  br label %70

66:                                               ; preds = %28, %66
  %67 = phi i16 [ 0, %28 ], [ %68, %66 ]
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %68 = add nuw nsw i16 %67, 1
  %69 = icmp eq i16 %68, 1024
  br i1 %69, label %57, label %66, !llvm.loop !123

70:                                               ; preds = %64, %70
  %71 = phi i8 [ %72, %70 ], [ 0, %64 ]
  %72 = add nuw nsw i8 %71, 1
  %73 = zext nneg i8 %71 to i16
  %74 = getelementptr i8, ptr %65, i16 %73
  %75 = load i8, ptr %74, align 1, !tbaa !6
  %76 = icmp ne i8 %75, 0
  %77 = icmp samesign ult i8 %71, 31
  %78 = select i1 %76, i1 %77, i1 false
  br i1 %78, label %70, label %79, !llvm.loop !124

79:                                               ; preds = %70, %61, %57
  %80 = phi i8 [ 0, %57 ], [ 0, %61 ], [ %72, %70 ]
  %81 = zext nneg i8 %80 to i16
  %82 = sub nuw nsw i16 32, %81
  %83 = lshr i16 %82, 1
  %84 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %85 = load i16, ptr %84, align 1, !tbaa !68
  %86 = shl i16 %85, 2
  %87 = and i16 %86, -32
  %88 = add i16 %87, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %88, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %89 = trunc nuw nsw i16 %83 to i8
  %90 = add nuw nsw i8 %80, %89
  %91 = sub nsw i16 0, %83
  %92 = getelementptr i8, ptr %59, i16 %91
  br label %105

93:                                               ; preds = %128
  %94 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %95 = load ptr, ptr %94, align 1, !tbaa !64
  %96 = getelementptr inbounds nuw i8, ptr %0, i16 11
  %97 = load i8, ptr %96, align 1, !tbaa !65
  %98 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %99 = load i16, ptr %98, align 1, !tbaa !69
  %100 = lshr i16 %99, 3
  %101 = trunc i16 %100 to i8
  tail call fastcc void @_title_write16(ptr noundef %95, i8 noundef zeroext %97, i8 noundef zeroext %101) #14
  %102 = getelementptr inbounds nuw i8, ptr %0, i16 9
  %103 = load ptr, ptr %102, align 1, !tbaa !66
  %104 = icmp eq ptr %103, null
  br i1 %104, label %139, label %132

105:                                              ; preds = %79, %128
  %106 = phi i8 [ 0, %79 ], [ %130, %128 ]
  %107 = zext nneg i8 %106 to i16
  br i1 %60, label %128, label %108

108:                                              ; preds = %105
  %109 = icmp samesign ugt i16 %83, %107
  br i1 %109, label %128, label %110

110:                                              ; preds = %108
  %111 = icmp ult i8 %106, %90
  br i1 %111, label %112, label %128

112:                                              ; preds = %110
  %113 = getelementptr i8, ptr %92, i16 %107
  %114 = load i8, ptr %113, align 1, !tbaa !6
  %115 = icmp ugt i8 %114, 96
  br i1 %115, label %116, label %120

116:                                              ; preds = %112
  %117 = icmp ult i8 %114, 123
  br i1 %117, label %118, label %128

118:                                              ; preds = %116
  %119 = add nsw i8 %114, -32
  br label %124

120:                                              ; preds = %112
  %121 = icmp samesign ugt i8 %114, 31
  br i1 %121, label %122, label %128

122:                                              ; preds = %120
  %123 = icmp eq i8 %114, 96
  br i1 %123, label %128, label %124

124:                                              ; preds = %122, %118
  %125 = phi i8 [ %119, %118 ], [ %114, %122 ]
  %126 = zext nneg i8 %125 to i16
  %127 = add nuw nsw i16 %126, 7136
  br label %128

128:                                              ; preds = %124, %122, %120, %116, %105, %108, %110
  %129 = phi i16 [ 7168, %105 ], [ 7168, %110 ], [ 7168, %108 ], [ %127, %124 ], [ 7168, %122 ], [ 7168, %120 ], [ 7168, %116 ]
  store volatile i16 %129, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %130 = add nuw nsw i8 %106, 1
  %131 = icmp eq i8 %130, 32
  br i1 %131, label %93, label %105, !llvm.loop !125

132:                                              ; preds = %93
  %133 = getelementptr inbounds nuw i8, ptr %0, i16 12
  %134 = load i8, ptr %133, align 1, !tbaa !67
  %135 = load i16, ptr %98, align 1, !tbaa !69
  %136 = lshr i16 %135, 3
  %137 = trunc i16 %136 to i8
  %138 = add i8 %137, 2
  tail call fastcc void @_title_write16(ptr noundef nonnull %103, i8 noundef zeroext %134, i8 noundef zeroext %138) #14
  br label %139

139:                                              ; preds = %132, %93
  %140 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 -128, ptr %140, align 1, !tbaa !98
  %141 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 3584, ptr %141, align 1, !tbaa !126
  %142 = getelementptr inbounds nuw i8, ptr %0, i16 23
  store i16 0, ptr %142, align 1, !tbaa !127
  %143 = load ptr, ptr %58, align 1, !tbaa !62
  %144 = icmp eq ptr %143, null
  br i1 %144, label %167, label %145

145:                                              ; preds = %139
  %146 = load i8, ptr %143, align 1, !tbaa !6
  %147 = icmp eq i8 %146, 0
  br i1 %147, label %150, label %148

148:                                              ; preds = %145
  %149 = getelementptr i8, ptr %143, i16 1
  br label %158

150:                                              ; preds = %158, %145
  %151 = phi i8 [ 0, %145 ], [ %160, %158 ]
  %152 = zext nneg i8 %151 to i16
  %153 = shl nuw nsw i16 %152, 2
  %154 = sub nuw nsw i16 128, %153
  %155 = and i16 %154, 248
  %156 = add nsw i16 %153, -128
  %157 = add nsw i16 %156, %155
  br label %167

158:                                              ; preds = %158, %148
  %159 = phi i8 [ %160, %158 ], [ 0, %148 ]
  %160 = add nuw nsw i8 %159, 1
  %161 = zext nneg i8 %159 to i16
  %162 = getelementptr i8, ptr %149, i16 %161
  %163 = load i8, ptr %162, align 1, !tbaa !6
  %164 = icmp ne i8 %163, 0
  %165 = icmp samesign ult i8 %159, 31
  %166 = select i1 %164, i1 %165, i1 false
  br i1 %166, label %158, label %150, !llvm.loop !128

167:                                              ; preds = %139, %150
  %168 = phi i16 [ %157, %150 ], [ 0, %139 ]
  %169 = getelementptr inbounds nuw i8, ptr %0, i16 26
  store i16 %168, ptr %169, align 1, !tbaa !129
  store volatile i8 -112, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  %170 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %171 = getelementptr inbounds nuw i8, ptr %0, i16 89
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef -8, i16 noundef 224, ptr noundef nonnull %170, ptr noundef nonnull %171) #14
  %172 = getelementptr inbounds nuw i8, ptr %0, i16 88
  store i8 0, ptr %172, align 1, !tbaa !130
  store volatile i8 2, ptr inttoptr (i16 17200 to ptr), align 16, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 17201 to ptr), align 1, !tbaa !6
  %173 = ptrtoint ptr %170 to i16
  %174 = trunc i16 %173 to i8
  store volatile i8 %174, ptr inttoptr (i16 17202 to ptr), align 2, !tbaa !6
  %175 = lshr i16 %173, 8
  %176 = trunc nuw i16 %175 to i8
  store volatile i8 %176, ptr inttoptr (i16 17203 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17204 to ptr), align 4, !tbaa !6
  %177 = getelementptr inbounds nuw i8, ptr %0, i16 139
  store i8 0, ptr %177, align 1, !tbaa !130
  store volatile i8 2, ptr inttoptr (i16 17216 to ptr), align 64, !tbaa !6
  store volatile i8 15, ptr inttoptr (i16 17217 to ptr), align 1, !tbaa !6
  %178 = ptrtoint ptr %171 to i16
  %179 = trunc i16 %178 to i8
  store volatile i8 %179, ptr inttoptr (i16 17218 to ptr), align 2, !tbaa !6
  %180 = lshr i16 %178, 8
  %181 = trunc nuw i16 %180 to i8
  store volatile i8 %181, ptr inttoptr (i16 17219 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17220 to ptr), align 4, !tbaa !6
  %182 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 2, ptr %182, align 1, !tbaa !61
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal void @_title_emit(ptr noundef %0, ptr noundef captures(none) %1) #6 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 29
  %4 = load i8, ptr %3, align 1, !tbaa !72
  %5 = icmp eq i8 %4, 0
  br i1 %5, label %188, label %6

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 30
  %8 = load i8, ptr %7, align 1, !tbaa !75
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %39, label %10

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 25
  %12 = load i8, ptr %11, align 1, !tbaa !76
  %13 = icmp ugt i8 %12, -6
  br i1 %13, label %16, label %14

14:                                               ; preds = %10
  %15 = add nuw i8 %12, 4
  br label %16

16:                                               ; preds = %10, %14
  %17 = phi i8 [ %15, %14 ], [ -1, %10 ]
  store i8 %17, ptr %11, align 1, !tbaa !76
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %19 = load i16, ptr %18, align 1, !tbaa !68
  %20 = xor i8 %17, -1
  %21 = zext i8 %20 to i16
  %22 = mul nuw i16 %21, %21
  %23 = lshr i16 %22, 8
  %24 = sub nuw nsw i16 256, %23
  %25 = add nsw i16 %19, 8
  %26 = mul nsw i16 %24, %25
  %27 = ashr i16 %26, 4
  %28 = and i16 %27, -16
  %29 = add nsw i16 %28, -128
  %30 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 %29, ptr %30, align 1, !tbaa !98
  %31 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %32 = load i16, ptr %31, align 1, !tbaa !69
  %33 = add nsw i16 %32, -224
  %34 = mul nsw i16 %33, %24
  %35 = ashr i16 %34, 4
  %36 = and i16 %35, -16
  %37 = add nsw i16 %36, 3584
  %38 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 %37, ptr %38, align 1, !tbaa !126
  br label %64

39:                                               ; preds = %6
  %40 = getelementptr inbounds nuw i8, ptr %0, i16 31
  %41 = load i8, ptr %40, align 1, !tbaa !73
  %42 = icmp eq i8 %41, 0
  br i1 %42, label %43, label %48

43:                                               ; preds = %39
  %44 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %45 = load i16, ptr %44, align 1, !tbaa !98
  %46 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %47 = load i16, ptr %46, align 1, !tbaa !126
  br label %64

48:                                               ; preds = %39
  %49 = getelementptr inbounds nuw i8, ptr %0, i16 23
  %50 = load i16, ptr %49, align 1, !tbaa !127
  %51 = add nsw i16 %50, 2
  store i16 %51, ptr %49, align 1, !tbaa !127
  %52 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %53 = load i16, ptr %52, align 1, !tbaa !98
  %54 = add nsw i16 %53, %51
  store i16 %54, ptr %52, align 1, !tbaa !98
  %55 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %56 = load i16, ptr %55, align 1, !tbaa !126
  %57 = add nsw i16 %56, %51
  store i16 %57, ptr %55, align 1, !tbaa !126
  %58 = icmp sgt i16 %54, 4480
  br i1 %58, label %59, label %60

59:                                               ; preds = %48
  store i16 4480, ptr %52, align 1, !tbaa !98
  br label %60

60:                                               ; preds = %59, %48
  %61 = phi i16 [ 4480, %59 ], [ %54, %48 ]
  %62 = icmp sgt i16 %57, 4736
  br i1 %62, label %63, label %64

63:                                               ; preds = %60
  store i16 4736, ptr %55, align 1, !tbaa !126
  br label %64

64:                                               ; preds = %43, %63, %60, %16
  %65 = phi i16 [ %47, %43 ], [ 4736, %63 ], [ %57, %60 ], [ %37, %16 ]
  %66 = phi i16 [ %45, %43 ], [ %61, %63 ], [ %61, %60 ], [ %29, %16 ]
  %67 = ashr i16 %66, 4
  %68 = ashr i16 %65, 4
  %69 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %70 = getelementptr inbounds nuw i8, ptr %0, i16 88
  %71 = load i8, ptr %70, align 1, !tbaa !130
  %72 = xor i8 %71, 1
  %73 = zext i8 %72 to i16
  %74 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %73
  %75 = getelementptr inbounds nuw i8, ptr %0, i16 89
  %76 = getelementptr inbounds nuw i8, ptr %0, i16 139
  %77 = load i8, ptr %76, align 1, !tbaa !130
  %78 = xor i8 %77, 1
  %79 = zext i8 %78 to i16
  %80 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %79
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef %67, i16 noundef %68, ptr noundef nonnull %74, ptr noundef nonnull %80) #14
  %81 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %82 = load i8, ptr %81, align 1, !tbaa !44
  %83 = icmp ugt i8 %82, 15
  br i1 %83, label %109, label %84

84:                                               ; preds = %64
  %85 = load i8, ptr %70, align 1, !tbaa !130
  %86 = xor i8 %85, 1
  %87 = zext i8 %86 to i16
  %88 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %87
  %89 = ptrtoint ptr %88 to i16
  %90 = zext nneg i8 %82 to i16
  %91 = add nuw nsw i8 %82, 1
  store i8 %91, ptr %81, align 1, !tbaa !44
  %92 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %90
  %93 = getelementptr inbounds nuw i8, ptr %92, i16 10
  store i8 4, ptr %93, align 1, !tbaa !45
  store i16 17202, ptr %92, align 1, !tbaa !47
  %94 = getelementptr inbounds nuw i8, ptr %92, i16 2
  store i16 %89, ptr %94, align 1, !tbaa !51
  %95 = getelementptr inbounds nuw i8, ptr %92, i16 4
  store i16 0, ptr %95, align 1, !tbaa !53
  store i8 %86, ptr %70, align 1, !tbaa !130
  %96 = icmp eq i8 %82, 15
  br i1 %96, label %109, label %97

97:                                               ; preds = %84
  %98 = load i8, ptr %76, align 1, !tbaa !130
  %99 = xor i8 %98, 1
  %100 = zext i8 %99 to i16
  %101 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %100
  %102 = ptrtoint ptr %101 to i16
  %103 = zext nneg i8 %91 to i16
  %104 = add nuw nsw i8 %82, 2
  store i8 %104, ptr %81, align 1, !tbaa !44
  %105 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %103
  %106 = getelementptr inbounds nuw i8, ptr %105, i16 10
  store i8 4, ptr %106, align 1, !tbaa !45
  store i16 17218, ptr %105, align 1, !tbaa !47
  %107 = getelementptr inbounds nuw i8, ptr %105, i16 2
  store i16 %102, ptr %107, align 1, !tbaa !51
  %108 = getelementptr inbounds nuw i8, ptr %105, i16 4
  store i16 0, ptr %108, align 1, !tbaa !53
  store i8 %99, ptr %76, align 1, !tbaa !130
  br label %109

109:                                              ; preds = %64, %84, %97
  %110 = phi i8 [ %82, %64 ], [ 16, %84 ], [ %104, %97 ]
  %111 = getelementptr inbounds nuw i8, ptr %0, i16 28
  %112 = load i8, ptr %111, align 1, !tbaa !71
  %113 = add i8 %112, 1
  store i8 %113, ptr %111, align 1, !tbaa !71
  %114 = getelementptr inbounds nuw i8, ptr %0, i16 32
  %115 = load i8, ptr %114, align 1, !tbaa !74
  %116 = icmp eq i8 %115, 0
  br i1 %116, label %117, label %155

117:                                              ; preds = %109
  %118 = shl i8 %113, 1
  %119 = icmp sgt i8 %118, -1
  br i1 %119, label %122, label %120

120:                                              ; preds = %117
  %121 = xor i8 %118, -1
  br label %122

122:                                              ; preds = %117, %120
  %123 = phi i8 [ %121, %120 ], [ %118, %117 ]
  %124 = lshr i8 %123, 4
  %125 = add nuw nsw i8 %124, 24
  %126 = zext nneg i8 %125 to i16
  %127 = mul nuw nsw i16 %126, 1057
  %128 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 %127, ptr %128, align 1, !tbaa !77
  %129 = add i8 %118, -86
  %130 = icmp sgt i8 %129, -1
  br i1 %130, label %133, label %131

131:                                              ; preds = %122
  %132 = sub nsw i8 85, %118
  br label %133

133:                                              ; preds = %122, %131
  %134 = phi i8 [ %132, %131 ], [ %129, %122 ]
  %135 = lshr i8 %134, 2
  %136 = zext nneg i8 %135 to i16
  %137 = shl nuw nsw i16 %136, 10
  %138 = add i8 %118, 85
  %139 = icmp sgt i8 %138, -1
  br i1 %139, label %142, label %140

140:                                              ; preds = %133
  %141 = sub nuw i8 -86, %118
  br label %142

142:                                              ; preds = %133, %140
  %143 = phi i8 [ %141, %140 ], [ %138, %133 ]
  %144 = lshr i8 %143, 2
  %145 = zext nneg i8 %144 to i16
  %146 = shl nuw nsw i16 %145, 5
  %147 = add nuw nsw i16 %146, %137
  br i1 %119, label %150, label %148

148:                                              ; preds = %142
  %149 = xor i8 %118, -1
  br label %150

150:                                              ; preds = %142, %148
  %151 = phi i8 [ %149, %148 ], [ %118, %142 ]
  %152 = lshr i8 %151, 2
  %153 = zext nneg i8 %152 to i16
  %154 = add nuw nsw i16 %147, %153
  br label %157

155:                                              ; preds = %109
  %156 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 29596, ptr %156, align 1, !tbaa !77
  br label %157

157:                                              ; preds = %155, %150
  %158 = phi i16 [ 0, %155 ], [ %154, %150 ]
  %159 = getelementptr inbounds nuw i8, ptr %0, i16 36
  store i16 %158, ptr %159, align 1, !tbaa !78
  %160 = icmp ugt i8 %110, 15
  br i1 %160, label %188, label %161

161:                                              ; preds = %157
  %162 = getelementptr inbounds nuw i8, ptr %0, i16 34
  %163 = zext nneg i8 %110 to i16
  %164 = add nuw nsw i8 %110, 1
  store i8 %164, ptr %81, align 1, !tbaa !44
  %165 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %163
  %166 = getelementptr inbounds nuw i8, ptr %165, i16 10
  store i8 1, ptr %166, align 1, !tbaa !45
  store i16 113, ptr %165, align 1, !tbaa !47
  %167 = getelementptr inbounds nuw i8, ptr %165, i16 9
  store i8 0, ptr %167, align 1, !tbaa !48
  %168 = getelementptr inbounds nuw i8, ptr %165, i16 7
  store i8 34, ptr %168, align 1, !tbaa !49
  %169 = getelementptr inbounds nuw i8, ptr %165, i16 8
  store i8 0, ptr %169, align 1, !tbaa !50
  %170 = ptrtoint ptr %162 to i16
  %171 = getelementptr inbounds nuw i8, ptr %165, i16 2
  store i16 %170, ptr %171, align 1, !tbaa !51
  %172 = getelementptr inbounds nuw i8, ptr %165, i16 6
  store i8 0, ptr %172, align 1, !tbaa !52
  %173 = getelementptr inbounds nuw i8, ptr %165, i16 4
  store i16 2, ptr %173, align 1, !tbaa !53
  %174 = icmp eq i8 %110, 15
  br i1 %174, label %188, label %175

175:                                              ; preds = %161
  %176 = getelementptr inbounds nuw i8, ptr %0, i16 36
  %177 = zext nneg i8 %164 to i16
  %178 = add nuw nsw i8 %110, 2
  store i8 %178, ptr %81, align 1, !tbaa !44
  %179 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %177
  %180 = getelementptr inbounds nuw i8, ptr %179, i16 10
  store i8 1, ptr %180, align 1, !tbaa !45
  store i16 0, ptr %179, align 1, !tbaa !47
  %181 = getelementptr inbounds nuw i8, ptr %179, i16 9
  store i8 0, ptr %181, align 1, !tbaa !48
  %182 = getelementptr inbounds nuw i8, ptr %179, i16 7
  store i8 34, ptr %182, align 1, !tbaa !49
  %183 = getelementptr inbounds nuw i8, ptr %179, i16 8
  store i8 0, ptr %183, align 1, !tbaa !50
  %184 = ptrtoint ptr %176 to i16
  %185 = getelementptr inbounds nuw i8, ptr %179, i16 2
  store i16 %184, ptr %185, align 1, !tbaa !51
  %186 = getelementptr inbounds nuw i8, ptr %179, i16 6
  store i8 0, ptr %186, align 1, !tbaa !52
  %187 = getelementptr inbounds nuw i8, ptr %179, i16 4
  store i16 2, ptr %187, align 1, !tbaa !53
  br label %188

188:                                              ; preds = %157, %175, %161, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @_title_write16(ptr noundef readonly captures(address_is_null) %0, i8 noundef zeroext %1, i8 noundef zeroext %2) unnamed_addr #3 {
  %4 = zext i8 %1 to i16
  %5 = shl nuw nsw i16 %4, 1
  %6 = and i16 %5, 254
  %7 = sub nsw i16 32, %6
  %8 = lshr exact i16 %7, 1
  %9 = zext i8 %2 to i16
  %10 = icmp eq ptr %0, null
  %11 = and i16 %8, 255
  %12 = add nuw i16 %8, %5
  %13 = and i16 %12, 255
  br label %15

14:                                               ; preds = %23
  ret void

15:                                               ; preds = %3, %23
  %16 = phi i1 [ true, %3 ], [ false, %23 ]
  %17 = phi i8 [ 0, %3 ], [ 1, %23 ]
  %18 = zext nneg i8 %17 to i16
  %19 = add nuw nsw i16 %18, %9
  %20 = shl nuw nsw i16 %19, 5
  %21 = add nuw nsw i16 %20, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %21, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %22 = select i1 %16, i16 7168, i16 7170
  br label %24

23:                                               ; preds = %56
  br i1 %16, label %15, label %14, !llvm.loop !131

24:                                               ; preds = %15, %56
  %25 = phi i8 [ 0, %15 ], [ %58, %56 ]
  %26 = zext nneg i8 %25 to i16
  br i1 %10, label %56, label %27

27:                                               ; preds = %24
  %28 = icmp samesign ugt i16 %11, %26
  br i1 %28, label %56, label %29

29:                                               ; preds = %27
  %30 = icmp samesign ugt i16 %13, %26
  br i1 %30, label %31, label %56

31:                                               ; preds = %29
  %32 = sub nsw i16 %26, %11
  %33 = lshr i16 %32, 1
  %34 = and i16 %33, 255
  %35 = getelementptr inbounds nuw i8, ptr %0, i16 %34
  %36 = load i8, ptr %35, align 1, !tbaa !6
  %37 = icmp ugt i8 %36, 96
  br i1 %37, label %38, label %42

38:                                               ; preds = %31
  %39 = icmp ult i8 %36, 123
  br i1 %39, label %40, label %51

40:                                               ; preds = %38
  %41 = add nsw i8 %36, -32
  br label %46

42:                                               ; preds = %31
  %43 = icmp samesign ugt i8 %36, 31
  br i1 %43, label %44, label %51

44:                                               ; preds = %42
  %45 = icmp eq i8 %36, 96
  br i1 %45, label %51, label %46

46:                                               ; preds = %44, %40
  %47 = phi i8 [ %41, %40 ], [ %36, %44 ]
  %48 = zext nneg i8 %47 to i16
  %49 = shl nuw nsw i16 %48, 2
  %50 = add nsw i16 %49, -64
  br label %51

51:                                               ; preds = %38, %42, %44, %46
  %52 = phi i16 [ %50, %46 ], [ 64, %44 ], [ 64, %42 ], [ 64, %38 ]
  %53 = and i16 %32, 1
  %54 = or disjoint i16 %22, %53
  %55 = or disjoint i16 %54, %52
  br label %56

56:                                               ; preds = %51, %29, %27, %24
  %57 = phi i16 [ %55, %51 ], [ 7168, %29 ], [ 7168, %27 ], [ 7168, %24 ]
  store volatile i16 %57, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %58 = add nuw nsw i8 %25, 1
  %59 = icmp eq i8 %58, 32
  br i1 %59, label %23, label %24, !llvm.loop !132
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_build(ptr noundef readonly captures(none) %0, i16 noundef range(i16 -2048, 2048) %1, i16 noundef range(i16 -2048, 2048) %2, ptr noundef %3, ptr noundef %4) unnamed_addr #6 {
  %6 = alloca %struct.HScrollW, align 1
  %7 = alloca %struct.HScrollW, align 1
  %8 = alloca i16, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #15
  store i16 0, ptr %8, align 1, !tbaa !2
  store ptr %3, ptr %6, align 1, !tbaa !133
  %9 = getelementptr inbounds nuw i8, ptr %6, i16 2
  store i8 0, ptr %9, align 1, !tbaa !135
  store ptr %4, ptr %7, align 1, !tbaa !133
  %10 = getelementptr inbounds nuw i8, ptr %7, i16 2
  store i8 0, ptr %10, align 1, !tbaa !135
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %12 = load i16, ptr %11, align 1, !tbaa !68
  %13 = getelementptr inbounds nuw i8, ptr %0, i16 26
  %14 = load i16, ptr %13, align 1, !tbaa !129
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %1, i16 noundef 8, i16 noundef %12, i16 noundef %14) #14
  %15 = getelementptr inbounds nuw i8, ptr %0, i16 17
  %16 = load i16, ptr %15, align 1, !tbaa !70
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %18 = load i16, ptr %17, align 1, !tbaa !69
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %2, i16 noundef %16, i16 noundef %18, i16 noundef 0) #14
  %19 = load i16, ptr %8, align 1, !tbaa !2
  call fastcc void @_title_blank(ptr noundef %6, ptr noundef %7, i16 noundef %19, i16 noundef 224) #14
  %20 = load ptr, ptr %6, align 1, !tbaa !133
  %21 = load i8, ptr %9, align 1, !tbaa !135
  %22 = zext i8 %21 to i16
  %23 = getelementptr inbounds nuw i8, ptr %20, i16 %22
  store i8 0, ptr %23, align 1, !tbaa !6
  %24 = load ptr, ptr %7, align 1, !tbaa !133
  %25 = load i8, ptr %10, align 1, !tbaa !135
  %26 = zext i8 %25 to i16
  %27 = getelementptr inbounds nuw i8, ptr %24, i16 %26
  store i8 0, ptr %27, align 1, !tbaa !6
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #15
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #15
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #15
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_glyph_band(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, ptr noundef nonnull captures(none) %2, i16 noundef range(i16 -2048, 2048) %3, i16 noundef %4, i16 noundef %5, i16 noundef %6) unnamed_addr #6 {
  %8 = add nsw i16 %3, -2
  %9 = add nsw i16 %4, %3
  %10 = add nsw i16 %9, 2
  %11 = load i16, ptr %2, align 1, !tbaa !2
  %12 = icmp slt i16 %8, %11
  br i1 %12, label %13, label %14

13:                                               ; preds = %7
  br label %14

14:                                               ; preds = %13, %7
  %15 = phi i16 [ %11, %13 ], [ %8, %7 ]
  %16 = icmp sgt i16 %9, 222
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  br label %18

18:                                               ; preds = %17, %14
  %19 = phi i16 [ 224, %17 ], [ %10, %14 ]
  %20 = icmp sgt i16 %19, %15
  br i1 %20, label %21, label %92

21:                                               ; preds = %18
  tail call fastcc void @_title_blank(ptr noundef %0, ptr noundef %1, i16 noundef %11, i16 noundef %15) #14
  %22 = sub nsw i16 %19, %15
  %23 = trunc i16 %22 to i8
  %24 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %25 = icmp eq i8 %23, 0
  br i1 %25, label %91, label %26

26:                                               ; preds = %21
  %27 = sub nsw i16 %5, %3
  %28 = and i16 %22, 255
  %29 = trunc i16 %27 to i8
  %30 = lshr i16 %27, 8
  %31 = trunc nuw i16 %30 to i8
  br label %32

32:                                               ; preds = %40, %26
  %33 = phi i16 [ %28, %26 ], [ %57, %40 ]
  %34 = load i8, ptr %24, align 1, !tbaa !135
  %35 = icmp ult i8 %34, 22
  br i1 %35, label %36, label %59

36:                                               ; preds = %32
  %37 = icmp ugt i16 %33, 127
  br i1 %37, label %40, label %38

38:                                               ; preds = %36
  %39 = trunc nuw nsw i16 %33 to i8
  br label %40

40:                                               ; preds = %38, %36
  %41 = phi i8 [ %39, %38 ], [ 127, %36 ]
  %42 = load ptr, ptr %0, align 1, !tbaa !133
  %43 = add nuw nsw i8 %34, 1
  store i8 %43, ptr %24, align 1, !tbaa !135
  %44 = zext nneg i8 %34 to i16
  %45 = getelementptr inbounds nuw i8, ptr %42, i16 %44
  store i8 %41, ptr %45, align 1, !tbaa !6
  %46 = load ptr, ptr %0, align 1, !tbaa !133
  %47 = load i8, ptr %24, align 1, !tbaa !135
  %48 = add i8 %47, 1
  store i8 %48, ptr %24, align 1, !tbaa !135
  %49 = zext i8 %47 to i16
  %50 = getelementptr inbounds nuw i8, ptr %46, i16 %49
  store i8 %29, ptr %50, align 1, !tbaa !6
  %51 = load ptr, ptr %0, align 1, !tbaa !133
  %52 = load i8, ptr %24, align 1, !tbaa !135
  %53 = add i8 %52, 1
  store i8 %53, ptr %24, align 1, !tbaa !135
  %54 = zext i8 %52 to i16
  %55 = getelementptr inbounds nuw i8, ptr %51, i16 %54
  store i8 %31, ptr %55, align 1, !tbaa !6
  %56 = zext nneg i8 %41 to i16
  %57 = sub i16 %33, %56
  %58 = icmp eq i16 %57, 0
  br i1 %58, label %59, label %32, !llvm.loop !136

59:                                               ; preds = %32, %40
  %60 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %61 = trunc i16 %6 to i8
  %62 = lshr i16 %6, 8
  %63 = trunc nuw i16 %62 to i8
  br label %64

64:                                               ; preds = %72, %59
  %65 = phi i16 [ %28, %59 ], [ %89, %72 ]
  %66 = load i8, ptr %60, align 1, !tbaa !135
  %67 = icmp ult i8 %66, 22
  br i1 %67, label %68, label %91

68:                                               ; preds = %64
  %69 = icmp ugt i16 %65, 127
  br i1 %69, label %72, label %70

70:                                               ; preds = %68
  %71 = trunc nuw nsw i16 %65 to i8
  br label %72

72:                                               ; preds = %70, %68
  %73 = phi i8 [ %71, %70 ], [ 127, %68 ]
  %74 = load ptr, ptr %1, align 1, !tbaa !133
  %75 = add nuw nsw i8 %66, 1
  store i8 %75, ptr %60, align 1, !tbaa !135
  %76 = zext nneg i8 %66 to i16
  %77 = getelementptr inbounds nuw i8, ptr %74, i16 %76
  store i8 %73, ptr %77, align 1, !tbaa !6
  %78 = load ptr, ptr %1, align 1, !tbaa !133
  %79 = load i8, ptr %60, align 1, !tbaa !135
  %80 = add i8 %79, 1
  store i8 %80, ptr %60, align 1, !tbaa !135
  %81 = zext i8 %79 to i16
  %82 = getelementptr inbounds nuw i8, ptr %78, i16 %81
  store i8 %61, ptr %82, align 1, !tbaa !6
  %83 = load ptr, ptr %1, align 1, !tbaa !133
  %84 = load i8, ptr %60, align 1, !tbaa !135
  %85 = add i8 %84, 1
  store i8 %85, ptr %60, align 1, !tbaa !135
  %86 = zext i8 %84 to i16
  %87 = getelementptr inbounds nuw i8, ptr %83, i16 %86
  store i8 %63, ptr %87, align 1, !tbaa !6
  %88 = zext nneg i8 %73 to i16
  %89 = sub i16 %65, %88
  %90 = icmp eq i16 %89, 0
  br i1 %90, label %91, label %64, !llvm.loop !136

91:                                               ; preds = %64, %72, %21
  store i16 %19, ptr %2, align 1, !tbaa !2
  br label %92

92:                                               ; preds = %18, %91
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_blank(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, i16 noundef %2, i16 noundef range(i16 -2050, 225) %3) unnamed_addr #6 {
  %5 = icmp sgt i16 %3, %2
  br i1 %5, label %6, label %83

6:                                                ; preds = %4
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 2
  br label %9

9:                                                ; preds = %6, %79
  %10 = phi i16 [ %2, %6 ], [ %81, %79 ]
  %11 = sub nsw i16 %3, %10
  %12 = icmp sgt i16 %11, 112
  br i1 %12, label %16, label %13

13:                                               ; preds = %9
  %14 = trunc i16 %11 to i8
  %15 = icmp eq i8 %14, 0
  br i1 %15, label %79, label %16

16:                                               ; preds = %9, %13
  %17 = phi i8 [ %14, %13 ], [ 112, %9 ]
  %18 = phi i16 [ %11, %13 ], [ 112, %9 ]
  %19 = sub nsw i16 144, %10
  %20 = zext i8 %17 to i16
  %21 = trunc i16 %19 to i8
  %22 = lshr i16 %19, 8
  %23 = trunc nuw i16 %22 to i8
  br label %24

24:                                               ; preds = %32, %16
  %25 = phi i16 [ %20, %16 ], [ %49, %32 ]
  %26 = load i8, ptr %7, align 1, !tbaa !135
  %27 = icmp ult i8 %26, 22
  br i1 %27, label %28, label %51

28:                                               ; preds = %24
  %29 = icmp ugt i16 %25, 127
  br i1 %29, label %32, label %30

30:                                               ; preds = %28
  %31 = trunc nuw nsw i16 %25 to i8
  br label %32

32:                                               ; preds = %30, %28
  %33 = phi i8 [ %31, %30 ], [ 127, %28 ]
  %34 = load ptr, ptr %0, align 1, !tbaa !133
  %35 = add nuw nsw i8 %26, 1
  store i8 %35, ptr %7, align 1, !tbaa !135
  %36 = zext nneg i8 %26 to i16
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 %36
  store i8 %33, ptr %37, align 1, !tbaa !6
  %38 = load ptr, ptr %0, align 1, !tbaa !133
  %39 = load i8, ptr %7, align 1, !tbaa !135
  %40 = add i8 %39, 1
  store i8 %40, ptr %7, align 1, !tbaa !135
  %41 = zext i8 %39 to i16
  %42 = getelementptr inbounds nuw i8, ptr %38, i16 %41
  store i8 %21, ptr %42, align 1, !tbaa !6
  %43 = load ptr, ptr %0, align 1, !tbaa !133
  %44 = load i8, ptr %7, align 1, !tbaa !135
  %45 = add i8 %44, 1
  store i8 %45, ptr %7, align 1, !tbaa !135
  %46 = zext i8 %44 to i16
  %47 = getelementptr inbounds nuw i8, ptr %43, i16 %46
  store i8 %23, ptr %47, align 1, !tbaa !6
  %48 = zext nneg i8 %33 to i16
  %49 = sub i16 %25, %48
  %50 = icmp eq i16 %49, 0
  br i1 %50, label %51, label %24, !llvm.loop !136

51:                                               ; preds = %24, %32
  br label %52

52:                                               ; preds = %51, %60
  %53 = phi i16 [ %77, %60 ], [ %20, %51 ]
  %54 = load i8, ptr %8, align 1, !tbaa !135
  %55 = icmp ult i8 %54, 22
  br i1 %55, label %56, label %79

56:                                               ; preds = %52
  %57 = icmp ugt i16 %53, 127
  br i1 %57, label %60, label %58

58:                                               ; preds = %56
  %59 = trunc nuw nsw i16 %53 to i8
  br label %60

60:                                               ; preds = %58, %56
  %61 = phi i8 [ %59, %58 ], [ 127, %56 ]
  %62 = load ptr, ptr %1, align 1, !tbaa !133
  %63 = add nuw nsw i8 %54, 1
  store i8 %63, ptr %8, align 1, !tbaa !135
  %64 = zext nneg i8 %54 to i16
  %65 = getelementptr inbounds nuw i8, ptr %62, i16 %64
  store i8 %61, ptr %65, align 1, !tbaa !6
  %66 = load ptr, ptr %1, align 1, !tbaa !133
  %67 = load i8, ptr %8, align 1, !tbaa !135
  %68 = add i8 %67, 1
  store i8 %68, ptr %8, align 1, !tbaa !135
  %69 = zext i8 %67 to i16
  %70 = getelementptr inbounds nuw i8, ptr %66, i16 %69
  store i8 0, ptr %70, align 1, !tbaa !6
  %71 = load ptr, ptr %1, align 1, !tbaa !133
  %72 = load i8, ptr %8, align 1, !tbaa !135
  %73 = add i8 %72, 1
  store i8 %73, ptr %8, align 1, !tbaa !135
  %74 = zext i8 %72 to i16
  %75 = getelementptr inbounds nuw i8, ptr %71, i16 %74
  store i8 0, ptr %75, align 1, !tbaa !6
  %76 = zext nneg i8 %61 to i16
  %77 = sub i16 %53, %76
  %78 = icmp eq i16 %77, 0
  br i1 %78, label %79, label %52, !llvm.loop !136

79:                                               ; preds = %52, %60, %13
  %80 = phi i16 [ %11, %13 ], [ %18, %60 ], [ %18, %52 ]
  %81 = add nsw i16 %80, %10
  %82 = icmp sgt i16 %3, %81
  br i1 %82, label %9, label %83, !llvm.loop !137

83:                                               ; preds = %79, %4
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal fastcc void @ms_edge_point(i8 noundef zeroext %0, i16 noundef range(i16 0, 32) %1, i16 noundef range(i16 0, 32) %2, i32 noundef range(i32 -32768, 32768) %3, i32 noundef range(i32 -32768, 32768) %4, i32 noundef range(i32 -32768, 32768) %5, i32 noundef range(i32 -32768, 32768) %6, ptr noundef nonnull writeonly captures(none) initializes((0, 2)) %7, ptr noundef nonnull writeonly captures(none) initializes((0, 2)) %8) unnamed_addr #7 {
  %10 = shl nuw nsw i16 %1, 4
  %11 = shl nuw nsw i16 %2, 4
  switch i8 %0, label %59 [
    i8 0, label %12
    i8 1, label %27
    i8 2, label %43
  ]

12:                                               ; preds = %9
  %13 = icmp eq i32 %4, %3
  br i1 %13, label %24, label %14

14:                                               ; preds = %12
  %15 = sub nsw i32 %4, %3
  %16 = shl nsw i32 %3, 4
  %17 = sub nsw i32 11200, %16
  %18 = sdiv i32 %17, %15
  %19 = icmp slt i32 %18, 0
  br i1 %19, label %24, label %20

20:                                               ; preds = %14
  %21 = icmp samesign ugt i32 %18, 16
  %22 = trunc nuw nsw i32 %18 to i16
  br i1 %21, label %23, label %24

23:                                               ; preds = %20
  br label %24

24:                                               ; preds = %12, %14, %20, %23
  %25 = phi i16 [ 8, %12 ], [ %22, %20 ], [ 16, %23 ], [ 0, %14 ]
  %26 = add nuw nsw i16 %25, %10
  store i16 %26, ptr %7, align 1, !tbaa !2
  br label %74

27:                                               ; preds = %9
  %28 = add nuw nsw i16 %10, 16
  store i16 %28, ptr %7, align 1, !tbaa !2
  %29 = icmp eq i32 %5, %4
  br i1 %29, label %40, label %30

30:                                               ; preds = %27
  %31 = sub nsw i32 %5, %4
  %32 = shl nsw i32 %4, 4
  %33 = sub nsw i32 11200, %32
  %34 = sdiv i32 %33, %31
  %35 = icmp slt i32 %34, 0
  br i1 %35, label %40, label %36

36:                                               ; preds = %30
  %37 = icmp samesign ugt i32 %34, 16
  %38 = trunc nuw nsw i32 %34 to i16
  br i1 %37, label %39, label %40

39:                                               ; preds = %36
  br label %40

40:                                               ; preds = %27, %30, %36, %39
  %41 = phi i16 [ 8, %27 ], [ %38, %36 ], [ 16, %39 ], [ 0, %30 ]
  %42 = add nuw nsw i16 %41, %11
  br label %74

43:                                               ; preds = %9
  %44 = icmp eq i32 %5, %6
  br i1 %44, label %55, label %45

45:                                               ; preds = %43
  %46 = sub nsw i32 %5, %6
  %47 = shl nsw i32 %6, 4
  %48 = sub nsw i32 11200, %47
  %49 = sdiv i32 %48, %46
  %50 = icmp slt i32 %49, 0
  br i1 %50, label %55, label %51

51:                                               ; preds = %45
  %52 = icmp samesign ugt i32 %49, 16
  %53 = trunc nuw nsw i32 %49 to i16
  br i1 %52, label %54, label %55

54:                                               ; preds = %51
  br label %55

55:                                               ; preds = %43, %45, %51, %54
  %56 = phi i16 [ 8, %43 ], [ %53, %51 ], [ 16, %54 ], [ 0, %45 ]
  %57 = add nuw nsw i16 %56, %10
  store i16 %57, ptr %7, align 1, !tbaa !2
  %58 = add nuw nsw i16 %11, 16
  br label %74

59:                                               ; preds = %9
  store i16 %10, ptr %7, align 1, !tbaa !2
  %60 = icmp eq i32 %6, %3
  br i1 %60, label %71, label %61

61:                                               ; preds = %59
  %62 = sub nsw i32 %6, %3
  %63 = shl nsw i32 %3, 4
  %64 = sub nsw i32 11200, %63
  %65 = sdiv i32 %64, %62
  %66 = icmp slt i32 %65, 0
  br i1 %66, label %71, label %67

67:                                               ; preds = %61
  %68 = icmp samesign ugt i32 %65, 16
  %69 = trunc nuw nsw i32 %65 to i16
  br i1 %68, label %70, label %71

70:                                               ; preds = %67
  br label %71

71:                                               ; preds = %59, %61, %67, %70
  %72 = phi i16 [ 8, %59 ], [ %69, %67 ], [ 16, %70 ], [ 0, %61 ]
  %73 = add nuw nsw i16 %72, %11
  br label %74

74:                                               ; preds = %71, %55, %40, %24
  %75 = phi i16 [ %73, %71 ], [ %58, %55 ], [ %42, %40 ], [ %11, %24 ]
  store i16 %75, ptr %8, align 1, !tbaa !2
  ret void
}

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none)
define internal fastcc void @canvas_line(i16 noundef range(i16 -8192, 8192) %0, i16 noundef range(i16 -8192, 8192) %1, i16 noundef range(i16 -8192, 8192) %2, i16 noundef range(i16 -8192, 8192) %3) unnamed_addr #8 {
  %5 = icmp sgt i16 %2, %0
  br i1 %5, label %6, label %8

6:                                                ; preds = %4
  %7 = sub nsw i16 %2, %0
  br label %10

8:                                                ; preds = %4
  %9 = sub nsw i16 %0, %2
  br label %10

10:                                               ; preds = %8, %6
  %11 = phi i16 [ %7, %6 ], [ %9, %8 ]
  %12 = icmp sgt i16 %3, %1
  br i1 %12, label %13, label %15

13:                                               ; preds = %10
  %14 = sub nsw i16 %3, %1
  br label %17

15:                                               ; preds = %10
  %16 = sub nsw i16 %1, %3
  br label %17

17:                                               ; preds = %15, %13
  %18 = phi i16 [ 1, %13 ], [ -1, %15 ]
  %19 = phi i16 [ %14, %13 ], [ %16, %15 ]
  %20 = select i1 %5, i16 1, i16 -1
  %21 = sub nsw i16 %11, %19
  %22 = sub nsw i16 0, %19
  br label %23

23:                                               ; preds = %71, %17
  %24 = phi i16 [ %73, %71 ], [ %1, %17 ]
  %25 = phi i16 [ %72, %71 ], [ %21, %17 ]
  %26 = phi i16 [ %69, %71 ], [ %0, %17 ]
  %27 = icmp ugt i16 %24, 127
  %28 = shl nuw nsw i16 %24, 1
  %29 = and i16 %28, 240
  %30 = and i16 %28, 14
  %31 = getelementptr inbounds i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %30
  %32 = icmp eq i16 %24, %3
  br label %33

33:                                               ; preds = %23, %67
  %34 = phi i16 [ %68, %67 ], [ %25, %23 ]
  %35 = phi i16 [ %69, %67 ], [ %26, %23 ]
  %36 = icmp ugt i16 %35, 127
  %37 = select i1 %36, i1 true, i1 %27
  br i1 %37, label %58, label %38

38:                                               ; preds = %33
  %39 = lshr i16 %35, 3
  %40 = or disjoint i16 %39, %29
  %41 = shl nuw nsw i16 %40, 4
  %42 = getelementptr inbounds i8, ptr %31, i16 %41
  %43 = and i16 %35, 7
  %44 = lshr exact i16 128, %43
  %45 = load i8, ptr %42, align 1, !tbaa !6
  %46 = trunc nuw i16 %44 to i8
  %47 = or i8 %45, %46
  store i8 %47, ptr %42, align 1, !tbaa !6
  %48 = getelementptr inbounds nuw i8, ptr %42, i16 1
  %49 = load i8, ptr %48, align 1, !tbaa !6
  %50 = or i8 %49, %46
  store i8 %50, ptr %48, align 1, !tbaa !6
  %51 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %52 = icmp ult i16 %40, %51
  br i1 %52, label %53, label %54

53:                                               ; preds = %38
  store i16 %40, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %54

54:                                               ; preds = %53, %38
  %55 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %56 = icmp ugt i16 %40, %55
  br i1 %56, label %57, label %58

57:                                               ; preds = %54
  store i16 %40, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %58

58:                                               ; preds = %33, %54, %57
  %59 = icmp eq i16 %35, %2
  %60 = select i1 %59, i1 %32, i1 false
  br i1 %60, label %74, label %61

61:                                               ; preds = %58
  %62 = shl nsw i16 %34, 1
  %63 = icmp sgt i16 %62, %22
  br i1 %63, label %64, label %67

64:                                               ; preds = %61
  %65 = sub nsw i16 %34, %19
  %66 = add nsw i16 %35, %20
  br label %67

67:                                               ; preds = %64, %61
  %68 = phi i16 [ %65, %64 ], [ %34, %61 ]
  %69 = phi i16 [ %66, %64 ], [ %35, %61 ]
  %70 = icmp slt i16 %62, %11
  br i1 %70, label %71, label %33

71:                                               ; preds = %67
  %72 = add nsw i16 %68, %11
  %73 = add nsw i16 %24, %18
  br label %23

74:                                               ; preds = %58
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @upq_flush() unnamed_addr #9 {
  %1 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 177), align 1, !tbaa !138
  %2 = zext i8 %1 to i16
  %3 = shl nuw nsw i16 %2, 4
  %4 = add nuw nsw i16 %3, 17152
  %5 = inttoptr i16 %4 to ptr
  %6 = shl nuw i16 1, %2
  %7 = trunc i16 %6 to i8
  %8 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %108, label %10

10:                                               ; preds = %0
  %11 = getelementptr inbounds nuw i8, ptr %5, i16 1
  %12 = getelementptr inbounds nuw i8, ptr %5, i16 2
  %13 = getelementptr inbounds nuw i8, ptr %5, i16 3
  %14 = getelementptr inbounds nuw i8, ptr %5, i16 4
  %15 = getelementptr inbounds nuw i8, ptr %5, i16 5
  %16 = getelementptr inbounds nuw i8, ptr %5, i16 6
  br label %17

17:                                               ; preds = %10, %86
  %18 = phi i8 [ %8, %10 ], [ %89, %86 ]
  %19 = phi i16 [ 0, %10 ], [ %87, %86 ]
  %20 = phi i8 [ 0, %10 ], [ %88, %86 ]
  %21 = zext i8 %20 to i16
  %22 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %21
  %23 = getelementptr inbounds nuw i8, ptr %22, i16 10
  %24 = load i8, ptr %23, align 1, !tbaa !45
  switch i8 %24, label %44 [
    i8 3, label %25
    i8 4, label %34
  ]

25:                                               ; preds = %17
  %26 = load i16, ptr %22, align 1, !tbaa !47
  %27 = inttoptr i16 %26 to ptr
  %28 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %29 = load i16, ptr %28, align 1, !tbaa !51
  %30 = trunc i16 %29 to i8
  store volatile i8 %30, ptr %27, align 1, !tbaa !6
  %31 = load i16, ptr %28, align 1, !tbaa !51
  %32 = lshr i16 %31, 8
  %33 = trunc nuw i16 %32 to i8
  store volatile i8 %33, ptr %27, align 1, !tbaa !6
  br label %86

34:                                               ; preds = %17
  %35 = load i16, ptr %22, align 1, !tbaa !47
  %36 = inttoptr i16 %35 to ptr
  %37 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %38 = load i16, ptr %37, align 1, !tbaa !51
  %39 = trunc i16 %38 to i8
  store volatile i8 %39, ptr %36, align 1, !tbaa !6
  %40 = load i16, ptr %37, align 1, !tbaa !51
  %41 = lshr i16 %40, 8
  %42 = trunc nuw i16 %41 to i8
  %43 = getelementptr inbounds nuw i8, ptr %36, i16 1
  store volatile i8 %42, ptr %43, align 1, !tbaa !6
  br label %86

44:                                               ; preds = %17
  %45 = icmp eq i16 %19, 0
  br i1 %45, label %51, label %46

46:                                               ; preds = %44
  %47 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %48 = load i16, ptr %47, align 1, !tbaa !53
  %49 = add i16 %48, %19
  %50 = icmp ugt i16 %49, 5100
  br i1 %50, label %91, label %51

51:                                               ; preds = %46, %44
  switch i8 %24, label %59 [
    i8 0, label %52
    i8 1, label %56
  ]

52:                                               ; preds = %51
  %53 = getelementptr inbounds nuw i8, ptr %22, i16 9
  %54 = load i8, ptr %53, align 1, !tbaa !48
  store volatile i8 %54, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  %55 = load i16, ptr %22, align 1, !tbaa !47
  store volatile i16 %55, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %65

56:                                               ; preds = %51
  %57 = load i16, ptr %22, align 1, !tbaa !47
  %58 = trunc i16 %57 to i8
  store volatile i8 %58, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  br label %65

59:                                               ; preds = %51
  %60 = load i16, ptr %22, align 1, !tbaa !47
  %61 = trunc i16 %60 to i8
  store volatile i8 %61, ptr inttoptr (i16 8450 to ptr), align 2, !tbaa !6
  %62 = load i16, ptr %22, align 1, !tbaa !47
  %63 = lshr i16 %62, 8
  %64 = trunc nuw i16 %63 to i8
  store volatile i8 %64, ptr inttoptr (i16 8451 to ptr), align 1, !tbaa !6
  br label %65

65:                                               ; preds = %56, %59, %52
  %66 = getelementptr inbounds nuw i8, ptr %22, i16 8
  %67 = load i8, ptr %66, align 1, !tbaa !50
  store volatile i8 %67, ptr %5, align 16, !tbaa !6
  %68 = getelementptr inbounds nuw i8, ptr %22, i16 7
  %69 = load i8, ptr %68, align 1, !tbaa !49
  store volatile i8 %69, ptr %11, align 1, !tbaa !6
  %70 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %71 = load i16, ptr %70, align 1, !tbaa !51
  %72 = trunc i16 %71 to i8
  store volatile i8 %72, ptr %12, align 2, !tbaa !6
  %73 = load i16, ptr %70, align 1, !tbaa !51
  %74 = lshr i16 %73, 8
  %75 = trunc nuw i16 %74 to i8
  store volatile i8 %75, ptr %13, align 1, !tbaa !6
  %76 = getelementptr inbounds nuw i8, ptr %22, i16 6
  %77 = load i8, ptr %76, align 1, !tbaa !52
  store volatile i8 %77, ptr %14, align 4, !tbaa !6
  %78 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %79 = load i16, ptr %78, align 1, !tbaa !53
  %80 = trunc i16 %79 to i8
  store volatile i8 %80, ptr %15, align 1, !tbaa !6
  %81 = load i16, ptr %78, align 1, !tbaa !53
  %82 = lshr i16 %81, 8
  %83 = trunc nuw i16 %82 to i8
  store volatile i8 %83, ptr %16, align 2, !tbaa !6
  store volatile i8 %7, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !6
  %84 = load i16, ptr %78, align 1, !tbaa !53
  %85 = add i16 %84, %19
  br label %86

86:                                               ; preds = %65, %34, %25
  %87 = phi i16 [ %19, %25 ], [ %19, %34 ], [ %85, %65 ]
  %88 = add nuw i8 %20, 1
  %89 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %90 = icmp ult i8 %88, %89
  br i1 %90, label %17, label %91

91:                                               ; preds = %86, %46
  %92 = phi i8 [ %89, %86 ], [ %18, %46 ]
  %93 = phi i8 [ %88, %86 ], [ %20, %46 ]
  %94 = icmp ult i8 %93, %92
  br i1 %94, label %95, label %108

95:                                               ; preds = %91
  %96 = icmp eq i8 %93, 0
  br i1 %96, label %110, label %97

97:                                               ; preds = %95, %97
  %98 = phi i8 [ %101, %97 ], [ 0, %95 ]
  %99 = phi i8 [ %104, %97 ], [ %93, %95 ]
  %100 = zext i8 %99 to i16
  %101 = add i8 %98, 1
  %102 = zext i8 %98 to i16
  %103 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %102
  %104 = add nuw i8 %99, 1
  %105 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %100
  tail call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(11) %103, ptr noundef nonnull align 1 dereferenceable(11) %105, i16 11, i1 false), !tbaa.struct !139
  %106 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %107 = icmp ult i8 %104, %106
  br i1 %107, label %97, label %108, !llvm.loop !140

108:                                              ; preds = %97, %91, %0
  %109 = phi i8 [ 0, %91 ], [ 0, %0 ], [ %101, %97 ]
  store i8 %109, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  br label %110

110:                                              ; preds = %108, %95
  ret void
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #11

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #12

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #12

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { nofree noinline norecurse nosync nounwind optsize memory(readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { nofree norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #4 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #5 = { nofree norecurse nosync nounwind optsize memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #6 = { nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #7 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #8 = { nofree noinline norecurse nosync nounwind optsize memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #9 = { nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #10 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #11 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #13 = { nounwind optsize }
attributes #14 = { optsize }
attributes #15 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!10, !4, i64 194}
!10 = !{!"", !11, i64 0, !12, i64 178, !13, i64 182, !4, i64 191, !4, i64 192, !4, i64 193, !4, i64 194, !4, i64 195}
!11 = !{!"", !4, i64 0, !4, i64 176, !4, i64 177}
!12 = !{!"", !3, i64 0, !3, i64 2}
!13 = !{!"", !4, i64 0, !4, i64 8}
!14 = !{!10, !4, i64 195}
!15 = !{!16, !18, i64 0}
!16 = !{!"", !17, i64 0, !4, i64 3, !3, i64 4099, !3, i64 4101, !3, i64 4103, !3, i64 4105, !4, i64 4107, !4, i64 4108}
!17 = !{!"Drawable", !18, i64 0, !4, i64 2}
!18 = !{!"any pointer", !4, i64 0}
!19 = !{!16, !4, i64 2}
!20 = !{!16, !3, i64 4103}
!21 = !{!16, !3, i64 4105}
!22 = !{!16, !4, i64 4107}
!23 = !{!16, !4, i64 4108}
!24 = !{!16, !3, i64 4099}
!25 = !{!16, !3, i64 4101}
!26 = !{!27, !18, i64 0}
!27 = !{!"", !17, i64 0, !3, i64 3, !4, i64 5, !4, i64 7, !4, i64 135}
!28 = !{!27, !4, i64 2}
!29 = !{!27, !3, i64 3}
!30 = distinct !{!30, !8}
!31 = !{!27, !4, i64 135}
!32 = !{!10, !4, i64 192}
!33 = !{!10, !4, i64 193}
!34 = !{!13, !4, i64 8}
!35 = !{!36, !36, i64 0}
!36 = !{!"p1 _ZTS8Drawable", !18, i64 0}
!37 = distinct !{null, null}
!38 = !{!10, !4, i64 191}
!39 = !{!17, !4, i64 2}
!40 = !{!17, !18, i64 0}
!41 = !{!42, !18, i64 0}
!42 = !{!"", !18, i64 0, !18, i64 2}
!43 = distinct !{null, null, null}
!44 = !{!11, !4, i64 176}
!45 = !{!46, !4, i64 10}
!46 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !4, i64 6, !4, i64 7, !4, i64 8, !4, i64 9, !4, i64 10}
!47 = !{!46, !3, i64 0}
!48 = !{!46, !4, i64 9}
!49 = !{!46, !4, i64 7}
!50 = !{!46, !4, i64 8}
!51 = !{!46, !3, i64 2}
!52 = !{!46, !4, i64 6}
!53 = !{!46, !3, i64 4}
!54 = !{!55, !3, i64 4441}
!55 = !{!"", !10, i64 0, !16, i64 196, !27, i64 4305, !3, i64 4441, !4, i64 4443}
!56 = distinct !{!56, !8}
!57 = !{!58, !18, i64 0}
!58 = !{!"", !17, i64 0, !59, i64 3, !59, i64 5, !59, i64 7, !59, i64 9, !4, i64 11, !4, i64 12, !3, i64 13, !3, i64 15, !3, i64 17, !3, i64 19, !3, i64 21, !3, i64 23, !4, i64 25, !3, i64 26, !4, i64 28, !4, i64 29, !4, i64 30, !4, i64 31, !4, i64 32, !4, i64 33, !3, i64 34, !3, i64 36, !60, i64 38, !60, i64 89}
!59 = !{!"p1 omnipotent char", !18, i64 0}
!60 = !{!"", !4, i64 0, !4, i64 50}
!61 = !{!58, !4, i64 2}
!62 = !{!58, !59, i64 3}
!63 = !{!58, !59, i64 5}
!64 = !{!58, !59, i64 7}
!65 = !{!58, !4, i64 11}
!66 = !{!58, !59, i64 9}
!67 = !{!58, !4, i64 12}
!68 = !{!58, !3, i64 13}
!69 = !{!58, !3, i64 15}
!70 = !{!58, !3, i64 17}
!71 = !{!58, !4, i64 28}
!72 = !{!58, !4, i64 29}
!73 = !{!58, !4, i64 31}
!74 = !{!58, !4, i64 32}
!75 = !{!58, !4, i64 30}
!76 = !{!58, !4, i64 25}
!77 = !{!58, !3, i64 34}
!78 = !{!58, !3, i64 36}
!79 = !{!58, !4, i64 33}
!80 = !{!42, !18, i64 2}
!81 = distinct !{null, null, null, null, null}
!82 = distinct !{!82, !8}
!83 = distinct !{!83, !8}
!84 = distinct !{!84, !8}
!85 = distinct !{null, null, null, null}
!86 = distinct !{!86, !8}
!87 = distinct !{!87, !8}
!88 = distinct !{!88, !8}
!89 = distinct !{!89, !8}
!90 = distinct !{!90, !8}
!91 = distinct !{!91, !8}
!92 = distinct !{!92, !8}
!93 = distinct !{!93, !8}
!94 = distinct !{null, null, null, null, null}
!95 = distinct !{!95, !8}
!96 = distinct !{!96, !8}
!97 = distinct !{null, null, null, null}
!98 = !{!58, !3, i64 19}
!99 = distinct !{null, null, null, null, null}
!100 = distinct !{null, null, null}
!101 = distinct !{!101, !8}
!102 = distinct !{!102, !8}
!103 = distinct !{!103, !8}
!104 = !{!55, !3, i64 4295}
!105 = !{!55, !3, i64 4297}
!106 = distinct !{!106, !8}
!107 = distinct !{!107, !8}
!108 = distinct !{!108, !8}
!109 = distinct !{!109, !8}
!110 = distinct !{!110, !8}
!111 = distinct !{!111, !8}
!112 = distinct !{!112, !8}
!113 = distinct !{!113, !8}
!114 = distinct !{!114, !8}
!115 = distinct !{!115, !8}
!116 = distinct !{!116, !8}
!117 = distinct !{!117, !8}
!118 = distinct !{!118, !8}
!119 = distinct !{!119, !8}
!120 = distinct !{!120, !8}
!121 = distinct !{!121, !8}
!122 = distinct !{!122, !8}
!123 = distinct !{!123, !8}
!124 = distinct !{!124, !8}
!125 = distinct !{!125, !8}
!126 = !{!58, !3, i64 21}
!127 = !{!58, !3, i64 23}
!128 = distinct !{!128, !8}
!129 = !{!58, !3, i64 26}
!130 = !{!60, !4, i64 50}
!131 = distinct !{!131, !8}
!132 = distinct !{!132, !8}
!133 = !{!134, !18, i64 0}
!134 = !{!"", !18, i64 0, !4, i64 2}
!135 = !{!134, !4, i64 2}
!136 = distinct !{!136, !8}
!137 = distinct !{!137, !8}
!138 = !{!11, !4, i64 177}
!139 = !{i64 0, i64 2, !2, i64 2, i64 2, !2, i64 4, i64 2, !2, i64 6, i64 1, !6, i64 7, i64 1, !6, i64 8, i64 1, !6, i64 9, i64 1, !6, i64 10, i64 1, !6}
!140 = distinct !{!140, !8}
