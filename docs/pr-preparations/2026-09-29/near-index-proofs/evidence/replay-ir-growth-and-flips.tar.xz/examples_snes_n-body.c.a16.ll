; ModuleID = '/work/examples/snes/n-body.c'
source_filename = "/work/examples/snes/n-body.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.App = type { %struct.Display, %struct.BitmapCanvas, %struct.TextLayer, [3 x %struct.NBody], [3 x %struct.BodyTrail], i16, i8, i8, i8, i8 }
%struct.Display = type { %struct.UploadQueue, %struct.VramAlloc, %struct.Scene, i8, i8, i8, i8, i8 }
%struct.UploadQueue = type { [16 x %struct.UpqJob], i8, i8 }
%struct.UpqJob = type { i16, i16, i16, i8, i8, i8, i8, i8 }
%struct.VramAlloc = type { i16, i16 }
%struct.Scene = type { [4 x ptr], i8 }
%struct.BitmapCanvas = type { %struct.Drawable, [4096 x i8], i16, i16, i16, i16, i8, i8 }
%struct.Drawable = type { ptr, i8 }
%struct.TextLayer = type { %struct.Drawable, i16, [2 x i8], [64 x i16], i8 }
%struct.NBody = type { i16, i16, i16, i16, i8 }
%struct.BodyTrail = type { [64 x i8], [64 x i8], i8 }
%struct.TitleLayer = type { %struct.Drawable, ptr, ptr, ptr, ptr, i8, i8, i16, i16, i16, i16, i16, i16, i8, i16, i8, i8, i8, i8, i8, i8, i16, i16, %struct.HScrollDB, %struct.HScrollDB }
%struct.HScrollDB = type { [2 x %struct.HScrollN], i8 }
%struct.HScrollN = type { [25 x i8] }
%struct.DrawableVT = type { ptr, ptr }
%struct.HScrollW = type { ptr, i8 }

@main.a = internal global %struct.App zeroinitializer, align 1
@main.title = internal global %struct.TitleLayer zeroinitializer, align 1
@.str = private unnamed_addr constant [14 x i8] c"N-BODY ORBITS\00", align 1
@.str.1 = private unnamed_addr constant [8 x i8] c"GRAVITY\00", align 1
@corpus_result = dso_local global i16 0, align 1
@bg3_pal = internal global [4 x i16] [i16 0, i16 25368, i16 336, i16 29440], align 1
@.str.2 = private unnamed_addr constant [18 x i8] c"NBODY N=3  FRAME:\00", align 1
@.str.3 = private unnamed_addr constant [35 x i8] c"SUN X=  Y=   E X=  Y=   J X=  Y=  \00", align 1
@CANVAS_VT = internal constant %struct.DrawableVT { ptr @_canvas_reserve, ptr @_canvas_emit }, align 1
@TEXT_VT = internal constant %struct.DrawableVT { ptr @_text_reserve, ptr @_text_emit }, align 1
@FONT8 = internal unnamed_addr constant [512 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 32, i16 0, i16 80, i16 80, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 80, i16 80, i16 248, i16 80, i16 248, i16 80, i16 80, i16 0, i16 32, i16 120, i16 160, i16 112, i16 40, i16 240, i16 32, i16 0, i16 196, i16 200, i16 16, i16 32, i16 64, i16 152, i16 12, i16 0, i16 96, i16 144, i16 160, i16 64, i16 168, i16 144, i16 104, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 16, i16 32, i16 64, i16 64, i16 64, i16 32, i16 16, i16 0, i16 64, i16 32, i16 16, i16 16, i16 16, i16 32, i16 64, i16 0, i16 0, i16 32, i16 168, i16 112, i16 168, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 248, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 64, i16 0, i16 0, i16 0, i16 248, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 0, i16 8, i16 8, i16 16, i16 32, i16 64, i16 128, i16 128, i16 0, i16 112, i16 136, i16 152, i16 168, i16 200, i16 136, i16 112, i16 0, i16 32, i16 96, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 64, i16 248, i16 0, i16 112, i16 136, i16 8, i16 48, i16 8, i16 136, i16 112, i16 0, i16 16, i16 48, i16 80, i16 144, i16 248, i16 16, i16 16, i16 0, i16 248, i16 128, i16 240, i16 8, i16 8, i16 136, i16 112, i16 0, i16 112, i16 136, i16 128, i16 240, i16 136, i16 136, i16 112, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 64, i16 64, i16 0, i16 112, i16 136, i16 136, i16 112, i16 136, i16 136, i16 112, i16 0, i16 112, i16 136, i16 136, i16 120, i16 8, i16 136, i16 112, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 64, i16 0, i16 16, i16 32, i16 64, i16 128, i16 64, i16 32, i16 16, i16 0, i16 0, i16 0, i16 248, i16 0, i16 248, i16 0, i16 0, i16 0, i16 128, i16 64, i16 32, i16 16, i16 32, i16 64, i16 128, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 0, i16 32, i16 0, i16 112, i16 136, i16 184, i16 168, i16 184, i16 128, i16 112, i16 0, i16 112, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 240, i16 136, i16 136, i16 240, i16 136, i16 136, i16 240, i16 0, i16 112, i16 136, i16 128, i16 128, i16 128, i16 136, i16 112, i16 0, i16 224, i16 144, i16 136, i16 136, i16 136, i16 144, i16 224, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 248, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 128, i16 176, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 112, i16 32, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 56, i16 16, i16 16, i16 16, i16 144, i16 144, i16 96, i16 0, i16 136, i16 144, i16 160, i16 192, i16 160, i16 144, i16 136, i16 0, i16 128, i16 128, i16 128, i16 128, i16 128, i16 128, i16 248, i16 0, i16 136, i16 216, i16 168, i16 136, i16 136, i16 136, i16 136, i16 0, i16 136, i16 200, i16 168, i16 152, i16 136, i16 136, i16 136, i16 0, i16 112, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 240, i16 136, i16 136, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 136, i16 136, i16 168, i16 144, i16 104, i16 0, i16 240, i16 136, i16 136, i16 240, i16 160, i16 144, i16 136, i16 0, i16 112, i16 136, i16 128, i16 112, i16 8, i16 136, i16 112, i16 0, i16 248, i16 32, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 80, i16 32, i16 0, i16 136, i16 136, i16 136, i16 168, i16 168, i16 216, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 80, i16 136, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 32, i16 32, i16 32, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 128, i16 248, i16 0, i16 48, i16 32, i16 32, i16 32, i16 32, i16 32, i16 48, i16 0, i16 128, i16 128, i16 64, i16 32, i16 16, i16 8, i16 8, i16 0, i16 48, i16 16, i16 16, i16 16, i16 16, i16 16, i16 48, i16 0, i16 32, i16 80, i16 136, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248], align 1
@TITLE_VT = internal constant %struct.DrawableVT { ptr @_title_reserve, ptr @_title_emit }, align 1
@FONT16 = internal unnamed_addr constant [2048 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 192, i16 192, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 768, i16 768, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 -4096, i16 -4096, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3840, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 3312, i16 15360, i16 15360, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 28, i16 28, i16 796, i16 127, i16 127, i16 796, i16 796, i16 127, i16 112, i16 112, i16 3184, i16 252, i16 252, i16 -28816, i16 -28816, i16 252, i16 127, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 0, i16 0, i16 252, i16 -28816, i16 -28816, i16 3184, i16 7168, i16 7168, i16 0, i16 0, i16 3, i16 63, i16 123, i16 1147, i16 63, i16 4111, i16 3075, i16 123, i16 192, i16 248, i16 8414, i16 16064, i16 2040, i16 248, i16 8414, i16 8414, i16 63, i16 7171, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 2040, i16 14272, i16 -512, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3585, i16 3, i16 7, i16 28, i16 56, i16 1904, i16 3808, i16 7392, i16 14528, i16 14464, i16 28672, i16 14, i16 284, i16 824, i16 1792, i16 3584, i16 0, i16 0, i16 0, i16 -8162, i16 -16354, i16 -32482, i16 286, i16 1792, i16 1792, i16 0, i16 0, i16 15, i16 31, i16 828, i16 828, i16 573, i16 31, i16 31, i16 63, i16 192, i16 224, i16 240, i16 2288, i16 7392, i16 15488, i16 30720, i16 -32648, i16 382, i16 3060, i16 3825, i16 1275, i16 127, i16 63, i16 7936, i16 3840, i16 248, i16 3824, i16 7904, i16 7392, i16 4332, i16 12492, i16 -1280, i16 -3328, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 7, i16 15, i16 15, i16 15, i16 15, i16 15, i16 240, i16 192, i16 15488, i16 -4096, i16 -8192, i16 -16384, i16 -16384, i16 -16384, i16 15, i16 7, i16 3, i16 256, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 16512, i16 192, i16 240, i16 -4096, i16 15360, i16 0, i16 0, i16 15, i16 3, i16 513, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 224, i16 240, i16 2288, i16 3312, i16 3312, i16 3312, i16 0, i16 1, i16 3, i16 15, i16 0, i16 768, i16 0, i16 0, i16 3312, i16 7392, i16 15552, i16 30720, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 51, i16 31, i16 15, i16 1027, i16 0, i16 0, i16 192, i16 192, i16 12492, i16 252, i16 1016, i16 16320, i16 15, i16 31, i16 51, i16 1027, i16 3072, i16 0, i16 0, i16 0, i16 1784, i16 252, i16 13004, i16 16320, i16 -3328, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 3, i16 63, i16 63, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 248, i16 248, i16 63, i16 3075, i16 3075, i16 3, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 16064, i16 16064, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 286, i16 828, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 28800, i16 -4096, i16 -8192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 -512, i16 -512, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7360, i16 14464, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7168, i16 14336, i16 28672, i16 -8192, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 828, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 15, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 1, i16 3, i16 15, i16 15, i16 513, i16 513, i16 1, i16 1, i16 240, i16 240, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 1, i16 1, i16 1, i16 1, i16 1, i16 1, i16 0, i16 0, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 31744, i16 31744, i16 15, i16 31, i16 318, i16 828, i16 3840, i16 3840, i16 3, i16 15, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 63, i16 510, i16 4080, i16 31, i16 318, i16 318, i16 318, i16 63, i16 63, i16 3840, i16 3840, i16 32640, i16 -1024, i16 -8192, i16 -32768, i16 255, i16 255, i16 -256, i16 -256, i16 15, i16 63, i16 824, i16 3840, i16 2055, i16 7, i16 256, i16 256, i16 252, i16 254, i16 -8161, i16 -4081, i16 510, i16 1020, i16 -7906, i16 -4081, i16 0, i16 0, i16 56, i16 60, i16 63, i16 31, i16 3840, i16 1792, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 15, i16 286, i16 62, i16 126, i16 510, i16 510, i16 8670, i16 24990, i16 -7906, i16 -7906, i16 828, i16 828, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 -16098, i16 -32482, i16 255, i16 255, i16 -7906, i16 -7906, i16 1792, i16 1792, i16 31, i16 63, i16 828, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 254, i16 254, i16 -256, i16 -256, i16 252, i16 254, i16 -8161, i16 -4081, i16 0, i16 0, i16 60, i16 62, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 63, i16 63, i16 318, i16 828, i16 254, i16 255, i16 -2041, i16 -256, i16 508, i16 254, i16 -4081, i16 -2041, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 -32761, i16 7, i16 7, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 31, i16 318, i16 892, i16 0, i16 1, i16 3, i16 7, i16 7, i16 7, i16 256, i16 256, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 28800, i16 -8192, i16 -8192, i16 15, i16 31, i16 828, i16 828, i16 828, i16 31, i16 15, i16 796, i16 252, i16 254, i16 -4081, i16 -4081, i16 15, i16 510, i16 1020, i16 -3826, i16 828, i16 828, i16 828, i16 828, i16 31, i16 15, i16 1792, i16 768, i16 -4081, i16 15, i16 15, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 318, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 31, i16 31, i16 15, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 270, i16 796, i16 824, i16 1792, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 15, i16 60, i16 828, i16 0, i16 0, i16 60, i16 240, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 15360, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 60, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 60, i16 0, i16 3, i16 15, i16 60, i16 768, i16 3840, i16 0, i16 0, i16 4080, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 31, i16 63, i16 828, i16 3840, i16 3840, i16 7, i16 7, i16 7, i16 240, i16 248, i16 -32644, i16 -32132, i16 2040, i16 4080, i16 16064, i16 31872, i16 256, i16 256, i16 7, i16 7, i16 7, i16 256, i16 256, i16 0, i16 -4096, i16 -8192, i16 128, i16 128, i16 24704, i16 -8192, i16 -8192, i16 0, i16 31, i16 63, i16 828, i16 573, i16 573, i16 573, i16 573, i16 573, i16 248, i16 252, i16 -15812, i16 4590, i16 494, i16 4590, i16 1020, i16 1016, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 0, i16 0, i16 0, i16 32512, i16 764, i16 248, i16 -256, i16 -512, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 892, i16 1020, i16 1020, i16 255, i16 255, i16 224, i16 240, i16 -32648, i16 -16324, i16 -32196, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -28928, i16 1792, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 0, i16 0, i16 28, i16 60, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -8164, i16 -3572, i16 -30976, i16 768, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 8988, i16 8988, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 60, i16 60, i16 828, i16 828, i16 828, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 255, i16 255, i16 16128, i16 16128, i16 12480, i16 12480, i16 12480, i16 12480, i16 252, i16 252, i16 -256, i16 -256, i16 63, i16 63, i16 3075, i16 3075, i16 3, i16 3, i16 51, i16 51, i16 252, i16 252, i16 4080, i16 4080, i16 3312, i16 3312, i16 3312, i16 3312, i16 3123, i16 3123, i16 63, i16 63, i16 31, i16 15, i16 1792, i16 768, i16 3312, i16 3312, i16 3312, i16 3312, i16 7392, i16 15552, i16 -2048, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 765, i16 255, i16 255, i16 255, i16 28, i16 60, i16 1912, i16 4080, i16 7904, i16 15552, i16 30848, i16 12480, i16 255, i16 765, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 224, i16 240, i16 248, i16 124, i16 572, i16 828, i16 3840, i16 3840, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 0, i16 0, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 248, i16 252, i16 254, i16 2295, i16 3315, i16 3315, i16 3315, i16 3315, i16 60, i16 124, i16 1020, i16 988, i16 9116, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 15360, i16 15360, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 -6400, i16 -6400, i16 240, i16 248, i16 252, i16 254, i16 255, i16 255, i16 2295, i16 3315, i16 60, i16 60, i16 828, i16 828, i16 828, i16 956, i16 1020, i16 1020, i16 3313, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 15360, i16 15360, i16 1020, i16 1020, i16 892, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -31972, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -512, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 224, i16 240, i16 -32648, i16 -15304, i16 -31176, i16 1592, i16 1592, i16 1592, i16 765, i16 765, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 1784, i16 1784, i16 17976, i16 1656, i16 764, i16 764, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 63, i16 127, i16 2040, i16 4080, i16 1784, i16 255, i16 127, i16 63, i16 248, i16 252, i16 -15812, i16 -256, i16 3840, i16 240, i16 248, i16 252, i16 7936, i16 3840, i16 224, i16 255, i16 255, i16 127, i16 16128, i16 7936, i16 -32132, i16 -15556, i16 892, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 -4096, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 28, i16 28, i16 796, i16 796, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 510, i16 255, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 828, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 248, i16 248, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 124, i16 124, i16 1912, i16 1912, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 572, i16 63, i16 31, i16 15, i16 7, i16 768, i16 256, i16 1656, i16 3824, i16 3824, i16 7392, i16 15552, i16 30848, i16 -4096, i16 -8192, i16 243, i16 243, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 156, i16 156, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 2295, i16 255, i16 510, i16 892, i16 16128, i16 7936, i16 25500, i16 25500, i16 9180, i16 1020, i16 1020, i16 -30856, i16 -16640, i16 7680, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 15, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 14528, i16 31, i16 63, i16 892, i16 2040, i16 4080, i16 3824, i16 15360, i16 15360, i16 4320, i16 240, i16 248, i16 -32644, i16 572, i16 828, i16 3840, i16 3840, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 7, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 7, i16 7, i16 7, i16 7, i16 7, i16 7, i16 256, i16 256, i16 28800, i16 24704, i16 24704, i16 24704, i16 24704, i16 24704, i16 -8192, i16 -8192, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 1, i16 3, i16 7, i16 252, i16 252, i16 1020, i16 -31876, i16 2040, i16 4080, i16 7904, i16 15552, i16 15, i16 31, i16 318, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 30848, i16 -4096, i16 -8192, i16 252, i16 252, i16 1020, i16 -256, i16 -256, i16 31, i16 31, i16 286, i16 286, i16 286, i16 286, i16 286, i16 286, i16 224, i16 224, i16 -2048, i16 -2048, i16 -32768, i16 -32768, i16 -32768, i16 -32768, i16 286, i16 286, i16 286, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 -32768, i16 -32768, i16 -32768, i16 224, i16 224, i16 -2048, i16 -2048, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 3, i16 1, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 128, i16 192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 768, i16 256, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 0, i16 0, i16 0, i16 224, i16 224, i16 2288, i16 2288, i16 3312, i16 3312, i16 3312, i16 3312, i16 0, i16 0, i16 0, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 3312, i16 3312, i16 3312, i16 7392, i16 7392, i16 -2048, i16 -2048, i16 0, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1840, i16 3584, i16 3072, i16 192, i16 224, i16 -32656, i16 -16328, i16 -32740, i16 524, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 127, i16 127, i16 7936, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 -512], align 1
@title_end._title_bg_black = internal constant i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [6 x i8], align 1
  store volatile i8 -113, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  br label %2

2:                                                ; preds = %6, %0
  %3 = phi i16 [ 8449, %0 ], [ %7, %6 ]
  switch i16 %3, label %4 [
    i16 8452, label %6
    i16 8470, label %6
    i16 8471, label %6
    i16 8472, label %6
    i16 8473, label %6
    i16 8481, label %6
    i16 8482, label %6
  ]

4:                                                ; preds = %2
  %5 = inttoptr i16 %3 to ptr
  store volatile i8 0, ptr %5, align 1, !tbaa !6
  br label %6

6:                                                ; preds = %4, %2, %2, %2, %2, %2, %2, %2
  %7 = add nuw nsw i16 %3, 1
  %8 = icmp eq i16 %7, 8500
  br i1 %8, label %9, label %2, !llvm.loop !7

9:                                                ; preds = %6
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) getelementptr inbounds nuw (i8, ptr @main.a, i16 176), i8 0, i64 6, i1 false)
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  store volatile i8 1, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 -127, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !6
  store ptr @CANVAS_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), align 1, !tbaa !15
  store i8 4, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !19
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4299), align 1, !tbaa !20
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4301), align 1, !tbaa !21
  store i8 8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4303), align 1, !tbaa !22
  store i8 6, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4304), align 1, !tbaa !23
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(4096) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i16 4096, i1 false), !tbaa !6
  store i16 -1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  store ptr @TEXT_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !26
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !28
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4308), align 1, !tbaa !29
  store i8 23, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4310), align 1, !tbaa !6
  store i8 25, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4311), align 1, !tbaa !6
  br label %10

10:                                               ; preds = %10, %9
  %11 = phi i8 [ 0, %9 ], [ %17, %10 ]
  %12 = phi i16 [ 0, %9 ], [ %15, %10 ]
  %13 = zext i8 %11 to i16
  %14 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4312), i16 %13
  store i16 256, ptr %14, align 1, !tbaa !2
  %15 = add nuw nsw i16 %12, 1
  %16 = icmp eq i16 %15, 64
  %17 = add nuw i8 %11, 2
  br i1 %16, label %18, label %10, !llvm.loop !30

18:                                               ; preds = %10
  store i8 3, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %19 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %20 = icmp eq i8 %19, 0
  br i1 %20, label %22, label %21

21:                                               ; preds = %18
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %22

22:                                               ; preds = %21, %18
  %23 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %24 = icmp ult i8 %23, 4
  br i1 %24, label %25, label %29

25:                                               ; preds = %22
  %26 = zext nneg i8 %23 to i16
  %27 = add nuw nsw i8 %23, 1
  store i8 %27, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %28 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %26
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr %28, align 1, !tbaa !35
  br label %29

29:                                               ; preds = %25, %22
  tail call void @_canvas_reserve(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr nonnull poison) #15, !inline_history !37
  %30 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %31 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !39
  %32 = or i8 %31, %30
  store i8 %32, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %32, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %33 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %34 = icmp eq i8 %33, 0
  br i1 %34, label %36, label %35

35:                                               ; preds = %29
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %36

36:                                               ; preds = %35, %29
  %37 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %38 = icmp ult i8 %37, 4
  br i1 %38, label %39, label %43

39:                                               ; preds = %36
  %40 = zext nneg i8 %37 to i16
  %41 = add nuw nsw i8 %37, 1
  store i8 %41, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %42 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %40
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr %42, align 1, !tbaa !35
  br label %43

43:                                               ; preds = %39, %36
  %44 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !40
  %45 = load ptr, ptr %44, align 1, !tbaa !41
  tail call void %45(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 178)) #15, !inline_history !43
  %46 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %47 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !39
  %48 = or i8 %47, %46
  store i8 %48, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %48, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %49 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %50 = icmp ugt i8 %49, 15
  br i1 %50, label %62, label %51

51:                                               ; preds = %43
  %52 = zext nneg i8 %49 to i16
  %53 = add nuw nsw i8 %49, 1
  store i8 %53, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %54 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %52
  %55 = getelementptr inbounds nuw i8, ptr %54, i16 10
  store i8 1, ptr %55, align 1, !tbaa !45
  store i16 0, ptr %54, align 1, !tbaa !47
  %56 = getelementptr inbounds nuw i8, ptr %54, i16 9
  store i8 0, ptr %56, align 1, !tbaa !48
  %57 = getelementptr inbounds nuw i8, ptr %54, i16 7
  store i8 34, ptr %57, align 1, !tbaa !49
  %58 = getelementptr inbounds nuw i8, ptr %54, i16 8
  store i8 0, ptr %58, align 1, !tbaa !50
  %59 = getelementptr inbounds nuw i8, ptr %54, i16 2
  store i16 ptrtoint (ptr @bg3_pal to i16), ptr %59, align 1, !tbaa !51
  %60 = getelementptr inbounds nuw i8, ptr %54, i16 6
  store i8 0, ptr %60, align 1, !tbaa !52
  %61 = getelementptr inbounds nuw i8, ptr %54, i16 4
  store i16 8, ptr %61, align 1, !tbaa !53
  br label %62

62:                                               ; preds = %51, %43
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !54
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), align 1, !tbaa !56
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4445), align 1, !tbaa !57
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4447), align 1, !tbaa !58
  store i8 -1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4449), align 1, !tbaa !59
  store i16 24064, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4450), align 1, !tbaa !54
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4452), align 1, !tbaa !56
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4454), align 1, !tbaa !57
  store i16 -490, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4456), align 1, !tbaa !58
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4458), align 1, !tbaa !59
  store i16 3584, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4459), align 1, !tbaa !54
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4461), align 1, !tbaa !56
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4463), align 1, !tbaa !57
  store i16 439, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4465), align 1, !tbaa !58
  store i8 3, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4467), align 1, !tbaa !59
  br label %63

63:                                               ; preds = %84, %62
  %64 = phi i8 [ 0, %62 ], [ %92, %84 ]
  %65 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4532), %62 ], [ %90, %84 ]
  %66 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4468), %62 ], [ %89, %84 ]
  %67 = phi i8 [ 0, %62 ], [ %88, %84 ]
  %68 = zext nneg i8 %64 to i16
  %69 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %68
  %70 = load i16, ptr %69, align 1, !tbaa !54
  %71 = lshr i16 %70, 8
  %72 = trunc nuw i16 %71 to i8
  %73 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), i16 %68
  %74 = load i16, ptr %73, align 1, !tbaa !56
  %75 = lshr i16 %74, 8
  %76 = trunc nuw i16 %75 to i8
  br label %77

77:                                               ; preds = %77, %63
  %78 = phi i8 [ 0, %63 ], [ %82, %77 ]
  %79 = zext nneg i8 %78 to i16
  %80 = getelementptr i8, ptr %66, i16 %79
  store i8 %72, ptr %80, align 1, !tbaa !6
  %81 = getelementptr i8, ptr %65, i16 %79
  store i8 %76, ptr %81, align 1, !tbaa !6
  %82 = add nuw nsw i8 %78, 1
  %83 = icmp eq i8 %82, 64
  br i1 %83, label %84, label %77, !llvm.loop !60

84:                                               ; preds = %77
  %85 = zext nneg i8 %67 to i16
  %86 = getelementptr inbounds nuw [129 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4468), i16 %85
  %87 = getelementptr inbounds nuw i8, ptr %86, i16 128
  store i8 0, ptr %87, align 1, !tbaa !61
  %88 = add nuw nsw i8 %67, 1
  %89 = getelementptr i8, ptr %66, i16 129
  %90 = getelementptr i8, ptr %65, i16 129
  %91 = icmp eq i8 %88, 3
  %92 = add nuw nsw i8 %64, 9
  br i1 %91, label %93, label %63, !llvm.loop !63

93:                                               ; preds = %84
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4855), align 1, !tbaa !64
  store i8 24, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4857), align 1, !tbaa !66
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4858), align 1, !tbaa !67
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4859), align 1, !tbaa !68
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4860), align 1, !tbaa !69
  br label %94

94:                                               ; preds = %104, %93
  %95 = phi i8 [ 0, %93 ], [ %110, %104 ]
  %96 = phi i8 [ 0, %93 ], [ %112, %104 ]
  %97 = phi i8 [ 78, %93 ], [ %111, %104 ]
  %98 = zext i8 %97 to i16
  %99 = icmp ugt i8 %97, 31
  br i1 %99, label %100, label %104

100:                                              ; preds = %94
  %101 = icmp ult i8 %97, 96
  br i1 %101, label %102, label %104

102:                                              ; preds = %100
  %103 = add nuw nsw i16 %98, 224
  br label %104

104:                                              ; preds = %102, %100, %94
  %105 = phi i16 [ %103, %102 ], [ 256, %100 ], [ 256, %94 ]
  %106 = zext nneg i8 %96 to i16
  %107 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4312), i16 %106
  store i16 %105, ptr %107, align 1, !tbaa !2
  %108 = zext nneg i8 %95 to i16
  %109 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @.str.2, i16 1), i16 %108
  %110 = add nuw nsw i8 %95, 1
  %111 = load i8, ptr %109, align 1, !tbaa !6
  %112 = add nuw nsw i8 %96, 2
  %113 = icmp eq i8 %110, 17
  br i1 %113, label %114, label %94, !llvm.loop !70

114:                                              ; preds = %104
  %115 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  br label %116

116:                                              ; preds = %114, %126
  %117 = phi i16 [ 83, %114 ], [ %135, %126 ]
  %118 = phi i8 [ 83, %114 ], [ %133, %126 ]
  %119 = phi i8 [ 0, %114 ], [ %134, %126 ]
  %120 = phi i8 [ 0, %114 ], [ %132, %126 ]
  %121 = icmp ugt i8 %118, 31
  br i1 %121, label %122, label %126

122:                                              ; preds = %116
  %123 = icmp ult i8 %118, 96
  br i1 %123, label %124, label %126

124:                                              ; preds = %122
  %125 = add nuw nsw i16 %117, 224
  br label %126

126:                                              ; preds = %124, %122, %116
  %127 = phi i16 [ %125, %124 ], [ 256, %122 ], [ 256, %116 ]
  %128 = zext nneg i8 %119 to i16
  %129 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4376), i16 %128
  store i16 %127, ptr %129, align 1, !tbaa !2
  %130 = zext nneg i8 %120 to i16
  %131 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @.str.3, i16 1), i16 %130
  %132 = add nuw nsw i8 %120, 1
  %133 = load i8, ptr %131, align 1, !tbaa !6
  %134 = add nuw nsw i8 %119, 2
  %135 = zext i8 %133 to i16
  %136 = icmp eq i8 %132, 32
  br i1 %136, label %137, label %116

137:                                              ; preds = %126
  %138 = or i8 %115, 3
  store i8 %138, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  store ptr @TITLE_VT, ptr @main.title, align 1, !tbaa !71
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !75
  store ptr @.str, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 3), align 1, !tbaa !76
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 5), align 1, !tbaa !77
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 7), align 1, !tbaa !78
  store i8 7, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 11), align 1, !tbaa !79
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 9), align 1, !tbaa !80
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 12), align 1, !tbaa !81
  store i16 96, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 13), align 1, !tbaa !82
  store i16 112, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 15), align 1, !tbaa !83
  store i16 16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 17), align 1, !tbaa !84
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 28), align 1, !tbaa !85
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !86
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !87
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !88
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !89
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !90
  store i16 32767, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 34), align 1, !tbaa !91
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 36), align 1, !tbaa !92
  %139 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %140 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %141 = icmp eq i8 %140, 0
  br i1 %141, label %143, label %142

142:                                              ; preds = %137
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %143

143:                                              ; preds = %142, %137
  %144 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %145 = icmp ult i8 %144, 4
  br i1 %145, label %146, label %150

146:                                              ; preds = %143
  %147 = zext nneg i8 %144 to i16
  %148 = add nuw nsw i8 %144, 1
  store i8 %148, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %149 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %147
  store ptr @main.title, ptr %149, align 1, !tbaa !35
  br label %150

150:                                              ; preds = %146, %143
  tail call void @_title_reserve(ptr noundef nonnull @main.title, ptr nonnull poison) #15, !inline_history !37
  %151 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %152 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %153 = or i8 %152, %151
  store volatile i8 %153, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store i8 %139, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !93
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 2, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 24, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  br label %154

154:                                              ; preds = %182, %150
  %155 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %156 = icmp eq i8 %155, 0
  br i1 %156, label %168, label %157

157:                                              ; preds = %154, %157
  %158 = phi i8 [ %165, %157 ], [ 0, %154 ]
  %159 = zext i8 %158 to i16
  %160 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %159
  %161 = load ptr, ptr %160, align 1, !tbaa !35
  %162 = load ptr, ptr %161, align 1, !tbaa !40
  %163 = getelementptr inbounds nuw i8, ptr %162, i16 2
  %164 = load ptr, ptr %163, align 1, !tbaa !94
  tail call void %164(ptr noundef nonnull %161, ptr noundef nonnull @main.a) #15, !inline_history !95
  %165 = add nuw i8 %158, 1
  %166 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %167 = icmp ult i8 %165, %166
  br i1 %167, label %157, label %168, !llvm.loop !96

168:                                              ; preds = %157, %154
  %169 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %170

170:                                              ; preds = %170, %168
  %171 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %172 = icmp sgt i8 %171, -1
  br i1 %172, label %170, label %173, !llvm.loop !97

173:                                              ; preds = %170
  tail call fastcc void @upq_flush() #16
  %174 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %175 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %176 = icmp ult i8 %174, %175
  br i1 %176, label %179, label %177

177:                                              ; preds = %173
  %178 = icmp ugt i8 %174, %175
  br i1 %178, label %179, label %182

179:                                              ; preds = %177, %173
  %180 = phi i8 [ 1, %173 ], [ -1, %177 ]
  %181 = add i8 %180, %174
  store i8 %181, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %182

182:                                              ; preds = %179, %177
  %183 = phi i8 [ %174, %177 ], [ %181, %179 ]
  %184 = and i8 %183, 15
  store volatile i8 %184, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %185 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %186 = icmp eq i8 %185, 15
  br i1 %186, label %187, label %154, !llvm.loop !98

187:                                              ; preds = %182
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !89
  %188 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !90
  %189 = icmp eq i8 %188, -1
  br i1 %189, label %227, label %190

190:                                              ; preds = %187, %219
  %191 = phi i8 [ %222, %219 ], [ 0, %187 ]
  %192 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %193 = icmp eq i8 %192, 0
  br i1 %193, label %205, label %194

194:                                              ; preds = %190, %194
  %195 = phi i8 [ %202, %194 ], [ 0, %190 ]
  %196 = zext i8 %195 to i16
  %197 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %196
  %198 = load ptr, ptr %197, align 1, !tbaa !35
  %199 = load ptr, ptr %198, align 1, !tbaa !40
  %200 = getelementptr inbounds nuw i8, ptr %199, i16 2
  %201 = load ptr, ptr %200, align 1, !tbaa !94
  tail call void %201(ptr noundef nonnull %198, ptr noundef nonnull @main.a) #15, !inline_history !99
  %202 = add nuw i8 %195, 1
  %203 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %204 = icmp ult i8 %202, %203
  br i1 %204, label %194, label %205, !llvm.loop !96

205:                                              ; preds = %194, %190
  %206 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %207

207:                                              ; preds = %207, %205
  %208 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %209 = icmp sgt i8 %208, -1
  br i1 %209, label %207, label %210, !llvm.loop !97

210:                                              ; preds = %207
  tail call fastcc void @upq_flush() #16
  %211 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %212 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %213 = icmp ult i8 %211, %212
  br i1 %213, label %216, label %214

214:                                              ; preds = %210
  %215 = icmp ugt i8 %211, %212
  br i1 %215, label %216, label %219

216:                                              ; preds = %214, %210
  %217 = phi i8 [ 1, %210 ], [ -1, %214 ]
  %218 = add i8 %217, %211
  store i8 %218, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %219

219:                                              ; preds = %216, %214
  %220 = phi i8 [ %211, %214 ], [ %218, %216 ]
  %221 = and i8 %220, 15
  store volatile i8 %221, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %222 = add nuw i8 %191, 1
  %223 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !90
  %224 = icmp ne i8 %223, -1
  %225 = icmp ult i8 %191, -57
  %226 = select i1 %224, i1 %225, i1 false
  br i1 %226, label %190, label %227, !llvm.loop !100

227:                                              ; preds = %219, %187
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !89
  %228 = tail call fastcc i16 @nbody_gate_crc() #16
  store volatile i16 %228, ptr @corpus_result, align 1, !tbaa !2
  br label %229

229:                                              ; preds = %259, %227
  %230 = phi i16 [ 110, %227 ], [ %231, %259 ]
  %231 = add nsw i16 %230, -1
  %232 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %233 = icmp eq i8 %232, 0
  br i1 %233, label %245, label %234

234:                                              ; preds = %229, %234
  %235 = phi i8 [ %242, %234 ], [ 0, %229 ]
  %236 = zext i8 %235 to i16
  %237 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %236
  %238 = load ptr, ptr %237, align 1, !tbaa !35
  %239 = load ptr, ptr %238, align 1, !tbaa !40
  %240 = getelementptr inbounds nuw i8, ptr %239, i16 2
  %241 = load ptr, ptr %240, align 1, !tbaa !94
  tail call void %241(ptr noundef nonnull %238, ptr noundef nonnull @main.a) #15, !inline_history !101
  %242 = add nuw i8 %235, 1
  %243 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %244 = icmp ult i8 %242, %243
  br i1 %244, label %234, label %245, !llvm.loop !96

245:                                              ; preds = %234, %229
  %246 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %247

247:                                              ; preds = %247, %245
  %248 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %249 = icmp sgt i8 %248, -1
  br i1 %249, label %247, label %250, !llvm.loop !97

250:                                              ; preds = %247
  tail call fastcc void @upq_flush() #16
  %251 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %252 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %253 = icmp ult i8 %251, %252
  br i1 %253, label %256, label %254

254:                                              ; preds = %250
  %255 = icmp ugt i8 %251, %252
  br i1 %255, label %256, label %259

256:                                              ; preds = %254, %250
  %257 = phi i8 [ 1, %250 ], [ -1, %254 ]
  %258 = add i8 %257, %251
  store i8 %258, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %259

259:                                              ; preds = %256, %254
  %260 = phi i8 [ %251, %254 ], [ %258, %256 ]
  %261 = and i8 %260, 15
  store volatile i8 %261, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %262 = icmp eq i16 %231, 0
  br i1 %262, label %263, label %229, !llvm.loop !102

263:                                              ; preds = %259
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !87
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !88
  br label %267

264:                                              ; preds = %296
  %265 = add nuw nsw i8 %268, 1
  %266 = icmp eq i8 %265, 90
  br i1 %266, label %301, label %267, !llvm.loop !103

267:                                              ; preds = %264, %263
  %268 = phi i8 [ 0, %263 ], [ %265, %264 ]
  %269 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %270 = icmp eq i8 %269, 0
  br i1 %270, label %282, label %271

271:                                              ; preds = %267, %271
  %272 = phi i8 [ %279, %271 ], [ 0, %267 ]
  %273 = zext i8 %272 to i16
  %274 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %273
  %275 = load ptr, ptr %274, align 1, !tbaa !35
  %276 = load ptr, ptr %275, align 1, !tbaa !40
  %277 = getelementptr inbounds nuw i8, ptr %276, i16 2
  %278 = load ptr, ptr %277, align 1, !tbaa !94
  tail call void %278(ptr noundef nonnull %275, ptr noundef nonnull @main.a) #15, !inline_history !104
  %279 = add nuw i8 %272, 1
  %280 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %281 = icmp ult i8 %279, %280
  br i1 %281, label %271, label %282, !llvm.loop !96

282:                                              ; preds = %271, %267
  %283 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %284

284:                                              ; preds = %284, %282
  %285 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %286 = icmp sgt i8 %285, -1
  br i1 %286, label %284, label %287, !llvm.loop !97

287:                                              ; preds = %284
  tail call fastcc void @upq_flush() #16
  %288 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %289 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %290 = icmp ult i8 %288, %289
  br i1 %290, label %293, label %291

291:                                              ; preds = %287
  %292 = icmp ugt i8 %288, %289
  br i1 %292, label %293, label %296

293:                                              ; preds = %291, %287
  %294 = phi i8 [ 1, %287 ], [ -1, %291 ]
  %295 = add i8 %294, %288
  store i8 %295, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %296

296:                                              ; preds = %293, %291
  %297 = phi i8 [ %288, %291 ], [ %295, %293 ]
  %298 = and i8 %297, 15
  store volatile i8 %298, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %299 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 19), align 1, !tbaa !105
  %300 = icmp sgt i16 %299, 3583
  br i1 %300, label %301, label %264

301:                                              ; preds = %296, %264
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !87
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %302 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %303 = icmp eq i8 %302, 0
  br i1 %303, label %337, label %304

304:                                              ; preds = %301, %332
  %305 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %306 = icmp eq i8 %305, 0
  br i1 %306, label %318, label %307

307:                                              ; preds = %304, %307
  %308 = phi i8 [ %315, %307 ], [ 0, %304 ]
  %309 = zext i8 %308 to i16
  %310 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %309
  %311 = load ptr, ptr %310, align 1, !tbaa !35
  %312 = load ptr, ptr %311, align 1, !tbaa !40
  %313 = getelementptr inbounds nuw i8, ptr %312, i16 2
  %314 = load ptr, ptr %313, align 1, !tbaa !94
  tail call void %314(ptr noundef nonnull %311, ptr noundef nonnull @main.a) #15, !inline_history !106
  %315 = add nuw i8 %308, 1
  %316 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %317 = icmp ult i8 %315, %316
  br i1 %317, label %307, label %318, !llvm.loop !96

318:                                              ; preds = %307, %304
  %319 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %320

320:                                              ; preds = %320, %318
  %321 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %322 = icmp sgt i8 %321, -1
  br i1 %322, label %320, label %323, !llvm.loop !97

323:                                              ; preds = %320
  tail call fastcc void @upq_flush() #16
  %324 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %325 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %326 = icmp ult i8 %324, %325
  br i1 %326, label %329, label %327

327:                                              ; preds = %323
  %328 = icmp ugt i8 %324, %325
  br i1 %328, label %329, label %332

329:                                              ; preds = %327, %323
  %330 = phi i8 [ 1, %323 ], [ -1, %327 ]
  %331 = add i8 %330, %324
  store i8 %331, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %332

332:                                              ; preds = %329, %327
  %333 = phi i8 [ %324, %327 ], [ %331, %329 ]
  %334 = and i8 %333, 15
  store volatile i8 %334, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %335 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %336 = icmp eq i8 %335, 0
  br i1 %336, label %337, label %304, !llvm.loop !98

337:                                              ; preds = %332, %301
  %338 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !93
  %339 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %340 = or i8 %339, %338
  %341 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %342 = xor i8 %341, -1
  %343 = and i8 %340, %342
  store i8 %343, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %343, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !86
  %344 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %345 = icmp ugt i8 %344, 15
  br i1 %345, label %357, label %346

346:                                              ; preds = %337
  %347 = zext nneg i8 %344 to i16
  %348 = add nuw nsw i8 %344, 1
  store i8 %348, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %349 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %347
  %350 = getelementptr inbounds nuw i8, ptr %349, i16 10
  store i8 1, ptr %350, align 1, !tbaa !45
  store i16 0, ptr %349, align 1, !tbaa !47
  %351 = getelementptr inbounds nuw i8, ptr %349, i16 9
  store i8 0, ptr %351, align 1, !tbaa !48
  %352 = getelementptr inbounds nuw i8, ptr %349, i16 7
  store i8 34, ptr %352, align 1, !tbaa !49
  %353 = getelementptr inbounds nuw i8, ptr %349, i16 8
  store i8 0, ptr %353, align 1, !tbaa !50
  %354 = getelementptr inbounds nuw i8, ptr %349, i16 2
  store i16 ptrtoint (ptr @title_end._title_bg_black to i16), ptr %354, align 1, !tbaa !51
  %355 = getelementptr inbounds nuw i8, ptr %349, i16 6
  store i8 0, ptr %355, align 1, !tbaa !52
  %356 = getelementptr inbounds nuw i8, ptr %349, i16 4
  store i16 2, ptr %356, align 1, !tbaa !53
  br label %357

357:                                              ; preds = %337, %346
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %358 = getelementptr inbounds nuw i8, ptr %1, i16 1
  br label %359

359:                                              ; preds = %775, %357
  tail call fastcc void @nbody_step(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 4441)) #16
  %360 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4855), align 1, !tbaa !64
  %361 = add i16 %360, 1
  store i16 %361, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4855), align 1, !tbaa !64
  %362 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4859), align 1, !tbaa !68
  %363 = add i8 %362, 1
  store i8 %363, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4859), align 1, !tbaa !68
  %364 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4858), align 1, !tbaa !67
  %365 = add i8 %364, 1
  store i8 %365, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4858), align 1, !tbaa !67
  br label %366

366:                                              ; preds = %359, %404
  %367 = phi i8 [ 0, %359 ], [ %420, %404 ]
  %368 = phi i8 [ 0, %359 ], [ %418, %404 ]
  %369 = zext nneg i8 %368 to i16
  %370 = zext nneg i8 %367 to i16
  %371 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %370
  %372 = load i16, ptr %371, align 1, !tbaa !54
  %373 = ashr i16 %372, 8
  %374 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), i16 %370
  %375 = load i16, ptr %374, align 1, !tbaa !56
  %376 = ashr i16 %375, 8
  %377 = icmp ugt i16 %373, 127
  br i1 %377, label %404, label %378

378:                                              ; preds = %366
  %379 = icmp ugt i16 %376, 127
  br i1 %379, label %404, label %380

380:                                              ; preds = %378
  %381 = shl nuw nsw i16 %376, 1
  %382 = and i16 %381, 240
  %383 = lshr i16 %373, 3
  %384 = or disjoint i16 %382, %383
  %385 = shl nuw nsw i16 %384, 4
  %386 = and i16 %381, 14
  %387 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %385
  %388 = getelementptr inbounds nuw i8, ptr %387, i16 %386
  %389 = and i16 %373, 7
  %390 = lshr exact i16 128, %389
  %391 = load i8, ptr %388, align 1, !tbaa !6
  %392 = trunc nuw i16 %390 to i8
  %393 = or i8 %391, %392
  store i8 %393, ptr %388, align 1, !tbaa !6
  %394 = getelementptr inbounds nuw i8, ptr %388, i16 1
  %395 = load i8, ptr %394, align 1, !tbaa !6
  %396 = or i8 %395, %392
  store i8 %396, ptr %394, align 1, !tbaa !6
  %397 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %398 = icmp ult i16 %384, %397
  br i1 %398, label %399, label %400

399:                                              ; preds = %380
  store i16 %384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %400

400:                                              ; preds = %399, %380
  %401 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %402 = icmp ugt i16 %384, %401
  br i1 %402, label %403, label %404

403:                                              ; preds = %400
  store i16 %384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %404

404:                                              ; preds = %366, %378, %400, %403
  %405 = getelementptr inbounds nuw [129 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4468), i16 %369
  %406 = trunc nsw i16 %373 to i8
  %407 = and i8 %406, 127
  %408 = trunc nsw i16 %376 to i8
  %409 = and i8 %408, 127
  %410 = getelementptr inbounds nuw i8, ptr %405, i16 128
  %411 = load i8, ptr %410, align 1, !tbaa !61
  %412 = add i8 %411, 1
  %413 = and i8 %412, 63
  store i8 %413, ptr %410, align 1, !tbaa !61
  %414 = zext nneg i8 %413 to i16
  %415 = getelementptr inbounds nuw i8, ptr %405, i16 %414
  store i8 %407, ptr %415, align 1, !tbaa !6
  %416 = getelementptr inbounds nuw i8, ptr %405, i16 64
  %417 = getelementptr inbounds nuw i8, ptr %416, i16 %414
  store i8 %409, ptr %417, align 1, !tbaa !6
  %418 = add nuw nsw i8 %368, 1
  %419 = icmp eq i8 %418, 3
  %420 = add nuw nsw i8 %367, 9
  br i1 %419, label %421, label %366, !llvm.loop !107

421:                                              ; preds = %404
  %422 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4858), align 1, !tbaa !67
  %423 = icmp ugt i8 %422, 2
  br i1 %423, label %424, label %442

424:                                              ; preds = %421
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4858), align 1, !tbaa !67
  %425 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4857), align 1, !tbaa !66
  %426 = icmp ugt i8 %425, 2
  br i1 %426, label %427, label %430

427:                                              ; preds = %424
  %428 = add i8 %425, -1
  store i8 %428, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4857), align 1, !tbaa !66
  %429 = icmp ult i8 %425, 29
  br i1 %429, label %430, label %433

430:                                              ; preds = %424, %427
  %431 = phi i8 [ %428, %427 ], [ %425, %424 ]
  %432 = add nuw nsw i8 %431, 4
  br label %433

433:                                              ; preds = %427, %430
  %434 = phi i8 [ %431, %430 ], [ %428, %427 ]
  %435 = phi i8 [ %432, %430 ], [ 31, %427 ]
  %436 = zext nneg i8 %435 to i16
  %437 = shl nuw nsw i16 %436, 10
  %438 = and i8 %434, 31
  %439 = zext nneg i8 %438 to i16
  %440 = shl nuw nsw i16 %439, 5
  %441 = or disjoint i16 %437, %440
  store i16 %441, ptr getelementptr inbounds nuw (i8, ptr @bg3_pal, i16 6), align 1, !tbaa !2
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4860), align 1, !tbaa !69
  br label %442

442:                                              ; preds = %433, %421
  %443 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4859), align 1, !tbaa !68
  %444 = icmp ugt i8 %443, 119
  br i1 %444, label %445, label %536

445:                                              ; preds = %442
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(4098) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i64 4098, i1 false)
  store i16 255, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %446

446:                                              ; preds = %491, %445
  %447 = phi i8 [ 0, %445 ], [ %492, %491 ]
  %448 = zext nneg i8 %447 to i16
  %449 = getelementptr inbounds nuw [129 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4468), i16 %448
  %450 = getelementptr inbounds nuw i8, ptr %449, i16 128
  %451 = getelementptr inbounds nuw i8, ptr %449, i16 64
  %452 = load i8, ptr %450, align 1, !tbaa !61
  br label %453

453:                                              ; preds = %488, %446
  %454 = phi i8 [ 0, %446 ], [ %489, %488 ]
  %455 = sub i8 %452, %454
  %456 = and i8 %455, 63
  %457 = icmp samesign ugt i8 %454, 31
  %458 = zext nneg i8 %456 to i16
  %459 = getelementptr inbounds nuw i8, ptr %449, i16 %458
  %460 = load i8, ptr %459, align 1, !tbaa !6
  %461 = zext i8 %460 to i16
  %462 = getelementptr inbounds nuw i8, ptr %451, i16 %458
  %463 = load i8, ptr %462, align 1, !tbaa !6
  %464 = icmp slt i8 %460, 0
  br i1 %464, label %488, label %465

465:                                              ; preds = %453
  %466 = icmp slt i8 %463, 0
  br i1 %466, label %488, label %467

467:                                              ; preds = %465
  %468 = shl nuw i8 %463, 1
  %469 = zext i8 %468 to i16
  %470 = and i16 %469, 240
  %471 = lshr i16 %461, 3
  %472 = or disjoint i16 %470, %471
  %473 = shl nuw nsw i16 %472, 4
  %474 = and i16 %469, 14
  %475 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %473
  %476 = getelementptr inbounds nuw i8, ptr %475, i16 %474
  %477 = and i16 %461, 7
  %478 = lshr exact i16 128, %477
  br i1 %457, label %479, label %483

479:                                              ; preds = %467
  %480 = load i8, ptr %476, align 1, !tbaa !6
  %481 = trunc nuw i16 %478 to i8
  %482 = or i8 %480, %481
  store i8 %482, ptr %476, align 1, !tbaa !6
  br label %488

483:                                              ; preds = %467
  %484 = getelementptr inbounds nuw i8, ptr %476, i16 1
  %485 = load i8, ptr %484, align 1, !tbaa !6
  %486 = trunc nuw i16 %478 to i8
  %487 = or i8 %485, %486
  store i8 %487, ptr %484, align 1, !tbaa !6
  br label %488

488:                                              ; preds = %483, %479, %465, %453
  %489 = add nuw nsw i8 %454, 1
  %490 = icmp eq i8 %489, 64
  br i1 %490, label %491, label %453, !llvm.loop !108

491:                                              ; preds = %488
  %492 = add nuw nsw i8 %447, 1
  %493 = icmp eq i8 %492, 3
  br i1 %493, label %494, label %446, !llvm.loop !109

494:                                              ; preds = %491, %531
  %495 = phi i8 [ %534, %531 ], [ 0, %491 ]
  %496 = phi i8 [ %532, %531 ], [ 0, %491 ]
  %497 = zext nneg i8 %495 to i16
  %498 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %497
  %499 = load i16, ptr %498, align 1, !tbaa !54
  %500 = ashr i16 %499, 8
  %501 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), i16 %497
  %502 = load i16, ptr %501, align 1, !tbaa !56
  %503 = ashr i16 %502, 8
  %504 = icmp ugt i16 %500, 127
  br i1 %504, label %531, label %505

505:                                              ; preds = %494
  %506 = icmp ugt i16 %503, 127
  br i1 %506, label %531, label %507

507:                                              ; preds = %505
  %508 = shl nuw nsw i16 %503, 1
  %509 = and i16 %508, 240
  %510 = lshr i16 %500, 3
  %511 = or disjoint i16 %509, %510
  %512 = shl nuw nsw i16 %511, 4
  %513 = and i16 %508, 14
  %514 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %512
  %515 = getelementptr inbounds nuw i8, ptr %514, i16 %513
  %516 = and i16 %500, 7
  %517 = lshr exact i16 128, %516
  %518 = load i8, ptr %515, align 1, !tbaa !6
  %519 = trunc nuw i16 %517 to i8
  %520 = or i8 %518, %519
  store i8 %520, ptr %515, align 1, !tbaa !6
  %521 = getelementptr inbounds nuw i8, ptr %515, i16 1
  %522 = load i8, ptr %521, align 1, !tbaa !6
  %523 = or i8 %522, %519
  store i8 %523, ptr %521, align 1, !tbaa !6
  %524 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %525 = icmp ult i16 %511, %524
  br i1 %525, label %526, label %527

526:                                              ; preds = %507
  store i16 %511, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %527

527:                                              ; preds = %526, %507
  %528 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %529 = icmp ugt i16 %511, %528
  br i1 %529, label %530, label %531

530:                                              ; preds = %527
  store i16 %511, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %531

531:                                              ; preds = %530, %527, %505, %494
  %532 = add nuw nsw i8 %496, 1
  %533 = icmp eq i8 %532, 3
  %534 = add nuw nsw i8 %495, 9
  br i1 %533, label %535, label %494, !llvm.loop !110

535:                                              ; preds = %531
  store i8 24, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4857), align 1, !tbaa !66
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4859), align 1, !tbaa !68
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4858), align 1, !tbaa !67
  store i16 29440, ptr getelementptr inbounds nuw (i8, ptr @bg3_pal, i16 6), align 1, !tbaa !2
  br label %539

536:                                              ; preds = %442
  %537 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4860), align 1, !tbaa !69
  %538 = icmp eq i8 %537, 0
  br i1 %538, label %554, label %539

539:                                              ; preds = %535, %536
  %540 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %541 = icmp ugt i8 %540, 15
  br i1 %541, label %553, label %542

542:                                              ; preds = %539
  %543 = zext nneg i8 %540 to i16
  %544 = add nuw nsw i8 %540, 1
  store i8 %544, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %545 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %543
  %546 = getelementptr inbounds nuw i8, ptr %545, i16 10
  store i8 1, ptr %546, align 1, !tbaa !45
  store i16 0, ptr %545, align 1, !tbaa !47
  %547 = getelementptr inbounds nuw i8, ptr %545, i16 9
  store i8 0, ptr %547, align 1, !tbaa !48
  %548 = getelementptr inbounds nuw i8, ptr %545, i16 7
  store i8 34, ptr %548, align 1, !tbaa !49
  %549 = getelementptr inbounds nuw i8, ptr %545, i16 8
  store i8 0, ptr %549, align 1, !tbaa !50
  %550 = getelementptr inbounds nuw i8, ptr %545, i16 2
  store i16 ptrtoint (ptr @bg3_pal to i16), ptr %550, align 1, !tbaa !51
  %551 = getelementptr inbounds nuw i8, ptr %545, i16 6
  store i8 0, ptr %551, align 1, !tbaa !52
  %552 = getelementptr inbounds nuw i8, ptr %545, i16 4
  store i16 8, ptr %552, align 1, !tbaa !53
  br label %553

553:                                              ; preds = %539, %542
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4860), align 1, !tbaa !69
  br label %554

554:                                              ; preds = %553, %536
  %555 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4855), align 1, !tbaa !64
  %556 = and i16 %555, 3
  %557 = icmp eq i16 %556, 0
  br i1 %557, label %558, label %747

558:                                              ; preds = %554
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #17
  call fastcc void @fmt_u16(i16 noundef %555, ptr noundef %1) #16
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4346), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4348), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4350), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4352), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4354), align 1, !tbaa !2
  %559 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %560 = load i8, ptr %1, align 1, !tbaa !6
  %561 = icmp eq i8 %560, 0
  br i1 %561, label %586, label %567

562:                                              ; preds = %578
  %563 = add nuw nsw i8 %568, 1
  %564 = add nuw nsw i8 %570, 2
  %565 = add nuw nsw i8 %571, 1
  %566 = icmp eq i8 %563, 32
  br i1 %566, label %586, label %567, !llvm.loop !70

567:                                              ; preds = %558, %562
  %568 = phi i8 [ %563, %562 ], [ 17, %558 ]
  %569 = phi i8 [ %584, %562 ], [ %560, %558 ]
  %570 = phi i8 [ %564, %562 ], [ 0, %558 ]
  %571 = phi i8 [ %565, %562 ], [ 0, %558 ]
  %572 = zext i8 %569 to i16
  %573 = icmp ugt i8 %569, 31
  br i1 %573, label %574, label %578

574:                                              ; preds = %567
  %575 = icmp ult i8 %569, 96
  br i1 %575, label %576, label %578

576:                                              ; preds = %574
  %577 = add nuw nsw i16 %572, 224
  br label %578

578:                                              ; preds = %576, %574, %567
  %579 = phi i16 [ %577, %576 ], [ 256, %574 ], [ 256, %567 ]
  %580 = zext nneg i8 %570 to i16
  %581 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4346), i16 %580
  store i16 %579, ptr %581, align 1, !tbaa !2
  %582 = zext nneg i8 %571 to i16
  %583 = getelementptr i8, ptr %358, i16 %582
  %584 = load i8, ptr %583, align 1, !tbaa !6
  %585 = icmp eq i8 %584, 0
  br i1 %585, label %586, label %562, !llvm.loop !70

586:                                              ; preds = %578, %562, %558
  %587 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !54
  %588 = lshr i16 %587, 8
  call fastcc void @fmt_u16(i16 noundef %588, ptr noundef %1) #16
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4388), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4390), align 1, !tbaa !2
  %589 = or i8 %559, 3
  store i8 %589, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %590 = load i8, ptr %1, align 1, !tbaa !6
  %591 = icmp eq i8 %590, 0
  br i1 %591, label %616, label %597

592:                                              ; preds = %608
  %593 = add nuw nsw i8 %598, 1
  %594 = add nuw nsw i8 %600, 2
  %595 = add nuw nsw i8 %601, 1
  %596 = icmp eq i8 %593, 32
  br i1 %596, label %616, label %597, !llvm.loop !70

597:                                              ; preds = %586, %592
  %598 = phi i8 [ %593, %592 ], [ 6, %586 ]
  %599 = phi i8 [ %614, %592 ], [ %590, %586 ]
  %600 = phi i8 [ %594, %592 ], [ 0, %586 ]
  %601 = phi i8 [ %595, %592 ], [ 0, %586 ]
  %602 = zext i8 %599 to i16
  %603 = icmp ugt i8 %599, 31
  br i1 %603, label %604, label %608

604:                                              ; preds = %597
  %605 = icmp ult i8 %599, 96
  br i1 %605, label %606, label %608

606:                                              ; preds = %604
  %607 = add nuw nsw i16 %602, 224
  br label %608

608:                                              ; preds = %606, %604, %597
  %609 = phi i16 [ %607, %606 ], [ 256, %604 ], [ 256, %597 ]
  %610 = zext nneg i8 %600 to i16
  %611 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4388), i16 %610
  store i16 %609, ptr %611, align 1, !tbaa !2
  %612 = zext nneg i8 %601 to i16
  %613 = getelementptr i8, ptr %358, i16 %612
  %614 = load i8, ptr %613, align 1, !tbaa !6
  %615 = icmp eq i8 %614, 0
  br i1 %615, label %616, label %592, !llvm.loop !70

616:                                              ; preds = %608, %592, %586
  %617 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), align 1, !tbaa !56
  %618 = lshr i16 %617, 8
  call fastcc void @fmt_u16(i16 noundef %618, ptr noundef %1) #16
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4394), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4396), align 1, !tbaa !2
  %619 = load i8, ptr %1, align 1, !tbaa !6
  %620 = icmp eq i8 %619, 0
  br i1 %620, label %645, label %626

621:                                              ; preds = %637
  %622 = add nuw nsw i8 %627, 1
  %623 = add nuw nsw i8 %629, 2
  %624 = add nuw nsw i8 %630, 1
  %625 = icmp eq i8 %622, 32
  br i1 %625, label %645, label %626, !llvm.loop !70

626:                                              ; preds = %616, %621
  %627 = phi i8 [ %622, %621 ], [ 9, %616 ]
  %628 = phi i8 [ %643, %621 ], [ %619, %616 ]
  %629 = phi i8 [ %623, %621 ], [ 0, %616 ]
  %630 = phi i8 [ %624, %621 ], [ 0, %616 ]
  %631 = zext i8 %628 to i16
  %632 = icmp ugt i8 %628, 31
  br i1 %632, label %633, label %637

633:                                              ; preds = %626
  %634 = icmp ult i8 %628, 96
  br i1 %634, label %635, label %637

635:                                              ; preds = %633
  %636 = add nuw nsw i16 %631, 224
  br label %637

637:                                              ; preds = %635, %633, %626
  %638 = phi i16 [ %636, %635 ], [ 256, %633 ], [ 256, %626 ]
  %639 = zext nneg i8 %629 to i16
  %640 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4394), i16 %639
  store i16 %638, ptr %640, align 1, !tbaa !2
  %641 = zext nneg i8 %630 to i16
  %642 = getelementptr i8, ptr %358, i16 %641
  %643 = load i8, ptr %642, align 1, !tbaa !6
  %644 = icmp eq i8 %643, 0
  br i1 %644, label %645, label %621, !llvm.loop !70

645:                                              ; preds = %637, %621, %616
  %646 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4450), align 1, !tbaa !54
  %647 = lshr i16 %646, 8
  call fastcc void @fmt_u16(i16 noundef %647, ptr noundef %1) #16
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4410), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4412), align 1, !tbaa !2
  %648 = load i8, ptr %1, align 1, !tbaa !6
  %649 = icmp eq i8 %648, 0
  br i1 %649, label %674, label %655

650:                                              ; preds = %666
  %651 = add nuw nsw i8 %656, 1
  %652 = add nuw nsw i8 %658, 2
  %653 = add nuw nsw i8 %659, 1
  %654 = icmp eq i8 %651, 32
  br i1 %654, label %674, label %655, !llvm.loop !70

655:                                              ; preds = %645, %650
  %656 = phi i8 [ %651, %650 ], [ 17, %645 ]
  %657 = phi i8 [ %672, %650 ], [ %648, %645 ]
  %658 = phi i8 [ %652, %650 ], [ 0, %645 ]
  %659 = phi i8 [ %653, %650 ], [ 0, %645 ]
  %660 = zext i8 %657 to i16
  %661 = icmp ugt i8 %657, 31
  br i1 %661, label %662, label %666

662:                                              ; preds = %655
  %663 = icmp ult i8 %657, 96
  br i1 %663, label %664, label %666

664:                                              ; preds = %662
  %665 = add nuw nsw i16 %660, 224
  br label %666

666:                                              ; preds = %664, %662, %655
  %667 = phi i16 [ %665, %664 ], [ 256, %662 ], [ 256, %655 ]
  %668 = zext nneg i8 %658 to i16
  %669 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4410), i16 %668
  store i16 %667, ptr %669, align 1, !tbaa !2
  %670 = zext nneg i8 %659 to i16
  %671 = getelementptr i8, ptr %358, i16 %670
  %672 = load i8, ptr %671, align 1, !tbaa !6
  %673 = icmp eq i8 %672, 0
  br i1 %673, label %674, label %650, !llvm.loop !70

674:                                              ; preds = %666, %650, %645
  %675 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4452), align 1, !tbaa !56
  %676 = lshr i16 %675, 8
  call fastcc void @fmt_u16(i16 noundef %676, ptr noundef %1) #16
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4416), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4418), align 1, !tbaa !2
  %677 = load i8, ptr %1, align 1, !tbaa !6
  %678 = icmp eq i8 %677, 0
  br i1 %678, label %703, label %684

679:                                              ; preds = %695
  %680 = add nuw nsw i8 %685, 1
  %681 = add nuw nsw i8 %687, 2
  %682 = add nuw nsw i8 %688, 1
  %683 = icmp eq i8 %680, 32
  br i1 %683, label %703, label %684, !llvm.loop !70

684:                                              ; preds = %674, %679
  %685 = phi i8 [ %680, %679 ], [ 20, %674 ]
  %686 = phi i8 [ %701, %679 ], [ %677, %674 ]
  %687 = phi i8 [ %681, %679 ], [ 0, %674 ]
  %688 = phi i8 [ %682, %679 ], [ 0, %674 ]
  %689 = zext i8 %686 to i16
  %690 = icmp ugt i8 %686, 31
  br i1 %690, label %691, label %695

691:                                              ; preds = %684
  %692 = icmp ult i8 %686, 96
  br i1 %692, label %693, label %695

693:                                              ; preds = %691
  %694 = add nuw nsw i16 %689, 224
  br label %695

695:                                              ; preds = %693, %691, %684
  %696 = phi i16 [ %694, %693 ], [ 256, %691 ], [ 256, %684 ]
  %697 = zext nneg i8 %687 to i16
  %698 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4416), i16 %697
  store i16 %696, ptr %698, align 1, !tbaa !2
  %699 = zext nneg i8 %688 to i16
  %700 = getelementptr i8, ptr %358, i16 %699
  %701 = load i8, ptr %700, align 1, !tbaa !6
  %702 = icmp eq i8 %701, 0
  br i1 %702, label %703, label %679, !llvm.loop !70

703:                                              ; preds = %695, %679, %674
  %704 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4459), align 1, !tbaa !54
  %705 = lshr i16 %704, 8
  call fastcc void @fmt_u16(i16 noundef %705, ptr noundef %1) #16
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4432), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4434), align 1, !tbaa !2
  %706 = load i8, ptr %1, align 1, !tbaa !6
  %707 = icmp eq i8 %706, 0
  br i1 %707, label %732, label %713

708:                                              ; preds = %724
  %709 = add nuw nsw i8 %714, 1
  %710 = add nuw nsw i8 %716, 2
  %711 = add nuw nsw i8 %717, 1
  %712 = icmp eq i8 %709, 32
  br i1 %712, label %732, label %713, !llvm.loop !70

713:                                              ; preds = %703, %708
  %714 = phi i8 [ %709, %708 ], [ 28, %703 ]
  %715 = phi i8 [ %730, %708 ], [ %706, %703 ]
  %716 = phi i8 [ %710, %708 ], [ 0, %703 ]
  %717 = phi i8 [ %711, %708 ], [ 0, %703 ]
  %718 = zext i8 %715 to i16
  %719 = icmp ugt i8 %715, 31
  br i1 %719, label %720, label %724

720:                                              ; preds = %713
  %721 = icmp ult i8 %715, 96
  br i1 %721, label %722, label %724

722:                                              ; preds = %720
  %723 = add nuw nsw i16 %718, 224
  br label %724

724:                                              ; preds = %722, %720, %713
  %725 = phi i16 [ %723, %722 ], [ 256, %720 ], [ 256, %713 ]
  %726 = zext nneg i8 %716 to i16
  %727 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4432), i16 %726
  store i16 %725, ptr %727, align 1, !tbaa !2
  %728 = zext nneg i8 %717 to i16
  %729 = getelementptr i8, ptr %358, i16 %728
  %730 = load i8, ptr %729, align 1, !tbaa !6
  %731 = icmp eq i8 %730, 0
  br i1 %731, label %732, label %708, !llvm.loop !70

732:                                              ; preds = %724, %708, %703
  %733 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4461), align 1, !tbaa !56
  %734 = lshr i16 %733, 8
  call fastcc void @fmt_u16(i16 noundef %734, ptr noundef %1) #16
  %735 = load i8, ptr %1, align 1, !tbaa !6
  %736 = icmp eq i8 %735, 0
  br i1 %736, label %742, label %737

737:                                              ; preds = %732
  %738 = icmp ugt i8 %735, 31
  br i1 %738, label %739, label %745

739:                                              ; preds = %737
  %740 = zext nneg i8 %735 to i16
  %741 = icmp ult i8 %735, 96
  br i1 %741, label %742, label %745

742:                                              ; preds = %739, %732
  %743 = phi i16 [ %740, %739 ], [ 32, %732 ]
  %744 = add nuw nsw i16 %743, 224
  br label %745

745:                                              ; preds = %737, %739, %742
  %746 = phi i16 [ %744, %742 ], [ 256, %739 ], [ 256, %737 ]
  store i16 %746, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4438), align 1, !tbaa !2
  store i8 %589, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #17
  br label %747

747:                                              ; preds = %745, %554
  %748 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %749 = icmp eq i8 %748, 0
  br i1 %749, label %761, label %750

750:                                              ; preds = %747, %750
  %751 = phi i8 [ %758, %750 ], [ 0, %747 ]
  %752 = zext i8 %751 to i16
  %753 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %752
  %754 = load ptr, ptr %753, align 1, !tbaa !35
  %755 = load ptr, ptr %754, align 1, !tbaa !40
  %756 = getelementptr inbounds nuw i8, ptr %755, i16 2
  %757 = load ptr, ptr %756, align 1, !tbaa !94
  tail call void %757(ptr noundef nonnull %754, ptr noundef nonnull @main.a) #15, !inline_history !111
  %758 = add nuw i8 %751, 1
  %759 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %760 = icmp ult i8 %758, %759
  br i1 %760, label %750, label %761, !llvm.loop !96

761:                                              ; preds = %750, %747
  %762 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %763

763:                                              ; preds = %763, %761
  %764 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %765 = icmp sgt i8 %764, -1
  br i1 %765, label %763, label %766, !llvm.loop !97

766:                                              ; preds = %763
  tail call fastcc void @upq_flush() #16
  %767 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %768 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %769 = icmp ult i8 %767, %768
  br i1 %769, label %772, label %770

770:                                              ; preds = %766
  %771 = icmp ugt i8 %767, %768
  br i1 %771, label %772, label %775

772:                                              ; preds = %770, %766
  %773 = phi i8 [ 1, %766 ], [ -1, %770 ]
  %774 = add i8 %773, %767
  store i8 %774, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %775

775:                                              ; preds = %770, %772
  %776 = phi i8 [ %767, %770 ], [ %774, %772 ]
  %777 = and i8 %776, 15
  store volatile i8 %777, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  br label %359
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(none)
define internal fastcc i16 @nbody_gate_crc() unnamed_addr #2 {
  %1 = alloca [3 x %struct.NBody], align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #17
  store i16 16384, ptr %1, align 1, !tbaa !54
  %2 = getelementptr inbounds nuw i8, ptr %1, i16 2
  store i16 16384, ptr %2, align 1, !tbaa !56
  %3 = getelementptr inbounds nuw i8, ptr %1, i16 4
  store i16 0, ptr %3, align 1, !tbaa !57
  %4 = getelementptr inbounds nuw i8, ptr %1, i16 6
  store i16 0, ptr %4, align 1, !tbaa !58
  %5 = getelementptr inbounds nuw i8, ptr %1, i16 8
  store i8 -1, ptr %5, align 1, !tbaa !59
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 9
  store i16 24064, ptr %6, align 1, !tbaa !54
  %7 = getelementptr inbounds nuw i8, ptr %1, i16 11
  store i16 16384, ptr %7, align 1, !tbaa !56
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 13
  store i16 0, ptr %8, align 1, !tbaa !57
  %9 = getelementptr inbounds nuw i8, ptr %1, i16 15
  store i16 -490, ptr %9, align 1, !tbaa !58
  %10 = getelementptr inbounds nuw i8, ptr %1, i16 17
  store i8 1, ptr %10, align 1, !tbaa !59
  %11 = getelementptr inbounds nuw i8, ptr %1, i16 18
  store i16 3584, ptr %11, align 1, !tbaa !54
  %12 = getelementptr inbounds nuw i8, ptr %1, i16 20
  store i16 16384, ptr %12, align 1, !tbaa !56
  %13 = getelementptr inbounds nuw i8, ptr %1, i16 22
  store i16 0, ptr %13, align 1, !tbaa !57
  %14 = getelementptr inbounds nuw i8, ptr %1, i16 24
  store i16 439, ptr %14, align 1, !tbaa !58
  %15 = getelementptr inbounds nuw i8, ptr %1, i16 26
  store i8 3, ptr %15, align 1, !tbaa !59
  br label %16

16:                                               ; preds = %0, %43
  %17 = phi i16 [ 0, %0 ], [ %44, %43 ]
  %18 = phi i16 [ 5053, %0 ], [ %39, %43 ]
  call fastcc void @nbody_step(ptr noundef nonnull %1) #16
  br label %19

19:                                               ; preds = %16, %19
  %20 = phi i8 [ 0, %16 ], [ %42, %19 ]
  %21 = phi i8 [ 0, %16 ], [ %40, %19 ]
  %22 = phi i16 [ %18, %16 ], [ %39, %19 ]
  %23 = tail call i16 @llvm.fshl.i16(i16 %22, i16 %22, i16 3)
  %24 = zext nneg i8 %20 to i16
  %25 = getelementptr i8, ptr %1, i16 %24
  %26 = load i16, ptr %25, align 1, !tbaa !54
  %27 = xor i16 %26, %23
  %28 = tail call i16 @llvm.fshl.i16(i16 %27, i16 %27, i16 3)
  %29 = getelementptr i8, ptr %2, i16 %24
  %30 = load i16, ptr %29, align 1, !tbaa !56
  %31 = xor i16 %28, %30
  %32 = tail call i16 @llvm.fshl.i16(i16 %31, i16 %31, i16 3)
  %33 = getelementptr i8, ptr %3, i16 %24
  %34 = load i16, ptr %33, align 1, !tbaa !57
  %35 = xor i16 %32, %34
  %36 = tail call i16 @llvm.fshl.i16(i16 %35, i16 %35, i16 3)
  %37 = getelementptr i8, ptr %4, i16 %24
  %38 = load i16, ptr %37, align 1, !tbaa !58
  %39 = xor i16 %36, %38
  %40 = add nuw nsw i8 %21, 1
  %41 = icmp eq i8 %40, 3
  %42 = add nuw nsw i8 %20, 9
  br i1 %41, label %43, label %19, !llvm.loop !112

43:                                               ; preds = %19
  %44 = add nuw nsw i16 %17, 1
  %45 = icmp eq i16 %44, 32
  br i1 %45, label %46, label %16, !llvm.loop !113

46:                                               ; preds = %43
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #17
  ret i16 %39
}

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(argmem: readwrite)
define internal fastcc void @nbody_step(ptr noundef captures(none) %0) unnamed_addr #3 {
  %2 = alloca [3 x i32], align 1
  %3 = alloca [3 x i32], align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #17
  call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(12) %2, i8 0, i16 12, i1 false)
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #17
  call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(12) %3, i8 0, i16 12, i1 false)
  %4 = getelementptr i8, ptr %0, i16 9
  %5 = getelementptr inbounds nuw i8, ptr %2, i16 4
  %6 = getelementptr inbounds nuw i8, ptr %3, i16 4
  %7 = getelementptr i8, ptr %0, i16 18
  %8 = getelementptr inbounds nuw i8, ptr %2, i16 8
  %9 = getelementptr inbounds nuw i8, ptr %3, i16 8
  br label %10

10:                                               ; preds = %1, %36
  %11 = phi i8 [ 0, %1 ], [ %17, %36 ]
  %12 = phi ptr [ %4, %1 ], [ %37, %36 ]
  %13 = phi ptr [ %5, %1 ], [ %38, %36 ]
  %14 = phi ptr [ %6, %1 ], [ %39, %36 ]
  %15 = phi i8 [ 0, %1 ], [ %40, %36 ]
  %16 = phi i8 [ 0, %1 ], [ %41, %36 ]
  %17 = add nuw nsw i8 %11, 1
  %18 = zext nneg i8 %15 to i16
  %19 = getelementptr i8, ptr %0, i16 %18
  %20 = zext nneg i8 %16 to i16
  %21 = getelementptr i8, ptr %2, i16 %20
  %22 = getelementptr i8, ptr %3, i16 %20
  br label %23

23:                                               ; preds = %10, %23
  %24 = phi i8 [ 0, %10 ], [ %35, %23 ]
  %25 = phi i8 [ 0, %10 ], [ %34, %23 ]
  %26 = phi i8 [ %17, %10 ], [ %32, %23 ]
  %27 = zext nneg i8 %25 to i16
  %28 = getelementptr i8, ptr %12, i16 %27
  %29 = zext nneg i8 %24 to i16
  %30 = getelementptr i8, ptr %13, i16 %29
  %31 = getelementptr i8, ptr %14, i16 %29
  call fastcc void @nbody_force_pair(ptr noundef %19, ptr noundef nonnull %28, ptr noundef %21, ptr noundef %22, ptr noundef %30, ptr noundef %31) #16
  %32 = add nuw nsw i8 %26, 1
  %33 = icmp eq i8 %32, 3
  %34 = add nuw nsw i8 %25, 9
  %35 = add nuw nsw i8 %24, 4
  br i1 %33, label %36, label %23, !llvm.loop !114

36:                                               ; preds = %23
  %37 = getelementptr i8, ptr %7, i16 %18
  %38 = getelementptr i8, ptr %8, i16 %20
  %39 = getelementptr i8, ptr %9, i16 %20
  %40 = add nuw nsw i8 %15, 9
  %41 = add nuw nsw i8 %16, 4
  %42 = icmp eq i8 %11, 0
  br i1 %42, label %10, label %43, !llvm.loop !115

43:                                               ; preds = %36
  %44 = getelementptr i8, ptr %0, i16 4
  %45 = getelementptr i8, ptr %0, i16 6
  %46 = getelementptr i8, ptr %0, i16 2
  br label %47

47:                                               ; preds = %43, %47
  %48 = phi i8 [ 0, %43 ], [ %76, %47 ]
  %49 = phi i8 [ 0, %43 ], [ %75, %47 ]
  %50 = phi i8 [ 0, %43 ], [ %73, %47 ]
  %51 = zext nneg i8 %49 to i16
  %52 = getelementptr i8, ptr %0, i16 %51
  %53 = getelementptr i8, ptr %44, i16 %51
  %54 = load i16, ptr %53, align 1, !tbaa !57
  %55 = zext nneg i8 %48 to i16
  %56 = getelementptr i8, ptr %2, i16 %55
  %57 = load i32, ptr %56, align 1, !tbaa !116
  %58 = lshr i32 %57, 4
  %59 = trunc i32 %58 to i16
  %60 = add nsw i16 %54, %59
  store i16 %60, ptr %53, align 1, !tbaa !57
  %61 = getelementptr i8, ptr %45, i16 %51
  %62 = load i16, ptr %61, align 1, !tbaa !58
  %63 = getelementptr i8, ptr %3, i16 %55
  %64 = load i32, ptr %63, align 1, !tbaa !116
  %65 = lshr i32 %64, 4
  %66 = trunc i32 %65 to i16
  %67 = add nsw i16 %62, %66
  store i16 %67, ptr %61, align 1, !tbaa !58
  %68 = load i16, ptr %52, align 1, !tbaa !54
  %69 = add nsw i16 %68, %60
  store i16 %69, ptr %52, align 1, !tbaa !54
  %70 = getelementptr i8, ptr %46, i16 %51
  %71 = load i16, ptr %70, align 1, !tbaa !56
  %72 = add nsw i16 %71, %67
  store i16 %72, ptr %70, align 1, !tbaa !56
  %73 = add nuw nsw i8 %50, 1
  %74 = icmp eq i8 %73, 3
  %75 = add nuw nsw i8 %49, 9
  %76 = add nuw nsw i8 %48, 4
  br i1 %74, label %77, label %47, !llvm.loop !118

77:                                               ; preds = %47
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #17
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #17
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_canvas_reserve(ptr noundef readonly captures(none) %0, ptr readnone captures(none) %1) #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4105
  %4 = load i16, ptr %3, align 1, !tbaa !21
  %5 = lshr i16 %4, 8
  %6 = trunc nuw i16 %5 to i8
  %7 = and i8 %6, -4
  store volatile i8 %7, ptr inttoptr (i16 8457 to ptr), align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %9 = load i16, ptr %8, align 1, !tbaa !20
  %10 = lshr i16 %9, 12
  %11 = trunc nuw nsw i16 %10 to i8
  store volatile i8 %11, ptr inttoptr (i16 8460 to ptr), align 4, !tbaa !6
  %12 = load i16, ptr %8, align 1, !tbaa !20
  %13 = lshr i16 %12, 3
  %14 = add nuw nsw i16 %13, 256
  %15 = load i16, ptr %3, align 1, !tbaa !21
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %15, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %16 = getelementptr inbounds nuw i8, ptr %0, i16 4107
  %17 = load i8, ptr %16, align 1, !tbaa !22
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 4108
  br label %19

19:                                               ; preds = %2, %23
  %20 = phi i8 [ 0, %2 ], [ %24, %23 ]
  br label %26

21:                                               ; preds = %23
  %22 = load i16, ptr %8, align 1, !tbaa !20
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %22, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %45

23:                                               ; preds = %40
  %24 = add nuw nsw i8 %20, 1
  %25 = icmp eq i8 %24, 32
  br i1 %25, label %21, label %19, !llvm.loop !119

26:                                               ; preds = %19, %40
  %27 = phi i8 [ 0, %19 ], [ %42, %40 ]
  %28 = sub i8 %27, %17
  %29 = zext i8 %28 to i16
  %30 = icmp ult i8 %28, 16
  br i1 %30, label %31, label %40

31:                                               ; preds = %26
  %32 = load i8, ptr %18, align 1, !tbaa !23
  %33 = sub i8 %20, %32
  %34 = icmp ult i8 %33, 16
  br i1 %34, label %35, label %40

35:                                               ; preds = %31
  %36 = shl nuw i8 %33, 4
  %37 = zext i8 %36 to i16
  %38 = add nuw nsw i16 %13, %29
  %39 = add nuw nsw i16 %38, %37
  br label %40

40:                                               ; preds = %26, %31, %35
  %41 = phi i16 [ %39, %35 ], [ %14, %31 ], [ %14, %26 ]
  store volatile i16 %41, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %42 = add nuw nsw i8 %27, 1
  %43 = icmp eq i8 %42, 32
  br i1 %43, label %23, label %26, !llvm.loop !120

44:                                               ; preds = %45
  ret void

45:                                               ; preds = %21, %45
  %46 = phi i16 [ 0, %21 ], [ %47, %45 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %47 = add nuw nsw i16 %46, 1
  %48 = icmp eq i16 %47, 2056
  br i1 %48, label %44, label %45, !llvm.loop !121
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal void @_canvas_emit(ptr noundef %0, ptr noundef captures(none) %1) #5 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4099
  %4 = load i16, ptr %3, align 1, !tbaa !24
  %5 = getelementptr inbounds nuw i8, ptr %0, i16 4101
  %6 = load i16, ptr %5, align 1, !tbaa !25
  %7 = icmp ugt i16 %4, %6
  br i1 %7, label %48, label %8

8:                                                ; preds = %2
  %9 = sub nuw i16 %6, %4
  %10 = add i16 %9, -64
  %11 = icmp ult i16 %10, -65
  br i1 %11, label %12, label %14

12:                                               ; preds = %8
  %13 = add i16 %4, 63
  br label %14

14:                                               ; preds = %12, %8
  %15 = phi i16 [ 63, %12 ], [ %9, %8 ]
  %16 = phi i16 [ %13, %12 ], [ %6, %8 ]
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %18 = load i16, ptr %17, align 1, !tbaa !20
  %19 = shl i16 %4, 3
  %20 = add i16 %18, %19
  %21 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %22 = shl i16 %4, 4
  %23 = getelementptr inbounds nuw i8, ptr %21, i16 %22
  %24 = shl nsw i16 %15, 4
  %25 = add nsw i16 %24, 16
  %26 = icmp eq i16 %25, 0
  br i1 %26, label %43, label %27

27:                                               ; preds = %14
  %28 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %29 = load i8, ptr %28, align 1, !tbaa !44
  %30 = icmp ugt i8 %29, 15
  br i1 %30, label %43, label %31

31:                                               ; preds = %27
  %32 = zext nneg i8 %29 to i16
  %33 = add nuw nsw i8 %29, 1
  store i8 %33, ptr %28, align 1, !tbaa !44
  %34 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %32
  %35 = getelementptr inbounds nuw i8, ptr %34, i16 10
  store i8 0, ptr %35, align 1, !tbaa !45
  store i16 %20, ptr %34, align 1, !tbaa !47
  %36 = getelementptr inbounds nuw i8, ptr %34, i16 9
  store i8 -128, ptr %36, align 1, !tbaa !48
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 7
  store i8 24, ptr %37, align 1, !tbaa !49
  %38 = getelementptr inbounds nuw i8, ptr %34, i16 8
  store i8 1, ptr %38, align 1, !tbaa !50
  %39 = ptrtoint ptr %23 to i16
  %40 = getelementptr inbounds nuw i8, ptr %34, i16 2
  store i16 %39, ptr %40, align 1, !tbaa !51
  %41 = getelementptr inbounds nuw i8, ptr %34, i16 6
  store i8 0, ptr %41, align 1, !tbaa !52
  %42 = getelementptr inbounds nuw i8, ptr %34, i16 4
  store i16 %25, ptr %42, align 1, !tbaa !53
  br label %43

43:                                               ; preds = %14, %27, %31
  %44 = icmp ult i16 %16, %6
  br i1 %44, label %46, label %45

45:                                               ; preds = %43
  store i16 -1, ptr %3, align 1, !tbaa !24
  store i16 0, ptr %5, align 1, !tbaa !25
  br label %48

46:                                               ; preds = %43
  %47 = add nuw i16 %16, 1
  store i16 %47, ptr %3, align 1, !tbaa !24
  br label %48

48:                                               ; preds = %45, %46, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_text_reserve(ptr readnone captures(none) %0, ptr readnone captures(none) %1) #4 {
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 2048, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %4

3:                                                ; preds = %4
  ret void

4:                                                ; preds = %2, %4
  %5 = phi i16 [ 0, %2 ], [ %8, %4 ]
  %6 = getelementptr inbounds nuw [2 x i8], ptr @FONT8, i16 %5
  %7 = load i16, ptr %6, align 1, !tbaa !2
  store volatile i16 %7, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %8 = add nuw nsw i16 %5, 1
  %9 = icmp eq i16 %8, 512
  br i1 %9, label %3, label %4, !llvm.loop !122
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(argmem: readwrite)
define internal void @_text_emit(ptr noundef %0, ptr noundef captures(none) %1) #6 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 135
  %4 = load i8, ptr %3, align 1, !tbaa !31
  %5 = zext i8 %4 to i16
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %7 = getelementptr i8, ptr %0, i16 7
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %9 = getelementptr i8, ptr %0, i16 5
  br label %11

10:                                               ; preds = %42
  store i8 0, ptr %3, align 1, !tbaa !31
  ret void

11:                                               ; preds = %2, %42
  %12 = phi i8 [ 0, %2 ], [ %43, %42 ]
  %13 = phi i1 [ true, %2 ], [ false, %42 ]
  %14 = phi i8 [ 0, %2 ], [ 1, %42 ]
  %15 = zext nneg i8 %14 to i16
  %16 = shl nuw nsw i16 1, %15
  %17 = and i16 %16, %5
  %18 = icmp eq i16 %17, 0
  br i1 %18, label %42, label %19

19:                                               ; preds = %11
  %20 = load i8, ptr %6, align 1, !tbaa !44
  %21 = icmp ugt i8 %20, 15
  br i1 %21, label %42, label %22

22:                                               ; preds = %19
  %23 = zext i8 %12 to i16
  %24 = getelementptr i8, ptr %7, i16 %23
  %25 = load i16, ptr %8, align 1, !tbaa !29
  %26 = getelementptr i8, ptr %9, i16 %15
  %27 = load i8, ptr %26, align 1, !tbaa !6
  %28 = zext i8 %27 to i16
  %29 = shl nuw nsw i16 %28, 5
  %30 = add i16 %29, %25
  %31 = zext nneg i8 %20 to i16
  %32 = add nuw nsw i8 %20, 1
  store i8 %32, ptr %6, align 1, !tbaa !44
  %33 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %31
  %34 = getelementptr inbounds nuw i8, ptr %33, i16 10
  store i8 0, ptr %34, align 1, !tbaa !45
  store i16 %30, ptr %33, align 1, !tbaa !47
  %35 = getelementptr inbounds nuw i8, ptr %33, i16 9
  store i8 -128, ptr %35, align 1, !tbaa !48
  %36 = getelementptr inbounds nuw i8, ptr %33, i16 7
  store i8 24, ptr %36, align 1, !tbaa !49
  %37 = getelementptr inbounds nuw i8, ptr %33, i16 8
  store i8 1, ptr %37, align 1, !tbaa !50
  %38 = ptrtoint ptr %24 to i16
  %39 = getelementptr inbounds nuw i8, ptr %33, i16 2
  store i16 %38, ptr %39, align 1, !tbaa !51
  %40 = getelementptr inbounds nuw i8, ptr %33, i16 6
  store i8 0, ptr %40, align 1, !tbaa !52
  %41 = getelementptr inbounds nuw i8, ptr %33, i16 4
  store i16 64, ptr %41, align 1, !tbaa !53
  br label %42

42:                                               ; preds = %22, %19, %11
  %43 = add nuw i8 %12, 64
  br i1 %13, label %11, label %10, !llvm.loop !123
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_title_reserve(ptr noundef %0, ptr readnone captures(none) %1) #4 {
  store volatile i8 80, ptr inttoptr (i16 8456 to ptr), align 8, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !6
  store volatile i8 112, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -1, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 127, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -124, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 4096, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %3

3:                                                ; preds = %2, %16
  %4 = phi ptr [ @FONT8, %2 ], [ %18, %16 ]
  %5 = phi i16 [ 0, %2 ], [ %17, %16 ]
  br label %7

6:                                                ; preds = %16
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 5120, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %24

7:                                                ; preds = %3, %7
  %8 = phi i8 [ 0, %3 ], [ %15, %7 ]
  %9 = phi i8 [ 0, %3 ], [ %13, %7 ]
  %10 = zext nneg i8 %8 to i16
  %11 = getelementptr i8, ptr %4, i16 %10
  %12 = load i16, ptr %11, align 1, !tbaa !2
  store volatile i16 %12, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %13 = add nuw nsw i8 %9, 1
  %14 = icmp eq i8 %13, 8
  %15 = add nuw nsw i8 %8, 2
  br i1 %14, label %20, label %7, !llvm.loop !124

16:                                               ; preds = %20
  %17 = add nuw nsw i16 %5, 1
  %18 = getelementptr i8, ptr %4, i16 16
  %19 = icmp eq i16 %17, 64
  br i1 %19, label %6, label %3, !llvm.loop !125

20:                                               ; preds = %7, %20
  %21 = phi i8 [ %22, %20 ], [ 0, %7 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %22 = add nuw nsw i8 %21, 1
  %23 = icmp eq i8 %22, 8
  br i1 %23, label %16, label %20, !llvm.loop !126

24:                                               ; preds = %6, %33
  %25 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 16), %6 ], [ %36, %33 ]
  %26 = phi ptr [ @FONT16, %6 ], [ %35, %33 ]
  %27 = phi i16 [ 0, %6 ], [ %34, %33 ]
  br label %29

28:                                               ; preds = %33
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 20480, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %66

29:                                               ; preds = %24, %47
  %30 = phi i8 [ 0, %24 ], [ %52, %47 ]
  %31 = phi ptr [ %26, %24 ], [ %50, %47 ]
  %32 = phi i8 [ 0, %24 ], [ %48, %47 ]
  br label %38

33:                                               ; preds = %47
  %34 = add nuw nsw i16 %27, 1
  %35 = getelementptr i8, ptr %26, i16 64
  %36 = getelementptr i8, ptr %25, i16 64
  %37 = icmp eq i16 %34, 64
  br i1 %37, label %28, label %24, !llvm.loop !127

38:                                               ; preds = %29, %38
  %39 = phi i8 [ 0, %29 ], [ %46, %38 ]
  %40 = phi i8 [ 0, %29 ], [ %44, %38 ]
  %41 = zext nneg i8 %39 to i16
  %42 = getelementptr i8, ptr %31, i16 %41
  %43 = load i16, ptr %42, align 1, !tbaa !2
  store volatile i16 %43, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %44 = add nuw nsw i8 %40, 1
  %45 = icmp eq i8 %44, 8
  %46 = add nuw nsw i8 %39, 2
  br i1 %45, label %53, label %38, !llvm.loop !128

47:                                               ; preds = %53
  %48 = add nuw nsw i8 %32, 1
  %49 = zext nneg i8 %30 to i16
  %50 = getelementptr i8, ptr %25, i16 %49
  %51 = icmp eq i8 %48, 4
  %52 = add nuw nsw i8 %30, 16
  br i1 %51, label %33, label %29, !llvm.loop !129

53:                                               ; preds = %38, %53
  %54 = phi i8 [ %55, %53 ], [ 0, %38 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %55 = add nuw nsw i8 %54, 1
  %56 = icmp eq i8 %55, 8
  br i1 %56, label %47, label %53, !llvm.loop !130

57:                                               ; preds = %66
  %58 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %59 = load ptr, ptr %58, align 1, !tbaa !76
  %60 = icmp eq ptr %59, null
  br i1 %60, label %79, label %61

61:                                               ; preds = %57
  %62 = load i8, ptr %59, align 1, !tbaa !6
  %63 = icmp eq i8 %62, 0
  br i1 %63, label %79, label %64

64:                                               ; preds = %61
  %65 = getelementptr i8, ptr %59, i16 1
  br label %70

66:                                               ; preds = %28, %66
  %67 = phi i16 [ 0, %28 ], [ %68, %66 ]
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %68 = add nuw nsw i16 %67, 1
  %69 = icmp eq i16 %68, 1024
  br i1 %69, label %57, label %66, !llvm.loop !131

70:                                               ; preds = %64, %70
  %71 = phi i8 [ %72, %70 ], [ 0, %64 ]
  %72 = add nuw nsw i8 %71, 1
  %73 = zext nneg i8 %71 to i16
  %74 = getelementptr i8, ptr %65, i16 %73
  %75 = load i8, ptr %74, align 1, !tbaa !6
  %76 = icmp ne i8 %75, 0
  %77 = icmp samesign ult i8 %71, 31
  %78 = select i1 %76, i1 %77, i1 false
  br i1 %78, label %70, label %79, !llvm.loop !132

79:                                               ; preds = %70, %61, %57
  %80 = phi i8 [ 0, %57 ], [ 0, %61 ], [ %72, %70 ]
  %81 = zext nneg i8 %80 to i16
  %82 = sub nuw nsw i16 32, %81
  %83 = lshr i16 %82, 1
  %84 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %85 = load i16, ptr %84, align 1, !tbaa !82
  %86 = shl i16 %85, 2
  %87 = and i16 %86, -32
  %88 = add i16 %87, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %88, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %89 = trunc nuw nsw i16 %83 to i8
  %90 = add nuw nsw i8 %80, %89
  %91 = sub nsw i16 0, %83
  %92 = getelementptr i8, ptr %59, i16 %91
  br label %105

93:                                               ; preds = %128
  %94 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %95 = load ptr, ptr %94, align 1, !tbaa !78
  %96 = getelementptr inbounds nuw i8, ptr %0, i16 11
  %97 = load i8, ptr %96, align 1, !tbaa !79
  %98 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %99 = load i16, ptr %98, align 1, !tbaa !83
  %100 = lshr i16 %99, 3
  %101 = trunc i16 %100 to i8
  tail call fastcc void @_title_write16(ptr noundef %95, i8 noundef zeroext %97, i8 noundef zeroext %101) #16
  %102 = getelementptr inbounds nuw i8, ptr %0, i16 9
  %103 = load ptr, ptr %102, align 1, !tbaa !80
  %104 = icmp eq ptr %103, null
  br i1 %104, label %139, label %132

105:                                              ; preds = %79, %128
  %106 = phi i8 [ 0, %79 ], [ %130, %128 ]
  %107 = zext nneg i8 %106 to i16
  br i1 %60, label %128, label %108

108:                                              ; preds = %105
  %109 = icmp samesign ugt i16 %83, %107
  br i1 %109, label %128, label %110

110:                                              ; preds = %108
  %111 = icmp ult i8 %106, %90
  br i1 %111, label %112, label %128

112:                                              ; preds = %110
  %113 = getelementptr i8, ptr %92, i16 %107
  %114 = load i8, ptr %113, align 1, !tbaa !6
  %115 = icmp ugt i8 %114, 96
  br i1 %115, label %116, label %120

116:                                              ; preds = %112
  %117 = icmp ult i8 %114, 123
  br i1 %117, label %118, label %128

118:                                              ; preds = %116
  %119 = add nsw i8 %114, -32
  br label %124

120:                                              ; preds = %112
  %121 = icmp samesign ugt i8 %114, 31
  br i1 %121, label %122, label %128

122:                                              ; preds = %120
  %123 = icmp eq i8 %114, 96
  br i1 %123, label %128, label %124

124:                                              ; preds = %122, %118
  %125 = phi i8 [ %119, %118 ], [ %114, %122 ]
  %126 = zext nneg i8 %125 to i16
  %127 = add nuw nsw i16 %126, 7136
  br label %128

128:                                              ; preds = %124, %122, %120, %116, %105, %108, %110
  %129 = phi i16 [ 7168, %105 ], [ 7168, %110 ], [ 7168, %108 ], [ %127, %124 ], [ 7168, %122 ], [ 7168, %120 ], [ 7168, %116 ]
  store volatile i16 %129, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %130 = add nuw nsw i8 %106, 1
  %131 = icmp eq i8 %130, 32
  br i1 %131, label %93, label %105, !llvm.loop !133

132:                                              ; preds = %93
  %133 = getelementptr inbounds nuw i8, ptr %0, i16 12
  %134 = load i8, ptr %133, align 1, !tbaa !81
  %135 = load i16, ptr %98, align 1, !tbaa !83
  %136 = lshr i16 %135, 3
  %137 = trunc i16 %136 to i8
  %138 = add i8 %137, 2
  tail call fastcc void @_title_write16(ptr noundef nonnull %103, i8 noundef zeroext %134, i8 noundef zeroext %138) #16
  br label %139

139:                                              ; preds = %132, %93
  %140 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 -128, ptr %140, align 1, !tbaa !105
  %141 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 3584, ptr %141, align 1, !tbaa !134
  %142 = getelementptr inbounds nuw i8, ptr %0, i16 23
  store i16 0, ptr %142, align 1, !tbaa !135
  %143 = load ptr, ptr %58, align 1, !tbaa !76
  %144 = icmp eq ptr %143, null
  br i1 %144, label %167, label %145

145:                                              ; preds = %139
  %146 = load i8, ptr %143, align 1, !tbaa !6
  %147 = icmp eq i8 %146, 0
  br i1 %147, label %150, label %148

148:                                              ; preds = %145
  %149 = getelementptr i8, ptr %143, i16 1
  br label %158

150:                                              ; preds = %158, %145
  %151 = phi i8 [ 0, %145 ], [ %160, %158 ]
  %152 = zext nneg i8 %151 to i16
  %153 = shl nuw nsw i16 %152, 2
  %154 = sub nuw nsw i16 128, %153
  %155 = and i16 %154, 248
  %156 = add nsw i16 %153, -128
  %157 = add nsw i16 %156, %155
  br label %167

158:                                              ; preds = %158, %148
  %159 = phi i8 [ %160, %158 ], [ 0, %148 ]
  %160 = add nuw nsw i8 %159, 1
  %161 = zext nneg i8 %159 to i16
  %162 = getelementptr i8, ptr %149, i16 %161
  %163 = load i8, ptr %162, align 1, !tbaa !6
  %164 = icmp ne i8 %163, 0
  %165 = icmp samesign ult i8 %159, 31
  %166 = select i1 %164, i1 %165, i1 false
  br i1 %166, label %158, label %150, !llvm.loop !136

167:                                              ; preds = %139, %150
  %168 = phi i16 [ %157, %150 ], [ 0, %139 ]
  %169 = getelementptr inbounds nuw i8, ptr %0, i16 26
  store i16 %168, ptr %169, align 1, !tbaa !137
  store volatile i8 -112, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  %170 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %171 = getelementptr inbounds nuw i8, ptr %0, i16 89
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef -8, i16 noundef 224, ptr noundef nonnull %170, ptr noundef nonnull %171) #16
  %172 = getelementptr inbounds nuw i8, ptr %0, i16 88
  store i8 0, ptr %172, align 1, !tbaa !138
  store volatile i8 2, ptr inttoptr (i16 17200 to ptr), align 16, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 17201 to ptr), align 1, !tbaa !6
  %173 = ptrtoint ptr %170 to i16
  %174 = trunc i16 %173 to i8
  store volatile i8 %174, ptr inttoptr (i16 17202 to ptr), align 2, !tbaa !6
  %175 = lshr i16 %173, 8
  %176 = trunc nuw i16 %175 to i8
  store volatile i8 %176, ptr inttoptr (i16 17203 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17204 to ptr), align 4, !tbaa !6
  %177 = getelementptr inbounds nuw i8, ptr %0, i16 139
  store i8 0, ptr %177, align 1, !tbaa !138
  store volatile i8 2, ptr inttoptr (i16 17216 to ptr), align 64, !tbaa !6
  store volatile i8 15, ptr inttoptr (i16 17217 to ptr), align 1, !tbaa !6
  %178 = ptrtoint ptr %171 to i16
  %179 = trunc i16 %178 to i8
  store volatile i8 %179, ptr inttoptr (i16 17218 to ptr), align 2, !tbaa !6
  %180 = lshr i16 %178, 8
  %181 = trunc nuw i16 %180 to i8
  store volatile i8 %181, ptr inttoptr (i16 17219 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17220 to ptr), align 4, !tbaa !6
  %182 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 2, ptr %182, align 1, !tbaa !75
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal void @_title_emit(ptr noundef %0, ptr noundef captures(none) %1) #7 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 29
  %4 = load i8, ptr %3, align 1, !tbaa !86
  %5 = icmp eq i8 %4, 0
  br i1 %5, label %188, label %6

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 30
  %8 = load i8, ptr %7, align 1, !tbaa !89
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %39, label %10

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 25
  %12 = load i8, ptr %11, align 1, !tbaa !90
  %13 = icmp ugt i8 %12, -6
  br i1 %13, label %16, label %14

14:                                               ; preds = %10
  %15 = add nuw i8 %12, 4
  br label %16

16:                                               ; preds = %10, %14
  %17 = phi i8 [ %15, %14 ], [ -1, %10 ]
  store i8 %17, ptr %11, align 1, !tbaa !90
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %19 = load i16, ptr %18, align 1, !tbaa !82
  %20 = xor i8 %17, -1
  %21 = zext i8 %20 to i16
  %22 = mul nuw i16 %21, %21
  %23 = lshr i16 %22, 8
  %24 = sub nuw nsw i16 256, %23
  %25 = add nsw i16 %19, 8
  %26 = mul nsw i16 %24, %25
  %27 = ashr i16 %26, 4
  %28 = and i16 %27, -16
  %29 = add nsw i16 %28, -128
  %30 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 %29, ptr %30, align 1, !tbaa !105
  %31 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %32 = load i16, ptr %31, align 1, !tbaa !83
  %33 = add nsw i16 %32, -224
  %34 = mul nsw i16 %33, %24
  %35 = ashr i16 %34, 4
  %36 = and i16 %35, -16
  %37 = add nsw i16 %36, 3584
  %38 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 %37, ptr %38, align 1, !tbaa !134
  br label %64

39:                                               ; preds = %6
  %40 = getelementptr inbounds nuw i8, ptr %0, i16 31
  %41 = load i8, ptr %40, align 1, !tbaa !87
  %42 = icmp eq i8 %41, 0
  br i1 %42, label %43, label %48

43:                                               ; preds = %39
  %44 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %45 = load i16, ptr %44, align 1, !tbaa !105
  %46 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %47 = load i16, ptr %46, align 1, !tbaa !134
  br label %64

48:                                               ; preds = %39
  %49 = getelementptr inbounds nuw i8, ptr %0, i16 23
  %50 = load i16, ptr %49, align 1, !tbaa !135
  %51 = add nsw i16 %50, 2
  store i16 %51, ptr %49, align 1, !tbaa !135
  %52 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %53 = load i16, ptr %52, align 1, !tbaa !105
  %54 = add nsw i16 %53, %51
  store i16 %54, ptr %52, align 1, !tbaa !105
  %55 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %56 = load i16, ptr %55, align 1, !tbaa !134
  %57 = add nsw i16 %56, %51
  store i16 %57, ptr %55, align 1, !tbaa !134
  %58 = icmp sgt i16 %54, 4480
  br i1 %58, label %59, label %60

59:                                               ; preds = %48
  store i16 4480, ptr %52, align 1, !tbaa !105
  br label %60

60:                                               ; preds = %59, %48
  %61 = phi i16 [ 4480, %59 ], [ %54, %48 ]
  %62 = icmp sgt i16 %57, 4736
  br i1 %62, label %63, label %64

63:                                               ; preds = %60
  store i16 4736, ptr %55, align 1, !tbaa !134
  br label %64

64:                                               ; preds = %43, %63, %60, %16
  %65 = phi i16 [ %47, %43 ], [ 4736, %63 ], [ %57, %60 ], [ %37, %16 ]
  %66 = phi i16 [ %45, %43 ], [ %61, %63 ], [ %61, %60 ], [ %29, %16 ]
  %67 = ashr i16 %66, 4
  %68 = ashr i16 %65, 4
  %69 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %70 = getelementptr inbounds nuw i8, ptr %0, i16 88
  %71 = load i8, ptr %70, align 1, !tbaa !138
  %72 = xor i8 %71, 1
  %73 = zext i8 %72 to i16
  %74 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %73
  %75 = getelementptr inbounds nuw i8, ptr %0, i16 89
  %76 = getelementptr inbounds nuw i8, ptr %0, i16 139
  %77 = load i8, ptr %76, align 1, !tbaa !138
  %78 = xor i8 %77, 1
  %79 = zext i8 %78 to i16
  %80 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %79
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef %67, i16 noundef %68, ptr noundef nonnull %74, ptr noundef nonnull %80) #16
  %81 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %82 = load i8, ptr %81, align 1, !tbaa !44
  %83 = icmp ugt i8 %82, 15
  br i1 %83, label %109, label %84

84:                                               ; preds = %64
  %85 = load i8, ptr %70, align 1, !tbaa !138
  %86 = xor i8 %85, 1
  %87 = zext i8 %86 to i16
  %88 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %87
  %89 = ptrtoint ptr %88 to i16
  %90 = zext nneg i8 %82 to i16
  %91 = add nuw nsw i8 %82, 1
  store i8 %91, ptr %81, align 1, !tbaa !44
  %92 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %90
  %93 = getelementptr inbounds nuw i8, ptr %92, i16 10
  store i8 4, ptr %93, align 1, !tbaa !45
  store i16 17202, ptr %92, align 1, !tbaa !47
  %94 = getelementptr inbounds nuw i8, ptr %92, i16 2
  store i16 %89, ptr %94, align 1, !tbaa !51
  %95 = getelementptr inbounds nuw i8, ptr %92, i16 4
  store i16 0, ptr %95, align 1, !tbaa !53
  store i8 %86, ptr %70, align 1, !tbaa !138
  %96 = icmp eq i8 %82, 15
  br i1 %96, label %109, label %97

97:                                               ; preds = %84
  %98 = load i8, ptr %76, align 1, !tbaa !138
  %99 = xor i8 %98, 1
  %100 = zext i8 %99 to i16
  %101 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %100
  %102 = ptrtoint ptr %101 to i16
  %103 = zext nneg i8 %91 to i16
  %104 = add nuw nsw i8 %82, 2
  store i8 %104, ptr %81, align 1, !tbaa !44
  %105 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %103
  %106 = getelementptr inbounds nuw i8, ptr %105, i16 10
  store i8 4, ptr %106, align 1, !tbaa !45
  store i16 17218, ptr %105, align 1, !tbaa !47
  %107 = getelementptr inbounds nuw i8, ptr %105, i16 2
  store i16 %102, ptr %107, align 1, !tbaa !51
  %108 = getelementptr inbounds nuw i8, ptr %105, i16 4
  store i16 0, ptr %108, align 1, !tbaa !53
  store i8 %99, ptr %76, align 1, !tbaa !138
  br label %109

109:                                              ; preds = %64, %84, %97
  %110 = phi i8 [ %82, %64 ], [ 16, %84 ], [ %104, %97 ]
  %111 = getelementptr inbounds nuw i8, ptr %0, i16 28
  %112 = load i8, ptr %111, align 1, !tbaa !85
  %113 = add i8 %112, 1
  store i8 %113, ptr %111, align 1, !tbaa !85
  %114 = getelementptr inbounds nuw i8, ptr %0, i16 32
  %115 = load i8, ptr %114, align 1, !tbaa !88
  %116 = icmp eq i8 %115, 0
  br i1 %116, label %117, label %155

117:                                              ; preds = %109
  %118 = shl i8 %113, 1
  %119 = icmp sgt i8 %118, -1
  br i1 %119, label %122, label %120

120:                                              ; preds = %117
  %121 = xor i8 %118, -1
  br label %122

122:                                              ; preds = %117, %120
  %123 = phi i8 [ %121, %120 ], [ %118, %117 ]
  %124 = lshr i8 %123, 4
  %125 = add nuw nsw i8 %124, 24
  %126 = zext nneg i8 %125 to i16
  %127 = mul nuw nsw i16 %126, 1057
  %128 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 %127, ptr %128, align 1, !tbaa !91
  %129 = add i8 %118, -86
  %130 = icmp sgt i8 %129, -1
  br i1 %130, label %133, label %131

131:                                              ; preds = %122
  %132 = sub nsw i8 85, %118
  br label %133

133:                                              ; preds = %122, %131
  %134 = phi i8 [ %132, %131 ], [ %129, %122 ]
  %135 = lshr i8 %134, 2
  %136 = zext nneg i8 %135 to i16
  %137 = shl nuw nsw i16 %136, 10
  %138 = add i8 %118, 85
  %139 = icmp sgt i8 %138, -1
  br i1 %139, label %142, label %140

140:                                              ; preds = %133
  %141 = sub nuw i8 -86, %118
  br label %142

142:                                              ; preds = %133, %140
  %143 = phi i8 [ %141, %140 ], [ %138, %133 ]
  %144 = lshr i8 %143, 2
  %145 = zext nneg i8 %144 to i16
  %146 = shl nuw nsw i16 %145, 5
  %147 = add nuw nsw i16 %146, %137
  br i1 %119, label %150, label %148

148:                                              ; preds = %142
  %149 = xor i8 %118, -1
  br label %150

150:                                              ; preds = %142, %148
  %151 = phi i8 [ %149, %148 ], [ %118, %142 ]
  %152 = lshr i8 %151, 2
  %153 = zext nneg i8 %152 to i16
  %154 = add nuw nsw i16 %147, %153
  br label %157

155:                                              ; preds = %109
  %156 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 29596, ptr %156, align 1, !tbaa !91
  br label %157

157:                                              ; preds = %155, %150
  %158 = phi i16 [ 0, %155 ], [ %154, %150 ]
  %159 = getelementptr inbounds nuw i8, ptr %0, i16 36
  store i16 %158, ptr %159, align 1, !tbaa !92
  %160 = icmp ugt i8 %110, 15
  br i1 %160, label %188, label %161

161:                                              ; preds = %157
  %162 = getelementptr inbounds nuw i8, ptr %0, i16 34
  %163 = zext nneg i8 %110 to i16
  %164 = add nuw nsw i8 %110, 1
  store i8 %164, ptr %81, align 1, !tbaa !44
  %165 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %163
  %166 = getelementptr inbounds nuw i8, ptr %165, i16 10
  store i8 1, ptr %166, align 1, !tbaa !45
  store i16 113, ptr %165, align 1, !tbaa !47
  %167 = getelementptr inbounds nuw i8, ptr %165, i16 9
  store i8 0, ptr %167, align 1, !tbaa !48
  %168 = getelementptr inbounds nuw i8, ptr %165, i16 7
  store i8 34, ptr %168, align 1, !tbaa !49
  %169 = getelementptr inbounds nuw i8, ptr %165, i16 8
  store i8 0, ptr %169, align 1, !tbaa !50
  %170 = ptrtoint ptr %162 to i16
  %171 = getelementptr inbounds nuw i8, ptr %165, i16 2
  store i16 %170, ptr %171, align 1, !tbaa !51
  %172 = getelementptr inbounds nuw i8, ptr %165, i16 6
  store i8 0, ptr %172, align 1, !tbaa !52
  %173 = getelementptr inbounds nuw i8, ptr %165, i16 4
  store i16 2, ptr %173, align 1, !tbaa !53
  %174 = icmp eq i8 %110, 15
  br i1 %174, label %188, label %175

175:                                              ; preds = %161
  %176 = getelementptr inbounds nuw i8, ptr %0, i16 36
  %177 = zext nneg i8 %164 to i16
  %178 = add nuw nsw i8 %110, 2
  store i8 %178, ptr %81, align 1, !tbaa !44
  %179 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %177
  %180 = getelementptr inbounds nuw i8, ptr %179, i16 10
  store i8 1, ptr %180, align 1, !tbaa !45
  store i16 0, ptr %179, align 1, !tbaa !47
  %181 = getelementptr inbounds nuw i8, ptr %179, i16 9
  store i8 0, ptr %181, align 1, !tbaa !48
  %182 = getelementptr inbounds nuw i8, ptr %179, i16 7
  store i8 34, ptr %182, align 1, !tbaa !49
  %183 = getelementptr inbounds nuw i8, ptr %179, i16 8
  store i8 0, ptr %183, align 1, !tbaa !50
  %184 = ptrtoint ptr %176 to i16
  %185 = getelementptr inbounds nuw i8, ptr %179, i16 2
  store i16 %184, ptr %185, align 1, !tbaa !51
  %186 = getelementptr inbounds nuw i8, ptr %179, i16 6
  store i8 0, ptr %186, align 1, !tbaa !52
  %187 = getelementptr inbounds nuw i8, ptr %179, i16 4
  store i16 2, ptr %187, align 1, !tbaa !53
  br label %188

188:                                              ; preds = %157, %175, %161, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @_title_write16(ptr noundef readonly captures(address_is_null) %0, i8 noundef zeroext %1, i8 noundef zeroext %2) unnamed_addr #4 {
  %4 = zext i8 %1 to i16
  %5 = shl nuw nsw i16 %4, 1
  %6 = and i16 %5, 254
  %7 = sub nsw i16 32, %6
  %8 = lshr exact i16 %7, 1
  %9 = zext i8 %2 to i16
  %10 = icmp eq ptr %0, null
  %11 = and i16 %8, 255
  %12 = add nuw i16 %8, %5
  %13 = and i16 %12, 255
  br label %15

14:                                               ; preds = %23
  ret void

15:                                               ; preds = %3, %23
  %16 = phi i1 [ true, %3 ], [ false, %23 ]
  %17 = phi i8 [ 0, %3 ], [ 1, %23 ]
  %18 = zext nneg i8 %17 to i16
  %19 = add nuw nsw i16 %18, %9
  %20 = shl nuw nsw i16 %19, 5
  %21 = add nuw nsw i16 %20, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %21, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %22 = select i1 %16, i16 7168, i16 7170
  br label %24

23:                                               ; preds = %56
  br i1 %16, label %15, label %14, !llvm.loop !139

24:                                               ; preds = %15, %56
  %25 = phi i8 [ 0, %15 ], [ %58, %56 ]
  %26 = zext nneg i8 %25 to i16
  br i1 %10, label %56, label %27

27:                                               ; preds = %24
  %28 = icmp samesign ugt i16 %11, %26
  br i1 %28, label %56, label %29

29:                                               ; preds = %27
  %30 = icmp samesign ugt i16 %13, %26
  br i1 %30, label %31, label %56

31:                                               ; preds = %29
  %32 = sub nsw i16 %26, %11
  %33 = lshr i16 %32, 1
  %34 = and i16 %33, 255
  %35 = getelementptr inbounds nuw i8, ptr %0, i16 %34
  %36 = load i8, ptr %35, align 1, !tbaa !6
  %37 = icmp ugt i8 %36, 96
  br i1 %37, label %38, label %42

38:                                               ; preds = %31
  %39 = icmp ult i8 %36, 123
  br i1 %39, label %40, label %51

40:                                               ; preds = %38
  %41 = add nsw i8 %36, -32
  br label %46

42:                                               ; preds = %31
  %43 = icmp samesign ugt i8 %36, 31
  br i1 %43, label %44, label %51

44:                                               ; preds = %42
  %45 = icmp eq i8 %36, 96
  br i1 %45, label %51, label %46

46:                                               ; preds = %44, %40
  %47 = phi i8 [ %41, %40 ], [ %36, %44 ]
  %48 = zext nneg i8 %47 to i16
  %49 = shl nuw nsw i16 %48, 2
  %50 = add nsw i16 %49, -64
  br label %51

51:                                               ; preds = %38, %42, %44, %46
  %52 = phi i16 [ %50, %46 ], [ 64, %44 ], [ 64, %42 ], [ 64, %38 ]
  %53 = and i16 %32, 1
  %54 = or disjoint i16 %22, %53
  %55 = or disjoint i16 %54, %52
  br label %56

56:                                               ; preds = %51, %29, %27, %24
  %57 = phi i16 [ %55, %51 ], [ 7168, %29 ], [ 7168, %27 ], [ 7168, %24 ]
  store volatile i16 %57, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %58 = add nuw nsw i8 %25, 1
  %59 = icmp eq i8 %58, 32
  br i1 %59, label %23, label %24, !llvm.loop !140
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_build(ptr noundef readonly captures(none) %0, i16 noundef range(i16 -2048, 2048) %1, i16 noundef range(i16 -2048, 2048) %2, ptr noundef %3, ptr noundef %4) unnamed_addr #7 {
  %6 = alloca %struct.HScrollW, align 1
  %7 = alloca %struct.HScrollW, align 1
  %8 = alloca i16, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #17
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #17
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #17
  store i16 0, ptr %8, align 1, !tbaa !2
  store ptr %3, ptr %6, align 1, !tbaa !141
  %9 = getelementptr inbounds nuw i8, ptr %6, i16 2
  store i8 0, ptr %9, align 1, !tbaa !143
  store ptr %4, ptr %7, align 1, !tbaa !141
  %10 = getelementptr inbounds nuw i8, ptr %7, i16 2
  store i8 0, ptr %10, align 1, !tbaa !143
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %12 = load i16, ptr %11, align 1, !tbaa !82
  %13 = getelementptr inbounds nuw i8, ptr %0, i16 26
  %14 = load i16, ptr %13, align 1, !tbaa !137
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %1, i16 noundef 8, i16 noundef %12, i16 noundef %14) #16
  %15 = getelementptr inbounds nuw i8, ptr %0, i16 17
  %16 = load i16, ptr %15, align 1, !tbaa !84
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %18 = load i16, ptr %17, align 1, !tbaa !83
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %2, i16 noundef %16, i16 noundef %18, i16 noundef 0) #16
  %19 = load i16, ptr %8, align 1, !tbaa !2
  call fastcc void @_title_blank(ptr noundef %6, ptr noundef %7, i16 noundef %19, i16 noundef 224) #16
  %20 = load ptr, ptr %6, align 1, !tbaa !141
  %21 = load i8, ptr %9, align 1, !tbaa !143
  %22 = zext i8 %21 to i16
  %23 = getelementptr inbounds nuw i8, ptr %20, i16 %22
  store i8 0, ptr %23, align 1, !tbaa !6
  %24 = load ptr, ptr %7, align 1, !tbaa !141
  %25 = load i8, ptr %10, align 1, !tbaa !143
  %26 = zext i8 %25 to i16
  %27 = getelementptr inbounds nuw i8, ptr %24, i16 %26
  store i8 0, ptr %27, align 1, !tbaa !6
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #17
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #17
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #17
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_glyph_band(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, ptr noundef nonnull captures(none) %2, i16 noundef range(i16 -2048, 2048) %3, i16 noundef %4, i16 noundef %5, i16 noundef %6) unnamed_addr #7 {
  %8 = add nsw i16 %3, -2
  %9 = add nsw i16 %4, %3
  %10 = add nsw i16 %9, 2
  %11 = load i16, ptr %2, align 1, !tbaa !2
  %12 = icmp slt i16 %8, %11
  br i1 %12, label %13, label %14

13:                                               ; preds = %7
  br label %14

14:                                               ; preds = %13, %7
  %15 = phi i16 [ %11, %13 ], [ %8, %7 ]
  %16 = icmp sgt i16 %9, 222
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  br label %18

18:                                               ; preds = %17, %14
  %19 = phi i16 [ 224, %17 ], [ %10, %14 ]
  %20 = icmp sgt i16 %19, %15
  br i1 %20, label %21, label %92

21:                                               ; preds = %18
  tail call fastcc void @_title_blank(ptr noundef %0, ptr noundef %1, i16 noundef %11, i16 noundef %15) #16
  %22 = sub nsw i16 %19, %15
  %23 = trunc i16 %22 to i8
  %24 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %25 = icmp eq i8 %23, 0
  br i1 %25, label %91, label %26

26:                                               ; preds = %21
  %27 = sub nsw i16 %5, %3
  %28 = and i16 %22, 255
  %29 = trunc i16 %27 to i8
  %30 = lshr i16 %27, 8
  %31 = trunc nuw i16 %30 to i8
  br label %32

32:                                               ; preds = %40, %26
  %33 = phi i16 [ %28, %26 ], [ %57, %40 ]
  %34 = load i8, ptr %24, align 1, !tbaa !143
  %35 = icmp ult i8 %34, 22
  br i1 %35, label %36, label %59

36:                                               ; preds = %32
  %37 = icmp ugt i16 %33, 127
  br i1 %37, label %40, label %38

38:                                               ; preds = %36
  %39 = trunc nuw nsw i16 %33 to i8
  br label %40

40:                                               ; preds = %38, %36
  %41 = phi i8 [ %39, %38 ], [ 127, %36 ]
  %42 = load ptr, ptr %0, align 1, !tbaa !141
  %43 = add nuw nsw i8 %34, 1
  store i8 %43, ptr %24, align 1, !tbaa !143
  %44 = zext nneg i8 %34 to i16
  %45 = getelementptr inbounds nuw i8, ptr %42, i16 %44
  store i8 %41, ptr %45, align 1, !tbaa !6
  %46 = load ptr, ptr %0, align 1, !tbaa !141
  %47 = load i8, ptr %24, align 1, !tbaa !143
  %48 = add i8 %47, 1
  store i8 %48, ptr %24, align 1, !tbaa !143
  %49 = zext i8 %47 to i16
  %50 = getelementptr inbounds nuw i8, ptr %46, i16 %49
  store i8 %29, ptr %50, align 1, !tbaa !6
  %51 = load ptr, ptr %0, align 1, !tbaa !141
  %52 = load i8, ptr %24, align 1, !tbaa !143
  %53 = add i8 %52, 1
  store i8 %53, ptr %24, align 1, !tbaa !143
  %54 = zext i8 %52 to i16
  %55 = getelementptr inbounds nuw i8, ptr %51, i16 %54
  store i8 %31, ptr %55, align 1, !tbaa !6
  %56 = zext nneg i8 %41 to i16
  %57 = sub i16 %33, %56
  %58 = icmp eq i16 %57, 0
  br i1 %58, label %59, label %32, !llvm.loop !144

59:                                               ; preds = %32, %40
  %60 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %61 = trunc i16 %6 to i8
  %62 = lshr i16 %6, 8
  %63 = trunc nuw i16 %62 to i8
  br label %64

64:                                               ; preds = %72, %59
  %65 = phi i16 [ %28, %59 ], [ %89, %72 ]
  %66 = load i8, ptr %60, align 1, !tbaa !143
  %67 = icmp ult i8 %66, 22
  br i1 %67, label %68, label %91

68:                                               ; preds = %64
  %69 = icmp ugt i16 %65, 127
  br i1 %69, label %72, label %70

70:                                               ; preds = %68
  %71 = trunc nuw nsw i16 %65 to i8
  br label %72

72:                                               ; preds = %70, %68
  %73 = phi i8 [ %71, %70 ], [ 127, %68 ]
  %74 = load ptr, ptr %1, align 1, !tbaa !141
  %75 = add nuw nsw i8 %66, 1
  store i8 %75, ptr %60, align 1, !tbaa !143
  %76 = zext nneg i8 %66 to i16
  %77 = getelementptr inbounds nuw i8, ptr %74, i16 %76
  store i8 %73, ptr %77, align 1, !tbaa !6
  %78 = load ptr, ptr %1, align 1, !tbaa !141
  %79 = load i8, ptr %60, align 1, !tbaa !143
  %80 = add i8 %79, 1
  store i8 %80, ptr %60, align 1, !tbaa !143
  %81 = zext i8 %79 to i16
  %82 = getelementptr inbounds nuw i8, ptr %78, i16 %81
  store i8 %61, ptr %82, align 1, !tbaa !6
  %83 = load ptr, ptr %1, align 1, !tbaa !141
  %84 = load i8, ptr %60, align 1, !tbaa !143
  %85 = add i8 %84, 1
  store i8 %85, ptr %60, align 1, !tbaa !143
  %86 = zext i8 %84 to i16
  %87 = getelementptr inbounds nuw i8, ptr %83, i16 %86
  store i8 %63, ptr %87, align 1, !tbaa !6
  %88 = zext nneg i8 %73 to i16
  %89 = sub i16 %65, %88
  %90 = icmp eq i16 %89, 0
  br i1 %90, label %91, label %64, !llvm.loop !144

91:                                               ; preds = %64, %72, %21
  store i16 %19, ptr %2, align 1, !tbaa !2
  br label %92

92:                                               ; preds = %18, %91
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_blank(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, i16 noundef %2, i16 noundef range(i16 -2050, 225) %3) unnamed_addr #7 {
  %5 = icmp sgt i16 %3, %2
  br i1 %5, label %6, label %83

6:                                                ; preds = %4
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 2
  br label %9

9:                                                ; preds = %6, %79
  %10 = phi i16 [ %2, %6 ], [ %81, %79 ]
  %11 = sub nsw i16 %3, %10
  %12 = icmp sgt i16 %11, 112
  br i1 %12, label %16, label %13

13:                                               ; preds = %9
  %14 = trunc i16 %11 to i8
  %15 = icmp eq i8 %14, 0
  br i1 %15, label %79, label %16

16:                                               ; preds = %9, %13
  %17 = phi i8 [ %14, %13 ], [ 112, %9 ]
  %18 = phi i16 [ %11, %13 ], [ 112, %9 ]
  %19 = sub nsw i16 144, %10
  %20 = zext i8 %17 to i16
  %21 = trunc i16 %19 to i8
  %22 = lshr i16 %19, 8
  %23 = trunc nuw i16 %22 to i8
  br label %24

24:                                               ; preds = %32, %16
  %25 = phi i16 [ %20, %16 ], [ %49, %32 ]
  %26 = load i8, ptr %7, align 1, !tbaa !143
  %27 = icmp ult i8 %26, 22
  br i1 %27, label %28, label %51

28:                                               ; preds = %24
  %29 = icmp ugt i16 %25, 127
  br i1 %29, label %32, label %30

30:                                               ; preds = %28
  %31 = trunc nuw nsw i16 %25 to i8
  br label %32

32:                                               ; preds = %30, %28
  %33 = phi i8 [ %31, %30 ], [ 127, %28 ]
  %34 = load ptr, ptr %0, align 1, !tbaa !141
  %35 = add nuw nsw i8 %26, 1
  store i8 %35, ptr %7, align 1, !tbaa !143
  %36 = zext nneg i8 %26 to i16
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 %36
  store i8 %33, ptr %37, align 1, !tbaa !6
  %38 = load ptr, ptr %0, align 1, !tbaa !141
  %39 = load i8, ptr %7, align 1, !tbaa !143
  %40 = add i8 %39, 1
  store i8 %40, ptr %7, align 1, !tbaa !143
  %41 = zext i8 %39 to i16
  %42 = getelementptr inbounds nuw i8, ptr %38, i16 %41
  store i8 %21, ptr %42, align 1, !tbaa !6
  %43 = load ptr, ptr %0, align 1, !tbaa !141
  %44 = load i8, ptr %7, align 1, !tbaa !143
  %45 = add i8 %44, 1
  store i8 %45, ptr %7, align 1, !tbaa !143
  %46 = zext i8 %44 to i16
  %47 = getelementptr inbounds nuw i8, ptr %43, i16 %46
  store i8 %23, ptr %47, align 1, !tbaa !6
  %48 = zext nneg i8 %33 to i16
  %49 = sub i16 %25, %48
  %50 = icmp eq i16 %49, 0
  br i1 %50, label %51, label %24, !llvm.loop !144

51:                                               ; preds = %24, %32
  br label %52

52:                                               ; preds = %51, %60
  %53 = phi i16 [ %77, %60 ], [ %20, %51 ]
  %54 = load i8, ptr %8, align 1, !tbaa !143
  %55 = icmp ult i8 %54, 22
  br i1 %55, label %56, label %79

56:                                               ; preds = %52
  %57 = icmp ugt i16 %53, 127
  br i1 %57, label %60, label %58

58:                                               ; preds = %56
  %59 = trunc nuw nsw i16 %53 to i8
  br label %60

60:                                               ; preds = %58, %56
  %61 = phi i8 [ %59, %58 ], [ 127, %56 ]
  %62 = load ptr, ptr %1, align 1, !tbaa !141
  %63 = add nuw nsw i8 %54, 1
  store i8 %63, ptr %8, align 1, !tbaa !143
  %64 = zext nneg i8 %54 to i16
  %65 = getelementptr inbounds nuw i8, ptr %62, i16 %64
  store i8 %61, ptr %65, align 1, !tbaa !6
  %66 = load ptr, ptr %1, align 1, !tbaa !141
  %67 = load i8, ptr %8, align 1, !tbaa !143
  %68 = add i8 %67, 1
  store i8 %68, ptr %8, align 1, !tbaa !143
  %69 = zext i8 %67 to i16
  %70 = getelementptr inbounds nuw i8, ptr %66, i16 %69
  store i8 0, ptr %70, align 1, !tbaa !6
  %71 = load ptr, ptr %1, align 1, !tbaa !141
  %72 = load i8, ptr %8, align 1, !tbaa !143
  %73 = add i8 %72, 1
  store i8 %73, ptr %8, align 1, !tbaa !143
  %74 = zext i8 %72 to i16
  %75 = getelementptr inbounds nuw i8, ptr %71, i16 %74
  store i8 0, ptr %75, align 1, !tbaa !6
  %76 = zext nneg i8 %61 to i16
  %77 = sub i16 %53, %76
  %78 = icmp eq i16 %77, 0
  br i1 %78, label %79, label %52, !llvm.loop !144

79:                                               ; preds = %52, %60, %13
  %80 = phi i16 [ %11, %13 ], [ %18, %60 ], [ %18, %52 ]
  %81 = add nsw i16 %80, %10
  %82 = icmp sgt i16 %3, %81
  br i1 %82, label %9, label %83, !llvm.loop !145

83:                                               ; preds = %79, %4
  ret void
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #8

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal fastcc void @nbody_force_pair(ptr noundef readonly captures(none) %0, ptr noundef readonly captures(none) %1, ptr noundef nonnull captures(none) %2, ptr noundef nonnull captures(none) %3, ptr noundef nonnull captures(none) %4, ptr noundef nonnull captures(none) %5) unnamed_addr #9 {
  %7 = load i16, ptr %1, align 1, !tbaa !54
  %8 = load i16, ptr %0, align 1, !tbaa !54
  %9 = sub nsw i16 %7, %8
  %10 = ashr i16 %9, 8
  %11 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %12 = load i16, ptr %11, align 1, !tbaa !56
  %13 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %14 = load i16, ptr %13, align 1, !tbaa !56
  %15 = sub nsw i16 %12, %14
  %16 = ashr i16 %15, 8
  %17 = sext i16 %10 to i32
  %18 = mul nsw i32 %17, %17
  %19 = sext i16 %16 to i32
  %20 = mul nsw i32 %19, %19
  %21 = add nuw nsw i32 %18, 16
  %22 = add nuw nsw i32 %21, %20
  %23 = getelementptr inbounds nuw i8, ptr %1, i16 8
  %24 = load i8, ptr %23, align 1, !tbaa !59
  %25 = zext i8 %24 to i32
  %26 = shl nuw nsw i32 %25, 6
  %27 = udiv i32 %26, %22
  %28 = getelementptr inbounds nuw i8, ptr %0, i16 8
  %29 = load i8, ptr %28, align 1, !tbaa !59
  %30 = zext i8 %29 to i32
  %31 = shl nuw nsw i32 %30, 6
  %32 = udiv i32 %31, %22
  %33 = mul nsw i32 %27, %17
  %34 = load i32, ptr %2, align 1, !tbaa !116
  %35 = add nsw i32 %34, %33
  store i32 %35, ptr %2, align 1, !tbaa !116
  %36 = mul nsw i32 %27, %19
  %37 = load i32, ptr %3, align 1, !tbaa !116
  %38 = add nsw i32 %37, %36
  store i32 %38, ptr %3, align 1, !tbaa !116
  %39 = mul nsw i32 %32, %17
  %40 = load i32, ptr %4, align 1, !tbaa !116
  %41 = sub nsw i32 %40, %39
  store i32 %41, ptr %4, align 1, !tbaa !116
  %42 = mul nsw i32 %32, %19
  %43 = load i32, ptr %5, align 1, !tbaa !116
  %44 = sub nsw i32 %43, %42
  store i32 %44, ptr %5, align 1, !tbaa !116
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal fastcc void @fmt_u16(i16 noundef %0, ptr noundef nonnull writeonly captures(none) %1) unnamed_addr #10 {
  %3 = icmp ult i16 %0, 10000
  br i1 %3, label %9, label %4

4:                                                ; preds = %2
  %5 = udiv i16 %0, 10000
  %6 = trunc nuw nsw i16 %5 to i8
  %7 = or disjoint i8 %6, 48
  store i8 %7, ptr %1, align 1, !tbaa !6
  %8 = urem i16 %0, 10000
  br label %11

9:                                                ; preds = %2
  %10 = icmp samesign ugt i16 %0, 999
  br i1 %10, label %11, label %22

11:                                               ; preds = %9, %4
  %12 = phi i16 [ 0, %9 ], [ 1, %4 ]
  %13 = phi i8 [ 1, %9 ], [ 2, %4 ]
  %14 = phi i16 [ %0, %9 ], [ %8, %4 ]
  %15 = udiv i16 %14, 1000
  %16 = trunc nuw nsw i16 %15 to i8
  %17 = add nuw nsw i8 %16, 48
  %18 = getelementptr inbounds nuw i8, ptr %1, i16 %12
  store i8 %17, ptr %18, align 1, !tbaa !6
  %19 = urem i16 %14, 1000
  %20 = zext nneg i8 %13 to i16
  %21 = add nuw nsw i8 %13, 1
  br label %24

22:                                               ; preds = %9
  %23 = icmp samesign ugt i16 %0, 99
  br i1 %23, label %24, label %36

24:                                               ; preds = %22, %11
  %25 = phi i16 [ 0, %22 ], [ %20, %11 ]
  %26 = phi i8 [ 1, %22 ], [ %21, %11 ]
  %27 = phi i16 [ %0, %22 ], [ %19, %11 ]
  %28 = udiv i16 %27, 100
  %29 = trunc nuw nsw i16 %28 to i8
  %30 = or disjoint i8 %29, 48
  %31 = getelementptr inbounds nuw i8, ptr %1, i16 %25
  store i8 %30, ptr %31, align 1, !tbaa !6
  %32 = urem i16 %27, 100
  %33 = zext nneg i8 %26 to i16
  %34 = trunc nuw nsw i16 %32 to i8
  %35 = add nuw nsw i8 %26, 1
  br label %39

36:                                               ; preds = %22
  %37 = icmp samesign ugt i16 %0, 9
  %38 = trunc nuw nsw i16 %0 to i8
  br i1 %37, label %39, label %47

39:                                               ; preds = %24, %36
  %40 = phi i16 [ 0, %36 ], [ %33, %24 ]
  %41 = phi i8 [ 1, %36 ], [ %35, %24 ]
  %42 = phi i8 [ %38, %36 ], [ %34, %24 ]
  %43 = udiv i8 %42, 10
  %44 = or disjoint i8 %43, 48
  %45 = getelementptr inbounds nuw i8, ptr %1, i16 %40
  store i8 %44, ptr %45, align 1, !tbaa !6
  %46 = urem i8 %42, 10
  br label %47

47:                                               ; preds = %39, %36
  %48 = phi i8 [ %46, %39 ], [ %38, %36 ]
  %49 = phi i8 [ %41, %39 ], [ 0, %36 ]
  %50 = or i8 %48, 48
  %51 = zext nneg i8 %49 to i16
  %52 = getelementptr inbounds nuw i8, ptr %1, i16 %51
  store i8 %50, ptr %52, align 1, !tbaa !6
  %53 = sext i8 %49 to i16
  %54 = getelementptr inbounds nuw i8, ptr %1, i16 %53
  %55 = getelementptr inbounds nuw i8, ptr %54, i16 1
  store i8 0, ptr %55, align 1, !tbaa !6
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @upq_flush() unnamed_addr #11 {
  %1 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 177), align 1, !tbaa !146
  %2 = zext i8 %1 to i16
  %3 = shl nuw nsw i16 %2, 4
  %4 = add nuw nsw i16 %3, 17152
  %5 = inttoptr i16 %4 to ptr
  %6 = shl nuw i16 1, %2
  %7 = trunc i16 %6 to i8
  %8 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %108, label %10

10:                                               ; preds = %0
  %11 = getelementptr inbounds nuw i8, ptr %5, i16 1
  %12 = getelementptr inbounds nuw i8, ptr %5, i16 2
  %13 = getelementptr inbounds nuw i8, ptr %5, i16 3
  %14 = getelementptr inbounds nuw i8, ptr %5, i16 4
  %15 = getelementptr inbounds nuw i8, ptr %5, i16 5
  %16 = getelementptr inbounds nuw i8, ptr %5, i16 6
  br label %17

17:                                               ; preds = %10, %86
  %18 = phi i8 [ %8, %10 ], [ %89, %86 ]
  %19 = phi i16 [ 0, %10 ], [ %87, %86 ]
  %20 = phi i8 [ 0, %10 ], [ %88, %86 ]
  %21 = zext i8 %20 to i16
  %22 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %21
  %23 = getelementptr inbounds nuw i8, ptr %22, i16 10
  %24 = load i8, ptr %23, align 1, !tbaa !45
  switch i8 %24, label %44 [
    i8 3, label %25
    i8 4, label %34
  ]

25:                                               ; preds = %17
  %26 = load i16, ptr %22, align 1, !tbaa !47
  %27 = inttoptr i16 %26 to ptr
  %28 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %29 = load i16, ptr %28, align 1, !tbaa !51
  %30 = trunc i16 %29 to i8
  store volatile i8 %30, ptr %27, align 1, !tbaa !6
  %31 = load i16, ptr %28, align 1, !tbaa !51
  %32 = lshr i16 %31, 8
  %33 = trunc nuw i16 %32 to i8
  store volatile i8 %33, ptr %27, align 1, !tbaa !6
  br label %86

34:                                               ; preds = %17
  %35 = load i16, ptr %22, align 1, !tbaa !47
  %36 = inttoptr i16 %35 to ptr
  %37 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %38 = load i16, ptr %37, align 1, !tbaa !51
  %39 = trunc i16 %38 to i8
  store volatile i8 %39, ptr %36, align 1, !tbaa !6
  %40 = load i16, ptr %37, align 1, !tbaa !51
  %41 = lshr i16 %40, 8
  %42 = trunc nuw i16 %41 to i8
  %43 = getelementptr inbounds nuw i8, ptr %36, i16 1
  store volatile i8 %42, ptr %43, align 1, !tbaa !6
  br label %86

44:                                               ; preds = %17
  %45 = icmp eq i16 %19, 0
  br i1 %45, label %51, label %46

46:                                               ; preds = %44
  %47 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %48 = load i16, ptr %47, align 1, !tbaa !53
  %49 = add i16 %48, %19
  %50 = icmp ugt i16 %49, 5100
  br i1 %50, label %91, label %51

51:                                               ; preds = %46, %44
  switch i8 %24, label %59 [
    i8 0, label %52
    i8 1, label %56
  ]

52:                                               ; preds = %51
  %53 = getelementptr inbounds nuw i8, ptr %22, i16 9
  %54 = load i8, ptr %53, align 1, !tbaa !48
  store volatile i8 %54, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  %55 = load i16, ptr %22, align 1, !tbaa !47
  store volatile i16 %55, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %65

56:                                               ; preds = %51
  %57 = load i16, ptr %22, align 1, !tbaa !47
  %58 = trunc i16 %57 to i8
  store volatile i8 %58, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  br label %65

59:                                               ; preds = %51
  %60 = load i16, ptr %22, align 1, !tbaa !47
  %61 = trunc i16 %60 to i8
  store volatile i8 %61, ptr inttoptr (i16 8450 to ptr), align 2, !tbaa !6
  %62 = load i16, ptr %22, align 1, !tbaa !47
  %63 = lshr i16 %62, 8
  %64 = trunc nuw i16 %63 to i8
  store volatile i8 %64, ptr inttoptr (i16 8451 to ptr), align 1, !tbaa !6
  br label %65

65:                                               ; preds = %56, %59, %52
  %66 = getelementptr inbounds nuw i8, ptr %22, i16 8
  %67 = load i8, ptr %66, align 1, !tbaa !50
  store volatile i8 %67, ptr %5, align 16, !tbaa !6
  %68 = getelementptr inbounds nuw i8, ptr %22, i16 7
  %69 = load i8, ptr %68, align 1, !tbaa !49
  store volatile i8 %69, ptr %11, align 1, !tbaa !6
  %70 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %71 = load i16, ptr %70, align 1, !tbaa !51
  %72 = trunc i16 %71 to i8
  store volatile i8 %72, ptr %12, align 2, !tbaa !6
  %73 = load i16, ptr %70, align 1, !tbaa !51
  %74 = lshr i16 %73, 8
  %75 = trunc nuw i16 %74 to i8
  store volatile i8 %75, ptr %13, align 1, !tbaa !6
  %76 = getelementptr inbounds nuw i8, ptr %22, i16 6
  %77 = load i8, ptr %76, align 1, !tbaa !52
  store volatile i8 %77, ptr %14, align 4, !tbaa !6
  %78 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %79 = load i16, ptr %78, align 1, !tbaa !53
  %80 = trunc i16 %79 to i8
  store volatile i8 %80, ptr %15, align 1, !tbaa !6
  %81 = load i16, ptr %78, align 1, !tbaa !53
  %82 = lshr i16 %81, 8
  %83 = trunc nuw i16 %82 to i8
  store volatile i8 %83, ptr %16, align 2, !tbaa !6
  store volatile i8 %7, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !6
  %84 = load i16, ptr %78, align 1, !tbaa !53
  %85 = add i16 %84, %19
  br label %86

86:                                               ; preds = %65, %34, %25
  %87 = phi i16 [ %19, %25 ], [ %19, %34 ], [ %85, %65 ]
  %88 = add nuw i8 %20, 1
  %89 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %90 = icmp ult i8 %88, %89
  br i1 %90, label %17, label %91

91:                                               ; preds = %86, %46
  %92 = phi i8 [ %89, %86 ], [ %18, %46 ]
  %93 = phi i8 [ %88, %86 ], [ %20, %46 ]
  %94 = icmp ult i8 %93, %92
  br i1 %94, label %95, label %108

95:                                               ; preds = %91
  %96 = icmp eq i8 %93, 0
  br i1 %96, label %110, label %97

97:                                               ; preds = %95, %97
  %98 = phi i8 [ %101, %97 ], [ 0, %95 ]
  %99 = phi i8 [ %104, %97 ], [ %93, %95 ]
  %100 = zext i8 %99 to i16
  %101 = add i8 %98, 1
  %102 = zext i8 %98 to i16
  %103 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %102
  %104 = add nuw i8 %99, 1
  %105 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %100
  tail call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(11) %103, ptr noundef nonnull align 1 dereferenceable(11) %105, i16 11, i1 false), !tbaa.struct !147
  %106 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  %107 = icmp ult i8 %104, %106
  br i1 %107, label %97, label %108, !llvm.loop !148

108:                                              ; preds = %97, %91, %0
  %109 = phi i8 [ 0, %91 ], [ 0, %0 ], [ %101, %97 ]
  store i8 %109, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !44
  br label %110

110:                                              ; preds = %108, %95
  ret void
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #13

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #14

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree noinline norecurse nosync nounwind optsize memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #3 = { nofree noinline norecurse nosync nounwind optsize memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #4 = { nofree norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #5 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #6 = { nofree norecurse nosync nounwind optsize memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #7 = { nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #8 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #9 = { mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #10 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #11 = { nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #12 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #13 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #14 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #15 = { nounwind optsize }
attributes #16 = { optsize }
attributes #17 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!10, !4, i64 194}
!10 = !{!"", !11, i64 0, !12, i64 178, !13, i64 182, !4, i64 191, !4, i64 192, !4, i64 193, !4, i64 194, !4, i64 195}
!11 = !{!"", !4, i64 0, !4, i64 176, !4, i64 177}
!12 = !{!"", !3, i64 0, !3, i64 2}
!13 = !{!"", !4, i64 0, !4, i64 8}
!14 = !{!10, !4, i64 195}
!15 = !{!16, !18, i64 0}
!16 = !{!"", !17, i64 0, !4, i64 3, !3, i64 4099, !3, i64 4101, !3, i64 4103, !3, i64 4105, !4, i64 4107, !4, i64 4108}
!17 = !{!"Drawable", !18, i64 0, !4, i64 2}
!18 = !{!"any pointer", !4, i64 0}
!19 = !{!16, !4, i64 2}
!20 = !{!16, !3, i64 4103}
!21 = !{!16, !3, i64 4105}
!22 = !{!16, !4, i64 4107}
!23 = !{!16, !4, i64 4108}
!24 = !{!16, !3, i64 4099}
!25 = !{!16, !3, i64 4101}
!26 = !{!27, !18, i64 0}
!27 = !{!"", !17, i64 0, !3, i64 3, !4, i64 5, !4, i64 7, !4, i64 135}
!28 = !{!27, !4, i64 2}
!29 = !{!27, !3, i64 3}
!30 = distinct !{!30, !8}
!31 = !{!27, !4, i64 135}
!32 = !{!10, !4, i64 192}
!33 = !{!10, !4, i64 193}
!34 = !{!13, !4, i64 8}
!35 = !{!36, !36, i64 0}
!36 = !{!"p1 _ZTS8Drawable", !18, i64 0}
!37 = distinct !{null, null}
!38 = !{!10, !4, i64 191}
!39 = !{!17, !4, i64 2}
!40 = !{!17, !18, i64 0}
!41 = !{!42, !18, i64 0}
!42 = !{!"", !18, i64 0, !18, i64 2}
!43 = distinct !{null, null, null}
!44 = !{!11, !4, i64 176}
!45 = !{!46, !4, i64 10}
!46 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !4, i64 6, !4, i64 7, !4, i64 8, !4, i64 9, !4, i64 10}
!47 = !{!46, !3, i64 0}
!48 = !{!46, !4, i64 9}
!49 = !{!46, !4, i64 7}
!50 = !{!46, !4, i64 8}
!51 = !{!46, !3, i64 2}
!52 = !{!46, !4, i64 6}
!53 = !{!46, !3, i64 4}
!54 = !{!55, !3, i64 0}
!55 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !3, i64 6, !4, i64 8}
!56 = !{!55, !3, i64 2}
!57 = !{!55, !3, i64 4}
!58 = !{!55, !3, i64 6}
!59 = !{!55, !4, i64 8}
!60 = distinct !{!60, !8}
!61 = !{!62, !4, i64 128}
!62 = !{!"", !4, i64 0, !4, i64 64, !4, i64 128}
!63 = distinct !{!63, !8}
!64 = !{!65, !3, i64 4855}
!65 = !{!"", !10, i64 0, !16, i64 196, !27, i64 4305, !4, i64 4441, !4, i64 4468, !3, i64 4855, !4, i64 4857, !4, i64 4858, !4, i64 4859, !4, i64 4860}
!66 = !{!65, !4, i64 4857}
!67 = !{!65, !4, i64 4858}
!68 = !{!65, !4, i64 4859}
!69 = !{!65, !4, i64 4860}
!70 = distinct !{!70, !8}
!71 = !{!72, !18, i64 0}
!72 = !{!"", !17, i64 0, !73, i64 3, !73, i64 5, !73, i64 7, !73, i64 9, !4, i64 11, !4, i64 12, !3, i64 13, !3, i64 15, !3, i64 17, !3, i64 19, !3, i64 21, !3, i64 23, !4, i64 25, !3, i64 26, !4, i64 28, !4, i64 29, !4, i64 30, !4, i64 31, !4, i64 32, !4, i64 33, !3, i64 34, !3, i64 36, !74, i64 38, !74, i64 89}
!73 = !{!"p1 omnipotent char", !18, i64 0}
!74 = !{!"", !4, i64 0, !4, i64 50}
!75 = !{!72, !4, i64 2}
!76 = !{!72, !73, i64 3}
!77 = !{!72, !73, i64 5}
!78 = !{!72, !73, i64 7}
!79 = !{!72, !4, i64 11}
!80 = !{!72, !73, i64 9}
!81 = !{!72, !4, i64 12}
!82 = !{!72, !3, i64 13}
!83 = !{!72, !3, i64 15}
!84 = !{!72, !3, i64 17}
!85 = !{!72, !4, i64 28}
!86 = !{!72, !4, i64 29}
!87 = !{!72, !4, i64 31}
!88 = !{!72, !4, i64 32}
!89 = !{!72, !4, i64 30}
!90 = !{!72, !4, i64 25}
!91 = !{!72, !3, i64 34}
!92 = !{!72, !3, i64 36}
!93 = !{!72, !4, i64 33}
!94 = !{!42, !18, i64 2}
!95 = distinct !{null, null, null, null, null}
!96 = distinct !{!96, !8}
!97 = distinct !{!97, !8}
!98 = distinct !{!98, !8}
!99 = distinct !{null, null, null, null}
!100 = distinct !{!100, !8}
!101 = distinct !{null, null, null, null, null}
!102 = distinct !{!102, !8}
!103 = distinct !{!103, !8}
!104 = distinct !{null, null, null, null}
!105 = !{!72, !3, i64 19}
!106 = distinct !{null, null, null, null, null}
!107 = distinct !{!107, !8}
!108 = distinct !{!108, !8}
!109 = distinct !{!109, !8}
!110 = distinct !{!110, !8}
!111 = distinct !{null, null, null}
!112 = distinct !{!112, !8}
!113 = distinct !{!113, !8}
!114 = distinct !{!114, !8}
!115 = distinct !{!115, !8}
!116 = !{!117, !117, i64 0}
!117 = !{!"long", !4, i64 0}
!118 = distinct !{!118, !8}
!119 = distinct !{!119, !8}
!120 = distinct !{!120, !8}
!121 = distinct !{!121, !8}
!122 = distinct !{!122, !8}
!123 = distinct !{!123, !8}
!124 = distinct !{!124, !8}
!125 = distinct !{!125, !8}
!126 = distinct !{!126, !8}
!127 = distinct !{!127, !8}
!128 = distinct !{!128, !8}
!129 = distinct !{!129, !8}
!130 = distinct !{!130, !8}
!131 = distinct !{!131, !8}
!132 = distinct !{!132, !8}
!133 = distinct !{!133, !8}
!134 = !{!72, !3, i64 21}
!135 = !{!72, !3, i64 23}
!136 = distinct !{!136, !8}
!137 = !{!72, !3, i64 26}
!138 = !{!74, !4, i64 50}
!139 = distinct !{!139, !8}
!140 = distinct !{!140, !8}
!141 = !{!142, !18, i64 0}
!142 = !{!"", !18, i64 0, !4, i64 2}
!143 = !{!142, !4, i64 2}
!144 = distinct !{!144, !8}
!145 = distinct !{!145, !8}
!146 = !{!11, !4, i64 177}
!147 = !{i64 0, i64 2, !2, i64 2, i64 2, !2, i64 4, i64 2, !2, i64 6, i64 1, !6, i64 7, i64 1, !6, i64 8, i64 1, !6, i64 9, i64 1, !6, i64 10, i64 1, !6}
!148 = distinct !{!148, !8}
