; ModuleID = '/work/examples/snes/bigbyval.c'
source_filename = "/work/examples/snes/bigbyval.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.App = type { %struct.Display, %struct.BitmapCanvas, %struct.TextLayer, i16 }
%struct.Display = type { %struct.UploadQueue, %struct.VramAlloc, %struct.Scene, i8, i8, i8, i8, i8 }
%struct.UploadQueue = type { [16 x %struct.UpqJob], i8, i8 }
%struct.UpqJob = type { i16, i16, i16, i8, i8, i8, i8, i8 }
%struct.VramAlloc = type { i16, i16 }
%struct.Scene = type { [4 x ptr], i8 }
%struct.BitmapCanvas = type { %struct.Drawable, [4096 x i8], i16, i16, i16, i16, i8, i8 }
%struct.Drawable = type { ptr, i8 }
%struct.TextLayer = type { %struct.Drawable, i16, [2 x i8], [64 x i16], i8 }
%struct.TitleLayer = type { %struct.Drawable, ptr, ptr, ptr, ptr, i8, i8, i16, i16, i16, i16, i16, i16, i8, i16, i8, i8, i8, i8, i8, i8, i16, i16, %struct.HScrollDB, %struct.HScrollDB }
%struct.HScrollDB = type { [2 x %struct.HScrollN], i8 }
%struct.HScrollN = type { [25 x i8] }
%struct.DrawableVT = type { ptr, ptr }
%struct.BvVert = type { i16, i16, i16, i16 }
%struct.BvMat = type { [9 x i16] }
%struct.HScrollW = type { ptr, i8 }

@main.a = internal global %struct.App zeroinitializer, align 1
@bg3_pal = internal constant [4 x i16] [i16 0, i16 20838, i16 23340, i16 12095], align 1
@.str = private unnamed_addr constant [27 x i8] c"BIGBYVAL  144-BIT BY VALUE\00", align 1
@main.title = internal global %struct.TitleLayer zeroinitializer, align 1
@.str.1 = private unnamed_addr constant [17 x i8] c"144-BIT BY VALUE\00", align 1
@.str.2 = private unnamed_addr constant [9 x i8] c"BIGBYVAL\00", align 1
@corpus_result = dso_local global i16 0, align 1
@bz_stage = internal unnamed_addr global i8 0, align 1
@bz_phase = internal unnamed_addr global i16 0, align 1
@hexd = internal unnamed_addr constant [17 x i8] c"0123456789ABCDEF\00", align 1
@CANVAS_VT = internal constant %struct.DrawableVT { ptr @_canvas_reserve, ptr @_canvas_emit }, align 1
@TEXT_VT = internal constant %struct.DrawableVT { ptr @_text_reserve, ptr @_text_emit }, align 1
@FONT8 = internal unnamed_addr constant [512 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 32, i16 0, i16 80, i16 80, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 80, i16 80, i16 248, i16 80, i16 248, i16 80, i16 80, i16 0, i16 32, i16 120, i16 160, i16 112, i16 40, i16 240, i16 32, i16 0, i16 196, i16 200, i16 16, i16 32, i16 64, i16 152, i16 12, i16 0, i16 96, i16 144, i16 160, i16 64, i16 168, i16 144, i16 104, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 16, i16 32, i16 64, i16 64, i16 64, i16 32, i16 16, i16 0, i16 64, i16 32, i16 16, i16 16, i16 16, i16 32, i16 64, i16 0, i16 0, i16 32, i16 168, i16 112, i16 168, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 248, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 64, i16 0, i16 0, i16 0, i16 248, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 0, i16 8, i16 8, i16 16, i16 32, i16 64, i16 128, i16 128, i16 0, i16 112, i16 136, i16 152, i16 168, i16 200, i16 136, i16 112, i16 0, i16 32, i16 96, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 64, i16 248, i16 0, i16 112, i16 136, i16 8, i16 48, i16 8, i16 136, i16 112, i16 0, i16 16, i16 48, i16 80, i16 144, i16 248, i16 16, i16 16, i16 0, i16 248, i16 128, i16 240, i16 8, i16 8, i16 136, i16 112, i16 0, i16 112, i16 136, i16 128, i16 240, i16 136, i16 136, i16 112, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 64, i16 64, i16 0, i16 112, i16 136, i16 136, i16 112, i16 136, i16 136, i16 112, i16 0, i16 112, i16 136, i16 136, i16 120, i16 8, i16 136, i16 112, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 64, i16 0, i16 16, i16 32, i16 64, i16 128, i16 64, i16 32, i16 16, i16 0, i16 0, i16 0, i16 248, i16 0, i16 248, i16 0, i16 0, i16 0, i16 128, i16 64, i16 32, i16 16, i16 32, i16 64, i16 128, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 0, i16 32, i16 0, i16 112, i16 136, i16 184, i16 168, i16 184, i16 128, i16 112, i16 0, i16 112, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 240, i16 136, i16 136, i16 240, i16 136, i16 136, i16 240, i16 0, i16 112, i16 136, i16 128, i16 128, i16 128, i16 136, i16 112, i16 0, i16 224, i16 144, i16 136, i16 136, i16 136, i16 144, i16 224, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 248, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 128, i16 176, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 112, i16 32, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 56, i16 16, i16 16, i16 16, i16 144, i16 144, i16 96, i16 0, i16 136, i16 144, i16 160, i16 192, i16 160, i16 144, i16 136, i16 0, i16 128, i16 128, i16 128, i16 128, i16 128, i16 128, i16 248, i16 0, i16 136, i16 216, i16 168, i16 136, i16 136, i16 136, i16 136, i16 0, i16 136, i16 200, i16 168, i16 152, i16 136, i16 136, i16 136, i16 0, i16 112, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 240, i16 136, i16 136, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 136, i16 136, i16 168, i16 144, i16 104, i16 0, i16 240, i16 136, i16 136, i16 240, i16 160, i16 144, i16 136, i16 0, i16 112, i16 136, i16 128, i16 112, i16 8, i16 136, i16 112, i16 0, i16 248, i16 32, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 80, i16 32, i16 0, i16 136, i16 136, i16 136, i16 168, i16 168, i16 216, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 80, i16 136, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 32, i16 32, i16 32, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 128, i16 248, i16 0, i16 48, i16 32, i16 32, i16 32, i16 32, i16 32, i16 48, i16 0, i16 128, i16 128, i16 64, i16 32, i16 16, i16 8, i16 8, i16 0, i16 48, i16 16, i16 16, i16 16, i16 16, i16 16, i16 48, i16 0, i16 32, i16 80, i16 136, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248], align 1
@TITLE_VT = internal constant %struct.DrawableVT { ptr @_title_reserve, ptr @_title_emit }, align 1
@FONT16 = internal unnamed_addr constant [2048 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 192, i16 192, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 768, i16 768, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 -4096, i16 -4096, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3840, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 3312, i16 15360, i16 15360, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 28, i16 28, i16 796, i16 127, i16 127, i16 796, i16 796, i16 127, i16 112, i16 112, i16 3184, i16 252, i16 252, i16 -28816, i16 -28816, i16 252, i16 127, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 0, i16 0, i16 252, i16 -28816, i16 -28816, i16 3184, i16 7168, i16 7168, i16 0, i16 0, i16 3, i16 63, i16 123, i16 1147, i16 63, i16 4111, i16 3075, i16 123, i16 192, i16 248, i16 8414, i16 16064, i16 2040, i16 248, i16 8414, i16 8414, i16 63, i16 7171, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 2040, i16 14272, i16 -512, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3585, i16 3, i16 7, i16 28, i16 56, i16 1904, i16 3808, i16 7392, i16 14528, i16 14464, i16 28672, i16 14, i16 284, i16 824, i16 1792, i16 3584, i16 0, i16 0, i16 0, i16 -8162, i16 -16354, i16 -32482, i16 286, i16 1792, i16 1792, i16 0, i16 0, i16 15, i16 31, i16 828, i16 828, i16 573, i16 31, i16 31, i16 63, i16 192, i16 224, i16 240, i16 2288, i16 7392, i16 15488, i16 30720, i16 -32648, i16 382, i16 3060, i16 3825, i16 1275, i16 127, i16 63, i16 7936, i16 3840, i16 248, i16 3824, i16 7904, i16 7392, i16 4332, i16 12492, i16 -1280, i16 -3328, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 7, i16 15, i16 15, i16 15, i16 15, i16 15, i16 240, i16 192, i16 15488, i16 -4096, i16 -8192, i16 -16384, i16 -16384, i16 -16384, i16 15, i16 7, i16 3, i16 256, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 16512, i16 192, i16 240, i16 -4096, i16 15360, i16 0, i16 0, i16 15, i16 3, i16 513, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 224, i16 240, i16 2288, i16 3312, i16 3312, i16 3312, i16 0, i16 1, i16 3, i16 15, i16 0, i16 768, i16 0, i16 0, i16 3312, i16 7392, i16 15552, i16 30720, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 51, i16 31, i16 15, i16 1027, i16 0, i16 0, i16 192, i16 192, i16 12492, i16 252, i16 1016, i16 16320, i16 15, i16 31, i16 51, i16 1027, i16 3072, i16 0, i16 0, i16 0, i16 1784, i16 252, i16 13004, i16 16320, i16 -3328, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 3, i16 63, i16 63, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 248, i16 248, i16 63, i16 3075, i16 3075, i16 3, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 16064, i16 16064, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 286, i16 828, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 28800, i16 -4096, i16 -8192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 -512, i16 -512, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7360, i16 14464, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7168, i16 14336, i16 28672, i16 -8192, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 828, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 15, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 1, i16 3, i16 15, i16 15, i16 513, i16 513, i16 1, i16 1, i16 240, i16 240, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 1, i16 1, i16 1, i16 1, i16 1, i16 1, i16 0, i16 0, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 31744, i16 31744, i16 15, i16 31, i16 318, i16 828, i16 3840, i16 3840, i16 3, i16 15, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 63, i16 510, i16 4080, i16 31, i16 318, i16 318, i16 318, i16 63, i16 63, i16 3840, i16 3840, i16 32640, i16 -1024, i16 -8192, i16 -32768, i16 255, i16 255, i16 -256, i16 -256, i16 15, i16 63, i16 824, i16 3840, i16 2055, i16 7, i16 256, i16 256, i16 252, i16 254, i16 -8161, i16 -4081, i16 510, i16 1020, i16 -7906, i16 -4081, i16 0, i16 0, i16 56, i16 60, i16 63, i16 31, i16 3840, i16 1792, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 15, i16 286, i16 62, i16 126, i16 510, i16 510, i16 8670, i16 24990, i16 -7906, i16 -7906, i16 828, i16 828, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 -16098, i16 -32482, i16 255, i16 255, i16 -7906, i16 -7906, i16 1792, i16 1792, i16 31, i16 63, i16 828, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 254, i16 254, i16 -256, i16 -256, i16 252, i16 254, i16 -8161, i16 -4081, i16 0, i16 0, i16 60, i16 62, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 63, i16 63, i16 318, i16 828, i16 254, i16 255, i16 -2041, i16 -256, i16 508, i16 254, i16 -4081, i16 -2041, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 -32761, i16 7, i16 7, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 31, i16 318, i16 892, i16 0, i16 1, i16 3, i16 7, i16 7, i16 7, i16 256, i16 256, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 28800, i16 -8192, i16 -8192, i16 15, i16 31, i16 828, i16 828, i16 828, i16 31, i16 15, i16 796, i16 252, i16 254, i16 -4081, i16 -4081, i16 15, i16 510, i16 1020, i16 -3826, i16 828, i16 828, i16 828, i16 828, i16 31, i16 15, i16 1792, i16 768, i16 -4081, i16 15, i16 15, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 318, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 31, i16 31, i16 15, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 270, i16 796, i16 824, i16 1792, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 15, i16 60, i16 828, i16 0, i16 0, i16 60, i16 240, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 15360, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 60, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 60, i16 0, i16 3, i16 15, i16 60, i16 768, i16 3840, i16 0, i16 0, i16 4080, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 31, i16 63, i16 828, i16 3840, i16 3840, i16 7, i16 7, i16 7, i16 240, i16 248, i16 -32644, i16 -32132, i16 2040, i16 4080, i16 16064, i16 31872, i16 256, i16 256, i16 7, i16 7, i16 7, i16 256, i16 256, i16 0, i16 -4096, i16 -8192, i16 128, i16 128, i16 24704, i16 -8192, i16 -8192, i16 0, i16 31, i16 63, i16 828, i16 573, i16 573, i16 573, i16 573, i16 573, i16 248, i16 252, i16 -15812, i16 4590, i16 494, i16 4590, i16 1020, i16 1016, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 0, i16 0, i16 0, i16 32512, i16 764, i16 248, i16 -256, i16 -512, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 892, i16 1020, i16 1020, i16 255, i16 255, i16 224, i16 240, i16 -32648, i16 -16324, i16 -32196, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -28928, i16 1792, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 0, i16 0, i16 28, i16 60, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -8164, i16 -3572, i16 -30976, i16 768, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 8988, i16 8988, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 60, i16 60, i16 828, i16 828, i16 828, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 255, i16 255, i16 16128, i16 16128, i16 12480, i16 12480, i16 12480, i16 12480, i16 252, i16 252, i16 -256, i16 -256, i16 63, i16 63, i16 3075, i16 3075, i16 3, i16 3, i16 51, i16 51, i16 252, i16 252, i16 4080, i16 4080, i16 3312, i16 3312, i16 3312, i16 3312, i16 3123, i16 3123, i16 63, i16 63, i16 31, i16 15, i16 1792, i16 768, i16 3312, i16 3312, i16 3312, i16 3312, i16 7392, i16 15552, i16 -2048, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 765, i16 255, i16 255, i16 255, i16 28, i16 60, i16 1912, i16 4080, i16 7904, i16 15552, i16 30848, i16 12480, i16 255, i16 765, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 224, i16 240, i16 248, i16 124, i16 572, i16 828, i16 3840, i16 3840, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 0, i16 0, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 248, i16 252, i16 254, i16 2295, i16 3315, i16 3315, i16 3315, i16 3315, i16 60, i16 124, i16 1020, i16 988, i16 9116, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 15360, i16 15360, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 -6400, i16 -6400, i16 240, i16 248, i16 252, i16 254, i16 255, i16 255, i16 2295, i16 3315, i16 60, i16 60, i16 828, i16 828, i16 828, i16 956, i16 1020, i16 1020, i16 3313, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 15360, i16 15360, i16 1020, i16 1020, i16 892, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -31972, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -512, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 224, i16 240, i16 -32648, i16 -15304, i16 -31176, i16 1592, i16 1592, i16 1592, i16 765, i16 765, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 1784, i16 1784, i16 17976, i16 1656, i16 764, i16 764, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 63, i16 127, i16 2040, i16 4080, i16 1784, i16 255, i16 127, i16 63, i16 248, i16 252, i16 -15812, i16 -256, i16 3840, i16 240, i16 248, i16 252, i16 7936, i16 3840, i16 224, i16 255, i16 255, i16 127, i16 16128, i16 7936, i16 -32132, i16 -15556, i16 892, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 -4096, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 28, i16 28, i16 796, i16 796, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 510, i16 255, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 828, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 248, i16 248, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 124, i16 124, i16 1912, i16 1912, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 572, i16 63, i16 31, i16 15, i16 7, i16 768, i16 256, i16 1656, i16 3824, i16 3824, i16 7392, i16 15552, i16 30848, i16 -4096, i16 -8192, i16 243, i16 243, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 156, i16 156, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 2295, i16 255, i16 510, i16 892, i16 16128, i16 7936, i16 25500, i16 25500, i16 9180, i16 1020, i16 1020, i16 -30856, i16 -16640, i16 7680, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 15, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 14528, i16 31, i16 63, i16 892, i16 2040, i16 4080, i16 3824, i16 15360, i16 15360, i16 4320, i16 240, i16 248, i16 -32644, i16 572, i16 828, i16 3840, i16 3840, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 7, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 7, i16 7, i16 7, i16 7, i16 7, i16 7, i16 256, i16 256, i16 28800, i16 24704, i16 24704, i16 24704, i16 24704, i16 24704, i16 -8192, i16 -8192, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 1, i16 3, i16 7, i16 252, i16 252, i16 1020, i16 -31876, i16 2040, i16 4080, i16 7904, i16 15552, i16 15, i16 31, i16 318, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 30848, i16 -4096, i16 -8192, i16 252, i16 252, i16 1020, i16 -256, i16 -256, i16 31, i16 31, i16 286, i16 286, i16 286, i16 286, i16 286, i16 286, i16 224, i16 224, i16 -2048, i16 -2048, i16 -32768, i16 -32768, i16 -32768, i16 -32768, i16 286, i16 286, i16 286, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 -32768, i16 -32768, i16 -32768, i16 224, i16 224, i16 -2048, i16 -2048, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 3, i16 1, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 128, i16 192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 768, i16 256, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 0, i16 0, i16 0, i16 224, i16 224, i16 2288, i16 2288, i16 3312, i16 3312, i16 3312, i16 3312, i16 0, i16 0, i16 0, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 3312, i16 3312, i16 3312, i16 7392, i16 7392, i16 -2048, i16 -2048, i16 0, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1840, i16 3584, i16 3072, i16 192, i16 224, i16 -32656, i16 -16328, i16 -32740, i16 524, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 127, i16 127, i16 7936, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 -512], align 1
@bv_mutations = internal unnamed_addr global i16 0, align 1
@bv_vin = internal unnamed_addr global [16 x %struct.BvVert] zeroinitializer, align 1
@bv_out = internal unnamed_addr global [6 x %struct.BvMat] zeroinitializer, align 1
@bv_reread = internal unnamed_addr global [6 x %struct.BvMat] zeroinitializer, align 1
@bv_vout = internal unnamed_addr global [6 x [16 x %struct.BvVert]] zeroinitializer, align 1
@__const.bv_stage.rot = private unnamed_addr constant [9 x i16] [i16 248, i16 -58, i16 0, i16 58, i16 248, i16 0, i16 0, i16 0, i16 256], align 1
@title_end._title_bg_black = internal constant i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca %struct.BvMat, align 1
  %2 = alloca %struct.BvMat, align 1
  %3 = alloca %struct.BvMat, align 1
  %4 = alloca %struct.BvVert, align 1
  %5 = alloca %struct.BvVert, align 1
  %6 = alloca [24 x i8], align 1
  store volatile i8 -113, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  br label %7

7:                                                ; preds = %11, %0
  %8 = phi i16 [ 8449, %0 ], [ %12, %11 ]
  switch i16 %8, label %9 [
    i16 8452, label %11
    i16 8470, label %11
    i16 8471, label %11
    i16 8472, label %11
    i16 8473, label %11
    i16 8481, label %11
    i16 8482, label %11
  ]

9:                                                ; preds = %7
  %10 = inttoptr i16 %8 to ptr
  store volatile i8 0, ptr %10, align 1, !tbaa !6
  br label %11

11:                                               ; preds = %9, %7, %7, %7, %7, %7, %7, %7
  %12 = add nuw nsw i16 %8, 1
  %13 = icmp eq i16 %12, 8500
  br i1 %13, label %14, label %7, !llvm.loop !7

14:                                               ; preds = %11
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) getelementptr inbounds nuw (i8, ptr @main.a, i16 176), i8 0, i64 6, i1 false)
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  store volatile i8 1, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 -127, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !6
  store ptr @CANVAS_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), align 1, !tbaa !15
  store i8 4, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !19
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4299), align 1, !tbaa !20
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4301), align 1, !tbaa !21
  store i8 8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4303), align 1, !tbaa !22
  store i8 6, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4304), align 1, !tbaa !23
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(4096) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i16 4096, i1 false), !tbaa !6
  store i16 -1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  store ptr @TEXT_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !26
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !28
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4308), align 1, !tbaa !29
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4310), align 1, !tbaa !6
  store i8 25, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4311), align 1, !tbaa !6
  br label %15

15:                                               ; preds = %15, %14
  %16 = phi i8 [ 0, %14 ], [ %22, %15 ]
  %17 = phi i16 [ 0, %14 ], [ %20, %15 ]
  %18 = zext i8 %16 to i16
  %19 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4312), i16 %18
  store i16 256, ptr %19, align 1, !tbaa !2
  %20 = add nuw nsw i16 %17, 1
  %21 = icmp eq i16 %20, 64
  %22 = add nuw i8 %16, 2
  br i1 %21, label %23, label %15, !llvm.loop !30

23:                                               ; preds = %15
  store i8 3, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %24 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %25 = icmp eq i8 %24, 0
  br i1 %25, label %27, label %26

26:                                               ; preds = %23
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %27

27:                                               ; preds = %26, %23
  %28 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %29 = icmp ult i8 %28, 4
  br i1 %29, label %30, label %34

30:                                               ; preds = %27
  %31 = zext nneg i8 %28 to i16
  %32 = add nuw nsw i8 %28, 1
  store i8 %32, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %33 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %31
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr %33, align 1, !tbaa !35
  br label %34

34:                                               ; preds = %27, %30
  tail call void @_canvas_reserve(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr nonnull poison) #13, !inline_history !37
  %35 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %36 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !39
  %37 = or i8 %36, %35
  store i8 %37, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %37, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %38 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %39 = icmp eq i8 %38, 0
  br i1 %39, label %41, label %40

40:                                               ; preds = %34
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %41

41:                                               ; preds = %40, %34
  %42 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %43 = icmp ult i8 %42, 4
  br i1 %43, label %44, label %48

44:                                               ; preds = %41
  %45 = zext nneg i8 %42 to i16
  %46 = add nuw nsw i8 %42, 1
  store i8 %46, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %47 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %45
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr %47, align 1, !tbaa !35
  br label %48

48:                                               ; preds = %41, %44
  %49 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !40
  %50 = load ptr, ptr %49, align 1, !tbaa !41
  tail call void %50(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 178)) #13, !inline_history !37
  %51 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %52 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !39
  %53 = or i8 %52, %51
  store i8 %53, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %53, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %54 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %55 = icmp ugt i8 %54, 15
  br i1 %55, label %67, label %56

56:                                               ; preds = %48
  %57 = zext nneg i8 %54 to i16
  %58 = add nuw nsw i8 %54, 1
  store i8 %58, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %59 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %57
  %60 = getelementptr inbounds nuw i8, ptr %59, i16 10
  store i8 1, ptr %60, align 1, !tbaa !44
  store i16 0, ptr %59, align 1, !tbaa !46
  %61 = getelementptr inbounds nuw i8, ptr %59, i16 9
  store i8 0, ptr %61, align 1, !tbaa !47
  %62 = getelementptr inbounds nuw i8, ptr %59, i16 7
  store i8 34, ptr %62, align 1, !tbaa !48
  %63 = getelementptr inbounds nuw i8, ptr %59, i16 8
  store i8 0, ptr %63, align 1, !tbaa !49
  %64 = getelementptr inbounds nuw i8, ptr %59, i16 2
  store i16 ptrtoint (ptr @bg3_pal to i16), ptr %64, align 1, !tbaa !50
  %65 = getelementptr inbounds nuw i8, ptr %59, i16 6
  store i8 0, ptr %65, align 1, !tbaa !51
  %66 = getelementptr inbounds nuw i8, ptr %59, i16 4
  store i16 8, ptr %66, align 1, !tbaa !52
  br label %67

67:                                               ; preds = %48, %56
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !53
  br label %68

68:                                               ; preds = %67, %78
  %69 = phi i8 [ 0, %67 ], [ %86, %78 ]
  %70 = phi i8 [ 0, %67 ], [ %85, %78 ]
  %71 = phi i8 [ 66, %67 ], [ %84, %78 ]
  %72 = zext i8 %71 to i16
  %73 = icmp ugt i8 %71, 31
  br i1 %73, label %74, label %78

74:                                               ; preds = %68
  %75 = icmp ult i8 %71, 96
  br i1 %75, label %76, label %78

76:                                               ; preds = %74
  %77 = add nuw nsw i16 %72, 224
  br label %78

78:                                               ; preds = %76, %74, %68
  %79 = phi i16 [ %77, %76 ], [ 256, %74 ], [ 256, %68 ]
  %80 = zext nneg i8 %70 to i16
  %81 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4314), i16 %80
  store i16 %79, ptr %81, align 1, !tbaa !2
  %82 = zext nneg i8 %69 to i16
  %83 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @.str, i16 1), i16 %82
  %84 = load i8, ptr %83, align 1, !tbaa !6
  %85 = add nuw nsw i8 %70, 2
  %86 = add nuw nsw i8 %69, 1
  %87 = icmp eq i8 %86, 26
  br i1 %87, label %88, label %68, !llvm.loop !55

88:                                               ; preds = %78
  %89 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %90 = or i8 %89, 1
  store i8 %90, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  store ptr @TITLE_VT, ptr @main.title, align 1, !tbaa !56
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !60
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 3), align 1, !tbaa !61
  store ptr @.str.2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 5), align 1, !tbaa !62
  store ptr @.str.2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 7), align 1, !tbaa !63
  store i8 8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 11), align 1, !tbaa !64
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 9), align 1, !tbaa !65
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 12), align 1, !tbaa !66
  store i16 96, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 13), align 1, !tbaa !67
  store i16 112, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 15), align 1, !tbaa !68
  store i16 16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 17), align 1, !tbaa !69
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 28), align 1, !tbaa !70
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !71
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !72
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !73
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !74
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !75
  store i16 32767, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 34), align 1, !tbaa !76
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 36), align 1, !tbaa !77
  %91 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %92 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %93 = icmp eq i8 %92, 0
  br i1 %93, label %95, label %94

94:                                               ; preds = %88
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !33
  br label %95

95:                                               ; preds = %94, %88
  %96 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %97 = icmp ult i8 %96, 4
  br i1 %97, label %98, label %102

98:                                               ; preds = %95
  %99 = zext nneg i8 %96 to i16
  %100 = add nuw nsw i8 %96, 1
  store i8 %100, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %101 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %99
  store ptr @main.title, ptr %101, align 1, !tbaa !35
  br label %102

102:                                              ; preds = %98, %95
  tail call void @_title_reserve(ptr noundef nonnull @main.title, ptr nonnull poison) #13, !inline_history !37
  %103 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %104 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %105 = or i8 %104, %103
  store volatile i8 %105, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store i8 %91, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !78
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 2, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 24, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  br label %106

106:                                              ; preds = %134, %102
  %107 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %108 = icmp eq i8 %107, 0
  br i1 %108, label %120, label %109

109:                                              ; preds = %106, %109
  %110 = phi i8 [ %117, %109 ], [ 0, %106 ]
  %111 = zext i8 %110 to i16
  %112 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %111
  %113 = load ptr, ptr %112, align 1, !tbaa !35
  %114 = load ptr, ptr %113, align 1, !tbaa !40
  %115 = getelementptr inbounds nuw i8, ptr %114, i16 2
  %116 = load ptr, ptr %115, align 1, !tbaa !79
  tail call void %116(ptr noundef nonnull %113, ptr noundef nonnull @main.a) #13, !inline_history !80
  %117 = add nuw i8 %110, 1
  %118 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %119 = icmp ult i8 %117, %118
  br i1 %119, label %109, label %120, !llvm.loop !81

120:                                              ; preds = %109, %106
  %121 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %122

122:                                              ; preds = %122, %120
  %123 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %124 = icmp sgt i8 %123, -1
  br i1 %124, label %122, label %125, !llvm.loop !82

125:                                              ; preds = %122
  tail call fastcc void @upq_flush() #14
  %126 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %127 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %128 = icmp ult i8 %126, %127
  br i1 %128, label %131, label %129

129:                                              ; preds = %125
  %130 = icmp ugt i8 %126, %127
  br i1 %130, label %131, label %134

131:                                              ; preds = %129, %125
  %132 = phi i8 [ 1, %125 ], [ -1, %129 ]
  %133 = add i8 %132, %126
  store i8 %133, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %134

134:                                              ; preds = %131, %129
  %135 = phi i8 [ %126, %129 ], [ %133, %131 ]
  %136 = and i8 %135, 15
  store volatile i8 %136, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %137 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %138 = icmp eq i8 %137, 15
  br i1 %138, label %139, label %106, !llvm.loop !83

139:                                              ; preds = %134
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !74
  %140 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !75
  %141 = icmp eq i8 %140, -1
  br i1 %141, label %179, label %142

142:                                              ; preds = %139, %171
  %143 = phi i8 [ %174, %171 ], [ 0, %139 ]
  %144 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %145 = icmp eq i8 %144, 0
  br i1 %145, label %157, label %146

146:                                              ; preds = %142, %146
  %147 = phi i8 [ %154, %146 ], [ 0, %142 ]
  %148 = zext i8 %147 to i16
  %149 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %148
  %150 = load ptr, ptr %149, align 1, !tbaa !35
  %151 = load ptr, ptr %150, align 1, !tbaa !40
  %152 = getelementptr inbounds nuw i8, ptr %151, i16 2
  %153 = load ptr, ptr %152, align 1, !tbaa !79
  tail call void %153(ptr noundef nonnull %150, ptr noundef nonnull @main.a) #13, !inline_history !84
  %154 = add nuw i8 %147, 1
  %155 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %156 = icmp ult i8 %154, %155
  br i1 %156, label %146, label %157, !llvm.loop !81

157:                                              ; preds = %146, %142
  %158 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %159

159:                                              ; preds = %159, %157
  %160 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %161 = icmp sgt i8 %160, -1
  br i1 %161, label %159, label %162, !llvm.loop !82

162:                                              ; preds = %159
  tail call fastcc void @upq_flush() #14
  %163 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %164 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %165 = icmp ult i8 %163, %164
  br i1 %165, label %168, label %166

166:                                              ; preds = %162
  %167 = icmp ugt i8 %163, %164
  br i1 %167, label %168, label %171

168:                                              ; preds = %166, %162
  %169 = phi i8 [ 1, %162 ], [ -1, %166 ]
  %170 = add i8 %169, %163
  store i8 %170, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %171

171:                                              ; preds = %168, %166
  %172 = phi i8 [ %163, %166 ], [ %170, %168 ]
  %173 = and i8 %172, 15
  store volatile i8 %173, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %174 = add nuw i8 %143, 1
  %175 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !75
  %176 = icmp ne i8 %175, -1
  %177 = icmp ult i8 %143, -57
  %178 = select i1 %176, i1 %177, i1 false
  br i1 %178, label %142, label %179, !llvm.loop !85

179:                                              ; preds = %171, %139
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !74
  store i16 0, ptr @bv_mutations, align 1, !tbaa !2
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #15
  br label %180

180:                                              ; preds = %180, %179
  %181 = phi i8 [ 0, %179 ], [ %190, %180 ]
  %182 = phi i8 [ 0, %179 ], [ %188, %180 ]
  %183 = zext nneg i8 %182 to i16
  %184 = mul nuw nsw i16 %183, 37
  %185 = add nsw i16 %184, -128
  %186 = zext nneg i8 %181 to i16
  %187 = getelementptr i8, ptr %1, i16 %186
  store i16 %185, ptr %187, align 1, !tbaa !2
  %188 = add nuw nsw i8 %182, 1
  %189 = icmp eq i8 %188, 9
  %190 = add nuw nsw i8 %181, 2
  br i1 %189, label %191, label %180, !llvm.loop !86

191:                                              ; preds = %180, %191
  %192 = phi i8 [ %212, %191 ], [ 0, %180 ]
  %193 = phi i8 [ %210, %191 ], [ 0, %180 ]
  %194 = zext nneg i8 %193 to i16
  %195 = and i16 %194, 3
  %196 = mul nuw nsw i16 %195, 96
  %197 = add nsw i16 %196, -144
  %198 = zext i8 %192 to i16
  %199 = getelementptr i8, ptr @bv_vin, i16 %198
  store i16 %197, ptr %199, align 1, !tbaa !87
  %200 = lshr i16 %194, 2
  %201 = mul nuw nsw i16 %200, 96
  %202 = add nsw i16 %201, -144
  %203 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @bv_vin, i16 2), i16 %198
  store i16 %202, ptr %203, align 1, !tbaa !89
  %204 = mul nuw nsw i16 %194, 17
  %205 = add nsw i16 %204, -136
  %206 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @bv_vin, i16 4), i16 %198
  store i16 %205, ptr %206, align 1, !tbaa !90
  %207 = mul nuw nsw i16 %194, 2053
  %208 = add nuw nsw i16 %207, 7
  %209 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @bv_vin, i16 6), i16 %198
  store i16 %208, ptr %209, align 1, !tbaa !91
  %210 = add nuw nsw i8 %193, 1
  %211 = icmp eq i8 %210, 16
  %212 = add nuw i8 %192, 8
  br i1 %211, label %213, label %191, !llvm.loop !92

213:                                              ; preds = %191, %224
  %214 = phi i8 [ %228, %224 ], [ 0, %191 ]
  %215 = phi ptr [ %226, %224 ], [ @bv_vout, %191 ]
  %216 = phi i16 [ %240, %224 ], [ 27601, %191 ]
  %217 = phi i8 [ %225, %224 ], [ 0, %191 ]
  %218 = zext nneg i8 %217 to i16
  %219 = mul nuw nsw i16 %218, 211
  %220 = add nuw nsw i16 %219, 13
  %221 = zext nneg i8 %214 to i16
  %222 = getelementptr i8, ptr @bv_out, i16 %221
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #15
  call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(18) %3, ptr noundef nonnull align 1 dereferenceable(18) %1, i16 18, i1 false), !tbaa.struct !93
  call fastcc void @bv_stage(ptr dead_on_unwind writable sret(%struct.BvMat) align 1 %2, ptr noundef dead_on_return %3, i16 noundef %220) #14
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #15
  call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(18) %222, ptr noundef nonnull align 1 dereferenceable(18) %2, i16 18, i1 false), !tbaa.struct !93
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #15
  %223 = getelementptr i8, ptr @bv_reread, i16 %221
  call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(18) %223, ptr noundef nonnull align 1 dereferenceable(18) %1, i16 18, i1 false), !tbaa.struct !93
  br label %229

224:                                              ; preds = %229
  %225 = add nuw nsw i8 %217, 1
  %226 = getelementptr i8, ptr %215, i16 128
  %227 = icmp eq i8 %225, 6
  %228 = add nuw nsw i8 %214, 18
  br i1 %227, label %244, label %213, !llvm.loop !94

229:                                              ; preds = %229, %213
  %230 = phi i8 [ 0, %213 ], [ %243, %229 ]
  %231 = phi i16 [ %216, %213 ], [ %240, %229 ]
  %232 = phi i8 [ 0, %213 ], [ %241, %229 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #15
  %233 = zext i8 %230 to i16
  %234 = getelementptr i8, ptr @bv_vin, i16 %233
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #15
  call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(8) %5, ptr noundef nonnull align 1 dereferenceable(8) %234, i16 8, i1 false), !tbaa.struct !95
  %235 = call fastcc i16 @bv_apply(ptr noundef dead_on_return %5, ptr noundef dead_on_return %222, ptr noundef %4) #14
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #15
  %236 = getelementptr i8, ptr %215, i16 %233
  call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(8) %236, ptr noundef nonnull align 1 dereferenceable(8) %4, i16 8, i1 false), !tbaa.struct !95
  %237 = xor i16 %235, %231
  %238 = tail call i16 @llvm.fshl.i16(i16 %237, i16 %237, i16 1)
  %239 = mul i16 %238, 25173
  %240 = add i16 %239, 13849
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #15
  %241 = add nuw nsw i8 %232, 1
  %242 = icmp eq i8 %241, 16
  %243 = add nuw i8 %230, 8
  br i1 %242, label %224, label %229, !llvm.loop !96

244:                                              ; preds = %224, %274
  %245 = phi i8 [ %284, %274 ], [ 0, %224 ]
  %246 = phi ptr [ %278, %274 ], [ @bv_reread, %224 ]
  %247 = phi ptr [ %277, %274 ], [ @bv_out, %224 ]
  %248 = phi ptr [ %282, %274 ], [ getelementptr inbounds nuw (i8, ptr @bv_vout, i16 6), %224 ]
  %249 = phi ptr [ %281, %274 ], [ getelementptr inbounds nuw (i8, ptr @bv_vout, i16 4), %224 ]
  %250 = phi ptr [ %280, %274 ], [ getelementptr inbounds nuw (i8, ptr @bv_vout, i16 2), %224 ]
  %251 = phi ptr [ %279, %274 ], [ @bv_vout, %224 ]
  %252 = phi i8 [ %275, %274 ], [ 0, %224 ]
  %253 = phi i16 [ %313, %274 ], [ %240, %224 ]
  br label %254

254:                                              ; preds = %254, %244
  %255 = phi i8 [ 0, %244 ], [ %273, %254 ]
  %256 = phi i8 [ 0, %244 ], [ %271, %254 ]
  %257 = phi i16 [ %253, %244 ], [ %270, %254 ]
  %258 = zext nneg i8 %255 to i16
  %259 = getelementptr i8, ptr %247, i16 %258
  %260 = load i16, ptr %259, align 1, !tbaa !2
  %261 = xor i16 %260, %257
  %262 = tail call i16 @llvm.fshl.i16(i16 %261, i16 %261, i16 1)
  %263 = mul i16 %262, 25173
  %264 = add i16 %263, 13849
  %265 = getelementptr i8, ptr %246, i16 %258
  %266 = load i16, ptr %265, align 1, !tbaa !2
  %267 = xor i16 %264, %266
  %268 = tail call i16 @llvm.fshl.i16(i16 %267, i16 %267, i16 1)
  %269 = mul i16 %268, 25173
  %270 = add i16 %269, 13849
  %271 = add nuw nsw i8 %256, 1
  %272 = icmp eq i8 %271, 9
  %273 = add nuw nsw i8 %255, 2
  br i1 %272, label %285, label %254, !llvm.loop !97

274:                                              ; preds = %285
  %275 = add nuw nsw i8 %252, 1
  %276 = zext nneg i8 %245 to i16
  %277 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @bv_out, i16 18), i16 %276
  %278 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @bv_reread, i16 18), i16 %276
  %279 = getelementptr i8, ptr %251, i16 128
  %280 = getelementptr i8, ptr %250, i16 128
  %281 = getelementptr i8, ptr %249, i16 128
  %282 = getelementptr i8, ptr %248, i16 128
  %283 = icmp eq i8 %275, 6
  %284 = add nuw nsw i8 %245, 18
  br i1 %283, label %317, label %244, !llvm.loop !98

285:                                              ; preds = %254, %285
  %286 = phi i8 [ %316, %285 ], [ 0, %254 ]
  %287 = phi i8 [ %314, %285 ], [ 0, %254 ]
  %288 = phi i16 [ %313, %285 ], [ %270, %254 ]
  %289 = zext i8 %286 to i16
  %290 = getelementptr i8, ptr %251, i16 %289
  %291 = load i16, ptr %290, align 1, !tbaa !87
  %292 = xor i16 %291, %288
  %293 = tail call i16 @llvm.fshl.i16(i16 %292, i16 %292, i16 1)
  %294 = mul i16 %293, 25173
  %295 = add i16 %294, 13849
  %296 = getelementptr i8, ptr %250, i16 %289
  %297 = load i16, ptr %296, align 1, !tbaa !89
  %298 = xor i16 %295, %297
  %299 = tail call i16 @llvm.fshl.i16(i16 %298, i16 %298, i16 1)
  %300 = mul i16 %299, 25173
  %301 = add i16 %300, 13849
  %302 = getelementptr i8, ptr %249, i16 %289
  %303 = load i16, ptr %302, align 1, !tbaa !90
  %304 = xor i16 %301, %303
  %305 = tail call i16 @llvm.fshl.i16(i16 %304, i16 %304, i16 1)
  %306 = mul i16 %305, 25173
  %307 = add i16 %306, 13849
  %308 = getelementptr i8, ptr %248, i16 %289
  %309 = load i16, ptr %308, align 1, !tbaa !91
  %310 = xor i16 %307, %309
  %311 = tail call i16 @llvm.fshl.i16(i16 %310, i16 %310, i16 1)
  %312 = mul i16 %311, 25173
  %313 = add i16 %312, 13849
  %314 = add nuw nsw i8 %287, 1
  %315 = icmp eq i8 %314, 16
  %316 = add nuw i8 %286, 8
  br i1 %315, label %274, label %285, !llvm.loop !99

317:                                              ; preds = %274, %317
  %318 = phi i8 [ %336, %317 ], [ 0, %274 ]
  %319 = phi i8 [ %334, %317 ], [ 0, %274 ]
  %320 = phi i16 [ %333, %317 ], [ %313, %274 ]
  %321 = zext i8 %318 to i16
  %322 = getelementptr i8, ptr @bv_vin, i16 %321
  %323 = load i16, ptr %322, align 1, !tbaa !87
  %324 = xor i16 %323, %320
  %325 = tail call i16 @llvm.fshl.i16(i16 %324, i16 %324, i16 1)
  %326 = mul i16 %325, 25173
  %327 = add i16 %326, 13849
  %328 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @bv_vin, i16 6), i16 %321
  %329 = load i16, ptr %328, align 1, !tbaa !91
  %330 = xor i16 %327, %329
  %331 = tail call i16 @llvm.fshl.i16(i16 %330, i16 %330, i16 1)
  %332 = mul i16 %331, 25173
  %333 = add i16 %332, 13849
  %334 = add nuw nsw i8 %319, 1
  %335 = icmp eq i8 %334, 16
  %336 = add nuw i8 %318, 8
  br i1 %335, label %337, label %317, !llvm.loop !100

337:                                              ; preds = %317
  %338 = load i16, ptr @bv_mutations, align 1, !tbaa !2
  %339 = xor i16 %338, %333
  %340 = tail call i16 @llvm.fshl.i16(i16 %339, i16 %339, i16 1)
  %341 = mul i16 %340, 25173
  %342 = add i16 %341, 13849
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #15
  store volatile i16 %342, ptr @corpus_result, align 1, !tbaa !2
  br label %343

343:                                              ; preds = %373, %337
  %344 = phi i16 [ 90, %337 ], [ %345, %373 ]
  %345 = add nsw i16 %344, -1
  %346 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %347 = icmp eq i8 %346, 0
  br i1 %347, label %359, label %348

348:                                              ; preds = %343, %348
  %349 = phi i8 [ %356, %348 ], [ 0, %343 ]
  %350 = zext i8 %349 to i16
  %351 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %350
  %352 = load ptr, ptr %351, align 1, !tbaa !35
  %353 = load ptr, ptr %352, align 1, !tbaa !40
  %354 = getelementptr inbounds nuw i8, ptr %353, i16 2
  %355 = load ptr, ptr %354, align 1, !tbaa !79
  tail call void %355(ptr noundef nonnull %352, ptr noundef nonnull @main.a) #13, !inline_history !101
  %356 = add nuw i8 %349, 1
  %357 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %358 = icmp ult i8 %356, %357
  br i1 %358, label %348, label %359, !llvm.loop !81

359:                                              ; preds = %348, %343
  %360 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %361

361:                                              ; preds = %361, %359
  %362 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %363 = icmp sgt i8 %362, -1
  br i1 %363, label %361, label %364, !llvm.loop !82

364:                                              ; preds = %361
  tail call fastcc void @upq_flush() #14
  %365 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %366 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %367 = icmp ult i8 %365, %366
  br i1 %367, label %370, label %368

368:                                              ; preds = %364
  %369 = icmp ugt i8 %365, %366
  br i1 %369, label %370, label %373

370:                                              ; preds = %368, %364
  %371 = phi i8 [ 1, %364 ], [ -1, %368 ]
  %372 = add i8 %371, %365
  store i8 %372, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %373

373:                                              ; preds = %370, %368
  %374 = phi i8 [ %365, %368 ], [ %372, %370 ]
  %375 = and i8 %374, 15
  store volatile i8 %375, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %376 = icmp eq i16 %345, 0
  br i1 %376, label %377, label %343, !llvm.loop !102

377:                                              ; preds = %373
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !72
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !73
  br label %381

378:                                              ; preds = %410
  %379 = add nuw nsw i8 %382, 1
  %380 = icmp eq i8 %379, 90
  br i1 %380, label %415, label %381, !llvm.loop !103

381:                                              ; preds = %378, %377
  %382 = phi i8 [ 0, %377 ], [ %379, %378 ]
  %383 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %384 = icmp eq i8 %383, 0
  br i1 %384, label %396, label %385

385:                                              ; preds = %381, %385
  %386 = phi i8 [ %393, %385 ], [ 0, %381 ]
  %387 = zext i8 %386 to i16
  %388 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %387
  %389 = load ptr, ptr %388, align 1, !tbaa !35
  %390 = load ptr, ptr %389, align 1, !tbaa !40
  %391 = getelementptr inbounds nuw i8, ptr %390, i16 2
  %392 = load ptr, ptr %391, align 1, !tbaa !79
  tail call void %392(ptr noundef nonnull %389, ptr noundef nonnull @main.a) #13, !inline_history !104
  %393 = add nuw i8 %386, 1
  %394 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %395 = icmp ult i8 %393, %394
  br i1 %395, label %385, label %396, !llvm.loop !81

396:                                              ; preds = %385, %381
  %397 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %398

398:                                              ; preds = %398, %396
  %399 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %400 = icmp sgt i8 %399, -1
  br i1 %400, label %398, label %401, !llvm.loop !82

401:                                              ; preds = %398
  tail call fastcc void @upq_flush() #14
  %402 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %403 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %404 = icmp ult i8 %402, %403
  br i1 %404, label %407, label %405

405:                                              ; preds = %401
  %406 = icmp ugt i8 %402, %403
  br i1 %406, label %407, label %410

407:                                              ; preds = %405, %401
  %408 = phi i8 [ 1, %401 ], [ -1, %405 ]
  %409 = add i8 %408, %402
  store i8 %409, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %410

410:                                              ; preds = %407, %405
  %411 = phi i8 [ %402, %405 ], [ %409, %407 ]
  %412 = and i8 %411, 15
  store volatile i8 %412, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %413 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 19), align 1, !tbaa !105
  %414 = icmp sgt i16 %413, 3583
  br i1 %414, label %415, label %378

415:                                              ; preds = %410, %378
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !72
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %416 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %417 = icmp eq i8 %416, 0
  br i1 %417, label %451, label %418

418:                                              ; preds = %415, %446
  %419 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %420 = icmp eq i8 %419, 0
  br i1 %420, label %432, label %421

421:                                              ; preds = %418, %421
  %422 = phi i8 [ %429, %421 ], [ 0, %418 ]
  %423 = zext i8 %422 to i16
  %424 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %423
  %425 = load ptr, ptr %424, align 1, !tbaa !35
  %426 = load ptr, ptr %425, align 1, !tbaa !40
  %427 = getelementptr inbounds nuw i8, ptr %426, i16 2
  %428 = load ptr, ptr %427, align 1, !tbaa !79
  tail call void %428(ptr noundef nonnull %425, ptr noundef nonnull @main.a) #13, !inline_history !106
  %429 = add nuw i8 %422, 1
  %430 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %431 = icmp ult i8 %429, %430
  br i1 %431, label %421, label %432, !llvm.loop !81

432:                                              ; preds = %421, %418
  %433 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %434

434:                                              ; preds = %434, %432
  %435 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %436 = icmp sgt i8 %435, -1
  br i1 %436, label %434, label %437, !llvm.loop !82

437:                                              ; preds = %434
  tail call fastcc void @upq_flush() #14
  %438 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %439 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %440 = icmp ult i8 %438, %439
  br i1 %440, label %443, label %441

441:                                              ; preds = %437
  %442 = icmp ugt i8 %438, %439
  br i1 %442, label %443, label %446

443:                                              ; preds = %441, %437
  %444 = phi i8 [ 1, %437 ], [ -1, %441 ]
  %445 = add i8 %444, %438
  store i8 %445, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %446

446:                                              ; preds = %443, %441
  %447 = phi i8 [ %438, %441 ], [ %445, %443 ]
  %448 = and i8 %447, 15
  store volatile i8 %448, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %449 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %450 = icmp eq i8 %449, 0
  br i1 %450, label %451, label %418, !llvm.loop !83

451:                                              ; preds = %446, %415
  %452 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !78
  %453 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  %454 = or i8 %453, %452
  %455 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !39
  %456 = xor i8 %455, -1
  %457 = and i8 %454, %456
  store i8 %457, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !38
  store volatile i8 %457, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !71
  %458 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %459 = icmp ugt i8 %458, 15
  br i1 %459, label %471, label %460

460:                                              ; preds = %451
  %461 = zext nneg i8 %458 to i16
  %462 = add nuw nsw i8 %458, 1
  store i8 %462, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %463 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %461
  %464 = getelementptr inbounds nuw i8, ptr %463, i16 10
  store i8 1, ptr %464, align 1, !tbaa !44
  store i16 0, ptr %463, align 1, !tbaa !46
  %465 = getelementptr inbounds nuw i8, ptr %463, i16 9
  store i8 0, ptr %465, align 1, !tbaa !47
  %466 = getelementptr inbounds nuw i8, ptr %463, i16 7
  store i8 34, ptr %466, align 1, !tbaa !48
  %467 = getelementptr inbounds nuw i8, ptr %463, i16 8
  store i8 0, ptr %467, align 1, !tbaa !49
  %468 = getelementptr inbounds nuw i8, ptr %463, i16 2
  store i16 ptrtoint (ptr @title_end._title_bg_black to i16), ptr %468, align 1, !tbaa !50
  %469 = getelementptr inbounds nuw i8, ptr %463, i16 6
  store i8 0, ptr %469, align 1, !tbaa !51
  %470 = getelementptr inbounds nuw i8, ptr %463, i16 4
  store i16 2, ptr %470, align 1, !tbaa !52
  br label %471

471:                                              ; preds = %451, %460
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  store i8 0, ptr @bz_stage, align 1, !tbaa !6
  tail call fastcc void @stage_draw(i8 noundef zeroext 0) #14
  br label %472

472:                                              ; preds = %477, %471
  %473 = phi i8 [ %482, %477 ], [ 0, %471 ]
  %474 = phi ptr [ %480, %477 ], [ getelementptr inbounds nuw (i8, ptr @bv_reread, i16 18), %471 ]
  %475 = phi i8 [ %478, %477 ], [ 1, %471 ]
  %476 = phi i16 [ %522, %477 ], [ 0, %471 ]
  br label %509

477:                                              ; preds = %521
  %478 = add nuw nsw i8 %475, 1
  %479 = zext nneg i8 %473 to i16
  %480 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @bv_reread, i16 36), i16 %479
  %481 = icmp eq i8 %478, 6
  %482 = add nuw nsw i8 %473, 18
  br i1 %481, label %483, label %472, !llvm.loop !107

483:                                              ; preds = %477
  %484 = getelementptr inbounds nuw i8, ptr %6, i16 1
  %485 = getelementptr inbounds nuw i8, ptr %6, i16 2
  %486 = getelementptr inbounds nuw i8, ptr %6, i16 3
  %487 = getelementptr inbounds nuw i8, ptr %6, i16 4
  %488 = getelementptr inbounds nuw i8, ptr %6, i16 5
  %489 = getelementptr inbounds nuw i8, ptr %6, i16 6
  %490 = getelementptr inbounds nuw i8, ptr %6, i16 7
  %491 = getelementptr inbounds nuw i8, ptr %6, i16 8
  %492 = getelementptr inbounds nuw i8, ptr %6, i16 9
  %493 = getelementptr inbounds nuw i8, ptr %6, i16 10
  %494 = getelementptr inbounds nuw i8, ptr %6, i16 11
  %495 = getelementptr inbounds nuw i8, ptr %6, i16 12
  %496 = icmp eq i16 %522, 0
  %497 = select i1 %496, i8 79, i8 88
  %498 = getelementptr inbounds nuw i8, ptr %6, i16 13
  %499 = getelementptr inbounds nuw i8, ptr %6, i16 14
  %500 = getelementptr inbounds nuw i8, ptr %6, i16 15
  %501 = getelementptr inbounds nuw i8, ptr %6, i16 16
  %502 = getelementptr inbounds nuw i8, ptr %6, i16 17
  %503 = getelementptr inbounds nuw i8, ptr %6, i16 18
  %504 = getelementptr inbounds nuw i8, ptr %6, i16 19
  %505 = getelementptr inbounds nuw i8, ptr %6, i16 20
  %506 = getelementptr inbounds nuw i8, ptr %6, i16 21
  %507 = getelementptr inbounds nuw i8, ptr %6, i16 22
  %508 = getelementptr inbounds nuw i8, ptr %6, i16 23
  br label %526

509:                                              ; preds = %521, %472
  %510 = phi i8 [ 0, %472 ], [ %525, %521 ]
  %511 = phi i8 [ 0, %472 ], [ %523, %521 ]
  %512 = phi i16 [ %476, %472 ], [ %522, %521 ]
  %513 = zext nneg i8 %510 to i16
  %514 = getelementptr i8, ptr %474, i16 %513
  %515 = load i16, ptr %514, align 1, !tbaa !2
  %516 = getelementptr i8, ptr @bv_reread, i16 %513
  %517 = load i16, ptr %516, align 1, !tbaa !2
  %518 = icmp eq i16 %515, %517
  br i1 %518, label %521, label %519

519:                                              ; preds = %509
  %520 = add i16 %512, 1
  br label %521

521:                                              ; preds = %519, %509
  %522 = phi i16 [ %520, %519 ], [ %512, %509 ]
  %523 = add nuw nsw i8 %511, 1
  %524 = icmp eq i8 %523, 9
  %525 = add nuw nsw i8 %510, 2
  br i1 %524, label %477, label %509, !llvm.loop !108

526:                                              ; preds = %483, %616
  %527 = phi i16 [ 0, %483 ], [ %619, %616 ]
  %528 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !53
  %529 = add i16 %528, 1
  store i16 %529, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !53
  %530 = add i16 %527, 1
  store i16 %530, ptr @bz_phase, align 1, !tbaa !2
  %531 = icmp ugt i16 %530, 44
  br i1 %531, label %532, label %537

532:                                              ; preds = %526
  store i16 0, ptr @bz_phase, align 1, !tbaa !2
  %533 = load i8, ptr @bz_stage, align 1, !tbaa !6
  %534 = add i8 %533, 1
  %535 = urem i8 %534, 6
  store i8 %535, ptr @bz_stage, align 1, !tbaa !6
  tail call fastcc void @stage_draw(i8 noundef zeroext %535) #14
  %536 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), align 1, !tbaa !53
  br label %537

537:                                              ; preds = %532, %526
  %538 = phi i16 [ %536, %532 ], [ %529, %526 ]
  %539 = and i16 %538, 7
  %540 = icmp eq i16 %539, 0
  br i1 %540, label %541, label %588

541:                                              ; preds = %537
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #15
  store i8 84, ptr %484, align 1, !tbaa !6
  store i8 71, ptr %485, align 1, !tbaa !6
  store i8 32, ptr %486, align 1, !tbaa !6
  %542 = load i8, ptr @bz_stage, align 1, !tbaa !6
  %543 = add i8 %542, 49
  store i8 %543, ptr %487, align 1, !tbaa !6
  store i8 47, ptr %488, align 1, !tbaa !6
  store i8 54, ptr %489, align 1, !tbaa !6
  store i8 32, ptr %490, align 1, !tbaa !6
  store i8 67, ptr %491, align 1, !tbaa !6
  store i8 79, ptr %492, align 1, !tbaa !6
  store i8 80, ptr %493, align 1, !tbaa !6
  store i8 89, ptr %494, align 1, !tbaa !6
  store i8 61, ptr %495, align 1, !tbaa !6
  store i8 %497, ptr %498, align 1, !tbaa !6
  store i8 75, ptr %499, align 1, !tbaa !6
  store i8 32, ptr %500, align 1, !tbaa !6
  store i8 67, ptr %501, align 1, !tbaa !6
  store i8 61, ptr %502, align 1, !tbaa !6
  %544 = load volatile i16, ptr @corpus_result, align 1, !tbaa !2
  %545 = lshr i16 %544, 12
  %546 = getelementptr inbounds nuw i8, ptr @hexd, i16 %545
  %547 = load i8, ptr %546, align 1, !tbaa !6
  store i8 %547, ptr %503, align 1, !tbaa !6
  %548 = load volatile i16, ptr @corpus_result, align 1, !tbaa !2
  %549 = lshr i16 %548, 8
  %550 = and i16 %549, 15
  %551 = getelementptr inbounds nuw i8, ptr @hexd, i16 %550
  %552 = load i8, ptr %551, align 1, !tbaa !6
  store i8 %552, ptr %504, align 1, !tbaa !6
  %553 = load volatile i16, ptr @corpus_result, align 1, !tbaa !2
  %554 = lshr i16 %553, 4
  %555 = and i16 %554, 15
  %556 = getelementptr inbounds nuw i8, ptr @hexd, i16 %555
  %557 = load i8, ptr %556, align 1, !tbaa !6
  store i8 %557, ptr %505, align 1, !tbaa !6
  %558 = load volatile i16, ptr @corpus_result, align 1, !tbaa !2
  %559 = and i16 %558, 15
  %560 = getelementptr inbounds nuw i8, ptr @hexd, i16 %559
  %561 = load i8, ptr %560, align 1, !tbaa !6
  store i8 %561, ptr %506, align 1, !tbaa !6
  store i8 32, ptr %507, align 1, !tbaa !6
  store i8 0, ptr %508, align 1, !tbaa !6
  br label %567

562:                                              ; preds = %577
  %563 = add nuw nsw i8 %570, 2
  %564 = add nuw nsw i8 %571, 1
  %565 = zext i8 %583 to i16
  %566 = icmp eq i8 %564, 32
  br i1 %566, label %585, label %567, !llvm.loop !55

567:                                              ; preds = %541, %562
  %568 = phi i16 [ 83, %541 ], [ %565, %562 ]
  %569 = phi i8 [ 83, %541 ], [ %583, %562 ]
  %570 = phi i8 [ 0, %541 ], [ %563, %562 ]
  %571 = phi i8 [ 0, %541 ], [ %564, %562 ]
  %572 = icmp ugt i8 %569, 31
  br i1 %572, label %573, label %577

573:                                              ; preds = %567
  %574 = icmp ult i8 %569, 96
  br i1 %574, label %575, label %577

575:                                              ; preds = %573
  %576 = add nuw nsw i16 %568, 224
  br label %577

577:                                              ; preds = %575, %573, %567
  %578 = phi i16 [ %576, %575 ], [ 256, %573 ], [ 256, %567 ]
  %579 = zext nneg i8 %570 to i16
  %580 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4376), i16 %579
  store i16 %578, ptr %580, align 1, !tbaa !2
  %581 = zext nneg i8 %571 to i16
  %582 = getelementptr i8, ptr %484, i16 %581
  %583 = load i8, ptr %582, align 1, !tbaa !6
  %584 = icmp eq i8 %583, 0
  br i1 %584, label %585, label %562, !llvm.loop !55

585:                                              ; preds = %562, %577
  %586 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  %587 = or i8 %586, 2
  store i8 %587, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !31
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #15
  br label %588

588:                                              ; preds = %585, %537
  %589 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %590 = icmp eq i8 %589, 0
  br i1 %590, label %602, label %591

591:                                              ; preds = %588, %591
  %592 = phi i8 [ %599, %591 ], [ 0, %588 ]
  %593 = zext i8 %592 to i16
  %594 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %593
  %595 = load ptr, ptr %594, align 1, !tbaa !35
  %596 = load ptr, ptr %595, align 1, !tbaa !40
  %597 = getelementptr inbounds nuw i8, ptr %596, i16 2
  %598 = load ptr, ptr %597, align 1, !tbaa !79
  tail call void %598(ptr noundef nonnull %595, ptr noundef nonnull @main.a) #13, !inline_history !109
  %599 = add nuw i8 %592, 1
  %600 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !34
  %601 = icmp ult i8 %599, %600
  br i1 %601, label %591, label %602, !llvm.loop !81

602:                                              ; preds = %591, %588
  %603 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %604

604:                                              ; preds = %604, %602
  %605 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %606 = icmp sgt i8 %605, -1
  br i1 %606, label %604, label %607, !llvm.loop !82

607:                                              ; preds = %604
  tail call fastcc void @upq_flush() #14
  %608 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  %609 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !14
  %610 = icmp ult i8 %608, %609
  br i1 %610, label %613, label %611

611:                                              ; preds = %607
  %612 = icmp ugt i8 %608, %609
  br i1 %612, label %613, label %616

613:                                              ; preds = %611, %607
  %614 = phi i8 [ 1, %607 ], [ -1, %611 ]
  %615 = add i8 %614, %608
  store i8 %615, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !9
  br label %616

616:                                              ; preds = %611, %613
  %617 = phi i8 [ %608, %611 ], [ %615, %613 ]
  %618 = and i8 %617, 15
  store volatile i8 %618, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !32
  %619 = load i16, ptr @bz_phase, align 1, !tbaa !2
  br label %526
}

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @stage_draw(i8 noundef zeroext range(i8 0, 6) %0) unnamed_addr #1 {
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(4098) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i64 4098, i1 false)
  store i16 255, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %2 = zext nneg i8 %0 to i16
  %3 = getelementptr inbounds nuw [128 x i8], ptr @bv_vout, i16 %2
  %4 = shl nuw nsw i16 %2, 7
  %5 = getelementptr nuw i8, ptr @bv_vout, i16 %4
  %6 = getelementptr nuw i8, ptr %5, i16 2
  %7 = getelementptr i8, ptr @bv_vout, i16 %4
  %8 = getelementptr i8, ptr %7, i16 -8
  %9 = getelementptr i8, ptr @bv_vout, i16 %4
  %10 = getelementptr i8, ptr %9, i16 -6
  br label %18

11:                                               ; preds = %68
  %12 = getelementptr inbounds nuw [18 x i8], ptr @bv_reread, i16 %2
  %13 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1
  %14 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1
  %15 = mul nuw nsw i16 %2, 18
  %16 = getelementptr i8, ptr @bv_reread, i16 %15
  %17 = getelementptr i8, ptr %16, i16 6
  br label %72

18:                                               ; preds = %1, %68
  %19 = phi i8 [ 0, %1 ], [ %71, %68 ]
  %20 = phi i8 [ 0, %1 ], [ %69, %68 ]
  %21 = zext i8 %19 to i16
  %22 = getelementptr i8, ptr %3, i16 %21
  %23 = load i16, ptr %22, align 1, !tbaa !87
  %24 = ashr i16 %23, 2
  %25 = add nsw i16 %24, 64
  %26 = getelementptr i8, ptr %6, i16 %21
  %27 = load i16, ptr %26, align 1, !tbaa !89
  %28 = ashr i16 %27, 2
  %29 = add nsw i16 %28, 44
  %30 = icmp ugt i16 %25, 127
  br i1 %30, label %57, label %31

31:                                               ; preds = %18
  %32 = icmp ugt i16 %29, 127
  br i1 %32, label %57, label %33

33:                                               ; preds = %31
  %34 = shl nuw nsw i16 %29, 1
  %35 = and i16 %34, 240
  %36 = lshr i16 %25, 3
  %37 = or disjoint i16 %35, %36
  %38 = shl nuw nsw i16 %37, 4
  %39 = and i16 %34, 14
  %40 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %38
  %41 = getelementptr inbounds nuw i8, ptr %40, i16 %39
  %42 = and i16 %24, 7
  %43 = lshr exact i16 128, %42
  %44 = load i8, ptr %41, align 1, !tbaa !6
  %45 = trunc nuw i16 %43 to i8
  %46 = or i8 %44, %45
  store i8 %46, ptr %41, align 1, !tbaa !6
  %47 = getelementptr inbounds nuw i8, ptr %41, i16 1
  %48 = load i8, ptr %47, align 1, !tbaa !6
  %49 = or i8 %48, %45
  store i8 %49, ptr %47, align 1, !tbaa !6
  %50 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %51 = icmp ult i16 %37, %50
  br i1 %51, label %52, label %53

52:                                               ; preds = %33
  store i16 %37, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %53

53:                                               ; preds = %52, %33
  %54 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %55 = icmp ugt i16 %37, %54
  br i1 %55, label %56, label %57

56:                                               ; preds = %53
  store i16 %37, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %57

57:                                               ; preds = %18, %31, %53, %56
  %58 = icmp eq i8 %20, 0
  br i1 %58, label %68, label %59

59:                                               ; preds = %57
  %60 = getelementptr i8, ptr %8, i16 %21
  %61 = load i16, ptr %60, align 1, !tbaa !87
  %62 = ashr i16 %61, 2
  %63 = add nsw i16 %62, 64
  %64 = getelementptr i8, ptr %10, i16 %21
  %65 = load i16, ptr %64, align 1, !tbaa !89
  %66 = ashr i16 %65, 2
  %67 = add nsw i16 %66, 44
  tail call fastcc void @canvas_line(i16 noundef %63, i16 noundef %67, i16 noundef %25, i16 noundef %29) #14
  br label %68

68:                                               ; preds = %59, %57
  %69 = add nuw nsw i8 %20, 1
  %70 = icmp eq i8 %69, 16
  %71 = add nuw i8 %19, 8
  br i1 %70, label %11, label %18, !llvm.loop !110

72:                                               ; preds = %11, %85
  %73 = phi i8 [ 0, %11 ], [ %90, %85 ]
  %74 = phi ptr [ %12, %11 ], [ %88, %85 ]
  %75 = phi i8 [ 0, %11 ], [ %86, %85 ]
  %76 = phi i16 [ %13, %11 ], [ %140, %85 ]
  %77 = phi i16 [ %14, %11 ], [ %139, %85 ]
  %78 = mul i8 %75, 12
  %79 = add i8 %78, -56
  %80 = zext i8 %79 to i16
  %81 = and i16 %80, 240
  %82 = and i16 %80, 12
  %83 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %82
  br label %91

84:                                               ; preds = %85
  ret void

85:                                               ; preds = %106
  %86 = add nuw nsw i8 %75, 1
  %87 = zext nneg i8 %73 to i16
  %88 = getelementptr i8, ptr %17, i16 %87
  %89 = icmp eq i8 %86, 3
  %90 = add nuw nsw i8 %73, 6
  br i1 %89, label %84, label %72, !llvm.loop !111

91:                                               ; preds = %72, %106
  %92 = phi i8 [ 0, %72 ], [ %109, %106 ]
  %93 = phi i16 [ %77, %72 ], [ %139, %106 ]
  %94 = phi i16 [ %76, %72 ], [ %140, %106 ]
  %95 = phi i8 [ 0, %72 ], [ %107, %106 ]
  %96 = phi i16 [ %76, %72 ], [ %142, %106 ]
  %97 = phi i16 [ %77, %72 ], [ %141, %106 ]
  %98 = zext nneg i8 %92 to i16
  %99 = getelementptr i8, ptr %74, i16 %98
  %100 = load i16, ptr %99, align 1, !tbaa !2
  %101 = lshr i16 %100, 5
  %102 = trunc i16 %101 to i8
  %103 = and i8 %102, 15
  %104 = mul nuw nsw i8 %95, 18
  %105 = add nuw nsw i8 %104, 36
  br label %110

106:                                              ; preds = %138
  %107 = add nuw nsw i8 %95, 1
  %108 = icmp eq i8 %107, 3
  %109 = add nuw nsw i8 %92, 2
  br i1 %108, label %85, label %91, !llvm.loop !112

110:                                              ; preds = %91, %138
  %111 = phi i16 [ %93, %91 ], [ %139, %138 ]
  %112 = phi i16 [ %94, %91 ], [ %140, %138 ]
  %113 = phi i16 [ %97, %91 ], [ %141, %138 ]
  %114 = phi i16 [ %96, %91 ], [ %142, %138 ]
  %115 = phi i8 [ 0, %91 ], [ %145, %138 ]
  %116 = phi i16 [ %96, %91 ], [ %144, %138 ]
  %117 = phi i16 [ %97, %91 ], [ %143, %138 ]
  %118 = add nuw i8 %115, %105
  %119 = icmp slt i8 %118, 0
  br i1 %119, label %138, label %120

120:                                              ; preds = %110
  %121 = lshr i8 %118, 3
  %122 = zext nneg i8 %121 to i16
  %123 = or disjoint i16 %81, %122
  %124 = shl nuw nsw i16 %123, 4
  %125 = getelementptr inbounds nuw i8, ptr %83, i16 %124
  %126 = and i8 %118, 7
  %127 = lshr exact i8 -128, %126
  %128 = load i8, ptr %125, align 1, !tbaa !6
  %129 = or i8 %128, %127
  store i8 %129, ptr %125, align 1, !tbaa !6
  %130 = icmp ult i16 %123, %116
  br i1 %130, label %131, label %132

131:                                              ; preds = %120
  store i16 %123, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %132

132:                                              ; preds = %131, %120
  %133 = phi i16 [ %123, %131 ], [ %112, %120 ]
  %134 = phi i16 [ %123, %131 ], [ %114, %120 ]
  %135 = phi i16 [ %123, %131 ], [ %116, %120 ]
  %136 = icmp ugt i16 %123, %117
  br i1 %136, label %137, label %138

137:                                              ; preds = %132
  store i16 %123, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %138

138:                                              ; preds = %110, %132, %137
  %139 = phi i16 [ %111, %110 ], [ %123, %137 ], [ %111, %132 ]
  %140 = phi i16 [ %112, %110 ], [ %133, %137 ], [ %133, %132 ]
  %141 = phi i16 [ %113, %110 ], [ %123, %137 ], [ %113, %132 ]
  %142 = phi i16 [ %114, %110 ], [ %134, %137 ], [ %134, %132 ]
  %143 = phi i16 [ %117, %110 ], [ %123, %137 ], [ %117, %132 ]
  %144 = phi i16 [ %116, %110 ], [ %135, %137 ], [ %135, %132 ]
  %145 = add nuw nsw i8 %115, 1
  %146 = xor i8 %103, %115
  %147 = icmp eq i8 %146, 8
  br i1 %147, label %106, label %110, !llvm.loop !113
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #2

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_canvas_reserve(ptr noundef readonly captures(none) %0, ptr readnone captures(none) %1) #3 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4105
  %4 = load i16, ptr %3, align 1, !tbaa !21
  %5 = lshr i16 %4, 8
  %6 = trunc nuw i16 %5 to i8
  %7 = and i8 %6, -4
  store volatile i8 %7, ptr inttoptr (i16 8457 to ptr), align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %9 = load i16, ptr %8, align 1, !tbaa !20
  %10 = lshr i16 %9, 12
  %11 = trunc nuw nsw i16 %10 to i8
  store volatile i8 %11, ptr inttoptr (i16 8460 to ptr), align 4, !tbaa !6
  %12 = load i16, ptr %8, align 1, !tbaa !20
  %13 = lshr i16 %12, 3
  %14 = add nuw nsw i16 %13, 256
  %15 = load i16, ptr %3, align 1, !tbaa !21
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %15, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %16 = getelementptr inbounds nuw i8, ptr %0, i16 4107
  %17 = load i8, ptr %16, align 1, !tbaa !22
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 4108
  br label %19

19:                                               ; preds = %2, %23
  %20 = phi i8 [ 0, %2 ], [ %24, %23 ]
  br label %26

21:                                               ; preds = %23
  %22 = load i16, ptr %8, align 1, !tbaa !20
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %22, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %45

23:                                               ; preds = %40
  %24 = add nuw nsw i8 %20, 1
  %25 = icmp eq i8 %24, 32
  br i1 %25, label %21, label %19, !llvm.loop !114

26:                                               ; preds = %19, %40
  %27 = phi i8 [ 0, %19 ], [ %42, %40 ]
  %28 = sub i8 %27, %17
  %29 = zext i8 %28 to i16
  %30 = icmp ult i8 %28, 16
  br i1 %30, label %31, label %40

31:                                               ; preds = %26
  %32 = load i8, ptr %18, align 1, !tbaa !23
  %33 = sub i8 %20, %32
  %34 = icmp ult i8 %33, 16
  br i1 %34, label %35, label %40

35:                                               ; preds = %31
  %36 = shl nuw i8 %33, 4
  %37 = zext i8 %36 to i16
  %38 = add nuw nsw i16 %13, %29
  %39 = add nuw nsw i16 %38, %37
  br label %40

40:                                               ; preds = %26, %31, %35
  %41 = phi i16 [ %39, %35 ], [ %14, %31 ], [ %14, %26 ]
  store volatile i16 %41, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %42 = add nuw nsw i8 %27, 1
  %43 = icmp eq i8 %42, 32
  br i1 %43, label %23, label %26, !llvm.loop !115

44:                                               ; preds = %45
  ret void

45:                                               ; preds = %21, %45
  %46 = phi i16 [ 0, %21 ], [ %47, %45 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %47 = add nuw nsw i16 %46, 1
  %48 = icmp eq i16 %47, 2056
  br i1 %48, label %44, label %45, !llvm.loop !116
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal void @_canvas_emit(ptr noundef %0, ptr noundef captures(none) %1) #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4099
  %4 = load i16, ptr %3, align 1, !tbaa !24
  %5 = getelementptr inbounds nuw i8, ptr %0, i16 4101
  %6 = load i16, ptr %5, align 1, !tbaa !25
  %7 = icmp ugt i16 %4, %6
  br i1 %7, label %48, label %8

8:                                                ; preds = %2
  %9 = sub nuw i16 %6, %4
  %10 = add i16 %9, -64
  %11 = icmp ult i16 %10, -65
  br i1 %11, label %12, label %14

12:                                               ; preds = %8
  %13 = add i16 %4, 63
  br label %14

14:                                               ; preds = %12, %8
  %15 = phi i16 [ 63, %12 ], [ %9, %8 ]
  %16 = phi i16 [ %13, %12 ], [ %6, %8 ]
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %18 = load i16, ptr %17, align 1, !tbaa !20
  %19 = shl i16 %4, 3
  %20 = add i16 %18, %19
  %21 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %22 = shl i16 %4, 4
  %23 = getelementptr inbounds nuw i8, ptr %21, i16 %22
  %24 = shl nsw i16 %15, 4
  %25 = add nsw i16 %24, 16
  %26 = icmp eq i16 %25, 0
  br i1 %26, label %43, label %27

27:                                               ; preds = %14
  %28 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %29 = load i8, ptr %28, align 1, !tbaa !43
  %30 = icmp ugt i8 %29, 15
  br i1 %30, label %43, label %31

31:                                               ; preds = %27
  %32 = zext nneg i8 %29 to i16
  %33 = add nuw nsw i8 %29, 1
  store i8 %33, ptr %28, align 1, !tbaa !43
  %34 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %32
  %35 = getelementptr inbounds nuw i8, ptr %34, i16 10
  store i8 0, ptr %35, align 1, !tbaa !44
  store i16 %20, ptr %34, align 1, !tbaa !46
  %36 = getelementptr inbounds nuw i8, ptr %34, i16 9
  store i8 -128, ptr %36, align 1, !tbaa !47
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 7
  store i8 24, ptr %37, align 1, !tbaa !48
  %38 = getelementptr inbounds nuw i8, ptr %34, i16 8
  store i8 1, ptr %38, align 1, !tbaa !49
  %39 = ptrtoint ptr %23 to i16
  %40 = getelementptr inbounds nuw i8, ptr %34, i16 2
  store i16 %39, ptr %40, align 1, !tbaa !50
  %41 = getelementptr inbounds nuw i8, ptr %34, i16 6
  store i8 0, ptr %41, align 1, !tbaa !51
  %42 = getelementptr inbounds nuw i8, ptr %34, i16 4
  store i16 %25, ptr %42, align 1, !tbaa !52
  br label %43

43:                                               ; preds = %14, %27, %31
  %44 = icmp ult i16 %16, %6
  br i1 %44, label %46, label %45

45:                                               ; preds = %43
  store i16 -1, ptr %3, align 1, !tbaa !24
  store i16 0, ptr %5, align 1, !tbaa !25
  br label %48

46:                                               ; preds = %43
  %47 = add nuw i16 %16, 1
  store i16 %47, ptr %3, align 1, !tbaa !24
  br label %48

48:                                               ; preds = %45, %46, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_text_reserve(ptr readnone captures(none) %0, ptr readnone captures(none) %1) #3 {
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 2048, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %4

3:                                                ; preds = %4
  ret void

4:                                                ; preds = %2, %4
  %5 = phi i16 [ 0, %2 ], [ %8, %4 ]
  %6 = getelementptr inbounds nuw [2 x i8], ptr @FONT8, i16 %5
  %7 = load i16, ptr %6, align 1, !tbaa !2
  store volatile i16 %7, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %8 = add nuw nsw i16 %5, 1
  %9 = icmp eq i16 %8, 512
  br i1 %9, label %3, label %4, !llvm.loop !117
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(argmem: readwrite)
define internal void @_text_emit(ptr noundef %0, ptr noundef captures(none) %1) #5 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 135
  %4 = load i8, ptr %3, align 1, !tbaa !31
  %5 = zext i8 %4 to i16
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %7 = getelementptr i8, ptr %0, i16 7
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %9 = getelementptr i8, ptr %0, i16 5
  br label %11

10:                                               ; preds = %42
  store i8 0, ptr %3, align 1, !tbaa !31
  ret void

11:                                               ; preds = %2, %42
  %12 = phi i8 [ 0, %2 ], [ %43, %42 ]
  %13 = phi i1 [ true, %2 ], [ false, %42 ]
  %14 = phi i8 [ 0, %2 ], [ 1, %42 ]
  %15 = zext nneg i8 %14 to i16
  %16 = shl nuw nsw i16 1, %15
  %17 = and i16 %16, %5
  %18 = icmp eq i16 %17, 0
  br i1 %18, label %42, label %19

19:                                               ; preds = %11
  %20 = load i8, ptr %6, align 1, !tbaa !43
  %21 = icmp ugt i8 %20, 15
  br i1 %21, label %42, label %22

22:                                               ; preds = %19
  %23 = zext i8 %12 to i16
  %24 = getelementptr i8, ptr %7, i16 %23
  %25 = load i16, ptr %8, align 1, !tbaa !29
  %26 = getelementptr i8, ptr %9, i16 %15
  %27 = load i8, ptr %26, align 1, !tbaa !6
  %28 = zext i8 %27 to i16
  %29 = shl nuw nsw i16 %28, 5
  %30 = add i16 %29, %25
  %31 = zext nneg i8 %20 to i16
  %32 = add nuw nsw i8 %20, 1
  store i8 %32, ptr %6, align 1, !tbaa !43
  %33 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %31
  %34 = getelementptr inbounds nuw i8, ptr %33, i16 10
  store i8 0, ptr %34, align 1, !tbaa !44
  store i16 %30, ptr %33, align 1, !tbaa !46
  %35 = getelementptr inbounds nuw i8, ptr %33, i16 9
  store i8 -128, ptr %35, align 1, !tbaa !47
  %36 = getelementptr inbounds nuw i8, ptr %33, i16 7
  store i8 24, ptr %36, align 1, !tbaa !48
  %37 = getelementptr inbounds nuw i8, ptr %33, i16 8
  store i8 1, ptr %37, align 1, !tbaa !49
  %38 = ptrtoint ptr %24 to i16
  %39 = getelementptr inbounds nuw i8, ptr %33, i16 2
  store i16 %38, ptr %39, align 1, !tbaa !50
  %40 = getelementptr inbounds nuw i8, ptr %33, i16 6
  store i8 0, ptr %40, align 1, !tbaa !51
  %41 = getelementptr inbounds nuw i8, ptr %33, i16 4
  store i16 64, ptr %41, align 1, !tbaa !52
  br label %42

42:                                               ; preds = %22, %19, %11
  %43 = add nuw i8 %12, 64
  br i1 %13, label %11, label %10, !llvm.loop !118
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_title_reserve(ptr noundef %0, ptr readnone captures(none) %1) #3 {
  store volatile i8 80, ptr inttoptr (i16 8456 to ptr), align 8, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !6
  store volatile i8 112, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -1, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 127, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -124, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 4096, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %3

3:                                                ; preds = %2, %16
  %4 = phi ptr [ @FONT8, %2 ], [ %18, %16 ]
  %5 = phi i16 [ 0, %2 ], [ %17, %16 ]
  br label %7

6:                                                ; preds = %16
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 5120, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %24

7:                                                ; preds = %3, %7
  %8 = phi i8 [ 0, %3 ], [ %15, %7 ]
  %9 = phi i8 [ 0, %3 ], [ %13, %7 ]
  %10 = zext nneg i8 %8 to i16
  %11 = getelementptr i8, ptr %4, i16 %10
  %12 = load i16, ptr %11, align 1, !tbaa !2
  store volatile i16 %12, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %13 = add nuw nsw i8 %9, 1
  %14 = icmp eq i8 %13, 8
  %15 = add nuw nsw i8 %8, 2
  br i1 %14, label %20, label %7, !llvm.loop !119

16:                                               ; preds = %20
  %17 = add nuw nsw i16 %5, 1
  %18 = getelementptr i8, ptr %4, i16 16
  %19 = icmp eq i16 %17, 64
  br i1 %19, label %6, label %3, !llvm.loop !120

20:                                               ; preds = %7, %20
  %21 = phi i8 [ %22, %20 ], [ 0, %7 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %22 = add nuw nsw i8 %21, 1
  %23 = icmp eq i8 %22, 8
  br i1 %23, label %16, label %20, !llvm.loop !121

24:                                               ; preds = %6, %33
  %25 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 16), %6 ], [ %36, %33 ]
  %26 = phi ptr [ @FONT16, %6 ], [ %35, %33 ]
  %27 = phi i16 [ 0, %6 ], [ %34, %33 ]
  br label %29

28:                                               ; preds = %33
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 20480, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %66

29:                                               ; preds = %24, %47
  %30 = phi i8 [ 0, %24 ], [ %52, %47 ]
  %31 = phi ptr [ %26, %24 ], [ %50, %47 ]
  %32 = phi i8 [ 0, %24 ], [ %48, %47 ]
  br label %38

33:                                               ; preds = %47
  %34 = add nuw nsw i16 %27, 1
  %35 = getelementptr i8, ptr %26, i16 64
  %36 = getelementptr i8, ptr %25, i16 64
  %37 = icmp eq i16 %34, 64
  br i1 %37, label %28, label %24, !llvm.loop !122

38:                                               ; preds = %29, %38
  %39 = phi i8 [ 0, %29 ], [ %46, %38 ]
  %40 = phi i8 [ 0, %29 ], [ %44, %38 ]
  %41 = zext nneg i8 %39 to i16
  %42 = getelementptr i8, ptr %31, i16 %41
  %43 = load i16, ptr %42, align 1, !tbaa !2
  store volatile i16 %43, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %44 = add nuw nsw i8 %40, 1
  %45 = icmp eq i8 %44, 8
  %46 = add nuw nsw i8 %39, 2
  br i1 %45, label %53, label %38, !llvm.loop !123

47:                                               ; preds = %53
  %48 = add nuw nsw i8 %32, 1
  %49 = zext nneg i8 %30 to i16
  %50 = getelementptr i8, ptr %25, i16 %49
  %51 = icmp eq i8 %48, 4
  %52 = add nuw nsw i8 %30, 16
  br i1 %51, label %33, label %29, !llvm.loop !124

53:                                               ; preds = %38, %53
  %54 = phi i8 [ %55, %53 ], [ 0, %38 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %55 = add nuw nsw i8 %54, 1
  %56 = icmp eq i8 %55, 8
  br i1 %56, label %47, label %53, !llvm.loop !125

57:                                               ; preds = %66
  %58 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %59 = load ptr, ptr %58, align 1, !tbaa !61
  %60 = icmp eq ptr %59, null
  br i1 %60, label %79, label %61

61:                                               ; preds = %57
  %62 = load i8, ptr %59, align 1, !tbaa !6
  %63 = icmp eq i8 %62, 0
  br i1 %63, label %79, label %64

64:                                               ; preds = %61
  %65 = getelementptr i8, ptr %59, i16 1
  br label %70

66:                                               ; preds = %28, %66
  %67 = phi i16 [ 0, %28 ], [ %68, %66 ]
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %68 = add nuw nsw i16 %67, 1
  %69 = icmp eq i16 %68, 1024
  br i1 %69, label %57, label %66, !llvm.loop !126

70:                                               ; preds = %64, %70
  %71 = phi i8 [ %72, %70 ], [ 0, %64 ]
  %72 = add nuw nsw i8 %71, 1
  %73 = zext nneg i8 %71 to i16
  %74 = getelementptr i8, ptr %65, i16 %73
  %75 = load i8, ptr %74, align 1, !tbaa !6
  %76 = icmp ne i8 %75, 0
  %77 = icmp samesign ult i8 %71, 31
  %78 = select i1 %76, i1 %77, i1 false
  br i1 %78, label %70, label %79, !llvm.loop !127

79:                                               ; preds = %70, %61, %57
  %80 = phi i8 [ 0, %57 ], [ 0, %61 ], [ %72, %70 ]
  %81 = zext nneg i8 %80 to i16
  %82 = sub nuw nsw i16 32, %81
  %83 = lshr i16 %82, 1
  %84 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %85 = load i16, ptr %84, align 1, !tbaa !67
  %86 = shl i16 %85, 2
  %87 = and i16 %86, -32
  %88 = add i16 %87, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %88, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %89 = trunc nuw nsw i16 %83 to i8
  %90 = add nuw nsw i8 %80, %89
  %91 = sub nsw i16 0, %83
  %92 = getelementptr i8, ptr %59, i16 %91
  br label %105

93:                                               ; preds = %128
  %94 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %95 = load ptr, ptr %94, align 1, !tbaa !63
  %96 = getelementptr inbounds nuw i8, ptr %0, i16 11
  %97 = load i8, ptr %96, align 1, !tbaa !64
  %98 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %99 = load i16, ptr %98, align 1, !tbaa !68
  %100 = lshr i16 %99, 3
  %101 = trunc i16 %100 to i8
  tail call fastcc void @_title_write16(ptr noundef %95, i8 noundef zeroext %97, i8 noundef zeroext %101) #14
  %102 = getelementptr inbounds nuw i8, ptr %0, i16 9
  %103 = load ptr, ptr %102, align 1, !tbaa !65
  %104 = icmp eq ptr %103, null
  br i1 %104, label %139, label %132

105:                                              ; preds = %79, %128
  %106 = phi i8 [ 0, %79 ], [ %130, %128 ]
  %107 = zext nneg i8 %106 to i16
  br i1 %60, label %128, label %108

108:                                              ; preds = %105
  %109 = icmp samesign ugt i16 %83, %107
  br i1 %109, label %128, label %110

110:                                              ; preds = %108
  %111 = icmp ult i8 %106, %90
  br i1 %111, label %112, label %128

112:                                              ; preds = %110
  %113 = getelementptr i8, ptr %92, i16 %107
  %114 = load i8, ptr %113, align 1, !tbaa !6
  %115 = icmp ugt i8 %114, 96
  br i1 %115, label %116, label %120

116:                                              ; preds = %112
  %117 = icmp ult i8 %114, 123
  br i1 %117, label %118, label %128

118:                                              ; preds = %116
  %119 = add nsw i8 %114, -32
  br label %124

120:                                              ; preds = %112
  %121 = icmp samesign ugt i8 %114, 31
  br i1 %121, label %122, label %128

122:                                              ; preds = %120
  %123 = icmp eq i8 %114, 96
  br i1 %123, label %128, label %124

124:                                              ; preds = %122, %118
  %125 = phi i8 [ %119, %118 ], [ %114, %122 ]
  %126 = zext nneg i8 %125 to i16
  %127 = add nuw nsw i16 %126, 7136
  br label %128

128:                                              ; preds = %124, %122, %120, %116, %105, %108, %110
  %129 = phi i16 [ 7168, %105 ], [ 7168, %110 ], [ 7168, %108 ], [ %127, %124 ], [ 7168, %122 ], [ 7168, %120 ], [ 7168, %116 ]
  store volatile i16 %129, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %130 = add nuw nsw i8 %106, 1
  %131 = icmp eq i8 %130, 32
  br i1 %131, label %93, label %105, !llvm.loop !128

132:                                              ; preds = %93
  %133 = getelementptr inbounds nuw i8, ptr %0, i16 12
  %134 = load i8, ptr %133, align 1, !tbaa !66
  %135 = load i16, ptr %98, align 1, !tbaa !68
  %136 = lshr i16 %135, 3
  %137 = trunc i16 %136 to i8
  %138 = add i8 %137, 2
  tail call fastcc void @_title_write16(ptr noundef nonnull %103, i8 noundef zeroext %134, i8 noundef zeroext %138) #14
  br label %139

139:                                              ; preds = %132, %93
  %140 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 -128, ptr %140, align 1, !tbaa !105
  %141 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 3584, ptr %141, align 1, !tbaa !129
  %142 = getelementptr inbounds nuw i8, ptr %0, i16 23
  store i16 0, ptr %142, align 1, !tbaa !130
  %143 = load ptr, ptr %58, align 1, !tbaa !61
  %144 = icmp eq ptr %143, null
  br i1 %144, label %167, label %145

145:                                              ; preds = %139
  %146 = load i8, ptr %143, align 1, !tbaa !6
  %147 = icmp eq i8 %146, 0
  br i1 %147, label %150, label %148

148:                                              ; preds = %145
  %149 = getelementptr i8, ptr %143, i16 1
  br label %158

150:                                              ; preds = %158, %145
  %151 = phi i8 [ 0, %145 ], [ %160, %158 ]
  %152 = zext nneg i8 %151 to i16
  %153 = shl nuw nsw i16 %152, 2
  %154 = sub nuw nsw i16 128, %153
  %155 = and i16 %154, 248
  %156 = add nsw i16 %153, -128
  %157 = add nsw i16 %156, %155
  br label %167

158:                                              ; preds = %158, %148
  %159 = phi i8 [ %160, %158 ], [ 0, %148 ]
  %160 = add nuw nsw i8 %159, 1
  %161 = zext nneg i8 %159 to i16
  %162 = getelementptr i8, ptr %149, i16 %161
  %163 = load i8, ptr %162, align 1, !tbaa !6
  %164 = icmp ne i8 %163, 0
  %165 = icmp samesign ult i8 %159, 31
  %166 = select i1 %164, i1 %165, i1 false
  br i1 %166, label %158, label %150, !llvm.loop !131

167:                                              ; preds = %139, %150
  %168 = phi i16 [ %157, %150 ], [ 0, %139 ]
  %169 = getelementptr inbounds nuw i8, ptr %0, i16 26
  store i16 %168, ptr %169, align 1, !tbaa !132
  store volatile i8 -112, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  %170 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %171 = getelementptr inbounds nuw i8, ptr %0, i16 89
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef -8, i16 noundef 224, ptr noundef nonnull %170, ptr noundef nonnull %171) #14
  %172 = getelementptr inbounds nuw i8, ptr %0, i16 88
  store i8 0, ptr %172, align 1, !tbaa !133
  store volatile i8 2, ptr inttoptr (i16 17200 to ptr), align 16, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 17201 to ptr), align 1, !tbaa !6
  %173 = ptrtoint ptr %170 to i16
  %174 = trunc i16 %173 to i8
  store volatile i8 %174, ptr inttoptr (i16 17202 to ptr), align 2, !tbaa !6
  %175 = lshr i16 %173, 8
  %176 = trunc nuw i16 %175 to i8
  store volatile i8 %176, ptr inttoptr (i16 17203 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17204 to ptr), align 4, !tbaa !6
  %177 = getelementptr inbounds nuw i8, ptr %0, i16 139
  store i8 0, ptr %177, align 1, !tbaa !133
  store volatile i8 2, ptr inttoptr (i16 17216 to ptr), align 64, !tbaa !6
  store volatile i8 15, ptr inttoptr (i16 17217 to ptr), align 1, !tbaa !6
  %178 = ptrtoint ptr %171 to i16
  %179 = trunc i16 %178 to i8
  store volatile i8 %179, ptr inttoptr (i16 17218 to ptr), align 2, !tbaa !6
  %180 = lshr i16 %178, 8
  %181 = trunc nuw i16 %180 to i8
  store volatile i8 %181, ptr inttoptr (i16 17219 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17220 to ptr), align 4, !tbaa !6
  %182 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 2, ptr %182, align 1, !tbaa !60
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal void @_title_emit(ptr noundef %0, ptr noundef captures(none) %1) #6 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 29
  %4 = load i8, ptr %3, align 1, !tbaa !71
  %5 = icmp eq i8 %4, 0
  br i1 %5, label %188, label %6

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 30
  %8 = load i8, ptr %7, align 1, !tbaa !74
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %39, label %10

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 25
  %12 = load i8, ptr %11, align 1, !tbaa !75
  %13 = icmp ugt i8 %12, -6
  br i1 %13, label %16, label %14

14:                                               ; preds = %10
  %15 = add nuw i8 %12, 4
  br label %16

16:                                               ; preds = %10, %14
  %17 = phi i8 [ %15, %14 ], [ -1, %10 ]
  store i8 %17, ptr %11, align 1, !tbaa !75
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %19 = load i16, ptr %18, align 1, !tbaa !67
  %20 = xor i8 %17, -1
  %21 = zext i8 %20 to i16
  %22 = mul nuw i16 %21, %21
  %23 = lshr i16 %22, 8
  %24 = sub nuw nsw i16 256, %23
  %25 = add nsw i16 %19, 8
  %26 = mul nsw i16 %24, %25
  %27 = ashr i16 %26, 4
  %28 = and i16 %27, -16
  %29 = add nsw i16 %28, -128
  %30 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 %29, ptr %30, align 1, !tbaa !105
  %31 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %32 = load i16, ptr %31, align 1, !tbaa !68
  %33 = add nsw i16 %32, -224
  %34 = mul nsw i16 %33, %24
  %35 = ashr i16 %34, 4
  %36 = and i16 %35, -16
  %37 = add nsw i16 %36, 3584
  %38 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 %37, ptr %38, align 1, !tbaa !129
  br label %64

39:                                               ; preds = %6
  %40 = getelementptr inbounds nuw i8, ptr %0, i16 31
  %41 = load i8, ptr %40, align 1, !tbaa !72
  %42 = icmp eq i8 %41, 0
  br i1 %42, label %43, label %48

43:                                               ; preds = %39
  %44 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %45 = load i16, ptr %44, align 1, !tbaa !105
  %46 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %47 = load i16, ptr %46, align 1, !tbaa !129
  br label %64

48:                                               ; preds = %39
  %49 = getelementptr inbounds nuw i8, ptr %0, i16 23
  %50 = load i16, ptr %49, align 1, !tbaa !130
  %51 = add nsw i16 %50, 2
  store i16 %51, ptr %49, align 1, !tbaa !130
  %52 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %53 = load i16, ptr %52, align 1, !tbaa !105
  %54 = add nsw i16 %53, %51
  store i16 %54, ptr %52, align 1, !tbaa !105
  %55 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %56 = load i16, ptr %55, align 1, !tbaa !129
  %57 = add nsw i16 %56, %51
  store i16 %57, ptr %55, align 1, !tbaa !129
  %58 = icmp sgt i16 %54, 4480
  br i1 %58, label %59, label %60

59:                                               ; preds = %48
  store i16 4480, ptr %52, align 1, !tbaa !105
  br label %60

60:                                               ; preds = %59, %48
  %61 = phi i16 [ 4480, %59 ], [ %54, %48 ]
  %62 = icmp sgt i16 %57, 4736
  br i1 %62, label %63, label %64

63:                                               ; preds = %60
  store i16 4736, ptr %55, align 1, !tbaa !129
  br label %64

64:                                               ; preds = %43, %63, %60, %16
  %65 = phi i16 [ %47, %43 ], [ 4736, %63 ], [ %57, %60 ], [ %37, %16 ]
  %66 = phi i16 [ %45, %43 ], [ %61, %63 ], [ %61, %60 ], [ %29, %16 ]
  %67 = ashr i16 %66, 4
  %68 = ashr i16 %65, 4
  %69 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %70 = getelementptr inbounds nuw i8, ptr %0, i16 88
  %71 = load i8, ptr %70, align 1, !tbaa !133
  %72 = xor i8 %71, 1
  %73 = zext i8 %72 to i16
  %74 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %73
  %75 = getelementptr inbounds nuw i8, ptr %0, i16 89
  %76 = getelementptr inbounds nuw i8, ptr %0, i16 139
  %77 = load i8, ptr %76, align 1, !tbaa !133
  %78 = xor i8 %77, 1
  %79 = zext i8 %78 to i16
  %80 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %79
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef %67, i16 noundef %68, ptr noundef nonnull %74, ptr noundef nonnull %80) #14
  %81 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %82 = load i8, ptr %81, align 1, !tbaa !43
  %83 = icmp ugt i8 %82, 15
  br i1 %83, label %109, label %84

84:                                               ; preds = %64
  %85 = load i8, ptr %70, align 1, !tbaa !133
  %86 = xor i8 %85, 1
  %87 = zext i8 %86 to i16
  %88 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %87
  %89 = ptrtoint ptr %88 to i16
  %90 = zext nneg i8 %82 to i16
  %91 = add nuw nsw i8 %82, 1
  store i8 %91, ptr %81, align 1, !tbaa !43
  %92 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %90
  %93 = getelementptr inbounds nuw i8, ptr %92, i16 10
  store i8 4, ptr %93, align 1, !tbaa !44
  store i16 17202, ptr %92, align 1, !tbaa !46
  %94 = getelementptr inbounds nuw i8, ptr %92, i16 2
  store i16 %89, ptr %94, align 1, !tbaa !50
  %95 = getelementptr inbounds nuw i8, ptr %92, i16 4
  store i16 0, ptr %95, align 1, !tbaa !52
  store i8 %86, ptr %70, align 1, !tbaa !133
  %96 = icmp eq i8 %82, 15
  br i1 %96, label %109, label %97

97:                                               ; preds = %84
  %98 = load i8, ptr %76, align 1, !tbaa !133
  %99 = xor i8 %98, 1
  %100 = zext i8 %99 to i16
  %101 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %100
  %102 = ptrtoint ptr %101 to i16
  %103 = zext nneg i8 %91 to i16
  %104 = add nuw nsw i8 %82, 2
  store i8 %104, ptr %81, align 1, !tbaa !43
  %105 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %103
  %106 = getelementptr inbounds nuw i8, ptr %105, i16 10
  store i8 4, ptr %106, align 1, !tbaa !44
  store i16 17218, ptr %105, align 1, !tbaa !46
  %107 = getelementptr inbounds nuw i8, ptr %105, i16 2
  store i16 %102, ptr %107, align 1, !tbaa !50
  %108 = getelementptr inbounds nuw i8, ptr %105, i16 4
  store i16 0, ptr %108, align 1, !tbaa !52
  store i8 %99, ptr %76, align 1, !tbaa !133
  br label %109

109:                                              ; preds = %64, %84, %97
  %110 = phi i8 [ %82, %64 ], [ 16, %84 ], [ %104, %97 ]
  %111 = getelementptr inbounds nuw i8, ptr %0, i16 28
  %112 = load i8, ptr %111, align 1, !tbaa !70
  %113 = add i8 %112, 1
  store i8 %113, ptr %111, align 1, !tbaa !70
  %114 = getelementptr inbounds nuw i8, ptr %0, i16 32
  %115 = load i8, ptr %114, align 1, !tbaa !73
  %116 = icmp eq i8 %115, 0
  br i1 %116, label %117, label %155

117:                                              ; preds = %109
  %118 = shl i8 %113, 1
  %119 = icmp sgt i8 %118, -1
  br i1 %119, label %122, label %120

120:                                              ; preds = %117
  %121 = xor i8 %118, -1
  br label %122

122:                                              ; preds = %117, %120
  %123 = phi i8 [ %121, %120 ], [ %118, %117 ]
  %124 = lshr i8 %123, 4
  %125 = add nuw nsw i8 %124, 24
  %126 = zext nneg i8 %125 to i16
  %127 = mul nuw nsw i16 %126, 1057
  %128 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 %127, ptr %128, align 1, !tbaa !76
  %129 = add i8 %118, -86
  %130 = icmp sgt i8 %129, -1
  br i1 %130, label %133, label %131

131:                                              ; preds = %122
  %132 = sub nsw i8 85, %118
  br label %133

133:                                              ; preds = %122, %131
  %134 = phi i8 [ %132, %131 ], [ %129, %122 ]
  %135 = lshr i8 %134, 2
  %136 = zext nneg i8 %135 to i16
  %137 = shl nuw nsw i16 %136, 10
  %138 = add i8 %118, 85
  %139 = icmp sgt i8 %138, -1
  br i1 %139, label %142, label %140

140:                                              ; preds = %133
  %141 = sub nuw i8 -86, %118
  br label %142

142:                                              ; preds = %133, %140
  %143 = phi i8 [ %141, %140 ], [ %138, %133 ]
  %144 = lshr i8 %143, 2
  %145 = zext nneg i8 %144 to i16
  %146 = shl nuw nsw i16 %145, 5
  %147 = add nuw nsw i16 %146, %137
  br i1 %119, label %150, label %148

148:                                              ; preds = %142
  %149 = xor i8 %118, -1
  br label %150

150:                                              ; preds = %142, %148
  %151 = phi i8 [ %149, %148 ], [ %118, %142 ]
  %152 = lshr i8 %151, 2
  %153 = zext nneg i8 %152 to i16
  %154 = add nuw nsw i16 %147, %153
  br label %157

155:                                              ; preds = %109
  %156 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 29596, ptr %156, align 1, !tbaa !76
  br label %157

157:                                              ; preds = %155, %150
  %158 = phi i16 [ 0, %155 ], [ %154, %150 ]
  %159 = getelementptr inbounds nuw i8, ptr %0, i16 36
  store i16 %158, ptr %159, align 1, !tbaa !77
  %160 = icmp ugt i8 %110, 15
  br i1 %160, label %188, label %161

161:                                              ; preds = %157
  %162 = getelementptr inbounds nuw i8, ptr %0, i16 34
  %163 = zext nneg i8 %110 to i16
  %164 = add nuw nsw i8 %110, 1
  store i8 %164, ptr %81, align 1, !tbaa !43
  %165 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %163
  %166 = getelementptr inbounds nuw i8, ptr %165, i16 10
  store i8 1, ptr %166, align 1, !tbaa !44
  store i16 113, ptr %165, align 1, !tbaa !46
  %167 = getelementptr inbounds nuw i8, ptr %165, i16 9
  store i8 0, ptr %167, align 1, !tbaa !47
  %168 = getelementptr inbounds nuw i8, ptr %165, i16 7
  store i8 34, ptr %168, align 1, !tbaa !48
  %169 = getelementptr inbounds nuw i8, ptr %165, i16 8
  store i8 0, ptr %169, align 1, !tbaa !49
  %170 = ptrtoint ptr %162 to i16
  %171 = getelementptr inbounds nuw i8, ptr %165, i16 2
  store i16 %170, ptr %171, align 1, !tbaa !50
  %172 = getelementptr inbounds nuw i8, ptr %165, i16 6
  store i8 0, ptr %172, align 1, !tbaa !51
  %173 = getelementptr inbounds nuw i8, ptr %165, i16 4
  store i16 2, ptr %173, align 1, !tbaa !52
  %174 = icmp eq i8 %110, 15
  br i1 %174, label %188, label %175

175:                                              ; preds = %161
  %176 = getelementptr inbounds nuw i8, ptr %0, i16 36
  %177 = zext nneg i8 %164 to i16
  %178 = add nuw nsw i8 %110, 2
  store i8 %178, ptr %81, align 1, !tbaa !43
  %179 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %177
  %180 = getelementptr inbounds nuw i8, ptr %179, i16 10
  store i8 1, ptr %180, align 1, !tbaa !44
  store i16 0, ptr %179, align 1, !tbaa !46
  %181 = getelementptr inbounds nuw i8, ptr %179, i16 9
  store i8 0, ptr %181, align 1, !tbaa !47
  %182 = getelementptr inbounds nuw i8, ptr %179, i16 7
  store i8 34, ptr %182, align 1, !tbaa !48
  %183 = getelementptr inbounds nuw i8, ptr %179, i16 8
  store i8 0, ptr %183, align 1, !tbaa !49
  %184 = ptrtoint ptr %176 to i16
  %185 = getelementptr inbounds nuw i8, ptr %179, i16 2
  store i16 %184, ptr %185, align 1, !tbaa !50
  %186 = getelementptr inbounds nuw i8, ptr %179, i16 6
  store i8 0, ptr %186, align 1, !tbaa !51
  %187 = getelementptr inbounds nuw i8, ptr %179, i16 4
  store i16 2, ptr %187, align 1, !tbaa !52
  br label %188

188:                                              ; preds = %157, %175, %161, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @_title_write16(ptr noundef readonly captures(address_is_null) %0, i8 noundef zeroext %1, i8 noundef zeroext %2) unnamed_addr #3 {
  %4 = zext i8 %1 to i16
  %5 = shl nuw nsw i16 %4, 1
  %6 = and i16 %5, 254
  %7 = sub nsw i16 32, %6
  %8 = lshr exact i16 %7, 1
  %9 = zext i8 %2 to i16
  %10 = icmp eq ptr %0, null
  %11 = and i16 %8, 255
  %12 = add nuw i16 %8, %5
  %13 = and i16 %12, 255
  br label %15

14:                                               ; preds = %23
  ret void

15:                                               ; preds = %3, %23
  %16 = phi i1 [ true, %3 ], [ false, %23 ]
  %17 = phi i8 [ 0, %3 ], [ 1, %23 ]
  %18 = zext nneg i8 %17 to i16
  %19 = add nuw nsw i16 %18, %9
  %20 = shl nuw nsw i16 %19, 5
  %21 = add nuw nsw i16 %20, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %21, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %22 = select i1 %16, i16 7168, i16 7170
  br label %24

23:                                               ; preds = %56
  br i1 %16, label %15, label %14, !llvm.loop !134

24:                                               ; preds = %15, %56
  %25 = phi i8 [ 0, %15 ], [ %58, %56 ]
  %26 = zext nneg i8 %25 to i16
  br i1 %10, label %56, label %27

27:                                               ; preds = %24
  %28 = icmp samesign ugt i16 %11, %26
  br i1 %28, label %56, label %29

29:                                               ; preds = %27
  %30 = icmp samesign ugt i16 %13, %26
  br i1 %30, label %31, label %56

31:                                               ; preds = %29
  %32 = sub nsw i16 %26, %11
  %33 = lshr i16 %32, 1
  %34 = and i16 %33, 255
  %35 = getelementptr inbounds nuw i8, ptr %0, i16 %34
  %36 = load i8, ptr %35, align 1, !tbaa !6
  %37 = icmp ugt i8 %36, 96
  br i1 %37, label %38, label %42

38:                                               ; preds = %31
  %39 = icmp ult i8 %36, 123
  br i1 %39, label %40, label %51

40:                                               ; preds = %38
  %41 = add nsw i8 %36, -32
  br label %46

42:                                               ; preds = %31
  %43 = icmp samesign ugt i8 %36, 31
  br i1 %43, label %44, label %51

44:                                               ; preds = %42
  %45 = icmp eq i8 %36, 96
  br i1 %45, label %51, label %46

46:                                               ; preds = %44, %40
  %47 = phi i8 [ %41, %40 ], [ %36, %44 ]
  %48 = zext nneg i8 %47 to i16
  %49 = shl nuw nsw i16 %48, 2
  %50 = add nsw i16 %49, -64
  br label %51

51:                                               ; preds = %38, %42, %44, %46
  %52 = phi i16 [ %50, %46 ], [ 64, %44 ], [ 64, %42 ], [ 64, %38 ]
  %53 = and i16 %32, 1
  %54 = or disjoint i16 %22, %53
  %55 = or disjoint i16 %54, %52
  br label %56

56:                                               ; preds = %51, %29, %27, %24
  %57 = phi i16 [ %55, %51 ], [ 7168, %29 ], [ 7168, %27 ], [ 7168, %24 ]
  store volatile i16 %57, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %58 = add nuw nsw i8 %25, 1
  %59 = icmp eq i8 %58, 32
  br i1 %59, label %23, label %24, !llvm.loop !135
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_build(ptr noundef readonly captures(none) %0, i16 noundef range(i16 -2048, 2048) %1, i16 noundef range(i16 -2048, 2048) %2, ptr noundef %3, ptr noundef %4) unnamed_addr #6 {
  %6 = alloca %struct.HScrollW, align 1
  %7 = alloca %struct.HScrollW, align 1
  %8 = alloca i16, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #15
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #15
  store i16 0, ptr %8, align 1, !tbaa !2
  store ptr %3, ptr %6, align 1, !tbaa !136
  %9 = getelementptr inbounds nuw i8, ptr %6, i16 2
  store i8 0, ptr %9, align 1, !tbaa !138
  store ptr %4, ptr %7, align 1, !tbaa !136
  %10 = getelementptr inbounds nuw i8, ptr %7, i16 2
  store i8 0, ptr %10, align 1, !tbaa !138
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %12 = load i16, ptr %11, align 1, !tbaa !67
  %13 = getelementptr inbounds nuw i8, ptr %0, i16 26
  %14 = load i16, ptr %13, align 1, !tbaa !132
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %1, i16 noundef 8, i16 noundef %12, i16 noundef %14) #14
  %15 = getelementptr inbounds nuw i8, ptr %0, i16 17
  %16 = load i16, ptr %15, align 1, !tbaa !69
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %18 = load i16, ptr %17, align 1, !tbaa !68
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %2, i16 noundef %16, i16 noundef %18, i16 noundef 0) #14
  %19 = load i16, ptr %8, align 1, !tbaa !2
  call fastcc void @_title_blank(ptr noundef %6, ptr noundef %7, i16 noundef %19, i16 noundef 224) #14
  %20 = load ptr, ptr %6, align 1, !tbaa !136
  %21 = load i8, ptr %9, align 1, !tbaa !138
  %22 = zext i8 %21 to i16
  %23 = getelementptr inbounds nuw i8, ptr %20, i16 %22
  store i8 0, ptr %23, align 1, !tbaa !6
  %24 = load ptr, ptr %7, align 1, !tbaa !136
  %25 = load i8, ptr %10, align 1, !tbaa !138
  %26 = zext i8 %25 to i16
  %27 = getelementptr inbounds nuw i8, ptr %24, i16 %26
  store i8 0, ptr %27, align 1, !tbaa !6
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #15
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #15
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #15
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_glyph_band(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, ptr noundef nonnull captures(none) %2, i16 noundef range(i16 -2048, 2048) %3, i16 noundef %4, i16 noundef %5, i16 noundef %6) unnamed_addr #6 {
  %8 = add nsw i16 %3, -2
  %9 = add nsw i16 %4, %3
  %10 = add nsw i16 %9, 2
  %11 = load i16, ptr %2, align 1, !tbaa !2
  %12 = icmp slt i16 %8, %11
  br i1 %12, label %13, label %14

13:                                               ; preds = %7
  br label %14

14:                                               ; preds = %13, %7
  %15 = phi i16 [ %11, %13 ], [ %8, %7 ]
  %16 = icmp sgt i16 %9, 222
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  br label %18

18:                                               ; preds = %17, %14
  %19 = phi i16 [ 224, %17 ], [ %10, %14 ]
  %20 = icmp sgt i16 %19, %15
  br i1 %20, label %21, label %92

21:                                               ; preds = %18
  tail call fastcc void @_title_blank(ptr noundef %0, ptr noundef %1, i16 noundef %11, i16 noundef %15) #14
  %22 = sub nsw i16 %19, %15
  %23 = trunc i16 %22 to i8
  %24 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %25 = icmp eq i8 %23, 0
  br i1 %25, label %91, label %26

26:                                               ; preds = %21
  %27 = sub nsw i16 %5, %3
  %28 = and i16 %22, 255
  %29 = trunc i16 %27 to i8
  %30 = lshr i16 %27, 8
  %31 = trunc nuw i16 %30 to i8
  br label %32

32:                                               ; preds = %40, %26
  %33 = phi i16 [ %28, %26 ], [ %57, %40 ]
  %34 = load i8, ptr %24, align 1, !tbaa !138
  %35 = icmp ult i8 %34, 22
  br i1 %35, label %36, label %59

36:                                               ; preds = %32
  %37 = icmp ugt i16 %33, 127
  br i1 %37, label %40, label %38

38:                                               ; preds = %36
  %39 = trunc nuw nsw i16 %33 to i8
  br label %40

40:                                               ; preds = %38, %36
  %41 = phi i8 [ %39, %38 ], [ 127, %36 ]
  %42 = load ptr, ptr %0, align 1, !tbaa !136
  %43 = add nuw nsw i8 %34, 1
  store i8 %43, ptr %24, align 1, !tbaa !138
  %44 = zext nneg i8 %34 to i16
  %45 = getelementptr inbounds nuw i8, ptr %42, i16 %44
  store i8 %41, ptr %45, align 1, !tbaa !6
  %46 = load ptr, ptr %0, align 1, !tbaa !136
  %47 = load i8, ptr %24, align 1, !tbaa !138
  %48 = add i8 %47, 1
  store i8 %48, ptr %24, align 1, !tbaa !138
  %49 = zext i8 %47 to i16
  %50 = getelementptr inbounds nuw i8, ptr %46, i16 %49
  store i8 %29, ptr %50, align 1, !tbaa !6
  %51 = load ptr, ptr %0, align 1, !tbaa !136
  %52 = load i8, ptr %24, align 1, !tbaa !138
  %53 = add i8 %52, 1
  store i8 %53, ptr %24, align 1, !tbaa !138
  %54 = zext i8 %52 to i16
  %55 = getelementptr inbounds nuw i8, ptr %51, i16 %54
  store i8 %31, ptr %55, align 1, !tbaa !6
  %56 = zext nneg i8 %41 to i16
  %57 = sub i16 %33, %56
  %58 = icmp eq i16 %57, 0
  br i1 %58, label %59, label %32, !llvm.loop !139

59:                                               ; preds = %32, %40
  %60 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %61 = trunc i16 %6 to i8
  %62 = lshr i16 %6, 8
  %63 = trunc nuw i16 %62 to i8
  br label %64

64:                                               ; preds = %72, %59
  %65 = phi i16 [ %28, %59 ], [ %89, %72 ]
  %66 = load i8, ptr %60, align 1, !tbaa !138
  %67 = icmp ult i8 %66, 22
  br i1 %67, label %68, label %91

68:                                               ; preds = %64
  %69 = icmp ugt i16 %65, 127
  br i1 %69, label %72, label %70

70:                                               ; preds = %68
  %71 = trunc nuw nsw i16 %65 to i8
  br label %72

72:                                               ; preds = %70, %68
  %73 = phi i8 [ %71, %70 ], [ 127, %68 ]
  %74 = load ptr, ptr %1, align 1, !tbaa !136
  %75 = add nuw nsw i8 %66, 1
  store i8 %75, ptr %60, align 1, !tbaa !138
  %76 = zext nneg i8 %66 to i16
  %77 = getelementptr inbounds nuw i8, ptr %74, i16 %76
  store i8 %73, ptr %77, align 1, !tbaa !6
  %78 = load ptr, ptr %1, align 1, !tbaa !136
  %79 = load i8, ptr %60, align 1, !tbaa !138
  %80 = add i8 %79, 1
  store i8 %80, ptr %60, align 1, !tbaa !138
  %81 = zext i8 %79 to i16
  %82 = getelementptr inbounds nuw i8, ptr %78, i16 %81
  store i8 %61, ptr %82, align 1, !tbaa !6
  %83 = load ptr, ptr %1, align 1, !tbaa !136
  %84 = load i8, ptr %60, align 1, !tbaa !138
  %85 = add i8 %84, 1
  store i8 %85, ptr %60, align 1, !tbaa !138
  %86 = zext i8 %84 to i16
  %87 = getelementptr inbounds nuw i8, ptr %83, i16 %86
  store i8 %63, ptr %87, align 1, !tbaa !6
  %88 = zext nneg i8 %73 to i16
  %89 = sub i16 %65, %88
  %90 = icmp eq i16 %89, 0
  br i1 %90, label %91, label %64, !llvm.loop !139

91:                                               ; preds = %64, %72, %21
  store i16 %19, ptr %2, align 1, !tbaa !2
  br label %92

92:                                               ; preds = %18, %91
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_blank(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, i16 noundef %2, i16 noundef range(i16 -2050, 225) %3) unnamed_addr #6 {
  %5 = icmp sgt i16 %3, %2
  br i1 %5, label %6, label %83

6:                                                ; preds = %4
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 2
  br label %9

9:                                                ; preds = %6, %79
  %10 = phi i16 [ %2, %6 ], [ %81, %79 ]
  %11 = sub nsw i16 %3, %10
  %12 = icmp sgt i16 %11, 112
  br i1 %12, label %16, label %13

13:                                               ; preds = %9
  %14 = trunc i16 %11 to i8
  %15 = icmp eq i8 %14, 0
  br i1 %15, label %79, label %16

16:                                               ; preds = %9, %13
  %17 = phi i8 [ %14, %13 ], [ 112, %9 ]
  %18 = phi i16 [ %11, %13 ], [ 112, %9 ]
  %19 = sub nsw i16 144, %10
  %20 = zext i8 %17 to i16
  %21 = trunc i16 %19 to i8
  %22 = lshr i16 %19, 8
  %23 = trunc nuw i16 %22 to i8
  br label %24

24:                                               ; preds = %32, %16
  %25 = phi i16 [ %20, %16 ], [ %49, %32 ]
  %26 = load i8, ptr %7, align 1, !tbaa !138
  %27 = icmp ult i8 %26, 22
  br i1 %27, label %28, label %51

28:                                               ; preds = %24
  %29 = icmp ugt i16 %25, 127
  br i1 %29, label %32, label %30

30:                                               ; preds = %28
  %31 = trunc nuw nsw i16 %25 to i8
  br label %32

32:                                               ; preds = %30, %28
  %33 = phi i8 [ %31, %30 ], [ 127, %28 ]
  %34 = load ptr, ptr %0, align 1, !tbaa !136
  %35 = add nuw nsw i8 %26, 1
  store i8 %35, ptr %7, align 1, !tbaa !138
  %36 = zext nneg i8 %26 to i16
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 %36
  store i8 %33, ptr %37, align 1, !tbaa !6
  %38 = load ptr, ptr %0, align 1, !tbaa !136
  %39 = load i8, ptr %7, align 1, !tbaa !138
  %40 = add i8 %39, 1
  store i8 %40, ptr %7, align 1, !tbaa !138
  %41 = zext i8 %39 to i16
  %42 = getelementptr inbounds nuw i8, ptr %38, i16 %41
  store i8 %21, ptr %42, align 1, !tbaa !6
  %43 = load ptr, ptr %0, align 1, !tbaa !136
  %44 = load i8, ptr %7, align 1, !tbaa !138
  %45 = add i8 %44, 1
  store i8 %45, ptr %7, align 1, !tbaa !138
  %46 = zext i8 %44 to i16
  %47 = getelementptr inbounds nuw i8, ptr %43, i16 %46
  store i8 %23, ptr %47, align 1, !tbaa !6
  %48 = zext nneg i8 %33 to i16
  %49 = sub i16 %25, %48
  %50 = icmp eq i16 %49, 0
  br i1 %50, label %51, label %24, !llvm.loop !139

51:                                               ; preds = %24, %32
  br label %52

52:                                               ; preds = %51, %60
  %53 = phi i16 [ %77, %60 ], [ %20, %51 ]
  %54 = load i8, ptr %8, align 1, !tbaa !138
  %55 = icmp ult i8 %54, 22
  br i1 %55, label %56, label %79

56:                                               ; preds = %52
  %57 = icmp ugt i16 %53, 127
  br i1 %57, label %60, label %58

58:                                               ; preds = %56
  %59 = trunc nuw nsw i16 %53 to i8
  br label %60

60:                                               ; preds = %58, %56
  %61 = phi i8 [ %59, %58 ], [ 127, %56 ]
  %62 = load ptr, ptr %1, align 1, !tbaa !136
  %63 = add nuw nsw i8 %54, 1
  store i8 %63, ptr %8, align 1, !tbaa !138
  %64 = zext nneg i8 %54 to i16
  %65 = getelementptr inbounds nuw i8, ptr %62, i16 %64
  store i8 %61, ptr %65, align 1, !tbaa !6
  %66 = load ptr, ptr %1, align 1, !tbaa !136
  %67 = load i8, ptr %8, align 1, !tbaa !138
  %68 = add i8 %67, 1
  store i8 %68, ptr %8, align 1, !tbaa !138
  %69 = zext i8 %67 to i16
  %70 = getelementptr inbounds nuw i8, ptr %66, i16 %69
  store i8 0, ptr %70, align 1, !tbaa !6
  %71 = load ptr, ptr %1, align 1, !tbaa !136
  %72 = load i8, ptr %8, align 1, !tbaa !138
  %73 = add i8 %72, 1
  store i8 %73, ptr %8, align 1, !tbaa !138
  %74 = zext i8 %72 to i16
  %75 = getelementptr inbounds nuw i8, ptr %71, i16 %74
  store i8 0, ptr %75, align 1, !tbaa !6
  %76 = zext nneg i8 %61 to i16
  %77 = sub i16 %53, %76
  %78 = icmp eq i16 %77, 0
  br i1 %78, label %79, label %52, !llvm.loop !139

79:                                               ; preds = %52, %60, %13
  %80 = phi i16 [ %11, %13 ], [ %18, %60 ], [ %18, %52 ]
  %81 = add nsw i16 %80, %10
  %82 = icmp sgt i16 %3, %81
  br i1 %82, label %9, label %83, !llvm.loop !140

83:                                               ; preds = %79, %4
  ret void
}

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @bv_stage(ptr dead_on_unwind noalias nonnull writable writeonly sret(%struct.BvMat) align 1 captures(none) %0, ptr noundef nonnull captures(none) dead_on_return %1, i16 noundef range(i16 13, 1069) %2) unnamed_addr #1 {
  %4 = load i16, ptr @bv_mutations, align 1, !tbaa !2
  br label %15

5:                                                ; preds = %15
  %6 = add i16 %4, 9
  store i16 %6, ptr @bv_mutations, align 1, !tbaa !2
  %7 = load i16, ptr %1, align 1, !tbaa !2
  %8 = shl nuw nsw i16 %2, 1
  %9 = xor i16 %7, %8
  store i16 %9, ptr %1, align 1, !tbaa !2
  %10 = getelementptr inbounds nuw i8, ptr %1, i16 16
  %11 = load i16, ptr %10, align 1, !tbaa !2
  %12 = sub nsw i16 %11, %2
  store i16 %12, ptr %10, align 1, !tbaa !2
  %13 = getelementptr i8, ptr %1, i16 6
  %14 = getelementptr inbounds nuw i8, ptr %0, i16 6
  br label %29

15:                                               ; preds = %3, %15
  %16 = phi i8 [ 0, %3 ], [ %28, %15 ]
  %17 = phi i8 [ 0, %3 ], [ %26, %15 ]
  %18 = zext nneg i8 %17 to i16
  %19 = zext nneg i8 %16 to i16
  %20 = getelementptr i8, ptr %1, i16 %19
  %21 = load i16, ptr %20, align 1, !tbaa !2
  %22 = add nuw nsw i16 %2, %18
  %23 = and i16 %22, 127
  %24 = add nsw i16 %23, -64
  %25 = add nsw i16 %24, %21
  store i16 %25, ptr %20, align 1, !tbaa !2
  %26 = add nuw nsw i8 %17, 1
  %27 = icmp eq i8 %26, 9
  %28 = add nuw nsw i8 %16, 2
  br i1 %27, label %5, label %15, !llvm.loop !141

29:                                               ; preds = %5, %39
  %30 = phi i8 [ 0, %5 ], [ %45, %39 ]
  %31 = phi ptr [ %0, %5 ], [ %43, %39 ]
  %32 = phi ptr [ %1, %5 ], [ %42, %39 ]
  %33 = phi i8 [ 0, %5 ], [ %40, %39 ]
  br label %35

34:                                               ; preds = %39
  ret void

35:                                               ; preds = %29, %46
  %36 = phi i8 [ 0, %29 ], [ %54, %46 ]
  %37 = phi ptr [ @__const.bv_stage.rot, %29 ], [ %52, %46 ]
  %38 = phi i8 [ 0, %29 ], [ %51, %46 ]
  br label %55

39:                                               ; preds = %46
  %40 = add nuw nsw i8 %33, 1
  %41 = zext nneg i8 %30 to i16
  %42 = getelementptr i8, ptr %13, i16 %41
  %43 = getelementptr i8, ptr %14, i16 %41
  %44 = icmp eq i8 %40, 3
  %45 = add nuw nsw i8 %30, 6
  br i1 %44, label %34, label %29, !llvm.loop !142

46:                                               ; preds = %55
  %47 = lshr i32 %69, 8
  %48 = trunc i32 %47 to i16
  %49 = zext nneg i8 %36 to i16
  %50 = getelementptr i8, ptr %31, i16 %49
  store i16 %48, ptr %50, align 1, !tbaa !2
  %51 = add nuw nsw i8 %38, 1
  %52 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @__const.bv_stage.rot, i16 2), i16 %49
  %53 = icmp eq i8 %51, 3
  %54 = add nuw nsw i8 %36, 2
  br i1 %53, label %39, label %35, !llvm.loop !143

55:                                               ; preds = %35, %55
  %56 = phi i8 [ 0, %35 ], [ %73, %55 ]
  %57 = phi i8 [ 0, %35 ], [ %72, %55 ]
  %58 = phi i8 [ 0, %35 ], [ %70, %55 ]
  %59 = phi i32 [ 0, %35 ], [ %69, %55 ]
  %60 = zext nneg i8 %57 to i16
  %61 = getelementptr i8, ptr %32, i16 %60
  %62 = load i16, ptr %61, align 1, !tbaa !2
  %63 = sext i16 %62 to i32
  %64 = zext nneg i8 %56 to i16
  %65 = getelementptr i8, ptr %37, i16 %64
  %66 = load i16, ptr %65, align 1, !tbaa !2
  %67 = sext i16 %66 to i32
  %68 = mul nsw i32 %67, %63
  %69 = add nsw i32 %68, %59
  %70 = add nuw nsw i8 %58, 1
  %71 = icmp eq i8 %70, 3
  %72 = add nuw nsw i8 %57, 2
  %73 = add nuw nsw i8 %56, 6
  br i1 %71, label %46, label %55, !llvm.loop !144
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #7

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal fastcc i16 @bv_apply(ptr noundef nonnull captures(none) dead_on_return %0, ptr noundef nonnull readonly captures(none) dead_on_return %1, ptr noundef nonnull writeonly captures(none) initializes((0, 8)) %2) unnamed_addr #8 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i16 6
  %5 = load i16, ptr %4, align 1, !tbaa !91
  %6 = xor i16 %5, -16657
  store i16 %6, ptr %4, align 1, !tbaa !91
  %7 = load i16, ptr %0, align 1, !tbaa !87
  %8 = add nsw i16 %7, 1
  store i16 %8, ptr %0, align 1, !tbaa !87
  %9 = load i16, ptr %1, align 1, !tbaa !2
  %10 = sext i16 %9 to i32
  %11 = sext i16 %8 to i32
  %12 = mul nsw i32 %10, %11
  %13 = lshr i32 %12, 8
  %14 = trunc i32 %13 to i16
  %15 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %16 = load i16, ptr %15, align 1, !tbaa !2
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %18 = load i16, ptr %17, align 1, !tbaa !89
  %19 = sext i16 %16 to i32
  %20 = sext i16 %18 to i32
  %21 = mul nsw i32 %20, %19
  %22 = lshr i32 %21, 8
  %23 = trunc i32 %22 to i16
  %24 = add nsw i16 %23, %14
  %25 = getelementptr inbounds nuw i8, ptr %1, i16 4
  %26 = load i16, ptr %25, align 1, !tbaa !2
  %27 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %28 = load i16, ptr %27, align 1, !tbaa !90
  %29 = sext i16 %26 to i32
  %30 = sext i16 %28 to i32
  %31 = mul nsw i32 %30, %29
  %32 = lshr i32 %31, 8
  %33 = trunc i32 %32 to i16
  %34 = add nsw i16 %24, %33
  %35 = getelementptr inbounds nuw i8, ptr %1, i16 6
  %36 = load i16, ptr %35, align 1, !tbaa !2
  %37 = sext i16 %36 to i32
  %38 = mul nsw i32 %37, %11
  %39 = lshr i32 %38, 8
  %40 = trunc i32 %39 to i16
  %41 = getelementptr inbounds nuw i8, ptr %1, i16 8
  %42 = load i16, ptr %41, align 1, !tbaa !2
  %43 = sext i16 %42 to i32
  %44 = mul nsw i32 %43, %20
  %45 = lshr i32 %44, 8
  %46 = trunc i32 %45 to i16
  %47 = add nsw i16 %46, %40
  %48 = getelementptr inbounds nuw i8, ptr %1, i16 10
  %49 = load i16, ptr %48, align 1, !tbaa !2
  %50 = sext i16 %49 to i32
  %51 = mul nsw i32 %50, %30
  %52 = lshr i32 %51, 8
  %53 = trunc i32 %52 to i16
  %54 = add nsw i16 %47, %53
  %55 = getelementptr inbounds nuw i8, ptr %1, i16 12
  %56 = load i16, ptr %55, align 1, !tbaa !2
  %57 = sext i16 %56 to i32
  %58 = mul nsw i32 %57, %11
  %59 = lshr i32 %58, 8
  %60 = trunc i32 %59 to i16
  %61 = getelementptr inbounds nuw i8, ptr %1, i16 14
  %62 = load i16, ptr %61, align 1, !tbaa !2
  %63 = sext i16 %62 to i32
  %64 = mul nsw i32 %63, %20
  %65 = lshr i32 %64, 8
  %66 = trunc i32 %65 to i16
  %67 = add nsw i16 %66, %60
  %68 = getelementptr inbounds nuw i8, ptr %1, i16 16
  %69 = load i16, ptr %68, align 1, !tbaa !2
  %70 = sext i16 %69 to i32
  %71 = mul nsw i32 %70, %30
  %72 = lshr i32 %71, 8
  %73 = trunc i32 %72 to i16
  %74 = add nsw i16 %67, %73
  store i16 %34, ptr %2, align 1, !tbaa !2
  %75 = getelementptr inbounds nuw i8, ptr %2, i16 2
  store i16 %54, ptr %75, align 1, !tbaa !2
  %76 = getelementptr inbounds nuw i8, ptr %2, i16 4
  store i16 %74, ptr %76, align 1, !tbaa !2
  %77 = getelementptr inbounds nuw i8, ptr %2, i16 6
  store i16 %6, ptr %77, align 1, !tbaa !2
  %78 = xor i16 %34, %6
  ret i16 %78
}

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none)
define internal fastcc void @canvas_line(i16 noundef range(i16 -8128, 8256) %0, i16 noundef range(i16 -8148, 8236) %1, i16 noundef range(i16 -8128, 8256) %2, i16 noundef range(i16 -8148, 8236) %3) unnamed_addr #9 {
  %5 = icmp sgt i16 %2, %0
  br i1 %5, label %6, label %8

6:                                                ; preds = %4
  %7 = sub nsw i16 %2, %0
  br label %10

8:                                                ; preds = %4
  %9 = sub nsw i16 %0, %2
  br label %10

10:                                               ; preds = %8, %6
  %11 = phi i16 [ %7, %6 ], [ %9, %8 ]
  %12 = icmp sgt i16 %3, %1
  br i1 %12, label %13, label %15

13:                                               ; preds = %10
  %14 = sub nsw i16 %3, %1
  br label %17

15:                                               ; preds = %10
  %16 = sub nsw i16 %1, %3
  br label %17

17:                                               ; preds = %15, %13
  %18 = phi i16 [ 1, %13 ], [ -1, %15 ]
  %19 = phi i16 [ %14, %13 ], [ %16, %15 ]
  %20 = select i1 %5, i16 1, i16 -1
  %21 = sub nsw i16 %11, %19
  %22 = sub nsw i16 0, %19
  br label %23

23:                                               ; preds = %69, %17
  %24 = phi i16 [ %71, %69 ], [ %1, %17 ]
  %25 = phi i16 [ %70, %69 ], [ %21, %17 ]
  %26 = phi i16 [ %67, %69 ], [ %0, %17 ]
  %27 = icmp ugt i16 %24, 127
  %28 = shl nuw nsw i16 %24, 1
  %29 = and i16 %28, 240
  %30 = and i16 %28, 14
  %31 = getelementptr inbounds i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %30
  %32 = icmp eq i16 %24, %3
  br label %33

33:                                               ; preds = %23, %65
  %34 = phi i16 [ %66, %65 ], [ %25, %23 ]
  %35 = phi i16 [ %67, %65 ], [ %26, %23 ]
  %36 = icmp ugt i16 %35, 127
  %37 = select i1 %36, i1 true, i1 %27
  br i1 %37, label %56, label %38

38:                                               ; preds = %33
  %39 = lshr i16 %35, 3
  %40 = or disjoint i16 %39, %29
  %41 = shl nuw nsw i16 %40, 4
  %42 = getelementptr inbounds i8, ptr %31, i16 %41
  %43 = and i16 %35, 7
  %44 = lshr exact i16 128, %43
  %45 = getelementptr inbounds nuw i8, ptr %42, i16 1
  %46 = load i8, ptr %45, align 1, !tbaa !6
  %47 = trunc nuw i16 %44 to i8
  %48 = or i8 %46, %47
  store i8 %48, ptr %45, align 1, !tbaa !6
  %49 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  %50 = icmp ult i16 %40, %49
  br i1 %50, label %51, label %52

51:                                               ; preds = %38
  store i16 %40, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !24
  br label %52

52:                                               ; preds = %51, %38
  %53 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  %54 = icmp ugt i16 %40, %53
  br i1 %54, label %55, label %56

55:                                               ; preds = %52
  store i16 %40, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !25
  br label %56

56:                                               ; preds = %33, %52, %55
  %57 = icmp eq i16 %35, %2
  %58 = select i1 %57, i1 %32, i1 false
  br i1 %58, label %72, label %59

59:                                               ; preds = %56
  %60 = shl nsw i16 %34, 1
  %61 = icmp sgt i16 %60, %22
  br i1 %61, label %62, label %65

62:                                               ; preds = %59
  %63 = sub nsw i16 %34, %19
  %64 = add nsw i16 %35, %20
  br label %65

65:                                               ; preds = %62, %59
  %66 = phi i16 [ %63, %62 ], [ %34, %59 ]
  %67 = phi i16 [ %64, %62 ], [ %35, %59 ]
  %68 = icmp slt i16 %60, %11
  br i1 %68, label %69, label %33

69:                                               ; preds = %65
  %70 = add nsw i16 %66, %11
  %71 = add nsw i16 %24, %18
  br label %23

72:                                               ; preds = %56
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @upq_flush() unnamed_addr #10 {
  %1 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 177), align 1, !tbaa !145
  %2 = zext i8 %1 to i16
  %3 = shl nuw nsw i16 %2, 4
  %4 = add nuw nsw i16 %3, 17152
  %5 = inttoptr i16 %4 to ptr
  %6 = shl nuw i16 1, %2
  %7 = trunc i16 %6 to i8
  %8 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %108, label %10

10:                                               ; preds = %0
  %11 = getelementptr inbounds nuw i8, ptr %5, i16 1
  %12 = getelementptr inbounds nuw i8, ptr %5, i16 2
  %13 = getelementptr inbounds nuw i8, ptr %5, i16 3
  %14 = getelementptr inbounds nuw i8, ptr %5, i16 4
  %15 = getelementptr inbounds nuw i8, ptr %5, i16 5
  %16 = getelementptr inbounds nuw i8, ptr %5, i16 6
  br label %17

17:                                               ; preds = %10, %86
  %18 = phi i8 [ %8, %10 ], [ %89, %86 ]
  %19 = phi i16 [ 0, %10 ], [ %87, %86 ]
  %20 = phi i8 [ 0, %10 ], [ %88, %86 ]
  %21 = zext i8 %20 to i16
  %22 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %21
  %23 = getelementptr inbounds nuw i8, ptr %22, i16 10
  %24 = load i8, ptr %23, align 1, !tbaa !44
  switch i8 %24, label %44 [
    i8 3, label %25
    i8 4, label %34
  ]

25:                                               ; preds = %17
  %26 = load i16, ptr %22, align 1, !tbaa !46
  %27 = inttoptr i16 %26 to ptr
  %28 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %29 = load i16, ptr %28, align 1, !tbaa !50
  %30 = trunc i16 %29 to i8
  store volatile i8 %30, ptr %27, align 1, !tbaa !6
  %31 = load i16, ptr %28, align 1, !tbaa !50
  %32 = lshr i16 %31, 8
  %33 = trunc nuw i16 %32 to i8
  store volatile i8 %33, ptr %27, align 1, !tbaa !6
  br label %86

34:                                               ; preds = %17
  %35 = load i16, ptr %22, align 1, !tbaa !46
  %36 = inttoptr i16 %35 to ptr
  %37 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %38 = load i16, ptr %37, align 1, !tbaa !50
  %39 = trunc i16 %38 to i8
  store volatile i8 %39, ptr %36, align 1, !tbaa !6
  %40 = load i16, ptr %37, align 1, !tbaa !50
  %41 = lshr i16 %40, 8
  %42 = trunc nuw i16 %41 to i8
  %43 = getelementptr inbounds nuw i8, ptr %36, i16 1
  store volatile i8 %42, ptr %43, align 1, !tbaa !6
  br label %86

44:                                               ; preds = %17
  %45 = icmp eq i16 %19, 0
  br i1 %45, label %51, label %46

46:                                               ; preds = %44
  %47 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %48 = load i16, ptr %47, align 1, !tbaa !52
  %49 = add i16 %48, %19
  %50 = icmp ugt i16 %49, 5100
  br i1 %50, label %91, label %51

51:                                               ; preds = %46, %44
  switch i8 %24, label %59 [
    i8 0, label %52
    i8 1, label %56
  ]

52:                                               ; preds = %51
  %53 = getelementptr inbounds nuw i8, ptr %22, i16 9
  %54 = load i8, ptr %53, align 1, !tbaa !47
  store volatile i8 %54, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  %55 = load i16, ptr %22, align 1, !tbaa !46
  store volatile i16 %55, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %65

56:                                               ; preds = %51
  %57 = load i16, ptr %22, align 1, !tbaa !46
  %58 = trunc i16 %57 to i8
  store volatile i8 %58, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  br label %65

59:                                               ; preds = %51
  %60 = load i16, ptr %22, align 1, !tbaa !46
  %61 = trunc i16 %60 to i8
  store volatile i8 %61, ptr inttoptr (i16 8450 to ptr), align 2, !tbaa !6
  %62 = load i16, ptr %22, align 1, !tbaa !46
  %63 = lshr i16 %62, 8
  %64 = trunc nuw i16 %63 to i8
  store volatile i8 %64, ptr inttoptr (i16 8451 to ptr), align 1, !tbaa !6
  br label %65

65:                                               ; preds = %56, %59, %52
  %66 = getelementptr inbounds nuw i8, ptr %22, i16 8
  %67 = load i8, ptr %66, align 1, !tbaa !49
  store volatile i8 %67, ptr %5, align 16, !tbaa !6
  %68 = getelementptr inbounds nuw i8, ptr %22, i16 7
  %69 = load i8, ptr %68, align 1, !tbaa !48
  store volatile i8 %69, ptr %11, align 1, !tbaa !6
  %70 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %71 = load i16, ptr %70, align 1, !tbaa !50
  %72 = trunc i16 %71 to i8
  store volatile i8 %72, ptr %12, align 2, !tbaa !6
  %73 = load i16, ptr %70, align 1, !tbaa !50
  %74 = lshr i16 %73, 8
  %75 = trunc nuw i16 %74 to i8
  store volatile i8 %75, ptr %13, align 1, !tbaa !6
  %76 = getelementptr inbounds nuw i8, ptr %22, i16 6
  %77 = load i8, ptr %76, align 1, !tbaa !51
  store volatile i8 %77, ptr %14, align 4, !tbaa !6
  %78 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %79 = load i16, ptr %78, align 1, !tbaa !52
  %80 = trunc i16 %79 to i8
  store volatile i8 %80, ptr %15, align 1, !tbaa !6
  %81 = load i16, ptr %78, align 1, !tbaa !52
  %82 = lshr i16 %81, 8
  %83 = trunc nuw i16 %82 to i8
  store volatile i8 %83, ptr %16, align 2, !tbaa !6
  store volatile i8 %7, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !6
  %84 = load i16, ptr %78, align 1, !tbaa !52
  %85 = add i16 %84, %19
  br label %86

86:                                               ; preds = %65, %34, %25
  %87 = phi i16 [ %19, %25 ], [ %19, %34 ], [ %85, %65 ]
  %88 = add nuw i8 %20, 1
  %89 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %90 = icmp ult i8 %88, %89
  br i1 %90, label %17, label %91

91:                                               ; preds = %86, %46
  %92 = phi i8 [ %89, %86 ], [ %18, %46 ]
  %93 = phi i8 [ %88, %86 ], [ %20, %46 ]
  %94 = icmp ult i8 %93, %92
  br i1 %94, label %95, label %108

95:                                               ; preds = %91
  %96 = icmp eq i8 %93, 0
  br i1 %96, label %110, label %97

97:                                               ; preds = %95, %97
  %98 = phi i8 [ %101, %97 ], [ 0, %95 ]
  %99 = phi i8 [ %104, %97 ], [ %93, %95 ]
  %100 = zext i8 %99 to i16
  %101 = add i8 %98, 1
  %102 = zext i8 %98 to i16
  %103 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %102
  %104 = add nuw i8 %99, 1
  %105 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %100
  tail call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(11) %103, ptr noundef nonnull align 1 dereferenceable(11) %105, i16 11, i1 false), !tbaa.struct !146
  %106 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %107 = icmp ult i8 %104, %106
  br i1 %107, label %97, label %108, !llvm.loop !147

108:                                              ; preds = %97, %91, %0
  %109 = phi i8 [ 0, %91 ], [ 0, %0 ], [ %101, %97 ]
  store i8 %109, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  br label %110

110:                                              ; preds = %108, %95
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #11

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #12

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #12

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #1 = { nofree noinline norecurse nosync nounwind optsize memory(readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { nofree norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #4 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #5 = { nofree norecurse nosync nounwind optsize memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #6 = { nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #7 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #9 = { nofree noinline norecurse nosync nounwind optsize memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #10 = { nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16" }
attributes #11 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #13 = { nounwind optsize }
attributes #14 = { optsize }
attributes #15 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!10, !4, i64 194}
!10 = !{!"", !11, i64 0, !12, i64 178, !13, i64 182, !4, i64 191, !4, i64 192, !4, i64 193, !4, i64 194, !4, i64 195}
!11 = !{!"", !4, i64 0, !4, i64 176, !4, i64 177}
!12 = !{!"", !3, i64 0, !3, i64 2}
!13 = !{!"", !4, i64 0, !4, i64 8}
!14 = !{!10, !4, i64 195}
!15 = !{!16, !18, i64 0}
!16 = !{!"", !17, i64 0, !4, i64 3, !3, i64 4099, !3, i64 4101, !3, i64 4103, !3, i64 4105, !4, i64 4107, !4, i64 4108}
!17 = !{!"Drawable", !18, i64 0, !4, i64 2}
!18 = !{!"any pointer", !4, i64 0}
!19 = !{!16, !4, i64 2}
!20 = !{!16, !3, i64 4103}
!21 = !{!16, !3, i64 4105}
!22 = !{!16, !4, i64 4107}
!23 = !{!16, !4, i64 4108}
!24 = !{!16, !3, i64 4099}
!25 = !{!16, !3, i64 4101}
!26 = !{!27, !18, i64 0}
!27 = !{!"", !17, i64 0, !3, i64 3, !4, i64 5, !4, i64 7, !4, i64 135}
!28 = !{!27, !4, i64 2}
!29 = !{!27, !3, i64 3}
!30 = distinct !{!30, !8}
!31 = !{!27, !4, i64 135}
!32 = !{!10, !4, i64 192}
!33 = !{!10, !4, i64 193}
!34 = !{!13, !4, i64 8}
!35 = !{!36, !36, i64 0}
!36 = !{!"p1 _ZTS8Drawable", !18, i64 0}
!37 = distinct !{null, null}
!38 = !{!10, !4, i64 191}
!39 = !{!17, !4, i64 2}
!40 = !{!17, !18, i64 0}
!41 = !{!42, !18, i64 0}
!42 = !{!"", !18, i64 0, !18, i64 2}
!43 = !{!11, !4, i64 176}
!44 = !{!45, !4, i64 10}
!45 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !4, i64 6, !4, i64 7, !4, i64 8, !4, i64 9, !4, i64 10}
!46 = !{!45, !3, i64 0}
!47 = !{!45, !4, i64 9}
!48 = !{!45, !4, i64 7}
!49 = !{!45, !4, i64 8}
!50 = !{!45, !3, i64 2}
!51 = !{!45, !4, i64 6}
!52 = !{!45, !3, i64 4}
!53 = !{!54, !3, i64 4441}
!54 = !{!"", !10, i64 0, !16, i64 196, !27, i64 4305, !3, i64 4441}
!55 = distinct !{!55, !8}
!56 = !{!57, !18, i64 0}
!57 = !{!"", !17, i64 0, !58, i64 3, !58, i64 5, !58, i64 7, !58, i64 9, !4, i64 11, !4, i64 12, !3, i64 13, !3, i64 15, !3, i64 17, !3, i64 19, !3, i64 21, !3, i64 23, !4, i64 25, !3, i64 26, !4, i64 28, !4, i64 29, !4, i64 30, !4, i64 31, !4, i64 32, !4, i64 33, !3, i64 34, !3, i64 36, !59, i64 38, !59, i64 89}
!58 = !{!"p1 omnipotent char", !18, i64 0}
!59 = !{!"", !4, i64 0, !4, i64 50}
!60 = !{!57, !4, i64 2}
!61 = !{!57, !58, i64 3}
!62 = !{!57, !58, i64 5}
!63 = !{!57, !58, i64 7}
!64 = !{!57, !4, i64 11}
!65 = !{!57, !58, i64 9}
!66 = !{!57, !4, i64 12}
!67 = !{!57, !3, i64 13}
!68 = !{!57, !3, i64 15}
!69 = !{!57, !3, i64 17}
!70 = !{!57, !4, i64 28}
!71 = !{!57, !4, i64 29}
!72 = !{!57, !4, i64 31}
!73 = !{!57, !4, i64 32}
!74 = !{!57, !4, i64 30}
!75 = !{!57, !4, i64 25}
!76 = !{!57, !3, i64 34}
!77 = !{!57, !3, i64 36}
!78 = !{!57, !4, i64 33}
!79 = !{!42, !18, i64 2}
!80 = distinct !{null, null, null, null, null}
!81 = distinct !{!81, !8}
!82 = distinct !{!82, !8}
!83 = distinct !{!83, !8}
!84 = distinct !{null, null, null, null}
!85 = distinct !{!85, !8}
!86 = distinct !{!86, !8}
!87 = !{!88, !3, i64 0}
!88 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !3, i64 6}
!89 = !{!88, !3, i64 2}
!90 = !{!88, !3, i64 4}
!91 = !{!88, !3, i64 6}
!92 = distinct !{!92, !8}
!93 = !{i64 0, i64 18, !6}
!94 = distinct !{!94, !8}
!95 = !{i64 0, i64 2, !2, i64 2, i64 2, !2, i64 4, i64 2, !2, i64 6, i64 2, !2}
!96 = distinct !{!96, !8}
!97 = distinct !{!97, !8}
!98 = distinct !{!98, !8}
!99 = distinct !{!99, !8}
!100 = distinct !{!100, !8}
!101 = distinct !{null, null, null, null, null}
!102 = distinct !{!102, !8}
!103 = distinct !{!103, !8}
!104 = distinct !{null, null, null, null}
!105 = !{!57, !3, i64 19}
!106 = distinct !{null, null, null, null, null}
!107 = distinct !{!107, !8}
!108 = distinct !{!108, !8}
!109 = distinct !{null, null, null}
!110 = distinct !{!110, !8}
!111 = distinct !{!111, !8}
!112 = distinct !{!112, !8}
!113 = distinct !{!113, !8}
!114 = distinct !{!114, !8}
!115 = distinct !{!115, !8}
!116 = distinct !{!116, !8}
!117 = distinct !{!117, !8}
!118 = distinct !{!118, !8}
!119 = distinct !{!119, !8}
!120 = distinct !{!120, !8}
!121 = distinct !{!121, !8}
!122 = distinct !{!122, !8}
!123 = distinct !{!123, !8}
!124 = distinct !{!124, !8}
!125 = distinct !{!125, !8}
!126 = distinct !{!126, !8}
!127 = distinct !{!127, !8}
!128 = distinct !{!128, !8}
!129 = !{!57, !3, i64 21}
!130 = !{!57, !3, i64 23}
!131 = distinct !{!131, !8}
!132 = !{!57, !3, i64 26}
!133 = !{!59, !4, i64 50}
!134 = distinct !{!134, !8}
!135 = distinct !{!135, !8}
!136 = !{!137, !18, i64 0}
!137 = !{!"", !18, i64 0, !4, i64 2}
!138 = !{!137, !4, i64 2}
!139 = distinct !{!139, !8}
!140 = distinct !{!140, !8}
!141 = distinct !{!141, !8}
!142 = distinct !{!142, !8}
!143 = distinct !{!143, !8}
!144 = distinct !{!144, !8}
!145 = !{!11, !4, i64 177}
!146 = !{i64 0, i64 2, !2, i64 2, i64 2, !2, i64 4, i64 2, !2, i64 6, i64 1, !6, i64 7, i64 1, !6, i64 8, i64 1, !6, i64 9, i64 1, !6, i64 10, i64 1, !6}
!147 = distinct !{!147, !8}
