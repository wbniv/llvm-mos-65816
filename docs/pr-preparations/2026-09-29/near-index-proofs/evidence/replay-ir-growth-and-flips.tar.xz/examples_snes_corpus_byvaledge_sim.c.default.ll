; ModuleID = '/work/examples/snes/corpus/byvaledge_sim.c'
source_filename = "/work/examples/snes/corpus/byvaledge_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.BvR33 = type { i32, i8 }
%struct.BvR40 = type { i16, i16, i8 }

@corpus_result = dso_local global i16 0, align 1
@bv_n = internal unnamed_addr global i16 0, align 1
@bv_out32 = internal unnamed_addr global [96 x [2 x i16]] zeroinitializer, align 1
@bv_out33 = internal unnamed_addr global [96 x i32] zeroinitializer, align 1
@bv_out40 = internal unnamed_addr global [96 x [3 x i16]] zeroinitializer, align 1
@bv_reread = internal unnamed_addr global [96 x [3 x i16]] zeroinitializer, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  store i16 0, ptr @bv_n, align 1, !tbaa !2
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(384) @bv_out32, i8 0, i16 384, i1 false), !tbaa !2
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(384) @bv_out33, i8 0, i16 384, i1 false), !tbaa !6
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(576) @bv_out40, i8 0, i16 576, i1 false), !tbaa !2
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(576) @bv_reread, i8 0, i16 576, i1 false), !tbaa !2
  tail call fastcc void @bv_run() #8
  %1 = load i16, ptr @bv_n, align 1, !tbaa !2
  %2 = xor i16 %1, 19842
  %3 = tail call i16 @llvm.fshl.i16(i16 %2, i16 %2, i16 1)
  %4 = mul i16 %3, 25173
  %5 = add i16 %4, 13849
  %6 = tail call i16 @llvm.fshl.i16(i16 %5, i16 %5, i16 1)
  %7 = mul i16 %6, 25173
  %8 = add i16 %7, 13849
  %9 = icmp eq i16 %1, 0
  br i1 %9, label %76, label %10

10:                                               ; preds = %0, %10
  %11 = phi i16 [ %74, %10 ], [ %8, %0 ]
  %12 = phi i16 [ %72, %10 ], [ 0, %0 ]
  %13 = getelementptr inbounds nuw [4 x i8], ptr @bv_out32, i16 %12
  %14 = load i16, ptr %13, align 1, !tbaa !2
  %15 = xor i16 %14, %11
  %16 = tail call i16 @llvm.fshl.i16(i16 %15, i16 %15, i16 1)
  %17 = mul i16 %16, 25173
  %18 = add i16 %17, 13849
  %19 = getelementptr inbounds nuw i8, ptr %13, i16 2
  %20 = load i16, ptr %19, align 1, !tbaa !2
  %21 = xor i16 %18, %20
  %22 = tail call i16 @llvm.fshl.i16(i16 %21, i16 %21, i16 1)
  %23 = mul i16 %22, 25173
  %24 = add i16 %23, 13849
  %25 = getelementptr inbounds nuw [4 x i8], ptr @bv_out33, i16 %12
  %26 = load i32, ptr %25, align 1, !tbaa !6
  %27 = trunc i32 %26 to i16
  %28 = xor i16 %24, %27
  %29 = tail call i16 @llvm.fshl.i16(i16 %28, i16 %28, i16 1)
  %30 = mul i16 %29, 25173
  %31 = add i16 %30, 13849
  %32 = lshr i32 %26, 16
  %33 = trunc nuw i32 %32 to i16
  %34 = xor i16 %31, %33
  %35 = tail call i16 @llvm.fshl.i16(i16 %34, i16 %34, i16 1)
  %36 = mul i16 %35, 25173
  %37 = add i16 %36, 13849
  %38 = getelementptr inbounds nuw [6 x i8], ptr @bv_out40, i16 %12
  %39 = load i16, ptr %38, align 1, !tbaa !2
  %40 = xor i16 %37, %39
  %41 = tail call i16 @llvm.fshl.i16(i16 %40, i16 %40, i16 1)
  %42 = mul i16 %41, 25173
  %43 = add i16 %42, 13849
  %44 = getelementptr inbounds nuw i8, ptr %38, i16 2
  %45 = load i16, ptr %44, align 1, !tbaa !2
  %46 = xor i16 %43, %45
  %47 = tail call i16 @llvm.fshl.i16(i16 %46, i16 %46, i16 1)
  %48 = mul i16 %47, 25173
  %49 = add i16 %48, 13849
  %50 = getelementptr inbounds nuw i8, ptr %38, i16 4
  %51 = load i16, ptr %50, align 1, !tbaa !2
  %52 = xor i16 %49, %51
  %53 = tail call i16 @llvm.fshl.i16(i16 %52, i16 %52, i16 1)
  %54 = mul i16 %53, 25173
  %55 = add i16 %54, 13849
  %56 = getelementptr inbounds nuw [6 x i8], ptr @bv_reread, i16 %12
  %57 = load i16, ptr %56, align 1, !tbaa !2
  %58 = xor i16 %55, %57
  %59 = tail call i16 @llvm.fshl.i16(i16 %58, i16 %58, i16 1)
  %60 = mul i16 %59, 25173
  %61 = add i16 %60, 13849
  %62 = getelementptr inbounds nuw i8, ptr %56, i16 2
  %63 = load i16, ptr %62, align 1, !tbaa !2
  %64 = xor i16 %61, %63
  %65 = tail call i16 @llvm.fshl.i16(i16 %64, i16 %64, i16 1)
  %66 = mul i16 %65, 25173
  %67 = add i16 %66, 13849
  %68 = getelementptr inbounds nuw i8, ptr %56, i16 4
  %69 = load i16, ptr %68, align 1, !tbaa !2
  %70 = xor i16 %67, %69
  %71 = tail call i16 @llvm.fshl.i16(i16 %70, i16 %70, i16 1)
  %72 = add nuw i16 %12, 1
  %73 = mul i16 %71, 25173
  %74 = add i16 %73, 13849
  %75 = icmp eq i16 %72, %1
  br i1 %75, label %76, label %10, !llvm.loop !8

76:                                               ; preds = %10, %0
  %77 = phi i16 [ %8, %0 ], [ %74, %10 ]
  store volatile i16 %77, ptr @corpus_result, align 1, !tbaa !2
  br label %78

78:                                               ; preds = %78, %76
  tail call void asm sideeffect "wai", ""() #9, !srcloc !10
  br label %78
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none)
define internal fastcc void @bv_run() unnamed_addr #2 {
  %1 = alloca %struct.BvR33, align 1
  %2 = alloca %struct.BvR33, align 1
  %3 = alloca %struct.BvR40, align 1
  %4 = alloca %struct.BvR40, align 1
  %5 = alloca %struct.BvR33, align 1
  %6 = alloca %struct.BvR40, align 1
  %7 = getelementptr inbounds nuw i8, ptr %2, i16 4
  %8 = getelementptr inbounds nuw i8, ptr %4, i16 2
  %9 = getelementptr inbounds nuw i8, ptr %4, i16 4
  %10 = getelementptr inbounds nuw i8, ptr %1, i16 4
  %11 = getelementptr inbounds nuw i8, ptr %3, i16 2
  %12 = getelementptr inbounds nuw i8, ptr %3, i16 4
  %13 = load i16, ptr @bv_n, align 1, !tbaa !2
  br label %16

14:                                               ; preds = %16
  %15 = add i16 %13, 96
  store i16 %15, ptr @bv_n, align 1, !tbaa !2
  ret void

16:                                               ; preds = %0, %16
  %17 = phi i16 [ 12139, %0 ], [ %20, %16 ]
  %18 = phi i16 [ 0, %0 ], [ %61, %16 ]
  %19 = mul i16 %17, 25173
  %20 = add i16 %19, 13849
  %21 = mul i16 %18, 733
  %22 = xor i16 %20, %21
  %23 = xor i16 %20, 23130
  %24 = zext i16 %20 to i32
  %25 = shl nuw i32 %24, 16
  %26 = xor i16 %20, 4660
  %27 = zext i16 %26 to i32
  %28 = or disjoint i32 %25, %27
  %29 = trunc i16 %20 to i8
  %30 = and i8 %29, 1
  %31 = add i16 %19, 29269
  %32 = lshr i16 %20, 8
  %33 = trunc nuw i16 %32 to i8
  %34 = tail call fastcc { i16, i16 } @bv_stage32(i16 %20, i16 %23, i16 noundef %22) #8
  %35 = extractvalue { i16, i16 } %34, 0
  %36 = extractvalue { i16, i16 } %34, 1
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #9
  store i32 %28, ptr %2, align 1, !tbaa !6
  store i8 %30, ptr %7, align 1, !tbaa !11
  call fastcc void @bv_stage33(ptr dead_on_unwind writable sret(%struct.BvR33) align 1 %1, ptr noundef dead_on_return %2, i16 noundef %22) #8
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #9
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #9
  store i16 %20, ptr %4, align 1, !tbaa !2
  store i16 %31, ptr %8, align 1, !tbaa !2
  store i8 %33, ptr %9, align 1, !tbaa !11
  call fastcc void @bv_stage40(ptr dead_on_unwind writable sret(%struct.BvR40) align 1 %3, ptr noundef dead_on_return %4, i16 noundef %22) #8
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #9
  %37 = xor i16 %22, -32767
  %38 = tail call fastcc { i16, i16 } @bv_stage32(i16 %35, i16 %36, i16 noundef %37) #8
  %39 = extractvalue { i16, i16 } %38, 0
  %40 = extractvalue { i16, i16 } %38, 1
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #9
  call fastcc void @bv_stage33(ptr dead_on_unwind writable sret(%struct.BvR33) align 1 %5, ptr noundef dead_on_return %1, i16 noundef %37) #8
  call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(5) %1, ptr noundef nonnull align 1 dereferenceable(5) %5, i16 5, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #9
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #9
  call fastcc void @bv_stage40(ptr dead_on_unwind writable sret(%struct.BvR40) align 1 %6, ptr noundef dead_on_return %3, i16 noundef %37) #8
  call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(5) %3, ptr noundef nonnull align 1 dereferenceable(5) %6, i16 5, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #9
  %41 = getelementptr inbounds nuw [4 x i8], ptr @bv_out32, i16 %18
  store i16 %39, ptr %41, align 1, !tbaa !2
  %42 = getelementptr inbounds nuw i8, ptr %41, i16 2
  store i16 %40, ptr %42, align 1, !tbaa !2
  %43 = load i32, ptr %1, align 1
  %44 = load i8, ptr %10, align 1
  %45 = and i8 %44, 1
  %46 = zext nneg i8 %45 to i32
  %47 = shl nuw i32 %46, 31
  %48 = xor i32 %47, %43
  %49 = getelementptr inbounds nuw [4 x i8], ptr @bv_out33, i16 %18
  store i32 %48, ptr %49, align 1, !tbaa !6
  %50 = load i16, ptr %3, align 1
  %51 = getelementptr inbounds nuw [6 x i8], ptr @bv_out40, i16 %18
  store i16 %50, ptr %51, align 1, !tbaa !2
  %52 = load i16, ptr %11, align 1
  %53 = getelementptr inbounds nuw i8, ptr %51, i16 2
  store i16 %52, ptr %53, align 1, !tbaa !2
  %54 = load i8, ptr %12, align 1
  %55 = zext i8 %54 to i16
  %56 = getelementptr inbounds nuw i8, ptr %51, i16 4
  store i16 %55, ptr %56, align 1, !tbaa !2
  %57 = getelementptr inbounds nuw [6 x i8], ptr @bv_reread, i16 %18
  store i16 %20, ptr %57, align 1, !tbaa !2
  %58 = getelementptr inbounds nuw i8, ptr %57, i16 2
  store i16 %26, ptr %58, align 1, !tbaa !2
  %59 = xor i16 %32, %20
  %60 = getelementptr inbounds nuw i8, ptr %57, i16 4
  store i16 %59, ptr %60, align 1, !tbaa !2
  %61 = add nuw nsw i16 %18, 1
  %62 = icmp eq i16 %61, 96
  br i1 %62, label %14, label %16, !llvm.loop !12
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none)
define internal fastcc { i16, i16 } @bv_stage32(i16 %0, i16 %1, i16 noundef %2) unnamed_addr #3 {
  %4 = xor i16 %2, %0
  %5 = add i16 %4, %1
  %6 = mul i16 %4, 25173
  %7 = add i16 %6, %5
  %8 = shl i16 %4, 3
  %9 = xor i16 %5, %8
  %10 = insertvalue { i16, i16 } poison, i16 %7, 0
  %11 = insertvalue { i16, i16 } %10, i16 %9, 1
  ret { i16, i16 } %11
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal fastcc void @bv_stage33(ptr dead_on_unwind noalias nonnull writable sret(%struct.BvR33) align 1 captures(none) initializes((0, 4)) %0, ptr noundef nonnull readonly captures(none) dead_on_return %1, i16 noundef %2) unnamed_addr #4 {
  %4 = load i32, ptr %1, align 1, !tbaa !13
  %5 = zext i16 %2 to i32
  %6 = xor i32 %4, %5
  %7 = getelementptr inbounds nuw i8, ptr %1, i16 4
  %8 = load i8, ptr %7, align 1
  %9 = and i8 %8, 1
  %10 = shl i32 %6, 3
  %11 = icmp eq i8 %9, 0
  %12 = select i1 %11, i32 40503, i32 11291
  %13 = add i32 %12, %10
  store i32 %13, ptr %0, align 1, !tbaa !13
  %14 = trunc i32 %6 to i8
  %15 = lshr i8 %14, 7
  %16 = getelementptr inbounds nuw i8, ptr %0, i16 4
  %17 = load i8, ptr %16, align 1
  %18 = and i8 %17, -2
  %19 = or disjoint i8 %18, %15
  store i8 %19, ptr %16, align 1
  ret void
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #5

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal fastcc void @bv_stage40(ptr dead_on_unwind noalias nonnull writable writeonly sret(%struct.BvR40) align 1 captures(none) initializes((0, 5)) %0, ptr noundef nonnull readonly captures(none) dead_on_return %1, i16 noundef %2) unnamed_addr #4 {
  %4 = load i16, ptr %1, align 1, !tbaa !15
  %5 = add i16 %4, %2
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %7 = load i16, ptr %6, align 1, !tbaa !17
  %8 = xor i16 %7, %5
  %9 = getelementptr inbounds nuw i8, ptr %1, i16 4
  %10 = load i8, ptr %9, align 1, !tbaa !18
  %11 = trunc i16 %8 to i8
  %12 = add i8 %10, %11
  %13 = shl i16 %5, 3
  %14 = lshr i16 %5, 5
  %15 = xor i16 %8, %14
  %16 = add i16 %15, %13
  store i16 %16, ptr %0, align 1, !tbaa !15
  %17 = zext i8 %12 to i16
  %18 = sub i16 %8, %17
  %19 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i16 %18, ptr %19, align 1, !tbaa !17
  %20 = lshr i16 %5, 8
  %21 = trunc nuw i16 %20 to i8
  %22 = xor i8 %12, %21
  %23 = getelementptr inbounds nuw i8, ptr %0, i16 4
  store i8 %22, ptr %23, align 1, !tbaa !18
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #6

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #7

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree noinline norecurse nosync nounwind optsize memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #3 = { mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #4 = { mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #5 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #7 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #8 = { optsize }
attributes #9 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !7, i64 0}
!7 = !{!"long", !4, i64 0}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = !{i64 1450}
!11 = !{!4, !4, i64 0}
!12 = distinct !{!12, !9}
!13 = !{!14, !7, i64 0}
!14 = !{!"", !7, i64 0, !4, i64 4}
!15 = !{!16, !3, i64 0}
!16 = !{!"", !3, i64 0, !3, i64 2, !4, i64 4}
!17 = !{!16, !3, i64 2}
!18 = !{!16, !4, i64 4}
