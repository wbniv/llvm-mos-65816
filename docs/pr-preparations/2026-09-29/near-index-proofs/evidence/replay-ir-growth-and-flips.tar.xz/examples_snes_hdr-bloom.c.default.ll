; ModuleID = '/work/examples/snes/hdr-bloom.c'
source_filename = "/work/examples/snes/hdr-bloom.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.BloomLayer = type { %struct.Drawable, [896 x i16] }
%struct.Drawable = type { ptr, i8 }
%struct.DrawableVT = type { ptr, ptr }
%struct.TitleLayer = type { %struct.Drawable, ptr, ptr, ptr, ptr, i8, i8, i16, i16, i16, i16, i16, i16, i8, i16, i8, i8, i8, i8, i8, i8, i16, i16, %struct.HScrollDB, %struct.HScrollDB }
%struct.HScrollDB = type { [2 x %struct.HScrollN], i8 }
%struct.HScrollN = type { [25 x i8] }
%struct.bloom_state = type { [6 x i16], [6 x i16], [6 x i16], [6 x i16], [896 x i8], [121 x i8], i16 }
%struct.Display = type { %struct.UploadQueue, %struct.VramAlloc, %struct.Scene, i8, i8, i8, i8, i8 }
%struct.UploadQueue = type { [16 x %struct.UpqJob], i8, i8 }
%struct.UpqJob = type { i16, i16, i16, i8, i8, i8, i8, i8 }
%struct.VramAlloc = type { i16, i16 }
%struct.Scene = type { [4 x ptr], i8 }
%struct.HScrollW = type { ptr, i8 }

@main.bl = internal global %struct.BloomLayer zeroinitializer, align 1
@BLOOM_VT = internal constant %struct.DrawableVT { ptr @_bloom_reserve, ptr @_bloom_emit }, align 1
@main.title = internal global %struct.TitleLayer zeroinitializer, align 1
@.str = private unnamed_addr constant [10 x i8] c"HDR BLOOM\00", align 1
@.str.1 = private unnamed_addr constant [15 x i8] c"SATURATING ADD\00", align 1
@corpus_result = dso_local global i16 0, align 1
@bs = internal global %struct.bloom_state zeroinitializer, align 1
@bloom_pal = internal constant [16 x i16] [i16 0, i16 6146, i16 12293, i16 18441, i16 22542, i16 24627, i16 22616, i16 16540, i16 10495, i16 6559, i16 3647, i16 2783, i16 7007, i16 15295, i16 24575, i16 32767], align 1
@TITLE_VT = internal constant %struct.DrawableVT { ptr @_title_reserve, ptr @_title_emit }, align 1
@FONT8 = internal unnamed_addr constant [512 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 32, i16 0, i16 80, i16 80, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 80, i16 80, i16 248, i16 80, i16 248, i16 80, i16 80, i16 0, i16 32, i16 120, i16 160, i16 112, i16 40, i16 240, i16 32, i16 0, i16 196, i16 200, i16 16, i16 32, i16 64, i16 152, i16 12, i16 0, i16 96, i16 144, i16 160, i16 64, i16 168, i16 144, i16 104, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 16, i16 32, i16 64, i16 64, i16 64, i16 32, i16 16, i16 0, i16 64, i16 32, i16 16, i16 16, i16 16, i16 32, i16 64, i16 0, i16 0, i16 32, i16 168, i16 112, i16 168, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 248, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 64, i16 0, i16 0, i16 0, i16 248, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 0, i16 8, i16 8, i16 16, i16 32, i16 64, i16 128, i16 128, i16 0, i16 112, i16 136, i16 152, i16 168, i16 200, i16 136, i16 112, i16 0, i16 32, i16 96, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 64, i16 248, i16 0, i16 112, i16 136, i16 8, i16 48, i16 8, i16 136, i16 112, i16 0, i16 16, i16 48, i16 80, i16 144, i16 248, i16 16, i16 16, i16 0, i16 248, i16 128, i16 240, i16 8, i16 8, i16 136, i16 112, i16 0, i16 112, i16 136, i16 128, i16 240, i16 136, i16 136, i16 112, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 64, i16 64, i16 0, i16 112, i16 136, i16 136, i16 112, i16 136, i16 136, i16 112, i16 0, i16 112, i16 136, i16 136, i16 120, i16 8, i16 136, i16 112, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 64, i16 0, i16 16, i16 32, i16 64, i16 128, i16 64, i16 32, i16 16, i16 0, i16 0, i16 0, i16 248, i16 0, i16 248, i16 0, i16 0, i16 0, i16 128, i16 64, i16 32, i16 16, i16 32, i16 64, i16 128, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 0, i16 32, i16 0, i16 112, i16 136, i16 184, i16 168, i16 184, i16 128, i16 112, i16 0, i16 112, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 240, i16 136, i16 136, i16 240, i16 136, i16 136, i16 240, i16 0, i16 112, i16 136, i16 128, i16 128, i16 128, i16 136, i16 112, i16 0, i16 224, i16 144, i16 136, i16 136, i16 136, i16 144, i16 224, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 248, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 128, i16 176, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 112, i16 32, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 56, i16 16, i16 16, i16 16, i16 144, i16 144, i16 96, i16 0, i16 136, i16 144, i16 160, i16 192, i16 160, i16 144, i16 136, i16 0, i16 128, i16 128, i16 128, i16 128, i16 128, i16 128, i16 248, i16 0, i16 136, i16 216, i16 168, i16 136, i16 136, i16 136, i16 136, i16 0, i16 136, i16 200, i16 168, i16 152, i16 136, i16 136, i16 136, i16 0, i16 112, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 240, i16 136, i16 136, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 136, i16 136, i16 168, i16 144, i16 104, i16 0, i16 240, i16 136, i16 136, i16 240, i16 160, i16 144, i16 136, i16 0, i16 112, i16 136, i16 128, i16 112, i16 8, i16 136, i16 112, i16 0, i16 248, i16 32, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 80, i16 32, i16 0, i16 136, i16 136, i16 136, i16 168, i16 168, i16 216, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 80, i16 136, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 32, i16 32, i16 32, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 128, i16 248, i16 0, i16 48, i16 32, i16 32, i16 32, i16 32, i16 32, i16 48, i16 0, i16 128, i16 128, i16 64, i16 32, i16 16, i16 8, i16 8, i16 0, i16 48, i16 16, i16 16, i16 16, i16 16, i16 16, i16 48, i16 0, i16 32, i16 80, i16 136, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248], align 1
@FONT16 = internal unnamed_addr constant [2048 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 192, i16 192, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 768, i16 768, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 -4096, i16 -4096, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3840, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 3312, i16 15360, i16 15360, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 28, i16 28, i16 796, i16 127, i16 127, i16 796, i16 796, i16 127, i16 112, i16 112, i16 3184, i16 252, i16 252, i16 -28816, i16 -28816, i16 252, i16 127, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 0, i16 0, i16 252, i16 -28816, i16 -28816, i16 3184, i16 7168, i16 7168, i16 0, i16 0, i16 3, i16 63, i16 123, i16 1147, i16 63, i16 4111, i16 3075, i16 123, i16 192, i16 248, i16 8414, i16 16064, i16 2040, i16 248, i16 8414, i16 8414, i16 63, i16 7171, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 2040, i16 14272, i16 -512, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3585, i16 3, i16 7, i16 28, i16 56, i16 1904, i16 3808, i16 7392, i16 14528, i16 14464, i16 28672, i16 14, i16 284, i16 824, i16 1792, i16 3584, i16 0, i16 0, i16 0, i16 -8162, i16 -16354, i16 -32482, i16 286, i16 1792, i16 1792, i16 0, i16 0, i16 15, i16 31, i16 828, i16 828, i16 573, i16 31, i16 31, i16 63, i16 192, i16 224, i16 240, i16 2288, i16 7392, i16 15488, i16 30720, i16 -32648, i16 382, i16 3060, i16 3825, i16 1275, i16 127, i16 63, i16 7936, i16 3840, i16 248, i16 3824, i16 7904, i16 7392, i16 4332, i16 12492, i16 -1280, i16 -3328, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 7, i16 15, i16 15, i16 15, i16 15, i16 15, i16 240, i16 192, i16 15488, i16 -4096, i16 -8192, i16 -16384, i16 -16384, i16 -16384, i16 15, i16 7, i16 3, i16 256, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 16512, i16 192, i16 240, i16 -4096, i16 15360, i16 0, i16 0, i16 15, i16 3, i16 513, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 224, i16 240, i16 2288, i16 3312, i16 3312, i16 3312, i16 0, i16 1, i16 3, i16 15, i16 0, i16 768, i16 0, i16 0, i16 3312, i16 7392, i16 15552, i16 30720, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 51, i16 31, i16 15, i16 1027, i16 0, i16 0, i16 192, i16 192, i16 12492, i16 252, i16 1016, i16 16320, i16 15, i16 31, i16 51, i16 1027, i16 3072, i16 0, i16 0, i16 0, i16 1784, i16 252, i16 13004, i16 16320, i16 -3328, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 3, i16 63, i16 63, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 248, i16 248, i16 63, i16 3075, i16 3075, i16 3, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 16064, i16 16064, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 286, i16 828, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 28800, i16 -4096, i16 -8192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 -512, i16 -512, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7360, i16 14464, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7168, i16 14336, i16 28672, i16 -8192, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 828, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 15, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 1, i16 3, i16 15, i16 15, i16 513, i16 513, i16 1, i16 1, i16 240, i16 240, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 1, i16 1, i16 1, i16 1, i16 1, i16 1, i16 0, i16 0, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 31744, i16 31744, i16 15, i16 31, i16 318, i16 828, i16 3840, i16 3840, i16 3, i16 15, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 63, i16 510, i16 4080, i16 31, i16 318, i16 318, i16 318, i16 63, i16 63, i16 3840, i16 3840, i16 32640, i16 -1024, i16 -8192, i16 -32768, i16 255, i16 255, i16 -256, i16 -256, i16 15, i16 63, i16 824, i16 3840, i16 2055, i16 7, i16 256, i16 256, i16 252, i16 254, i16 -8161, i16 -4081, i16 510, i16 1020, i16 -7906, i16 -4081, i16 0, i16 0, i16 56, i16 60, i16 63, i16 31, i16 3840, i16 1792, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 15, i16 286, i16 62, i16 126, i16 510, i16 510, i16 8670, i16 24990, i16 -7906, i16 -7906, i16 828, i16 828, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 -16098, i16 -32482, i16 255, i16 255, i16 -7906, i16 -7906, i16 1792, i16 1792, i16 31, i16 63, i16 828, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 254, i16 254, i16 -256, i16 -256, i16 252, i16 254, i16 -8161, i16 -4081, i16 0, i16 0, i16 60, i16 62, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 63, i16 63, i16 318, i16 828, i16 254, i16 255, i16 -2041, i16 -256, i16 508, i16 254, i16 -4081, i16 -2041, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 -32761, i16 7, i16 7, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 31, i16 318, i16 892, i16 0, i16 1, i16 3, i16 7, i16 7, i16 7, i16 256, i16 256, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 28800, i16 -8192, i16 -8192, i16 15, i16 31, i16 828, i16 828, i16 828, i16 31, i16 15, i16 796, i16 252, i16 254, i16 -4081, i16 -4081, i16 15, i16 510, i16 1020, i16 -3826, i16 828, i16 828, i16 828, i16 828, i16 31, i16 15, i16 1792, i16 768, i16 -4081, i16 15, i16 15, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 318, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 31, i16 31, i16 15, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 270, i16 796, i16 824, i16 1792, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 15, i16 60, i16 828, i16 0, i16 0, i16 60, i16 240, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 15360, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 60, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 60, i16 0, i16 3, i16 15, i16 60, i16 768, i16 3840, i16 0, i16 0, i16 4080, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 31, i16 63, i16 828, i16 3840, i16 3840, i16 7, i16 7, i16 7, i16 240, i16 248, i16 -32644, i16 -32132, i16 2040, i16 4080, i16 16064, i16 31872, i16 256, i16 256, i16 7, i16 7, i16 7, i16 256, i16 256, i16 0, i16 -4096, i16 -8192, i16 128, i16 128, i16 24704, i16 -8192, i16 -8192, i16 0, i16 31, i16 63, i16 828, i16 573, i16 573, i16 573, i16 573, i16 573, i16 248, i16 252, i16 -15812, i16 4590, i16 494, i16 4590, i16 1020, i16 1016, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 0, i16 0, i16 0, i16 32512, i16 764, i16 248, i16 -256, i16 -512, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 892, i16 1020, i16 1020, i16 255, i16 255, i16 224, i16 240, i16 -32648, i16 -16324, i16 -32196, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -28928, i16 1792, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 0, i16 0, i16 28, i16 60, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -8164, i16 -3572, i16 -30976, i16 768, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 8988, i16 8988, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 60, i16 60, i16 828, i16 828, i16 828, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 255, i16 255, i16 16128, i16 16128, i16 12480, i16 12480, i16 12480, i16 12480, i16 252, i16 252, i16 -256, i16 -256, i16 63, i16 63, i16 3075, i16 3075, i16 3, i16 3, i16 51, i16 51, i16 252, i16 252, i16 4080, i16 4080, i16 3312, i16 3312, i16 3312, i16 3312, i16 3123, i16 3123, i16 63, i16 63, i16 31, i16 15, i16 1792, i16 768, i16 3312, i16 3312, i16 3312, i16 3312, i16 7392, i16 15552, i16 -2048, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 765, i16 255, i16 255, i16 255, i16 28, i16 60, i16 1912, i16 4080, i16 7904, i16 15552, i16 30848, i16 12480, i16 255, i16 765, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 224, i16 240, i16 248, i16 124, i16 572, i16 828, i16 3840, i16 3840, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 0, i16 0, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 248, i16 252, i16 254, i16 2295, i16 3315, i16 3315, i16 3315, i16 3315, i16 60, i16 124, i16 1020, i16 988, i16 9116, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 15360, i16 15360, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 -6400, i16 -6400, i16 240, i16 248, i16 252, i16 254, i16 255, i16 255, i16 2295, i16 3315, i16 60, i16 60, i16 828, i16 828, i16 828, i16 956, i16 1020, i16 1020, i16 3313, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 15360, i16 15360, i16 1020, i16 1020, i16 892, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -31972, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -512, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 224, i16 240, i16 -32648, i16 -15304, i16 -31176, i16 1592, i16 1592, i16 1592, i16 765, i16 765, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 1784, i16 1784, i16 17976, i16 1656, i16 764, i16 764, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 63, i16 127, i16 2040, i16 4080, i16 1784, i16 255, i16 127, i16 63, i16 248, i16 252, i16 -15812, i16 -256, i16 3840, i16 240, i16 248, i16 252, i16 7936, i16 3840, i16 224, i16 255, i16 255, i16 127, i16 16128, i16 7936, i16 -32132, i16 -15556, i16 892, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 -4096, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 28, i16 28, i16 796, i16 796, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 510, i16 255, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 828, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 248, i16 248, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 124, i16 124, i16 1912, i16 1912, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 572, i16 63, i16 31, i16 15, i16 7, i16 768, i16 256, i16 1656, i16 3824, i16 3824, i16 7392, i16 15552, i16 30848, i16 -4096, i16 -8192, i16 243, i16 243, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 156, i16 156, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 2295, i16 255, i16 510, i16 892, i16 16128, i16 7936, i16 25500, i16 25500, i16 9180, i16 1020, i16 1020, i16 -30856, i16 -16640, i16 7680, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 15, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 14528, i16 31, i16 63, i16 892, i16 2040, i16 4080, i16 3824, i16 15360, i16 15360, i16 4320, i16 240, i16 248, i16 -32644, i16 572, i16 828, i16 3840, i16 3840, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 7, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 7, i16 7, i16 7, i16 7, i16 7, i16 7, i16 256, i16 256, i16 28800, i16 24704, i16 24704, i16 24704, i16 24704, i16 24704, i16 -8192, i16 -8192, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 1, i16 3, i16 7, i16 252, i16 252, i16 1020, i16 -31876, i16 2040, i16 4080, i16 7904, i16 15552, i16 15, i16 31, i16 318, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 30848, i16 -4096, i16 -8192, i16 252, i16 252, i16 1020, i16 -256, i16 -256, i16 31, i16 31, i16 286, i16 286, i16 286, i16 286, i16 286, i16 286, i16 224, i16 224, i16 -2048, i16 -2048, i16 -32768, i16 -32768, i16 -32768, i16 -32768, i16 286, i16 286, i16 286, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 -32768, i16 -32768, i16 -32768, i16 224, i16 224, i16 -2048, i16 -2048, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 3, i16 1, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 128, i16 192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 768, i16 256, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 0, i16 0, i16 0, i16 224, i16 224, i16 2288, i16 2288, i16 3312, i16 3312, i16 3312, i16 3312, i16 0, i16 0, i16 0, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 3312, i16 3312, i16 3312, i16 7392, i16 7392, i16 -2048, i16 -2048, i16 0, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1840, i16 3584, i16 3072, i16 192, i16 224, i16 -32656, i16 -16328, i16 -32740, i16 524, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 127, i16 127, i16 7936, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 -512], align 1
@hdr_bloom_gate_crc.s = internal global %struct.bloom_state zeroinitializer, align 1
@bloom_init.px = internal unnamed_addr constant [6 x i16] [i16 14, i16 17, i16 4, i16 28, i16 6, i16 26], align 1
@bloom_init.py = internal unnamed_addr constant [6 x i16] [i16 13, i16 13, i16 4, i16 5, i16 22, i16 21], align 1
@bloom_init.vX = internal unnamed_addr constant [6 x i16] [i16 3, i16 -3, i16 5, i16 -6, i16 4, i16 -5], align 1
@bloom_init.vY = internal unnamed_addr constant [6 x i16] [i16 2, i16 -2, i16 6, i16 4, i16 -5, i16 3], align 1
@title_end._title_bg_black = internal constant i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca %struct.Display, align 1
  store ptr @BLOOM_VT, ptr @main.bl, align 1, !tbaa !6
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #12
  store volatile i8 -113, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !10
  br label %2

2:                                                ; preds = %6, %0
  %3 = phi i16 [ 8449, %0 ], [ %7, %6 ]
  switch i16 %3, label %4 [
    i16 8452, label %6
    i16 8470, label %6
    i16 8471, label %6
    i16 8472, label %6
    i16 8473, label %6
    i16 8481, label %6
    i16 8482, label %6
  ]

4:                                                ; preds = %2
  %5 = inttoptr i16 %3 to ptr
  store volatile i8 0, ptr %5, align 1, !tbaa !10
  br label %6

6:                                                ; preds = %4, %2, %2, %2, %2, %2, %2, %2
  %7 = add nuw nsw i16 %3, 1
  %8 = icmp eq i16 %7, 8500
  br i1 %8, label %9, label %2, !llvm.loop !11

9:                                                ; preds = %6
  %10 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %11 = getelementptr inbounds nuw i8, ptr %1, i16 190
  %12 = getelementptr inbounds nuw i8, ptr %1, i16 194
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) %10, i8 0, i64 6, i1 false)
  store i32 0, ptr %11, align 1
  store i8 15, ptr %12, align 1, !tbaa !13
  %13 = getelementptr inbounds nuw i8, ptr %1, i16 195
  store i8 15, ptr %13, align 1, !tbaa !18
  store volatile i8 1, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !10
  store volatile i8 0, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !10
  store volatile i8 -127, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !10
  %14 = getelementptr inbounds nuw i8, ptr %1, i16 192
  %15 = load i8, ptr %14, align 1, !tbaa !19
  %16 = icmp eq i8 %15, 0
  br i1 %16, label %19, label %17

17:                                               ; preds = %9
  %18 = getelementptr inbounds nuw i8, ptr %1, i16 193
  store i8 1, ptr %18, align 1, !tbaa !20
  br label %19

19:                                               ; preds = %17, %9
  %20 = load i8, ptr %11, align 1, !tbaa !21
  %21 = icmp ult i8 %20, 4
  br i1 %21, label %22, label %27

22:                                               ; preds = %19
  %23 = getelementptr inbounds nuw i8, ptr %1, i16 182
  %24 = zext nneg i8 %20 to i16
  %25 = add nuw nsw i8 %20, 1
  store i8 %25, ptr %11, align 1, !tbaa !21
  %26 = getelementptr inbounds nuw [2 x i8], ptr %23, i16 %24
  store ptr @main.bl, ptr %26, align 1, !tbaa !22
  br label %27

27:                                               ; preds = %19, %22
  %28 = getelementptr inbounds nuw i8, ptr %1, i16 178
  %29 = load ptr, ptr @main.bl, align 1, !tbaa !24
  %30 = load ptr, ptr %29, align 1, !tbaa !25
  call void %30(ptr noundef nonnull @main.bl, ptr noundef nonnull %28) #13, !inline_history !27
  %31 = getelementptr inbounds nuw i8, ptr %1, i16 191
  %32 = load i8, ptr %31, align 1, !tbaa !28
  %33 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.bl, i16 2), align 1, !tbaa !29
  %34 = or i8 %33, %32
  store i8 %34, ptr %31, align 1, !tbaa !28
  store volatile i8 %34, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !10
  store ptr @TITLE_VT, ptr @main.title, align 1, !tbaa !30
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !34
  store ptr @.str, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 3), align 1, !tbaa !35
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 5), align 1, !tbaa !36
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 7), align 1, !tbaa !37
  store i8 14, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 11), align 1, !tbaa !38
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 9), align 1, !tbaa !39
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 12), align 1, !tbaa !40
  store i16 96, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 13), align 1, !tbaa !41
  store i16 112, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 15), align 1, !tbaa !42
  store i16 16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 17), align 1, !tbaa !43
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 28), align 1, !tbaa !44
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !45
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !46
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !47
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !48
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !49
  store i16 32767, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 34), align 1, !tbaa !50
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 36), align 1, !tbaa !51
  %35 = load i8, ptr %31, align 1, !tbaa !28
  %36 = load i8, ptr %14, align 1, !tbaa !19
  %37 = icmp eq i8 %36, 0
  br i1 %37, label %40, label %38

38:                                               ; preds = %27
  %39 = getelementptr inbounds nuw i8, ptr %1, i16 193
  store i8 1, ptr %39, align 1, !tbaa !20
  br label %40

40:                                               ; preds = %38, %27
  %41 = load i8, ptr %11, align 1, !tbaa !21
  %42 = icmp ult i8 %41, 4
  br i1 %42, label %43, label %48

43:                                               ; preds = %40
  %44 = getelementptr inbounds nuw i8, ptr %1, i16 182
  %45 = zext nneg i8 %41 to i16
  %46 = add nuw nsw i8 %41, 1
  store i8 %46, ptr %11, align 1, !tbaa !21
  %47 = getelementptr inbounds nuw [2 x i8], ptr %44, i16 %45
  store ptr @main.title, ptr %47, align 1, !tbaa !22
  br label %48

48:                                               ; preds = %43, %40
  call void @_title_reserve(ptr noundef nonnull @main.title, ptr nonnull poison) #13, !inline_history !27
  %49 = load i8, ptr %31, align 1, !tbaa !28
  %50 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !29
  %51 = or i8 %50, %49
  store volatile i8 %51, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !10
  store i8 %35, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !52
  store i8 2, ptr %31, align 1, !tbaa !28
  store volatile i8 2, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !10
  store volatile i8 24, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !10
  store i8 0, ptr %12, align 1, !tbaa !13
  store i8 15, ptr %13, align 1, !tbaa !18
  %52 = getelementptr inbounds nuw i8, ptr %1, i16 182
  br label %53

53:                                               ; preds = %81, %48
  %54 = load i8, ptr %11, align 1, !tbaa !21
  %55 = icmp eq i8 %54, 0
  br i1 %55, label %67, label %56

56:                                               ; preds = %53, %56
  %57 = phi i8 [ %64, %56 ], [ 0, %53 ]
  %58 = zext i8 %57 to i16
  %59 = getelementptr inbounds nuw [2 x i8], ptr %52, i16 %58
  %60 = load ptr, ptr %59, align 1, !tbaa !22
  %61 = load ptr, ptr %60, align 1, !tbaa !24
  %62 = getelementptr inbounds nuw i8, ptr %61, i16 2
  %63 = load ptr, ptr %62, align 1, !tbaa !53
  call void %63(ptr noundef nonnull %60, ptr noundef nonnull %1) #13, !inline_history !54
  %64 = add nuw i8 %57, 1
  %65 = load i8, ptr %11, align 1, !tbaa !21
  %66 = icmp ult i8 %64, %65
  br i1 %66, label %56, label %67, !llvm.loop !55

67:                                               ; preds = %56, %53
  %68 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !10
  br label %69

69:                                               ; preds = %69, %67
  %70 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !10
  %71 = icmp sgt i8 %70, -1
  br i1 %71, label %69, label %72, !llvm.loop !56

72:                                               ; preds = %69
  call fastcc void @upq_flush(ptr noundef nonnull %1) #14
  %73 = load i8, ptr %12, align 1, !tbaa !13
  %74 = load i8, ptr %13, align 1, !tbaa !18
  %75 = icmp ult i8 %73, %74
  br i1 %75, label %78, label %76

76:                                               ; preds = %72
  %77 = icmp ugt i8 %73, %74
  br i1 %77, label %78, label %81

78:                                               ; preds = %76, %72
  %79 = phi i8 [ 1, %72 ], [ -1, %76 ]
  %80 = add i8 %79, %73
  store i8 %80, ptr %12, align 1, !tbaa !13
  br label %81

81:                                               ; preds = %78, %76
  %82 = phi i8 [ %73, %76 ], [ %80, %78 ]
  %83 = and i8 %82, 15
  store volatile i8 %83, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !10
  store i8 1, ptr %14, align 1, !tbaa !19
  %84 = load i8, ptr %12, align 1, !tbaa !13
  %85 = icmp eq i8 %84, 15
  br i1 %85, label %86, label %53, !llvm.loop !57

86:                                               ; preds = %81
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !48
  %87 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !49
  %88 = icmp eq i8 %87, -1
  br i1 %88, label %126, label %89

89:                                               ; preds = %86, %118
  %90 = phi i8 [ %121, %118 ], [ 0, %86 ]
  %91 = load i8, ptr %11, align 1, !tbaa !21
  %92 = icmp eq i8 %91, 0
  br i1 %92, label %104, label %93

93:                                               ; preds = %89, %93
  %94 = phi i8 [ %101, %93 ], [ 0, %89 ]
  %95 = zext i8 %94 to i16
  %96 = getelementptr inbounds nuw [2 x i8], ptr %52, i16 %95
  %97 = load ptr, ptr %96, align 1, !tbaa !22
  %98 = load ptr, ptr %97, align 1, !tbaa !24
  %99 = getelementptr inbounds nuw i8, ptr %98, i16 2
  %100 = load ptr, ptr %99, align 1, !tbaa !53
  call void %100(ptr noundef nonnull %97, ptr noundef nonnull %1) #13, !inline_history !58
  %101 = add nuw i8 %94, 1
  %102 = load i8, ptr %11, align 1, !tbaa !21
  %103 = icmp ult i8 %101, %102
  br i1 %103, label %93, label %104, !llvm.loop !55

104:                                              ; preds = %93, %89
  %105 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !10
  br label %106

106:                                              ; preds = %106, %104
  %107 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !10
  %108 = icmp sgt i8 %107, -1
  br i1 %108, label %106, label %109, !llvm.loop !56

109:                                              ; preds = %106
  call fastcc void @upq_flush(ptr noundef nonnull %1) #14
  %110 = load i8, ptr %12, align 1, !tbaa !13
  %111 = load i8, ptr %13, align 1, !tbaa !18
  %112 = icmp ult i8 %110, %111
  br i1 %112, label %115, label %113

113:                                              ; preds = %109
  %114 = icmp ugt i8 %110, %111
  br i1 %114, label %115, label %118

115:                                              ; preds = %113, %109
  %116 = phi i8 [ 1, %109 ], [ -1, %113 ]
  %117 = add i8 %116, %110
  store i8 %117, ptr %12, align 1, !tbaa !13
  br label %118

118:                                              ; preds = %115, %113
  %119 = phi i8 [ %110, %113 ], [ %117, %115 ]
  %120 = and i8 %119, 15
  store volatile i8 %120, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !10
  store i8 1, ptr %14, align 1, !tbaa !19
  %121 = add nuw i8 %90, 1
  %122 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !49
  %123 = icmp ne i8 %122, -1
  %124 = icmp ult i8 %90, -57
  %125 = select i1 %123, i1 %124, i1 false
  br i1 %125, label %89, label %126, !llvm.loop !59

126:                                              ; preds = %118, %86
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !48
  call fastcc void @bloom_init(ptr noundef nonnull @hdr_bloom_gate_crc.s) #14
  br label %127

127:                                              ; preds = %145, %126
  %128 = phi i16 [ 0, %126 ], [ %146, %145 ]
  %129 = phi i16 [ 0, %126 ], [ %156, %145 ]
  call fastcc void @bloom_step(ptr noundef nonnull @hdr_bloom_gate_crc.s) #14
  br label %130

130:                                              ; preds = %138, %127
  %131 = phi i16 [ 0, %127 ], [ %140, %138 ]
  %132 = phi i16 [ 0, %127 ], [ %139, %138 ]
  %133 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @hdr_bloom_gate_crc.s, i16 48), i16 %131
  %134 = load i8, ptr %133, align 1, !tbaa !10
  %135 = icmp eq i8 %134, -1
  br i1 %135, label %136, label %138

136:                                              ; preds = %130
  %137 = add i16 %132, 1
  br label %138

138:                                              ; preds = %136, %130
  %139 = phi i16 [ %137, %136 ], [ %132, %130 ]
  %140 = add nuw nsw i16 %131, 1
  %141 = icmp eq i16 %140, 896
  br i1 %141, label %142, label %130, !llvm.loop !60

142:                                              ; preds = %138
  store i16 %139, ptr getelementptr inbounds nuw (i8, ptr @hdr_bloom_gate_crc.s, i16 1065), align 1, !tbaa !61
  %143 = call i16 @llvm.fshl.i16(i16 %129, i16 %129, i16 1)
  %144 = xor i16 %139, %143
  br label %148

145:                                              ; preds = %148
  %146 = add nuw nsw i16 %128, 1
  %147 = icmp eq i16 %146, 12
  br i1 %147, label %159, label %127, !llvm.loop !63

148:                                              ; preds = %148, %142
  %149 = phi i16 [ 0, %142 ], [ %157, %148 ]
  %150 = phi i16 [ %144, %142 ], [ %156, %148 ]
  %151 = mul nuw nsw i16 %149, 33
  %152 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @hdr_bloom_gate_crc.s, i16 48), i16 %151
  %153 = load i8, ptr %152, align 1, !tbaa !10
  %154 = zext i8 %153 to i16
  %155 = call i16 @llvm.fshl.i16(i16 %150, i16 %150, i16 1)
  %156 = xor i16 %155, %154
  %157 = add nuw nsw i16 %149, 1
  %158 = icmp eq i16 %157, 28
  br i1 %158, label %145, label %148, !llvm.loop !64

159:                                              ; preds = %145
  store volatile i16 %156, ptr @corpus_result, align 1, !tbaa !2
  call fastcc void @bloom_init(ptr noundef nonnull @bs) #14
  br label %160

160:                                              ; preds = %190, %159
  %161 = phi i16 [ 90, %159 ], [ %162, %190 ]
  %162 = add nsw i16 %161, -1
  %163 = load i8, ptr %11, align 1, !tbaa !21
  %164 = icmp eq i8 %163, 0
  br i1 %164, label %176, label %165

165:                                              ; preds = %160, %165
  %166 = phi i8 [ %173, %165 ], [ 0, %160 ]
  %167 = zext i8 %166 to i16
  %168 = getelementptr inbounds nuw [2 x i8], ptr %52, i16 %167
  %169 = load ptr, ptr %168, align 1, !tbaa !22
  %170 = load ptr, ptr %169, align 1, !tbaa !24
  %171 = getelementptr inbounds nuw i8, ptr %170, i16 2
  %172 = load ptr, ptr %171, align 1, !tbaa !53
  call void %172(ptr noundef nonnull %169, ptr noundef nonnull %1) #13, !inline_history !65
  %173 = add nuw i8 %166, 1
  %174 = load i8, ptr %11, align 1, !tbaa !21
  %175 = icmp ult i8 %173, %174
  br i1 %175, label %165, label %176, !llvm.loop !55

176:                                              ; preds = %165, %160
  %177 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !10
  br label %178

178:                                              ; preds = %178, %176
  %179 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !10
  %180 = icmp sgt i8 %179, -1
  br i1 %180, label %178, label %181, !llvm.loop !56

181:                                              ; preds = %178
  call fastcc void @upq_flush(ptr noundef nonnull %1) #14
  %182 = load i8, ptr %12, align 1, !tbaa !13
  %183 = load i8, ptr %13, align 1, !tbaa !18
  %184 = icmp ult i8 %182, %183
  br i1 %184, label %187, label %185

185:                                              ; preds = %181
  %186 = icmp ugt i8 %182, %183
  br i1 %186, label %187, label %190

187:                                              ; preds = %185, %181
  %188 = phi i8 [ 1, %181 ], [ -1, %185 ]
  %189 = add i8 %188, %182
  store i8 %189, ptr %12, align 1, !tbaa !13
  br label %190

190:                                              ; preds = %187, %185
  %191 = phi i8 [ %182, %185 ], [ %189, %187 ]
  %192 = and i8 %191, 15
  store volatile i8 %192, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !10
  store i8 1, ptr %14, align 1, !tbaa !19
  %193 = icmp eq i16 %162, 0
  br i1 %193, label %194, label %160, !llvm.loop !66

194:                                              ; preds = %190
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !46
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !47
  br label %198

195:                                              ; preds = %227
  %196 = add nuw nsw i8 %199, 1
  %197 = icmp eq i8 %196, 90
  br i1 %197, label %232, label %198, !llvm.loop !67

198:                                              ; preds = %195, %194
  %199 = phi i8 [ 0, %194 ], [ %196, %195 ]
  %200 = load i8, ptr %11, align 1, !tbaa !21
  %201 = icmp eq i8 %200, 0
  br i1 %201, label %213, label %202

202:                                              ; preds = %198, %202
  %203 = phi i8 [ %210, %202 ], [ 0, %198 ]
  %204 = zext i8 %203 to i16
  %205 = getelementptr inbounds nuw [2 x i8], ptr %52, i16 %204
  %206 = load ptr, ptr %205, align 1, !tbaa !22
  %207 = load ptr, ptr %206, align 1, !tbaa !24
  %208 = getelementptr inbounds nuw i8, ptr %207, i16 2
  %209 = load ptr, ptr %208, align 1, !tbaa !53
  call void %209(ptr noundef nonnull %206, ptr noundef nonnull %1) #13, !inline_history !68
  %210 = add nuw i8 %203, 1
  %211 = load i8, ptr %11, align 1, !tbaa !21
  %212 = icmp ult i8 %210, %211
  br i1 %212, label %202, label %213, !llvm.loop !55

213:                                              ; preds = %202, %198
  %214 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !10
  br label %215

215:                                              ; preds = %215, %213
  %216 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !10
  %217 = icmp sgt i8 %216, -1
  br i1 %217, label %215, label %218, !llvm.loop !56

218:                                              ; preds = %215
  call fastcc void @upq_flush(ptr noundef nonnull %1) #14
  %219 = load i8, ptr %12, align 1, !tbaa !13
  %220 = load i8, ptr %13, align 1, !tbaa !18
  %221 = icmp ult i8 %219, %220
  br i1 %221, label %224, label %222

222:                                              ; preds = %218
  %223 = icmp ugt i8 %219, %220
  br i1 %223, label %224, label %227

224:                                              ; preds = %222, %218
  %225 = phi i8 [ 1, %218 ], [ -1, %222 ]
  %226 = add i8 %225, %219
  store i8 %226, ptr %12, align 1, !tbaa !13
  br label %227

227:                                              ; preds = %224, %222
  %228 = phi i8 [ %219, %222 ], [ %226, %224 ]
  %229 = and i8 %228, 15
  store volatile i8 %229, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !10
  store i8 1, ptr %14, align 1, !tbaa !19
  %230 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 19), align 1, !tbaa !69
  %231 = icmp sgt i16 %230, 3583
  br i1 %231, label %232, label %195

232:                                              ; preds = %227, %195
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !46
  store i8 0, ptr %13, align 1, !tbaa !18
  %233 = load i8, ptr %12, align 1, !tbaa !13
  %234 = icmp eq i8 %233, 0
  br i1 %234, label %268, label %235

235:                                              ; preds = %232, %263
  %236 = load i8, ptr %11, align 1, !tbaa !21
  %237 = icmp eq i8 %236, 0
  br i1 %237, label %249, label %238

238:                                              ; preds = %235, %238
  %239 = phi i8 [ %246, %238 ], [ 0, %235 ]
  %240 = zext i8 %239 to i16
  %241 = getelementptr inbounds nuw [2 x i8], ptr %52, i16 %240
  %242 = load ptr, ptr %241, align 1, !tbaa !22
  %243 = load ptr, ptr %242, align 1, !tbaa !24
  %244 = getelementptr inbounds nuw i8, ptr %243, i16 2
  %245 = load ptr, ptr %244, align 1, !tbaa !53
  call void %245(ptr noundef nonnull %242, ptr noundef nonnull %1) #13, !inline_history !70
  %246 = add nuw i8 %239, 1
  %247 = load i8, ptr %11, align 1, !tbaa !21
  %248 = icmp ult i8 %246, %247
  br i1 %248, label %238, label %249, !llvm.loop !55

249:                                              ; preds = %238, %235
  %250 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !10
  br label %251

251:                                              ; preds = %251, %249
  %252 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !10
  %253 = icmp sgt i8 %252, -1
  br i1 %253, label %251, label %254, !llvm.loop !56

254:                                              ; preds = %251
  call fastcc void @upq_flush(ptr noundef nonnull %1) #14
  %255 = load i8, ptr %12, align 1, !tbaa !13
  %256 = load i8, ptr %13, align 1, !tbaa !18
  %257 = icmp ult i8 %255, %256
  br i1 %257, label %260, label %258

258:                                              ; preds = %254
  %259 = icmp ugt i8 %255, %256
  br i1 %259, label %260, label %263

260:                                              ; preds = %258, %254
  %261 = phi i8 [ 1, %254 ], [ -1, %258 ]
  %262 = add i8 %261, %255
  store i8 %262, ptr %12, align 1, !tbaa !13
  br label %263

263:                                              ; preds = %260, %258
  %264 = phi i8 [ %255, %258 ], [ %262, %260 ]
  %265 = and i8 %264, 15
  store volatile i8 %265, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !10
  store i8 1, ptr %14, align 1, !tbaa !19
  %266 = load i8, ptr %12, align 1, !tbaa !13
  %267 = icmp eq i8 %266, 0
  br i1 %267, label %268, label %235, !llvm.loop !57

268:                                              ; preds = %263, %232
  %269 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !52
  %270 = load i8, ptr %31, align 1, !tbaa !28
  %271 = or i8 %270, %269
  %272 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !29
  %273 = xor i8 %272, -1
  %274 = and i8 %271, %273
  store i8 %274, ptr %31, align 1, !tbaa !28
  store volatile i8 %274, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !10
  store volatile i8 0, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !10
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !10
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !10
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !10
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !10
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !45
  %275 = load i8, ptr %10, align 1, !tbaa !71
  %276 = icmp ugt i8 %275, 15
  br i1 %276, label %288, label %277

277:                                              ; preds = %268
  %278 = zext nneg i8 %275 to i16
  %279 = add nuw nsw i8 %275, 1
  store i8 %279, ptr %10, align 1, !tbaa !71
  %280 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %278
  %281 = getelementptr inbounds nuw i8, ptr %280, i16 10
  store i8 1, ptr %281, align 1, !tbaa !72
  store i16 0, ptr %280, align 1, !tbaa !74
  %282 = getelementptr inbounds nuw i8, ptr %280, i16 9
  store i8 0, ptr %282, align 1, !tbaa !75
  %283 = getelementptr inbounds nuw i8, ptr %280, i16 7
  store i8 34, ptr %283, align 1, !tbaa !76
  %284 = getelementptr inbounds nuw i8, ptr %280, i16 8
  store i8 0, ptr %284, align 1, !tbaa !77
  %285 = getelementptr inbounds nuw i8, ptr %280, i16 2
  store i16 ptrtoint (ptr @title_end._title_bg_black to i16), ptr %285, align 1, !tbaa !78
  %286 = getelementptr inbounds nuw i8, ptr %280, i16 6
  store i8 0, ptr %286, align 1, !tbaa !79
  %287 = getelementptr inbounds nuw i8, ptr %280, i16 4
  store i16 2, ptr %287, align 1, !tbaa !80
  br label %288

288:                                              ; preds = %268, %277
  store i8 15, ptr %13, align 1, !tbaa !18
  br label %289

289:                                              ; preds = %317, %288
  call fastcc void @bloom_step(ptr noundef nonnull @bs) #14
  %290 = load i8, ptr %11, align 1, !tbaa !21
  %291 = icmp eq i8 %290, 0
  br i1 %291, label %303, label %292

292:                                              ; preds = %289, %292
  %293 = phi i8 [ %300, %292 ], [ 0, %289 ]
  %294 = zext i8 %293 to i16
  %295 = getelementptr inbounds nuw [2 x i8], ptr %52, i16 %294
  %296 = load ptr, ptr %295, align 1, !tbaa !22
  %297 = load ptr, ptr %296, align 1, !tbaa !24
  %298 = getelementptr inbounds nuw i8, ptr %297, i16 2
  %299 = load ptr, ptr %298, align 1, !tbaa !53
  call void %299(ptr noundef nonnull %296, ptr noundef nonnull %1) #13, !inline_history !81
  %300 = add nuw i8 %293, 1
  %301 = load i8, ptr %11, align 1, !tbaa !21
  %302 = icmp ult i8 %300, %301
  br i1 %302, label %292, label %303, !llvm.loop !55

303:                                              ; preds = %292, %289
  %304 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !10
  br label %305

305:                                              ; preds = %305, %303
  %306 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !10
  %307 = icmp sgt i8 %306, -1
  br i1 %307, label %305, label %308, !llvm.loop !56

308:                                              ; preds = %305
  call fastcc void @upq_flush(ptr noundef nonnull %1) #14
  %309 = load i8, ptr %12, align 1, !tbaa !13
  %310 = load i8, ptr %13, align 1, !tbaa !18
  %311 = icmp ult i8 %309, %310
  br i1 %311, label %314, label %312

312:                                              ; preds = %308
  %313 = icmp ugt i8 %309, %310
  br i1 %313, label %314, label %317

314:                                              ; preds = %312, %308
  %315 = phi i8 [ 1, %308 ], [ -1, %312 ]
  %316 = add i8 %315, %309
  store i8 %316, ptr %12, align 1, !tbaa !13
  br label %317

317:                                              ; preds = %312, %314
  %318 = phi i8 [ %309, %312 ], [ %316, %314 ]
  %319 = and i8 %318, 15
  store volatile i8 %319, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !10
  store i8 1, ptr %14, align 1, !tbaa !19
  br label %289
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: nofree norecurse nosync nounwind optsize memory(argmem: write)
define internal fastcc void @bloom_init(ptr noundef writeonly captures(none) %0) unnamed_addr #2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i16 12
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 24
  %4 = getelementptr inbounds nuw i8, ptr %0, i16 36
  br label %10

5:                                                ; preds = %10
  %6 = getelementptr inbounds nuw i8, ptr %0, i16 48
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(896) %6, i8 0, i16 896, i1 false), !tbaa !10
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 1065
  store i16 0, ptr %7, align 1, !tbaa !61
  %8 = getelementptr i8, ptr %0, i16 944
  %9 = getelementptr i8, ptr %0, i16 955
  br label %31

10:                                               ; preds = %1, %10
  %11 = phi i8 [ 0, %1 ], [ %30, %10 ]
  %12 = phi i16 [ 0, %1 ], [ %28, %10 ]
  %13 = zext nneg i8 %11 to i16
  %14 = getelementptr i8, ptr @bloom_init.px, i16 %13
  %15 = load i16, ptr %14, align 1, !tbaa !2
  %16 = shl i16 %15, 4
  %17 = getelementptr i8, ptr %0, i16 %13
  store i16 %16, ptr %17, align 1, !tbaa !2
  %18 = getelementptr i8, ptr @bloom_init.py, i16 %13
  %19 = load i16, ptr %18, align 1, !tbaa !2
  %20 = shl i16 %19, 4
  %21 = getelementptr i8, ptr %2, i16 %13
  store i16 %20, ptr %21, align 1, !tbaa !2
  %22 = getelementptr i8, ptr @bloom_init.vX, i16 %13
  %23 = load i16, ptr %22, align 1, !tbaa !2
  %24 = getelementptr i8, ptr %3, i16 %13
  store i16 %23, ptr %24, align 1, !tbaa !2
  %25 = getelementptr i8, ptr @bloom_init.vY, i16 %13
  %26 = load i16, ptr %25, align 1, !tbaa !2
  %27 = getelementptr i8, ptr %4, i16 %13
  store i16 %26, ptr %27, align 1, !tbaa !2
  %28 = add nuw nsw i16 %12, 1
  %29 = icmp eq i16 %28, 6
  %30 = add nuw nsw i8 %11, 2
  br i1 %29, label %5, label %10, !llvm.loop !82

31:                                               ; preds = %36, %5
  %32 = phi i8 [ %41, %36 ], [ 0, %5 ]
  %33 = phi ptr [ %39, %36 ], [ %8, %5 ]
  %34 = phi i16 [ %37, %36 ], [ -5, %5 ]
  %35 = mul nsw i16 %34, %34
  br label %42

36:                                               ; preds = %52
  %37 = add nsw i16 %34, 1
  %38 = zext nneg i8 %32 to i16
  %39 = getelementptr i8, ptr %9, i16 %38
  %40 = icmp eq i16 %37, 6
  %41 = add nuw nsw i8 %32, 11
  br i1 %40, label %59, label %31, !llvm.loop !83

42:                                               ; preds = %52, %31
  %43 = phi i8 [ 0, %31 ], [ %58, %52 ]
  %44 = phi i16 [ -5, %31 ], [ %56, %52 ]
  %45 = mul nsw i16 %44, %44
  %46 = add nuw nsw i16 %45, %35
  %47 = icmp samesign ult i16 %46, 26
  br i1 %47, label %48, label %52

48:                                               ; preds = %42
  %49 = trunc nuw nsw i16 %46 to i8
  %50 = shl nuw i8 %49, 3
  %51 = sub nuw i8 -56, %50
  br label %52

52:                                               ; preds = %48, %42
  %53 = phi i8 [ %51, %48 ], [ 0, %42 ]
  %54 = zext nneg i8 %43 to i16
  %55 = getelementptr i8, ptr %33, i16 %54
  store i8 %53, ptr %55, align 1, !tbaa !10
  %56 = add nsw i16 %44, 1
  %57 = icmp eq i16 %56, 6
  %58 = add nuw nsw i8 %43, 1
  br i1 %57, label %36, label %42, !llvm.loop !84

59:                                               ; preds = %36
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(argmem: readwrite)
define internal fastcc void @bloom_step(ptr noundef captures(none) %0) unnamed_addr #3 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i16 24
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 12
  %4 = getelementptr inbounds nuw i8, ptr %0, i16 36
  br label %10

5:                                                ; preds = %38
  %6 = getelementptr inbounds nuw i8, ptr %0, i16 48
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(896) %6, i8 0, i16 896, i1 false), !tbaa !10
  %7 = getelementptr i8, ptr %0, i16 -117
  %8 = getelementptr i8, ptr %0, i16 944
  %9 = getelementptr i8, ptr %0, i16 955
  br label %44

10:                                               ; preds = %1, %38
  %11 = phi i8 [ 0, %1 ], [ %42, %38 ]
  %12 = phi i16 [ 0, %1 ], [ %40, %38 ]
  %13 = zext nneg i8 %11 to i16
  %14 = getelementptr i8, ptr %0, i16 %13
  %15 = load i16, ptr %14, align 1, !tbaa !2
  %16 = getelementptr i8, ptr %2, i16 %13
  %17 = load i16, ptr %16, align 1, !tbaa !2
  %18 = add nsw i16 %17, %15
  %19 = getelementptr i8, ptr %3, i16 %13
  %20 = load i16, ptr %19, align 1, !tbaa !2
  %21 = getelementptr i8, ptr %4, i16 %13
  %22 = load i16, ptr %21, align 1, !tbaa !2
  %23 = add nsw i16 %22, %20
  %24 = icmp slt i16 %18, 0
  br i1 %24, label %27, label %25

25:                                               ; preds = %10
  %26 = icmp samesign ugt i16 %18, 496
  br i1 %26, label %27, label %30

27:                                               ; preds = %25, %10
  %28 = phi i16 [ 0, %10 ], [ 496, %25 ]
  %29 = sub nsw i16 0, %17
  store i16 %29, ptr %16, align 1, !tbaa !2
  br label %30

30:                                               ; preds = %27, %25
  %31 = phi i16 [ %18, %25 ], [ %28, %27 ]
  %32 = icmp slt i16 %23, 0
  br i1 %32, label %35, label %33

33:                                               ; preds = %30
  %34 = icmp samesign ugt i16 %23, 432
  br i1 %34, label %35, label %38

35:                                               ; preds = %33, %30
  %36 = phi i16 [ 0, %30 ], [ 432, %33 ]
  %37 = sub nsw i16 0, %22
  store i16 %37, ptr %21, align 1, !tbaa !2
  br label %38

38:                                               ; preds = %35, %33
  %39 = phi i16 [ %23, %33 ], [ %36, %35 ]
  store i16 %31, ptr %14, align 1, !tbaa !2
  store i16 %39, ptr %19, align 1, !tbaa !2
  %40 = add nuw nsw i16 %12, 1
  %41 = icmp eq i16 %40, 6
  %42 = add nuw nsw i8 %11, 2
  br i1 %41, label %5, label %10, !llvm.loop !85

43:                                               ; preds = %57
  ret void

44:                                               ; preds = %5, %57
  %45 = phi i8 [ 0, %5 ], [ %60, %57 ]
  %46 = phi i16 [ 0, %5 ], [ %58, %57 ]
  %47 = zext nneg i8 %45 to i16
  %48 = getelementptr i8, ptr %0, i16 %47
  %49 = load i16, ptr %48, align 1, !tbaa !2
  %50 = ashr i16 %49, 4
  %51 = getelementptr i8, ptr %3, i16 %47
  %52 = load i16, ptr %51, align 1, !tbaa !2
  %53 = ashr i16 %52, 4
  %54 = shl i16 %53, 5
  %55 = getelementptr i8, ptr %7, i16 %50
  %56 = getelementptr i8, ptr %55, i16 %54
  br label %61

57:                                               ; preds = %93
  %58 = add nuw nsw i16 %46, 1
  %59 = icmp eq i16 %58, 6
  %60 = add nuw nsw i8 %45, 2
  br i1 %59, label %43, label %44, !llvm.loop !86

61:                                               ; preds = %44, %93
  %62 = phi i8 [ 0, %44 ], [ %99, %93 ]
  %63 = phi ptr [ %8, %44 ], [ %97, %93 ]
  %64 = phi ptr [ %56, %44 ], [ %95, %93 ]
  %65 = phi i16 [ -5, %44 ], [ %94, %93 ]
  %66 = add nsw i16 %65, %53
  %67 = icmp slt i16 %66, 0
  br i1 %67, label %93, label %68

68:                                               ; preds = %61
  %69 = icmp samesign ugt i16 %66, 27
  br i1 %69, label %93, label %70

70:                                               ; preds = %68, %89
  %71 = phi i8 [ %92, %89 ], [ 0, %68 ]
  %72 = phi i16 [ %90, %89 ], [ -5, %68 ]
  %73 = add nsw i16 %72, %50
  %74 = icmp slt i16 %73, 0
  br i1 %74, label %89, label %75

75:                                               ; preds = %70
  %76 = icmp samesign ugt i16 %73, 31
  br i1 %76, label %89, label %77

77:                                               ; preds = %75
  %78 = zext nneg i8 %71 to i16
  %79 = getelementptr i8, ptr %64, i16 %78
  %80 = load i8, ptr %79, align 1, !tbaa !10
  %81 = getelementptr i8, ptr %63, i16 %78
  %82 = load i8, ptr %81, align 1, !tbaa !10
  %83 = tail call { i8, i1 } @llvm.uadd.with.overflow.i8(i8 %80, i8 %82)
  %84 = extractvalue { i8, i1 } %83, 1
  br i1 %84, label %87, label %85

85:                                               ; preds = %77
  %86 = extractvalue { i8, i1 } %83, 0
  br label %87

87:                                               ; preds = %77, %85
  %88 = phi i8 [ %86, %85 ], [ -1, %77 ]
  store i8 %88, ptr %79, align 1, !tbaa !10
  br label %89

89:                                               ; preds = %70, %75, %87
  %90 = add nsw i16 %72, 1
  %91 = icmp eq i16 %90, 6
  %92 = add nuw nsw i8 %71, 1
  br i1 %91, label %93, label %70, !llvm.loop !87

93:                                               ; preds = %89, %61, %68
  %94 = add nsw i16 %65, 1
  %95 = getelementptr i8, ptr %64, i16 32
  %96 = zext nneg i8 %62 to i16
  %97 = getelementptr i8, ptr %9, i16 %96
  %98 = icmp eq i16 %94, 6
  %99 = add nuw nsw i8 %62, 11
  br i1 %98, label %57, label %61, !llvm.loop !88
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_bloom_reserve(ptr noundef writeonly captures(none) %0, ptr readnone captures(none) %1) #4 {
  store volatile i8 64, ptr inttoptr (i16 8455 to ptr), align 1, !tbaa !10
  store volatile i8 0, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !10
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !10
  store volatile i16 0, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %4

3:                                                ; preds = %25
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !10
  store volatile i16 16384, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %34

4:                                                ; preds = %2, %25
  %5 = phi i8 [ 0, %2 ], [ %26, %25 ]
  %6 = zext nneg i8 %5 to i16
  %7 = and i16 %6, 2
  %8 = icmp eq i16 %7, 0
  %9 = select i1 %8, i16 0, i16 -256
  %10 = and i16 %6, 1
  %11 = icmp eq i16 %10, 0
  %12 = select i1 %11, i16 0, i16 255
  %13 = or disjoint i16 %9, %12
  br label %14

14:                                               ; preds = %4, %14
  %15 = phi i8 [ 0, %4 ], [ %16, %14 ]
  store volatile i16 %13, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %16 = add nuw nsw i8 %15, 1
  %17 = icmp eq i8 %16, 8
  br i1 %17, label %18, label %14, !llvm.loop !89

18:                                               ; preds = %14
  %19 = icmp samesign ult i8 %5, 8
  %20 = select i1 %19, i16 0, i16 -256
  %21 = and i16 %6, 4
  %22 = icmp eq i16 %21, 0
  %23 = select i1 %22, i16 0, i16 255
  %24 = or disjoint i16 %23, %20
  br label %28

25:                                               ; preds = %28
  %26 = add nuw nsw i8 %5, 1
  %27 = icmp eq i8 %26, 16
  br i1 %27, label %3, label %4, !llvm.loop !90

28:                                               ; preds = %18, %28
  %29 = phi i8 [ %30, %28 ], [ 0, %18 ]
  store volatile i16 %24, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %30 = add nuw nsw i8 %29, 1
  %31 = icmp eq i8 %30, 8
  br i1 %31, label %25, label %28, !llvm.loop !91

32:                                               ; preds = %34
  %33 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 1, ptr %33, align 1, !tbaa !92
  ret void

34:                                               ; preds = %3, %34
  %35 = phi i16 [ 0, %3 ], [ %36, %34 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %36 = add nuw nsw i16 %35, 1
  %37 = icmp eq i16 %36, 1024
  br i1 %37, label %32, label %34, !llvm.loop !93
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(read, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal void @_bloom_emit(ptr noundef %0, ptr noundef captures(none) %1) #5 {
  %3 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %4 = load i8, ptr %3, align 1, !tbaa !71
  %5 = icmp ugt i8 %4, 15
  br i1 %5, label %17, label %6

6:                                                ; preds = %2
  %7 = zext nneg i8 %4 to i16
  %8 = add nuw nsw i8 %4, 1
  store i8 %8, ptr %3, align 1, !tbaa !71
  %9 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %7
  %10 = getelementptr inbounds nuw i8, ptr %9, i16 10
  store i8 1, ptr %10, align 1, !tbaa !72
  store i16 0, ptr %9, align 1, !tbaa !74
  %11 = getelementptr inbounds nuw i8, ptr %9, i16 9
  store i8 0, ptr %11, align 1, !tbaa !75
  %12 = getelementptr inbounds nuw i8, ptr %9, i16 7
  store i8 34, ptr %12, align 1, !tbaa !76
  %13 = getelementptr inbounds nuw i8, ptr %9, i16 8
  store i8 0, ptr %13, align 1, !tbaa !77
  %14 = getelementptr inbounds nuw i8, ptr %9, i16 2
  store i16 ptrtoint (ptr @bloom_pal to i16), ptr %14, align 1, !tbaa !78
  %15 = getelementptr inbounds nuw i8, ptr %9, i16 6
  store i8 0, ptr %15, align 1, !tbaa !79
  %16 = getelementptr inbounds nuw i8, ptr %9, i16 4
  store i16 32, ptr %16, align 1, !tbaa !80
  br label %17

17:                                               ; preds = %2, %6
  %18 = phi i8 [ %4, %2 ], [ %8, %6 ]
  %19 = getelementptr inbounds nuw i8, ptr %0, i16 3
  br label %35

20:                                               ; preds = %35
  %21 = icmp ugt i8 %18, 15
  br i1 %21, label %34, label %22

22:                                               ; preds = %20
  %23 = zext nneg i8 %18 to i16
  %24 = add nuw nsw i8 %18, 1
  store i8 %24, ptr %3, align 1, !tbaa !71
  %25 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %23
  %26 = getelementptr inbounds nuw i8, ptr %25, i16 10
  store i8 0, ptr %26, align 1, !tbaa !72
  store i16 16384, ptr %25, align 1, !tbaa !74
  %27 = getelementptr inbounds nuw i8, ptr %25, i16 9
  store i8 -128, ptr %27, align 1, !tbaa !75
  %28 = getelementptr inbounds nuw i8, ptr %25, i16 7
  store i8 24, ptr %28, align 1, !tbaa !76
  %29 = getelementptr inbounds nuw i8, ptr %25, i16 8
  store i8 1, ptr %29, align 1, !tbaa !77
  %30 = ptrtoint ptr %19 to i16
  %31 = getelementptr inbounds nuw i8, ptr %25, i16 2
  store i16 %30, ptr %31, align 1, !tbaa !78
  %32 = getelementptr inbounds nuw i8, ptr %25, i16 6
  store i8 0, ptr %32, align 1, !tbaa !79
  %33 = getelementptr inbounds nuw i8, ptr %25, i16 4
  store i16 1792, ptr %33, align 1, !tbaa !80
  br label %34

34:                                               ; preds = %20, %22
  ret void

35:                                               ; preds = %17, %35
  %36 = phi i16 [ 0, %17 ], [ %42, %35 ]
  %37 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @bs, i16 48), i16 %36
  %38 = load i8, ptr %37, align 1, !tbaa !10
  %39 = lshr i8 %38, 4
  %40 = zext nneg i8 %39 to i16
  %41 = getelementptr inbounds nuw [2 x i8], ptr %19, i16 %36
  store i16 %40, ptr %41, align 1, !tbaa !2
  %42 = add nuw nsw i16 %36, 1
  %43 = icmp eq i16 %42, 896
  br i1 %43, label %20, label %35, !llvm.loop !94
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_title_reserve(ptr noundef %0, ptr readnone captures(none) %1) #4 {
  store volatile i8 80, ptr inttoptr (i16 8456 to ptr), align 8, !tbaa !10
  store volatile i8 16, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !10
  store volatile i8 112, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !10
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !10
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !10
  store volatile i8 -1, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !10
  store volatile i8 127, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !10
  store volatile i8 -124, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !10
  store volatile i8 16, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !10
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !10
  store volatile i16 4096, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %3

3:                                                ; preds = %2, %16
  %4 = phi ptr [ @FONT8, %2 ], [ %18, %16 ]
  %5 = phi i16 [ 0, %2 ], [ %17, %16 ]
  br label %7

6:                                                ; preds = %16
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !10
  store volatile i16 5120, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %24

7:                                                ; preds = %3, %7
  %8 = phi i8 [ 0, %3 ], [ %15, %7 ]
  %9 = phi i8 [ 0, %3 ], [ %13, %7 ]
  %10 = zext nneg i8 %8 to i16
  %11 = getelementptr i8, ptr %4, i16 %10
  %12 = load i16, ptr %11, align 1, !tbaa !2
  store volatile i16 %12, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %13 = add nuw nsw i8 %9, 1
  %14 = icmp eq i8 %13, 8
  %15 = add nuw nsw i8 %8, 2
  br i1 %14, label %20, label %7, !llvm.loop !95

16:                                               ; preds = %20
  %17 = add nuw nsw i16 %5, 1
  %18 = getelementptr i8, ptr %4, i16 16
  %19 = icmp eq i16 %17, 64
  br i1 %19, label %6, label %3, !llvm.loop !96

20:                                               ; preds = %7, %20
  %21 = phi i8 [ %22, %20 ], [ 0, %7 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %22 = add nuw nsw i8 %21, 1
  %23 = icmp eq i8 %22, 8
  br i1 %23, label %16, label %20, !llvm.loop !97

24:                                               ; preds = %6, %33
  %25 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 16), %6 ], [ %36, %33 ]
  %26 = phi ptr [ @FONT16, %6 ], [ %35, %33 ]
  %27 = phi i16 [ 0, %6 ], [ %34, %33 ]
  br label %29

28:                                               ; preds = %33
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !10
  store volatile i16 20480, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %66

29:                                               ; preds = %24, %47
  %30 = phi i8 [ 0, %24 ], [ %52, %47 ]
  %31 = phi ptr [ %26, %24 ], [ %50, %47 ]
  %32 = phi i8 [ 0, %24 ], [ %48, %47 ]
  br label %38

33:                                               ; preds = %47
  %34 = add nuw nsw i16 %27, 1
  %35 = getelementptr i8, ptr %26, i16 64
  %36 = getelementptr i8, ptr %25, i16 64
  %37 = icmp eq i16 %34, 64
  br i1 %37, label %28, label %24, !llvm.loop !98

38:                                               ; preds = %29, %38
  %39 = phi i8 [ 0, %29 ], [ %46, %38 ]
  %40 = phi i8 [ 0, %29 ], [ %44, %38 ]
  %41 = zext nneg i8 %39 to i16
  %42 = getelementptr i8, ptr %31, i16 %41
  %43 = load i16, ptr %42, align 1, !tbaa !2
  store volatile i16 %43, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %44 = add nuw nsw i8 %40, 1
  %45 = icmp eq i8 %44, 8
  %46 = add nuw nsw i8 %39, 2
  br i1 %45, label %53, label %38, !llvm.loop !99

47:                                               ; preds = %53
  %48 = add nuw nsw i8 %32, 1
  %49 = zext nneg i8 %30 to i16
  %50 = getelementptr i8, ptr %25, i16 %49
  %51 = icmp eq i8 %48, 4
  %52 = add nuw nsw i8 %30, 16
  br i1 %51, label %33, label %29, !llvm.loop !100

53:                                               ; preds = %38, %53
  %54 = phi i8 [ %55, %53 ], [ 0, %38 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %55 = add nuw nsw i8 %54, 1
  %56 = icmp eq i8 %55, 8
  br i1 %56, label %47, label %53, !llvm.loop !101

57:                                               ; preds = %66
  %58 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %59 = load ptr, ptr %58, align 1, !tbaa !35
  %60 = icmp eq ptr %59, null
  br i1 %60, label %79, label %61

61:                                               ; preds = %57
  %62 = load i8, ptr %59, align 1, !tbaa !10
  %63 = icmp eq i8 %62, 0
  br i1 %63, label %79, label %64

64:                                               ; preds = %61
  %65 = getelementptr i8, ptr %59, i16 1
  br label %70

66:                                               ; preds = %28, %66
  %67 = phi i16 [ 0, %28 ], [ %68, %66 ]
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %68 = add nuw nsw i16 %67, 1
  %69 = icmp eq i16 %68, 1024
  br i1 %69, label %57, label %66, !llvm.loop !102

70:                                               ; preds = %64, %70
  %71 = phi i8 [ %72, %70 ], [ 0, %64 ]
  %72 = add nuw nsw i8 %71, 1
  %73 = zext nneg i8 %71 to i16
  %74 = getelementptr i8, ptr %65, i16 %73
  %75 = load i8, ptr %74, align 1, !tbaa !10
  %76 = icmp ne i8 %75, 0
  %77 = icmp samesign ult i8 %71, 31
  %78 = select i1 %76, i1 %77, i1 false
  br i1 %78, label %70, label %79, !llvm.loop !103

79:                                               ; preds = %70, %61, %57
  %80 = phi i8 [ 0, %57 ], [ 0, %61 ], [ %72, %70 ]
  %81 = zext nneg i8 %80 to i16
  %82 = sub nuw nsw i16 32, %81
  %83 = lshr i16 %82, 1
  %84 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %85 = load i16, ptr %84, align 1, !tbaa !41
  %86 = shl i16 %85, 2
  %87 = and i16 %86, -32
  %88 = add i16 %87, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !10
  store volatile i16 %88, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %89 = trunc nuw nsw i16 %83 to i8
  %90 = add nuw nsw i8 %80, %89
  %91 = sub nsw i16 0, %83
  %92 = getelementptr i8, ptr %59, i16 %91
  br label %105

93:                                               ; preds = %128
  %94 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %95 = load ptr, ptr %94, align 1, !tbaa !37
  %96 = getelementptr inbounds nuw i8, ptr %0, i16 11
  %97 = load i8, ptr %96, align 1, !tbaa !38
  %98 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %99 = load i16, ptr %98, align 1, !tbaa !42
  %100 = lshr i16 %99, 3
  %101 = trunc i16 %100 to i8
  tail call fastcc void @_title_write16(ptr noundef %95, i8 noundef zeroext %97, i8 noundef zeroext %101) #14
  %102 = getelementptr inbounds nuw i8, ptr %0, i16 9
  %103 = load ptr, ptr %102, align 1, !tbaa !39
  %104 = icmp eq ptr %103, null
  br i1 %104, label %139, label %132

105:                                              ; preds = %79, %128
  %106 = phi i8 [ 0, %79 ], [ %130, %128 ]
  %107 = zext nneg i8 %106 to i16
  br i1 %60, label %128, label %108

108:                                              ; preds = %105
  %109 = icmp samesign ugt i16 %83, %107
  br i1 %109, label %128, label %110

110:                                              ; preds = %108
  %111 = icmp ult i8 %106, %90
  br i1 %111, label %112, label %128

112:                                              ; preds = %110
  %113 = getelementptr i8, ptr %92, i16 %107
  %114 = load i8, ptr %113, align 1, !tbaa !10
  %115 = icmp ugt i8 %114, 96
  br i1 %115, label %116, label %120

116:                                              ; preds = %112
  %117 = icmp ult i8 %114, 123
  br i1 %117, label %118, label %128

118:                                              ; preds = %116
  %119 = add nsw i8 %114, -32
  br label %124

120:                                              ; preds = %112
  %121 = icmp samesign ugt i8 %114, 31
  br i1 %121, label %122, label %128

122:                                              ; preds = %120
  %123 = icmp eq i8 %114, 96
  br i1 %123, label %128, label %124

124:                                              ; preds = %122, %118
  %125 = phi i8 [ %119, %118 ], [ %114, %122 ]
  %126 = zext nneg i8 %125 to i16
  %127 = add nuw nsw i16 %126, 7136
  br label %128

128:                                              ; preds = %124, %122, %120, %116, %105, %108, %110
  %129 = phi i16 [ 7168, %105 ], [ 7168, %110 ], [ 7168, %108 ], [ %127, %124 ], [ 7168, %122 ], [ 7168, %120 ], [ 7168, %116 ]
  store volatile i16 %129, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %130 = add nuw nsw i8 %106, 1
  %131 = icmp eq i8 %130, 32
  br i1 %131, label %93, label %105, !llvm.loop !104

132:                                              ; preds = %93
  %133 = getelementptr inbounds nuw i8, ptr %0, i16 12
  %134 = load i8, ptr %133, align 1, !tbaa !40
  %135 = load i16, ptr %98, align 1, !tbaa !42
  %136 = lshr i16 %135, 3
  %137 = trunc i16 %136 to i8
  %138 = add i8 %137, 2
  tail call fastcc void @_title_write16(ptr noundef nonnull %103, i8 noundef zeroext %134, i8 noundef zeroext %138) #14
  br label %139

139:                                              ; preds = %132, %93
  %140 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 -128, ptr %140, align 1, !tbaa !69
  %141 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 3584, ptr %141, align 1, !tbaa !105
  %142 = getelementptr inbounds nuw i8, ptr %0, i16 23
  store i16 0, ptr %142, align 1, !tbaa !106
  %143 = load ptr, ptr %58, align 1, !tbaa !35
  %144 = icmp eq ptr %143, null
  br i1 %144, label %167, label %145

145:                                              ; preds = %139
  %146 = load i8, ptr %143, align 1, !tbaa !10
  %147 = icmp eq i8 %146, 0
  br i1 %147, label %150, label %148

148:                                              ; preds = %145
  %149 = getelementptr i8, ptr %143, i16 1
  br label %158

150:                                              ; preds = %158, %145
  %151 = phi i8 [ 0, %145 ], [ %160, %158 ]
  %152 = zext nneg i8 %151 to i16
  %153 = shl nuw nsw i16 %152, 2
  %154 = sub nuw nsw i16 128, %153
  %155 = and i16 %154, 248
  %156 = add nsw i16 %153, -128
  %157 = add nsw i16 %156, %155
  br label %167

158:                                              ; preds = %158, %148
  %159 = phi i8 [ %160, %158 ], [ 0, %148 ]
  %160 = add nuw nsw i8 %159, 1
  %161 = zext nneg i8 %159 to i16
  %162 = getelementptr i8, ptr %149, i16 %161
  %163 = load i8, ptr %162, align 1, !tbaa !10
  %164 = icmp ne i8 %163, 0
  %165 = icmp samesign ult i8 %159, 31
  %166 = select i1 %164, i1 %165, i1 false
  br i1 %166, label %158, label %150, !llvm.loop !107

167:                                              ; preds = %139, %150
  %168 = phi i16 [ %157, %150 ], [ 0, %139 ]
  %169 = getelementptr inbounds nuw i8, ptr %0, i16 26
  store i16 %168, ptr %169, align 1, !tbaa !108
  store volatile i8 -112, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !10
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !10
  %170 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %171 = getelementptr inbounds nuw i8, ptr %0, i16 89
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef -8, i16 noundef 224, ptr noundef nonnull %170, ptr noundef nonnull %171) #14
  %172 = getelementptr inbounds nuw i8, ptr %0, i16 88
  store i8 0, ptr %172, align 1, !tbaa !109
  store volatile i8 2, ptr inttoptr (i16 17200 to ptr), align 16, !tbaa !10
  store volatile i8 16, ptr inttoptr (i16 17201 to ptr), align 1, !tbaa !10
  %173 = ptrtoint ptr %170 to i16
  %174 = trunc i16 %173 to i8
  store volatile i8 %174, ptr inttoptr (i16 17202 to ptr), align 2, !tbaa !10
  %175 = lshr i16 %173, 8
  %176 = trunc nuw i16 %175 to i8
  store volatile i8 %176, ptr inttoptr (i16 17203 to ptr), align 1, !tbaa !10
  store volatile i8 0, ptr inttoptr (i16 17204 to ptr), align 4, !tbaa !10
  %177 = getelementptr inbounds nuw i8, ptr %0, i16 139
  store i8 0, ptr %177, align 1, !tbaa !109
  store volatile i8 2, ptr inttoptr (i16 17216 to ptr), align 64, !tbaa !10
  store volatile i8 15, ptr inttoptr (i16 17217 to ptr), align 1, !tbaa !10
  %178 = ptrtoint ptr %171 to i16
  %179 = trunc i16 %178 to i8
  store volatile i8 %179, ptr inttoptr (i16 17218 to ptr), align 2, !tbaa !10
  %180 = lshr i16 %178, 8
  %181 = trunc nuw i16 %180 to i8
  store volatile i8 %181, ptr inttoptr (i16 17219 to ptr), align 1, !tbaa !10
  store volatile i8 0, ptr inttoptr (i16 17220 to ptr), align 4, !tbaa !10
  %182 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 2, ptr %182, align 1, !tbaa !34
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal void @_title_emit(ptr noundef %0, ptr noundef captures(none) %1) #6 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 29
  %4 = load i8, ptr %3, align 1, !tbaa !45
  %5 = icmp eq i8 %4, 0
  br i1 %5, label %188, label %6

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 30
  %8 = load i8, ptr %7, align 1, !tbaa !48
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %39, label %10

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 25
  %12 = load i8, ptr %11, align 1, !tbaa !49
  %13 = icmp ugt i8 %12, -6
  br i1 %13, label %16, label %14

14:                                               ; preds = %10
  %15 = add nuw i8 %12, 4
  br label %16

16:                                               ; preds = %10, %14
  %17 = phi i8 [ %15, %14 ], [ -1, %10 ]
  store i8 %17, ptr %11, align 1, !tbaa !49
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %19 = load i16, ptr %18, align 1, !tbaa !41
  %20 = xor i8 %17, -1
  %21 = zext i8 %20 to i16
  %22 = mul nuw i16 %21, %21
  %23 = lshr i16 %22, 8
  %24 = sub nuw nsw i16 256, %23
  %25 = add nsw i16 %19, 8
  %26 = mul nsw i16 %24, %25
  %27 = ashr i16 %26, 4
  %28 = and i16 %27, -16
  %29 = add nsw i16 %28, -128
  %30 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 %29, ptr %30, align 1, !tbaa !69
  %31 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %32 = load i16, ptr %31, align 1, !tbaa !42
  %33 = add nsw i16 %32, -224
  %34 = mul nsw i16 %33, %24
  %35 = ashr i16 %34, 4
  %36 = and i16 %35, -16
  %37 = add nsw i16 %36, 3584
  %38 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 %37, ptr %38, align 1, !tbaa !105
  br label %64

39:                                               ; preds = %6
  %40 = getelementptr inbounds nuw i8, ptr %0, i16 31
  %41 = load i8, ptr %40, align 1, !tbaa !46
  %42 = icmp eq i8 %41, 0
  br i1 %42, label %43, label %48

43:                                               ; preds = %39
  %44 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %45 = load i16, ptr %44, align 1, !tbaa !69
  %46 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %47 = load i16, ptr %46, align 1, !tbaa !105
  br label %64

48:                                               ; preds = %39
  %49 = getelementptr inbounds nuw i8, ptr %0, i16 23
  %50 = load i16, ptr %49, align 1, !tbaa !106
  %51 = add nsw i16 %50, 2
  store i16 %51, ptr %49, align 1, !tbaa !106
  %52 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %53 = load i16, ptr %52, align 1, !tbaa !69
  %54 = add nsw i16 %53, %51
  store i16 %54, ptr %52, align 1, !tbaa !69
  %55 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %56 = load i16, ptr %55, align 1, !tbaa !105
  %57 = add nsw i16 %56, %51
  store i16 %57, ptr %55, align 1, !tbaa !105
  %58 = icmp sgt i16 %54, 4480
  br i1 %58, label %59, label %60

59:                                               ; preds = %48
  store i16 4480, ptr %52, align 1, !tbaa !69
  br label %60

60:                                               ; preds = %59, %48
  %61 = phi i16 [ 4480, %59 ], [ %54, %48 ]
  %62 = icmp sgt i16 %57, 4736
  br i1 %62, label %63, label %64

63:                                               ; preds = %60
  store i16 4736, ptr %55, align 1, !tbaa !105
  br label %64

64:                                               ; preds = %43, %63, %60, %16
  %65 = phi i16 [ %47, %43 ], [ 4736, %63 ], [ %57, %60 ], [ %37, %16 ]
  %66 = phi i16 [ %45, %43 ], [ %61, %63 ], [ %61, %60 ], [ %29, %16 ]
  %67 = ashr i16 %66, 4
  %68 = ashr i16 %65, 4
  %69 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %70 = getelementptr inbounds nuw i8, ptr %0, i16 88
  %71 = load i8, ptr %70, align 1, !tbaa !109
  %72 = xor i8 %71, 1
  %73 = zext i8 %72 to i16
  %74 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %73
  %75 = getelementptr inbounds nuw i8, ptr %0, i16 89
  %76 = getelementptr inbounds nuw i8, ptr %0, i16 139
  %77 = load i8, ptr %76, align 1, !tbaa !109
  %78 = xor i8 %77, 1
  %79 = zext i8 %78 to i16
  %80 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %79
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef %67, i16 noundef %68, ptr noundef nonnull %74, ptr noundef nonnull %80) #14
  %81 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %82 = load i8, ptr %81, align 1, !tbaa !71
  %83 = icmp ugt i8 %82, 15
  br i1 %83, label %109, label %84

84:                                               ; preds = %64
  %85 = load i8, ptr %70, align 1, !tbaa !109
  %86 = xor i8 %85, 1
  %87 = zext i8 %86 to i16
  %88 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %87
  %89 = ptrtoint ptr %88 to i16
  %90 = zext nneg i8 %82 to i16
  %91 = add nuw nsw i8 %82, 1
  store i8 %91, ptr %81, align 1, !tbaa !71
  %92 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %90
  %93 = getelementptr inbounds nuw i8, ptr %92, i16 10
  store i8 4, ptr %93, align 1, !tbaa !72
  store i16 17202, ptr %92, align 1, !tbaa !74
  %94 = getelementptr inbounds nuw i8, ptr %92, i16 2
  store i16 %89, ptr %94, align 1, !tbaa !78
  %95 = getelementptr inbounds nuw i8, ptr %92, i16 4
  store i16 0, ptr %95, align 1, !tbaa !80
  store i8 %86, ptr %70, align 1, !tbaa !109
  %96 = icmp eq i8 %82, 15
  br i1 %96, label %109, label %97

97:                                               ; preds = %84
  %98 = load i8, ptr %76, align 1, !tbaa !109
  %99 = xor i8 %98, 1
  %100 = zext i8 %99 to i16
  %101 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %100
  %102 = ptrtoint ptr %101 to i16
  %103 = zext nneg i8 %91 to i16
  %104 = add nuw nsw i8 %82, 2
  store i8 %104, ptr %81, align 1, !tbaa !71
  %105 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %103
  %106 = getelementptr inbounds nuw i8, ptr %105, i16 10
  store i8 4, ptr %106, align 1, !tbaa !72
  store i16 17218, ptr %105, align 1, !tbaa !74
  %107 = getelementptr inbounds nuw i8, ptr %105, i16 2
  store i16 %102, ptr %107, align 1, !tbaa !78
  %108 = getelementptr inbounds nuw i8, ptr %105, i16 4
  store i16 0, ptr %108, align 1, !tbaa !80
  store i8 %99, ptr %76, align 1, !tbaa !109
  br label %109

109:                                              ; preds = %64, %84, %97
  %110 = phi i8 [ %82, %64 ], [ 16, %84 ], [ %104, %97 ]
  %111 = getelementptr inbounds nuw i8, ptr %0, i16 28
  %112 = load i8, ptr %111, align 1, !tbaa !44
  %113 = add i8 %112, 1
  store i8 %113, ptr %111, align 1, !tbaa !44
  %114 = getelementptr inbounds nuw i8, ptr %0, i16 32
  %115 = load i8, ptr %114, align 1, !tbaa !47
  %116 = icmp eq i8 %115, 0
  br i1 %116, label %117, label %155

117:                                              ; preds = %109
  %118 = shl i8 %113, 1
  %119 = icmp sgt i8 %118, -1
  br i1 %119, label %122, label %120

120:                                              ; preds = %117
  %121 = xor i8 %118, -1
  br label %122

122:                                              ; preds = %117, %120
  %123 = phi i8 [ %121, %120 ], [ %118, %117 ]
  %124 = lshr i8 %123, 4
  %125 = add nuw nsw i8 %124, 24
  %126 = zext nneg i8 %125 to i16
  %127 = mul nuw nsw i16 %126, 1057
  %128 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 %127, ptr %128, align 1, !tbaa !50
  %129 = add i8 %118, -86
  %130 = icmp sgt i8 %129, -1
  br i1 %130, label %133, label %131

131:                                              ; preds = %122
  %132 = sub nsw i8 85, %118
  br label %133

133:                                              ; preds = %122, %131
  %134 = phi i8 [ %132, %131 ], [ %129, %122 ]
  %135 = lshr i8 %134, 2
  %136 = zext nneg i8 %135 to i16
  %137 = shl nuw nsw i16 %136, 10
  %138 = add i8 %118, 85
  %139 = icmp sgt i8 %138, -1
  br i1 %139, label %142, label %140

140:                                              ; preds = %133
  %141 = sub nuw i8 -86, %118
  br label %142

142:                                              ; preds = %133, %140
  %143 = phi i8 [ %141, %140 ], [ %138, %133 ]
  %144 = lshr i8 %143, 2
  %145 = zext nneg i8 %144 to i16
  %146 = shl nuw nsw i16 %145, 5
  %147 = add nuw nsw i16 %146, %137
  br i1 %119, label %150, label %148

148:                                              ; preds = %142
  %149 = xor i8 %118, -1
  br label %150

150:                                              ; preds = %142, %148
  %151 = phi i8 [ %149, %148 ], [ %118, %142 ]
  %152 = lshr i8 %151, 2
  %153 = zext nneg i8 %152 to i16
  %154 = add nuw nsw i16 %147, %153
  br label %157

155:                                              ; preds = %109
  %156 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 29596, ptr %156, align 1, !tbaa !50
  br label %157

157:                                              ; preds = %155, %150
  %158 = phi i16 [ 0, %155 ], [ %154, %150 ]
  %159 = getelementptr inbounds nuw i8, ptr %0, i16 36
  store i16 %158, ptr %159, align 1, !tbaa !51
  %160 = icmp ugt i8 %110, 15
  br i1 %160, label %188, label %161

161:                                              ; preds = %157
  %162 = getelementptr inbounds nuw i8, ptr %0, i16 34
  %163 = zext nneg i8 %110 to i16
  %164 = add nuw nsw i8 %110, 1
  store i8 %164, ptr %81, align 1, !tbaa !71
  %165 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %163
  %166 = getelementptr inbounds nuw i8, ptr %165, i16 10
  store i8 1, ptr %166, align 1, !tbaa !72
  store i16 113, ptr %165, align 1, !tbaa !74
  %167 = getelementptr inbounds nuw i8, ptr %165, i16 9
  store i8 0, ptr %167, align 1, !tbaa !75
  %168 = getelementptr inbounds nuw i8, ptr %165, i16 7
  store i8 34, ptr %168, align 1, !tbaa !76
  %169 = getelementptr inbounds nuw i8, ptr %165, i16 8
  store i8 0, ptr %169, align 1, !tbaa !77
  %170 = ptrtoint ptr %162 to i16
  %171 = getelementptr inbounds nuw i8, ptr %165, i16 2
  store i16 %170, ptr %171, align 1, !tbaa !78
  %172 = getelementptr inbounds nuw i8, ptr %165, i16 6
  store i8 0, ptr %172, align 1, !tbaa !79
  %173 = getelementptr inbounds nuw i8, ptr %165, i16 4
  store i16 2, ptr %173, align 1, !tbaa !80
  %174 = icmp eq i8 %110, 15
  br i1 %174, label %188, label %175

175:                                              ; preds = %161
  %176 = getelementptr inbounds nuw i8, ptr %0, i16 36
  %177 = zext nneg i8 %164 to i16
  %178 = add nuw nsw i8 %110, 2
  store i8 %178, ptr %81, align 1, !tbaa !71
  %179 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %177
  %180 = getelementptr inbounds nuw i8, ptr %179, i16 10
  store i8 1, ptr %180, align 1, !tbaa !72
  store i16 0, ptr %179, align 1, !tbaa !74
  %181 = getelementptr inbounds nuw i8, ptr %179, i16 9
  store i8 0, ptr %181, align 1, !tbaa !75
  %182 = getelementptr inbounds nuw i8, ptr %179, i16 7
  store i8 34, ptr %182, align 1, !tbaa !76
  %183 = getelementptr inbounds nuw i8, ptr %179, i16 8
  store i8 0, ptr %183, align 1, !tbaa !77
  %184 = ptrtoint ptr %176 to i16
  %185 = getelementptr inbounds nuw i8, ptr %179, i16 2
  store i16 %184, ptr %185, align 1, !tbaa !78
  %186 = getelementptr inbounds nuw i8, ptr %179, i16 6
  store i8 0, ptr %186, align 1, !tbaa !79
  %187 = getelementptr inbounds nuw i8, ptr %179, i16 4
  store i16 2, ptr %187, align 1, !tbaa !80
  br label %188

188:                                              ; preds = %157, %175, %161, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @_title_write16(ptr noundef readonly captures(address_is_null) %0, i8 noundef zeroext %1, i8 noundef zeroext %2) unnamed_addr #4 {
  %4 = zext i8 %1 to i16
  %5 = shl nuw nsw i16 %4, 1
  %6 = and i16 %5, 254
  %7 = sub nsw i16 32, %6
  %8 = lshr exact i16 %7, 1
  %9 = zext i8 %2 to i16
  %10 = icmp eq ptr %0, null
  %11 = and i16 %8, 255
  %12 = add nuw i16 %8, %5
  %13 = and i16 %12, 255
  br label %15

14:                                               ; preds = %23
  ret void

15:                                               ; preds = %3, %23
  %16 = phi i1 [ true, %3 ], [ false, %23 ]
  %17 = phi i8 [ 0, %3 ], [ 1, %23 ]
  %18 = zext nneg i8 %17 to i16
  %19 = add nuw nsw i16 %18, %9
  %20 = shl nuw nsw i16 %19, 5
  %21 = add nuw nsw i16 %20, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !10
  store volatile i16 %21, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %22 = select i1 %16, i16 7168, i16 7170
  br label %24

23:                                               ; preds = %56
  br i1 %16, label %15, label %14, !llvm.loop !110

24:                                               ; preds = %15, %56
  %25 = phi i8 [ 0, %15 ], [ %58, %56 ]
  %26 = zext nneg i8 %25 to i16
  br i1 %10, label %56, label %27

27:                                               ; preds = %24
  %28 = icmp samesign ugt i16 %11, %26
  br i1 %28, label %56, label %29

29:                                               ; preds = %27
  %30 = icmp samesign ugt i16 %13, %26
  br i1 %30, label %31, label %56

31:                                               ; preds = %29
  %32 = sub nsw i16 %26, %11
  %33 = lshr i16 %32, 1
  %34 = and i16 %33, 255
  %35 = getelementptr inbounds nuw i8, ptr %0, i16 %34
  %36 = load i8, ptr %35, align 1, !tbaa !10
  %37 = icmp ugt i8 %36, 96
  br i1 %37, label %38, label %42

38:                                               ; preds = %31
  %39 = icmp ult i8 %36, 123
  br i1 %39, label %40, label %51

40:                                               ; preds = %38
  %41 = add nsw i8 %36, -32
  br label %46

42:                                               ; preds = %31
  %43 = icmp samesign ugt i8 %36, 31
  br i1 %43, label %44, label %51

44:                                               ; preds = %42
  %45 = icmp eq i8 %36, 96
  br i1 %45, label %51, label %46

46:                                               ; preds = %44, %40
  %47 = phi i8 [ %41, %40 ], [ %36, %44 ]
  %48 = zext nneg i8 %47 to i16
  %49 = shl nuw nsw i16 %48, 2
  %50 = add nsw i16 %49, -64
  br label %51

51:                                               ; preds = %38, %42, %44, %46
  %52 = phi i16 [ %50, %46 ], [ 64, %44 ], [ 64, %42 ], [ 64, %38 ]
  %53 = and i16 %32, 1
  %54 = or disjoint i16 %22, %53
  %55 = or disjoint i16 %54, %52
  br label %56

56:                                               ; preds = %51, %29, %27, %24
  %57 = phi i16 [ %55, %51 ], [ 7168, %29 ], [ 7168, %27 ], [ 7168, %24 ]
  store volatile i16 %57, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %58 = add nuw nsw i8 %25, 1
  %59 = icmp eq i8 %58, 32
  br i1 %59, label %23, label %24, !llvm.loop !111
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_build(ptr noundef readonly captures(none) %0, i16 noundef range(i16 -2048, 2048) %1, i16 noundef range(i16 -2048, 2048) %2, ptr noundef %3, ptr noundef %4) unnamed_addr #6 {
  %6 = alloca %struct.HScrollW, align 1
  %7 = alloca %struct.HScrollW, align 1
  %8 = alloca i16, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #12
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #12
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #12
  store i16 0, ptr %8, align 1, !tbaa !2
  store ptr %3, ptr %6, align 1, !tbaa !112
  %9 = getelementptr inbounds nuw i8, ptr %6, i16 2
  store i8 0, ptr %9, align 1, !tbaa !114
  store ptr %4, ptr %7, align 1, !tbaa !112
  %10 = getelementptr inbounds nuw i8, ptr %7, i16 2
  store i8 0, ptr %10, align 1, !tbaa !114
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %12 = load i16, ptr %11, align 1, !tbaa !41
  %13 = getelementptr inbounds nuw i8, ptr %0, i16 26
  %14 = load i16, ptr %13, align 1, !tbaa !108
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %1, i16 noundef 8, i16 noundef %12, i16 noundef %14) #14
  %15 = getelementptr inbounds nuw i8, ptr %0, i16 17
  %16 = load i16, ptr %15, align 1, !tbaa !43
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %18 = load i16, ptr %17, align 1, !tbaa !42
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %2, i16 noundef %16, i16 noundef %18, i16 noundef 0) #14
  %19 = load i16, ptr %8, align 1, !tbaa !2
  call fastcc void @_title_blank(ptr noundef %6, ptr noundef %7, i16 noundef %19, i16 noundef 224) #14
  %20 = load ptr, ptr %6, align 1, !tbaa !112
  %21 = load i8, ptr %9, align 1, !tbaa !114
  %22 = zext i8 %21 to i16
  %23 = getelementptr inbounds nuw i8, ptr %20, i16 %22
  store i8 0, ptr %23, align 1, !tbaa !10
  %24 = load ptr, ptr %7, align 1, !tbaa !112
  %25 = load i8, ptr %10, align 1, !tbaa !114
  %26 = zext i8 %25 to i16
  %27 = getelementptr inbounds nuw i8, ptr %24, i16 %26
  store i8 0, ptr %27, align 1, !tbaa !10
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #12
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #12
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #12
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_glyph_band(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, ptr noundef nonnull captures(none) %2, i16 noundef range(i16 -2048, 2048) %3, i16 noundef %4, i16 noundef %5, i16 noundef %6) unnamed_addr #6 {
  %8 = add nsw i16 %3, -2
  %9 = add nsw i16 %4, %3
  %10 = add nsw i16 %9, 2
  %11 = load i16, ptr %2, align 1, !tbaa !2
  %12 = icmp slt i16 %8, %11
  br i1 %12, label %13, label %14

13:                                               ; preds = %7
  br label %14

14:                                               ; preds = %13, %7
  %15 = phi i16 [ %11, %13 ], [ %8, %7 ]
  %16 = icmp sgt i16 %9, 222
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  br label %18

18:                                               ; preds = %17, %14
  %19 = phi i16 [ 224, %17 ], [ %10, %14 ]
  %20 = icmp sgt i16 %19, %15
  br i1 %20, label %21, label %92

21:                                               ; preds = %18
  tail call fastcc void @_title_blank(ptr noundef %0, ptr noundef %1, i16 noundef %11, i16 noundef %15) #14
  %22 = sub nsw i16 %19, %15
  %23 = trunc i16 %22 to i8
  %24 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %25 = icmp eq i8 %23, 0
  br i1 %25, label %91, label %26

26:                                               ; preds = %21
  %27 = sub nsw i16 %5, %3
  %28 = and i16 %22, 255
  %29 = trunc i16 %27 to i8
  %30 = lshr i16 %27, 8
  %31 = trunc nuw i16 %30 to i8
  br label %32

32:                                               ; preds = %40, %26
  %33 = phi i16 [ %28, %26 ], [ %57, %40 ]
  %34 = load i8, ptr %24, align 1, !tbaa !114
  %35 = icmp ult i8 %34, 22
  br i1 %35, label %36, label %59

36:                                               ; preds = %32
  %37 = icmp ugt i16 %33, 127
  br i1 %37, label %40, label %38

38:                                               ; preds = %36
  %39 = trunc nuw nsw i16 %33 to i8
  br label %40

40:                                               ; preds = %38, %36
  %41 = phi i8 [ %39, %38 ], [ 127, %36 ]
  %42 = load ptr, ptr %0, align 1, !tbaa !112
  %43 = add nuw nsw i8 %34, 1
  store i8 %43, ptr %24, align 1, !tbaa !114
  %44 = zext nneg i8 %34 to i16
  %45 = getelementptr inbounds nuw i8, ptr %42, i16 %44
  store i8 %41, ptr %45, align 1, !tbaa !10
  %46 = load ptr, ptr %0, align 1, !tbaa !112
  %47 = load i8, ptr %24, align 1, !tbaa !114
  %48 = add i8 %47, 1
  store i8 %48, ptr %24, align 1, !tbaa !114
  %49 = zext i8 %47 to i16
  %50 = getelementptr inbounds nuw i8, ptr %46, i16 %49
  store i8 %29, ptr %50, align 1, !tbaa !10
  %51 = load ptr, ptr %0, align 1, !tbaa !112
  %52 = load i8, ptr %24, align 1, !tbaa !114
  %53 = add i8 %52, 1
  store i8 %53, ptr %24, align 1, !tbaa !114
  %54 = zext i8 %52 to i16
  %55 = getelementptr inbounds nuw i8, ptr %51, i16 %54
  store i8 %31, ptr %55, align 1, !tbaa !10
  %56 = zext nneg i8 %41 to i16
  %57 = sub i16 %33, %56
  %58 = icmp eq i16 %57, 0
  br i1 %58, label %59, label %32, !llvm.loop !115

59:                                               ; preds = %32, %40
  %60 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %61 = trunc i16 %6 to i8
  %62 = lshr i16 %6, 8
  %63 = trunc nuw i16 %62 to i8
  br label %64

64:                                               ; preds = %72, %59
  %65 = phi i16 [ %28, %59 ], [ %89, %72 ]
  %66 = load i8, ptr %60, align 1, !tbaa !114
  %67 = icmp ult i8 %66, 22
  br i1 %67, label %68, label %91

68:                                               ; preds = %64
  %69 = icmp ugt i16 %65, 127
  br i1 %69, label %72, label %70

70:                                               ; preds = %68
  %71 = trunc nuw nsw i16 %65 to i8
  br label %72

72:                                               ; preds = %70, %68
  %73 = phi i8 [ %71, %70 ], [ 127, %68 ]
  %74 = load ptr, ptr %1, align 1, !tbaa !112
  %75 = add nuw nsw i8 %66, 1
  store i8 %75, ptr %60, align 1, !tbaa !114
  %76 = zext nneg i8 %66 to i16
  %77 = getelementptr inbounds nuw i8, ptr %74, i16 %76
  store i8 %73, ptr %77, align 1, !tbaa !10
  %78 = load ptr, ptr %1, align 1, !tbaa !112
  %79 = load i8, ptr %60, align 1, !tbaa !114
  %80 = add i8 %79, 1
  store i8 %80, ptr %60, align 1, !tbaa !114
  %81 = zext i8 %79 to i16
  %82 = getelementptr inbounds nuw i8, ptr %78, i16 %81
  store i8 %61, ptr %82, align 1, !tbaa !10
  %83 = load ptr, ptr %1, align 1, !tbaa !112
  %84 = load i8, ptr %60, align 1, !tbaa !114
  %85 = add i8 %84, 1
  store i8 %85, ptr %60, align 1, !tbaa !114
  %86 = zext i8 %84 to i16
  %87 = getelementptr inbounds nuw i8, ptr %83, i16 %86
  store i8 %63, ptr %87, align 1, !tbaa !10
  %88 = zext nneg i8 %73 to i16
  %89 = sub i16 %65, %88
  %90 = icmp eq i16 %89, 0
  br i1 %90, label %91, label %64, !llvm.loop !115

91:                                               ; preds = %64, %72, %21
  store i16 %19, ptr %2, align 1, !tbaa !2
  br label %92

92:                                               ; preds = %18, %91
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_blank(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, i16 noundef %2, i16 noundef range(i16 -2050, 225) %3) unnamed_addr #6 {
  %5 = icmp sgt i16 %3, %2
  br i1 %5, label %6, label %83

6:                                                ; preds = %4
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 2
  br label %9

9:                                                ; preds = %6, %79
  %10 = phi i16 [ %2, %6 ], [ %81, %79 ]
  %11 = sub nsw i16 %3, %10
  %12 = icmp sgt i16 %11, 112
  br i1 %12, label %16, label %13

13:                                               ; preds = %9
  %14 = trunc i16 %11 to i8
  %15 = icmp eq i8 %14, 0
  br i1 %15, label %79, label %16

16:                                               ; preds = %9, %13
  %17 = phi i8 [ %14, %13 ], [ 112, %9 ]
  %18 = phi i16 [ %11, %13 ], [ 112, %9 ]
  %19 = sub nsw i16 144, %10
  %20 = zext i8 %17 to i16
  %21 = trunc i16 %19 to i8
  %22 = lshr i16 %19, 8
  %23 = trunc nuw i16 %22 to i8
  br label %24

24:                                               ; preds = %32, %16
  %25 = phi i16 [ %20, %16 ], [ %49, %32 ]
  %26 = load i8, ptr %7, align 1, !tbaa !114
  %27 = icmp ult i8 %26, 22
  br i1 %27, label %28, label %51

28:                                               ; preds = %24
  %29 = icmp ugt i16 %25, 127
  br i1 %29, label %32, label %30

30:                                               ; preds = %28
  %31 = trunc nuw nsw i16 %25 to i8
  br label %32

32:                                               ; preds = %30, %28
  %33 = phi i8 [ %31, %30 ], [ 127, %28 ]
  %34 = load ptr, ptr %0, align 1, !tbaa !112
  %35 = add nuw nsw i8 %26, 1
  store i8 %35, ptr %7, align 1, !tbaa !114
  %36 = zext nneg i8 %26 to i16
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 %36
  store i8 %33, ptr %37, align 1, !tbaa !10
  %38 = load ptr, ptr %0, align 1, !tbaa !112
  %39 = load i8, ptr %7, align 1, !tbaa !114
  %40 = add i8 %39, 1
  store i8 %40, ptr %7, align 1, !tbaa !114
  %41 = zext i8 %39 to i16
  %42 = getelementptr inbounds nuw i8, ptr %38, i16 %41
  store i8 %21, ptr %42, align 1, !tbaa !10
  %43 = load ptr, ptr %0, align 1, !tbaa !112
  %44 = load i8, ptr %7, align 1, !tbaa !114
  %45 = add i8 %44, 1
  store i8 %45, ptr %7, align 1, !tbaa !114
  %46 = zext i8 %44 to i16
  %47 = getelementptr inbounds nuw i8, ptr %43, i16 %46
  store i8 %23, ptr %47, align 1, !tbaa !10
  %48 = zext nneg i8 %33 to i16
  %49 = sub i16 %25, %48
  %50 = icmp eq i16 %49, 0
  br i1 %50, label %51, label %24, !llvm.loop !115

51:                                               ; preds = %24, %32
  br label %52

52:                                               ; preds = %51, %60
  %53 = phi i16 [ %77, %60 ], [ %20, %51 ]
  %54 = load i8, ptr %8, align 1, !tbaa !114
  %55 = icmp ult i8 %54, 22
  br i1 %55, label %56, label %79

56:                                               ; preds = %52
  %57 = icmp ugt i16 %53, 127
  br i1 %57, label %60, label %58

58:                                               ; preds = %56
  %59 = trunc nuw nsw i16 %53 to i8
  br label %60

60:                                               ; preds = %58, %56
  %61 = phi i8 [ %59, %58 ], [ 127, %56 ]
  %62 = load ptr, ptr %1, align 1, !tbaa !112
  %63 = add nuw nsw i8 %54, 1
  store i8 %63, ptr %8, align 1, !tbaa !114
  %64 = zext nneg i8 %54 to i16
  %65 = getelementptr inbounds nuw i8, ptr %62, i16 %64
  store i8 %61, ptr %65, align 1, !tbaa !10
  %66 = load ptr, ptr %1, align 1, !tbaa !112
  %67 = load i8, ptr %8, align 1, !tbaa !114
  %68 = add i8 %67, 1
  store i8 %68, ptr %8, align 1, !tbaa !114
  %69 = zext i8 %67 to i16
  %70 = getelementptr inbounds nuw i8, ptr %66, i16 %69
  store i8 0, ptr %70, align 1, !tbaa !10
  %71 = load ptr, ptr %1, align 1, !tbaa !112
  %72 = load i8, ptr %8, align 1, !tbaa !114
  %73 = add i8 %72, 1
  store i8 %73, ptr %8, align 1, !tbaa !114
  %74 = zext i8 %72 to i16
  %75 = getelementptr inbounds nuw i8, ptr %71, i16 %74
  store i8 0, ptr %75, align 1, !tbaa !10
  %76 = zext nneg i8 %61 to i16
  %77 = sub i16 %53, %76
  %78 = icmp eq i16 %77, 0
  br i1 %78, label %79, label %52, !llvm.loop !115

79:                                               ; preds = %52, %60, %13
  %80 = phi i16 [ %11, %13 ], [ %18, %60 ], [ %18, %52 ]
  %81 = add nsw i16 %80, %10
  %82 = icmp sgt i16 %3, %81
  br i1 %82, label %9, label %83, !llvm.loop !116

83:                                               ; preds = %79, %4
  ret void
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.uadd.with.overflow.i8(i8, i8) #7

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @upq_flush(ptr noundef nonnull captures(none) %0) unnamed_addr #8 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i16 177
  %3 = load i8, ptr %2, align 1, !tbaa !117
  %4 = zext i8 %3 to i16
  %5 = shl nuw nsw i16 %4, 4
  %6 = add nuw nsw i16 %5, 17152
  %7 = inttoptr i16 %6 to ptr
  %8 = shl nuw i16 1, %4
  %9 = trunc i16 %8 to i8
  %10 = getelementptr inbounds nuw i8, ptr %0, i16 176
  %11 = load i8, ptr %10, align 1, !tbaa !71
  %12 = icmp eq i8 %11, 0
  br i1 %12, label %111, label %13

13:                                               ; preds = %1
  %14 = getelementptr inbounds nuw i8, ptr %7, i16 1
  %15 = getelementptr inbounds nuw i8, ptr %7, i16 2
  %16 = getelementptr inbounds nuw i8, ptr %7, i16 3
  %17 = getelementptr inbounds nuw i8, ptr %7, i16 4
  %18 = getelementptr inbounds nuw i8, ptr %7, i16 5
  %19 = getelementptr inbounds nuw i8, ptr %7, i16 6
  br label %20

20:                                               ; preds = %13, %89
  %21 = phi i8 [ %11, %13 ], [ %92, %89 ]
  %22 = phi i16 [ 0, %13 ], [ %90, %89 ]
  %23 = phi i8 [ 0, %13 ], [ %91, %89 ]
  %24 = zext i8 %23 to i16
  %25 = getelementptr inbounds nuw [11 x i8], ptr %0, i16 %24
  %26 = getelementptr inbounds nuw i8, ptr %25, i16 10
  %27 = load i8, ptr %26, align 1, !tbaa !72
  switch i8 %27, label %47 [
    i8 3, label %28
    i8 4, label %37
  ]

28:                                               ; preds = %20
  %29 = load i16, ptr %25, align 1, !tbaa !74
  %30 = inttoptr i16 %29 to ptr
  %31 = getelementptr inbounds nuw i8, ptr %25, i16 2
  %32 = load i16, ptr %31, align 1, !tbaa !78
  %33 = trunc i16 %32 to i8
  store volatile i8 %33, ptr %30, align 1, !tbaa !10
  %34 = load i16, ptr %31, align 1, !tbaa !78
  %35 = lshr i16 %34, 8
  %36 = trunc nuw i16 %35 to i8
  store volatile i8 %36, ptr %30, align 1, !tbaa !10
  br label %89

37:                                               ; preds = %20
  %38 = load i16, ptr %25, align 1, !tbaa !74
  %39 = inttoptr i16 %38 to ptr
  %40 = getelementptr inbounds nuw i8, ptr %25, i16 2
  %41 = load i16, ptr %40, align 1, !tbaa !78
  %42 = trunc i16 %41 to i8
  store volatile i8 %42, ptr %39, align 1, !tbaa !10
  %43 = load i16, ptr %40, align 1, !tbaa !78
  %44 = lshr i16 %43, 8
  %45 = trunc nuw i16 %44 to i8
  %46 = getelementptr inbounds nuw i8, ptr %39, i16 1
  store volatile i8 %45, ptr %46, align 1, !tbaa !10
  br label %89

47:                                               ; preds = %20
  %48 = icmp eq i16 %22, 0
  br i1 %48, label %54, label %49

49:                                               ; preds = %47
  %50 = getelementptr inbounds nuw i8, ptr %25, i16 4
  %51 = load i16, ptr %50, align 1, !tbaa !80
  %52 = add i16 %51, %22
  %53 = icmp ugt i16 %52, 5100
  br i1 %53, label %94, label %54

54:                                               ; preds = %49, %47
  switch i8 %27, label %62 [
    i8 0, label %55
    i8 1, label %59
  ]

55:                                               ; preds = %54
  %56 = getelementptr inbounds nuw i8, ptr %25, i16 9
  %57 = load i8, ptr %56, align 1, !tbaa !75
  store volatile i8 %57, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !10
  %58 = load i16, ptr %25, align 1, !tbaa !74
  store volatile i16 %58, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %68

59:                                               ; preds = %54
  %60 = load i16, ptr %25, align 1, !tbaa !74
  %61 = trunc i16 %60 to i8
  store volatile i8 %61, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !10
  br label %68

62:                                               ; preds = %54
  %63 = load i16, ptr %25, align 1, !tbaa !74
  %64 = trunc i16 %63 to i8
  store volatile i8 %64, ptr inttoptr (i16 8450 to ptr), align 2, !tbaa !10
  %65 = load i16, ptr %25, align 1, !tbaa !74
  %66 = lshr i16 %65, 8
  %67 = trunc nuw i16 %66 to i8
  store volatile i8 %67, ptr inttoptr (i16 8451 to ptr), align 1, !tbaa !10
  br label %68

68:                                               ; preds = %59, %62, %55
  %69 = getelementptr inbounds nuw i8, ptr %25, i16 8
  %70 = load i8, ptr %69, align 1, !tbaa !77
  store volatile i8 %70, ptr %7, align 16, !tbaa !10
  %71 = getelementptr inbounds nuw i8, ptr %25, i16 7
  %72 = load i8, ptr %71, align 1, !tbaa !76
  store volatile i8 %72, ptr %14, align 1, !tbaa !10
  %73 = getelementptr inbounds nuw i8, ptr %25, i16 2
  %74 = load i16, ptr %73, align 1, !tbaa !78
  %75 = trunc i16 %74 to i8
  store volatile i8 %75, ptr %15, align 2, !tbaa !10
  %76 = load i16, ptr %73, align 1, !tbaa !78
  %77 = lshr i16 %76, 8
  %78 = trunc nuw i16 %77 to i8
  store volatile i8 %78, ptr %16, align 1, !tbaa !10
  %79 = getelementptr inbounds nuw i8, ptr %25, i16 6
  %80 = load i8, ptr %79, align 1, !tbaa !79
  store volatile i8 %80, ptr %17, align 4, !tbaa !10
  %81 = getelementptr inbounds nuw i8, ptr %25, i16 4
  %82 = load i16, ptr %81, align 1, !tbaa !80
  %83 = trunc i16 %82 to i8
  store volatile i8 %83, ptr %18, align 1, !tbaa !10
  %84 = load i16, ptr %81, align 1, !tbaa !80
  %85 = lshr i16 %84, 8
  %86 = trunc nuw i16 %85 to i8
  store volatile i8 %86, ptr %19, align 2, !tbaa !10
  store volatile i8 %9, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !10
  %87 = load i16, ptr %81, align 1, !tbaa !80
  %88 = add i16 %87, %22
  br label %89

89:                                               ; preds = %68, %37, %28
  %90 = phi i16 [ %22, %28 ], [ %22, %37 ], [ %88, %68 ]
  %91 = add nuw i8 %23, 1
  %92 = load i8, ptr %10, align 1, !tbaa !71
  %93 = icmp ult i8 %91, %92
  br i1 %93, label %20, label %94

94:                                               ; preds = %89, %49
  %95 = phi i8 [ %92, %89 ], [ %21, %49 ]
  %96 = phi i8 [ %91, %89 ], [ %23, %49 ]
  %97 = icmp ult i8 %96, %95
  br i1 %97, label %98, label %111

98:                                               ; preds = %94
  %99 = icmp eq i8 %96, 0
  br i1 %99, label %113, label %100

100:                                              ; preds = %98, %100
  %101 = phi i8 [ %104, %100 ], [ 0, %98 ]
  %102 = phi i8 [ %107, %100 ], [ %96, %98 ]
  %103 = zext i8 %102 to i16
  %104 = add i8 %101, 1
  %105 = zext i8 %101 to i16
  %106 = getelementptr inbounds nuw [11 x i8], ptr %0, i16 %105
  %107 = add nuw i8 %102, 1
  %108 = getelementptr inbounds nuw [11 x i8], ptr %0, i16 %103
  tail call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(11) %106, ptr noundef nonnull align 1 dereferenceable(11) %108, i16 11, i1 false), !tbaa.struct !118
  %109 = load i8, ptr %10, align 1, !tbaa !71
  %110 = icmp ult i8 %107, %109
  br i1 %110, label %100, label %111, !llvm.loop !119

111:                                              ; preds = %100, %94, %1
  %112 = phi i8 [ 0, %94 ], [ 0, %1 ], [ %104, %100 ]
  store i8 %112, ptr %10, align 1, !tbaa !71
  br label %113

113:                                              ; preds = %111, %98
  ret void
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #10

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #11

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #11

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree norecurse nosync nounwind optsize memory(argmem: write) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #3 = { nofree norecurse nosync nounwind optsize memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #4 = { nofree norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #5 = { nofree norecurse nosync nounwind optsize memory(read, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #6 = { nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #7 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #8 = { nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #9 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #10 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #12 = { nounwind }
attributes #13 = { nounwind optsize }
attributes #14 = { optsize }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !9, i64 0}
!7 = !{!"", !8, i64 0, !4, i64 3}
!8 = !{!"Drawable", !9, i64 0, !4, i64 2}
!9 = !{!"any pointer", !4, i64 0}
!10 = !{!4, !4, i64 0}
!11 = distinct !{!11, !12}
!12 = !{!"llvm.loop.mustprogress"}
!13 = !{!14, !4, i64 194}
!14 = !{!"", !15, i64 0, !16, i64 178, !17, i64 182, !4, i64 191, !4, i64 192, !4, i64 193, !4, i64 194, !4, i64 195}
!15 = !{!"", !4, i64 0, !4, i64 176, !4, i64 177}
!16 = !{!"", !3, i64 0, !3, i64 2}
!17 = !{!"", !4, i64 0, !4, i64 8}
!18 = !{!14, !4, i64 195}
!19 = !{!14, !4, i64 192}
!20 = !{!14, !4, i64 193}
!21 = !{!17, !4, i64 8}
!22 = !{!23, !23, i64 0}
!23 = !{!"p1 _ZTS8Drawable", !9, i64 0}
!24 = !{!8, !9, i64 0}
!25 = !{!26, !9, i64 0}
!26 = !{!"", !9, i64 0, !9, i64 2}
!27 = distinct !{null, null}
!28 = !{!14, !4, i64 191}
!29 = !{!8, !4, i64 2}
!30 = !{!31, !9, i64 0}
!31 = !{!"", !8, i64 0, !32, i64 3, !32, i64 5, !32, i64 7, !32, i64 9, !4, i64 11, !4, i64 12, !3, i64 13, !3, i64 15, !3, i64 17, !3, i64 19, !3, i64 21, !3, i64 23, !4, i64 25, !3, i64 26, !4, i64 28, !4, i64 29, !4, i64 30, !4, i64 31, !4, i64 32, !4, i64 33, !3, i64 34, !3, i64 36, !33, i64 38, !33, i64 89}
!32 = !{!"p1 omnipotent char", !9, i64 0}
!33 = !{!"", !4, i64 0, !4, i64 50}
!34 = !{!31, !4, i64 2}
!35 = !{!31, !32, i64 3}
!36 = !{!31, !32, i64 5}
!37 = !{!31, !32, i64 7}
!38 = !{!31, !4, i64 11}
!39 = !{!31, !32, i64 9}
!40 = !{!31, !4, i64 12}
!41 = !{!31, !3, i64 13}
!42 = !{!31, !3, i64 15}
!43 = !{!31, !3, i64 17}
!44 = !{!31, !4, i64 28}
!45 = !{!31, !4, i64 29}
!46 = !{!31, !4, i64 31}
!47 = !{!31, !4, i64 32}
!48 = !{!31, !4, i64 30}
!49 = !{!31, !4, i64 25}
!50 = !{!31, !3, i64 34}
!51 = !{!31, !3, i64 36}
!52 = !{!31, !4, i64 33}
!53 = !{!26, !9, i64 2}
!54 = distinct !{null, null, null, null, null}
!55 = distinct !{!55, !12}
!56 = distinct !{!56, !12}
!57 = distinct !{!57, !12}
!58 = distinct !{null, null, null, null}
!59 = distinct !{!59, !12}
!60 = distinct !{!60, !12}
!61 = !{!62, !3, i64 1065}
!62 = !{!"", !4, i64 0, !4, i64 12, !4, i64 24, !4, i64 36, !4, i64 48, !4, i64 944, !3, i64 1065}
!63 = distinct !{!63, !12}
!64 = distinct !{!64, !12}
!65 = distinct !{null, null, null, null, null}
!66 = distinct !{!66, !12}
!67 = distinct !{!67, !12}
!68 = distinct !{null, null, null, null}
!69 = !{!31, !3, i64 19}
!70 = distinct !{null, null, null, null, null}
!71 = !{!15, !4, i64 176}
!72 = !{!73, !4, i64 10}
!73 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !4, i64 6, !4, i64 7, !4, i64 8, !4, i64 9, !4, i64 10}
!74 = !{!73, !3, i64 0}
!75 = !{!73, !4, i64 9}
!76 = !{!73, !4, i64 7}
!77 = !{!73, !4, i64 8}
!78 = !{!73, !3, i64 2}
!79 = !{!73, !4, i64 6}
!80 = !{!73, !3, i64 4}
!81 = distinct !{null, null, null}
!82 = distinct !{!82, !12}
!83 = distinct !{!83, !12}
!84 = distinct !{!84, !12}
!85 = distinct !{!85, !12}
!86 = distinct !{!86, !12}
!87 = distinct !{!87, !12}
!88 = distinct !{!88, !12}
!89 = distinct !{!89, !12}
!90 = distinct !{!90, !12}
!91 = distinct !{!91, !12}
!92 = !{!7, !4, i64 2}
!93 = distinct !{!93, !12}
!94 = distinct !{!94, !12}
!95 = distinct !{!95, !12}
!96 = distinct !{!96, !12}
!97 = distinct !{!97, !12}
!98 = distinct !{!98, !12}
!99 = distinct !{!99, !12}
!100 = distinct !{!100, !12}
!101 = distinct !{!101, !12}
!102 = distinct !{!102, !12}
!103 = distinct !{!103, !12}
!104 = distinct !{!104, !12}
!105 = !{!31, !3, i64 21}
!106 = !{!31, !3, i64 23}
!107 = distinct !{!107, !12}
!108 = !{!31, !3, i64 26}
!109 = !{!33, !4, i64 50}
!110 = distinct !{!110, !12}
!111 = distinct !{!111, !12}
!112 = !{!113, !9, i64 0}
!113 = !{!"", !9, i64 0, !4, i64 2}
!114 = !{!113, !4, i64 2}
!115 = distinct !{!115, !12}
!116 = distinct !{!116, !12}
!117 = !{!15, !4, i64 177}
!118 = !{i64 0, i64 2, !2, i64 2, i64 2, !2, i64 4, i64 2, !2, i64 6, i64 1, !10, i64 7, i64 1, !10, i64 8, i64 1, !10, i64 9, i64 1, !10, i64 10, i64 1, !10}
!119 = distinct !{!119, !12}
