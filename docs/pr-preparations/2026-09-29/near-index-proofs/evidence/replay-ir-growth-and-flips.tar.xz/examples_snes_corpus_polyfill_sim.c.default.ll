; ModuleID = '/work/examples/snes/corpus/polyfill_sim.c'
source_filename = "/work/examples/snes/corpus/polyfill_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1
@PF_SIN_LUT = internal unnamed_addr constant [256 x i16] [i16 0, i16 6, i16 13, i16 19, i16 25, i16 31, i16 38, i16 44, i16 50, i16 56, i16 62, i16 68, i16 74, i16 80, i16 86, i16 92, i16 98, i16 104, i16 109, i16 115, i16 121, i16 126, i16 132, i16 137, i16 142, i16 147, i16 152, i16 157, i16 162, i16 167, i16 172, i16 177, i16 181, i16 185, i16 190, i16 194, i16 198, i16 202, i16 206, i16 209, i16 213, i16 216, i16 220, i16 223, i16 226, i16 229, i16 231, i16 234, i16 237, i16 239, i16 241, i16 243, i16 245, i16 247, i16 248, i16 250, i16 251, i16 252, i16 253, i16 254, i16 255, i16 255, i16 256, i16 256, i16 256, i16 256, i16 256, i16 255, i16 255, i16 254, i16 253, i16 252, i16 251, i16 250, i16 248, i16 247, i16 245, i16 243, i16 241, i16 239, i16 237, i16 234, i16 231, i16 229, i16 226, i16 223, i16 220, i16 216, i16 213, i16 209, i16 206, i16 202, i16 198, i16 194, i16 190, i16 185, i16 181, i16 177, i16 172, i16 167, i16 162, i16 157, i16 152, i16 147, i16 142, i16 137, i16 132, i16 126, i16 121, i16 115, i16 109, i16 104, i16 98, i16 92, i16 86, i16 80, i16 74, i16 68, i16 62, i16 56, i16 50, i16 44, i16 38, i16 31, i16 25, i16 19, i16 13, i16 6, i16 0, i16 -6, i16 -13, i16 -19, i16 -25, i16 -31, i16 -38, i16 -44, i16 -50, i16 -56, i16 -62, i16 -68, i16 -74, i16 -80, i16 -86, i16 -92, i16 -98, i16 -104, i16 -109, i16 -115, i16 -121, i16 -126, i16 -132, i16 -137, i16 -142, i16 -147, i16 -152, i16 -157, i16 -162, i16 -167, i16 -172, i16 -177, i16 -181, i16 -185, i16 -190, i16 -194, i16 -198, i16 -202, i16 -206, i16 -209, i16 -213, i16 -216, i16 -220, i16 -223, i16 -226, i16 -229, i16 -231, i16 -234, i16 -237, i16 -239, i16 -241, i16 -243, i16 -245, i16 -247, i16 -248, i16 -250, i16 -251, i16 -252, i16 -253, i16 -254, i16 -255, i16 -255, i16 -256, i16 -256, i16 -256, i16 -256, i16 -256, i16 -255, i16 -255, i16 -254, i16 -253, i16 -252, i16 -251, i16 -250, i16 -248, i16 -247, i16 -245, i16 -243, i16 -241, i16 -239, i16 -237, i16 -234, i16 -231, i16 -229, i16 -226, i16 -223, i16 -220, i16 -216, i16 -213, i16 -209, i16 -206, i16 -202, i16 -198, i16 -194, i16 -190, i16 -185, i16 -181, i16 -177, i16 -172, i16 -167, i16 -162, i16 -157, i16 -152, i16 -147, i16 -142, i16 -137, i16 -132, i16 -126, i16 -121, i16 -115, i16 -109, i16 -104, i16 -98, i16 -92, i16 -86, i16 -80, i16 -74, i16 -68, i16 -62, i16 -56, i16 -50, i16 -44, i16 -38, i16 -31, i16 -25, i16 -19, i16 -13, i16 -6], align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca [6 x i16], align 1
  %2 = alloca [16 x i16], align 1
  %3 = alloca [16 x i16], align 1
  %4 = getelementptr inbounds nuw i8, ptr %3, i16 10
  br label %5

5:                                                ; preds = %127, %0
  %6 = phi i16 [ 0, %0 ], [ %134, %127 ]
  %7 = phi i16 [ 0, %0 ], [ %135, %127 ]
  %8 = phi i8 [ 0, %0 ], [ %136, %127 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #4
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #4
  br label %9

9:                                                ; preds = %9, %5
  %10 = phi i8 [ %43, %9 ], [ 0, %5 ]
  %11 = phi i16 [ %41, %9 ], [ 0, %5 ]
  %12 = zext nneg i16 %11 to i32
  %13 = shl nuw nsw i32 %12, 8
  %14 = udiv i32 %13, 6
  %15 = trunc i32 %14 to i8
  %16 = add i8 %8, %15
  %17 = zext i8 %16 to i16
  %18 = add i8 %16, 64
  %19 = zext i8 %18 to i16
  %20 = getelementptr inbounds nuw [2 x i8], ptr @PF_SIN_LUT, i16 %19
  %21 = load i16, ptr %20, align 1, !tbaa !2
  %22 = getelementptr inbounds nuw [2 x i8], ptr @PF_SIN_LUT, i16 %17
  %23 = load i16, ptr %22, align 1, !tbaa !2
  %24 = and i16 %11, 1
  %25 = icmp eq i16 %24, 0
  %26 = select i1 %25, i16 52, i16 22
  %27 = zext nneg i16 %26 to i32
  %28 = sext i16 %21 to i32
  %29 = mul nsw i32 %27, %28
  %30 = lshr i32 %29, 8
  %31 = trunc i32 %30 to i16
  %32 = add nsw i16 %31, 64
  %33 = zext nneg i8 %10 to i16
  %34 = getelementptr i8, ptr %2, i16 %33
  store i16 %32, ptr %34, align 1, !tbaa !2
  %35 = sext i16 %23 to i32
  %36 = mul nsw i32 %27, %35
  %37 = lshr i32 %36, 8
  %38 = trunc i32 %37 to i16
  %39 = add nsw i16 %38, 64
  %40 = getelementptr i8, ptr %3, i16 %33
  store i16 %39, ptr %40, align 1, !tbaa !2
  %41 = add nuw nsw i16 %11, 1
  %42 = icmp eq i16 %41, 6
  %43 = add nuw nsw i8 %10, 2
  br i1 %42, label %44, label %9, !llvm.loop !6

44:                                               ; preds = %9
  %45 = tail call ptr @llvm.stacksave.p0()
  call void @llvm.lifetime.start.p0(ptr nonnull %1)
  %46 = load i16, ptr %4, align 1, !tbaa !2
  br label %47

47:                                               ; preds = %105, %44
  %48 = phi i32 [ 0, %44 ], [ %106, %105 ]
  %49 = phi i16 [ 12, %44 ], [ %107, %105 ]
  br label %52

50:                                               ; preds = %82
  %51 = icmp ugt i16 %83, 1
  br i1 %51, label %87, label %105

52:                                               ; preds = %82, %47
  %53 = phi i8 [ %86, %82 ], [ 0, %47 ]
  %54 = phi i16 [ %60, %82 ], [ %46, %47 ]
  %55 = phi i16 [ %83, %82 ], [ 0, %47 ]
  %56 = phi i16 [ %57, %82 ], [ 5, %47 ]
  %57 = phi i16 [ %84, %82 ], [ 0, %47 ]
  %58 = zext nneg i8 %53 to i16
  %59 = getelementptr i8, ptr %3, i16 %58
  %60 = load i16, ptr %59, align 1, !tbaa !2
  %61 = icmp sgt i16 %60, %49
  %62 = icmp sgt i16 %54, %49
  br i1 %61, label %64, label %63

63:                                               ; preds = %52
  br i1 %62, label %65, label %82

64:                                               ; preds = %52
  br i1 %62, label %82, label %65

65:                                               ; preds = %64, %63
  %66 = sub nsw i16 %49, %60
  %67 = sext i16 %66 to i32
  %68 = getelementptr inbounds nuw [2 x i8], ptr %2, i16 %56
  %69 = load i16, ptr %68, align 1, !tbaa !2
  %70 = getelementptr i8, ptr %2, i16 %58
  %71 = load i16, ptr %70, align 1, !tbaa !2
  %72 = sub nsw i16 %69, %71
  %73 = sext i16 %72 to i32
  %74 = mul nsw i32 %73, %67
  %75 = sub nsw i16 %54, %60
  %76 = sext i16 %75 to i32
  %77 = sdiv i32 %74, %76
  %78 = trunc i32 %77 to i16
  %79 = add i16 %71, %78
  %80 = add i16 %55, 1
  %81 = getelementptr inbounds nuw [2 x i8], ptr %1, i16 %55
  store i16 %79, ptr %81, align 1, !tbaa !2
  br label %82

82:                                               ; preds = %65, %64, %63
  %83 = phi i16 [ %80, %65 ], [ %55, %64 ], [ %55, %63 ]
  %84 = add nuw nsw i16 %57, 1
  %85 = icmp eq i16 %84, 6
  %86 = add nuw nsw i8 %53, 2
  br i1 %85, label %50, label %52, !llvm.loop !8

87:                                               ; preds = %50, %100
  %88 = phi i16 [ %103, %100 ], [ 1, %50 ]
  %89 = getelementptr inbounds nuw [2 x i8], ptr %1, i16 %88
  %90 = load i16, ptr %89, align 1, !tbaa !2
  br label %91

91:                                               ; preds = %97, %87
  %92 = phi i16 [ %98, %97 ], [ %88, %87 ]
  %93 = getelementptr [2 x i8], ptr %1, i16 %92
  %94 = getelementptr i8, ptr %93, i16 -2
  %95 = load i16, ptr %94, align 1, !tbaa !2
  %96 = icmp sgt i16 %95, %90
  br i1 %96, label %97, label %100

97:                                               ; preds = %91
  store i16 %95, ptr %93, align 1, !tbaa !2
  %98 = add i16 %92, -1
  %99 = icmp eq i16 %98, 0
  br i1 %99, label %100, label %91, !llvm.loop !9

100:                                              ; preds = %97, %91
  %101 = phi i16 [ %92, %91 ], [ 0, %97 ]
  %102 = getelementptr inbounds nuw [2 x i8], ptr %1, i16 %101
  store i16 %90, ptr %102, align 1, !tbaa !2
  %103 = add nuw i16 %88, 1
  %104 = icmp eq i16 %103, %83
  br i1 %104, label %109, label %87, !llvm.loop !10

105:                                              ; preds = %122, %50
  %106 = phi i32 [ %48, %50 ], [ %123, %122 ]
  %107 = add nuw nsw i16 %49, 4
  %108 = icmp samesign ult i16 %49, 113
  br i1 %108, label %47, label %127, !llvm.loop !11

109:                                              ; preds = %100, %122
  %110 = phi i32 [ %123, %122 ], [ %48, %100 ]
  %111 = phi i16 [ %124, %122 ], [ 0, %100 ]
  %112 = getelementptr inbounds nuw [2 x i8], ptr %1, i16 %111
  %113 = load i16, ptr %112, align 1, !tbaa !2
  %114 = getelementptr inbounds nuw i8, ptr %112, i16 2
  %115 = load i16, ptr %114, align 1, !tbaa !2
  %116 = icmp slt i16 %115, %113
  br i1 %116, label %122, label %117

117:                                              ; preds = %109
  %118 = sub i16 %115, %113
  %119 = add i16 %118, 1
  %120 = zext nneg i16 %119 to i32
  %121 = add i32 %110, %120
  br label %122

122:                                              ; preds = %117, %109
  %123 = phi i32 [ %121, %117 ], [ %110, %109 ]
  %124 = add nuw i16 %111, 2
  %125 = or disjoint i16 %124, 1
  %126 = icmp ult i16 %125, %83
  br i1 %126, label %109, label %105, !llvm.loop !12

127:                                              ; preds = %105
  call void @llvm.lifetime.end.p0(ptr nonnull %1)
  call void @llvm.stackrestore.p0(ptr %45)
  %128 = trunc i32 %106 to i16
  %129 = tail call i16 @llvm.fshl.i16(i16 %6, i16 %6, i16 1)
  %130 = xor i16 %129, %128
  %131 = lshr i32 %106, 16
  %132 = trunc nuw i32 %131 to i16
  %133 = tail call i16 @llvm.fshl.i16(i16 %130, i16 %130, i16 1)
  %134 = xor i16 %133, %132
  %135 = add nuw nsw i16 %7, 1
  %136 = add nuw nsw i8 %8, 3
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #4
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #4
  %137 = icmp eq i16 %135, 16
  br i1 %137, label %138, label %5, !llvm.loop !13

138:                                              ; preds = %127
  store volatile i16 %134, ptr @corpus_result, align 1, !tbaa !2
  br label %139

139:                                              ; preds = %139, %138
  tail call void asm sideeffect "wai", ""() #4, !srcloc !14
  br label %139
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #3

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = !{i64 386}
