; ModuleID = '/work/examples/snes/newton.c'
source_filename = "/work/examples/snes/newton.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.NewtonLayer = type { %struct.Drawable, [896 x i16], i32, i8 }
%struct.Drawable = type { ptr, i8 }
%struct.DrawableVT = type { ptr, ptr }
%struct.TitleLayer = type { %struct.Drawable, ptr, ptr, ptr, ptr, i8, i8, i16, i16, i16, i16, i16, i16, i8, i16, i8, i8, i8, i8, i8, i8, i16, i16, %struct.HScrollDB, %struct.HScrollDB }
%struct.HScrollDB = type { [2 x %struct.HScrollN], i8 }
%struct.HScrollN = type { [25 x i8] }
%struct.Display = type { %struct.UploadQueue, %struct.VramAlloc, %struct.Scene, i8, i8, i8, i8, i8 }
%struct.UploadQueue = type { [16 x %struct.UpqJob], i8, i8 }
%struct.UpqJob = type { i16, i16, i16, i8, i8, i8, i8, i8 }
%struct.VramAlloc = type { i16, i16 }
%struct.Scene = type { [4 x ptr], i8 }
%struct.HScrollW = type { ptr, i8 }

@main.layer = internal global %struct.NewtonLayer zeroinitializer, align 1
@NEWTON_VT = internal constant %struct.DrawableVT { ptr @_newton_reserve, ptr @_newton_emit }, align 1
@main.title = internal global %struct.TitleLayer zeroinitializer, align 1
@.str = private unnamed_addr constant [15 x i8] c"NEWTON FRACTAL\00", align 1
@.str.1 = private unnamed_addr constant [17 x i8] c"COMPLEX DIVISION\00", align 1
@corpus_result = dso_local global i16 0, align 1
@newton_pal = internal constant [64 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 4, i16 6, i16 8, i16 10, i16 12, i16 14, i16 16, i16 18, i16 20, i16 1078, i16 2136, i16 3194, i16 4252, i16 4254, i16 8479, i16 0, i16 128, i16 192, i16 256, i16 320, i16 384, i16 448, i16 512, i16 576, i16 640, i16 1729, i16 2818, i16 3907, i16 4996, i16 5060, i16 9192, i16 0, i16 4096, i16 6144, i16 8192, i16 10240, i16 12288, i16 14336, i16 16384, i16 18432, i16 20480, i16 22561, i16 24642, i16 26723, i16 28804, i16 30852, i16 32008], align 1
@TITLE_VT = internal constant %struct.DrawableVT { ptr @_title_reserve, ptr @_title_emit }, align 1
@FONT8 = internal unnamed_addr constant [512 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 32, i16 0, i16 80, i16 80, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 80, i16 80, i16 248, i16 80, i16 248, i16 80, i16 80, i16 0, i16 32, i16 120, i16 160, i16 112, i16 40, i16 240, i16 32, i16 0, i16 196, i16 200, i16 16, i16 32, i16 64, i16 152, i16 12, i16 0, i16 96, i16 144, i16 160, i16 64, i16 168, i16 144, i16 104, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 16, i16 32, i16 64, i16 64, i16 64, i16 32, i16 16, i16 0, i16 64, i16 32, i16 16, i16 16, i16 16, i16 32, i16 64, i16 0, i16 0, i16 32, i16 168, i16 112, i16 168, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 248, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 64, i16 0, i16 0, i16 0, i16 248, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 0, i16 8, i16 8, i16 16, i16 32, i16 64, i16 128, i16 128, i16 0, i16 112, i16 136, i16 152, i16 168, i16 200, i16 136, i16 112, i16 0, i16 32, i16 96, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 64, i16 248, i16 0, i16 112, i16 136, i16 8, i16 48, i16 8, i16 136, i16 112, i16 0, i16 16, i16 48, i16 80, i16 144, i16 248, i16 16, i16 16, i16 0, i16 248, i16 128, i16 240, i16 8, i16 8, i16 136, i16 112, i16 0, i16 112, i16 136, i16 128, i16 240, i16 136, i16 136, i16 112, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 64, i16 64, i16 0, i16 112, i16 136, i16 136, i16 112, i16 136, i16 136, i16 112, i16 0, i16 112, i16 136, i16 136, i16 120, i16 8, i16 136, i16 112, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 64, i16 0, i16 16, i16 32, i16 64, i16 128, i16 64, i16 32, i16 16, i16 0, i16 0, i16 0, i16 248, i16 0, i16 248, i16 0, i16 0, i16 0, i16 128, i16 64, i16 32, i16 16, i16 32, i16 64, i16 128, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 0, i16 32, i16 0, i16 112, i16 136, i16 184, i16 168, i16 184, i16 128, i16 112, i16 0, i16 112, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 240, i16 136, i16 136, i16 240, i16 136, i16 136, i16 240, i16 0, i16 112, i16 136, i16 128, i16 128, i16 128, i16 136, i16 112, i16 0, i16 224, i16 144, i16 136, i16 136, i16 136, i16 144, i16 224, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 248, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 128, i16 176, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 112, i16 32, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 56, i16 16, i16 16, i16 16, i16 144, i16 144, i16 96, i16 0, i16 136, i16 144, i16 160, i16 192, i16 160, i16 144, i16 136, i16 0, i16 128, i16 128, i16 128, i16 128, i16 128, i16 128, i16 248, i16 0, i16 136, i16 216, i16 168, i16 136, i16 136, i16 136, i16 136, i16 0, i16 136, i16 200, i16 168, i16 152, i16 136, i16 136, i16 136, i16 0, i16 112, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 240, i16 136, i16 136, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 136, i16 136, i16 168, i16 144, i16 104, i16 0, i16 240, i16 136, i16 136, i16 240, i16 160, i16 144, i16 136, i16 0, i16 112, i16 136, i16 128, i16 112, i16 8, i16 136, i16 112, i16 0, i16 248, i16 32, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 80, i16 32, i16 0, i16 136, i16 136, i16 136, i16 168, i16 168, i16 216, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 80, i16 136, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 32, i16 32, i16 32, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 128, i16 248, i16 0, i16 48, i16 32, i16 32, i16 32, i16 32, i16 32, i16 48, i16 0, i16 128, i16 128, i16 64, i16 32, i16 16, i16 8, i16 8, i16 0, i16 48, i16 16, i16 16, i16 16, i16 16, i16 16, i16 48, i16 0, i16 32, i16 80, i16 136, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248], align 1
@FONT16 = internal unnamed_addr constant [2048 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 192, i16 192, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 768, i16 768, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 -4096, i16 -4096, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3840, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 3312, i16 15360, i16 15360, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 28, i16 28, i16 796, i16 127, i16 127, i16 796, i16 796, i16 127, i16 112, i16 112, i16 3184, i16 252, i16 252, i16 -28816, i16 -28816, i16 252, i16 127, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 0, i16 0, i16 252, i16 -28816, i16 -28816, i16 3184, i16 7168, i16 7168, i16 0, i16 0, i16 3, i16 63, i16 123, i16 1147, i16 63, i16 4111, i16 3075, i16 123, i16 192, i16 248, i16 8414, i16 16064, i16 2040, i16 248, i16 8414, i16 8414, i16 63, i16 7171, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 2040, i16 14272, i16 -512, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3585, i16 3, i16 7, i16 28, i16 56, i16 1904, i16 3808, i16 7392, i16 14528, i16 14464, i16 28672, i16 14, i16 284, i16 824, i16 1792, i16 3584, i16 0, i16 0, i16 0, i16 -8162, i16 -16354, i16 -32482, i16 286, i16 1792, i16 1792, i16 0, i16 0, i16 15, i16 31, i16 828, i16 828, i16 573, i16 31, i16 31, i16 63, i16 192, i16 224, i16 240, i16 2288, i16 7392, i16 15488, i16 30720, i16 -32648, i16 382, i16 3060, i16 3825, i16 1275, i16 127, i16 63, i16 7936, i16 3840, i16 248, i16 3824, i16 7904, i16 7392, i16 4332, i16 12492, i16 -1280, i16 -3328, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 7, i16 15, i16 15, i16 15, i16 15, i16 15, i16 240, i16 192, i16 15488, i16 -4096, i16 -8192, i16 -16384, i16 -16384, i16 -16384, i16 15, i16 7, i16 3, i16 256, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 16512, i16 192, i16 240, i16 -4096, i16 15360, i16 0, i16 0, i16 15, i16 3, i16 513, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 224, i16 240, i16 2288, i16 3312, i16 3312, i16 3312, i16 0, i16 1, i16 3, i16 15, i16 0, i16 768, i16 0, i16 0, i16 3312, i16 7392, i16 15552, i16 30720, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 51, i16 31, i16 15, i16 1027, i16 0, i16 0, i16 192, i16 192, i16 12492, i16 252, i16 1016, i16 16320, i16 15, i16 31, i16 51, i16 1027, i16 3072, i16 0, i16 0, i16 0, i16 1784, i16 252, i16 13004, i16 16320, i16 -3328, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 3, i16 63, i16 63, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 248, i16 248, i16 63, i16 3075, i16 3075, i16 3, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 16064, i16 16064, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 286, i16 828, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 28800, i16 -4096, i16 -8192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 -512, i16 -512, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7360, i16 14464, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7168, i16 14336, i16 28672, i16 -8192, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 828, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 15, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 1, i16 3, i16 15, i16 15, i16 513, i16 513, i16 1, i16 1, i16 240, i16 240, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 1, i16 1, i16 1, i16 1, i16 1, i16 1, i16 0, i16 0, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 31744, i16 31744, i16 15, i16 31, i16 318, i16 828, i16 3840, i16 3840, i16 3, i16 15, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 63, i16 510, i16 4080, i16 31, i16 318, i16 318, i16 318, i16 63, i16 63, i16 3840, i16 3840, i16 32640, i16 -1024, i16 -8192, i16 -32768, i16 255, i16 255, i16 -256, i16 -256, i16 15, i16 63, i16 824, i16 3840, i16 2055, i16 7, i16 256, i16 256, i16 252, i16 254, i16 -8161, i16 -4081, i16 510, i16 1020, i16 -7906, i16 -4081, i16 0, i16 0, i16 56, i16 60, i16 63, i16 31, i16 3840, i16 1792, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 15, i16 286, i16 62, i16 126, i16 510, i16 510, i16 8670, i16 24990, i16 -7906, i16 -7906, i16 828, i16 828, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 -16098, i16 -32482, i16 255, i16 255, i16 -7906, i16 -7906, i16 1792, i16 1792, i16 31, i16 63, i16 828, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 254, i16 254, i16 -256, i16 -256, i16 252, i16 254, i16 -8161, i16 -4081, i16 0, i16 0, i16 60, i16 62, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 63, i16 63, i16 318, i16 828, i16 254, i16 255, i16 -2041, i16 -256, i16 508, i16 254, i16 -4081, i16 -2041, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 -32761, i16 7, i16 7, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 31, i16 318, i16 892, i16 0, i16 1, i16 3, i16 7, i16 7, i16 7, i16 256, i16 256, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 28800, i16 -8192, i16 -8192, i16 15, i16 31, i16 828, i16 828, i16 828, i16 31, i16 15, i16 796, i16 252, i16 254, i16 -4081, i16 -4081, i16 15, i16 510, i16 1020, i16 -3826, i16 828, i16 828, i16 828, i16 828, i16 31, i16 15, i16 1792, i16 768, i16 -4081, i16 15, i16 15, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 318, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 31, i16 31, i16 15, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 270, i16 796, i16 824, i16 1792, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 15, i16 60, i16 828, i16 0, i16 0, i16 60, i16 240, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 15360, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 60, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 60, i16 0, i16 3, i16 15, i16 60, i16 768, i16 3840, i16 0, i16 0, i16 4080, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 31, i16 63, i16 828, i16 3840, i16 3840, i16 7, i16 7, i16 7, i16 240, i16 248, i16 -32644, i16 -32132, i16 2040, i16 4080, i16 16064, i16 31872, i16 256, i16 256, i16 7, i16 7, i16 7, i16 256, i16 256, i16 0, i16 -4096, i16 -8192, i16 128, i16 128, i16 24704, i16 -8192, i16 -8192, i16 0, i16 31, i16 63, i16 828, i16 573, i16 573, i16 573, i16 573, i16 573, i16 248, i16 252, i16 -15812, i16 4590, i16 494, i16 4590, i16 1020, i16 1016, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 0, i16 0, i16 0, i16 32512, i16 764, i16 248, i16 -256, i16 -512, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 892, i16 1020, i16 1020, i16 255, i16 255, i16 224, i16 240, i16 -32648, i16 -16324, i16 -32196, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -28928, i16 1792, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 0, i16 0, i16 28, i16 60, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -8164, i16 -3572, i16 -30976, i16 768, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 8988, i16 8988, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 60, i16 60, i16 828, i16 828, i16 828, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 255, i16 255, i16 16128, i16 16128, i16 12480, i16 12480, i16 12480, i16 12480, i16 252, i16 252, i16 -256, i16 -256, i16 63, i16 63, i16 3075, i16 3075, i16 3, i16 3, i16 51, i16 51, i16 252, i16 252, i16 4080, i16 4080, i16 3312, i16 3312, i16 3312, i16 3312, i16 3123, i16 3123, i16 63, i16 63, i16 31, i16 15, i16 1792, i16 768, i16 3312, i16 3312, i16 3312, i16 3312, i16 7392, i16 15552, i16 -2048, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 765, i16 255, i16 255, i16 255, i16 28, i16 60, i16 1912, i16 4080, i16 7904, i16 15552, i16 30848, i16 12480, i16 255, i16 765, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 224, i16 240, i16 248, i16 124, i16 572, i16 828, i16 3840, i16 3840, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 0, i16 0, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 248, i16 252, i16 254, i16 2295, i16 3315, i16 3315, i16 3315, i16 3315, i16 60, i16 124, i16 1020, i16 988, i16 9116, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 15360, i16 15360, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 -6400, i16 -6400, i16 240, i16 248, i16 252, i16 254, i16 255, i16 255, i16 2295, i16 3315, i16 60, i16 60, i16 828, i16 828, i16 828, i16 956, i16 1020, i16 1020, i16 3313, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 15360, i16 15360, i16 1020, i16 1020, i16 892, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -31972, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -512, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 224, i16 240, i16 -32648, i16 -15304, i16 -31176, i16 1592, i16 1592, i16 1592, i16 765, i16 765, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 1784, i16 1784, i16 17976, i16 1656, i16 764, i16 764, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 63, i16 127, i16 2040, i16 4080, i16 1784, i16 255, i16 127, i16 63, i16 248, i16 252, i16 -15812, i16 -256, i16 3840, i16 240, i16 248, i16 252, i16 7936, i16 3840, i16 224, i16 255, i16 255, i16 127, i16 16128, i16 7936, i16 -32132, i16 -15556, i16 892, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 -4096, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 28, i16 28, i16 796, i16 796, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 510, i16 255, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 828, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 248, i16 248, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 124, i16 124, i16 1912, i16 1912, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 572, i16 63, i16 31, i16 15, i16 7, i16 768, i16 256, i16 1656, i16 3824, i16 3824, i16 7392, i16 15552, i16 30848, i16 -4096, i16 -8192, i16 243, i16 243, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 156, i16 156, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 2295, i16 255, i16 510, i16 892, i16 16128, i16 7936, i16 25500, i16 25500, i16 9180, i16 1020, i16 1020, i16 -30856, i16 -16640, i16 7680, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 15, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 14528, i16 31, i16 63, i16 892, i16 2040, i16 4080, i16 3824, i16 15360, i16 15360, i16 4320, i16 240, i16 248, i16 -32644, i16 572, i16 828, i16 3840, i16 3840, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 7, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 7, i16 7, i16 7, i16 7, i16 7, i16 7, i16 256, i16 256, i16 28800, i16 24704, i16 24704, i16 24704, i16 24704, i16 24704, i16 -8192, i16 -8192, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 1, i16 3, i16 7, i16 252, i16 252, i16 1020, i16 -31876, i16 2040, i16 4080, i16 7904, i16 15552, i16 15, i16 31, i16 318, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 30848, i16 -4096, i16 -8192, i16 252, i16 252, i16 1020, i16 -256, i16 -256, i16 31, i16 31, i16 286, i16 286, i16 286, i16 286, i16 286, i16 286, i16 224, i16 224, i16 -2048, i16 -2048, i16 -32768, i16 -32768, i16 -32768, i16 -32768, i16 286, i16 286, i16 286, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 -32768, i16 -32768, i16 -32768, i16 224, i16 224, i16 -2048, i16 -2048, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 3, i16 1, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 128, i16 192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 768, i16 256, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 0, i16 0, i16 0, i16 224, i16 224, i16 2288, i16 2288, i16 3312, i16 3312, i16 3312, i16 3312, i16 0, i16 0, i16 0, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 3312, i16 3312, i16 3312, i16 7392, i16 7392, i16 -2048, i16 -2048, i16 0, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1840, i16 3584, i16 3072, i16 192, i16 224, i16 -32656, i16 -16328, i16 -32740, i16 524, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 127, i16 127, i16 7936, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 -512], align 1
@title_end._title_bg_black = internal constant i16 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  %1 = alloca i16, align 1
  %2 = alloca i16, align 1
  %3 = alloca %struct.Display, align 1
  store ptr @NEWTON_VT, ptr @main.layer, align 1, !tbaa !6
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #12
  store volatile i8 -113, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !11
  br label %4

4:                                                ; preds = %8, %0
  %5 = phi i16 [ 8449, %0 ], [ %9, %8 ]
  switch i16 %5, label %6 [
    i16 8452, label %8
    i16 8470, label %8
    i16 8471, label %8
    i16 8472, label %8
    i16 8473, label %8
    i16 8481, label %8
    i16 8482, label %8
  ]

6:                                                ; preds = %4
  %7 = inttoptr i16 %5 to ptr
  store volatile i8 0, ptr %7, align 1, !tbaa !11
  br label %8

8:                                                ; preds = %6, %4, %4, %4, %4, %4, %4, %4
  %9 = add nuw nsw i16 %5, 1
  %10 = icmp eq i16 %9, 8500
  br i1 %10, label %11, label %4, !llvm.loop !12

11:                                               ; preds = %8
  %12 = getelementptr inbounds nuw i8, ptr %3, i16 176
  %13 = getelementptr inbounds nuw i8, ptr %3, i16 190
  %14 = getelementptr inbounds nuw i8, ptr %3, i16 194
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) %12, i8 0, i64 6, i1 false)
  store i32 0, ptr %13, align 1
  store i8 15, ptr %14, align 1, !tbaa !14
  %15 = getelementptr inbounds nuw i8, ptr %3, i16 195
  store i8 15, ptr %15, align 1, !tbaa !19
  store volatile i8 1, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !11
  store volatile i8 0, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !11
  store volatile i8 -127, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !11
  %16 = getelementptr inbounds nuw i8, ptr %3, i16 192
  %17 = load i8, ptr %16, align 1, !tbaa !20
  %18 = icmp eq i8 %17, 0
  br i1 %18, label %21, label %19

19:                                               ; preds = %11
  %20 = getelementptr inbounds nuw i8, ptr %3, i16 193
  store i8 1, ptr %20, align 1, !tbaa !21
  br label %21

21:                                               ; preds = %19, %11
  %22 = load i8, ptr %13, align 1, !tbaa !22
  %23 = icmp ult i8 %22, 4
  br i1 %23, label %24, label %29

24:                                               ; preds = %21
  %25 = getelementptr inbounds nuw i8, ptr %3, i16 182
  %26 = zext nneg i8 %22 to i16
  %27 = add nuw nsw i8 %22, 1
  store i8 %27, ptr %13, align 1, !tbaa !22
  %28 = getelementptr inbounds nuw [2 x i8], ptr %25, i16 %26
  store ptr @main.layer, ptr %28, align 1, !tbaa !23
  br label %29

29:                                               ; preds = %21, %24
  %30 = getelementptr inbounds nuw i8, ptr %3, i16 178
  %31 = load ptr, ptr @main.layer, align 1, !tbaa !25
  %32 = load ptr, ptr %31, align 1, !tbaa !26
  call void %32(ptr noundef nonnull @main.layer, ptr noundef nonnull %30) #13, !inline_history !28
  %33 = getelementptr inbounds nuw i8, ptr %3, i16 191
  %34 = load i8, ptr %33, align 1, !tbaa !29
  %35 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.layer, i16 2), align 1, !tbaa !30
  %36 = or i8 %35, %34
  store i8 %36, ptr %33, align 1, !tbaa !29
  store volatile i8 %36, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !11
  store ptr @TITLE_VT, ptr @main.title, align 1, !tbaa !31
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !35
  store ptr @.str, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 3), align 1, !tbaa !36
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 5), align 1, !tbaa !37
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 7), align 1, !tbaa !38
  store i8 16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 11), align 1, !tbaa !39
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 9), align 1, !tbaa !40
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 12), align 1, !tbaa !41
  store i16 96, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 13), align 1, !tbaa !42
  store i16 112, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 15), align 1, !tbaa !43
  store i16 16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 17), align 1, !tbaa !44
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 28), align 1, !tbaa !45
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !46
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !47
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !48
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !49
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !50
  store i16 32767, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 34), align 1, !tbaa !51
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 36), align 1, !tbaa !52
  %37 = load i8, ptr %33, align 1, !tbaa !29
  %38 = load i8, ptr %16, align 1, !tbaa !20
  %39 = icmp eq i8 %38, 0
  br i1 %39, label %42, label %40

40:                                               ; preds = %29
  %41 = getelementptr inbounds nuw i8, ptr %3, i16 193
  store i8 1, ptr %41, align 1, !tbaa !21
  br label %42

42:                                               ; preds = %40, %29
  %43 = load i8, ptr %13, align 1, !tbaa !22
  %44 = icmp ult i8 %43, 4
  br i1 %44, label %45, label %50

45:                                               ; preds = %42
  %46 = getelementptr inbounds nuw i8, ptr %3, i16 182
  %47 = zext nneg i8 %43 to i16
  %48 = add nuw nsw i8 %43, 1
  store i8 %48, ptr %13, align 1, !tbaa !22
  %49 = getelementptr inbounds nuw [2 x i8], ptr %46, i16 %47
  store ptr @main.title, ptr %49, align 1, !tbaa !23
  br label %50

50:                                               ; preds = %45, %42
  call void @_title_reserve(ptr noundef nonnull @main.title, ptr nonnull poison) #13, !inline_history !28
  %51 = load i8, ptr %33, align 1, !tbaa !29
  %52 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !30
  %53 = or i8 %52, %51
  store volatile i8 %53, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !11
  store i8 %37, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !53
  store i8 2, ptr %33, align 1, !tbaa !29
  store volatile i8 2, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !11
  store volatile i8 24, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !11
  store i8 0, ptr %14, align 1, !tbaa !14
  store i8 15, ptr %15, align 1, !tbaa !19
  %54 = getelementptr inbounds nuw i8, ptr %3, i16 182
  br label %55

55:                                               ; preds = %83, %50
  %56 = load i8, ptr %13, align 1, !tbaa !22
  %57 = icmp eq i8 %56, 0
  br i1 %57, label %69, label %58

58:                                               ; preds = %55, %58
  %59 = phi i8 [ %66, %58 ], [ 0, %55 ]
  %60 = zext i8 %59 to i16
  %61 = getelementptr inbounds nuw [2 x i8], ptr %54, i16 %60
  %62 = load ptr, ptr %61, align 1, !tbaa !23
  %63 = load ptr, ptr %62, align 1, !tbaa !25
  %64 = getelementptr inbounds nuw i8, ptr %63, i16 2
  %65 = load ptr, ptr %64, align 1, !tbaa !54
  call void %65(ptr noundef nonnull %62, ptr noundef nonnull %3) #13, !inline_history !55
  %66 = add nuw i8 %59, 1
  %67 = load i8, ptr %13, align 1, !tbaa !22
  %68 = icmp ult i8 %66, %67
  br i1 %68, label %58, label %69, !llvm.loop !56

69:                                               ; preds = %58, %55
  %70 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !11
  br label %71

71:                                               ; preds = %71, %69
  %72 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !11
  %73 = icmp sgt i8 %72, -1
  br i1 %73, label %71, label %74, !llvm.loop !57

74:                                               ; preds = %71
  call fastcc void @upq_flush(ptr noundef nonnull %3) #14
  %75 = load i8, ptr %14, align 1, !tbaa !14
  %76 = load i8, ptr %15, align 1, !tbaa !19
  %77 = icmp ult i8 %75, %76
  br i1 %77, label %80, label %78

78:                                               ; preds = %74
  %79 = icmp ugt i8 %75, %76
  br i1 %79, label %80, label %83

80:                                               ; preds = %78, %74
  %81 = phi i8 [ 1, %74 ], [ -1, %78 ]
  %82 = add i8 %81, %75
  store i8 %82, ptr %14, align 1, !tbaa !14
  br label %83

83:                                               ; preds = %80, %78
  %84 = phi i8 [ %75, %78 ], [ %82, %80 ]
  %85 = and i8 %84, 15
  store volatile i8 %85, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !11
  store i8 1, ptr %16, align 1, !tbaa !20
  %86 = load i8, ptr %14, align 1, !tbaa !14
  %87 = icmp eq i8 %86, 15
  br i1 %87, label %88, label %55, !llvm.loop !58

88:                                               ; preds = %83
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !49
  %89 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !50
  %90 = icmp eq i8 %89, -1
  br i1 %90, label %128, label %91

91:                                               ; preds = %88, %120
  %92 = phi i8 [ %123, %120 ], [ 0, %88 ]
  %93 = load i8, ptr %13, align 1, !tbaa !22
  %94 = icmp eq i8 %93, 0
  br i1 %94, label %106, label %95

95:                                               ; preds = %91, %95
  %96 = phi i8 [ %103, %95 ], [ 0, %91 ]
  %97 = zext i8 %96 to i16
  %98 = getelementptr inbounds nuw [2 x i8], ptr %54, i16 %97
  %99 = load ptr, ptr %98, align 1, !tbaa !23
  %100 = load ptr, ptr %99, align 1, !tbaa !25
  %101 = getelementptr inbounds nuw i8, ptr %100, i16 2
  %102 = load ptr, ptr %101, align 1, !tbaa !54
  call void %102(ptr noundef nonnull %99, ptr noundef nonnull %3) #13, !inline_history !59
  %103 = add nuw i8 %96, 1
  %104 = load i8, ptr %13, align 1, !tbaa !22
  %105 = icmp ult i8 %103, %104
  br i1 %105, label %95, label %106, !llvm.loop !56

106:                                              ; preds = %95, %91
  %107 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !11
  br label %108

108:                                              ; preds = %108, %106
  %109 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !11
  %110 = icmp sgt i8 %109, -1
  br i1 %110, label %108, label %111, !llvm.loop !57

111:                                              ; preds = %108
  call fastcc void @upq_flush(ptr noundef nonnull %3) #14
  %112 = load i8, ptr %14, align 1, !tbaa !14
  %113 = load i8, ptr %15, align 1, !tbaa !19
  %114 = icmp ult i8 %112, %113
  br i1 %114, label %117, label %115

115:                                              ; preds = %111
  %116 = icmp ugt i8 %112, %113
  br i1 %116, label %117, label %120

117:                                              ; preds = %115, %111
  %118 = phi i8 [ 1, %111 ], [ -1, %115 ]
  %119 = add i8 %118, %112
  store i8 %119, ptr %14, align 1, !tbaa !14
  br label %120

120:                                              ; preds = %117, %115
  %121 = phi i8 [ %112, %115 ], [ %119, %117 ]
  %122 = and i8 %121, 15
  store volatile i8 %122, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !11
  store i8 1, ptr %16, align 1, !tbaa !20
  %123 = add nuw i8 %92, 1
  %124 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !50
  %125 = icmp ne i8 %124, -1
  %126 = icmp ult i8 %92, -57
  %127 = select i1 %125, i1 %126, i1 false
  br i1 %127, label %91, label %128, !llvm.loop !60

128:                                              ; preds = %120, %88
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !49
  %129 = load i8, ptr %13, align 1, !tbaa !22
  %130 = icmp eq i8 %129, 0
  br i1 %130, label %142, label %131

131:                                              ; preds = %128, %131
  %132 = phi i8 [ %139, %131 ], [ 0, %128 ]
  %133 = zext i8 %132 to i16
  %134 = getelementptr inbounds nuw [2 x i8], ptr %54, i16 %133
  %135 = load ptr, ptr %134, align 1, !tbaa !23
  %136 = load ptr, ptr %135, align 1, !tbaa !25
  %137 = getelementptr inbounds nuw i8, ptr %136, i16 2
  %138 = load ptr, ptr %137, align 1, !tbaa !54
  call void %138(ptr noundef nonnull %135, ptr noundef nonnull %3) #13, !inline_history !61
  %139 = add nuw i8 %132, 1
  %140 = load i8, ptr %13, align 1, !tbaa !22
  %141 = icmp ult i8 %139, %140
  br i1 %141, label %131, label %142, !llvm.loop !56

142:                                              ; preds = %131, %128
  %143 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !11
  br label %144

144:                                              ; preds = %144, %142
  %145 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !11
  %146 = icmp sgt i8 %145, -1
  br i1 %146, label %144, label %147, !llvm.loop !57

147:                                              ; preds = %144
  call fastcc void @upq_flush(ptr noundef nonnull %3) #14
  %148 = load i8, ptr %14, align 1, !tbaa !14
  %149 = load i8, ptr %15, align 1, !tbaa !19
  %150 = icmp ult i8 %148, %149
  br i1 %150, label %153, label %151

151:                                              ; preds = %147
  %152 = icmp ugt i8 %148, %149
  br i1 %152, label %153, label %156

153:                                              ; preds = %151, %147
  %154 = phi i8 [ 1, %147 ], [ -1, %151 ]
  %155 = add i8 %154, %148
  store i8 %155, ptr %14, align 1, !tbaa !14
  br label %156

156:                                              ; preds = %151, %153
  %157 = phi i8 [ %148, %151 ], [ %155, %153 ]
  %158 = and i8 %157, 15
  store volatile i8 %158, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !11
  store i8 1, ptr %16, align 1, !tbaa !20
  %159 = tail call fastcc i16 @newton_gate_crc() #14
  store volatile i16 %159, ptr @corpus_result, align 1, !tbaa !2
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !47
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !48
  br label %163

160:                                              ; preds = %192
  %161 = add nuw nsw i8 %164, 1
  %162 = icmp eq i8 %161, 90
  br i1 %162, label %197, label %163, !llvm.loop !62

163:                                              ; preds = %160, %156
  %164 = phi i8 [ 0, %156 ], [ %161, %160 ]
  %165 = load i8, ptr %13, align 1, !tbaa !22
  %166 = icmp eq i8 %165, 0
  br i1 %166, label %178, label %167

167:                                              ; preds = %163, %167
  %168 = phi i8 [ %175, %167 ], [ 0, %163 ]
  %169 = zext i8 %168 to i16
  %170 = getelementptr inbounds nuw [2 x i8], ptr %54, i16 %169
  %171 = load ptr, ptr %170, align 1, !tbaa !23
  %172 = load ptr, ptr %171, align 1, !tbaa !25
  %173 = getelementptr inbounds nuw i8, ptr %172, i16 2
  %174 = load ptr, ptr %173, align 1, !tbaa !54
  call void %174(ptr noundef nonnull %171, ptr noundef nonnull %3) #13, !inline_history !63
  %175 = add nuw i8 %168, 1
  %176 = load i8, ptr %13, align 1, !tbaa !22
  %177 = icmp ult i8 %175, %176
  br i1 %177, label %167, label %178, !llvm.loop !56

178:                                              ; preds = %167, %163
  %179 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !11
  br label %180

180:                                              ; preds = %180, %178
  %181 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !11
  %182 = icmp sgt i8 %181, -1
  br i1 %182, label %180, label %183, !llvm.loop !57

183:                                              ; preds = %180
  call fastcc void @upq_flush(ptr noundef nonnull %3) #14
  %184 = load i8, ptr %14, align 1, !tbaa !14
  %185 = load i8, ptr %15, align 1, !tbaa !19
  %186 = icmp ult i8 %184, %185
  br i1 %186, label %189, label %187

187:                                              ; preds = %183
  %188 = icmp ugt i8 %184, %185
  br i1 %188, label %189, label %192

189:                                              ; preds = %187, %183
  %190 = phi i8 [ 1, %183 ], [ -1, %187 ]
  %191 = add i8 %190, %184
  store i8 %191, ptr %14, align 1, !tbaa !14
  br label %192

192:                                              ; preds = %189, %187
  %193 = phi i8 [ %184, %187 ], [ %191, %189 ]
  %194 = and i8 %193, 15
  store volatile i8 %194, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !11
  store i8 1, ptr %16, align 1, !tbaa !20
  %195 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 19), align 1, !tbaa !64
  %196 = icmp sgt i16 %195, 3583
  br i1 %196, label %197, label %160

197:                                              ; preds = %192, %160
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !47
  store i8 0, ptr %15, align 1, !tbaa !19
  %198 = load i8, ptr %14, align 1, !tbaa !14
  %199 = icmp eq i8 %198, 0
  br i1 %199, label %233, label %200

200:                                              ; preds = %197, %228
  %201 = load i8, ptr %13, align 1, !tbaa !22
  %202 = icmp eq i8 %201, 0
  br i1 %202, label %214, label %203

203:                                              ; preds = %200, %203
  %204 = phi i8 [ %211, %203 ], [ 0, %200 ]
  %205 = zext i8 %204 to i16
  %206 = getelementptr inbounds nuw [2 x i8], ptr %54, i16 %205
  %207 = load ptr, ptr %206, align 1, !tbaa !23
  %208 = load ptr, ptr %207, align 1, !tbaa !25
  %209 = getelementptr inbounds nuw i8, ptr %208, i16 2
  %210 = load ptr, ptr %209, align 1, !tbaa !54
  call void %210(ptr noundef nonnull %207, ptr noundef nonnull %3) #13, !inline_history !65
  %211 = add nuw i8 %204, 1
  %212 = load i8, ptr %13, align 1, !tbaa !22
  %213 = icmp ult i8 %211, %212
  br i1 %213, label %203, label %214, !llvm.loop !56

214:                                              ; preds = %203, %200
  %215 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !11
  br label %216

216:                                              ; preds = %216, %214
  %217 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !11
  %218 = icmp sgt i8 %217, -1
  br i1 %218, label %216, label %219, !llvm.loop !57

219:                                              ; preds = %216
  call fastcc void @upq_flush(ptr noundef nonnull %3) #14
  %220 = load i8, ptr %14, align 1, !tbaa !14
  %221 = load i8, ptr %15, align 1, !tbaa !19
  %222 = icmp ult i8 %220, %221
  br i1 %222, label %225, label %223

223:                                              ; preds = %219
  %224 = icmp ugt i8 %220, %221
  br i1 %224, label %225, label %228

225:                                              ; preds = %223, %219
  %226 = phi i8 [ 1, %219 ], [ -1, %223 ]
  %227 = add i8 %226, %220
  store i8 %227, ptr %14, align 1, !tbaa !14
  br label %228

228:                                              ; preds = %225, %223
  %229 = phi i8 [ %220, %223 ], [ %227, %225 ]
  %230 = and i8 %229, 15
  store volatile i8 %230, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !11
  store i8 1, ptr %16, align 1, !tbaa !20
  %231 = load i8, ptr %14, align 1, !tbaa !14
  %232 = icmp eq i8 %231, 0
  br i1 %232, label %233, label %200, !llvm.loop !58

233:                                              ; preds = %228, %197
  %234 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !53
  %235 = load i8, ptr %33, align 1, !tbaa !29
  %236 = or i8 %235, %234
  %237 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !30
  %238 = xor i8 %237, -1
  %239 = and i8 %236, %238
  store i8 %239, ptr %33, align 1, !tbaa !29
  store volatile i8 %239, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !11
  store volatile i8 0, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !11
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !11
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !11
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !11
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !11
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !46
  %240 = load i8, ptr %12, align 1, !tbaa !66
  %241 = icmp ugt i8 %240, 15
  br i1 %241, label %253, label %242

242:                                              ; preds = %233
  %243 = zext nneg i8 %240 to i16
  %244 = add nuw nsw i8 %240, 1
  store i8 %244, ptr %12, align 1, !tbaa !66
  %245 = getelementptr inbounds nuw [11 x i8], ptr %3, i16 %243
  %246 = getelementptr inbounds nuw i8, ptr %245, i16 10
  store i8 1, ptr %246, align 1, !tbaa !67
  store i16 0, ptr %245, align 1, !tbaa !69
  %247 = getelementptr inbounds nuw i8, ptr %245, i16 9
  store i8 0, ptr %247, align 1, !tbaa !70
  %248 = getelementptr inbounds nuw i8, ptr %245, i16 7
  store i8 34, ptr %248, align 1, !tbaa !71
  %249 = getelementptr inbounds nuw i8, ptr %245, i16 8
  store i8 0, ptr %249, align 1, !tbaa !72
  %250 = getelementptr inbounds nuw i8, ptr %245, i16 2
  store i16 ptrtoint (ptr @title_end._title_bg_black to i16), ptr %250, align 1, !tbaa !73
  %251 = getelementptr inbounds nuw i8, ptr %245, i16 6
  store i8 0, ptr %251, align 1, !tbaa !74
  %252 = getelementptr inbounds nuw i8, ptr %245, i16 4
  store i16 2, ptr %252, align 1, !tbaa !75
  br label %253

253:                                              ; preds = %233, %242
  store i8 15, ptr %15, align 1, !tbaa !19
  br label %254

254:                                              ; preds = %285, %253
  %255 = phi i16 [ 0, %253 ], [ %335, %285 ]
  %256 = load i32, ptr getelementptr inbounds nuw (i8, ptr @main.layer, i16 1795), align 1
  br label %288

257:                                              ; preds = %333
  %258 = load i8, ptr %13, align 1, !tbaa !22
  %259 = icmp eq i8 %258, 0
  br i1 %259, label %271, label %260

260:                                              ; preds = %257, %260
  %261 = phi i8 [ %268, %260 ], [ 0, %257 ]
  %262 = zext i8 %261 to i16
  %263 = getelementptr inbounds nuw [2 x i8], ptr %54, i16 %262
  %264 = load ptr, ptr %263, align 1, !tbaa !23
  %265 = load ptr, ptr %264, align 1, !tbaa !25
  %266 = getelementptr inbounds nuw i8, ptr %265, i16 2
  %267 = load ptr, ptr %266, align 1, !tbaa !54
  call void %267(ptr noundef nonnull %264, ptr noundef nonnull %3) #13, !inline_history !61
  %268 = add nuw i8 %261, 1
  %269 = load i8, ptr %13, align 1, !tbaa !22
  %270 = icmp ult i8 %268, %269
  br i1 %270, label %260, label %271, !llvm.loop !56

271:                                              ; preds = %260, %257
  %272 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !11
  br label %273

273:                                              ; preds = %273, %271
  %274 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !11
  %275 = icmp sgt i8 %274, -1
  br i1 %275, label %273, label %276, !llvm.loop !57

276:                                              ; preds = %273
  call fastcc void @upq_flush(ptr noundef nonnull %3) #14
  %277 = load i8, ptr %14, align 1, !tbaa !14
  %278 = load i8, ptr %15, align 1, !tbaa !19
  %279 = icmp ult i8 %277, %278
  br i1 %279, label %282, label %280

280:                                              ; preds = %276
  %281 = icmp ugt i8 %277, %278
  br i1 %281, label %282, label %285

282:                                              ; preds = %280, %276
  %283 = phi i8 [ 1, %276 ], [ -1, %280 ]
  %284 = add i8 %283, %277
  store i8 %284, ptr %14, align 1, !tbaa !14
  br label %285

285:                                              ; preds = %280, %282
  %286 = phi i8 [ %277, %280 ], [ %284, %282 ]
  %287 = and i8 %286, 15
  store volatile i8 %287, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !11
  store i8 1, ptr %16, align 1, !tbaa !20
  br label %254

288:                                              ; preds = %254, %333
  %289 = phi i16 [ %255, %254 ], [ %335, %333 ]
  %290 = phi i8 [ 0, %254 ], [ %336, %333 ]
  %291 = phi i32 [ %256, %254 ], [ %334, %333 ]
  %292 = icmp ult i16 %289, 896
  br i1 %292, label %293, label %333

293:                                              ; preds = %288
  %294 = and i16 %289, 31
  %295 = lshr i16 %289, 5
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #12
  %296 = shl nuw nsw i16 %294, 5
  %297 = add nsw i16 %296, -494
  store i16 %297, ptr %1, align 1, !tbaa !2
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #12
  %298 = and i16 %289, 992
  %299 = sub nsw i16 430, %298
  store i16 %299, ptr %2, align 1, !tbaa !2
  %300 = call fastcc signext i8 @newton_nearest_root(i16 noundef %297, i16 noundef %299) #14
  %301 = icmp eq i8 %300, 0
  br i1 %301, label %305, label %315

302:                                              ; preds = %305
  %303 = add nuw nsw i8 %306, 1
  %304 = icmp eq i8 %303, 20
  br i1 %304, label %322, label %305, !llvm.loop !76

305:                                              ; preds = %293, %302
  %306 = phi i8 [ %303, %302 ], [ 0, %293 ]
  call fastcc void @newton_step(ptr noundef %1, ptr noundef %2) #14
  %307 = load i16, ptr %1, align 1, !tbaa !2
  %308 = load i16, ptr %2, align 1, !tbaa !2
  %309 = call fastcc signext i8 @newton_nearest_root(i16 noundef %307, i16 noundef %308) #14
  %310 = icmp eq i8 %309, 0
  br i1 %310, label %302, label %311, !llvm.loop !76

311:                                              ; preds = %305
  %312 = icmp samesign ugt i8 %306, 12
  br i1 %312, label %315, label %313

313:                                              ; preds = %311
  %314 = sub nuw nsw i8 14, %306
  br label %315

315:                                              ; preds = %313, %311, %293
  %316 = phi i8 [ %309, %311 ], [ %309, %313 ], [ %300, %293 ]
  %317 = phi i8 [ 1, %311 ], [ %314, %313 ], [ 15, %293 ]
  %318 = zext nneg i8 %316 to i16
  %319 = shl nuw nsw i16 %318, 10
  %320 = zext nneg i8 %317 to i16
  %321 = or disjoint i16 %319, %320
  br label %322

322:                                              ; preds = %302, %315
  %323 = phi i16 [ %321, %315 ], [ 0, %302 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #12
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #12
  %324 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.layer, i16 3), i16 %289
  store i16 %323, ptr %324, align 1, !tbaa !2
  %325 = icmp eq i16 %294, 31
  br i1 %325, label %326, label %330

326:                                              ; preds = %322
  %327 = zext nneg i16 %295 to i32
  %328 = shl nuw nsw i32 1, %327
  %329 = or i32 %291, %328
  store i32 %329, ptr getelementptr inbounds nuw (i8, ptr @main.layer, i16 1795), align 1, !tbaa !77
  br label %330

330:                                              ; preds = %326, %322
  %331 = phi i32 [ %329, %326 ], [ %291, %322 ]
  %332 = add nuw nsw i16 %289, 1
  br label %333

333:                                              ; preds = %288, %330
  %334 = phi i32 [ %331, %330 ], [ %291, %288 ]
  %335 = phi i16 [ %332, %330 ], [ %289, %288 ]
  %336 = add nuw nsw i8 %290, 1
  %337 = icmp eq i8 %336, 4
  br i1 %337, label %257, label %288, !llvm.loop !78
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: nofree noinline norecurse nosync nounwind optsize memory(none)
define internal fastcc i16 @newton_gate_crc() unnamed_addr #2 {
  %1 = alloca i16, align 1
  %2 = alloca i16, align 1
  br label %3

3:                                                ; preds = %0, %8
  %4 = phi i16 [ 0, %0 ], [ %42, %8 ]
  %5 = phi i8 [ 0, %0 ], [ %10, %8 ]
  %6 = phi i16 [ 307, %0 ], [ %9, %8 ]
  br label %12

7:                                                ; preds = %8
  ret i16 %42

8:                                                ; preds = %36
  %9 = add nsw i16 %6, -88
  %10 = add nuw nsw i8 %5, 1
  %11 = icmp eq i8 %10, 8
  br i1 %11, label %7, label %3, !llvm.loop !79

12:                                               ; preds = %3, %36
  %13 = phi i16 [ %4, %3 ], [ %42, %36 ]
  %14 = phi i8 [ 0, %3 ], [ %44, %36 ]
  %15 = phi i16 [ -307, %3 ], [ %43, %36 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #12
  store i16 %15, ptr %1, align 1, !tbaa !2
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #12
  store i16 %6, ptr %2, align 1, !tbaa !2
  %16 = tail call fastcc signext i8 @newton_nearest_root(i16 noundef %15, i16 noundef %6) #14
  %17 = icmp eq i8 %16, 0
  br i1 %17, label %22, label %18

18:                                               ; preds = %12
  %19 = shl nuw nsw i8 %16, 4
  br label %32

20:                                               ; preds = %22
  %21 = icmp eq i8 %24, 20
  br i1 %21, label %36, label %22, !llvm.loop !80

22:                                               ; preds = %12, %20
  %23 = phi i8 [ %24, %20 ], [ 0, %12 ]
  call fastcc void @newton_step(ptr noundef %1, ptr noundef %2) #14
  %24 = add nuw nsw i8 %23, 1
  %25 = load i16, ptr %1, align 1, !tbaa !2
  %26 = load i16, ptr %2, align 1, !tbaa !2
  %27 = tail call fastcc signext i8 @newton_nearest_root(i16 noundef %25, i16 noundef %26) #14
  %28 = icmp eq i8 %27, 0
  br i1 %28, label %20, label %29, !llvm.loop !80

29:                                               ; preds = %22
  %30 = shl nuw nsw i8 %27, 4
  %31 = icmp samesign ult i8 %23, 14
  br i1 %31, label %32, label %36

32:                                               ; preds = %18, %29
  %33 = phi i8 [ %19, %18 ], [ %30, %29 ]
  %34 = phi i8 [ 0, %18 ], [ %24, %29 ]
  %35 = zext nneg i8 %34 to i16
  br label %36

36:                                               ; preds = %20, %29, %32
  %37 = phi i8 [ %33, %32 ], [ %30, %29 ], [ 0, %20 ]
  %38 = phi i16 [ %35, %32 ], [ 15, %29 ], [ 15, %20 ]
  %39 = zext nneg i8 %37 to i16
  %40 = add nuw nsw i16 %38, %39
  %41 = tail call i16 @llvm.fshl.i16(i16 %13, i16 %13, i16 1)
  %42 = xor i16 %40, %41
  %43 = add nsw i16 %15, 88
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #12
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #12
  %44 = add nuw nsw i8 %14, 1
  %45 = icmp eq i8 %44, 8
  br i1 %45, label %8, label %12, !llvm.loop !81
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_newton_reserve(ptr noundef writeonly captures(none) %0, ptr readnone captures(none) %1) #3 {
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !11
  store volatile i16 0, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %4

3:                                                ; preds = %25
  store volatile i8 64, ptr inttoptr (i16 8455 to ptr), align 1, !tbaa !11
  store volatile i8 0, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !11
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !11
  store volatile i16 16384, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %35

4:                                                ; preds = %2, %25
  %5 = phi i8 [ 0, %2 ], [ %26, %25 ]
  %6 = zext nneg i8 %5 to i16
  %7 = and i16 %6, 2
  %8 = icmp eq i16 %7, 0
  %9 = select i1 %8, i16 0, i16 -256
  %10 = and i16 %6, 1
  %11 = icmp eq i16 %10, 0
  %12 = select i1 %11, i16 0, i16 255
  %13 = or disjoint i16 %9, %12
  br label %14

14:                                               ; preds = %4, %14
  %15 = phi i8 [ 0, %4 ], [ %16, %14 ]
  store volatile i16 %13, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %16 = add nuw nsw i8 %15, 1
  %17 = icmp eq i8 %16, 8
  br i1 %17, label %18, label %14, !llvm.loop !82

18:                                               ; preds = %14
  %19 = icmp samesign ult i8 %5, 8
  %20 = select i1 %19, i16 0, i16 -256
  %21 = and i16 %6, 4
  %22 = icmp eq i16 %21, 0
  %23 = select i1 %22, i16 0, i16 255
  %24 = or disjoint i16 %23, %20
  br label %28

25:                                               ; preds = %28
  %26 = add nuw nsw i8 %5, 1
  %27 = icmp eq i8 %26, 16
  br i1 %27, label %3, label %4, !llvm.loop !83

28:                                               ; preds = %18, %28
  %29 = phi i8 [ %30, %28 ], [ 0, %18 ]
  store volatile i16 %24, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %30 = add nuw nsw i8 %29, 1
  %31 = icmp eq i8 %30, 8
  br i1 %31, label %25, label %28, !llvm.loop !84

32:                                               ; preds = %35
  %33 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %34 = getelementptr inbounds nuw i8, ptr %0, i16 2
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(1797) %33, i8 0, i64 1797, i1 false)
  store i8 1, ptr %34, align 1, !tbaa !85
  ret void

35:                                               ; preds = %3, %35
  %36 = phi i16 [ 0, %3 ], [ %37, %35 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %37 = add nuw nsw i16 %36, 1
  %38 = icmp eq i16 %37, 1024
  br i1 %38, label %32, label %35, !llvm.loop !86
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(argmem: readwrite)
define internal void @_newton_emit(ptr noundef %0, ptr noundef captures(none) %1) #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 1799
  %4 = load i8, ptr %3, align 1, !tbaa !87
  %5 = icmp eq i8 %4, 0
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %7 = load i8, ptr %6, align 1, !tbaa !66
  br i1 %5, label %8, label %23

8:                                                ; preds = %2
  %9 = icmp ugt i8 %7, 15
  br i1 %9, label %21, label %10

10:                                               ; preds = %8
  %11 = zext nneg i8 %7 to i16
  %12 = add nuw nsw i8 %7, 1
  store i8 %12, ptr %6, align 1, !tbaa !66
  %13 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %11
  %14 = getelementptr inbounds nuw i8, ptr %13, i16 10
  store i8 1, ptr %14, align 1, !tbaa !67
  store i16 0, ptr %13, align 1, !tbaa !69
  %15 = getelementptr inbounds nuw i8, ptr %13, i16 9
  store i8 0, ptr %15, align 1, !tbaa !70
  %16 = getelementptr inbounds nuw i8, ptr %13, i16 7
  store i8 34, ptr %16, align 1, !tbaa !71
  %17 = getelementptr inbounds nuw i8, ptr %13, i16 8
  store i8 0, ptr %17, align 1, !tbaa !72
  %18 = getelementptr inbounds nuw i8, ptr %13, i16 2
  store i16 ptrtoint (ptr @newton_pal to i16), ptr %18, align 1, !tbaa !73
  %19 = getelementptr inbounds nuw i8, ptr %13, i16 6
  store i8 0, ptr %19, align 1, !tbaa !74
  %20 = getelementptr inbounds nuw i8, ptr %13, i16 4
  store i16 128, ptr %20, align 1, !tbaa !75
  br label %21

21:                                               ; preds = %8, %10
  %22 = phi i8 [ %7, %8 ], [ %12, %10 ]
  store i8 1, ptr %3, align 1, !tbaa !87
  br label %23

23:                                               ; preds = %2, %21
  %24 = phi i8 [ %22, %21 ], [ %7, %2 ]
  %25 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %26 = getelementptr inbounds nuw i8, ptr %0, i16 1795
  %27 = getelementptr inbounds nuw i8, ptr %0, i16 3
  br label %28

28:                                               ; preds = %23, %57
  %29 = phi i8 [ %24, %23 ], [ %58, %57 ]
  %30 = phi i8 [ 0, %23 ], [ %59, %57 ]
  %31 = zext nneg i8 %30 to i16
  %32 = icmp ult i8 %29, 16
  br i1 %32, label %34, label %33

33:                                               ; preds = %57, %28
  ret void

34:                                               ; preds = %28
  %35 = load i32, ptr %26, align 1, !tbaa !77
  %36 = zext nneg i8 %30 to i32
  %37 = shl nuw nsw i32 1, %36
  %38 = and i32 %35, %37
  %39 = icmp eq i32 %38, 0
  br i1 %39, label %57, label %40

40:                                               ; preds = %34
  %41 = shl nuw nsw i16 %31, 5
  %42 = or disjoint i16 %41, 16384
  %43 = getelementptr inbounds nuw [2 x i8], ptr %27, i16 %41
  %44 = zext nneg i8 %29 to i16
  %45 = add nuw nsw i8 %29, 1
  store i8 %45, ptr %25, align 1, !tbaa !66
  %46 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %44
  %47 = getelementptr inbounds nuw i8, ptr %46, i16 10
  store i8 0, ptr %47, align 1, !tbaa !67
  store i16 %42, ptr %46, align 1, !tbaa !69
  %48 = getelementptr inbounds nuw i8, ptr %46, i16 9
  store i8 -128, ptr %48, align 1, !tbaa !70
  %49 = getelementptr inbounds nuw i8, ptr %46, i16 7
  store i8 24, ptr %49, align 1, !tbaa !71
  %50 = getelementptr inbounds nuw i8, ptr %46, i16 8
  store i8 1, ptr %50, align 1, !tbaa !72
  %51 = ptrtoint ptr %43 to i16
  %52 = getelementptr inbounds nuw i8, ptr %46, i16 2
  store i16 %51, ptr %52, align 1, !tbaa !73
  %53 = getelementptr inbounds nuw i8, ptr %46, i16 6
  store i8 0, ptr %53, align 1, !tbaa !74
  %54 = getelementptr inbounds nuw i8, ptr %46, i16 4
  store i16 64, ptr %54, align 1, !tbaa !75
  %55 = xor i32 %37, -1
  %56 = and i32 %35, %55
  store i32 %56, ptr %26, align 1, !tbaa !77
  br label %57

57:                                               ; preds = %34, %40
  %58 = phi i8 [ %29, %34 ], [ %45, %40 ]
  %59 = add nuw nsw i8 %30, 1
  %60 = icmp eq i8 %59, 28
  br i1 %60, label %33, label %28, !llvm.loop !88
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal void @_title_reserve(ptr noundef %0, ptr readnone captures(none) %1) #3 {
  store volatile i8 80, ptr inttoptr (i16 8456 to ptr), align 8, !tbaa !11
  store volatile i8 16, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !11
  store volatile i8 112, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !11
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !11
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !11
  store volatile i8 -1, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !11
  store volatile i8 127, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !11
  store volatile i8 -124, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !11
  store volatile i8 16, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !11
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !11
  store volatile i16 4096, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %3

3:                                                ; preds = %2, %16
  %4 = phi ptr [ @FONT8, %2 ], [ %18, %16 ]
  %5 = phi i16 [ 0, %2 ], [ %17, %16 ]
  br label %7

6:                                                ; preds = %16
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !11
  store volatile i16 5120, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %24

7:                                                ; preds = %3, %7
  %8 = phi i8 [ 0, %3 ], [ %15, %7 ]
  %9 = phi i8 [ 0, %3 ], [ %13, %7 ]
  %10 = zext nneg i8 %8 to i16
  %11 = getelementptr i8, ptr %4, i16 %10
  %12 = load i16, ptr %11, align 1, !tbaa !2
  store volatile i16 %12, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %13 = add nuw nsw i8 %9, 1
  %14 = icmp eq i8 %13, 8
  %15 = add nuw nsw i8 %8, 2
  br i1 %14, label %20, label %7, !llvm.loop !89

16:                                               ; preds = %20
  %17 = add nuw nsw i16 %5, 1
  %18 = getelementptr i8, ptr %4, i16 16
  %19 = icmp eq i16 %17, 64
  br i1 %19, label %6, label %3, !llvm.loop !90

20:                                               ; preds = %7, %20
  %21 = phi i8 [ %22, %20 ], [ 0, %7 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %22 = add nuw nsw i8 %21, 1
  %23 = icmp eq i8 %22, 8
  br i1 %23, label %16, label %20, !llvm.loop !91

24:                                               ; preds = %6, %33
  %25 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 16), %6 ], [ %36, %33 ]
  %26 = phi ptr [ @FONT16, %6 ], [ %35, %33 ]
  %27 = phi i16 [ 0, %6 ], [ %34, %33 ]
  br label %29

28:                                               ; preds = %33
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !11
  store volatile i16 20480, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %66

29:                                               ; preds = %24, %47
  %30 = phi i8 [ 0, %24 ], [ %52, %47 ]
  %31 = phi ptr [ %26, %24 ], [ %50, %47 ]
  %32 = phi i8 [ 0, %24 ], [ %48, %47 ]
  br label %38

33:                                               ; preds = %47
  %34 = add nuw nsw i16 %27, 1
  %35 = getelementptr i8, ptr %26, i16 64
  %36 = getelementptr i8, ptr %25, i16 64
  %37 = icmp eq i16 %34, 64
  br i1 %37, label %28, label %24, !llvm.loop !92

38:                                               ; preds = %29, %38
  %39 = phi i8 [ 0, %29 ], [ %46, %38 ]
  %40 = phi i8 [ 0, %29 ], [ %44, %38 ]
  %41 = zext nneg i8 %39 to i16
  %42 = getelementptr i8, ptr %31, i16 %41
  %43 = load i16, ptr %42, align 1, !tbaa !2
  store volatile i16 %43, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %44 = add nuw nsw i8 %40, 1
  %45 = icmp eq i8 %44, 8
  %46 = add nuw nsw i8 %39, 2
  br i1 %45, label %53, label %38, !llvm.loop !93

47:                                               ; preds = %53
  %48 = add nuw nsw i8 %32, 1
  %49 = zext nneg i8 %30 to i16
  %50 = getelementptr i8, ptr %25, i16 %49
  %51 = icmp eq i8 %48, 4
  %52 = add nuw nsw i8 %30, 16
  br i1 %51, label %33, label %29, !llvm.loop !94

53:                                               ; preds = %38, %53
  %54 = phi i8 [ %55, %53 ], [ 0, %38 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %55 = add nuw nsw i8 %54, 1
  %56 = icmp eq i8 %55, 8
  br i1 %56, label %47, label %53, !llvm.loop !95

57:                                               ; preds = %66
  %58 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %59 = load ptr, ptr %58, align 1, !tbaa !36
  %60 = icmp eq ptr %59, null
  br i1 %60, label %79, label %61

61:                                               ; preds = %57
  %62 = load i8, ptr %59, align 1, !tbaa !11
  %63 = icmp eq i8 %62, 0
  br i1 %63, label %79, label %64

64:                                               ; preds = %61
  %65 = getelementptr i8, ptr %59, i16 1
  br label %70

66:                                               ; preds = %28, %66
  %67 = phi i16 [ 0, %28 ], [ %68, %66 ]
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %68 = add nuw nsw i16 %67, 1
  %69 = icmp eq i16 %68, 1024
  br i1 %69, label %57, label %66, !llvm.loop !96

70:                                               ; preds = %64, %70
  %71 = phi i8 [ %72, %70 ], [ 0, %64 ]
  %72 = add nuw nsw i8 %71, 1
  %73 = zext nneg i8 %71 to i16
  %74 = getelementptr i8, ptr %65, i16 %73
  %75 = load i8, ptr %74, align 1, !tbaa !11
  %76 = icmp ne i8 %75, 0
  %77 = icmp samesign ult i8 %71, 31
  %78 = select i1 %76, i1 %77, i1 false
  br i1 %78, label %70, label %79, !llvm.loop !97

79:                                               ; preds = %70, %61, %57
  %80 = phi i8 [ 0, %57 ], [ 0, %61 ], [ %72, %70 ]
  %81 = zext nneg i8 %80 to i16
  %82 = sub nuw nsw i16 32, %81
  %83 = lshr i16 %82, 1
  %84 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %85 = load i16, ptr %84, align 1, !tbaa !42
  %86 = shl i16 %85, 2
  %87 = and i16 %86, -32
  %88 = add i16 %87, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !11
  store volatile i16 %88, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %89 = trunc nuw nsw i16 %83 to i8
  %90 = add nuw nsw i8 %80, %89
  %91 = sub nsw i16 0, %83
  %92 = getelementptr i8, ptr %59, i16 %91
  br label %105

93:                                               ; preds = %128
  %94 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %95 = load ptr, ptr %94, align 1, !tbaa !38
  %96 = getelementptr inbounds nuw i8, ptr %0, i16 11
  %97 = load i8, ptr %96, align 1, !tbaa !39
  %98 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %99 = load i16, ptr %98, align 1, !tbaa !43
  %100 = lshr i16 %99, 3
  %101 = trunc i16 %100 to i8
  tail call fastcc void @_title_write16(ptr noundef %95, i8 noundef zeroext %97, i8 noundef zeroext %101) #14
  %102 = getelementptr inbounds nuw i8, ptr %0, i16 9
  %103 = load ptr, ptr %102, align 1, !tbaa !40
  %104 = icmp eq ptr %103, null
  br i1 %104, label %139, label %132

105:                                              ; preds = %79, %128
  %106 = phi i8 [ 0, %79 ], [ %130, %128 ]
  %107 = zext nneg i8 %106 to i16
  br i1 %60, label %128, label %108

108:                                              ; preds = %105
  %109 = icmp samesign ugt i16 %83, %107
  br i1 %109, label %128, label %110

110:                                              ; preds = %108
  %111 = icmp ult i8 %106, %90
  br i1 %111, label %112, label %128

112:                                              ; preds = %110
  %113 = getelementptr i8, ptr %92, i16 %107
  %114 = load i8, ptr %113, align 1, !tbaa !11
  %115 = icmp ugt i8 %114, 96
  br i1 %115, label %116, label %120

116:                                              ; preds = %112
  %117 = icmp ult i8 %114, 123
  br i1 %117, label %118, label %128

118:                                              ; preds = %116
  %119 = add nsw i8 %114, -32
  br label %124

120:                                              ; preds = %112
  %121 = icmp samesign ugt i8 %114, 31
  br i1 %121, label %122, label %128

122:                                              ; preds = %120
  %123 = icmp eq i8 %114, 96
  br i1 %123, label %128, label %124

124:                                              ; preds = %122, %118
  %125 = phi i8 [ %119, %118 ], [ %114, %122 ]
  %126 = zext nneg i8 %125 to i16
  %127 = add nuw nsw i16 %126, 7136
  br label %128

128:                                              ; preds = %124, %122, %120, %116, %105, %108, %110
  %129 = phi i16 [ 7168, %105 ], [ 7168, %110 ], [ 7168, %108 ], [ %127, %124 ], [ 7168, %122 ], [ 7168, %120 ], [ 7168, %116 ]
  store volatile i16 %129, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %130 = add nuw nsw i8 %106, 1
  %131 = icmp eq i8 %130, 32
  br i1 %131, label %93, label %105, !llvm.loop !98

132:                                              ; preds = %93
  %133 = getelementptr inbounds nuw i8, ptr %0, i16 12
  %134 = load i8, ptr %133, align 1, !tbaa !41
  %135 = load i16, ptr %98, align 1, !tbaa !43
  %136 = lshr i16 %135, 3
  %137 = trunc i16 %136 to i8
  %138 = add i8 %137, 2
  tail call fastcc void @_title_write16(ptr noundef nonnull %103, i8 noundef zeroext %134, i8 noundef zeroext %138) #14
  br label %139

139:                                              ; preds = %132, %93
  %140 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 -128, ptr %140, align 1, !tbaa !64
  %141 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 3584, ptr %141, align 1, !tbaa !99
  %142 = getelementptr inbounds nuw i8, ptr %0, i16 23
  store i16 0, ptr %142, align 1, !tbaa !100
  %143 = load ptr, ptr %58, align 1, !tbaa !36
  %144 = icmp eq ptr %143, null
  br i1 %144, label %167, label %145

145:                                              ; preds = %139
  %146 = load i8, ptr %143, align 1, !tbaa !11
  %147 = icmp eq i8 %146, 0
  br i1 %147, label %150, label %148

148:                                              ; preds = %145
  %149 = getelementptr i8, ptr %143, i16 1
  br label %158

150:                                              ; preds = %158, %145
  %151 = phi i8 [ 0, %145 ], [ %160, %158 ]
  %152 = zext nneg i8 %151 to i16
  %153 = shl nuw nsw i16 %152, 2
  %154 = sub nuw nsw i16 128, %153
  %155 = and i16 %154, 248
  %156 = add nsw i16 %153, -128
  %157 = add nsw i16 %156, %155
  br label %167

158:                                              ; preds = %158, %148
  %159 = phi i8 [ %160, %158 ], [ 0, %148 ]
  %160 = add nuw nsw i8 %159, 1
  %161 = zext nneg i8 %159 to i16
  %162 = getelementptr i8, ptr %149, i16 %161
  %163 = load i8, ptr %162, align 1, !tbaa !11
  %164 = icmp ne i8 %163, 0
  %165 = icmp samesign ult i8 %159, 31
  %166 = select i1 %164, i1 %165, i1 false
  br i1 %166, label %158, label %150, !llvm.loop !101

167:                                              ; preds = %139, %150
  %168 = phi i16 [ %157, %150 ], [ 0, %139 ]
  %169 = getelementptr inbounds nuw i8, ptr %0, i16 26
  store i16 %168, ptr %169, align 1, !tbaa !102
  store volatile i8 -112, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !11
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !11
  %170 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %171 = getelementptr inbounds nuw i8, ptr %0, i16 89
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef -8, i16 noundef 224, ptr noundef nonnull %170, ptr noundef nonnull %171) #14
  %172 = getelementptr inbounds nuw i8, ptr %0, i16 88
  store i8 0, ptr %172, align 1, !tbaa !103
  store volatile i8 2, ptr inttoptr (i16 17200 to ptr), align 16, !tbaa !11
  store volatile i8 16, ptr inttoptr (i16 17201 to ptr), align 1, !tbaa !11
  %173 = ptrtoint ptr %170 to i16
  %174 = trunc i16 %173 to i8
  store volatile i8 %174, ptr inttoptr (i16 17202 to ptr), align 2, !tbaa !11
  %175 = lshr i16 %173, 8
  %176 = trunc nuw i16 %175 to i8
  store volatile i8 %176, ptr inttoptr (i16 17203 to ptr), align 1, !tbaa !11
  store volatile i8 0, ptr inttoptr (i16 17204 to ptr), align 4, !tbaa !11
  %177 = getelementptr inbounds nuw i8, ptr %0, i16 139
  store i8 0, ptr %177, align 1, !tbaa !103
  store volatile i8 2, ptr inttoptr (i16 17216 to ptr), align 64, !tbaa !11
  store volatile i8 15, ptr inttoptr (i16 17217 to ptr), align 1, !tbaa !11
  %178 = ptrtoint ptr %171 to i16
  %179 = trunc i16 %178 to i8
  store volatile i8 %179, ptr inttoptr (i16 17218 to ptr), align 2, !tbaa !11
  %180 = lshr i16 %178, 8
  %181 = trunc nuw i16 %180 to i8
  store volatile i8 %181, ptr inttoptr (i16 17219 to ptr), align 1, !tbaa !11
  store volatile i8 0, ptr inttoptr (i16 17220 to ptr), align 4, !tbaa !11
  %182 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 2, ptr %182, align 1, !tbaa !35
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal void @_title_emit(ptr noundef %0, ptr noundef captures(none) %1) #5 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 29
  %4 = load i8, ptr %3, align 1, !tbaa !46
  %5 = icmp eq i8 %4, 0
  br i1 %5, label %188, label %6

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 30
  %8 = load i8, ptr %7, align 1, !tbaa !49
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %39, label %10

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 25
  %12 = load i8, ptr %11, align 1, !tbaa !50
  %13 = icmp ugt i8 %12, -6
  br i1 %13, label %16, label %14

14:                                               ; preds = %10
  %15 = add nuw i8 %12, 4
  br label %16

16:                                               ; preds = %10, %14
  %17 = phi i8 [ %15, %14 ], [ -1, %10 ]
  store i8 %17, ptr %11, align 1, !tbaa !50
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %19 = load i16, ptr %18, align 1, !tbaa !42
  %20 = xor i8 %17, -1
  %21 = zext i8 %20 to i16
  %22 = mul nuw i16 %21, %21
  %23 = lshr i16 %22, 8
  %24 = sub nuw nsw i16 256, %23
  %25 = add nsw i16 %19, 8
  %26 = mul nsw i16 %24, %25
  %27 = ashr i16 %26, 4
  %28 = and i16 %27, -16
  %29 = add nsw i16 %28, -128
  %30 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 %29, ptr %30, align 1, !tbaa !64
  %31 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %32 = load i16, ptr %31, align 1, !tbaa !43
  %33 = add nsw i16 %32, -224
  %34 = mul nsw i16 %33, %24
  %35 = ashr i16 %34, 4
  %36 = and i16 %35, -16
  %37 = add nsw i16 %36, 3584
  %38 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 %37, ptr %38, align 1, !tbaa !99
  br label %64

39:                                               ; preds = %6
  %40 = getelementptr inbounds nuw i8, ptr %0, i16 31
  %41 = load i8, ptr %40, align 1, !tbaa !47
  %42 = icmp eq i8 %41, 0
  br i1 %42, label %43, label %48

43:                                               ; preds = %39
  %44 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %45 = load i16, ptr %44, align 1, !tbaa !64
  %46 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %47 = load i16, ptr %46, align 1, !tbaa !99
  br label %64

48:                                               ; preds = %39
  %49 = getelementptr inbounds nuw i8, ptr %0, i16 23
  %50 = load i16, ptr %49, align 1, !tbaa !100
  %51 = add nsw i16 %50, 2
  store i16 %51, ptr %49, align 1, !tbaa !100
  %52 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %53 = load i16, ptr %52, align 1, !tbaa !64
  %54 = add nsw i16 %53, %51
  store i16 %54, ptr %52, align 1, !tbaa !64
  %55 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %56 = load i16, ptr %55, align 1, !tbaa !99
  %57 = add nsw i16 %56, %51
  store i16 %57, ptr %55, align 1, !tbaa !99
  %58 = icmp sgt i16 %54, 4480
  br i1 %58, label %59, label %60

59:                                               ; preds = %48
  store i16 4480, ptr %52, align 1, !tbaa !64
  br label %60

60:                                               ; preds = %59, %48
  %61 = phi i16 [ 4480, %59 ], [ %54, %48 ]
  %62 = icmp sgt i16 %57, 4736
  br i1 %62, label %63, label %64

63:                                               ; preds = %60
  store i16 4736, ptr %55, align 1, !tbaa !99
  br label %64

64:                                               ; preds = %43, %63, %60, %16
  %65 = phi i16 [ %47, %43 ], [ 4736, %63 ], [ %57, %60 ], [ %37, %16 ]
  %66 = phi i16 [ %45, %43 ], [ %61, %63 ], [ %61, %60 ], [ %29, %16 ]
  %67 = ashr i16 %66, 4
  %68 = ashr i16 %65, 4
  %69 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %70 = getelementptr inbounds nuw i8, ptr %0, i16 88
  %71 = load i8, ptr %70, align 1, !tbaa !103
  %72 = xor i8 %71, 1
  %73 = zext i8 %72 to i16
  %74 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %73
  %75 = getelementptr inbounds nuw i8, ptr %0, i16 89
  %76 = getelementptr inbounds nuw i8, ptr %0, i16 139
  %77 = load i8, ptr %76, align 1, !tbaa !103
  %78 = xor i8 %77, 1
  %79 = zext i8 %78 to i16
  %80 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %79
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef %67, i16 noundef %68, ptr noundef nonnull %74, ptr noundef nonnull %80) #14
  %81 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %82 = load i8, ptr %81, align 1, !tbaa !66
  %83 = icmp ugt i8 %82, 15
  br i1 %83, label %109, label %84

84:                                               ; preds = %64
  %85 = load i8, ptr %70, align 1, !tbaa !103
  %86 = xor i8 %85, 1
  %87 = zext i8 %86 to i16
  %88 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %87
  %89 = ptrtoint ptr %88 to i16
  %90 = zext nneg i8 %82 to i16
  %91 = add nuw nsw i8 %82, 1
  store i8 %91, ptr %81, align 1, !tbaa !66
  %92 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %90
  %93 = getelementptr inbounds nuw i8, ptr %92, i16 10
  store i8 4, ptr %93, align 1, !tbaa !67
  store i16 17202, ptr %92, align 1, !tbaa !69
  %94 = getelementptr inbounds nuw i8, ptr %92, i16 2
  store i16 %89, ptr %94, align 1, !tbaa !73
  %95 = getelementptr inbounds nuw i8, ptr %92, i16 4
  store i16 0, ptr %95, align 1, !tbaa !75
  store i8 %86, ptr %70, align 1, !tbaa !103
  %96 = icmp eq i8 %82, 15
  br i1 %96, label %109, label %97

97:                                               ; preds = %84
  %98 = load i8, ptr %76, align 1, !tbaa !103
  %99 = xor i8 %98, 1
  %100 = zext i8 %99 to i16
  %101 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %100
  %102 = ptrtoint ptr %101 to i16
  %103 = zext nneg i8 %91 to i16
  %104 = add nuw nsw i8 %82, 2
  store i8 %104, ptr %81, align 1, !tbaa !66
  %105 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %103
  %106 = getelementptr inbounds nuw i8, ptr %105, i16 10
  store i8 4, ptr %106, align 1, !tbaa !67
  store i16 17218, ptr %105, align 1, !tbaa !69
  %107 = getelementptr inbounds nuw i8, ptr %105, i16 2
  store i16 %102, ptr %107, align 1, !tbaa !73
  %108 = getelementptr inbounds nuw i8, ptr %105, i16 4
  store i16 0, ptr %108, align 1, !tbaa !75
  store i8 %99, ptr %76, align 1, !tbaa !103
  br label %109

109:                                              ; preds = %64, %84, %97
  %110 = phi i8 [ %82, %64 ], [ 16, %84 ], [ %104, %97 ]
  %111 = getelementptr inbounds nuw i8, ptr %0, i16 28
  %112 = load i8, ptr %111, align 1, !tbaa !45
  %113 = add i8 %112, 1
  store i8 %113, ptr %111, align 1, !tbaa !45
  %114 = getelementptr inbounds nuw i8, ptr %0, i16 32
  %115 = load i8, ptr %114, align 1, !tbaa !48
  %116 = icmp eq i8 %115, 0
  br i1 %116, label %117, label %155

117:                                              ; preds = %109
  %118 = shl i8 %113, 1
  %119 = icmp sgt i8 %118, -1
  br i1 %119, label %122, label %120

120:                                              ; preds = %117
  %121 = xor i8 %118, -1
  br label %122

122:                                              ; preds = %117, %120
  %123 = phi i8 [ %121, %120 ], [ %118, %117 ]
  %124 = lshr i8 %123, 4
  %125 = add nuw nsw i8 %124, 24
  %126 = zext nneg i8 %125 to i16
  %127 = mul nuw nsw i16 %126, 1057
  %128 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 %127, ptr %128, align 1, !tbaa !51
  %129 = add i8 %118, -86
  %130 = icmp sgt i8 %129, -1
  br i1 %130, label %133, label %131

131:                                              ; preds = %122
  %132 = sub nsw i8 85, %118
  br label %133

133:                                              ; preds = %122, %131
  %134 = phi i8 [ %132, %131 ], [ %129, %122 ]
  %135 = lshr i8 %134, 2
  %136 = zext nneg i8 %135 to i16
  %137 = shl nuw nsw i16 %136, 10
  %138 = add i8 %118, 85
  %139 = icmp sgt i8 %138, -1
  br i1 %139, label %142, label %140

140:                                              ; preds = %133
  %141 = sub nuw i8 -86, %118
  br label %142

142:                                              ; preds = %133, %140
  %143 = phi i8 [ %141, %140 ], [ %138, %133 ]
  %144 = lshr i8 %143, 2
  %145 = zext nneg i8 %144 to i16
  %146 = shl nuw nsw i16 %145, 5
  %147 = add nuw nsw i16 %146, %137
  br i1 %119, label %150, label %148

148:                                              ; preds = %142
  %149 = xor i8 %118, -1
  br label %150

150:                                              ; preds = %142, %148
  %151 = phi i8 [ %149, %148 ], [ %118, %142 ]
  %152 = lshr i8 %151, 2
  %153 = zext nneg i8 %152 to i16
  %154 = add nuw nsw i16 %147, %153
  br label %157

155:                                              ; preds = %109
  %156 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 29596, ptr %156, align 1, !tbaa !51
  br label %157

157:                                              ; preds = %155, %150
  %158 = phi i16 [ 0, %155 ], [ %154, %150 ]
  %159 = getelementptr inbounds nuw i8, ptr %0, i16 36
  store i16 %158, ptr %159, align 1, !tbaa !52
  %160 = icmp ugt i8 %110, 15
  br i1 %160, label %188, label %161

161:                                              ; preds = %157
  %162 = getelementptr inbounds nuw i8, ptr %0, i16 34
  %163 = zext nneg i8 %110 to i16
  %164 = add nuw nsw i8 %110, 1
  store i8 %164, ptr %81, align 1, !tbaa !66
  %165 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %163
  %166 = getelementptr inbounds nuw i8, ptr %165, i16 10
  store i8 1, ptr %166, align 1, !tbaa !67
  store i16 113, ptr %165, align 1, !tbaa !69
  %167 = getelementptr inbounds nuw i8, ptr %165, i16 9
  store i8 0, ptr %167, align 1, !tbaa !70
  %168 = getelementptr inbounds nuw i8, ptr %165, i16 7
  store i8 34, ptr %168, align 1, !tbaa !71
  %169 = getelementptr inbounds nuw i8, ptr %165, i16 8
  store i8 0, ptr %169, align 1, !tbaa !72
  %170 = ptrtoint ptr %162 to i16
  %171 = getelementptr inbounds nuw i8, ptr %165, i16 2
  store i16 %170, ptr %171, align 1, !tbaa !73
  %172 = getelementptr inbounds nuw i8, ptr %165, i16 6
  store i8 0, ptr %172, align 1, !tbaa !74
  %173 = getelementptr inbounds nuw i8, ptr %165, i16 4
  store i16 2, ptr %173, align 1, !tbaa !75
  %174 = icmp eq i8 %110, 15
  br i1 %174, label %188, label %175

175:                                              ; preds = %161
  %176 = getelementptr inbounds nuw i8, ptr %0, i16 36
  %177 = zext nneg i8 %164 to i16
  %178 = add nuw nsw i8 %110, 2
  store i8 %178, ptr %81, align 1, !tbaa !66
  %179 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %177
  %180 = getelementptr inbounds nuw i8, ptr %179, i16 10
  store i8 1, ptr %180, align 1, !tbaa !67
  store i16 0, ptr %179, align 1, !tbaa !69
  %181 = getelementptr inbounds nuw i8, ptr %179, i16 9
  store i8 0, ptr %181, align 1, !tbaa !70
  %182 = getelementptr inbounds nuw i8, ptr %179, i16 7
  store i8 34, ptr %182, align 1, !tbaa !71
  %183 = getelementptr inbounds nuw i8, ptr %179, i16 8
  store i8 0, ptr %183, align 1, !tbaa !72
  %184 = ptrtoint ptr %176 to i16
  %185 = getelementptr inbounds nuw i8, ptr %179, i16 2
  store i16 %184, ptr %185, align 1, !tbaa !73
  %186 = getelementptr inbounds nuw i8, ptr %179, i16 6
  store i8 0, ptr %186, align 1, !tbaa !74
  %187 = getelementptr inbounds nuw i8, ptr %179, i16 4
  store i16 2, ptr %187, align 1, !tbaa !75
  br label %188

188:                                              ; preds = %157, %175, %161, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @_title_write16(ptr noundef readonly captures(address_is_null) %0, i8 noundef zeroext %1, i8 noundef zeroext %2) unnamed_addr #3 {
  %4 = zext i8 %1 to i16
  %5 = shl nuw nsw i16 %4, 1
  %6 = and i16 %5, 254
  %7 = sub nsw i16 32, %6
  %8 = lshr exact i16 %7, 1
  %9 = zext i8 %2 to i16
  %10 = icmp eq ptr %0, null
  %11 = and i16 %8, 255
  %12 = add nuw i16 %8, %5
  %13 = and i16 %12, 255
  br label %15

14:                                               ; preds = %23
  ret void

15:                                               ; preds = %3, %23
  %16 = phi i1 [ true, %3 ], [ false, %23 ]
  %17 = phi i8 [ 0, %3 ], [ 1, %23 ]
  %18 = zext nneg i8 %17 to i16
  %19 = add nuw nsw i16 %18, %9
  %20 = shl nuw nsw i16 %19, 5
  %21 = add nuw nsw i16 %20, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !11
  store volatile i16 %21, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %22 = select i1 %16, i16 7168, i16 7170
  br label %24

23:                                               ; preds = %56
  br i1 %16, label %15, label %14, !llvm.loop !104

24:                                               ; preds = %15, %56
  %25 = phi i8 [ 0, %15 ], [ %58, %56 ]
  %26 = zext nneg i8 %25 to i16
  br i1 %10, label %56, label %27

27:                                               ; preds = %24
  %28 = icmp samesign ugt i16 %11, %26
  br i1 %28, label %56, label %29

29:                                               ; preds = %27
  %30 = icmp samesign ugt i16 %13, %26
  br i1 %30, label %31, label %56

31:                                               ; preds = %29
  %32 = sub nsw i16 %26, %11
  %33 = lshr i16 %32, 1
  %34 = and i16 %33, 255
  %35 = getelementptr inbounds nuw i8, ptr %0, i16 %34
  %36 = load i8, ptr %35, align 1, !tbaa !11
  %37 = icmp ugt i8 %36, 96
  br i1 %37, label %38, label %42

38:                                               ; preds = %31
  %39 = icmp ult i8 %36, 123
  br i1 %39, label %40, label %51

40:                                               ; preds = %38
  %41 = add nsw i8 %36, -32
  br label %46

42:                                               ; preds = %31
  %43 = icmp samesign ugt i8 %36, 31
  br i1 %43, label %44, label %51

44:                                               ; preds = %42
  %45 = icmp eq i8 %36, 96
  br i1 %45, label %51, label %46

46:                                               ; preds = %44, %40
  %47 = phi i8 [ %41, %40 ], [ %36, %44 ]
  %48 = zext nneg i8 %47 to i16
  %49 = shl nuw nsw i16 %48, 2
  %50 = add nsw i16 %49, -64
  br label %51

51:                                               ; preds = %38, %42, %44, %46
  %52 = phi i16 [ %50, %46 ], [ 64, %44 ], [ 64, %42 ], [ 64, %38 ]
  %53 = and i16 %32, 1
  %54 = or disjoint i16 %22, %53
  %55 = or disjoint i16 %54, %52
  br label %56

56:                                               ; preds = %51, %29, %27, %24
  %57 = phi i16 [ %55, %51 ], [ 7168, %29 ], [ 7168, %27 ], [ 7168, %24 ]
  store volatile i16 %57, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %58 = add nuw nsw i8 %25, 1
  %59 = icmp eq i8 %58, 32
  br i1 %59, label %23, label %24, !llvm.loop !105
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_build(ptr noundef readonly captures(none) %0, i16 noundef range(i16 -2048, 2048) %1, i16 noundef range(i16 -2048, 2048) %2, ptr noundef %3, ptr noundef %4) unnamed_addr #5 {
  %6 = alloca %struct.HScrollW, align 1
  %7 = alloca %struct.HScrollW, align 1
  %8 = alloca i16, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #12
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #12
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #12
  store i16 0, ptr %8, align 1, !tbaa !2
  store ptr %3, ptr %6, align 1, !tbaa !106
  %9 = getelementptr inbounds nuw i8, ptr %6, i16 2
  store i8 0, ptr %9, align 1, !tbaa !108
  store ptr %4, ptr %7, align 1, !tbaa !106
  %10 = getelementptr inbounds nuw i8, ptr %7, i16 2
  store i8 0, ptr %10, align 1, !tbaa !108
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %12 = load i16, ptr %11, align 1, !tbaa !42
  %13 = getelementptr inbounds nuw i8, ptr %0, i16 26
  %14 = load i16, ptr %13, align 1, !tbaa !102
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %1, i16 noundef 8, i16 noundef %12, i16 noundef %14) #14
  %15 = getelementptr inbounds nuw i8, ptr %0, i16 17
  %16 = load i16, ptr %15, align 1, !tbaa !44
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %18 = load i16, ptr %17, align 1, !tbaa !43
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %2, i16 noundef %16, i16 noundef %18, i16 noundef 0) #14
  %19 = load i16, ptr %8, align 1, !tbaa !2
  call fastcc void @_title_blank(ptr noundef %6, ptr noundef %7, i16 noundef %19, i16 noundef 224) #14
  %20 = load ptr, ptr %6, align 1, !tbaa !106
  %21 = load i8, ptr %9, align 1, !tbaa !108
  %22 = zext i8 %21 to i16
  %23 = getelementptr inbounds nuw i8, ptr %20, i16 %22
  store i8 0, ptr %23, align 1, !tbaa !11
  %24 = load ptr, ptr %7, align 1, !tbaa !106
  %25 = load i8, ptr %10, align 1, !tbaa !108
  %26 = zext i8 %25 to i16
  %27 = getelementptr inbounds nuw i8, ptr %24, i16 %26
  store i8 0, ptr %27, align 1, !tbaa !11
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #12
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #12
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #12
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_glyph_band(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, ptr noundef nonnull captures(none) %2, i16 noundef range(i16 -2048, 2048) %3, i16 noundef %4, i16 noundef %5, i16 noundef %6) unnamed_addr #5 {
  %8 = add nsw i16 %3, -2
  %9 = add nsw i16 %4, %3
  %10 = add nsw i16 %9, 2
  %11 = load i16, ptr %2, align 1, !tbaa !2
  %12 = icmp slt i16 %8, %11
  br i1 %12, label %13, label %14

13:                                               ; preds = %7
  br label %14

14:                                               ; preds = %13, %7
  %15 = phi i16 [ %11, %13 ], [ %8, %7 ]
  %16 = icmp sgt i16 %9, 222
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  br label %18

18:                                               ; preds = %17, %14
  %19 = phi i16 [ 224, %17 ], [ %10, %14 ]
  %20 = icmp sgt i16 %19, %15
  br i1 %20, label %21, label %92

21:                                               ; preds = %18
  tail call fastcc void @_title_blank(ptr noundef %0, ptr noundef %1, i16 noundef %11, i16 noundef %15) #14
  %22 = sub nsw i16 %19, %15
  %23 = trunc i16 %22 to i8
  %24 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %25 = icmp eq i8 %23, 0
  br i1 %25, label %91, label %26

26:                                               ; preds = %21
  %27 = sub nsw i16 %5, %3
  %28 = and i16 %22, 255
  %29 = trunc i16 %27 to i8
  %30 = lshr i16 %27, 8
  %31 = trunc nuw i16 %30 to i8
  br label %32

32:                                               ; preds = %40, %26
  %33 = phi i16 [ %28, %26 ], [ %57, %40 ]
  %34 = load i8, ptr %24, align 1, !tbaa !108
  %35 = icmp ult i8 %34, 22
  br i1 %35, label %36, label %59

36:                                               ; preds = %32
  %37 = icmp ugt i16 %33, 127
  br i1 %37, label %40, label %38

38:                                               ; preds = %36
  %39 = trunc nuw nsw i16 %33 to i8
  br label %40

40:                                               ; preds = %38, %36
  %41 = phi i8 [ %39, %38 ], [ 127, %36 ]
  %42 = load ptr, ptr %0, align 1, !tbaa !106
  %43 = add nuw nsw i8 %34, 1
  store i8 %43, ptr %24, align 1, !tbaa !108
  %44 = zext nneg i8 %34 to i16
  %45 = getelementptr inbounds nuw i8, ptr %42, i16 %44
  store i8 %41, ptr %45, align 1, !tbaa !11
  %46 = load ptr, ptr %0, align 1, !tbaa !106
  %47 = load i8, ptr %24, align 1, !tbaa !108
  %48 = add i8 %47, 1
  store i8 %48, ptr %24, align 1, !tbaa !108
  %49 = zext i8 %47 to i16
  %50 = getelementptr inbounds nuw i8, ptr %46, i16 %49
  store i8 %29, ptr %50, align 1, !tbaa !11
  %51 = load ptr, ptr %0, align 1, !tbaa !106
  %52 = load i8, ptr %24, align 1, !tbaa !108
  %53 = add i8 %52, 1
  store i8 %53, ptr %24, align 1, !tbaa !108
  %54 = zext i8 %52 to i16
  %55 = getelementptr inbounds nuw i8, ptr %51, i16 %54
  store i8 %31, ptr %55, align 1, !tbaa !11
  %56 = zext nneg i8 %41 to i16
  %57 = sub i16 %33, %56
  %58 = icmp eq i16 %57, 0
  br i1 %58, label %59, label %32, !llvm.loop !109

59:                                               ; preds = %32, %40
  %60 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %61 = trunc i16 %6 to i8
  %62 = lshr i16 %6, 8
  %63 = trunc nuw i16 %62 to i8
  br label %64

64:                                               ; preds = %72, %59
  %65 = phi i16 [ %28, %59 ], [ %89, %72 ]
  %66 = load i8, ptr %60, align 1, !tbaa !108
  %67 = icmp ult i8 %66, 22
  br i1 %67, label %68, label %91

68:                                               ; preds = %64
  %69 = icmp ugt i16 %65, 127
  br i1 %69, label %72, label %70

70:                                               ; preds = %68
  %71 = trunc nuw nsw i16 %65 to i8
  br label %72

72:                                               ; preds = %70, %68
  %73 = phi i8 [ %71, %70 ], [ 127, %68 ]
  %74 = load ptr, ptr %1, align 1, !tbaa !106
  %75 = add nuw nsw i8 %66, 1
  store i8 %75, ptr %60, align 1, !tbaa !108
  %76 = zext nneg i8 %66 to i16
  %77 = getelementptr inbounds nuw i8, ptr %74, i16 %76
  store i8 %73, ptr %77, align 1, !tbaa !11
  %78 = load ptr, ptr %1, align 1, !tbaa !106
  %79 = load i8, ptr %60, align 1, !tbaa !108
  %80 = add i8 %79, 1
  store i8 %80, ptr %60, align 1, !tbaa !108
  %81 = zext i8 %79 to i16
  %82 = getelementptr inbounds nuw i8, ptr %78, i16 %81
  store i8 %61, ptr %82, align 1, !tbaa !11
  %83 = load ptr, ptr %1, align 1, !tbaa !106
  %84 = load i8, ptr %60, align 1, !tbaa !108
  %85 = add i8 %84, 1
  store i8 %85, ptr %60, align 1, !tbaa !108
  %86 = zext i8 %84 to i16
  %87 = getelementptr inbounds nuw i8, ptr %83, i16 %86
  store i8 %63, ptr %87, align 1, !tbaa !11
  %88 = zext nneg i8 %73 to i16
  %89 = sub i16 %65, %88
  %90 = icmp eq i16 %89, 0
  br i1 %90, label %91, label %64, !llvm.loop !109

91:                                               ; preds = %64, %72, %21
  store i16 %19, ptr %2, align 1, !tbaa !2
  br label %92

92:                                               ; preds = %18, %91
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_blank(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, i16 noundef %2, i16 noundef range(i16 -2050, 225) %3) unnamed_addr #5 {
  %5 = icmp sgt i16 %3, %2
  br i1 %5, label %6, label %83

6:                                                ; preds = %4
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 2
  br label %9

9:                                                ; preds = %6, %79
  %10 = phi i16 [ %2, %6 ], [ %81, %79 ]
  %11 = sub nsw i16 %3, %10
  %12 = icmp sgt i16 %11, 112
  br i1 %12, label %16, label %13

13:                                               ; preds = %9
  %14 = trunc i16 %11 to i8
  %15 = icmp eq i8 %14, 0
  br i1 %15, label %79, label %16

16:                                               ; preds = %9, %13
  %17 = phi i8 [ %14, %13 ], [ 112, %9 ]
  %18 = phi i16 [ %11, %13 ], [ 112, %9 ]
  %19 = sub nsw i16 144, %10
  %20 = zext i8 %17 to i16
  %21 = trunc i16 %19 to i8
  %22 = lshr i16 %19, 8
  %23 = trunc nuw i16 %22 to i8
  br label %24

24:                                               ; preds = %32, %16
  %25 = phi i16 [ %20, %16 ], [ %49, %32 ]
  %26 = load i8, ptr %7, align 1, !tbaa !108
  %27 = icmp ult i8 %26, 22
  br i1 %27, label %28, label %51

28:                                               ; preds = %24
  %29 = icmp ugt i16 %25, 127
  br i1 %29, label %32, label %30

30:                                               ; preds = %28
  %31 = trunc nuw nsw i16 %25 to i8
  br label %32

32:                                               ; preds = %30, %28
  %33 = phi i8 [ %31, %30 ], [ 127, %28 ]
  %34 = load ptr, ptr %0, align 1, !tbaa !106
  %35 = add nuw nsw i8 %26, 1
  store i8 %35, ptr %7, align 1, !tbaa !108
  %36 = zext nneg i8 %26 to i16
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 %36
  store i8 %33, ptr %37, align 1, !tbaa !11
  %38 = load ptr, ptr %0, align 1, !tbaa !106
  %39 = load i8, ptr %7, align 1, !tbaa !108
  %40 = add i8 %39, 1
  store i8 %40, ptr %7, align 1, !tbaa !108
  %41 = zext i8 %39 to i16
  %42 = getelementptr inbounds nuw i8, ptr %38, i16 %41
  store i8 %21, ptr %42, align 1, !tbaa !11
  %43 = load ptr, ptr %0, align 1, !tbaa !106
  %44 = load i8, ptr %7, align 1, !tbaa !108
  %45 = add i8 %44, 1
  store i8 %45, ptr %7, align 1, !tbaa !108
  %46 = zext i8 %44 to i16
  %47 = getelementptr inbounds nuw i8, ptr %43, i16 %46
  store i8 %23, ptr %47, align 1, !tbaa !11
  %48 = zext nneg i8 %33 to i16
  %49 = sub i16 %25, %48
  %50 = icmp eq i16 %49, 0
  br i1 %50, label %51, label %24, !llvm.loop !109

51:                                               ; preds = %24, %32
  br label %52

52:                                               ; preds = %51, %60
  %53 = phi i16 [ %77, %60 ], [ %20, %51 ]
  %54 = load i8, ptr %8, align 1, !tbaa !108
  %55 = icmp ult i8 %54, 22
  br i1 %55, label %56, label %79

56:                                               ; preds = %52
  %57 = icmp ugt i16 %53, 127
  br i1 %57, label %60, label %58

58:                                               ; preds = %56
  %59 = trunc nuw nsw i16 %53 to i8
  br label %60

60:                                               ; preds = %58, %56
  %61 = phi i8 [ %59, %58 ], [ 127, %56 ]
  %62 = load ptr, ptr %1, align 1, !tbaa !106
  %63 = add nuw nsw i8 %54, 1
  store i8 %63, ptr %8, align 1, !tbaa !108
  %64 = zext nneg i8 %54 to i16
  %65 = getelementptr inbounds nuw i8, ptr %62, i16 %64
  store i8 %61, ptr %65, align 1, !tbaa !11
  %66 = load ptr, ptr %1, align 1, !tbaa !106
  %67 = load i8, ptr %8, align 1, !tbaa !108
  %68 = add i8 %67, 1
  store i8 %68, ptr %8, align 1, !tbaa !108
  %69 = zext i8 %67 to i16
  %70 = getelementptr inbounds nuw i8, ptr %66, i16 %69
  store i8 0, ptr %70, align 1, !tbaa !11
  %71 = load ptr, ptr %1, align 1, !tbaa !106
  %72 = load i8, ptr %8, align 1, !tbaa !108
  %73 = add i8 %72, 1
  store i8 %73, ptr %8, align 1, !tbaa !108
  %74 = zext i8 %72 to i16
  %75 = getelementptr inbounds nuw i8, ptr %71, i16 %74
  store i8 0, ptr %75, align 1, !tbaa !11
  %76 = zext nneg i8 %61 to i16
  %77 = sub i16 %53, %76
  %78 = icmp eq i16 %77, 0
  br i1 %78, label %79, label %52, !llvm.loop !109

79:                                               ; preds = %52, %60, %13
  %80 = phi i16 [ %11, %13 ], [ %18, %60 ], [ %18, %52 ]
  %81 = add nsw i16 %80, %10
  %82 = icmp sgt i16 %3, %81
  br i1 %82, label %9, label %83, !llvm.loop !110

83:                                               ; preds = %79, %4
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none)
define internal fastcc void @upq_flush(ptr noundef nonnull captures(none) %0) unnamed_addr #6 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i16 177
  %3 = load i8, ptr %2, align 1, !tbaa !111
  %4 = zext i8 %3 to i16
  %5 = shl nuw nsw i16 %4, 4
  %6 = add nuw nsw i16 %5, 17152
  %7 = inttoptr i16 %6 to ptr
  %8 = shl nuw i16 1, %4
  %9 = trunc i16 %8 to i8
  %10 = getelementptr inbounds nuw i8, ptr %0, i16 176
  %11 = load i8, ptr %10, align 1, !tbaa !66
  %12 = icmp eq i8 %11, 0
  br i1 %12, label %111, label %13

13:                                               ; preds = %1
  %14 = getelementptr inbounds nuw i8, ptr %7, i16 1
  %15 = getelementptr inbounds nuw i8, ptr %7, i16 2
  %16 = getelementptr inbounds nuw i8, ptr %7, i16 3
  %17 = getelementptr inbounds nuw i8, ptr %7, i16 4
  %18 = getelementptr inbounds nuw i8, ptr %7, i16 5
  %19 = getelementptr inbounds nuw i8, ptr %7, i16 6
  br label %20

20:                                               ; preds = %13, %89
  %21 = phi i8 [ %11, %13 ], [ %92, %89 ]
  %22 = phi i16 [ 0, %13 ], [ %90, %89 ]
  %23 = phi i8 [ 0, %13 ], [ %91, %89 ]
  %24 = zext i8 %23 to i16
  %25 = getelementptr inbounds nuw [11 x i8], ptr %0, i16 %24
  %26 = getelementptr inbounds nuw i8, ptr %25, i16 10
  %27 = load i8, ptr %26, align 1, !tbaa !67
  switch i8 %27, label %47 [
    i8 3, label %28
    i8 4, label %37
  ]

28:                                               ; preds = %20
  %29 = load i16, ptr %25, align 1, !tbaa !69
  %30 = inttoptr i16 %29 to ptr
  %31 = getelementptr inbounds nuw i8, ptr %25, i16 2
  %32 = load i16, ptr %31, align 1, !tbaa !73
  %33 = trunc i16 %32 to i8
  store volatile i8 %33, ptr %30, align 1, !tbaa !11
  %34 = load i16, ptr %31, align 1, !tbaa !73
  %35 = lshr i16 %34, 8
  %36 = trunc nuw i16 %35 to i8
  store volatile i8 %36, ptr %30, align 1, !tbaa !11
  br label %89

37:                                               ; preds = %20
  %38 = load i16, ptr %25, align 1, !tbaa !69
  %39 = inttoptr i16 %38 to ptr
  %40 = getelementptr inbounds nuw i8, ptr %25, i16 2
  %41 = load i16, ptr %40, align 1, !tbaa !73
  %42 = trunc i16 %41 to i8
  store volatile i8 %42, ptr %39, align 1, !tbaa !11
  %43 = load i16, ptr %40, align 1, !tbaa !73
  %44 = lshr i16 %43, 8
  %45 = trunc nuw i16 %44 to i8
  %46 = getelementptr inbounds nuw i8, ptr %39, i16 1
  store volatile i8 %45, ptr %46, align 1, !tbaa !11
  br label %89

47:                                               ; preds = %20
  %48 = icmp eq i16 %22, 0
  br i1 %48, label %54, label %49

49:                                               ; preds = %47
  %50 = getelementptr inbounds nuw i8, ptr %25, i16 4
  %51 = load i16, ptr %50, align 1, !tbaa !75
  %52 = add i16 %51, %22
  %53 = icmp ugt i16 %52, 5100
  br i1 %53, label %94, label %54

54:                                               ; preds = %49, %47
  switch i8 %27, label %62 [
    i8 0, label %55
    i8 1, label %59
  ]

55:                                               ; preds = %54
  %56 = getelementptr inbounds nuw i8, ptr %25, i16 9
  %57 = load i8, ptr %56, align 1, !tbaa !70
  store volatile i8 %57, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !11
  %58 = load i16, ptr %25, align 1, !tbaa !69
  store volatile i16 %58, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %68

59:                                               ; preds = %54
  %60 = load i16, ptr %25, align 1, !tbaa !69
  %61 = trunc i16 %60 to i8
  store volatile i8 %61, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !11
  br label %68

62:                                               ; preds = %54
  %63 = load i16, ptr %25, align 1, !tbaa !69
  %64 = trunc i16 %63 to i8
  store volatile i8 %64, ptr inttoptr (i16 8450 to ptr), align 2, !tbaa !11
  %65 = load i16, ptr %25, align 1, !tbaa !69
  %66 = lshr i16 %65, 8
  %67 = trunc nuw i16 %66 to i8
  store volatile i8 %67, ptr inttoptr (i16 8451 to ptr), align 1, !tbaa !11
  br label %68

68:                                               ; preds = %59, %62, %55
  %69 = getelementptr inbounds nuw i8, ptr %25, i16 8
  %70 = load i8, ptr %69, align 1, !tbaa !72
  store volatile i8 %70, ptr %7, align 16, !tbaa !11
  %71 = getelementptr inbounds nuw i8, ptr %25, i16 7
  %72 = load i8, ptr %71, align 1, !tbaa !71
  store volatile i8 %72, ptr %14, align 1, !tbaa !11
  %73 = getelementptr inbounds nuw i8, ptr %25, i16 2
  %74 = load i16, ptr %73, align 1, !tbaa !73
  %75 = trunc i16 %74 to i8
  store volatile i8 %75, ptr %15, align 2, !tbaa !11
  %76 = load i16, ptr %73, align 1, !tbaa !73
  %77 = lshr i16 %76, 8
  %78 = trunc nuw i16 %77 to i8
  store volatile i8 %78, ptr %16, align 1, !tbaa !11
  %79 = getelementptr inbounds nuw i8, ptr %25, i16 6
  %80 = load i8, ptr %79, align 1, !tbaa !74
  store volatile i8 %80, ptr %17, align 4, !tbaa !11
  %81 = getelementptr inbounds nuw i8, ptr %25, i16 4
  %82 = load i16, ptr %81, align 1, !tbaa !75
  %83 = trunc i16 %82 to i8
  store volatile i8 %83, ptr %18, align 1, !tbaa !11
  %84 = load i16, ptr %81, align 1, !tbaa !75
  %85 = lshr i16 %84, 8
  %86 = trunc nuw i16 %85 to i8
  store volatile i8 %86, ptr %19, align 2, !tbaa !11
  store volatile i8 %9, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !11
  %87 = load i16, ptr %81, align 1, !tbaa !75
  %88 = add i16 %87, %22
  br label %89

89:                                               ; preds = %68, %37, %28
  %90 = phi i16 [ %22, %28 ], [ %22, %37 ], [ %88, %68 ]
  %91 = add nuw i8 %23, 1
  %92 = load i8, ptr %10, align 1, !tbaa !66
  %93 = icmp ult i8 %91, %92
  br i1 %93, label %20, label %94

94:                                               ; preds = %89, %49
  %95 = phi i8 [ %92, %89 ], [ %21, %49 ]
  %96 = phi i8 [ %91, %89 ], [ %23, %49 ]
  %97 = icmp ult i8 %96, %95
  br i1 %97, label %98, label %111

98:                                               ; preds = %94
  %99 = icmp eq i8 %96, 0
  br i1 %99, label %113, label %100

100:                                              ; preds = %98, %100
  %101 = phi i8 [ %104, %100 ], [ 0, %98 ]
  %102 = phi i8 [ %107, %100 ], [ %96, %98 ]
  %103 = zext i8 %102 to i16
  %104 = add i8 %101, 1
  %105 = zext i8 %101 to i16
  %106 = getelementptr inbounds nuw [11 x i8], ptr %0, i16 %105
  %107 = add nuw i8 %102, 1
  %108 = getelementptr inbounds nuw [11 x i8], ptr %0, i16 %103
  tail call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(11) %106, ptr noundef nonnull align 1 dereferenceable(11) %108, i16 11, i1 false), !tbaa.struct !112
  %109 = load i8, ptr %10, align 1, !tbaa !66
  %110 = icmp ult i8 %107, %109
  br i1 %110, label %100, label %111, !llvm.loop !113

111:                                              ; preds = %100, %94, %1
  %112 = phi i8 [ 0, %94 ], [ 0, %1 ], [ %104, %100 ]
  store i8 %112, ptr %10, align 1, !tbaa !66
  br label %113

113:                                              ; preds = %111, %98
  ret void
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #7

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define internal fastcc signext range(i8 0, 4) i8 @newton_nearest_root(i16 noundef %0, i16 noundef %1) unnamed_addr #8 {
  %3 = add nsw i16 %0, -256
  %4 = sext i16 %3 to i32
  %5 = sext i16 %1 to i32
  %6 = mul nsw i32 %4, %4
  %7 = mul nsw i32 %5, %5
  %8 = add nuw nsw i32 %6, %7
  %9 = icmp samesign ult i32 %8, 1024
  br i1 %9, label %26, label %10

10:                                               ; preds = %2
  %11 = add nsw i16 %0, 128
  %12 = sext i16 %11 to i32
  %13 = mul nsw i32 %12, %12
  %14 = add nsw i16 %1, -222
  %15 = sext i16 %14 to i32
  %16 = mul nsw i32 %15, %15
  %17 = add nuw nsw i32 %16, %13
  %18 = icmp samesign ult i32 %17, 1024
  br i1 %18, label %26, label %19

19:                                               ; preds = %10
  %20 = add nsw i16 %1, 222
  %21 = sext i16 %20 to i32
  %22 = mul nsw i32 %21, %21
  %23 = add nuw nsw i32 %22, %13
  %24 = icmp samesign ult i32 %23, 1024
  %25 = select i1 %24, i8 3, i8 0
  br label %26

26:                                               ; preds = %10, %19, %2
  %27 = phi i8 [ 1, %2 ], [ 2, %10 ], [ %25, %19 ]
  ret i8 %27
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal fastcc void @newton_step(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1) unnamed_addr #9 {
  %3 = load i16, ptr %0, align 1, !tbaa !2
  %4 = load i16, ptr %1, align 1, !tbaa !2
  %5 = sext i16 %3 to i32
  %6 = sext i16 %4 to i32
  %7 = add nsw i32 %6, %5
  %8 = sub nsw i32 %5, %6
  %9 = shl nsw i32 %8, 8
  %10 = mul i32 %9, %7
  %11 = ashr i32 %10, 16
  %12 = shl nsw i32 %5, 9
  %13 = mul i32 %12, %6
  %14 = ashr i32 %13, 16
  %15 = trunc nsw i32 %11 to i16
  %16 = mul i16 %15, 3
  %17 = trunc nsw i32 %14 to i16
  %18 = mul i16 %17, 3
  %19 = ashr i16 %16, 1
  %20 = sext i16 %19 to i32
  %21 = ashr i16 %18, 1
  %22 = sext i16 %21 to i32
  %23 = mul nsw i32 %20, %20
  %24 = mul nsw i32 %22, %22
  %25 = add nuw nsw i32 %23, %24
  %26 = icmp eq i32 %25, 0
  br i1 %26, label %67, label %27

27:                                               ; preds = %2
  %28 = mul nsw i32 %11, %6
  %29 = mul nsw i32 %14, %5
  %30 = add nsw i32 %28, %29
  %31 = shl i32 %30, 8
  %32 = ashr i32 %31, 17
  %33 = mul nsw i32 %11, %5
  %34 = mul nsw i32 %14, %6
  %35 = sub nsw i32 %33, %34
  %36 = lshr i32 %35, 8
  %37 = trunc i32 %36 to i16
  %38 = add nsw i16 %37, -256
  %39 = ashr i16 %38, 1
  %40 = sext i16 %39 to i32
  %41 = mul nsw i32 %40, %20
  %42 = mul nsw i32 %32, %22
  %43 = add nsw i32 %41, %42
  %44 = shl i32 %43, 8
  %45 = sdiv i32 %44, %25
  %46 = mul nsw i32 %32, %20
  %47 = mul nsw i32 %40, %22
  %48 = sub nsw i32 %46, %47
  %49 = shl i32 %48, 8
  %50 = sdiv i32 %49, %25
  %51 = icmp sgt i32 %45, 512
  br i1 %51, label %56, label %52

52:                                               ; preds = %27
  %53 = icmp slt i32 %45, -512
  %54 = trunc nsw i32 %45 to i16
  br i1 %53, label %55, label %56

55:                                               ; preds = %52
  br label %56

56:                                               ; preds = %27, %55, %52
  %57 = phi i16 [ -512, %55 ], [ %54, %52 ], [ 512, %27 ]
  %58 = icmp sgt i32 %50, 512
  br i1 %58, label %63, label %59

59:                                               ; preds = %56
  %60 = icmp slt i32 %50, -512
  %61 = trunc nsw i32 %50 to i16
  br i1 %60, label %62, label %63

62:                                               ; preds = %59
  br label %63

63:                                               ; preds = %56, %62, %59
  %64 = phi i16 [ -512, %62 ], [ %61, %59 ], [ 512, %56 ]
  %65 = sub nsw i16 %3, %57
  store i16 %65, ptr %0, align 1, !tbaa !2
  %66 = sub nsw i16 %4, %64
  store i16 %66, ptr %1, align 1, !tbaa !2
  br label %67

67:                                               ; preds = %2, %63
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #10

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #11

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree noinline norecurse nosync nounwind optsize memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #3 = { nofree norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #4 = { nofree norecurse nosync nounwind optsize memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #5 = { nofree norecurse nosync nounwind optsize memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #6 = { nofree noinline norecurse nounwind optsize memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #7 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #9 = { mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" }
attributes #10 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #12 = { nounwind }
attributes #13 = { nounwind optsize }
attributes #14 = { optsize }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !9, i64 0}
!7 = !{!"", !8, i64 0, !4, i64 3, !10, i64 1795, !4, i64 1799}
!8 = !{!"Drawable", !9, i64 0, !4, i64 2}
!9 = !{!"any pointer", !4, i64 0}
!10 = !{!"long", !4, i64 0}
!11 = !{!4, !4, i64 0}
!12 = distinct !{!12, !13}
!13 = !{!"llvm.loop.mustprogress"}
!14 = !{!15, !4, i64 194}
!15 = !{!"", !16, i64 0, !17, i64 178, !18, i64 182, !4, i64 191, !4, i64 192, !4, i64 193, !4, i64 194, !4, i64 195}
!16 = !{!"", !4, i64 0, !4, i64 176, !4, i64 177}
!17 = !{!"", !3, i64 0, !3, i64 2}
!18 = !{!"", !4, i64 0, !4, i64 8}
!19 = !{!15, !4, i64 195}
!20 = !{!15, !4, i64 192}
!21 = !{!15, !4, i64 193}
!22 = !{!18, !4, i64 8}
!23 = !{!24, !24, i64 0}
!24 = !{!"p1 _ZTS8Drawable", !9, i64 0}
!25 = !{!8, !9, i64 0}
!26 = !{!27, !9, i64 0}
!27 = !{!"", !9, i64 0, !9, i64 2}
!28 = distinct !{null, null}
!29 = !{!15, !4, i64 191}
!30 = !{!8, !4, i64 2}
!31 = !{!32, !9, i64 0}
!32 = !{!"", !8, i64 0, !33, i64 3, !33, i64 5, !33, i64 7, !33, i64 9, !4, i64 11, !4, i64 12, !3, i64 13, !3, i64 15, !3, i64 17, !3, i64 19, !3, i64 21, !3, i64 23, !4, i64 25, !3, i64 26, !4, i64 28, !4, i64 29, !4, i64 30, !4, i64 31, !4, i64 32, !4, i64 33, !3, i64 34, !3, i64 36, !34, i64 38, !34, i64 89}
!33 = !{!"p1 omnipotent char", !9, i64 0}
!34 = !{!"", !4, i64 0, !4, i64 50}
!35 = !{!32, !4, i64 2}
!36 = !{!32, !33, i64 3}
!37 = !{!32, !33, i64 5}
!38 = !{!32, !33, i64 7}
!39 = !{!32, !4, i64 11}
!40 = !{!32, !33, i64 9}
!41 = !{!32, !4, i64 12}
!42 = !{!32, !3, i64 13}
!43 = !{!32, !3, i64 15}
!44 = !{!32, !3, i64 17}
!45 = !{!32, !4, i64 28}
!46 = !{!32, !4, i64 29}
!47 = !{!32, !4, i64 31}
!48 = !{!32, !4, i64 32}
!49 = !{!32, !4, i64 30}
!50 = !{!32, !4, i64 25}
!51 = !{!32, !3, i64 34}
!52 = !{!32, !3, i64 36}
!53 = !{!32, !4, i64 33}
!54 = !{!27, !9, i64 2}
!55 = distinct !{null, null, null, null, null}
!56 = distinct !{!56, !13}
!57 = distinct !{!57, !13}
!58 = distinct !{!58, !13}
!59 = distinct !{null, null, null, null}
!60 = distinct !{!60, !13}
!61 = distinct !{null, null, null}
!62 = distinct !{!62, !13}
!63 = distinct !{null, null, null, null}
!64 = !{!32, !3, i64 19}
!65 = distinct !{null, null, null, null, null}
!66 = !{!16, !4, i64 176}
!67 = !{!68, !4, i64 10}
!68 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !4, i64 6, !4, i64 7, !4, i64 8, !4, i64 9, !4, i64 10}
!69 = !{!68, !3, i64 0}
!70 = !{!68, !4, i64 9}
!71 = !{!68, !4, i64 7}
!72 = !{!68, !4, i64 8}
!73 = !{!68, !3, i64 2}
!74 = !{!68, !4, i64 6}
!75 = !{!68, !3, i64 4}
!76 = distinct !{!76, !13}
!77 = !{!7, !10, i64 1795}
!78 = distinct !{!78, !13}
!79 = distinct !{!79, !13}
!80 = distinct !{!80, !13}
!81 = distinct !{!81, !13}
!82 = distinct !{!82, !13}
!83 = distinct !{!83, !13}
!84 = distinct !{!84, !13}
!85 = !{!7, !4, i64 2}
!86 = distinct !{!86, !13}
!87 = !{!7, !4, i64 1799}
!88 = distinct !{!88, !13}
!89 = distinct !{!89, !13}
!90 = distinct !{!90, !13}
!91 = distinct !{!91, !13}
!92 = distinct !{!92, !13}
!93 = distinct !{!93, !13}
!94 = distinct !{!94, !13}
!95 = distinct !{!95, !13}
!96 = distinct !{!96, !13}
!97 = distinct !{!97, !13}
!98 = distinct !{!98, !13}
!99 = !{!32, !3, i64 21}
!100 = !{!32, !3, i64 23}
!101 = distinct !{!101, !13}
!102 = !{!32, !3, i64 26}
!103 = !{!34, !4, i64 50}
!104 = distinct !{!104, !13}
!105 = distinct !{!105, !13}
!106 = !{!107, !9, i64 0}
!107 = !{!"", !9, i64 0, !4, i64 2}
!108 = !{!107, !4, i64 2}
!109 = distinct !{!109, !13}
!110 = distinct !{!110, !13}
!111 = !{!16, !4, i64 177}
!112 = !{i64 0, i64 2, !2, i64 2, i64 2, !2, i64 4, i64 2, !2, i64 6, i64 1, !11, i64 7, i64 1, !11, i64 8, i64 1, !11, i64 9, i64 1, !11, i64 10, i64 1, !11}
!113 = distinct !{!113, !13}
