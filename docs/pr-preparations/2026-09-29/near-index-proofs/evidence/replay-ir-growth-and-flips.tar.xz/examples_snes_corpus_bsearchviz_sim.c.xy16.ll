; ModuleID = '/work/examples/snes/corpus/bsearchviz_sim.c'
source_filename = "/work/examples/snes/corpus/bsearchviz_sim.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@corpus_result = dso_local global i16 0, align 1
@bs_hits = internal unnamed_addr global i16 0, align 1
@bs_misses = internal unnamed_addr global i16 0, align 1
@bs_keys = internal global [64 x i16] zeroinitializer, align 1
@bs_query = internal unnamed_addr global [48 x i16] zeroinitializer, align 1
@bs_found = internal unnamed_addr global [48 x i16] zeroinitializer, align 1
@bs_nprobe = internal unnamed_addr global [48 x i8] zeroinitializer, align 1
@bs_calls = internal unnamed_addr global i16 0, align 1
@bs_cur = internal unnamed_addr global i8 0, align 1

; Function Attrs: noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  br label %4

1:                                                ; preds = %4
  %2 = load i16, ptr getelementptr inbounds nuw (i8, ptr @bs_keys, i16 126), align 1
  %3 = add i16 %2, 1
  br label %19

4:                                                ; preds = %4, %0
  %5 = phi i8 [ 0, %0 ], [ %18, %4 ]
  %6 = phi i16 [ 37, %0 ], [ %15, %4 ]
  %7 = phi i8 [ 0, %0 ], [ %16, %4 ]
  %8 = phi i16 [ 12061, %0 ], [ %12, %4 ]
  %9 = zext i8 %5 to i16
  %10 = getelementptr i8, ptr @bs_keys, i16 %9
  store i16 %6, ptr %10, align 1, !tbaa !2
  %11 = mul i16 %8, 25173
  %12 = add i16 %11, 13849
  %13 = lshr i16 %12, 11
  %14 = add i16 %6, 2
  %15 = add i16 %14, %13
  %16 = add nuw nsw i8 %7, 1
  %17 = icmp eq i8 %16, 64
  %18 = add nuw i8 %5, 2
  br i1 %17, label %1, label %4, !llvm.loop !6

19:                                               ; preds = %45, %1
  %20 = phi i8 [ 0, %1 ], [ %51, %45 ]
  %21 = phi i8 [ 0, %1 ], [ %49, %45 ]
  %22 = phi i16 [ 27525, %1 ], [ %25, %45 ]
  %23 = zext nneg i8 %21 to i16
  %24 = mul i16 %22, 25173
  %25 = add i16 %24, 13849
  %26 = lshr i16 %25, 5
  %27 = and i16 %23, 3
  %28 = icmp eq i16 %27, 3
  br i1 %28, label %29, label %36

29:                                               ; preds = %19
  %30 = and i16 %26, 63
  %31 = getelementptr inbounds nuw [2 x i8], ptr @bs_keys, i16 %30
  %32 = load i16, ptr %31, align 1, !tbaa !2
  %33 = add i16 %32, -1
  %34 = zext nneg i8 %20 to i16
  %35 = getelementptr i8, ptr @bs_query, i16 %34
  store i16 %33, ptr %35, align 1, !tbaa !2
  br label %45

36:                                               ; preds = %19
  switch i8 %21, label %39 [
    i8 0, label %37
    i8 1, label %38
  ]

37:                                               ; preds = %36
  store i16 0, ptr @bs_query, align 1, !tbaa !2
  br label %45

38:                                               ; preds = %36
  store i16 %3, ptr getelementptr inbounds nuw (i8, ptr @bs_query, i16 2), align 1, !tbaa !2
  br label %45

39:                                               ; preds = %36
  %40 = and i16 %26, 63
  %41 = getelementptr inbounds nuw [2 x i8], ptr @bs_keys, i16 %40
  %42 = load i16, ptr %41, align 1, !tbaa !2
  %43 = zext nneg i8 %20 to i16
  %44 = getelementptr i8, ptr @bs_query, i16 %43
  store i16 %42, ptr %44, align 1, !tbaa !2
  br label %45

45:                                               ; preds = %39, %38, %37, %29
  %46 = zext nneg i8 %20 to i16
  %47 = getelementptr i8, ptr @bs_found, i16 %46
  store i16 -1, ptr %47, align 1, !tbaa !2
  %48 = getelementptr i8, ptr @bs_nprobe, i16 %23
  store i8 0, ptr %48, align 1, !tbaa !8
  %49 = add nuw nsw i8 %21, 1
  %50 = icmp eq i8 %49, 48
  %51 = add nuw nsw i8 %20, 2
  br i1 %50, label %52, label %19, !llvm.loop !9

52:                                               ; preds = %45
  store i16 0, ptr @bs_misses, align 1, !tbaa !2
  store i16 0, ptr @bs_hits, align 1, !tbaa !2
  store i16 0, ptr @bs_calls, align 1, !tbaa !2
  store i8 0, ptr @bs_cur, align 1, !tbaa !8
  tail call fastcc void @bs_run() #6
  %53 = load i16, ptr @bs_hits, align 1, !tbaa !2
  %54 = xor i16 %53, 18370
  %55 = tail call i16 @llvm.fshl.i16(i16 %54, i16 %54, i16 1)
  %56 = mul i16 %55, 25173
  %57 = add i16 %56, 13849
  %58 = load i16, ptr @bs_misses, align 1, !tbaa !2
  %59 = xor i16 %57, %58
  %60 = tail call i16 @llvm.fshl.i16(i16 %59, i16 %59, i16 1)
  %61 = mul i16 %60, 25173
  %62 = add i16 %61, 13849
  br label %63

63:                                               ; preds = %63, %52
  %64 = phi i8 [ 0, %52 ], [ %76, %63 ]
  %65 = phi i16 [ %62, %52 ], [ %74, %63 ]
  %66 = phi i8 [ 0, %52 ], [ %72, %63 ]
  %67 = zext i8 %64 to i16
  %68 = getelementptr i8, ptr @bs_keys, i16 %67
  %69 = load i16, ptr %68, align 1, !tbaa !2
  %70 = xor i16 %69, %65
  %71 = tail call i16 @llvm.fshl.i16(i16 %70, i16 %70, i16 1)
  %72 = add nuw nsw i8 %66, 1
  %73 = mul i16 %71, 25173
  %74 = add i16 %73, 13849
  %75 = icmp eq i8 %72, 64
  %76 = add nuw i8 %64, 2
  br i1 %75, label %77, label %63, !llvm.loop !10

77:                                               ; preds = %63, %77
  %78 = phi i8 [ %96, %77 ], [ 0, %63 ]
  %79 = phi i8 [ %94, %77 ], [ 0, %63 ]
  %80 = phi i16 [ %93, %77 ], [ %74, %63 ]
  %81 = zext nneg i8 %78 to i16
  %82 = getelementptr i8, ptr @bs_query, i16 %81
  %83 = load i16, ptr %82, align 1, !tbaa !2
  %84 = xor i16 %83, %80
  %85 = tail call i16 @llvm.fshl.i16(i16 %84, i16 %84, i16 1)
  %86 = mul i16 %85, 25173
  %87 = add i16 %86, 13849
  %88 = getelementptr i8, ptr @bs_found, i16 %81
  %89 = load i16, ptr %88, align 1, !tbaa !2
  %90 = xor i16 %87, %89
  %91 = tail call i16 @llvm.fshl.i16(i16 %90, i16 %90, i16 1)
  %92 = mul i16 %91, 25173
  %93 = add i16 %92, 13849
  %94 = add nuw nsw i8 %79, 1
  %95 = icmp eq i8 %94, 48
  %96 = add nuw nsw i8 %78, 2
  br i1 %95, label %97, label %77, !llvm.loop !11

97:                                               ; preds = %77
  store volatile i16 %93, ptr @corpus_result, align 1, !tbaa !2
  br label %98

98:                                               ; preds = %98, %97
  tail call void asm sideeffect "wai", ""() #7, !srcloc !12
  br label %98
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: noinline nounwind optsize
define internal fastcc void @bs_run() unnamed_addr #2 {
  %1 = alloca i16, align 1
  br label %3

2:                                                ; preds = %15
  ret void

3:                                                ; preds = %0, %15
  %4 = phi i8 [ 0, %0 ], [ %23, %15 ]
  %5 = phi i8 [ 0, %0 ], [ %21, %15 ]
  store i8 %5, ptr @bs_cur, align 1, !tbaa !8
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #7
  %6 = zext nneg i8 %4 to i16
  %7 = getelementptr i8, ptr @bs_query, i16 %6
  %8 = load i16, ptr %7, align 1, !tbaa !2
  store i16 %8, ptr %1, align 1, !tbaa !2
  %9 = call ptr @bsearch(ptr noundef nonnull %1, ptr noundef nonnull @bs_keys, i16 noundef 64, i16 noundef 2, ptr noundef nonnull @bs_cmp) #8
  %10 = icmp eq ptr %9, null
  br i1 %10, label %15, label %11

11:                                               ; preds = %3
  %12 = ptrtoint ptr %9 to i16
  %13 = sub i16 %12, ptrtoint (ptr @bs_keys to i16)
  %14 = ashr exact i16 %13, 1
  br label %15

15:                                               ; preds = %3, %11
  %16 = phi i16 [ %14, %11 ], [ -1, %3 ]
  %17 = phi ptr [ @bs_hits, %11 ], [ @bs_misses, %3 ]
  %18 = getelementptr i8, ptr @bs_found, i16 %6
  store i16 %16, ptr %18, align 1, !tbaa !2
  %19 = load i16, ptr %17, align 1, !tbaa !2
  %20 = add i16 %19, 1
  store i16 %20, ptr %17, align 1, !tbaa !2
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #7
  %21 = add nuw nsw i8 %5, 1
  %22 = icmp eq i8 %21, 48
  %23 = add nuw nsw i8 %4, 2
  br i1 %22, label %2, label %3, !llvm.loop !13
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: optsize
declare dso_local ptr @bsearch(ptr noundef, ptr noundef, i16 noundef, i16 noundef, ptr noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem: none)
define internal range(i16 -1, 2) i16 @bs_cmp(ptr noundef readonly captures(none) %0, ptr noundef readonly captures(none) %1) #4 {
  %3 = load i8, ptr @bs_cur, align 1, !tbaa !8
  %4 = icmp ult i8 %3, 48
  br i1 %4, label %5, label %12

5:                                                ; preds = %2
  %6 = zext nneg i8 %3 to i16
  %7 = getelementptr inbounds nuw i8, ptr @bs_nprobe, i16 %6
  %8 = load i8, ptr %7, align 1, !tbaa !8
  %9 = icmp ult i8 %8, 8
  br i1 %9, label %10, label %12

10:                                               ; preds = %5
  %11 = add nuw nsw i8 %8, 1
  store i8 %11, ptr %7, align 1, !tbaa !8
  br label %12

12:                                               ; preds = %10, %5, %2
  %13 = load i16, ptr @bs_calls, align 1, !tbaa !2
  %14 = add i16 %13, 1
  store i16 %14, ptr @bs_calls, align 1, !tbaa !2
  %15 = load i16, ptr %0, align 1, !tbaa !2
  %16 = load i16, ptr %1, align 1, !tbaa !2
  %17 = icmp ult i16 %15, %16
  br i1 %17, label %21, label %18

18:                                               ; preds = %12
  %19 = icmp ugt i16 %15, %16
  %20 = zext i1 %19 to i16
  br label %21

21:                                               ; preds = %18, %12
  %22 = phi i16 [ -1, %12 ], [ %20, %18 ]
  ret i16 %22
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #5

attributes #0 = { noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noinline nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #3 = { optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #4 = { mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(readwrite, argmem: read, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #5 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { optsize }
attributes #7 = { nounwind }
attributes #8 = { nounwind optsize }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{!4, !4, i64 0}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = !{i64 1374}
!13 = distinct !{!13, !7}
