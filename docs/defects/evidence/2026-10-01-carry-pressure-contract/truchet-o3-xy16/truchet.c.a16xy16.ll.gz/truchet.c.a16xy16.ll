; ModuleID = '/work/examples/snes/truchet.c'
source_filename = "/work/examples/snes/truchet.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

%struct.App = type { %struct.Display, %struct.BitmapCanvas, %struct.TextLayer, [256 x %struct.Cell], i8 }
%struct.Display = type { %struct.UploadQueue, %struct.VramAlloc, %struct.Scene, i8, i8, i8, i8, i8 }
%struct.UploadQueue = type { [16 x %struct.UpqJob], i8, i8 }
%struct.UpqJob = type { i16, i16, i16, i8, i8, i8, i8, i8 }
%struct.VramAlloc = type { i16, i16 }
%struct.Scene = type { [4 x ptr], i8 }
%struct.BitmapCanvas = type { %struct.Drawable, [4096 x i8], i16, i16, i16, i16, i8, i8 }
%struct.Drawable = type { ptr, i8 }
%struct.TextLayer = type { %struct.Drawable, i16, [2 x i8], [64 x i16], i8 }
%struct.Cell = type { i8, i8 }
%struct.TitleLayer = type { %struct.Drawable, ptr, ptr, ptr, ptr, i8, i8, i16, i16, i16, i16, i16, i16, i8, i16, i8, i8, i8, i8, i8, i8, i16, i16, %struct.HScrollDB, %struct.HScrollDB }
%struct.HScrollDB = type { [2 x %struct.HScrollN], i8 }
%struct.HScrollN = type { [25 x i8] }
%struct.DrawableVT = type { ptr, ptr }
%struct.HScrollW = type { ptr, i8 }

@main.a = internal global %struct.App zeroinitializer, align 1
@main.title = internal global %struct.TitleLayer zeroinitializer, align 1
@.str = private unnamed_addr constant [8 x i8] c"TRUCHET\00", align 1
@.str.1 = private unnamed_addr constant [10 x i8] c"BITFIELDS\00", align 1
@corpus_result = dso_local global i16 0, align 1
@pal = internal global [4 x i16] [i16 0, i16 32767, i16 32394, i16 24991], align 1
@.str.2 = private unnamed_addr constant [26 x i8] c"TRUCHET  PACKED BITFIELDS\00", align 1
@.str.3 = private unnamed_addr constant [30 x i8] c"6 FIELDS PACKED IN ONE UINT16\00", align 1
@CANVAS_VT = internal constant %struct.DrawableVT { ptr @_canvas_reserve, ptr @_canvas_emit }, align 1
@TEXT_VT = internal constant %struct.DrawableVT { ptr @_text_reserve, ptr @_text_emit }, align 1
@FONT8 = internal unnamed_addr constant [512 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 32, i16 0, i16 80, i16 80, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 80, i16 80, i16 248, i16 80, i16 248, i16 80, i16 80, i16 0, i16 32, i16 120, i16 160, i16 112, i16 40, i16 240, i16 32, i16 0, i16 196, i16 200, i16 16, i16 32, i16 64, i16 152, i16 12, i16 0, i16 96, i16 144, i16 160, i16 64, i16 168, i16 144, i16 104, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 16, i16 32, i16 64, i16 64, i16 64, i16 32, i16 16, i16 0, i16 64, i16 32, i16 16, i16 16, i16 16, i16 32, i16 64, i16 0, i16 0, i16 32, i16 168, i16 112, i16 168, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 248, i16 32, i16 32, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 64, i16 0, i16 0, i16 0, i16 248, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 96, i16 96, i16 0, i16 8, i16 8, i16 16, i16 32, i16 64, i16 128, i16 128, i16 0, i16 112, i16 136, i16 152, i16 168, i16 200, i16 136, i16 112, i16 0, i16 32, i16 96, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 64, i16 248, i16 0, i16 112, i16 136, i16 8, i16 48, i16 8, i16 136, i16 112, i16 0, i16 16, i16 48, i16 80, i16 144, i16 248, i16 16, i16 16, i16 0, i16 248, i16 128, i16 240, i16 8, i16 8, i16 136, i16 112, i16 0, i16 112, i16 136, i16 128, i16 240, i16 136, i16 136, i16 112, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 64, i16 64, i16 0, i16 112, i16 136, i16 136, i16 112, i16 136, i16 136, i16 112, i16 0, i16 112, i16 136, i16 136, i16 120, i16 8, i16 136, i16 112, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 0, i16 0, i16 0, i16 32, i16 32, i16 0, i16 32, i16 32, i16 64, i16 0, i16 16, i16 32, i16 64, i16 128, i16 64, i16 32, i16 16, i16 0, i16 0, i16 0, i16 248, i16 0, i16 248, i16 0, i16 0, i16 0, i16 128, i16 64, i16 32, i16 16, i16 32, i16 64, i16 128, i16 0, i16 112, i16 136, i16 8, i16 16, i16 32, i16 0, i16 32, i16 0, i16 112, i16 136, i16 184, i16 168, i16 184, i16 128, i16 112, i16 0, i16 112, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 240, i16 136, i16 136, i16 240, i16 136, i16 136, i16 240, i16 0, i16 112, i16 136, i16 128, i16 128, i16 128, i16 136, i16 112, i16 0, i16 224, i16 144, i16 136, i16 136, i16 136, i16 144, i16 224, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 248, i16 0, i16 248, i16 128, i16 128, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 128, i16 176, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 248, i16 136, i16 136, i16 136, i16 0, i16 112, i16 32, i16 32, i16 32, i16 32, i16 32, i16 112, i16 0, i16 56, i16 16, i16 16, i16 16, i16 144, i16 144, i16 96, i16 0, i16 136, i16 144, i16 160, i16 192, i16 160, i16 144, i16 136, i16 0, i16 128, i16 128, i16 128, i16 128, i16 128, i16 128, i16 248, i16 0, i16 136, i16 216, i16 168, i16 136, i16 136, i16 136, i16 136, i16 0, i16 136, i16 200, i16 168, i16 152, i16 136, i16 136, i16 136, i16 0, i16 112, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 240, i16 136, i16 136, i16 240, i16 128, i16 128, i16 128, i16 0, i16 112, i16 136, i16 136, i16 136, i16 168, i16 144, i16 104, i16 0, i16 240, i16 136, i16 136, i16 240, i16 160, i16 144, i16 136, i16 0, i16 112, i16 136, i16 128, i16 112, i16 8, i16 136, i16 112, i16 0, i16 248, i16 32, i16 32, i16 32, i16 32, i16 32, i16 32, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 136, i16 112, i16 0, i16 136, i16 136, i16 136, i16 136, i16 136, i16 80, i16 32, i16 0, i16 136, i16 136, i16 136, i16 168, i16 168, i16 216, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 80, i16 136, i16 136, i16 0, i16 136, i16 136, i16 80, i16 32, i16 32, i16 32, i16 32, i16 0, i16 248, i16 8, i16 16, i16 32, i16 64, i16 128, i16 248, i16 0, i16 48, i16 32, i16 32, i16 32, i16 32, i16 32, i16 48, i16 0, i16 128, i16 128, i16 64, i16 32, i16 16, i16 8, i16 8, i16 0, i16 48, i16 16, i16 16, i16 16, i16 16, i16 16, i16 48, i16 0, i16 32, i16 80, i16 136, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248], align 1
@TITLE_VT = internal constant %struct.DrawableVT { ptr @_title_reserve, ptr @_title_emit }, align 1
@FONT16 = internal unnamed_addr constant [2048 x i16] [i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 192, i16 192, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 768, i16 768, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 -4096, i16 -4096, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3840, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 3312, i16 15360, i16 15360, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 28, i16 28, i16 796, i16 127, i16 127, i16 796, i16 796, i16 127, i16 112, i16 112, i16 3184, i16 252, i16 252, i16 -28816, i16 -28816, i16 252, i16 127, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 0, i16 0, i16 252, i16 -28816, i16 -28816, i16 3184, i16 7168, i16 7168, i16 0, i16 0, i16 3, i16 63, i16 123, i16 1147, i16 63, i16 4111, i16 3075, i16 123, i16 192, i16 248, i16 8414, i16 16064, i16 2040, i16 248, i16 8414, i16 8414, i16 63, i16 7171, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 2040, i16 14272, i16 -512, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 60, i16 60, i16 828, i16 828, i16 3840, i16 3585, i16 3, i16 7, i16 28, i16 56, i16 1904, i16 3808, i16 7392, i16 14528, i16 14464, i16 28672, i16 14, i16 284, i16 824, i16 1792, i16 3584, i16 0, i16 0, i16 0, i16 -8162, i16 -16354, i16 -32482, i16 286, i16 1792, i16 1792, i16 0, i16 0, i16 15, i16 31, i16 828, i16 828, i16 573, i16 31, i16 31, i16 63, i16 192, i16 224, i16 240, i16 2288, i16 7392, i16 15488, i16 30720, i16 -32648, i16 382, i16 3060, i16 3825, i16 1275, i16 127, i16 63, i16 7936, i16 3840, i16 248, i16 3824, i16 7904, i16 7392, i16 4332, i16 12492, i16 -1280, i16 -3328, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 7, i16 15, i16 15, i16 15, i16 15, i16 15, i16 240, i16 192, i16 15488, i16 -4096, i16 -8192, i16 -16384, i16 -16384, i16 -16384, i16 15, i16 7, i16 3, i16 256, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 16512, i16 192, i16 240, i16 -4096, i16 15360, i16 0, i16 0, i16 15, i16 3, i16 513, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 224, i16 240, i16 2288, i16 3312, i16 3312, i16 3312, i16 0, i16 1, i16 3, i16 15, i16 0, i16 768, i16 0, i16 0, i16 3312, i16 7392, i16 15552, i16 30720, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 51, i16 31, i16 15, i16 1027, i16 0, i16 0, i16 192, i16 192, i16 12492, i16 252, i16 1016, i16 16320, i16 15, i16 31, i16 51, i16 1027, i16 3072, i16 0, i16 0, i16 0, i16 1784, i16 252, i16 13004, i16 16320, i16 -3328, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 3, i16 3, i16 63, i16 63, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 248, i16 248, i16 63, i16 3075, i16 3075, i16 3, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 16064, i16 16064, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 15, i16 286, i16 828, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 28800, i16 -4096, i16 -8192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1784, i16 -512, i16 -512, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 192, i16 192, i16 12480, i16 -4096, i16 -4096, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7360, i16 14464, i16 7, i16 14, i16 284, i16 824, i16 1904, i16 3808, i16 7168, i16 14336, i16 28672, i16 -8192, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 828, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 15, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 1, i16 3, i16 15, i16 15, i16 513, i16 513, i16 1, i16 1, i16 240, i16 240, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 1, i16 1, i16 1, i16 1, i16 1, i16 1, i16 0, i16 0, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 31744, i16 31744, i16 15, i16 31, i16 318, i16 828, i16 3840, i16 3840, i16 3, i16 15, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 63, i16 510, i16 4080, i16 31, i16 318, i16 318, i16 318, i16 63, i16 63, i16 3840, i16 3840, i16 32640, i16 -1024, i16 -8192, i16 -32768, i16 255, i16 255, i16 -256, i16 -256, i16 15, i16 63, i16 824, i16 3840, i16 2055, i16 7, i16 256, i16 256, i16 252, i16 254, i16 -8161, i16 -4081, i16 510, i16 1020, i16 -7906, i16 -4081, i16 0, i16 0, i16 56, i16 60, i16 63, i16 31, i16 3840, i16 1792, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 0, i16 0, i16 0, i16 1, i16 3, i16 7, i16 15, i16 286, i16 62, i16 126, i16 510, i16 510, i16 8670, i16 24990, i16 -7906, i16 -7906, i16 828, i16 828, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 -16098, i16 -32482, i16 255, i16 255, i16 -7906, i16 -7906, i16 1792, i16 1792, i16 31, i16 63, i16 828, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 254, i16 254, i16 -256, i16 -256, i16 252, i16 254, i16 -8161, i16 -4081, i16 0, i16 0, i16 60, i16 62, i16 31, i16 15, i16 1792, i16 768, i16 15, i16 15, i16 15, i16 31, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 63, i16 63, i16 318, i16 828, i16 254, i16 255, i16 -2041, i16 -256, i16 508, i16 254, i16 -4081, i16 -2041, i16 828, i16 828, i16 828, i16 318, i16 31, i16 15, i16 1792, i16 768, i16 -32761, i16 7, i16 7, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 31, i16 318, i16 892, i16 0, i16 1, i16 3, i16 7, i16 7, i16 7, i16 256, i16 256, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 28800, i16 -8192, i16 -8192, i16 15, i16 31, i16 828, i16 828, i16 828, i16 31, i16 15, i16 796, i16 252, i16 254, i16 -4081, i16 -4081, i16 15, i16 510, i16 1020, i16 -3826, i16 828, i16 828, i16 828, i16 828, i16 31, i16 15, i16 1792, i16 768, i16 -4081, i16 15, i16 15, i16 15, i16 510, i16 1020, i16 -256, i16 -256, i16 15, i16 31, i16 318, i16 828, i16 828, i16 828, i16 828, i16 318, i16 252, i16 254, i16 -8161, i16 -4081, i16 -32753, i16 15, i16 15, i16 31, i16 31, i16 15, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 255, i16 255, i16 -4081, i16 -4081, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 0, i16 0, i16 0, i16 0, i16 15, i16 15, i16 15, i16 768, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 0, i16 15, i16 15, i16 15, i16 270, i16 796, i16 824, i16 1792, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 -16384, i16 -32768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 3, i16 15, i16 60, i16 828, i16 0, i16 0, i16 60, i16 240, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 15360, i16 3840, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 63, i16 63, i16 63, i16 3840, i16 3840, i16 0, i16 0, i16 0, i16 240, i16 240, i16 3312, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 60, i16 15, i16 3075, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 192, i16 240, i16 -16324, i16 60, i16 0, i16 3, i16 15, i16 60, i16 768, i16 3840, i16 0, i16 0, i16 4080, i16 4032, i16 15360, i16 -4096, i16 -16384, i16 0, i16 0, i16 0, i16 31, i16 63, i16 828, i16 3840, i16 3840, i16 7, i16 7, i16 7, i16 240, i16 248, i16 -32644, i16 -32132, i16 2040, i16 4080, i16 16064, i16 31872, i16 256, i16 256, i16 7, i16 7, i16 7, i16 256, i16 256, i16 0, i16 -4096, i16 -8192, i16 128, i16 128, i16 24704, i16 -8192, i16 -8192, i16 0, i16 31, i16 63, i16 828, i16 573, i16 573, i16 573, i16 573, i16 573, i16 248, i16 252, i16 -15812, i16 4590, i16 494, i16 4590, i16 1020, i16 1016, i16 828, i16 63, i16 31, i16 3840, i16 1792, i16 0, i16 0, i16 0, i16 32512, i16 764, i16 248, i16 -256, i16 -512, i16 0, i16 0, i16 0, i16 15, i16 31, i16 318, i16 892, i16 1020, i16 1020, i16 255, i16 255, i16 224, i16 240, i16 -32648, i16 -16324, i16 -32196, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -28928, i16 1792, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 0, i16 0, i16 28, i16 60, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 252, i16 252, i16 -256, i16 -256, i16 0, i16 0, i16 240, i16 240, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 -1024, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 -16384, i16 -16384, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -8164, i16 -3572, i16 -30976, i16 768, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 8988, i16 8988, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 60, i16 60, i16 828, i16 828, i16 828, i16 828, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -15556, i16 -15556, i16 828, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 255, i16 255, i16 16128, i16 16128, i16 12480, i16 12480, i16 12480, i16 12480, i16 252, i16 252, i16 -256, i16 -256, i16 63, i16 63, i16 3075, i16 3075, i16 3, i16 3, i16 51, i16 51, i16 252, i16 252, i16 4080, i16 4080, i16 3312, i16 3312, i16 3312, i16 3312, i16 3123, i16 3123, i16 63, i16 63, i16 31, i16 15, i16 1792, i16 768, i16 3312, i16 3312, i16 3312, i16 3312, i16 7392, i16 15552, i16 -2048, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 765, i16 255, i16 255, i16 255, i16 28, i16 60, i16 1912, i16 4080, i16 7904, i16 15552, i16 30848, i16 12480, i16 255, i16 765, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 224, i16 240, i16 248, i16 124, i16 572, i16 828, i16 3840, i16 3840, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 16128, i16 16128, i16 0, i16 0, i16 0, i16 0, i16 252, i16 252, i16 -256, i16 -256, i16 248, i16 252, i16 254, i16 2295, i16 3315, i16 3315, i16 3315, i16 3315, i16 60, i16 124, i16 1020, i16 988, i16 9116, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 15360, i16 15360, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 -6400, i16 -6400, i16 240, i16 248, i16 252, i16 254, i16 255, i16 255, i16 2295, i16 3315, i16 60, i16 60, i16 828, i16 828, i16 828, i16 956, i16 1020, i16 1020, i16 3313, i16 3312, i16 3312, i16 3312, i16 3312, i16 3312, i16 15360, i16 15360, i16 1020, i16 1020, i16 892, i16 828, i16 828, i16 828, i16 3840, i16 3840, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 240, i16 248, i16 -16324, i16 -7652, i16 -31972, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 796, i16 828, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 828, i16 2040, i16 4080, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -512, i16 -1024, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 63, i16 127, i16 510, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 224, i16 240, i16 -32648, i16 -15304, i16 -31176, i16 1592, i16 1592, i16 1592, i16 765, i16 765, i16 1020, i16 510, i16 127, i16 63, i16 7936, i16 3840, i16 1784, i16 1784, i16 17976, i16 1656, i16 764, i16 764, i16 -256, i16 -256, i16 255, i16 255, i16 1020, i16 1020, i16 1020, i16 1020, i16 255, i16 255, i16 240, i16 248, i16 -16324, i16 -7652, i16 796, i16 1848, i16 2032, i16 1784, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 16128, i16 16128, i16 -16324, i16 -7652, i16 796, i16 796, i16 796, i16 796, i16 1792, i16 1792, i16 63, i16 127, i16 2040, i16 4080, i16 1784, i16 255, i16 127, i16 63, i16 248, i16 252, i16 -15812, i16 -256, i16 3840, i16 240, i16 248, i16 252, i16 7936, i16 3840, i16 224, i16 255, i16 255, i16 127, i16 16128, i16 7936, i16 -32132, i16 -15556, i16 892, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 255, i16 255, i16 12303, i16 12303, i16 15, i16 15, i16 15, i16 15, i16 252, i16 252, i16 16320, i16 16320, i16 12480, i16 12480, i16 12480, i16 12480, i16 15, i16 15, i16 15, i16 15, i16 15, i16 15, i16 768, i16 768, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 12480, i16 -4096, i16 -4096, i16 252, i16 252, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 1020, i16 28, i16 28, i16 796, i16 796, i16 796, i16 796, i16 796, i16 796, i16 1020, i16 1020, i16 510, i16 255, i16 127, i16 63, i16 7936, i16 3840, i16 796, i16 796, i16 828, i16 1020, i16 2040, i16 4080, i16 -512, i16 -1024, i16 248, i16 248, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 124, i16 124, i16 1912, i16 1912, i16 1656, i16 1656, i16 1656, i16 1656, i16 1656, i16 572, i16 63, i16 31, i16 15, i16 7, i16 768, i16 256, i16 1656, i16 3824, i16 3824, i16 7392, i16 15552, i16 30848, i16 -4096, i16 -8192, i16 243, i16 243, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 3315, i16 156, i16 156, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 25500, i16 3315, i16 3315, i16 2295, i16 255, i16 510, i16 892, i16 16128, i16 7936, i16 25500, i16 25500, i16 9180, i16 1020, i16 1020, i16 -30856, i16 -16640, i16 7680, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 15, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 14528, i16 31, i16 63, i16 892, i16 2040, i16 4080, i16 3824, i16 15360, i16 15360, i16 4320, i16 240, i16 248, i16 -32644, i16 572, i16 828, i16 3840, i16 3840, i16 240, i16 240, i16 1272, i16 124, i16 63, i16 31, i16 15, i16 7, i16 60, i16 60, i16 892, i16 2040, i16 4080, i16 7904, i16 15552, i16 30848, i16 7, i16 7, i16 7, i16 7, i16 7, i16 7, i16 256, i16 256, i16 28800, i16 24704, i16 24704, i16 24704, i16 24704, i16 24704, i16 -8192, i16 -8192, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 1, i16 3, i16 7, i16 252, i16 252, i16 1020, i16 -31876, i16 2040, i16 4080, i16 7904, i16 15552, i16 15, i16 31, i16 318, i16 127, i16 127, i16 127, i16 7936, i16 7936, i16 30848, i16 -4096, i16 -8192, i16 252, i16 252, i16 1020, i16 -256, i16 -256, i16 31, i16 31, i16 286, i16 286, i16 286, i16 286, i16 286, i16 286, i16 224, i16 224, i16 -2048, i16 -2048, i16 -32768, i16 -32768, i16 -32768, i16 -32768, i16 286, i16 286, i16 286, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 -32768, i16 -32768, i16 -32768, i16 224, i16 224, i16 -2048, i16 -2048, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 3, i16 1, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 128, i16 192, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 224, i16 112, i16 56, i16 28, i16 14, i16 7, i16 768, i16 256, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 0, i16 0, i16 0, i16 224, i16 224, i16 2288, i16 2288, i16 3312, i16 3312, i16 3312, i16 3312, i16 0, i16 0, i16 0, i16 31, i16 31, i16 1792, i16 1792, i16 0, i16 3312, i16 3312, i16 3312, i16 7392, i16 7392, i16 -2048, i16 -2048, i16 0, i16 3, i16 7, i16 14, i16 284, i16 824, i16 1840, i16 3584, i16 3072, i16 192, i16 224, i16 -32656, i16 -16328, i16 -32740, i16 524, i16 1792, i16 768, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 0, i16 127, i16 127, i16 7936, i16 0, i16 0, i16 0, i16 0, i16 0, i16 248, i16 248, i16 -512], align 1
@title_end._title_bg_black = internal constant i16 0, align 1
@tr_gate_crc.g = internal unnamed_addr global [224 x %struct.Cell] zeroinitializer, align 1
@switch.table.main = private unnamed_addr constant [8 x i8] c"\0B\16\00\16\16\00\16\16", align 1
@switch.table.main.35 = private unnamed_addr constant [8 x i8] c"\16\00\0B\16\00\16\0B\16", align 1
@switch.table.main.36 = private unnamed_addr constant [8 x i8] c"\00\0B\16\00\16\0B\00\16", align 1
@switch.table.main.37 = private unnamed_addr constant [8 x i8] c"\1F\00\0F\1F\00\1F\0F\1F", align 1
@switch.table.main.38 = private unnamed_addr constant [8 x i8] c"\0F\1F\00\1F\1F\00\1F\1F", align 1
@switch.table.main.39 = private unnamed_addr constant [8 x i8] c"\00\0F\1F\00\1F\0F\00\1F", align 1

; Function Attrs: noreturn nounwind
define dso_local noundef i16 @main() local_unnamed_addr #0 {
  store volatile i8 -113, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8449 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8450 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8451 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8454 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8455 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8456 to ptr), align 8, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8457 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8458 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8460 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8461 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8462 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8465 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8466 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8467 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8468 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8474 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8475 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8476 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8477 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8478 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8479 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8480 to ptr), align 32, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8483 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8484 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8485 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8486 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8487 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8488 to ptr), align 8, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8489 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8490 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8491 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8493 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8494 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8495 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8496 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8497 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8498 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8499 to ptr), align 1, !tbaa !6
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) getelementptr inbounds nuw (i8, ptr @main.a, i16 176), i8 0, i64 6, i1 false)
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !12
  store volatile i8 1, ptr inttoptr (i16 8453 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 -127, ptr inttoptr (i16 16896 to ptr), align 512, !tbaa !6
  store ptr @CANVAS_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), align 1, !tbaa !13
  store i8 4, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !17
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4299), align 1, !tbaa !18
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4301), align 1, !tbaa !19
  store i8 8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4303), align 1, !tbaa !20
  store i8 6, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4304), align 1, !tbaa !21
  tail call void @llvm.memset.p0.i16(ptr noundef nonnull align 1 dereferenceable(4096) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i16 4096, i1 false), !tbaa !6
  store i16 -1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !22
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !23
  store ptr @TEXT_VT, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !24
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !26
  store i16 16384, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4308), align 1, !tbaa !27
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4310), align 1, !tbaa !6
  store i8 25, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4311), align 1, !tbaa !6
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4312), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4314), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4316), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4318), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4320), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4322), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4324), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4326), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4328), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4330), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4332), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4334), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4336), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4338), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4340), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4342), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4344), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4346), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4348), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4350), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4352), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4354), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4356), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4358), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4360), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4362), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4364), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4366), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4368), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4370), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4372), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4374), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4376), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4378), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4380), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4382), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4384), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4386), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4388), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4390), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4392), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4394), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4396), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4398), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4400), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4402), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4404), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4406), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4408), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4410), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4412), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4414), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4416), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4418), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4420), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4422), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4424), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4426), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4428), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4430), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4432), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4434), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4436), align 1, !tbaa !2
  store i16 256, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4438), align 1, !tbaa !2
  store i8 3, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !28
  %1 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !29
  %2 = icmp eq i8 %1, 0
  br i1 %2, label %4, label %3

3:                                                ; preds = %0
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !30
  br label %4

4:                                                ; preds = %3, %0
  %5 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %6 = icmp ult i8 %5, 4
  br i1 %6, label %7, label %11

7:                                                ; preds = %4
  %8 = zext nneg i8 %5 to i16
  %9 = add nuw nsw i8 %5, 1
  store i8 %9, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %10 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %8
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 196), ptr %10, align 1, !tbaa !32
  br label %11

11:                                               ; preds = %7, %4
  store volatile i8 64, ptr inttoptr (i16 8457 to ptr), align 1, !tbaa !6
  %12 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4299), align 1, !tbaa !18
  %13 = lshr i16 %12, 12
  %14 = trunc nuw nsw i16 %13 to i8
  store volatile i8 %14, ptr inttoptr (i16 8460 to ptr), align 4, !tbaa !6
  %15 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4299), align 1, !tbaa !18
  %16 = lshr i16 %15, 3
  %17 = add nuw nsw i16 %16, 256
  %18 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4301), align 1, !tbaa !19
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %18, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %19 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4303), align 1, !tbaa !20
  %20 = sub i8 0, %19
  %21 = icmp ult i8 %20, 16
  %22 = zext nneg i8 %20 to i16
  %23 = sub i8 1, %19
  %24 = icmp ult i8 %23, 16
  %25 = zext nneg i8 %23 to i16
  %26 = sub i8 2, %19
  %27 = icmp ult i8 %26, 16
  %28 = zext nneg i8 %26 to i16
  %29 = sub i8 3, %19
  %30 = icmp ult i8 %29, 16
  %31 = zext nneg i8 %29 to i16
  %32 = sub i8 4, %19
  %33 = icmp ult i8 %32, 16
  %34 = zext nneg i8 %32 to i16
  %35 = sub i8 5, %19
  %36 = icmp ult i8 %35, 16
  %37 = zext nneg i8 %35 to i16
  %38 = sub i8 6, %19
  %39 = icmp ult i8 %38, 16
  %40 = zext nneg i8 %38 to i16
  %41 = sub i8 7, %19
  %42 = icmp ult i8 %41, 16
  %43 = zext nneg i8 %41 to i16
  %44 = sub i8 8, %19
  %45 = icmp ult i8 %44, 16
  %46 = zext nneg i8 %44 to i16
  %47 = sub i8 9, %19
  %48 = icmp ult i8 %47, 16
  %49 = zext nneg i8 %47 to i16
  %50 = sub i8 10, %19
  %51 = icmp ult i8 %50, 16
  %52 = zext nneg i8 %50 to i16
  %53 = sub i8 11, %19
  %54 = icmp ult i8 %53, 16
  %55 = zext nneg i8 %53 to i16
  %56 = sub i8 12, %19
  %57 = icmp ult i8 %56, 16
  %58 = zext nneg i8 %56 to i16
  %59 = sub i8 13, %19
  %60 = icmp ult i8 %59, 16
  %61 = zext nneg i8 %59 to i16
  %62 = sub i8 14, %19
  %63 = icmp ult i8 %62, 16
  %64 = zext nneg i8 %62 to i16
  %65 = sub i8 15, %19
  %66 = icmp ult i8 %65, 16
  %67 = zext nneg i8 %65 to i16
  %68 = sub i8 16, %19
  %69 = icmp ult i8 %68, 16
  %70 = zext nneg i8 %68 to i16
  %71 = sub i8 17, %19
  %72 = icmp ult i8 %71, 16
  %73 = zext nneg i8 %71 to i16
  %74 = sub i8 18, %19
  %75 = icmp ult i8 %74, 16
  %76 = zext nneg i8 %74 to i16
  %77 = sub i8 19, %19
  %78 = icmp ult i8 %77, 16
  %79 = zext nneg i8 %77 to i16
  %80 = sub i8 20, %19
  %81 = icmp ult i8 %80, 16
  %82 = zext nneg i8 %80 to i16
  %83 = sub i8 21, %19
  %84 = icmp ult i8 %83, 16
  %85 = zext nneg i8 %83 to i16
  %86 = sub i8 22, %19
  %87 = icmp ult i8 %86, 16
  %88 = zext nneg i8 %86 to i16
  %89 = sub i8 23, %19
  %90 = icmp ult i8 %89, 16
  %91 = zext nneg i8 %89 to i16
  %92 = sub i8 24, %19
  %93 = icmp ult i8 %92, 16
  %94 = zext nneg i8 %92 to i16
  %95 = sub i8 25, %19
  %96 = icmp ult i8 %95, 16
  %97 = zext nneg i8 %95 to i16
  %98 = sub i8 26, %19
  %99 = icmp ult i8 %98, 16
  %100 = zext nneg i8 %98 to i16
  %101 = sub i8 27, %19
  %102 = icmp ult i8 %101, 16
  %103 = zext nneg i8 %101 to i16
  %104 = sub i8 28, %19
  %105 = icmp ult i8 %104, 16
  %106 = zext nneg i8 %104 to i16
  %107 = sub i8 29, %19
  %108 = icmp ult i8 %107, 16
  %109 = zext nneg i8 %107 to i16
  %110 = sub i8 30, %19
  %111 = icmp ult i8 %110, 16
  %112 = zext nneg i8 %110 to i16
  %113 = sub i8 31, %19
  %114 = icmp ult i8 %113, 16
  %115 = zext nneg i8 %113 to i16
  br label %116

116:                                              ; preds = %255, %11
  %117 = phi i8 [ 0, %11 ], [ %257, %255 ]
  %118 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4304), align 1
  %119 = sub i8 %117, %118
  %120 = freeze i8 %119
  %121 = icmp ult i8 %120, 16
  %122 = shl nuw i8 %120, 4
  %123 = zext i8 %122 to i16
  %124 = add nuw nsw i16 %16, %123
  br i1 %121, label %126, label %125

125:                                              ; preds = %116
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 %17, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br label %255

126:                                              ; preds = %116
  br i1 %21, label %127, label %129

127:                                              ; preds = %126
  %128 = add nuw nsw i16 %124, %22
  br label %129

129:                                              ; preds = %127, %126
  %130 = phi i16 [ %128, %127 ], [ %17, %126 ]
  store volatile i16 %130, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %24, label %131, label %133

131:                                              ; preds = %129
  %132 = add nuw nsw i16 %124, %25
  br label %133

133:                                              ; preds = %131, %129
  %134 = phi i16 [ %132, %131 ], [ %17, %129 ]
  store volatile i16 %134, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %27, label %135, label %137

135:                                              ; preds = %133
  %136 = add nuw nsw i16 %124, %28
  br label %137

137:                                              ; preds = %135, %133
  %138 = phi i16 [ %136, %135 ], [ %17, %133 ]
  store volatile i16 %138, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %30, label %139, label %141

139:                                              ; preds = %137
  %140 = add nuw nsw i16 %124, %31
  br label %141

141:                                              ; preds = %139, %137
  %142 = phi i16 [ %140, %139 ], [ %17, %137 ]
  store volatile i16 %142, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %33, label %143, label %145

143:                                              ; preds = %141
  %144 = add nuw nsw i16 %124, %34
  br label %145

145:                                              ; preds = %143, %141
  %146 = phi i16 [ %144, %143 ], [ %17, %141 ]
  store volatile i16 %146, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %36, label %147, label %149

147:                                              ; preds = %145
  %148 = add nuw nsw i16 %124, %37
  br label %149

149:                                              ; preds = %147, %145
  %150 = phi i16 [ %148, %147 ], [ %17, %145 ]
  store volatile i16 %150, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %39, label %151, label %153

151:                                              ; preds = %149
  %152 = add nuw nsw i16 %124, %40
  br label %153

153:                                              ; preds = %151, %149
  %154 = phi i16 [ %152, %151 ], [ %17, %149 ]
  store volatile i16 %154, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %42, label %155, label %157

155:                                              ; preds = %153
  %156 = add nuw nsw i16 %124, %43
  br label %157

157:                                              ; preds = %155, %153
  %158 = phi i16 [ %156, %155 ], [ %17, %153 ]
  store volatile i16 %158, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %45, label %159, label %161

159:                                              ; preds = %157
  %160 = add nuw nsw i16 %124, %46
  br label %161

161:                                              ; preds = %159, %157
  %162 = phi i16 [ %160, %159 ], [ %17, %157 ]
  store volatile i16 %162, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %48, label %163, label %165

163:                                              ; preds = %161
  %164 = add nuw nsw i16 %124, %49
  br label %165

165:                                              ; preds = %163, %161
  %166 = phi i16 [ %164, %163 ], [ %17, %161 ]
  store volatile i16 %166, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %51, label %167, label %169

167:                                              ; preds = %165
  %168 = add nuw nsw i16 %124, %52
  br label %169

169:                                              ; preds = %167, %165
  %170 = phi i16 [ %168, %167 ], [ %17, %165 ]
  store volatile i16 %170, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %54, label %171, label %173

171:                                              ; preds = %169
  %172 = add nuw nsw i16 %124, %55
  br label %173

173:                                              ; preds = %171, %169
  %174 = phi i16 [ %172, %171 ], [ %17, %169 ]
  store volatile i16 %174, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %57, label %175, label %177

175:                                              ; preds = %173
  %176 = add nuw nsw i16 %124, %58
  br label %177

177:                                              ; preds = %175, %173
  %178 = phi i16 [ %176, %175 ], [ %17, %173 ]
  store volatile i16 %178, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %60, label %179, label %181

179:                                              ; preds = %177
  %180 = add nuw nsw i16 %124, %61
  br label %181

181:                                              ; preds = %179, %177
  %182 = phi i16 [ %180, %179 ], [ %17, %177 ]
  store volatile i16 %182, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %63, label %183, label %185

183:                                              ; preds = %181
  %184 = add nuw nsw i16 %124, %64
  br label %185

185:                                              ; preds = %183, %181
  %186 = phi i16 [ %184, %183 ], [ %17, %181 ]
  store volatile i16 %186, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %66, label %187, label %189

187:                                              ; preds = %185
  %188 = add nuw nsw i16 %124, %67
  br label %189

189:                                              ; preds = %187, %185
  %190 = phi i16 [ %188, %187 ], [ %17, %185 ]
  store volatile i16 %190, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %69, label %191, label %193

191:                                              ; preds = %189
  %192 = add nuw nsw i16 %124, %70
  br label %193

193:                                              ; preds = %191, %189
  %194 = phi i16 [ %192, %191 ], [ %17, %189 ]
  store volatile i16 %194, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %72, label %195, label %197

195:                                              ; preds = %193
  %196 = add nuw nsw i16 %124, %73
  br label %197

197:                                              ; preds = %195, %193
  %198 = phi i16 [ %196, %195 ], [ %17, %193 ]
  store volatile i16 %198, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %75, label %199, label %201

199:                                              ; preds = %197
  %200 = add nuw nsw i16 %124, %76
  br label %201

201:                                              ; preds = %199, %197
  %202 = phi i16 [ %200, %199 ], [ %17, %197 ]
  store volatile i16 %202, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %78, label %203, label %205

203:                                              ; preds = %201
  %204 = add nuw nsw i16 %124, %79
  br label %205

205:                                              ; preds = %203, %201
  %206 = phi i16 [ %204, %203 ], [ %17, %201 ]
  store volatile i16 %206, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %81, label %207, label %209

207:                                              ; preds = %205
  %208 = add nuw nsw i16 %124, %82
  br label %209

209:                                              ; preds = %207, %205
  %210 = phi i16 [ %208, %207 ], [ %17, %205 ]
  store volatile i16 %210, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %84, label %211, label %213

211:                                              ; preds = %209
  %212 = add nuw nsw i16 %124, %85
  br label %213

213:                                              ; preds = %211, %209
  %214 = phi i16 [ %212, %211 ], [ %17, %209 ]
  store volatile i16 %214, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %87, label %215, label %217

215:                                              ; preds = %213
  %216 = add nuw nsw i16 %124, %88
  br label %217

217:                                              ; preds = %215, %213
  %218 = phi i16 [ %216, %215 ], [ %17, %213 ]
  store volatile i16 %218, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %90, label %219, label %221

219:                                              ; preds = %217
  %220 = add nuw nsw i16 %124, %91
  br label %221

221:                                              ; preds = %219, %217
  %222 = phi i16 [ %220, %219 ], [ %17, %217 ]
  store volatile i16 %222, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %93, label %223, label %225

223:                                              ; preds = %221
  %224 = add nuw nsw i16 %124, %94
  br label %225

225:                                              ; preds = %223, %221
  %226 = phi i16 [ %224, %223 ], [ %17, %221 ]
  store volatile i16 %226, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %96, label %227, label %229

227:                                              ; preds = %225
  %228 = add nuw nsw i16 %124, %97
  br label %229

229:                                              ; preds = %227, %225
  %230 = phi i16 [ %228, %227 ], [ %17, %225 ]
  store volatile i16 %230, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %99, label %231, label %233

231:                                              ; preds = %229
  %232 = add nuw nsw i16 %124, %100
  br label %233

233:                                              ; preds = %231, %229
  %234 = phi i16 [ %232, %231 ], [ %17, %229 ]
  store volatile i16 %234, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %102, label %235, label %237

235:                                              ; preds = %233
  %236 = add nuw nsw i16 %124, %103
  br label %237

237:                                              ; preds = %235, %233
  %238 = phi i16 [ %236, %235 ], [ %17, %233 ]
  store volatile i16 %238, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %105, label %239, label %241

239:                                              ; preds = %237
  %240 = add nuw nsw i16 %124, %106
  br label %241

241:                                              ; preds = %239, %237
  %242 = phi i16 [ %240, %239 ], [ %17, %237 ]
  store volatile i16 %242, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %108, label %243, label %245

243:                                              ; preds = %241
  %244 = add nuw nsw i16 %124, %109
  br label %245

245:                                              ; preds = %243, %241
  %246 = phi i16 [ %244, %243 ], [ %17, %241 ]
  store volatile i16 %246, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %111, label %247, label %249

247:                                              ; preds = %245
  %248 = add nuw nsw i16 %124, %112
  br label %249

249:                                              ; preds = %247, %245
  %250 = phi i16 [ %248, %247 ], [ %17, %245 ]
  store volatile i16 %250, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br i1 %114, label %251, label %255

251:                                              ; preds = %249
  %252 = add nuw nsw i16 %124, %115
  br label %255

253:                                              ; preds = %255
  %254 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4299), align 1, !tbaa !18
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %254, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %259

255:                                              ; preds = %251, %249, %125
  %256 = phi i16 [ %17, %125 ], [ %252, %251 ], [ %17, %249 ]
  store volatile i16 %256, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %257 = add nuw nsw i8 %117, 1
  %258 = icmp eq i8 %257, 32
  br i1 %258, label %253, label %116, !llvm.loop !34

259:                                              ; preds = %259, %253
  %260 = phi i16 [ 0, %253 ], [ %261, %259 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %261 = add nuw nsw i16 %260, 1
  %262 = icmp eq i16 %261, 2056
  br i1 %262, label %263, label %259, !llvm.loop !36

263:                                              ; preds = %259
  %264 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !37
  %265 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 198), align 1, !tbaa !38
  %266 = or i8 %265, %264
  store i8 %266, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !37
  store volatile i8 %266, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %267 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !29
  %268 = icmp eq i8 %267, 0
  br i1 %268, label %270, label %269

269:                                              ; preds = %263
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !30
  br label %270

270:                                              ; preds = %269, %263
  %271 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %272 = icmp ult i8 %271, 4
  br i1 %272, label %273, label %277

273:                                              ; preds = %270
  %274 = zext nneg i8 %271 to i16
  %275 = add nuw nsw i8 %271, 1
  store i8 %275, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %276 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %274
  store ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr %276, align 1, !tbaa !32
  br label %277

277:                                              ; preds = %273, %270
  %278 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), align 1, !tbaa !39
  %279 = load ptr, ptr %278, align 1, !tbaa !40
  tail call void %279(ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 4305), ptr noundef nonnull getelementptr inbounds nuw (i8, ptr @main.a, i16 178)) #10, !inline_history !42
  %280 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !37
  %281 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4307), align 1, !tbaa !38
  %282 = or i8 %281, %280
  store i8 %282, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !37
  store volatile i8 %282, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  %283 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %284 = icmp ugt i8 %283, 15
  br i1 %284, label %296, label %285

285:                                              ; preds = %277
  %286 = zext nneg i8 %283 to i16
  %287 = add nuw nsw i8 %283, 1
  store i8 %287, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %288 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %286
  %289 = getelementptr inbounds nuw i8, ptr %288, i16 10
  store i8 1, ptr %289, align 1, !tbaa !44
  store i16 0, ptr %288, align 1, !tbaa !46
  %290 = getelementptr inbounds nuw i8, ptr %288, i16 9
  store i8 0, ptr %290, align 1, !tbaa !47
  %291 = getelementptr inbounds nuw i8, ptr %288, i16 7
  store i8 34, ptr %291, align 1, !tbaa !48
  %292 = getelementptr inbounds nuw i8, ptr %288, i16 8
  store i8 0, ptr %292, align 1, !tbaa !49
  %293 = getelementptr inbounds nuw i8, ptr %288, i16 2
  store i16 ptrtoint (ptr @pal to i16), ptr %293, align 1, !tbaa !50
  %294 = getelementptr inbounds nuw i8, ptr %288, i16 6
  store i8 0, ptr %294, align 1, !tbaa !51
  %295 = getelementptr inbounds nuw i8, ptr %288, i16 4
  store i16 8, ptr %295, align 1, !tbaa !52
  br label %296

296:                                              ; preds = %285, %277
  br label %297

297:                                              ; preds = %296, %297
  %298 = phi i16 [ %312, %297 ], [ 0, %296 ]
  %299 = phi i16 [ %306, %297 ], [ -21279, %296 ]
  %300 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %298
  %301 = shl i16 %299, 7
  %302 = xor i16 %301, %299
  %303 = lshr i16 %302, 9
  %304 = xor i16 %303, %302
  %305 = shl i16 %304, 8
  %306 = xor i16 %305, %304
  %307 = trunc i16 %304 to i8
  %308 = lshr i16 %306, 8
  %309 = trunc nuw i16 %308 to i8
  %310 = and i8 %309, 15
  store i8 %307, ptr %300, align 1, !tbaa !6
  %311 = getelementptr inbounds nuw i8, ptr %300, i16 1
  store i8 %310, ptr %311, align 1, !tbaa !6
  %312 = add nuw nsw i16 %298, 1
  %313 = icmp eq i16 %312, 256
  br i1 %313, label %314, label %297, !llvm.loop !53

314:                                              ; preds = %297
  %315 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4442), align 1
  %316 = or i8 %315, 15
  store i8 %316, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4442), align 1
  %317 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4472), align 1
  %318 = or i8 %317, 15
  store i8 %318, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4472), align 1
  %319 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4922), align 1
  %320 = or i8 %319, 15
  store i8 %320, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4922), align 1
  %321 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4952), align 1
  %322 = or i8 %321, 15
  store i8 %322, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4952), align 1
  %323 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4714), align 1
  %324 = or i8 %323, 15
  store i8 %324, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4714), align 1
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(4098) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i64 4098, i1 false)
  store i16 255, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !23
  br label %325

325:                                              ; preds = %332, %314
  %326 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4442), %314 ], [ %335, %332 ]
  %327 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), %314 ], [ %334, %332 ]
  %328 = phi i8 [ 0, %314 ], [ %333, %332 ]
  %329 = zext nneg i8 %328 to i16
  %330 = shl nuw nsw i16 %329, 3
  %331 = or disjoint i16 %330, 7
  br label %337

332:                                              ; preds = %364
  %333 = add nuw nsw i8 %328, 1
  %334 = getelementptr i8, ptr %327, i16 32
  %335 = getelementptr i8, ptr %326, i16 32
  %336 = icmp eq i8 %333, 16
  br i1 %336, label %368, label %325, !llvm.loop !54

337:                                              ; preds = %364, %325
  %338 = phi i8 [ 0, %325 ], [ %367, %364 ]
  %339 = phi i8 [ 0, %325 ], [ %365, %364 ]
  %340 = zext nneg i8 %339 to i16
  %341 = zext nneg i8 %338 to i16
  %342 = getelementptr i8, ptr %327, i16 %341
  %343 = load i8, ptr %342, align 1, !tbaa !6
  %344 = getelementptr i8, ptr %326, i16 %341
  %345 = load i8, ptr %344, align 1, !tbaa !6
  %346 = and i8 %345, 15
  %347 = icmp samesign ugt i8 %346, 10
  br i1 %347, label %351, label %348

348:                                              ; preds = %337
  %349 = icmp samesign ugt i8 %346, 4
  %350 = select i1 %349, i8 2, i8 1
  br label %351

351:                                              ; preds = %348, %337
  %352 = phi i8 [ %350, %348 ], [ 3, %337 ]
  %353 = shl nuw nsw i16 %340, 3
  %354 = and i8 %343, 1
  %355 = icmp eq i8 %354, 0
  %356 = or disjoint i16 %353, 7
  %357 = and i8 %343, 2
  %358 = icmp eq i8 %357, 0
  br i1 %355, label %359, label %360

359:                                              ; preds = %351
  tail call fastcc void @canvas_line(i16 noundef %353, i16 noundef %330, i16 noundef %356, i16 noundef %331, i8 noundef zeroext %352)
  br i1 %358, label %364, label %361

360:                                              ; preds = %351
  tail call fastcc void @canvas_line(i16 noundef %356, i16 noundef %330, i16 noundef %353, i16 noundef %331, i8 noundef zeroext %352)
  br i1 %358, label %364, label %361

361:                                              ; preds = %360, %359
  %362 = phi i16 [ %356, %359 ], [ %353, %360 ]
  %363 = phi i16 [ %353, %359 ], [ %356, %360 ]
  tail call fastcc void @canvas_line(i16 noundef %362, i16 noundef %330, i16 noundef %363, i16 noundef %331, i8 noundef zeroext 1)
  br label %364

364:                                              ; preds = %361, %360, %359
  %365 = add nuw nsw i8 %339, 1
  %366 = icmp eq i8 %365, 16
  %367 = add nuw nsw i8 %338, 2
  br i1 %366, label %332, label %337, !llvm.loop !55

368:                                              ; preds = %332, %378
  %369 = phi i8 [ %386, %378 ], [ 0, %332 ]
  %370 = phi i8 [ %385, %378 ], [ 0, %332 ]
  %371 = phi i8 [ %384, %378 ], [ 84, %332 ]
  %372 = zext i8 %371 to i16
  %373 = icmp ugt i8 %371, 31
  br i1 %373, label %374, label %378

374:                                              ; preds = %368
  %375 = icmp ult i8 %371, 96
  br i1 %375, label %376, label %378

376:                                              ; preds = %374
  %377 = add nuw nsw i16 %372, 224
  br label %378

378:                                              ; preds = %376, %374, %368
  %379 = phi i16 [ %377, %376 ], [ 256, %374 ], [ 256, %368 ]
  %380 = zext nneg i8 %370 to i16
  %381 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4316), i16 %380
  store i16 %379, ptr %381, align 1, !tbaa !2
  %382 = zext nneg i8 %369 to i16
  %383 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @.str.2, i16 1), i16 %382
  %384 = load i8, ptr %383, align 1, !tbaa !6
  %385 = add nuw nsw i8 %370, 2
  %386 = add nuw nsw i8 %369, 1
  %387 = icmp eq i8 %386, 25
  br i1 %387, label %388, label %368, !llvm.loop !56

388:                                              ; preds = %378
  %389 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !28
  br label %390

390:                                              ; preds = %400, %388
  %391 = phi i8 [ 0, %388 ], [ %408, %400 ]
  %392 = phi i8 [ 0, %388 ], [ %407, %400 ]
  %393 = phi i8 [ 54, %388 ], [ %406, %400 ]
  %394 = zext i8 %393 to i16
  %395 = icmp ugt i8 %393, 31
  br i1 %395, label %396, label %400

396:                                              ; preds = %390
  %397 = icmp ult i8 %393, 96
  br i1 %397, label %398, label %400

398:                                              ; preds = %396
  %399 = add nuw nsw i16 %394, 224
  br label %400

400:                                              ; preds = %398, %396, %390
  %401 = phi i16 [ %399, %398 ], [ 256, %396 ], [ 256, %390 ]
  %402 = zext nneg i8 %392 to i16
  %403 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4378), i16 %402
  store i16 %401, ptr %403, align 1, !tbaa !2
  %404 = zext nneg i8 %391 to i16
  %405 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @.str.3, i16 1), i16 %404
  %406 = load i8, ptr %405, align 1, !tbaa !6
  %407 = add nuw nsw i8 %392, 2
  %408 = add nuw nsw i8 %391, 1
  %409 = icmp eq i8 %408, 29
  br i1 %409, label %410, label %390, !llvm.loop !56

410:                                              ; preds = %400
  %411 = or i8 %389, 3
  store i8 %411, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4440), align 1, !tbaa !28
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4953), align 1, !tbaa !57
  store ptr @TITLE_VT, ptr @main.title, align 1, !tbaa !59
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !63
  store ptr @.str, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 3), align 1, !tbaa !64
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 5), align 1, !tbaa !65
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 7), align 1, !tbaa !66
  store i8 9, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 11), align 1, !tbaa !67
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 9), align 1, !tbaa !68
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 12), align 1, !tbaa !69
  store i16 96, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 13), align 1, !tbaa !70
  store i16 112, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 15), align 1, !tbaa !71
  store i16 16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 17), align 1, !tbaa !72
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 28), align 1, !tbaa !73
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !74
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !75
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !76
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !77
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !78
  store i16 32767, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 34), align 1, !tbaa !79
  store i16 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 36), align 1, !tbaa !80
  %412 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !37
  %413 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !29
  %414 = icmp eq i8 %413, 0
  br i1 %414, label %416, label %415

415:                                              ; preds = %410
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 193), align 1, !tbaa !30
  br label %416

416:                                              ; preds = %415, %410
  %417 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %418 = icmp ult i8 %417, 4
  br i1 %418, label %419, label %423

419:                                              ; preds = %416
  %420 = zext nneg i8 %417 to i16
  %421 = add nuw nsw i8 %417, 1
  store i8 %421, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %422 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %420
  store ptr @main.title, ptr %422, align 1, !tbaa !32
  br label %423

423:                                              ; preds = %419, %416
  tail call void @_title_reserve(ptr noundef nonnull @main.title, ptr nonnull poison) #10, !inline_history !81
  %424 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !37
  %425 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !38
  %426 = or i8 %425, %424
  store volatile i8 %426, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store i8 %412, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !82
  store i8 2, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !37
  store volatile i8 2, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 24, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !12
  br label %427

427:                                              ; preds = %455, %423
  %428 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %429 = icmp eq i8 %428, 0
  br i1 %429, label %441, label %430

430:                                              ; preds = %427, %430
  %431 = phi i8 [ %438, %430 ], [ 0, %427 ]
  %432 = zext i8 %431 to i16
  %433 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %432
  %434 = load ptr, ptr %433, align 1, !tbaa !32
  %435 = load ptr, ptr %434, align 1, !tbaa !39
  %436 = getelementptr inbounds nuw i8, ptr %435, i16 2
  %437 = load ptr, ptr %436, align 1, !tbaa !83
  tail call void %437(ptr noundef nonnull %434, ptr noundef nonnull @main.a) #10, !inline_history !84
  %438 = add nuw i8 %431, 1
  %439 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %440 = icmp ult i8 %438, %439
  br i1 %440, label %430, label %441, !llvm.loop !85

441:                                              ; preds = %430, %427
  %442 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %443

443:                                              ; preds = %443, %441
  %444 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %445 = icmp sgt i8 %444, -1
  br i1 %445, label %443, label %446, !llvm.loop !86

446:                                              ; preds = %443
  tail call fastcc void @upq_flush()
  %447 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  %448 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !12
  %449 = icmp ult i8 %447, %448
  br i1 %449, label %452, label %450

450:                                              ; preds = %446
  %451 = icmp ugt i8 %447, %448
  br i1 %451, label %452, label %455

452:                                              ; preds = %450, %446
  %453 = phi i8 [ 1, %446 ], [ -1, %450 ]
  %454 = add i8 %453, %447
  store i8 %454, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  br label %455

455:                                              ; preds = %452, %450
  %456 = phi i8 [ %447, %450 ], [ %454, %452 ]
  %457 = and i8 %456, 15
  store volatile i8 %457, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !29
  %458 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  %459 = icmp eq i8 %458, 15
  br i1 %459, label %460, label %427, !llvm.loop !87

460:                                              ; preds = %455
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !77
  %461 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !78
  %462 = icmp eq i8 %461, -1
  br i1 %462, label %500, label %463

463:                                              ; preds = %460, %492
  %464 = phi i8 [ %495, %492 ], [ 0, %460 ]
  %465 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %466 = icmp eq i8 %465, 0
  br i1 %466, label %478, label %467

467:                                              ; preds = %463, %467
  %468 = phi i8 [ %475, %467 ], [ 0, %463 ]
  %469 = zext i8 %468 to i16
  %470 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %469
  %471 = load ptr, ptr %470, align 1, !tbaa !32
  %472 = load ptr, ptr %471, align 1, !tbaa !39
  %473 = getelementptr inbounds nuw i8, ptr %472, i16 2
  %474 = load ptr, ptr %473, align 1, !tbaa !83
  tail call void %474(ptr noundef nonnull %471, ptr noundef nonnull @main.a) #10, !inline_history !88
  %475 = add nuw i8 %468, 1
  %476 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %477 = icmp ult i8 %475, %476
  br i1 %477, label %467, label %478, !llvm.loop !85

478:                                              ; preds = %467, %463
  %479 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %480

480:                                              ; preds = %480, %478
  %481 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %482 = icmp sgt i8 %481, -1
  br i1 %482, label %480, label %483, !llvm.loop !86

483:                                              ; preds = %480
  tail call fastcc void @upq_flush()
  %484 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  %485 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !12
  %486 = icmp ult i8 %484, %485
  br i1 %486, label %489, label %487

487:                                              ; preds = %483
  %488 = icmp ugt i8 %484, %485
  br i1 %488, label %489, label %492

489:                                              ; preds = %487, %483
  %490 = phi i8 [ 1, %483 ], [ -1, %487 ]
  %491 = add i8 %490, %484
  store i8 %491, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  br label %492

492:                                              ; preds = %489, %487
  %493 = phi i8 [ %484, %487 ], [ %491, %489 ]
  %494 = and i8 %493, 15
  store volatile i8 %494, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !29
  %495 = add nuw i8 %464, 1
  %496 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 25), align 1, !tbaa !78
  %497 = icmp ne i8 %496, -1
  %498 = icmp ult i8 %464, -57
  %499 = select i1 %497, i1 %498, i1 false
  br i1 %499, label %463, label %500, !llvm.loop !89

500:                                              ; preds = %492, %460
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 30), align 1, !tbaa !77
  br label %501

501:                                              ; preds = %531, %500
  %502 = phi i16 [ 90, %500 ], [ %503, %531 ]
  %503 = add nsw i16 %502, -1
  %504 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %505 = icmp eq i8 %504, 0
  br i1 %505, label %517, label %506

506:                                              ; preds = %501, %506
  %507 = phi i8 [ %514, %506 ], [ 0, %501 ]
  %508 = zext i8 %507 to i16
  %509 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %508
  %510 = load ptr, ptr %509, align 1, !tbaa !32
  %511 = load ptr, ptr %510, align 1, !tbaa !39
  %512 = getelementptr inbounds nuw i8, ptr %511, i16 2
  %513 = load ptr, ptr %512, align 1, !tbaa !83
  tail call void %513(ptr noundef nonnull %510, ptr noundef nonnull @main.a) #10, !inline_history !90
  %514 = add nuw i8 %507, 1
  %515 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %516 = icmp ult i8 %514, %515
  br i1 %516, label %506, label %517, !llvm.loop !85

517:                                              ; preds = %506, %501
  %518 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %519

519:                                              ; preds = %519, %517
  %520 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %521 = icmp sgt i8 %520, -1
  br i1 %521, label %519, label %522, !llvm.loop !86

522:                                              ; preds = %519
  tail call fastcc void @upq_flush()
  %523 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  %524 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !12
  %525 = icmp ult i8 %523, %524
  br i1 %525, label %528, label %526

526:                                              ; preds = %522
  %527 = icmp ugt i8 %523, %524
  br i1 %527, label %528, label %531

528:                                              ; preds = %526, %522
  %529 = phi i8 [ 1, %522 ], [ -1, %526 ]
  %530 = add i8 %529, %523
  store i8 %530, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  br label %531

531:                                              ; preds = %528, %526
  %532 = phi i8 [ %523, %526 ], [ %530, %528 ]
  %533 = and i8 %532, 15
  store volatile i8 %533, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !29
  %534 = icmp eq i16 %503, 0
  br i1 %534, label %535, label %501, !llvm.loop !91

535:                                              ; preds = %531
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !75
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 32), align 1, !tbaa !76
  br label %539

536:                                              ; preds = %568
  %537 = add nuw nsw i8 %540, 1
  %538 = icmp eq i8 %537, 90
  br i1 %538, label %573, label %539, !llvm.loop !92

539:                                              ; preds = %536, %535
  %540 = phi i8 [ 0, %535 ], [ %537, %536 ]
  %541 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %542 = icmp eq i8 %541, 0
  br i1 %542, label %554, label %543

543:                                              ; preds = %539, %543
  %544 = phi i8 [ %551, %543 ], [ 0, %539 ]
  %545 = zext i8 %544 to i16
  %546 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %545
  %547 = load ptr, ptr %546, align 1, !tbaa !32
  %548 = load ptr, ptr %547, align 1, !tbaa !39
  %549 = getelementptr inbounds nuw i8, ptr %548, i16 2
  %550 = load ptr, ptr %549, align 1, !tbaa !83
  tail call void %550(ptr noundef nonnull %547, ptr noundef nonnull @main.a) #10, !inline_history !93
  %551 = add nuw i8 %544, 1
  %552 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %553 = icmp ult i8 %551, %552
  br i1 %553, label %543, label %554, !llvm.loop !85

554:                                              ; preds = %543, %539
  %555 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %556

556:                                              ; preds = %556, %554
  %557 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %558 = icmp sgt i8 %557, -1
  br i1 %558, label %556, label %559, !llvm.loop !86

559:                                              ; preds = %556
  tail call fastcc void @upq_flush()
  %560 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  %561 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !12
  %562 = icmp ult i8 %560, %561
  br i1 %562, label %565, label %563

563:                                              ; preds = %559
  %564 = icmp ugt i8 %560, %561
  br i1 %564, label %565, label %568

565:                                              ; preds = %563, %559
  %566 = phi i8 [ 1, %559 ], [ -1, %563 ]
  %567 = add i8 %566, %560
  store i8 %567, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  br label %568

568:                                              ; preds = %565, %563
  %569 = phi i8 [ %560, %563 ], [ %567, %565 ]
  %570 = and i8 %569, 15
  store volatile i8 %570, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !29
  %571 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 19), align 1, !tbaa !94
  %572 = icmp sgt i16 %571, 3583
  br i1 %572, label %573, label %536

573:                                              ; preds = %568, %536
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 31), align 1, !tbaa !75
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !12
  %574 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  %575 = icmp eq i8 %574, 0
  br i1 %575, label %609, label %576

576:                                              ; preds = %573, %604
  %577 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %578 = icmp eq i8 %577, 0
  br i1 %578, label %590, label %579

579:                                              ; preds = %576, %579
  %580 = phi i8 [ %587, %579 ], [ 0, %576 ]
  %581 = zext i8 %580 to i16
  %582 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %581
  %583 = load ptr, ptr %582, align 1, !tbaa !32
  %584 = load ptr, ptr %583, align 1, !tbaa !39
  %585 = getelementptr inbounds nuw i8, ptr %584, i16 2
  %586 = load ptr, ptr %585, align 1, !tbaa !83
  tail call void %586(ptr noundef nonnull %583, ptr noundef nonnull @main.a) #10, !inline_history !95
  %587 = add nuw i8 %580, 1
  %588 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %589 = icmp ult i8 %587, %588
  br i1 %589, label %579, label %590, !llvm.loop !85

590:                                              ; preds = %579, %576
  %591 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %592

592:                                              ; preds = %592, %590
  %593 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %594 = icmp sgt i8 %593, -1
  br i1 %594, label %592, label %595, !llvm.loop !86

595:                                              ; preds = %592
  tail call fastcc void @upq_flush()
  %596 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  %597 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !12
  %598 = icmp ult i8 %596, %597
  br i1 %598, label %601, label %599

599:                                              ; preds = %595
  %600 = icmp ugt i8 %596, %597
  br i1 %600, label %601, label %604

601:                                              ; preds = %599, %595
  %602 = phi i8 [ 1, %595 ], [ -1, %599 ]
  %603 = add i8 %602, %596
  store i8 %603, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  br label %604

604:                                              ; preds = %601, %599
  %605 = phi i8 [ %596, %599 ], [ %603, %601 ]
  %606 = and i8 %605, 15
  store volatile i8 %606, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !29
  %607 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  %608 = icmp eq i8 %607, 0
  br i1 %608, label %609, label %576, !llvm.loop !87

609:                                              ; preds = %604, %573
  %610 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 33), align 1, !tbaa !82
  %611 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !37
  %612 = or i8 %611, %610
  %613 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 2), align 1, !tbaa !38
  %614 = xor i8 %613, -1
  %615 = and i8 %612, %614
  store i8 %615, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 191), align 1, !tbaa !37
  store volatile i8 %615, ptr inttoptr (i16 8492 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 16908 to ptr), align 4, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8463 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @main.title, i16 29), align 1, !tbaa !74
  %616 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %617 = icmp ugt i8 %616, 15
  br i1 %617, label %629, label %618

618:                                              ; preds = %609
  %619 = zext nneg i8 %616 to i16
  %620 = add nuw nsw i8 %616, 1
  store i8 %620, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %621 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %619
  %622 = getelementptr inbounds nuw i8, ptr %621, i16 10
  store i8 1, ptr %622, align 1, !tbaa !44
  store i16 0, ptr %621, align 1, !tbaa !46
  %623 = getelementptr inbounds nuw i8, ptr %621, i16 9
  store i8 0, ptr %623, align 1, !tbaa !47
  %624 = getelementptr inbounds nuw i8, ptr %621, i16 7
  store i8 34, ptr %624, align 1, !tbaa !48
  %625 = getelementptr inbounds nuw i8, ptr %621, i16 8
  store i8 0, ptr %625, align 1, !tbaa !49
  %626 = getelementptr inbounds nuw i8, ptr %621, i16 2
  store i16 ptrtoint (ptr @title_end._title_bg_black to i16), ptr %626, align 1, !tbaa !50
  %627 = getelementptr inbounds nuw i8, ptr %621, i16 6
  store i8 0, ptr %627, align 1, !tbaa !51
  %628 = getelementptr inbounds nuw i8, ptr %621, i16 4
  store i16 2, ptr %628, align 1, !tbaa !52
  br label %629

629:                                              ; preds = %609, %618
  store i8 15, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !12
  br label %630

630:                                              ; preds = %630, %629
  %631 = phi ptr [ getelementptr inbounds nuw (i8, ptr @tr_gate_crc.g, i16 1), %629 ], [ %827, %630 ]
  %632 = phi ptr [ @tr_gate_crc.g, %629 ], [ %826, %630 ]
  %633 = phi i8 [ 0, %629 ], [ %825, %630 ]
  %634 = phi i16 [ -21279, %629 ], [ %819, %630 ]
  %635 = shl i16 %634, 7
  %636 = xor i16 %635, %634
  %637 = lshr i16 %636, 9
  %638 = xor i16 %637, %636
  %639 = shl i16 %638, 8
  %640 = xor i16 %639, %638
  %641 = trunc i16 %638 to i8
  %642 = lshr i16 %640, 8
  %643 = trunc nuw i16 %642 to i8
  %644 = and i8 %643, 15
  store i8 %641, ptr %632, align 1, !tbaa !6
  store i8 %644, ptr %631, align 1, !tbaa !6
  %645 = getelementptr i8, ptr %632, i16 2
  %646 = shl i16 %640, 7
  %647 = xor i16 %646, %640
  %648 = lshr i16 %647, 9
  %649 = xor i16 %648, %647
  %650 = shl i16 %649, 8
  %651 = xor i16 %650, %649
  %652 = trunc i16 %649 to i8
  %653 = lshr i16 %651, 8
  %654 = trunc nuw i16 %653 to i8
  %655 = and i8 %654, 15
  store i8 %652, ptr %645, align 1, !tbaa !6
  %656 = getelementptr i8, ptr %631, i16 2
  store i8 %655, ptr %656, align 1, !tbaa !6
  %657 = getelementptr i8, ptr %632, i16 4
  %658 = shl i16 %651, 7
  %659 = xor i16 %658, %651
  %660 = lshr i16 %659, 9
  %661 = xor i16 %660, %659
  %662 = shl i16 %661, 8
  %663 = xor i16 %662, %661
  %664 = trunc i16 %661 to i8
  %665 = lshr i16 %663, 8
  %666 = trunc nuw i16 %665 to i8
  %667 = and i8 %666, 15
  store i8 %664, ptr %657, align 1, !tbaa !6
  %668 = getelementptr i8, ptr %631, i16 4
  store i8 %667, ptr %668, align 1, !tbaa !6
  %669 = getelementptr i8, ptr %632, i16 6
  %670 = shl i16 %663, 7
  %671 = xor i16 %670, %663
  %672 = lshr i16 %671, 9
  %673 = xor i16 %672, %671
  %674 = shl i16 %673, 8
  %675 = xor i16 %674, %673
  %676 = trunc i16 %673 to i8
  %677 = lshr i16 %675, 8
  %678 = trunc nuw i16 %677 to i8
  %679 = and i8 %678, 15
  store i8 %676, ptr %669, align 1, !tbaa !6
  %680 = getelementptr i8, ptr %631, i16 6
  store i8 %679, ptr %680, align 1, !tbaa !6
  %681 = getelementptr i8, ptr %632, i16 8
  %682 = shl i16 %675, 7
  %683 = xor i16 %682, %675
  %684 = lshr i16 %683, 9
  %685 = xor i16 %684, %683
  %686 = shl i16 %685, 8
  %687 = xor i16 %686, %685
  %688 = trunc i16 %685 to i8
  %689 = lshr i16 %687, 8
  %690 = trunc nuw i16 %689 to i8
  %691 = and i8 %690, 15
  store i8 %688, ptr %681, align 1, !tbaa !6
  %692 = getelementptr i8, ptr %631, i16 8
  store i8 %691, ptr %692, align 1, !tbaa !6
  %693 = getelementptr i8, ptr %632, i16 10
  %694 = shl i16 %687, 7
  %695 = xor i16 %694, %687
  %696 = lshr i16 %695, 9
  %697 = xor i16 %696, %695
  %698 = shl i16 %697, 8
  %699 = xor i16 %698, %697
  %700 = trunc i16 %697 to i8
  %701 = lshr i16 %699, 8
  %702 = trunc nuw i16 %701 to i8
  %703 = and i8 %702, 15
  store i8 %700, ptr %693, align 1, !tbaa !6
  %704 = getelementptr i8, ptr %631, i16 10
  store i8 %703, ptr %704, align 1, !tbaa !6
  %705 = getelementptr i8, ptr %632, i16 12
  %706 = shl i16 %699, 7
  %707 = xor i16 %706, %699
  %708 = lshr i16 %707, 9
  %709 = xor i16 %708, %707
  %710 = shl i16 %709, 8
  %711 = xor i16 %710, %709
  %712 = trunc i16 %709 to i8
  %713 = lshr i16 %711, 8
  %714 = trunc nuw i16 %713 to i8
  %715 = and i8 %714, 15
  store i8 %712, ptr %705, align 1, !tbaa !6
  %716 = getelementptr i8, ptr %631, i16 12
  store i8 %715, ptr %716, align 1, !tbaa !6
  %717 = getelementptr i8, ptr %632, i16 14
  %718 = shl i16 %711, 7
  %719 = xor i16 %718, %711
  %720 = lshr i16 %719, 9
  %721 = xor i16 %720, %719
  %722 = shl i16 %721, 8
  %723 = xor i16 %722, %721
  %724 = trunc i16 %721 to i8
  %725 = lshr i16 %723, 8
  %726 = trunc nuw i16 %725 to i8
  %727 = and i8 %726, 15
  store i8 %724, ptr %717, align 1, !tbaa !6
  %728 = getelementptr i8, ptr %631, i16 14
  store i8 %727, ptr %728, align 1, !tbaa !6
  %729 = getelementptr i8, ptr %632, i16 16
  %730 = shl i16 %723, 7
  %731 = xor i16 %730, %723
  %732 = lshr i16 %731, 9
  %733 = xor i16 %732, %731
  %734 = shl i16 %733, 8
  %735 = xor i16 %734, %733
  %736 = trunc i16 %733 to i8
  %737 = lshr i16 %735, 8
  %738 = trunc nuw i16 %737 to i8
  %739 = and i8 %738, 15
  store i8 %736, ptr %729, align 1, !tbaa !6
  %740 = getelementptr i8, ptr %631, i16 16
  store i8 %739, ptr %740, align 1, !tbaa !6
  %741 = getelementptr i8, ptr %632, i16 18
  %742 = shl i16 %735, 7
  %743 = xor i16 %742, %735
  %744 = lshr i16 %743, 9
  %745 = xor i16 %744, %743
  %746 = shl i16 %745, 8
  %747 = xor i16 %746, %745
  %748 = trunc i16 %745 to i8
  %749 = lshr i16 %747, 8
  %750 = trunc nuw i16 %749 to i8
  %751 = and i8 %750, 15
  store i8 %748, ptr %741, align 1, !tbaa !6
  %752 = getelementptr i8, ptr %631, i16 18
  store i8 %751, ptr %752, align 1, !tbaa !6
  %753 = getelementptr i8, ptr %632, i16 20
  %754 = shl i16 %747, 7
  %755 = xor i16 %754, %747
  %756 = lshr i16 %755, 9
  %757 = xor i16 %756, %755
  %758 = shl i16 %757, 8
  %759 = xor i16 %758, %757
  %760 = trunc i16 %757 to i8
  %761 = lshr i16 %759, 8
  %762 = trunc nuw i16 %761 to i8
  %763 = and i8 %762, 15
  store i8 %760, ptr %753, align 1, !tbaa !6
  %764 = getelementptr i8, ptr %631, i16 20
  store i8 %763, ptr %764, align 1, !tbaa !6
  %765 = getelementptr i8, ptr %632, i16 22
  %766 = shl i16 %759, 7
  %767 = xor i16 %766, %759
  %768 = lshr i16 %767, 9
  %769 = xor i16 %768, %767
  %770 = shl i16 %769, 8
  %771 = xor i16 %770, %769
  %772 = trunc i16 %769 to i8
  %773 = lshr i16 %771, 8
  %774 = trunc nuw i16 %773 to i8
  %775 = and i8 %774, 15
  store i8 %772, ptr %765, align 1, !tbaa !6
  %776 = getelementptr i8, ptr %631, i16 22
  store i8 %775, ptr %776, align 1, !tbaa !6
  %777 = getelementptr i8, ptr %632, i16 24
  %778 = shl i16 %771, 7
  %779 = xor i16 %778, %771
  %780 = lshr i16 %779, 9
  %781 = xor i16 %780, %779
  %782 = shl i16 %781, 8
  %783 = xor i16 %782, %781
  %784 = trunc i16 %781 to i8
  %785 = lshr i16 %783, 8
  %786 = trunc nuw i16 %785 to i8
  %787 = and i8 %786, 15
  store i8 %784, ptr %777, align 1, !tbaa !6
  %788 = getelementptr i8, ptr %631, i16 24
  store i8 %787, ptr %788, align 1, !tbaa !6
  %789 = getelementptr i8, ptr %632, i16 26
  %790 = shl i16 %783, 7
  %791 = xor i16 %790, %783
  %792 = lshr i16 %791, 9
  %793 = xor i16 %792, %791
  %794 = shl i16 %793, 8
  %795 = xor i16 %794, %793
  %796 = trunc i16 %793 to i8
  %797 = lshr i16 %795, 8
  %798 = trunc nuw i16 %797 to i8
  %799 = and i8 %798, 15
  store i8 %796, ptr %789, align 1, !tbaa !6
  %800 = getelementptr i8, ptr %631, i16 26
  store i8 %799, ptr %800, align 1, !tbaa !6
  %801 = getelementptr i8, ptr %632, i16 28
  %802 = shl i16 %795, 7
  %803 = xor i16 %802, %795
  %804 = lshr i16 %803, 9
  %805 = xor i16 %804, %803
  %806 = shl i16 %805, 8
  %807 = xor i16 %806, %805
  %808 = trunc i16 %805 to i8
  %809 = lshr i16 %807, 8
  %810 = trunc nuw i16 %809 to i8
  %811 = and i8 %810, 15
  store i8 %808, ptr %801, align 1, !tbaa !6
  %812 = getelementptr i8, ptr %631, i16 28
  store i8 %811, ptr %812, align 1, !tbaa !6
  %813 = getelementptr i8, ptr %632, i16 30
  %814 = shl i16 %807, 7
  %815 = xor i16 %814, %807
  %816 = lshr i16 %815, 9
  %817 = xor i16 %816, %815
  %818 = shl i16 %817, 8
  %819 = xor i16 %818, %817
  %820 = trunc i16 %817 to i8
  %821 = lshr i16 %819, 8
  %822 = trunc nuw i16 %821 to i8
  %823 = and i8 %822, 15
  store i8 %820, ptr %813, align 1, !tbaa !6
  %824 = getelementptr i8, ptr %631, i16 30
  store i8 %823, ptr %824, align 1, !tbaa !6
  %825 = add nuw nsw i8 %633, 1
  %826 = getelementptr i8, ptr %632, i16 32
  %827 = getelementptr i8, ptr %631, i16 32
  %828 = icmp eq i8 %825, 14
  br i1 %828, label %829, label %630, !llvm.loop !96

829:                                              ; preds = %630
  %830 = load i8, ptr getelementptr inbounds nuw (i8, ptr @tr_gate_crc.g, i16 1), align 1
  %831 = or i8 %830, 15
  store i8 %831, ptr getelementptr inbounds nuw (i8, ptr @tr_gate_crc.g, i16 1), align 1
  %832 = load i8, ptr getelementptr inbounds nuw (i8, ptr @tr_gate_crc.g, i16 241), align 1
  %833 = or i8 %832, 15
  store i8 %833, ptr getelementptr inbounds nuw (i8, ptr @tr_gate_crc.g, i16 241), align 1
  %834 = load i8, ptr getelementptr inbounds nuw (i8, ptr @tr_gate_crc.g, i16 447), align 1
  %835 = or i8 %834, 15
  store i8 %835, ptr getelementptr inbounds nuw (i8, ptr @tr_gate_crc.g, i16 447), align 1
  br label %836

836:                                              ; preds = %1033, %829
  %837 = phi i8 [ 0, %829 ], [ %1034, %1033 ]
  %838 = phi i16 [ 0, %829 ], [ %1153, %1033 ]
  br label %839

839:                                              ; preds = %950, %836
  %840 = phi ptr [ %966, %950 ], [ getelementptr inbounds nuw (i8, ptr @tr_gate_crc.g, i16 3), %836 ]
  %841 = phi ptr [ %965, %950 ], [ getelementptr inbounds nuw (i8, ptr @tr_gate_crc.g, i16 2), %836 ]
  %842 = phi ptr [ %963, %950 ], [ getelementptr inbounds nuw (i8, ptr @tr_gate_crc.g, i16 1), %836 ]
  %843 = phi ptr [ %962, %950 ], [ @tr_gate_crc.g, %836 ]
  %844 = phi i8 [ %851, %950 ], [ 0, %836 ]
  %845 = zext nneg i8 %844 to i16
  %846 = shl nuw nsw i16 %845, 5
  %847 = getelementptr inbounds nuw i8, ptr @tr_gate_crc.g, i16 %846
  %848 = icmp eq i8 %844, 0
  %849 = add nsw i8 %844, -1
  %850 = select i1 %848, i8 13, i8 %849
  %851 = add nuw nsw i8 %844, 1
  %852 = icmp samesign ult i8 %844, 13
  %853 = zext i8 %850 to i16
  %854 = shl nuw nsw i16 %853, 5
  %855 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @tr_gate_crc.g, i16 1), i16 %854
  %856 = load i8, ptr %842, align 1
  %857 = and i8 %856, 15
  br i1 %852, label %858, label %859

858:                                              ; preds = %839
  br label %859

859:                                              ; preds = %858, %839
  %860 = phi i8 [ %851, %858 ], [ 0, %839 ]
  %861 = getelementptr inbounds nuw i8, ptr %847, i16 31
  %862 = load i8, ptr %861, align 1
  %863 = and i8 %862, 15
  %864 = getelementptr inbounds nuw i8, ptr %847, i16 3
  %865 = load i8, ptr %864, align 1
  %866 = and i8 %865, 15
  %867 = load i8, ptr %855, align 1
  %868 = and i8 %867, 15
  %869 = zext nneg i8 %860 to i16
  %870 = shl nuw nsw i16 %869, 5
  %871 = getelementptr inbounds nuw i8, ptr @tr_gate_crc.g, i16 %870
  %872 = getelementptr inbounds nuw i8, ptr %871, i16 1
  %873 = load i8, ptr %872, align 1
  %874 = and i8 %873, 15
  %875 = icmp samesign ugt i8 %866, %863
  br i1 %875, label %876, label %877

876:                                              ; preds = %859
  br label %877

877:                                              ; preds = %876, %859
  %878 = phi i8 [ %866, %876 ], [ %863, %859 ]
  %879 = icmp samesign ugt i8 %868, %878
  br i1 %879, label %880, label %881

880:                                              ; preds = %877
  br label %881

881:                                              ; preds = %880, %877
  %882 = phi i8 [ %868, %880 ], [ %878, %877 ]
  %883 = icmp samesign ugt i8 %874, %882
  br i1 %883, label %886, label %884

884:                                              ; preds = %881
  %885 = icmp eq i8 %882, 0
  br i1 %885, label %889, label %886

886:                                              ; preds = %884, %881
  %887 = phi i8 [ %882, %884 ], [ %874, %881 ]
  %888 = add nsw i8 %887, -1
  br label %889

889:                                              ; preds = %886, %884
  %890 = phi i8 [ %888, %886 ], [ 0, %884 ]
  %891 = icmp samesign ugt i8 %857, %890
  br i1 %891, label %892, label %894

892:                                              ; preds = %889
  %893 = add nsw i8 %857, -1
  br label %894

894:                                              ; preds = %892, %889
  %895 = phi i8 [ %893, %892 ], [ %890, %889 ]
  %896 = and i8 %856, -16
  %897 = or i8 %895, %896
  store i8 %897, ptr %842, align 1
  %898 = icmp samesign ugt i8 %895, 7
  %899 = load i8, ptr %843, align 1
  %900 = select i1 %898, i8 -128, i8 0
  %901 = and i8 %899, 31
  %902 = or disjoint i8 %901, %900
  %903 = add i8 %899, 32
  %904 = and i8 %903, 96
  %905 = or disjoint i8 %902, %904
  store i8 %905, ptr %843, align 1
  %906 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @tr_gate_crc.g, i16 3), i16 %854
  br label %967

907:                                              ; preds = %1018
  %908 = zext nneg i8 %1032 to i16
  %909 = getelementptr i8, ptr %841, i16 %908
  %910 = getelementptr i8, ptr %840, i16 %908
  %911 = load i8, ptr %910, align 1
  %912 = and i8 %911, 15
  br i1 %852, label %913, label %914

913:                                              ; preds = %907
  br label %914

914:                                              ; preds = %913, %907
  %915 = phi i8 [ %851, %913 ], [ 0, %907 ]
  %916 = getelementptr inbounds nuw i8, ptr %847, i16 29
  %917 = load i8, ptr %916, align 1
  %918 = and i8 %917, 15
  %919 = getelementptr inbounds nuw i8, ptr %847, i16 1
  %920 = load i8, ptr %919, align 1
  %921 = and i8 %920, 15
  %922 = getelementptr i8, ptr %906, i16 %908
  %923 = load i8, ptr %922, align 1
  %924 = and i8 %923, 15
  %925 = zext nneg i8 %915 to i16
  %926 = shl nuw nsw i16 %925, 5
  %927 = getelementptr inbounds nuw i8, ptr @tr_gate_crc.g, i16 %926
  %928 = getelementptr inbounds nuw i8, ptr %927, i16 31
  %929 = load i8, ptr %928, align 1
  %930 = and i8 %929, 15
  %931 = icmp samesign ugt i8 %921, %918
  br i1 %931, label %932, label %933

932:                                              ; preds = %914
  br label %933

933:                                              ; preds = %932, %914
  %934 = phi i8 [ %921, %932 ], [ %918, %914 ]
  %935 = icmp samesign ugt i8 %924, %934
  br i1 %935, label %936, label %937

936:                                              ; preds = %933
  br label %937

937:                                              ; preds = %936, %933
  %938 = phi i8 [ %924, %936 ], [ %934, %933 ]
  %939 = icmp samesign ugt i8 %930, %938
  br i1 %939, label %942, label %940

940:                                              ; preds = %937
  %941 = icmp eq i8 %938, 0
  br i1 %941, label %945, label %942

942:                                              ; preds = %940, %937
  %943 = phi i8 [ %938, %940 ], [ %930, %937 ]
  %944 = add nsw i8 %943, -1
  br label %945

945:                                              ; preds = %942, %940
  %946 = phi i8 [ %944, %942 ], [ 0, %940 ]
  %947 = icmp samesign ugt i8 %912, %946
  br i1 %947, label %948, label %950

948:                                              ; preds = %945
  %949 = add nsw i8 %912, -1
  br label %950

950:                                              ; preds = %948, %945
  %951 = phi i8 [ %949, %948 ], [ %946, %945 ]
  %952 = and i8 %911, -16
  %953 = or i8 %951, %952
  store i8 %953, ptr %910, align 1
  %954 = icmp samesign ugt i8 %951, 7
  %955 = load i8, ptr %909, align 1
  %956 = select i1 %954, i8 -128, i8 0
  %957 = and i8 %955, 31
  %958 = or disjoint i8 %957, %956
  %959 = add i8 %955, 32
  %960 = and i8 %959, 96
  %961 = or disjoint i8 %958, %960
  store i8 %961, ptr %909, align 1
  %962 = getelementptr i8, ptr %843, i16 32
  %963 = getelementptr i8, ptr %842, i16 32
  %964 = icmp eq i8 %851, 14
  %965 = getelementptr i8, ptr %841, i16 32
  %966 = getelementptr i8, ptr %840, i16 32
  br i1 %964, label %1036, label %839, !llvm.loop !97

967:                                              ; preds = %1018, %894
  %968 = phi i8 [ %1032, %1018 ], [ 0, %894 ]
  %969 = phi i8 [ %1030, %1018 ], [ 1, %894 ]
  %970 = zext nneg i8 %969 to i16
  %971 = zext nneg i8 %968 to i16
  %972 = getelementptr i8, ptr %841, i16 %971
  %973 = getelementptr i8, ptr %840, i16 %971
  %974 = load i8, ptr %973, align 1
  %975 = and i8 %974, 15
  br i1 %852, label %976, label %977

976:                                              ; preds = %967
  br label %977

977:                                              ; preds = %976, %967
  %978 = phi i8 [ %851, %976 ], [ 0, %967 ]
  %979 = zext nneg i8 %969 to i16
  %980 = getelementptr [2 x i8], ptr %847, i16 %979
  %981 = getelementptr i8, ptr %980, i16 -1
  %982 = load i8, ptr %981, align 1
  %983 = and i8 %982, 15
  %984 = zext nneg i8 %969 to i16
  %985 = getelementptr inbounds nuw [2 x i8], ptr %847, i16 %984
  %986 = getelementptr inbounds nuw i8, ptr %985, i16 3
  %987 = load i8, ptr %986, align 1
  %988 = and i8 %987, 15
  %989 = getelementptr i8, ptr %906, i16 %971
  %990 = load i8, ptr %989, align 1
  %991 = and i8 %990, 15
  %992 = zext nneg i8 %978 to i16
  %993 = shl nuw nsw i16 %992, 5
  %994 = getelementptr inbounds nuw i8, ptr @tr_gate_crc.g, i16 %993
  %995 = getelementptr inbounds nuw [2 x i8], ptr %994, i16 %970
  %996 = getelementptr inbounds nuw i8, ptr %995, i16 1
  %997 = load i8, ptr %996, align 1
  %998 = and i8 %997, 15
  %999 = icmp samesign ugt i8 %988, %983
  br i1 %999, label %1000, label %1001

1000:                                             ; preds = %977
  br label %1001

1001:                                             ; preds = %1000, %977
  %1002 = phi i8 [ %988, %1000 ], [ %983, %977 ]
  %1003 = icmp samesign ugt i8 %991, %1002
  br i1 %1003, label %1004, label %1005

1004:                                             ; preds = %1001
  br label %1005

1005:                                             ; preds = %1004, %1001
  %1006 = phi i8 [ %991, %1004 ], [ %1002, %1001 ]
  %1007 = icmp samesign ugt i8 %998, %1006
  br i1 %1007, label %1010, label %1008

1008:                                             ; preds = %1005
  %1009 = icmp eq i8 %1006, 0
  br i1 %1009, label %1013, label %1010

1010:                                             ; preds = %1008, %1005
  %1011 = phi i8 [ %1006, %1008 ], [ %998, %1005 ]
  %1012 = add nsw i8 %1011, -1
  br label %1013

1013:                                             ; preds = %1010, %1008
  %1014 = phi i8 [ %1012, %1010 ], [ 0, %1008 ]
  %1015 = icmp samesign ugt i8 %975, %1014
  br i1 %1015, label %1016, label %1018

1016:                                             ; preds = %1013
  %1017 = add nsw i8 %975, -1
  br label %1018

1018:                                             ; preds = %1016, %1013
  %1019 = phi i8 [ %1017, %1016 ], [ %1014, %1013 ]
  %1020 = and i8 %974, -16
  %1021 = or i8 %1019, %1020
  store i8 %1021, ptr %973, align 1
  %1022 = icmp samesign ugt i8 %1019, 7
  %1023 = load i8, ptr %972, align 1
  %1024 = select i1 %1022, i8 -128, i8 0
  %1025 = and i8 %1023, 31
  %1026 = or disjoint i8 %1025, %1024
  %1027 = add i8 %1023, 32
  %1028 = and i8 %1027, 96
  %1029 = or disjoint i8 %1026, %1028
  store i8 %1029, ptr %972, align 1
  %1030 = add nuw nsw i8 %969, 1
  %1031 = icmp eq i8 %1030, 15
  %1032 = add nuw nsw i8 %968, 2
  br i1 %1031, label %907, label %967, !llvm.loop !98

1033:                                             ; preds = %1150
  %1034 = add nuw nsw i8 %837, 1
  %1035 = icmp eq i8 %1034, 24
  br i1 %1035, label %1156, label %836, !llvm.loop !100

1036:                                             ; preds = %950, %1150
  %1037 = phi i16 [ %1154, %1150 ], [ 0, %950 ]
  %1038 = phi i16 [ %1153, %1150 ], [ %838, %950 ]
  %1039 = getelementptr inbounds nuw [2 x i8], ptr @tr_gate_crc.g, i16 %1037
  %1040 = load i8, ptr %1039, align 1
  %1041 = and i8 %1040, 31
  %1042 = lshr i8 %1040, 2
  %1043 = and i8 %1042, 32
  %1044 = or disjoint i8 %1043, %1041
  %1045 = shl i8 %1040, 1
  %1046 = and i8 %1045, 64
  %1047 = or disjoint i8 %1044, %1046
  %1048 = getelementptr inbounds nuw i8, ptr %1039, i16 1
  %1049 = load i8, ptr %1048, align 1
  %1050 = and i8 %1049, 15
  %1051 = zext nneg i8 %1047 to i16
  %1052 = icmp sgt i8 %1045, -1
  %1053 = shl nuw i16 %1051, 9
  %1054 = xor i16 %1053, -2
  br i1 %1052, label %1055, label %1057

1055:                                             ; preds = %1036
  %1056 = xor i16 %1053, -4129
  br label %1057

1057:                                             ; preds = %1055, %1036
  %1058 = phi i16 [ %1056, %1055 ], [ %1054, %1036 ]
  %1059 = icmp sgt i16 %1058, -1
  %1060 = shl i16 %1058, 1
  br i1 %1059, label %1063, label %1061

1061:                                             ; preds = %1057
  %1062 = xor i16 %1060, 4129
  br label %1063

1063:                                             ; preds = %1061, %1057
  %1064 = phi i16 [ %1062, %1061 ], [ %1060, %1057 ]
  %1065 = icmp sgt i16 %1064, -1
  %1066 = shl i16 %1064, 1
  br i1 %1065, label %1069, label %1067

1067:                                             ; preds = %1063
  %1068 = xor i16 %1066, 4129
  br label %1069

1069:                                             ; preds = %1067, %1063
  %1070 = phi i16 [ %1068, %1067 ], [ %1066, %1063 ]
  %1071 = icmp sgt i16 %1070, -1
  %1072 = shl i16 %1070, 1
  br i1 %1071, label %1075, label %1073

1073:                                             ; preds = %1069
  %1074 = xor i16 %1072, 4129
  br label %1075

1075:                                             ; preds = %1073, %1069
  %1076 = phi i16 [ %1074, %1073 ], [ %1072, %1069 ]
  %1077 = icmp sgt i16 %1076, -1
  %1078 = shl i16 %1076, 1
  br i1 %1077, label %1081, label %1079

1079:                                             ; preds = %1075
  %1080 = xor i16 %1078, 4129
  br label %1081

1081:                                             ; preds = %1079, %1075
  %1082 = phi i16 [ %1080, %1079 ], [ %1078, %1075 ]
  %1083 = icmp sgt i16 %1082, -1
  %1084 = shl i16 %1082, 1
  br i1 %1083, label %1087, label %1085

1085:                                             ; preds = %1081
  %1086 = xor i16 %1084, 4129
  br label %1087

1087:                                             ; preds = %1085, %1081
  %1088 = phi i16 [ %1086, %1085 ], [ %1084, %1081 ]
  %1089 = icmp sgt i16 %1088, -1
  %1090 = shl i16 %1088, 1
  br i1 %1089, label %1093, label %1091

1091:                                             ; preds = %1087
  %1092 = xor i16 %1090, 4129
  br label %1093

1093:                                             ; preds = %1091, %1087
  %1094 = phi i16 [ %1092, %1091 ], [ %1090, %1087 ]
  %1095 = icmp sgt i16 %1094, -1
  %1096 = shl i16 %1094, 1
  br i1 %1095, label %1099, label %1097

1097:                                             ; preds = %1093
  %1098 = xor i16 %1096, 4129
  br label %1099

1099:                                             ; preds = %1097, %1093
  %1100 = phi i16 [ %1098, %1097 ], [ %1096, %1093 ]
  %1101 = zext nneg i8 %1050 to i16
  %1102 = icmp sgt i16 %1100, -1
  %1103 = shl nuw nsw i16 %1101, 9
  %1104 = shl i16 %1100, 1
  %1105 = xor i16 %1104, %1103
  br i1 %1102, label %1108, label %1106

1106:                                             ; preds = %1099
  %1107 = xor i16 %1105, 4129
  br label %1108

1108:                                             ; preds = %1106, %1099
  %1109 = phi i16 [ %1107, %1106 ], [ %1105, %1099 ]
  %1110 = icmp sgt i16 %1109, -1
  %1111 = shl i16 %1109, 1
  br i1 %1110, label %1114, label %1112

1112:                                             ; preds = %1108
  %1113 = xor i16 %1111, 4129
  br label %1114

1114:                                             ; preds = %1112, %1108
  %1115 = phi i16 [ %1113, %1112 ], [ %1111, %1108 ]
  %1116 = icmp sgt i16 %1115, -1
  %1117 = shl i16 %1115, 1
  br i1 %1116, label %1120, label %1118

1118:                                             ; preds = %1114
  %1119 = xor i16 %1117, 4129
  br label %1120

1120:                                             ; preds = %1118, %1114
  %1121 = phi i16 [ %1119, %1118 ], [ %1117, %1114 ]
  %1122 = icmp sgt i16 %1121, -1
  %1123 = shl i16 %1121, 1
  br i1 %1122, label %1126, label %1124

1124:                                             ; preds = %1120
  %1125 = xor i16 %1123, 4129
  br label %1126

1126:                                             ; preds = %1124, %1120
  %1127 = phi i16 [ %1125, %1124 ], [ %1123, %1120 ]
  %1128 = icmp sgt i16 %1127, -1
  %1129 = shl i16 %1127, 1
  br i1 %1128, label %1132, label %1130

1130:                                             ; preds = %1126
  %1131 = xor i16 %1129, 4129
  br label %1132

1132:                                             ; preds = %1130, %1126
  %1133 = phi i16 [ %1131, %1130 ], [ %1129, %1126 ]
  %1134 = icmp sgt i16 %1133, -1
  %1135 = shl i16 %1133, 1
  br i1 %1134, label %1138, label %1136

1136:                                             ; preds = %1132
  %1137 = xor i16 %1135, 4129
  br label %1138

1138:                                             ; preds = %1136, %1132
  %1139 = phi i16 [ %1137, %1136 ], [ %1135, %1132 ]
  %1140 = icmp sgt i16 %1139, -1
  %1141 = shl i16 %1139, 1
  br i1 %1140, label %1144, label %1142

1142:                                             ; preds = %1138
  %1143 = xor i16 %1141, 4129
  br label %1144

1144:                                             ; preds = %1142, %1138
  %1145 = phi i16 [ %1143, %1142 ], [ %1141, %1138 ]
  %1146 = icmp sgt i16 %1145, -1
  %1147 = shl i16 %1145, 1
  br i1 %1146, label %1150, label %1148

1148:                                             ; preds = %1144
  %1149 = xor i16 %1147, 4129
  br label %1150

1150:                                             ; preds = %1148, %1144
  %1151 = phi i16 [ %1149, %1148 ], [ %1147, %1144 ]
  %1152 = tail call i16 @llvm.fshl.i16(i16 %1038, i16 %1038, i16 1)
  %1153 = xor i16 %1151, %1152
  %1154 = add nuw nsw i16 %1037, 1
  %1155 = icmp eq i16 %1154, 224
  br i1 %1155, label %1033, label %1036, !llvm.loop !101

1156:                                             ; preds = %1033
  store volatile i16 %1153, ptr @corpus_result, align 1, !tbaa !2
  br label %1157

1157:                                             ; preds = %1498, %1156
  %1158 = phi i8 [ 0, %1156 ], [ %1469, %1498 ]
  %1159 = phi i8 [ 0, %1156 ], [ %1470, %1498 ]
  %1160 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4953), align 1, !tbaa !57
  %1161 = add i8 %1160, 1
  store i8 %1161, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4953), align 1, !tbaa !57
  %1162 = lshr i8 %1161, 4
  %1163 = and i8 %1162, 7
  %1164 = zext nneg i8 %1163 to i16
  %1165 = getelementptr inbounds nuw i8, ptr @switch.table.main, i16 %1164
  %1166 = load i8, ptr %1165, align 1
  %1167 = zext nneg i8 %1163 to i16
  %1168 = getelementptr inbounds nuw i8, ptr @switch.table.main.35, i16 %1167
  %1169 = load i8, ptr %1168, align 1
  %1170 = zext nneg i8 %1163 to i16
  %1171 = getelementptr inbounds nuw i8, ptr @switch.table.main.36, i16 %1170
  %1172 = load i8, ptr %1171, align 1
  %1173 = add nuw nsw i8 %1162, 3
  %1174 = and i8 %1173, 7
  %1175 = zext nneg i8 %1174 to i16
  %1176 = getelementptr inbounds nuw i8, ptr @switch.table.main.37, i16 %1175
  %1177 = load i8, ptr %1176, align 1
  %1178 = zext nneg i8 %1174 to i16
  %1179 = getelementptr inbounds nuw i8, ptr @switch.table.main.38, i16 %1178
  %1180 = load i8, ptr %1179, align 1
  %1181 = zext nneg i8 %1174 to i16
  %1182 = getelementptr inbounds nuw i8, ptr @switch.table.main.39, i16 %1181
  %1183 = load i8, ptr %1182, align 1
  %1184 = zext nneg i8 %1172 to i16
  %1185 = shl nuw nsw i16 %1184, 10
  %1186 = zext nneg i8 %1166 to i16
  %1187 = shl nuw nsw i16 %1186, 5
  %1188 = or disjoint i16 %1185, %1187
  %1189 = zext nneg i8 %1169 to i16
  %1190 = or disjoint i16 %1188, %1189
  store i16 %1190, ptr getelementptr inbounds nuw (i8, ptr @pal, i16 4), align 1, !tbaa !2
  %1191 = zext nneg i8 %1183 to i16
  %1192 = shl nuw nsw i16 %1191, 10
  %1193 = zext nneg i8 %1180 to i16
  %1194 = shl nuw nsw i16 %1193, 5
  %1195 = or disjoint i16 %1192, %1194
  %1196 = zext nneg i8 %1177 to i16
  %1197 = or disjoint i16 %1195, %1196
  store i16 %1197, ptr getelementptr inbounds nuw (i8, ptr @pal, i16 6), align 1, !tbaa !2
  %1198 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %1199 = icmp ugt i8 %1198, 15
  br i1 %1199, label %1211, label %1200

1200:                                             ; preds = %1157
  %1201 = zext nneg i8 %1198 to i16
  %1202 = add nuw nsw i8 %1198, 1
  store i8 %1202, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %1203 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %1201
  %1204 = getelementptr inbounds nuw i8, ptr %1203, i16 10
  store i8 1, ptr %1204, align 1, !tbaa !44
  store i16 0, ptr %1203, align 1, !tbaa !46
  %1205 = getelementptr inbounds nuw i8, ptr %1203, i16 9
  store i8 0, ptr %1205, align 1, !tbaa !47
  %1206 = getelementptr inbounds nuw i8, ptr %1203, i16 7
  store i8 34, ptr %1206, align 1, !tbaa !48
  %1207 = getelementptr inbounds nuw i8, ptr %1203, i16 8
  store i8 0, ptr %1207, align 1, !tbaa !49
  %1208 = getelementptr inbounds nuw i8, ptr %1203, i16 2
  store i16 ptrtoint (ptr @pal to i16), ptr %1208, align 1, !tbaa !50
  %1209 = getelementptr inbounds nuw i8, ptr %1203, i16 6
  store i8 0, ptr %1209, align 1, !tbaa !51
  %1210 = getelementptr inbounds nuw i8, ptr %1203, i16 4
  store i16 8, ptr %1210, align 1, !tbaa !52
  br label %1211

1211:                                             ; preds = %1157, %1200
  %1212 = add i8 %1158, 1
  %1213 = icmp ugt i8 %1212, 5
  br i1 %1213, label %1214, label %1468

1214:                                             ; preds = %1211
  %1215 = add i8 %1159, 1
  %1216 = icmp ugt i8 %1215, 2
  br i1 %1216, label %1217, label %1228

1217:                                             ; preds = %1214
  %1218 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4442), align 1
  %1219 = or i8 %1218, 15
  store i8 %1219, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4442), align 1
  %1220 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4472), align 1
  %1221 = or i8 %1220, 15
  store i8 %1221, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4472), align 1
  %1222 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4922), align 1
  %1223 = or i8 %1222, 15
  store i8 %1223, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4922), align 1
  %1224 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4952), align 1
  %1225 = or i8 %1224, 15
  store i8 %1225, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4952), align 1
  %1226 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4714), align 1
  %1227 = or i8 %1226, 15
  store i8 %1227, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4714), align 1
  br label %1228

1228:                                             ; preds = %1217, %1214
  %1229 = phi i8 [ 0, %1217 ], [ %1215, %1214 ]
  br label %1230

1230:                                             ; preds = %1341, %1228
  %1231 = phi ptr [ %1357, %1341 ], [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4444), %1228 ]
  %1232 = phi ptr [ %1356, %1341 ], [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4443), %1228 ]
  %1233 = phi ptr [ %1354, %1341 ], [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4442), %1228 ]
  %1234 = phi ptr [ %1353, %1341 ], [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), %1228 ]
  %1235 = phi i8 [ %1242, %1341 ], [ 0, %1228 ]
  %1236 = zext nneg i8 %1235 to i16
  %1237 = shl nuw nsw i16 %1236, 5
  %1238 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %1237
  %1239 = icmp eq i8 %1235, 0
  %1240 = add nsw i8 %1235, -1
  %1241 = select i1 %1239, i8 15, i8 %1240
  %1242 = add nuw nsw i8 %1235, 1
  %1243 = icmp samesign ult i8 %1235, 15
  %1244 = zext i8 %1241 to i16
  %1245 = shl nuw nsw i16 %1244, 5
  %1246 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4442), i16 %1245
  %1247 = load i8, ptr %1233, align 1
  %1248 = and i8 %1247, 15
  br i1 %1243, label %1249, label %1250

1249:                                             ; preds = %1230
  br label %1250

1250:                                             ; preds = %1249, %1230
  %1251 = phi i8 [ %1242, %1249 ], [ 0, %1230 ]
  %1252 = getelementptr inbounds nuw i8, ptr %1238, i16 31
  %1253 = load i8, ptr %1252, align 1
  %1254 = and i8 %1253, 15
  %1255 = getelementptr inbounds nuw i8, ptr %1238, i16 3
  %1256 = load i8, ptr %1255, align 1
  %1257 = and i8 %1256, 15
  %1258 = load i8, ptr %1246, align 1
  %1259 = and i8 %1258, 15
  %1260 = zext nneg i8 %1251 to i16
  %1261 = shl nuw nsw i16 %1260, 5
  %1262 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %1261
  %1263 = getelementptr inbounds nuw i8, ptr %1262, i16 1
  %1264 = load i8, ptr %1263, align 1
  %1265 = and i8 %1264, 15
  %1266 = icmp samesign ugt i8 %1257, %1254
  br i1 %1266, label %1267, label %1268

1267:                                             ; preds = %1250
  br label %1268

1268:                                             ; preds = %1267, %1250
  %1269 = phi i8 [ %1257, %1267 ], [ %1254, %1250 ]
  %1270 = icmp samesign ugt i8 %1259, %1269
  br i1 %1270, label %1271, label %1272

1271:                                             ; preds = %1268
  br label %1272

1272:                                             ; preds = %1271, %1268
  %1273 = phi i8 [ %1259, %1271 ], [ %1269, %1268 ]
  %1274 = icmp samesign ugt i8 %1265, %1273
  br i1 %1274, label %1277, label %1275

1275:                                             ; preds = %1272
  %1276 = icmp eq i8 %1273, 0
  br i1 %1276, label %1280, label %1277

1277:                                             ; preds = %1275, %1272
  %1278 = phi i8 [ %1273, %1275 ], [ %1265, %1272 ]
  %1279 = add nsw i8 %1278, -1
  br label %1280

1280:                                             ; preds = %1277, %1275
  %1281 = phi i8 [ %1279, %1277 ], [ 0, %1275 ]
  %1282 = icmp samesign ugt i8 %1248, %1281
  br i1 %1282, label %1283, label %1285

1283:                                             ; preds = %1280
  %1284 = add nsw i8 %1248, -1
  br label %1285

1285:                                             ; preds = %1283, %1280
  %1286 = phi i8 [ %1284, %1283 ], [ %1281, %1280 ]
  %1287 = and i8 %1247, -16
  %1288 = or i8 %1286, %1287
  store i8 %1288, ptr %1233, align 1
  %1289 = icmp samesign ugt i8 %1286, 7
  %1290 = load i8, ptr %1234, align 1
  %1291 = select i1 %1289, i8 -128, i8 0
  %1292 = and i8 %1290, 31
  %1293 = or disjoint i8 %1292, %1291
  %1294 = add i8 %1290, 32
  %1295 = and i8 %1294, 96
  %1296 = or disjoint i8 %1293, %1295
  store i8 %1296, ptr %1234, align 1
  %1297 = getelementptr i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4444), i16 %1245
  br label %1358

1298:                                             ; preds = %1409
  %1299 = zext nneg i8 %1423 to i16
  %1300 = getelementptr i8, ptr %1232, i16 %1299
  %1301 = getelementptr i8, ptr %1231, i16 %1299
  %1302 = load i8, ptr %1301, align 1
  %1303 = and i8 %1302, 15
  br i1 %1243, label %1304, label %1305

1304:                                             ; preds = %1298
  br label %1305

1305:                                             ; preds = %1304, %1298
  %1306 = phi i8 [ %1242, %1304 ], [ 0, %1298 ]
  %1307 = getelementptr inbounds nuw i8, ptr %1238, i16 29
  %1308 = load i8, ptr %1307, align 1
  %1309 = and i8 %1308, 15
  %1310 = getelementptr inbounds nuw i8, ptr %1238, i16 1
  %1311 = load i8, ptr %1310, align 1
  %1312 = and i8 %1311, 15
  %1313 = getelementptr i8, ptr %1297, i16 %1299
  %1314 = load i8, ptr %1313, align 1
  %1315 = and i8 %1314, 15
  %1316 = zext nneg i8 %1306 to i16
  %1317 = shl nuw nsw i16 %1316, 5
  %1318 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %1317
  %1319 = getelementptr inbounds nuw i8, ptr %1318, i16 31
  %1320 = load i8, ptr %1319, align 1
  %1321 = and i8 %1320, 15
  %1322 = icmp samesign ugt i8 %1312, %1309
  br i1 %1322, label %1323, label %1324

1323:                                             ; preds = %1305
  br label %1324

1324:                                             ; preds = %1323, %1305
  %1325 = phi i8 [ %1312, %1323 ], [ %1309, %1305 ]
  %1326 = icmp samesign ugt i8 %1315, %1325
  br i1 %1326, label %1327, label %1328

1327:                                             ; preds = %1324
  br label %1328

1328:                                             ; preds = %1327, %1324
  %1329 = phi i8 [ %1315, %1327 ], [ %1325, %1324 ]
  %1330 = icmp samesign ugt i8 %1321, %1329
  br i1 %1330, label %1333, label %1331

1331:                                             ; preds = %1328
  %1332 = icmp eq i8 %1329, 0
  br i1 %1332, label %1336, label %1333

1333:                                             ; preds = %1331, %1328
  %1334 = phi i8 [ %1329, %1331 ], [ %1321, %1328 ]
  %1335 = add nsw i8 %1334, -1
  br label %1336

1336:                                             ; preds = %1333, %1331
  %1337 = phi i8 [ %1335, %1333 ], [ 0, %1331 ]
  %1338 = icmp samesign ugt i8 %1303, %1337
  br i1 %1338, label %1339, label %1341

1339:                                             ; preds = %1336
  %1340 = add nsw i8 %1303, -1
  br label %1341

1341:                                             ; preds = %1339, %1336
  %1342 = phi i8 [ %1340, %1339 ], [ %1337, %1336 ]
  %1343 = and i8 %1302, -16
  %1344 = or i8 %1342, %1343
  store i8 %1344, ptr %1301, align 1
  %1345 = icmp samesign ugt i8 %1342, 7
  %1346 = load i8, ptr %1300, align 1
  %1347 = select i1 %1345, i8 -128, i8 0
  %1348 = and i8 %1346, 31
  %1349 = or disjoint i8 %1348, %1347
  %1350 = add i8 %1346, 32
  %1351 = and i8 %1350, 96
  %1352 = or disjoint i8 %1349, %1351
  store i8 %1352, ptr %1300, align 1
  %1353 = getelementptr i8, ptr %1234, i16 32
  %1354 = getelementptr i8, ptr %1233, i16 32
  %1355 = icmp eq i8 %1242, 16
  %1356 = getelementptr i8, ptr %1232, i16 32
  %1357 = getelementptr i8, ptr %1231, i16 32
  br i1 %1355, label %1424, label %1230, !llvm.loop !97

1358:                                             ; preds = %1409, %1285
  %1359 = phi i8 [ %1423, %1409 ], [ 0, %1285 ]
  %1360 = phi i8 [ %1421, %1409 ], [ 1, %1285 ]
  %1361 = zext nneg i8 %1360 to i16
  %1362 = zext nneg i8 %1359 to i16
  %1363 = getelementptr i8, ptr %1232, i16 %1362
  %1364 = getelementptr i8, ptr %1231, i16 %1362
  %1365 = load i8, ptr %1364, align 1
  %1366 = and i8 %1365, 15
  br i1 %1243, label %1367, label %1368

1367:                                             ; preds = %1358
  br label %1368

1368:                                             ; preds = %1367, %1358
  %1369 = phi i8 [ %1242, %1367 ], [ 0, %1358 ]
  %1370 = zext nneg i8 %1360 to i16
  %1371 = getelementptr [2 x i8], ptr %1238, i16 %1370
  %1372 = getelementptr i8, ptr %1371, i16 -1
  %1373 = load i8, ptr %1372, align 1
  %1374 = and i8 %1373, 15
  %1375 = zext nneg i8 %1360 to i16
  %1376 = getelementptr inbounds nuw [2 x i8], ptr %1238, i16 %1375
  %1377 = getelementptr inbounds nuw i8, ptr %1376, i16 3
  %1378 = load i8, ptr %1377, align 1
  %1379 = and i8 %1378, 15
  %1380 = getelementptr i8, ptr %1297, i16 %1362
  %1381 = load i8, ptr %1380, align 1
  %1382 = and i8 %1381, 15
  %1383 = zext nneg i8 %1369 to i16
  %1384 = shl nuw nsw i16 %1383, 5
  %1385 = getelementptr inbounds nuw i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), i16 %1384
  %1386 = getelementptr inbounds nuw [2 x i8], ptr %1385, i16 %1361
  %1387 = getelementptr inbounds nuw i8, ptr %1386, i16 1
  %1388 = load i8, ptr %1387, align 1
  %1389 = and i8 %1388, 15
  %1390 = icmp samesign ugt i8 %1379, %1374
  br i1 %1390, label %1391, label %1392

1391:                                             ; preds = %1368
  br label %1392

1392:                                             ; preds = %1391, %1368
  %1393 = phi i8 [ %1379, %1391 ], [ %1374, %1368 ]
  %1394 = icmp samesign ugt i8 %1382, %1393
  br i1 %1394, label %1395, label %1396

1395:                                             ; preds = %1392
  br label %1396

1396:                                             ; preds = %1395, %1392
  %1397 = phi i8 [ %1382, %1395 ], [ %1393, %1392 ]
  %1398 = icmp samesign ugt i8 %1389, %1397
  br i1 %1398, label %1401, label %1399

1399:                                             ; preds = %1396
  %1400 = icmp eq i8 %1397, 0
  br i1 %1400, label %1404, label %1401

1401:                                             ; preds = %1399, %1396
  %1402 = phi i8 [ %1397, %1399 ], [ %1389, %1396 ]
  %1403 = add nsw i8 %1402, -1
  br label %1404

1404:                                             ; preds = %1401, %1399
  %1405 = phi i8 [ %1403, %1401 ], [ 0, %1399 ]
  %1406 = icmp samesign ugt i8 %1366, %1405
  br i1 %1406, label %1407, label %1409

1407:                                             ; preds = %1404
  %1408 = add nsw i8 %1366, -1
  br label %1409

1409:                                             ; preds = %1407, %1404
  %1410 = phi i8 [ %1408, %1407 ], [ %1405, %1404 ]
  %1411 = and i8 %1365, -16
  %1412 = or i8 %1410, %1411
  store i8 %1412, ptr %1364, align 1
  %1413 = icmp samesign ugt i8 %1410, 7
  %1414 = load i8, ptr %1363, align 1
  %1415 = select i1 %1413, i8 -128, i8 0
  %1416 = and i8 %1414, 31
  %1417 = or disjoint i8 %1416, %1415
  %1418 = add i8 %1414, 32
  %1419 = and i8 %1418, 96
  %1420 = or disjoint i8 %1417, %1419
  store i8 %1420, ptr %1363, align 1
  %1421 = add nuw nsw i8 %1360, 1
  %1422 = icmp eq i8 %1421, 15
  %1423 = add nuw nsw i8 %1359, 2
  br i1 %1422, label %1298, label %1358, !llvm.loop !102

1424:                                             ; preds = %1341
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(4098) getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i8 0, i64 4098, i1 false)
  store i16 255, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !23
  br label %1425

1425:                                             ; preds = %1432, %1424
  %1426 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4442), %1424 ], [ %1435, %1432 ]
  %1427 = phi ptr [ getelementptr inbounds nuw (i8, ptr @main.a, i16 4441), %1424 ], [ %1434, %1432 ]
  %1428 = phi i8 [ 0, %1424 ], [ %1433, %1432 ]
  %1429 = zext nneg i8 %1428 to i16
  %1430 = shl nuw nsw i16 %1429, 3
  %1431 = or disjoint i16 %1430, 7
  br label %1437

1432:                                             ; preds = %1464
  %1433 = add nuw nsw i8 %1428, 1
  %1434 = getelementptr i8, ptr %1427, i16 32
  %1435 = getelementptr i8, ptr %1426, i16 32
  %1436 = icmp eq i8 %1433, 16
  br i1 %1436, label %1468, label %1425, !llvm.loop !54

1437:                                             ; preds = %1464, %1425
  %1438 = phi i8 [ 0, %1425 ], [ %1467, %1464 ]
  %1439 = phi i8 [ 0, %1425 ], [ %1465, %1464 ]
  %1440 = zext nneg i8 %1439 to i16
  %1441 = zext nneg i8 %1438 to i16
  %1442 = getelementptr i8, ptr %1427, i16 %1441
  %1443 = load i8, ptr %1442, align 1, !tbaa !6
  %1444 = getelementptr i8, ptr %1426, i16 %1441
  %1445 = load i8, ptr %1444, align 1, !tbaa !6
  %1446 = and i8 %1445, 15
  %1447 = icmp samesign ugt i8 %1446, 10
  br i1 %1447, label %1451, label %1448

1448:                                             ; preds = %1437
  %1449 = icmp samesign ugt i8 %1446, 4
  %1450 = select i1 %1449, i8 2, i8 1
  br label %1451

1451:                                             ; preds = %1448, %1437
  %1452 = phi i8 [ %1450, %1448 ], [ 3, %1437 ]
  %1453 = shl nuw nsw i16 %1440, 3
  %1454 = and i8 %1443, 1
  %1455 = icmp eq i8 %1454, 0
  %1456 = or disjoint i16 %1453, 7
  %1457 = and i8 %1443, 2
  %1458 = icmp eq i8 %1457, 0
  br i1 %1455, label %1459, label %1460

1459:                                             ; preds = %1451
  tail call fastcc void @canvas_line(i16 noundef %1453, i16 noundef %1430, i16 noundef %1456, i16 noundef %1431, i8 noundef zeroext %1452)
  br i1 %1458, label %1464, label %1461

1460:                                             ; preds = %1451
  tail call fastcc void @canvas_line(i16 noundef %1456, i16 noundef %1430, i16 noundef %1453, i16 noundef %1431, i8 noundef zeroext %1452)
  br i1 %1458, label %1464, label %1461

1461:                                             ; preds = %1460, %1459
  %1462 = phi i16 [ %1456, %1459 ], [ %1453, %1460 ]
  %1463 = phi i16 [ %1453, %1459 ], [ %1456, %1460 ]
  tail call fastcc void @canvas_line(i16 noundef %1462, i16 noundef %1430, i16 noundef %1463, i16 noundef %1431, i8 noundef zeroext 1)
  br label %1464

1464:                                             ; preds = %1461, %1460, %1459
  %1465 = add nuw nsw i8 %1439, 1
  %1466 = icmp eq i8 %1465, 16
  %1467 = add nuw nsw i8 %1438, 2
  br i1 %1466, label %1432, label %1437, !llvm.loop !55

1468:                                             ; preds = %1432, %1211
  %1469 = phi i8 [ %1212, %1211 ], [ 0, %1432 ]
  %1470 = phi i8 [ %1159, %1211 ], [ %1229, %1432 ]
  %1471 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %1472 = icmp eq i8 %1471, 0
  br i1 %1472, label %1484, label %1473

1473:                                             ; preds = %1468, %1473
  %1474 = phi i8 [ %1481, %1473 ], [ 0, %1468 ]
  %1475 = zext i8 %1474 to i16
  %1476 = getelementptr inbounds nuw [2 x i8], ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 182), i16 %1475
  %1477 = load ptr, ptr %1476, align 1, !tbaa !32
  %1478 = load ptr, ptr %1477, align 1, !tbaa !39
  %1479 = getelementptr inbounds nuw i8, ptr %1478, i16 2
  %1480 = load ptr, ptr %1479, align 1, !tbaa !83
  tail call void %1480(ptr noundef nonnull %1477, ptr noundef nonnull @main.a) #10, !inline_history !103
  %1481 = add nuw i8 %1474, 1
  %1482 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 190), align 1, !tbaa !31
  %1483 = icmp ult i8 %1481, %1482
  br i1 %1483, label %1473, label %1484, !llvm.loop !85

1484:                                             ; preds = %1473, %1468
  %1485 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  br label %1486

1486:                                             ; preds = %1486, %1484
  %1487 = load volatile i8, ptr inttoptr (i16 16912 to ptr), align 16, !tbaa !6
  %1488 = icmp sgt i8 %1487, -1
  br i1 %1488, label %1486, label %1489, !llvm.loop !86

1489:                                             ; preds = %1486
  tail call fastcc void @upq_flush()
  %1490 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  %1491 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 195), align 1, !tbaa !12
  %1492 = icmp ult i8 %1490, %1491
  br i1 %1492, label %1495, label %1493

1493:                                             ; preds = %1489
  %1494 = icmp ugt i8 %1490, %1491
  br i1 %1494, label %1495, label %1498

1495:                                             ; preds = %1493, %1489
  %1496 = phi i8 [ 1, %1489 ], [ -1, %1493 ]
  %1497 = add i8 %1496, %1490
  store i8 %1497, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 194), align 1, !tbaa !7
  br label %1498

1498:                                             ; preds = %1493, %1495
  %1499 = phi i8 [ %1490, %1493 ], [ %1497, %1495 ]
  %1500 = and i8 %1499, 15
  store volatile i8 %1500, ptr inttoptr (i16 8448 to ptr), align 256, !tbaa !6
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 192), align 1, !tbaa !29
  br label %1157
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nofree norecurse nounwind memory(readwrite, target_mem: none)
define internal void @_canvas_reserve(ptr noundef readonly captures(none) %0, ptr readnone captures(none) %1) #2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4105
  %4 = load i16, ptr %3, align 1, !tbaa !19
  %5 = lshr i16 %4, 8
  %6 = trunc nuw i16 %5 to i8
  %7 = and i8 %6, -4
  store volatile i8 %7, ptr inttoptr (i16 8457 to ptr), align 1, !tbaa !6
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %9 = load i16, ptr %8, align 1, !tbaa !18
  %10 = lshr i16 %9, 12
  %11 = trunc nuw nsw i16 %10 to i8
  store volatile i8 %11, ptr inttoptr (i16 8460 to ptr), align 4, !tbaa !6
  %12 = load i16, ptr %8, align 1, !tbaa !18
  %13 = lshr i16 %12, 3
  %14 = add nuw nsw i16 %13, 256
  %15 = load i16, ptr %3, align 1, !tbaa !19
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %15, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %16 = getelementptr inbounds nuw i8, ptr %0, i16 4107
  %17 = load i8, ptr %16, align 1, !tbaa !20
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 4108
  br label %19

19:                                               ; preds = %2, %23
  %20 = phi i8 [ 0, %2 ], [ %24, %23 ]
  br label %26

21:                                               ; preds = %23
  %22 = load i16, ptr %8, align 1, !tbaa !18
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %22, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %45

23:                                               ; preds = %40
  %24 = add nuw nsw i8 %20, 1
  %25 = icmp eq i8 %24, 32
  br i1 %25, label %21, label %19, !llvm.loop !34

26:                                               ; preds = %19, %40
  %27 = phi i8 [ 0, %19 ], [ %42, %40 ]
  %28 = sub i8 %27, %17
  %29 = zext i8 %28 to i16
  %30 = icmp ult i8 %28, 16
  br i1 %30, label %31, label %40

31:                                               ; preds = %26
  %32 = load i8, ptr %18, align 1, !tbaa !21
  %33 = sub i8 %20, %32
  %34 = icmp ult i8 %33, 16
  br i1 %34, label %35, label %40

35:                                               ; preds = %31
  %36 = shl nuw i8 %33, 4
  %37 = zext i8 %36 to i16
  %38 = add nuw nsw i16 %13, %29
  %39 = add nuw nsw i16 %38, %37
  br label %40

40:                                               ; preds = %26, %31, %35
  %41 = phi i16 [ %39, %35 ], [ %14, %31 ], [ %14, %26 ]
  store volatile i16 %41, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %42 = add nuw nsw i8 %27, 1
  %43 = icmp eq i8 %42, 32
  br i1 %43, label %23, label %26, !llvm.loop !104

44:                                               ; preds = %45
  ret void

45:                                               ; preds = %21, %45
  %46 = phi i16 [ 0, %21 ], [ %47, %45 ]
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %47 = add nuw nsw i16 %46, 1
  %48 = icmp eq i16 %47, 2056
  br i1 %48, label %44, label %45, !llvm.loop !36
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define internal void @_canvas_emit(ptr noundef %0, ptr noundef captures(none) %1) #3 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 4099
  %4 = load i16, ptr %3, align 1, !tbaa !22
  %5 = getelementptr inbounds nuw i8, ptr %0, i16 4101
  %6 = load i16, ptr %5, align 1, !tbaa !23
  %7 = icmp ugt i16 %4, %6
  br i1 %7, label %48, label %8

8:                                                ; preds = %2
  %9 = sub nuw i16 %6, %4
  %10 = add i16 %9, -64
  %11 = icmp ult i16 %10, -65
  br i1 %11, label %12, label %14

12:                                               ; preds = %8
  %13 = add i16 %4, 63
  br label %14

14:                                               ; preds = %12, %8
  %15 = phi i16 [ 63, %12 ], [ %9, %8 ]
  %16 = phi i16 [ %13, %12 ], [ %6, %8 ]
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 4103
  %18 = load i16, ptr %17, align 1, !tbaa !18
  %19 = shl i16 %4, 3
  %20 = add i16 %18, %19
  %21 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %22 = shl i16 %4, 4
  %23 = getelementptr inbounds nuw i8, ptr %21, i16 %22
  %24 = shl nsw i16 %15, 4
  %25 = add nsw i16 %24, 16
  %26 = icmp eq i16 %25, 0
  br i1 %26, label %43, label %27

27:                                               ; preds = %14
  %28 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %29 = load i8, ptr %28, align 1, !tbaa !43
  %30 = icmp ugt i8 %29, 15
  br i1 %30, label %43, label %31

31:                                               ; preds = %27
  %32 = zext nneg i8 %29 to i16
  %33 = add nuw nsw i8 %29, 1
  store i8 %33, ptr %28, align 1, !tbaa !43
  %34 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %32
  %35 = getelementptr inbounds nuw i8, ptr %34, i16 10
  store i8 0, ptr %35, align 1, !tbaa !44
  store i16 %20, ptr %34, align 1, !tbaa !46
  %36 = getelementptr inbounds nuw i8, ptr %34, i16 9
  store i8 -128, ptr %36, align 1, !tbaa !47
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 7
  store i8 24, ptr %37, align 1, !tbaa !48
  %38 = getelementptr inbounds nuw i8, ptr %34, i16 8
  store i8 1, ptr %38, align 1, !tbaa !49
  %39 = ptrtoint ptr %23 to i16
  %40 = getelementptr inbounds nuw i8, ptr %34, i16 2
  store i16 %39, ptr %40, align 1, !tbaa !50
  %41 = getelementptr inbounds nuw i8, ptr %34, i16 6
  store i8 0, ptr %41, align 1, !tbaa !51
  %42 = getelementptr inbounds nuw i8, ptr %34, i16 4
  store i16 %25, ptr %42, align 1, !tbaa !52
  br label %43

43:                                               ; preds = %14, %27, %31
  %44 = icmp ult i16 %16, %6
  br i1 %44, label %46, label %45

45:                                               ; preds = %43
  store i16 -1, ptr %3, align 1, !tbaa !22
  store i16 0, ptr %5, align 1, !tbaa !23
  br label %48

46:                                               ; preds = %43
  %47 = add nuw i16 %16, 1
  store i16 %47, ptr %3, align 1, !tbaa !22
  br label %48

48:                                               ; preds = %45, %46, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind memory(readwrite, target_mem: none)
define internal void @_text_reserve(ptr readnone captures(none) %0, ptr readnone captures(none) %1) #2 {
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 2048, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %4

3:                                                ; preds = %4
  ret void

4:                                                ; preds = %2, %4
  %5 = phi i16 [ 0, %2 ], [ %8, %4 ]
  %6 = getelementptr inbounds nuw [2 x i8], ptr @FONT8, i16 %5
  %7 = load i16, ptr %6, align 1, !tbaa !2
  store volatile i16 %7, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %8 = add nuw nsw i16 %5, 1
  %9 = icmp eq i16 %8, 512
  br i1 %9, label %3, label %4, !llvm.loop !105
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define internal void @_text_emit(ptr noundef %0, ptr noundef captures(none) %1) #3 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 135
  %4 = load i8, ptr %3, align 1, !tbaa !28
  %5 = zext i8 %4 to i16
  %6 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %7 = getelementptr i8, ptr %0, i16 7
  %8 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %9 = getelementptr i8, ptr %0, i16 5
  %10 = and i16 %5, 1
  %11 = icmp eq i16 %10, 0
  br i1 %11, label %32, label %12

12:                                               ; preds = %2
  %13 = load i8, ptr %6, align 1, !tbaa !43
  %14 = icmp ugt i8 %13, 15
  br i1 %14, label %32, label %15

15:                                               ; preds = %12
  %16 = load i16, ptr %8, align 1, !tbaa !27
  %17 = load i8, ptr %9, align 1, !tbaa !6
  %18 = zext i8 %17 to i16
  %19 = shl nuw nsw i16 %18, 5
  %20 = add i16 %19, %16
  %21 = zext nneg i8 %13 to i16
  %22 = add nuw nsw i8 %13, 1
  store i8 %22, ptr %6, align 1, !tbaa !43
  %23 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %21
  %24 = getelementptr inbounds nuw i8, ptr %23, i16 10
  store i8 0, ptr %24, align 1, !tbaa !44
  store i16 %20, ptr %23, align 1, !tbaa !46
  %25 = getelementptr inbounds nuw i8, ptr %23, i16 9
  store i8 -128, ptr %25, align 1, !tbaa !47
  %26 = getelementptr inbounds nuw i8, ptr %23, i16 7
  store i8 24, ptr %26, align 1, !tbaa !48
  %27 = getelementptr inbounds nuw i8, ptr %23, i16 8
  store i8 1, ptr %27, align 1, !tbaa !49
  %28 = ptrtoint ptr %7 to i16
  %29 = getelementptr inbounds nuw i8, ptr %23, i16 2
  store i16 %28, ptr %29, align 1, !tbaa !50
  %30 = getelementptr inbounds nuw i8, ptr %23, i16 6
  store i8 0, ptr %30, align 1, !tbaa !51
  %31 = getelementptr inbounds nuw i8, ptr %23, i16 4
  store i16 64, ptr %31, align 1, !tbaa !52
  br label %32

32:                                               ; preds = %15, %12, %2
  %33 = and i16 %5, 2
  %34 = icmp eq i16 %33, 0
  br i1 %34, label %57, label %35

35:                                               ; preds = %32
  %36 = load i8, ptr %6, align 1, !tbaa !43
  %37 = icmp ugt i8 %36, 15
  br i1 %37, label %57, label %38

38:                                               ; preds = %35
  %39 = getelementptr i8, ptr %0, i16 71
  %40 = load i16, ptr %8, align 1, !tbaa !27
  %41 = getelementptr i8, ptr %0, i16 6
  %42 = load i8, ptr %41, align 1, !tbaa !6
  %43 = zext i8 %42 to i16
  %44 = shl nuw nsw i16 %43, 5
  %45 = add i16 %44, %40
  %46 = zext nneg i8 %36 to i16
  %47 = add nuw nsw i8 %36, 1
  store i8 %47, ptr %6, align 1, !tbaa !43
  %48 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %46
  %49 = getelementptr inbounds nuw i8, ptr %48, i16 10
  store i8 0, ptr %49, align 1, !tbaa !44
  store i16 %45, ptr %48, align 1, !tbaa !46
  %50 = getelementptr inbounds nuw i8, ptr %48, i16 9
  store i8 -128, ptr %50, align 1, !tbaa !47
  %51 = getelementptr inbounds nuw i8, ptr %48, i16 7
  store i8 24, ptr %51, align 1, !tbaa !48
  %52 = getelementptr inbounds nuw i8, ptr %48, i16 8
  store i8 1, ptr %52, align 1, !tbaa !49
  %53 = ptrtoint ptr %39 to i16
  %54 = getelementptr inbounds nuw i8, ptr %48, i16 2
  store i16 %53, ptr %54, align 1, !tbaa !50
  %55 = getelementptr inbounds nuw i8, ptr %48, i16 6
  store i8 0, ptr %55, align 1, !tbaa !51
  %56 = getelementptr inbounds nuw i8, ptr %48, i16 4
  store i16 64, ptr %56, align 1, !tbaa !52
  br label %57

57:                                               ; preds = %38, %35, %32
  store i8 0, ptr %3, align 1, !tbaa !28
  ret void
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i16(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i16, i1 immarg) #4

; Function Attrs: nofree norecurse nounwind memory(readwrite, target_mem: none)
define internal void @_title_reserve(ptr noundef %0, ptr readnone captures(none) %1) #2 {
  store volatile i8 80, ptr inttoptr (i16 8456 to ptr), align 8, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8459 to ptr), align 1, !tbaa !6
  store volatile i8 112, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -1, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 127, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -124, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 8482 to ptr), align 2, !tbaa !6
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 4096, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %3

3:                                                ; preds = %2, %3
  %4 = phi ptr [ @FONT8, %2 ], [ %22, %3 ]
  %5 = phi i16 [ 0, %2 ], [ %21, %3 ]
  %6 = load i16, ptr %4, align 1, !tbaa !2
  store volatile i16 %6, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %7 = getelementptr i8, ptr %4, i16 2
  %8 = load i16, ptr %7, align 1, !tbaa !2
  store volatile i16 %8, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %9 = getelementptr i8, ptr %4, i16 4
  %10 = load i16, ptr %9, align 1, !tbaa !2
  store volatile i16 %10, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %11 = getelementptr i8, ptr %4, i16 6
  %12 = load i16, ptr %11, align 1, !tbaa !2
  store volatile i16 %12, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %13 = getelementptr i8, ptr %4, i16 8
  %14 = load i16, ptr %13, align 1, !tbaa !2
  store volatile i16 %14, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %15 = getelementptr i8, ptr %4, i16 10
  %16 = load i16, ptr %15, align 1, !tbaa !2
  store volatile i16 %16, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %17 = getelementptr i8, ptr %4, i16 12
  %18 = load i16, ptr %17, align 1, !tbaa !2
  store volatile i16 %18, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %19 = getelementptr i8, ptr %4, i16 14
  %20 = load i16, ptr %19, align 1, !tbaa !2
  store volatile i16 %20, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %21 = add nuw nsw i16 %5, 1
  %22 = getelementptr i8, ptr %4, i16 16
  %23 = icmp eq i16 %21, 64
  br i1 %23, label %24, label %3, !llvm.loop !106

24:                                               ; preds = %3
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 5120, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %25

25:                                               ; preds = %24, %25
  %26 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 16), %24 ], [ %100, %25 ]
  %27 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 14), %24 ], [ %99, %25 ]
  %28 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 12), %24 ], [ %98, %25 ]
  %29 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 10), %24 ], [ %97, %25 ]
  %30 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 8), %24 ], [ %96, %25 ]
  %31 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 6), %24 ], [ %95, %25 ]
  %32 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 4), %24 ], [ %94, %25 ]
  %33 = phi ptr [ getelementptr inbounds nuw (i8, ptr @FONT16, i16 2), %24 ], [ %93, %25 ]
  %34 = phi ptr [ @FONT16, %24 ], [ %92, %25 ]
  %35 = phi i16 [ 0, %24 ], [ %91, %25 ]
  %36 = load i16, ptr %34, align 1, !tbaa !2
  store volatile i16 %36, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %37 = load i16, ptr %33, align 1, !tbaa !2
  store volatile i16 %37, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %38 = load i16, ptr %32, align 1, !tbaa !2
  store volatile i16 %38, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %39 = load i16, ptr %31, align 1, !tbaa !2
  store volatile i16 %39, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %40 = load i16, ptr %30, align 1, !tbaa !2
  store volatile i16 %40, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %41 = load i16, ptr %29, align 1, !tbaa !2
  store volatile i16 %41, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %42 = load i16, ptr %28, align 1, !tbaa !2
  store volatile i16 %42, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %43 = load i16, ptr %27, align 1, !tbaa !2
  store volatile i16 %43, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %44 = load i16, ptr %26, align 1, !tbaa !2
  store volatile i16 %44, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %45 = getelementptr i8, ptr %33, i16 16
  %46 = load i16, ptr %45, align 1, !tbaa !2
  store volatile i16 %46, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %47 = getelementptr i8, ptr %32, i16 16
  %48 = load i16, ptr %47, align 1, !tbaa !2
  store volatile i16 %48, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %49 = getelementptr i8, ptr %31, i16 16
  %50 = load i16, ptr %49, align 1, !tbaa !2
  store volatile i16 %50, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %51 = getelementptr i8, ptr %30, i16 16
  %52 = load i16, ptr %51, align 1, !tbaa !2
  store volatile i16 %52, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %53 = getelementptr i8, ptr %29, i16 16
  %54 = load i16, ptr %53, align 1, !tbaa !2
  store volatile i16 %54, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %55 = getelementptr i8, ptr %28, i16 16
  %56 = load i16, ptr %55, align 1, !tbaa !2
  store volatile i16 %56, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %57 = getelementptr i8, ptr %27, i16 16
  %58 = load i16, ptr %57, align 1, !tbaa !2
  store volatile i16 %58, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %59 = getelementptr i8, ptr %26, i16 16
  %60 = load i16, ptr %59, align 1, !tbaa !2
  store volatile i16 %60, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %61 = getelementptr i8, ptr %33, i16 32
  %62 = load i16, ptr %61, align 1, !tbaa !2
  store volatile i16 %62, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %63 = getelementptr i8, ptr %32, i16 32
  %64 = load i16, ptr %63, align 1, !tbaa !2
  store volatile i16 %64, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %65 = getelementptr i8, ptr %31, i16 32
  %66 = load i16, ptr %65, align 1, !tbaa !2
  store volatile i16 %66, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %67 = getelementptr i8, ptr %30, i16 32
  %68 = load i16, ptr %67, align 1, !tbaa !2
  store volatile i16 %68, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %69 = getelementptr i8, ptr %29, i16 32
  %70 = load i16, ptr %69, align 1, !tbaa !2
  store volatile i16 %70, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %71 = getelementptr i8, ptr %28, i16 32
  %72 = load i16, ptr %71, align 1, !tbaa !2
  store volatile i16 %72, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %73 = getelementptr i8, ptr %27, i16 32
  %74 = load i16, ptr %73, align 1, !tbaa !2
  store volatile i16 %74, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %75 = getelementptr i8, ptr %26, i16 32
  %76 = load i16, ptr %75, align 1, !tbaa !2
  store volatile i16 %76, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %77 = getelementptr i8, ptr %33, i16 48
  %78 = load i16, ptr %77, align 1, !tbaa !2
  store volatile i16 %78, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %79 = getelementptr i8, ptr %32, i16 48
  %80 = load i16, ptr %79, align 1, !tbaa !2
  store volatile i16 %80, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %81 = getelementptr i8, ptr %31, i16 48
  %82 = load i16, ptr %81, align 1, !tbaa !2
  store volatile i16 %82, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %83 = getelementptr i8, ptr %30, i16 48
  %84 = load i16, ptr %83, align 1, !tbaa !2
  store volatile i16 %84, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %85 = getelementptr i8, ptr %29, i16 48
  %86 = load i16, ptr %85, align 1, !tbaa !2
  store volatile i16 %86, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %87 = getelementptr i8, ptr %28, i16 48
  %88 = load i16, ptr %87, align 1, !tbaa !2
  store volatile i16 %88, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %89 = getelementptr i8, ptr %27, i16 48
  %90 = load i16, ptr %89, align 1, !tbaa !2
  store volatile i16 %90, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 0, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %91 = add nuw nsw i16 %35, 1
  %92 = getelementptr i8, ptr %34, i16 64
  %93 = getelementptr i8, ptr %33, i16 64
  %94 = getelementptr i8, ptr %32, i16 64
  %95 = getelementptr i8, ptr %31, i16 64
  %96 = getelementptr i8, ptr %30, i16 64
  %97 = getelementptr i8, ptr %29, i16 64
  %98 = getelementptr i8, ptr %28, i16 64
  %99 = getelementptr i8, ptr %27, i16 64
  %100 = getelementptr i8, ptr %26, i16 64
  %101 = icmp eq i16 %91, 64
  br i1 %101, label %102, label %25, !llvm.loop !107

102:                                              ; preds = %25
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 20480, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %112

103:                                              ; preds = %112
  %104 = getelementptr inbounds nuw i8, ptr %0, i16 3
  %105 = load ptr, ptr %104, align 1, !tbaa !64
  %106 = icmp eq ptr %105, null
  br i1 %106, label %125, label %107

107:                                              ; preds = %103
  %108 = load i8, ptr %105, align 1, !tbaa !6
  %109 = icmp eq i8 %108, 0
  br i1 %109, label %125, label %110

110:                                              ; preds = %107
  %111 = getelementptr i8, ptr %105, i16 1
  br label %116

112:                                              ; preds = %102, %112
  %113 = phi i16 [ 0, %102 ], [ %114, %112 ]
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %114 = add nuw nsw i16 %113, 1
  %115 = icmp eq i16 %114, 1024
  br i1 %115, label %103, label %112, !llvm.loop !108

116:                                              ; preds = %110, %116
  %117 = phi i8 [ %118, %116 ], [ 0, %110 ]
  %118 = add nuw nsw i8 %117, 1
  %119 = zext nneg i8 %117 to i16
  %120 = getelementptr i8, ptr %111, i16 %119
  %121 = load i8, ptr %120, align 1, !tbaa !6
  %122 = icmp ne i8 %121, 0
  %123 = icmp samesign ult i8 %117, 31
  %124 = select i1 %122, i1 %123, i1 false
  br i1 %124, label %116, label %125, !llvm.loop !109

125:                                              ; preds = %116, %107, %103
  %126 = phi i8 [ 0, %103 ], [ 0, %107 ], [ %118, %116 ]
  %127 = zext nneg i8 %126 to i16
  %128 = sub nuw nsw i16 32, %127
  %129 = lshr i16 %128, 1
  %130 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %131 = load i16, ptr %130, align 1, !tbaa !70
  %132 = shl i16 %131, 2
  %133 = and i16 %132, -32
  %134 = add i16 %133, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %134, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  %135 = trunc nuw nsw i16 %129 to i8
  %136 = add nuw nsw i8 %126, %135
  br i1 %106, label %140, label %137

137:                                              ; preds = %125
  %138 = sub nsw i16 0, %129
  %139 = getelementptr i8, ptr %105, i16 %138
  br label %153

140:                                              ; preds = %125
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br label %141

141:                                              ; preds = %175, %140
  %142 = getelementptr inbounds nuw i8, ptr %0, i16 7
  %143 = load ptr, ptr %142, align 1, !tbaa !66
  %144 = getelementptr inbounds nuw i8, ptr %0, i16 11
  %145 = load i8, ptr %144, align 1, !tbaa !67
  %146 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %147 = load i16, ptr %146, align 1, !tbaa !71
  %148 = lshr i16 %147, 3
  %149 = trunc i16 %148 to i8
  tail call fastcc void @_title_write16(ptr noundef %143, i8 noundef zeroext %145, i8 noundef zeroext %149)
  %150 = getelementptr inbounds nuw i8, ptr %0, i16 9
  %151 = load ptr, ptr %150, align 1, !tbaa !68
  %152 = icmp eq ptr %151, null
  br i1 %152, label %186, label %179

153:                                              ; preds = %137, %175
  %154 = phi i8 [ %177, %175 ], [ 0, %137 ]
  %155 = zext nneg i8 %154 to i16
  %156 = icmp samesign ugt i16 %129, %155
  br i1 %156, label %175, label %157

157:                                              ; preds = %153
  %158 = icmp ult i8 %154, %136
  br i1 %158, label %159, label %175

159:                                              ; preds = %157
  %160 = getelementptr i8, ptr %139, i16 %155
  %161 = load i8, ptr %160, align 1, !tbaa !6
  %162 = icmp ugt i8 %161, 96
  br i1 %162, label %163, label %167

163:                                              ; preds = %159
  %164 = icmp ult i8 %161, 123
  br i1 %164, label %165, label %175

165:                                              ; preds = %163
  %166 = add nsw i8 %161, -32
  br label %171

167:                                              ; preds = %159
  %168 = icmp samesign ugt i8 %161, 31
  br i1 %168, label %169, label %175

169:                                              ; preds = %167
  %170 = icmp eq i8 %161, 96
  br i1 %170, label %175, label %171

171:                                              ; preds = %169, %165
  %172 = phi i8 [ %166, %165 ], [ %161, %169 ]
  %173 = zext nneg i8 %172 to i16
  %174 = add nuw nsw i16 %173, 7136
  br label %175

175:                                              ; preds = %171, %169, %167, %163, %153, %157
  %176 = phi i16 [ 7168, %163 ], [ 7168, %157 ], [ 7168, %153 ], [ %174, %171 ], [ 7168, %169 ], [ 7168, %167 ]
  store volatile i16 %176, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %177 = add nuw nsw i8 %154, 1
  %178 = icmp eq i8 %177, 32
  br i1 %178, label %141, label %153, !llvm.loop !110

179:                                              ; preds = %141
  %180 = getelementptr inbounds nuw i8, ptr %0, i16 12
  %181 = load i8, ptr %180, align 1, !tbaa !69
  %182 = load i16, ptr %146, align 1, !tbaa !71
  %183 = lshr i16 %182, 3
  %184 = trunc i16 %183 to i8
  %185 = add i8 %184, 2
  tail call fastcc void @_title_write16(ptr noundef nonnull %151, i8 noundef zeroext %181, i8 noundef zeroext %185)
  br label %186

186:                                              ; preds = %179, %141
  %187 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 -128, ptr %187, align 1, !tbaa !94
  %188 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 3584, ptr %188, align 1, !tbaa !111
  %189 = getelementptr inbounds nuw i8, ptr %0, i16 23
  store i16 0, ptr %189, align 1, !tbaa !112
  %190 = load ptr, ptr %104, align 1, !tbaa !64
  %191 = icmp eq ptr %190, null
  br i1 %191, label %214, label %192

192:                                              ; preds = %186
  %193 = load i8, ptr %190, align 1, !tbaa !6
  %194 = icmp eq i8 %193, 0
  br i1 %194, label %197, label %195

195:                                              ; preds = %192
  %196 = getelementptr i8, ptr %190, i16 1
  br label %205

197:                                              ; preds = %205, %192
  %198 = phi i8 [ 0, %192 ], [ %207, %205 ]
  %199 = zext nneg i8 %198 to i16
  %200 = shl nuw nsw i16 %199, 2
  %201 = sub nuw nsw i16 128, %200
  %202 = and i16 %201, 248
  %203 = add nsw i16 %200, -128
  %204 = add nsw i16 %203, %202
  br label %214

205:                                              ; preds = %205, %195
  %206 = phi i8 [ %207, %205 ], [ 0, %195 ]
  %207 = add nuw nsw i8 %206, 1
  %208 = zext nneg i8 %206 to i16
  %209 = getelementptr i8, ptr %196, i16 %208
  %210 = load i8, ptr %209, align 1, !tbaa !6
  %211 = icmp ne i8 %210, 0
  %212 = icmp samesign ult i8 %206, 31
  %213 = select i1 %211, i1 %212, i1 false
  br i1 %213, label %205, label %197, !llvm.loop !113

214:                                              ; preds = %186, %197
  %215 = phi i16 [ %204, %197 ], [ 0, %186 ]
  %216 = getelementptr inbounds nuw i8, ptr %0, i16 26
  store i16 %215, ptr %216, align 1, !tbaa !114
  store volatile i8 -112, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 8464 to ptr), align 16, !tbaa !6
  %217 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %218 = getelementptr inbounds nuw i8, ptr %0, i16 89
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef -8, i16 noundef 224, ptr noundef nonnull %217, ptr noundef nonnull %218)
  %219 = getelementptr inbounds nuw i8, ptr %0, i16 88
  store i8 0, ptr %219, align 1, !tbaa !115
  store volatile i8 2, ptr inttoptr (i16 17200 to ptr), align 16, !tbaa !6
  store volatile i8 16, ptr inttoptr (i16 17201 to ptr), align 1, !tbaa !6
  %220 = ptrtoint ptr %217 to i16
  %221 = trunc i16 %220 to i8
  store volatile i8 %221, ptr inttoptr (i16 17202 to ptr), align 2, !tbaa !6
  %222 = lshr i16 %220, 8
  %223 = trunc nuw i16 %222 to i8
  store volatile i8 %223, ptr inttoptr (i16 17203 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17204 to ptr), align 4, !tbaa !6
  %224 = getelementptr inbounds nuw i8, ptr %0, i16 139
  store i8 0, ptr %224, align 1, !tbaa !115
  store volatile i8 2, ptr inttoptr (i16 17216 to ptr), align 64, !tbaa !6
  store volatile i8 15, ptr inttoptr (i16 17217 to ptr), align 1, !tbaa !6
  %225 = ptrtoint ptr %218 to i16
  %226 = trunc i16 %225 to i8
  store volatile i8 %226, ptr inttoptr (i16 17218 to ptr), align 2, !tbaa !6
  %227 = lshr i16 %225, 8
  %228 = trunc nuw i16 %227 to i8
  store volatile i8 %228, ptr inttoptr (i16 17219 to ptr), align 1, !tbaa !6
  store volatile i8 0, ptr inttoptr (i16 17220 to ptr), align 4, !tbaa !6
  %229 = getelementptr inbounds nuw i8, ptr %0, i16 2
  store i8 2, ptr %229, align 1, !tbaa !63
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal void @_title_emit(ptr noundef %0, ptr noundef captures(none) %1) #5 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i16 29
  %4 = load i8, ptr %3, align 1, !tbaa !74
  %5 = icmp eq i8 %4, 0
  br i1 %5, label %188, label %6

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 30
  %8 = load i8, ptr %7, align 1, !tbaa !77
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %39, label %10

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 25
  %12 = load i8, ptr %11, align 1, !tbaa !78
  %13 = icmp ugt i8 %12, -6
  br i1 %13, label %16, label %14

14:                                               ; preds = %10
  %15 = add nuw i8 %12, 4
  br label %16

16:                                               ; preds = %10, %14
  %17 = phi i8 [ %15, %14 ], [ -1, %10 ]
  store i8 %17, ptr %11, align 1, !tbaa !78
  %18 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %19 = load i16, ptr %18, align 1, !tbaa !70
  %20 = xor i8 %17, -1
  %21 = zext i8 %20 to i16
  %22 = mul nuw i16 %21, %21
  %23 = lshr i16 %22, 8
  %24 = sub nuw nsw i16 256, %23
  %25 = add nsw i16 %19, 8
  %26 = mul nsw i16 %24, %25
  %27 = ashr i16 %26, 4
  %28 = and i16 %27, -16
  %29 = add nsw i16 %28, -128
  %30 = getelementptr inbounds nuw i8, ptr %0, i16 19
  store i16 %29, ptr %30, align 1, !tbaa !94
  %31 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %32 = load i16, ptr %31, align 1, !tbaa !71
  %33 = add nsw i16 %32, -224
  %34 = mul nsw i16 %33, %24
  %35 = ashr i16 %34, 4
  %36 = and i16 %35, -16
  %37 = add nsw i16 %36, 3584
  %38 = getelementptr inbounds nuw i8, ptr %0, i16 21
  store i16 %37, ptr %38, align 1, !tbaa !111
  br label %64

39:                                               ; preds = %6
  %40 = getelementptr inbounds nuw i8, ptr %0, i16 31
  %41 = load i8, ptr %40, align 1, !tbaa !75
  %42 = icmp eq i8 %41, 0
  br i1 %42, label %43, label %48

43:                                               ; preds = %39
  %44 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %45 = load i16, ptr %44, align 1, !tbaa !94
  %46 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %47 = load i16, ptr %46, align 1, !tbaa !111
  br label %64

48:                                               ; preds = %39
  %49 = getelementptr inbounds nuw i8, ptr %0, i16 23
  %50 = load i16, ptr %49, align 1, !tbaa !112
  %51 = add nsw i16 %50, 2
  store i16 %51, ptr %49, align 1, !tbaa !112
  %52 = getelementptr inbounds nuw i8, ptr %0, i16 19
  %53 = load i16, ptr %52, align 1, !tbaa !94
  %54 = add nsw i16 %53, %51
  store i16 %54, ptr %52, align 1, !tbaa !94
  %55 = getelementptr inbounds nuw i8, ptr %0, i16 21
  %56 = load i16, ptr %55, align 1, !tbaa !111
  %57 = add nsw i16 %56, %51
  store i16 %57, ptr %55, align 1, !tbaa !111
  %58 = icmp sgt i16 %54, 4480
  br i1 %58, label %59, label %60

59:                                               ; preds = %48
  store i16 4480, ptr %52, align 1, !tbaa !94
  br label %60

60:                                               ; preds = %59, %48
  %61 = phi i16 [ 4480, %59 ], [ %54, %48 ]
  %62 = icmp sgt i16 %57, 4736
  br i1 %62, label %63, label %64

63:                                               ; preds = %60
  store i16 4736, ptr %55, align 1, !tbaa !111
  br label %64

64:                                               ; preds = %43, %63, %60, %16
  %65 = phi i16 [ %47, %43 ], [ 4736, %63 ], [ %57, %60 ], [ %37, %16 ]
  %66 = phi i16 [ %45, %43 ], [ %61, %63 ], [ %61, %60 ], [ %29, %16 ]
  %67 = ashr i16 %66, 4
  %68 = ashr i16 %65, 4
  %69 = getelementptr inbounds nuw i8, ptr %0, i16 38
  %70 = getelementptr inbounds nuw i8, ptr %0, i16 88
  %71 = load i8, ptr %70, align 1, !tbaa !115
  %72 = xor i8 %71, 1
  %73 = zext i8 %72 to i16
  %74 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %73
  %75 = getelementptr inbounds nuw i8, ptr %0, i16 89
  %76 = getelementptr inbounds nuw i8, ptr %0, i16 139
  %77 = load i8, ptr %76, align 1, !tbaa !115
  %78 = xor i8 %77, 1
  %79 = zext i8 %78 to i16
  %80 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %79
  tail call fastcc void @_title_build(ptr noundef nonnull %0, i16 noundef %67, i16 noundef %68, ptr noundef nonnull %74, ptr noundef nonnull %80)
  %81 = getelementptr inbounds nuw i8, ptr %1, i16 176
  %82 = load i8, ptr %81, align 1, !tbaa !43
  %83 = icmp ugt i8 %82, 15
  br i1 %83, label %109, label %84

84:                                               ; preds = %64
  %85 = load i8, ptr %70, align 1, !tbaa !115
  %86 = xor i8 %85, 1
  %87 = zext i8 %86 to i16
  %88 = getelementptr inbounds nuw [25 x i8], ptr %69, i16 %87
  %89 = ptrtoint ptr %88 to i16
  %90 = zext nneg i8 %82 to i16
  %91 = add nuw nsw i8 %82, 1
  store i8 %91, ptr %81, align 1, !tbaa !43
  %92 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %90
  %93 = getelementptr inbounds nuw i8, ptr %92, i16 10
  store i8 4, ptr %93, align 1, !tbaa !44
  store i16 17202, ptr %92, align 1, !tbaa !46
  %94 = getelementptr inbounds nuw i8, ptr %92, i16 2
  store i16 %89, ptr %94, align 1, !tbaa !50
  %95 = getelementptr inbounds nuw i8, ptr %92, i16 4
  store i16 0, ptr %95, align 1, !tbaa !52
  store i8 %86, ptr %70, align 1, !tbaa !115
  %96 = icmp eq i8 %82, 15
  br i1 %96, label %109, label %97

97:                                               ; preds = %84
  %98 = load i8, ptr %76, align 1, !tbaa !115
  %99 = xor i8 %98, 1
  %100 = zext i8 %99 to i16
  %101 = getelementptr inbounds nuw [25 x i8], ptr %75, i16 %100
  %102 = ptrtoint ptr %101 to i16
  %103 = zext nneg i8 %91 to i16
  %104 = add nuw nsw i8 %82, 2
  store i8 %104, ptr %81, align 1, !tbaa !43
  %105 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %103
  %106 = getelementptr inbounds nuw i8, ptr %105, i16 10
  store i8 4, ptr %106, align 1, !tbaa !44
  store i16 17218, ptr %105, align 1, !tbaa !46
  %107 = getelementptr inbounds nuw i8, ptr %105, i16 2
  store i16 %102, ptr %107, align 1, !tbaa !50
  %108 = getelementptr inbounds nuw i8, ptr %105, i16 4
  store i16 0, ptr %108, align 1, !tbaa !52
  store i8 %99, ptr %76, align 1, !tbaa !115
  br label %109

109:                                              ; preds = %64, %84, %97
  %110 = phi i8 [ %82, %64 ], [ 16, %84 ], [ %104, %97 ]
  %111 = getelementptr inbounds nuw i8, ptr %0, i16 28
  %112 = load i8, ptr %111, align 1, !tbaa !73
  %113 = add i8 %112, 1
  store i8 %113, ptr %111, align 1, !tbaa !73
  %114 = getelementptr inbounds nuw i8, ptr %0, i16 32
  %115 = load i8, ptr %114, align 1, !tbaa !76
  %116 = icmp eq i8 %115, 0
  br i1 %116, label %117, label %155

117:                                              ; preds = %109
  %118 = shl i8 %113, 1
  %119 = icmp sgt i8 %118, -1
  br i1 %119, label %122, label %120

120:                                              ; preds = %117
  %121 = xor i8 %118, -1
  br label %122

122:                                              ; preds = %117, %120
  %123 = phi i8 [ %121, %120 ], [ %118, %117 ]
  %124 = lshr i8 %123, 4
  %125 = add nuw nsw i8 %124, 24
  %126 = zext nneg i8 %125 to i16
  %127 = mul nuw nsw i16 %126, 1057
  %128 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 %127, ptr %128, align 1, !tbaa !79
  %129 = add i8 %118, -86
  %130 = icmp sgt i8 %129, -1
  br i1 %130, label %133, label %131

131:                                              ; preds = %122
  %132 = sub nsw i8 85, %118
  br label %133

133:                                              ; preds = %122, %131
  %134 = phi i8 [ %132, %131 ], [ %129, %122 ]
  %135 = lshr i8 %134, 2
  %136 = zext nneg i8 %135 to i16
  %137 = shl nuw nsw i16 %136, 10
  %138 = add i8 %118, 85
  %139 = icmp sgt i8 %138, -1
  br i1 %139, label %142, label %140

140:                                              ; preds = %133
  %141 = sub nuw i8 -86, %118
  br label %142

142:                                              ; preds = %133, %140
  %143 = phi i8 [ %141, %140 ], [ %138, %133 ]
  %144 = lshr i8 %143, 2
  %145 = zext nneg i8 %144 to i16
  %146 = shl nuw nsw i16 %145, 5
  %147 = add nuw nsw i16 %146, %137
  br i1 %119, label %150, label %148

148:                                              ; preds = %142
  %149 = xor i8 %118, -1
  br label %150

150:                                              ; preds = %142, %148
  %151 = phi i8 [ %149, %148 ], [ %118, %142 ]
  %152 = lshr i8 %151, 2
  %153 = zext nneg i8 %152 to i16
  %154 = add nuw nsw i16 %147, %153
  br label %157

155:                                              ; preds = %109
  %156 = getelementptr inbounds nuw i8, ptr %0, i16 34
  store i16 29596, ptr %156, align 1, !tbaa !79
  br label %157

157:                                              ; preds = %155, %150
  %158 = phi i16 [ 0, %155 ], [ %154, %150 ]
  %159 = getelementptr inbounds nuw i8, ptr %0, i16 36
  store i16 %158, ptr %159, align 1, !tbaa !80
  %160 = icmp ugt i8 %110, 15
  br i1 %160, label %188, label %161

161:                                              ; preds = %157
  %162 = getelementptr inbounds nuw i8, ptr %0, i16 34
  %163 = zext nneg i8 %110 to i16
  %164 = add nuw nsw i8 %110, 1
  store i8 %164, ptr %81, align 1, !tbaa !43
  %165 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %163
  %166 = getelementptr inbounds nuw i8, ptr %165, i16 10
  store i8 1, ptr %166, align 1, !tbaa !44
  store i16 113, ptr %165, align 1, !tbaa !46
  %167 = getelementptr inbounds nuw i8, ptr %165, i16 9
  store i8 0, ptr %167, align 1, !tbaa !47
  %168 = getelementptr inbounds nuw i8, ptr %165, i16 7
  store i8 34, ptr %168, align 1, !tbaa !48
  %169 = getelementptr inbounds nuw i8, ptr %165, i16 8
  store i8 0, ptr %169, align 1, !tbaa !49
  %170 = ptrtoint ptr %162 to i16
  %171 = getelementptr inbounds nuw i8, ptr %165, i16 2
  store i16 %170, ptr %171, align 1, !tbaa !50
  %172 = getelementptr inbounds nuw i8, ptr %165, i16 6
  store i8 0, ptr %172, align 1, !tbaa !51
  %173 = getelementptr inbounds nuw i8, ptr %165, i16 4
  store i16 2, ptr %173, align 1, !tbaa !52
  %174 = icmp eq i8 %110, 15
  br i1 %174, label %188, label %175

175:                                              ; preds = %161
  %176 = getelementptr inbounds nuw i8, ptr %0, i16 36
  %177 = zext nneg i8 %164 to i16
  %178 = add nuw nsw i8 %110, 2
  store i8 %178, ptr %81, align 1, !tbaa !43
  %179 = getelementptr inbounds nuw [11 x i8], ptr %1, i16 %177
  %180 = getelementptr inbounds nuw i8, ptr %179, i16 10
  store i8 1, ptr %180, align 1, !tbaa !44
  store i16 0, ptr %179, align 1, !tbaa !46
  %181 = getelementptr inbounds nuw i8, ptr %179, i16 9
  store i8 0, ptr %181, align 1, !tbaa !47
  %182 = getelementptr inbounds nuw i8, ptr %179, i16 7
  store i8 34, ptr %182, align 1, !tbaa !48
  %183 = getelementptr inbounds nuw i8, ptr %179, i16 8
  store i8 0, ptr %183, align 1, !tbaa !49
  %184 = ptrtoint ptr %176 to i16
  %185 = getelementptr inbounds nuw i8, ptr %179, i16 2
  store i16 %184, ptr %185, align 1, !tbaa !50
  %186 = getelementptr inbounds nuw i8, ptr %179, i16 6
  store i8 0, ptr %186, align 1, !tbaa !51
  %187 = getelementptr inbounds nuw i8, ptr %179, i16 4
  store i16 2, ptr %187, align 1, !tbaa !52
  br label %188

188:                                              ; preds = %157, %175, %161, %2
  ret void
}

; Function Attrs: nofree norecurse nounwind memory(readwrite, target_mem: none)
define internal fastcc void @_title_write16(ptr noundef readonly captures(address_is_null) %0, i8 noundef zeroext %1, i8 noundef zeroext %2) unnamed_addr #2 {
  %4 = zext i8 %1 to i16
  %5 = shl nuw nsw i16 %4, 1
  %6 = and i16 %5, 254
  %7 = sub nsw i16 32, %6
  %8 = lshr exact i16 %7, 1
  %9 = zext i8 %2 to i16
  %10 = icmp eq ptr %0, null
  %11 = and i16 %8, 255
  %12 = add nuw i16 %8, %5
  %13 = and i16 %12, 255
  %14 = shl nuw nsw i16 %9, 5
  %15 = add nuw nsw i16 %14, 20480
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %15, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br i1 %10, label %16, label %58

16:                                               ; preds = %3
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %17 = shl nuw nsw i16 %9, 5
  %18 = add nuw nsw i16 %17, 20512
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %18, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  store volatile i16 7168, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  br label %19

19:                                               ; preds = %54, %16
  ret void

20:                                               ; preds = %89
  %21 = shl nuw nsw i16 %9, 5
  %22 = add nuw nsw i16 %21, 20512
  store volatile i8 -128, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  store volatile i16 %22, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %23

23:                                               ; preds = %54, %20
  %24 = phi i8 [ 0, %20 ], [ %56, %54 ]
  %25 = zext nneg i8 %24 to i16
  %26 = icmp samesign ugt i16 %11, %25
  br i1 %26, label %54, label %27

27:                                               ; preds = %23
  %28 = icmp samesign ugt i16 %13, %25
  br i1 %28, label %29, label %54

29:                                               ; preds = %27
  %30 = sub nsw i16 %25, %11
  %31 = lshr i16 %30, 1
  %32 = and i16 %31, 255
  %33 = getelementptr inbounds nuw i8, ptr %0, i16 %32
  %34 = load i8, ptr %33, align 1, !tbaa !6
  %35 = icmp ugt i8 %34, 96
  br i1 %35, label %40, label %36

36:                                               ; preds = %29
  %37 = icmp samesign ugt i8 %34, 31
  br i1 %37, label %38, label %49

38:                                               ; preds = %36
  %39 = icmp eq i8 %34, 96
  br i1 %39, label %49, label %44

40:                                               ; preds = %29
  %41 = icmp ult i8 %34, 123
  br i1 %41, label %42, label %49

42:                                               ; preds = %40
  %43 = add nsw i8 %34, -32
  br label %44

44:                                               ; preds = %42, %38
  %45 = phi i8 [ %43, %42 ], [ %34, %38 ]
  %46 = zext nneg i8 %45 to i16
  %47 = shl nuw nsw i16 %46, 2
  %48 = add nsw i16 %47, -64
  br label %49

49:                                               ; preds = %44, %40, %38, %36
  %50 = phi i16 [ %48, %44 ], [ 64, %38 ], [ 64, %36 ], [ 64, %40 ]
  %51 = and i16 %30, 1
  %52 = or disjoint i16 %51, %50
  %53 = or disjoint i16 %52, 7170
  br label %54

54:                                               ; preds = %49, %27, %23
  %55 = phi i16 [ %53, %49 ], [ 7168, %27 ], [ 7168, %23 ]
  store volatile i16 %55, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %56 = add nuw nsw i8 %24, 1
  %57 = icmp eq i8 %56, 32
  br i1 %57, label %19, label %23, !llvm.loop !116

58:                                               ; preds = %3, %89
  %59 = phi i8 [ %91, %89 ], [ 0, %3 ]
  %60 = zext nneg i8 %59 to i16
  %61 = icmp samesign ugt i16 %11, %60
  br i1 %61, label %89, label %62

62:                                               ; preds = %58
  %63 = icmp samesign ugt i16 %13, %60
  br i1 %63, label %64, label %89

64:                                               ; preds = %62
  %65 = sub nsw i16 %60, %11
  %66 = lshr i16 %65, 1
  %67 = and i16 %66, 255
  %68 = getelementptr inbounds nuw i8, ptr %0, i16 %67
  %69 = load i8, ptr %68, align 1, !tbaa !6
  %70 = icmp ugt i8 %69, 96
  br i1 %70, label %71, label %75

71:                                               ; preds = %64
  %72 = icmp ult i8 %69, 123
  br i1 %72, label %73, label %84

73:                                               ; preds = %71
  %74 = add nsw i8 %69, -32
  br label %79

75:                                               ; preds = %64
  %76 = icmp samesign ugt i8 %69, 31
  br i1 %76, label %77, label %84

77:                                               ; preds = %75
  %78 = icmp eq i8 %69, 96
  br i1 %78, label %84, label %79

79:                                               ; preds = %77, %73
  %80 = phi i8 [ %74, %73 ], [ %69, %77 ]
  %81 = zext nneg i8 %80 to i16
  %82 = shl nuw nsw i16 %81, 2
  %83 = add nsw i16 %82, -64
  br label %84

84:                                               ; preds = %71, %75, %77, %79
  %85 = phi i16 [ %83, %79 ], [ 64, %77 ], [ 64, %75 ], [ 64, %71 ]
  %86 = and i16 %65, 1
  %87 = or disjoint i16 %86, %85
  %88 = or disjoint i16 %87, 7168
  br label %89

89:                                               ; preds = %84, %62, %58
  %90 = phi i16 [ %88, %84 ], [ 7168, %62 ], [ 7168, %58 ]
  store volatile i16 %90, ptr inttoptr (i16 8472 to ptr), align 8, !tbaa !2
  %91 = add nuw nsw i8 %59, 1
  %92 = icmp eq i8 %91, 32
  br i1 %92, label %20, label %58, !llvm.loop !116
}

; Function Attrs: nofree norecurse nosync nounwind memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_build(ptr noundef readonly captures(none) %0, i16 noundef range(i16 -2048, 2048) %1, i16 noundef range(i16 -2048, 2048) %2, ptr noundef %3, ptr noundef %4) unnamed_addr #5 {
  %6 = alloca %struct.HScrollW, align 1
  %7 = alloca %struct.HScrollW, align 1
  %8 = alloca i16, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #10
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #10
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #10
  store i16 0, ptr %8, align 1, !tbaa !2
  store ptr %3, ptr %6, align 1, !tbaa !117
  %9 = getelementptr inbounds nuw i8, ptr %6, i16 2
  store i8 0, ptr %9, align 1, !tbaa !119
  store ptr %4, ptr %7, align 1, !tbaa !117
  %10 = getelementptr inbounds nuw i8, ptr %7, i16 2
  store i8 0, ptr %10, align 1, !tbaa !119
  %11 = getelementptr inbounds nuw i8, ptr %0, i16 13
  %12 = load i16, ptr %11, align 1, !tbaa !70
  %13 = getelementptr inbounds nuw i8, ptr %0, i16 26
  %14 = load i16, ptr %13, align 1, !tbaa !114
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %1, i16 noundef 8, i16 noundef %12, i16 noundef %14)
  %15 = getelementptr inbounds nuw i8, ptr %0, i16 17
  %16 = load i16, ptr %15, align 1, !tbaa !72
  %17 = getelementptr inbounds nuw i8, ptr %0, i16 15
  %18 = load i16, ptr %17, align 1, !tbaa !71
  call fastcc void @_title_glyph_band(ptr noundef %6, ptr noundef %7, ptr noundef %8, i16 noundef %2, i16 noundef %16, i16 noundef %18, i16 noundef 0)
  %19 = load i16, ptr %8, align 1, !tbaa !2
  %20 = icmp slt i16 %19, 224
  %21 = load ptr, ptr %6, align 1, !tbaa !117
  %22 = load i8, ptr %9, align 1, !tbaa !119
  %23 = load ptr, ptr %7, align 1, !tbaa !117
  %24 = load i8, ptr %10, align 1, !tbaa !119
  br i1 %20, label %25, label %104

25:                                               ; preds = %5
  %26 = getelementptr i8, ptr %21, i16 1
  %27 = getelementptr i8, ptr %21, i16 2
  %28 = getelementptr i8, ptr %23, i16 1
  %29 = getelementptr i8, ptr %23, i16 2
  br label %30

30:                                               ; preds = %25, %100
  %31 = phi i8 [ %101, %100 ], [ %24, %25 ]
  %32 = phi i8 [ %73, %100 ], [ %22, %25 ]
  %33 = phi i16 [ %102, %100 ], [ %19, %25 ]
  %34 = sub nsw i16 224, %33
  %35 = icmp samesign ugt i16 %34, 112
  br i1 %35, label %38, label %36

36:                                               ; preds = %30
  %37 = trunc nuw nsw i16 %34 to i8
  br label %38

38:                                               ; preds = %36, %30
  %39 = phi i8 [ %37, %36 ], [ 112, %30 ]
  %40 = phi i16 [ %34, %36 ], [ 112, %30 ]
  %41 = sub nsw i16 144, %33
  %42 = zext nneg i8 %39 to i16
  %43 = trunc i16 %41 to i8
  %44 = lshr i16 %41, 8
  %45 = trunc nuw i16 %44 to i8
  %46 = zext i8 %32 to i16
  %47 = getelementptr i8, ptr %21, i16 %46
  %48 = getelementptr i8, ptr %26, i16 %46
  %49 = getelementptr i8, ptr %27, i16 %46
  %50 = icmp ult i8 %32, 22
  br i1 %50, label %54, label %72

51:                                               ; preds = %61
  %52 = add nuw nsw i8 %57, 3
  %53 = icmp ult i8 %56, 19
  br i1 %53, label %54, label %72, !llvm.loop !120

54:                                               ; preds = %38, %51
  %55 = phi i16 [ %69, %51 ], [ %42, %38 ]
  %56 = phi i8 [ %66, %51 ], [ %32, %38 ]
  %57 = phi i8 [ %52, %51 ], [ 0, %38 ]
  %58 = icmp ugt i16 %55, 127
  br i1 %58, label %61, label %59

59:                                               ; preds = %54
  %60 = trunc nuw nsw i16 %55 to i8
  br label %61

61:                                               ; preds = %59, %54
  %62 = phi i8 [ %60, %59 ], [ 127, %54 ]
  %63 = zext nneg i8 %57 to i16
  %64 = getelementptr i8, ptr %47, i16 %63
  store i8 %62, ptr %64, align 1, !tbaa !6
  %65 = getelementptr i8, ptr %48, i16 %63
  store i8 %43, ptr %65, align 1, !tbaa !6
  %66 = add nuw nsw i8 %56, 3
  %67 = getelementptr i8, ptr %49, i16 %63
  store i8 %45, ptr %67, align 1, !tbaa !6
  %68 = zext nneg i8 %62 to i16
  %69 = sub i16 %55, %68
  %70 = icmp eq i16 %69, 0
  br i1 %70, label %71, label %51, !llvm.loop !120

71:                                               ; preds = %61
  br label %72, !llvm.loop !120

72:                                               ; preds = %51, %71, %38
  %73 = phi i8 [ %66, %71 ], [ %32, %38 ], [ %66, %51 ]
  %74 = zext i8 %31 to i16
  %75 = getelementptr i8, ptr %23, i16 %74
  %76 = getelementptr i8, ptr %28, i16 %74
  %77 = getelementptr i8, ptr %29, i16 %74
  %78 = icmp ult i8 %31, 22
  br i1 %78, label %82, label %100

79:                                               ; preds = %89
  %80 = add nuw nsw i8 %85, 3
  %81 = icmp ult i8 %84, 19
  br i1 %81, label %82, label %100, !llvm.loop !120

82:                                               ; preds = %72, %79
  %83 = phi i16 [ %97, %79 ], [ %42, %72 ]
  %84 = phi i8 [ %94, %79 ], [ %31, %72 ]
  %85 = phi i8 [ %80, %79 ], [ 0, %72 ]
  %86 = icmp ugt i16 %83, 127
  br i1 %86, label %89, label %87

87:                                               ; preds = %82
  %88 = trunc nuw nsw i16 %83 to i8
  br label %89

89:                                               ; preds = %87, %82
  %90 = phi i8 [ %88, %87 ], [ 127, %82 ]
  %91 = zext nneg i8 %85 to i16
  %92 = getelementptr i8, ptr %75, i16 %91
  store i8 %90, ptr %92, align 1, !tbaa !6
  %93 = getelementptr i8, ptr %76, i16 %91
  store i8 0, ptr %93, align 1, !tbaa !6
  %94 = add nuw nsw i8 %84, 3
  %95 = getelementptr i8, ptr %77, i16 %91
  store i8 0, ptr %95, align 1, !tbaa !6
  %96 = zext nneg i8 %90 to i16
  %97 = sub i16 %83, %96
  %98 = icmp eq i16 %97, 0
  br i1 %98, label %99, label %79, !llvm.loop !120

99:                                               ; preds = %89
  br label %100, !llvm.loop !120

100:                                              ; preds = %79, %99, %72
  %101 = phi i8 [ %94, %99 ], [ %31, %72 ], [ %94, %79 ]
  %102 = add nsw i16 %40, %33
  %103 = icmp slt i16 %102, 224
  br i1 %103, label %30, label %104, !llvm.loop !121

104:                                              ; preds = %100, %5
  %105 = phi i8 [ %24, %5 ], [ %101, %100 ]
  %106 = phi i8 [ %22, %5 ], [ %73, %100 ]
  %107 = zext i8 %106 to i16
  %108 = getelementptr inbounds nuw i8, ptr %21, i16 %107
  store i8 0, ptr %108, align 1, !tbaa !6
  %109 = zext i8 %105 to i16
  %110 = getelementptr inbounds nuw i8, ptr %23, i16 %109
  store i8 0, ptr %110, align 1, !tbaa !6
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #10
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #10
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #10
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_glyph_band(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, ptr noundef nonnull captures(none) %2, i16 noundef range(i16 -2048, 2048) %3, i16 noundef %4, i16 noundef %5, i16 noundef %6) unnamed_addr #5 {
  %8 = add nsw i16 %3, -2
  %9 = add nsw i16 %4, %3
  %10 = add nsw i16 %9, 2
  %11 = load i16, ptr %2, align 1, !tbaa !2
  %12 = icmp slt i16 %8, %11
  br i1 %12, label %13, label %14

13:                                               ; preds = %7
  br label %14

14:                                               ; preds = %13, %7
  %15 = phi i16 [ %11, %13 ], [ %8, %7 ]
  %16 = icmp sgt i16 %9, 222
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  br label %18

18:                                               ; preds = %17, %14
  %19 = phi i16 [ 224, %17 ], [ %10, %14 ]
  %20 = icmp sgt i16 %19, %15
  br i1 %20, label %21, label %92

21:                                               ; preds = %18
  tail call fastcc void @_title_blank(ptr noundef %0, ptr noundef %1, i16 noundef %11, i16 noundef %15)
  %22 = sub nsw i16 %19, %15
  %23 = trunc i16 %22 to i8
  %24 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %25 = icmp eq i8 %23, 0
  br i1 %25, label %91, label %26

26:                                               ; preds = %21
  %27 = sub nsw i16 %5, %3
  %28 = and i16 %22, 255
  %29 = trunc i16 %27 to i8
  %30 = lshr i16 %27, 8
  %31 = trunc nuw i16 %30 to i8
  br label %32

32:                                               ; preds = %40, %26
  %33 = phi i16 [ %28, %26 ], [ %57, %40 ]
  %34 = load i8, ptr %24, align 1, !tbaa !119
  %35 = icmp ult i8 %34, 22
  br i1 %35, label %36, label %59

36:                                               ; preds = %32
  %37 = icmp ugt i16 %33, 127
  br i1 %37, label %40, label %38

38:                                               ; preds = %36
  %39 = trunc nuw nsw i16 %33 to i8
  br label %40

40:                                               ; preds = %38, %36
  %41 = phi i8 [ %39, %38 ], [ 127, %36 ]
  %42 = load ptr, ptr %0, align 1, !tbaa !117
  %43 = add nuw nsw i8 %34, 1
  store i8 %43, ptr %24, align 1, !tbaa !119
  %44 = zext nneg i8 %34 to i16
  %45 = getelementptr inbounds nuw i8, ptr %42, i16 %44
  store i8 %41, ptr %45, align 1, !tbaa !6
  %46 = load ptr, ptr %0, align 1, !tbaa !117
  %47 = load i8, ptr %24, align 1, !tbaa !119
  %48 = add i8 %47, 1
  store i8 %48, ptr %24, align 1, !tbaa !119
  %49 = zext i8 %47 to i16
  %50 = getelementptr inbounds nuw i8, ptr %46, i16 %49
  store i8 %29, ptr %50, align 1, !tbaa !6
  %51 = load ptr, ptr %0, align 1, !tbaa !117
  %52 = load i8, ptr %24, align 1, !tbaa !119
  %53 = add i8 %52, 1
  store i8 %53, ptr %24, align 1, !tbaa !119
  %54 = zext i8 %52 to i16
  %55 = getelementptr inbounds nuw i8, ptr %51, i16 %54
  store i8 %31, ptr %55, align 1, !tbaa !6
  %56 = zext nneg i8 %41 to i16
  %57 = sub i16 %33, %56
  %58 = icmp eq i16 %57, 0
  br i1 %58, label %59, label %32, !llvm.loop !120

59:                                               ; preds = %32, %40
  %60 = getelementptr inbounds nuw i8, ptr %1, i16 2
  %61 = trunc i16 %6 to i8
  %62 = lshr i16 %6, 8
  %63 = trunc nuw i16 %62 to i8
  br label %64

64:                                               ; preds = %72, %59
  %65 = phi i16 [ %28, %59 ], [ %89, %72 ]
  %66 = load i8, ptr %60, align 1, !tbaa !119
  %67 = icmp ult i8 %66, 22
  br i1 %67, label %68, label %91

68:                                               ; preds = %64
  %69 = icmp ugt i16 %65, 127
  br i1 %69, label %72, label %70

70:                                               ; preds = %68
  %71 = trunc nuw nsw i16 %65 to i8
  br label %72

72:                                               ; preds = %70, %68
  %73 = phi i8 [ %71, %70 ], [ 127, %68 ]
  %74 = load ptr, ptr %1, align 1, !tbaa !117
  %75 = add nuw nsw i8 %66, 1
  store i8 %75, ptr %60, align 1, !tbaa !119
  %76 = zext nneg i8 %66 to i16
  %77 = getelementptr inbounds nuw i8, ptr %74, i16 %76
  store i8 %73, ptr %77, align 1, !tbaa !6
  %78 = load ptr, ptr %1, align 1, !tbaa !117
  %79 = load i8, ptr %60, align 1, !tbaa !119
  %80 = add i8 %79, 1
  store i8 %80, ptr %60, align 1, !tbaa !119
  %81 = zext i8 %79 to i16
  %82 = getelementptr inbounds nuw i8, ptr %78, i16 %81
  store i8 %61, ptr %82, align 1, !tbaa !6
  %83 = load ptr, ptr %1, align 1, !tbaa !117
  %84 = load i8, ptr %60, align 1, !tbaa !119
  %85 = add i8 %84, 1
  store i8 %85, ptr %60, align 1, !tbaa !119
  %86 = zext i8 %84 to i16
  %87 = getelementptr inbounds nuw i8, ptr %83, i16 %86
  store i8 %63, ptr %87, align 1, !tbaa !6
  %88 = zext nneg i8 %73 to i16
  %89 = sub i16 %65, %88
  %90 = icmp eq i16 %89, 0
  br i1 %90, label %91, label %64, !llvm.loop !120

91:                                               ; preds = %64, %72, %21
  store i16 %19, ptr %2, align 1, !tbaa !2
  br label %92

92:                                               ; preds = %18, %91
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none)
define internal fastcc void @_title_blank(ptr noundef nonnull captures(none) %0, ptr noundef nonnull captures(none) %1, i16 noundef %2, i16 noundef range(i16 -2050, 225) %3) unnamed_addr #5 {
  %5 = icmp sgt i16 %3, %2
  br i1 %5, label %6, label %83

6:                                                ; preds = %4
  %7 = getelementptr inbounds nuw i8, ptr %0, i16 2
  %8 = getelementptr inbounds nuw i8, ptr %1, i16 2
  br label %9

9:                                                ; preds = %6, %79
  %10 = phi i16 [ %2, %6 ], [ %81, %79 ]
  %11 = sub nsw i16 %3, %10
  %12 = icmp sgt i16 %11, 112
  br i1 %12, label %16, label %13

13:                                               ; preds = %9
  %14 = trunc i16 %11 to i8
  %15 = icmp eq i8 %14, 0
  br i1 %15, label %79, label %16

16:                                               ; preds = %9, %13
  %17 = phi i8 [ %14, %13 ], [ 112, %9 ]
  %18 = phi i16 [ %11, %13 ], [ 112, %9 ]
  %19 = sub nsw i16 144, %10
  %20 = zext i8 %17 to i16
  %21 = trunc i16 %19 to i8
  %22 = lshr i16 %19, 8
  %23 = trunc nuw i16 %22 to i8
  br label %24

24:                                               ; preds = %32, %16
  %25 = phi i16 [ %20, %16 ], [ %49, %32 ]
  %26 = load i8, ptr %7, align 1, !tbaa !119
  %27 = icmp ult i8 %26, 22
  br i1 %27, label %28, label %51

28:                                               ; preds = %24
  %29 = icmp ugt i16 %25, 127
  br i1 %29, label %32, label %30

30:                                               ; preds = %28
  %31 = trunc nuw nsw i16 %25 to i8
  br label %32

32:                                               ; preds = %30, %28
  %33 = phi i8 [ %31, %30 ], [ 127, %28 ]
  %34 = load ptr, ptr %0, align 1, !tbaa !117
  %35 = add nuw nsw i8 %26, 1
  store i8 %35, ptr %7, align 1, !tbaa !119
  %36 = zext nneg i8 %26 to i16
  %37 = getelementptr inbounds nuw i8, ptr %34, i16 %36
  store i8 %33, ptr %37, align 1, !tbaa !6
  %38 = load ptr, ptr %0, align 1, !tbaa !117
  %39 = load i8, ptr %7, align 1, !tbaa !119
  %40 = add i8 %39, 1
  store i8 %40, ptr %7, align 1, !tbaa !119
  %41 = zext i8 %39 to i16
  %42 = getelementptr inbounds nuw i8, ptr %38, i16 %41
  store i8 %21, ptr %42, align 1, !tbaa !6
  %43 = load ptr, ptr %0, align 1, !tbaa !117
  %44 = load i8, ptr %7, align 1, !tbaa !119
  %45 = add i8 %44, 1
  store i8 %45, ptr %7, align 1, !tbaa !119
  %46 = zext i8 %44 to i16
  %47 = getelementptr inbounds nuw i8, ptr %43, i16 %46
  store i8 %23, ptr %47, align 1, !tbaa !6
  %48 = zext nneg i8 %33 to i16
  %49 = sub i16 %25, %48
  %50 = icmp eq i16 %49, 0
  br i1 %50, label %51, label %24, !llvm.loop !120

51:                                               ; preds = %24, %32
  br label %52

52:                                               ; preds = %51, %60
  %53 = phi i16 [ %77, %60 ], [ %20, %51 ]
  %54 = load i8, ptr %8, align 1, !tbaa !119
  %55 = icmp ult i8 %54, 22
  br i1 %55, label %56, label %79

56:                                               ; preds = %52
  %57 = icmp ugt i16 %53, 127
  br i1 %57, label %60, label %58

58:                                               ; preds = %56
  %59 = trunc nuw nsw i16 %53 to i8
  br label %60

60:                                               ; preds = %58, %56
  %61 = phi i8 [ %59, %58 ], [ 127, %56 ]
  %62 = load ptr, ptr %1, align 1, !tbaa !117
  %63 = add nuw nsw i8 %54, 1
  store i8 %63, ptr %8, align 1, !tbaa !119
  %64 = zext nneg i8 %54 to i16
  %65 = getelementptr inbounds nuw i8, ptr %62, i16 %64
  store i8 %61, ptr %65, align 1, !tbaa !6
  %66 = load ptr, ptr %1, align 1, !tbaa !117
  %67 = load i8, ptr %8, align 1, !tbaa !119
  %68 = add i8 %67, 1
  store i8 %68, ptr %8, align 1, !tbaa !119
  %69 = zext i8 %67 to i16
  %70 = getelementptr inbounds nuw i8, ptr %66, i16 %69
  store i8 0, ptr %70, align 1, !tbaa !6
  %71 = load ptr, ptr %1, align 1, !tbaa !117
  %72 = load i8, ptr %8, align 1, !tbaa !119
  %73 = add i8 %72, 1
  store i8 %73, ptr %8, align 1, !tbaa !119
  %74 = zext i8 %72 to i16
  %75 = getelementptr inbounds nuw i8, ptr %71, i16 %74
  store i8 0, ptr %75, align 1, !tbaa !6
  %76 = zext nneg i8 %61 to i16
  %77 = sub i16 %53, %76
  %78 = icmp eq i16 %77, 0
  br i1 %78, label %79, label %52, !llvm.loop !120

79:                                               ; preds = %52, %60, %13
  %80 = phi i16 [ %11, %13 ], [ %18, %60 ], [ %18, %52 ]
  %81 = add nsw i16 %80, %10
  %82 = icmp sgt i16 %3, %81
  br i1 %82, label %9, label %83, !llvm.loop !121

83:                                               ; preds = %79, %4
  ret void
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none)
define internal fastcc void @canvas_line(i16 noundef %0, i16 noundef range(i16 0, 121) %1, i16 noundef %2, i16 noundef range(i16 7, 128) %3, i8 noundef zeroext range(i8 1, 4) %4) unnamed_addr #6 {
  %6 = icmp sgt i16 %2, %0
  br i1 %6, label %7, label %9

7:                                                ; preds = %5
  %8 = sub nsw i16 %2, %0
  br label %11

9:                                                ; preds = %5
  %10 = sub nsw i16 %0, %2
  br label %11

11:                                               ; preds = %9, %7
  %12 = phi i16 [ %8, %7 ], [ %10, %9 ]
  %13 = icmp samesign ugt i16 %3, %1
  br i1 %13, label %14, label %16

14:                                               ; preds = %11
  %15 = sub nuw nsw i16 %3, %1
  br label %18

16:                                               ; preds = %11
  %17 = sub nuw nsw i16 %1, %3
  br label %18

18:                                               ; preds = %16, %14
  %19 = phi i16 [ 1, %14 ], [ -1, %16 ]
  %20 = phi i16 [ %15, %14 ], [ %17, %16 ]
  %21 = select i1 %6, i16 1, i16 -1
  %22 = sub nsw i16 %12, %20
  %23 = and i8 %4, 1
  %24 = icmp eq i8 %23, 0
  %25 = icmp samesign ult i8 %4, 2
  %26 = sub nsw i16 0, %20
  br i1 %24, label %27, label %124

27:                                               ; preds = %18
  br i1 %25, label %28, label %114

28:                                               ; preds = %27
  %29 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1
  %30 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1
  br label %31

31:                                               ; preds = %72, %28
  %32 = phi i16 [ %58, %72 ], [ %30, %28 ]
  %33 = phi i16 [ %59, %72 ], [ %29, %28 ]
  %34 = phi i16 [ %74, %72 ], [ %1, %28 ]
  %35 = phi i16 [ %73, %72 ], [ %22, %28 ]
  %36 = phi i16 [ %70, %72 ], [ %0, %28 ]
  %37 = icmp ugt i16 %34, 127
  %38 = shl nuw nsw i16 %34, 1
  %39 = and i16 %38, 240
  %40 = icmp eq i16 %34, %3
  br label %41

41:                                               ; preds = %31, %68
  %42 = phi i16 [ %58, %68 ], [ %32, %31 ]
  %43 = phi i16 [ %59, %68 ], [ %33, %31 ]
  %44 = phi i16 [ %69, %68 ], [ %35, %31 ]
  %45 = phi i16 [ %70, %68 ], [ %36, %31 ]
  %46 = icmp ugt i16 %45, 127
  %47 = select i1 %46, i1 true, i1 %37
  br i1 %47, label %57, label %48

48:                                               ; preds = %41
  %49 = lshr i16 %45, 3
  %50 = or disjoint i16 %49, %39
  %51 = icmp ult i16 %50, %43
  br i1 %51, label %52, label %53

52:                                               ; preds = %48
  store i16 %50, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !22
  br label %53

53:                                               ; preds = %52, %48
  %54 = phi i16 [ %50, %52 ], [ %43, %48 ]
  %55 = icmp ugt i16 %50, %42
  br i1 %55, label %56, label %57

56:                                               ; preds = %53
  store i16 %50, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !23
  br label %57

57:                                               ; preds = %41, %56, %53
  %58 = phi i16 [ %50, %56 ], [ %42, %53 ], [ %42, %41 ]
  %59 = phi i16 [ %54, %56 ], [ %54, %53 ], [ %43, %41 ]
  %60 = icmp eq i16 %45, %2
  %61 = select i1 %60, i1 %40, i1 false
  br i1 %61, label %224, label %62

62:                                               ; preds = %57
  %63 = shl nsw i16 %44, 1
  %64 = icmp sgt i16 %63, %26
  br i1 %64, label %65, label %68

65:                                               ; preds = %62
  %66 = sub nsw i16 %44, %20
  %67 = add nsw i16 %45, %21
  br label %68

68:                                               ; preds = %65, %62
  %69 = phi i16 [ %66, %65 ], [ %44, %62 ]
  %70 = phi i16 [ %67, %65 ], [ %45, %62 ]
  %71 = icmp slt i16 %63, %12
  br i1 %71, label %72, label %41

72:                                               ; preds = %68
  %73 = add nsw i16 %69, %12
  %74 = add nsw i16 %34, %19
  br label %31

75:                                               ; preds = %114, %107
  %76 = phi i16 [ %108, %107 ], [ %116, %114 ]
  %77 = phi i16 [ %109, %107 ], [ %117, %114 ]
  %78 = icmp ugt i16 %77, 127
  %79 = select i1 %78, i1 true, i1 %118
  br i1 %79, label %98, label %80

80:                                               ; preds = %75
  %81 = lshr i16 %77, 3
  %82 = or disjoint i16 %81, %120
  %83 = shl nuw nsw i16 %82, 4
  %84 = getelementptr inbounds i8, ptr %122, i16 %83
  %85 = and i16 %77, 7
  %86 = lshr exact i16 128, %85
  %87 = getelementptr inbounds nuw i8, ptr %84, i16 1
  %88 = load i8, ptr %87, align 1, !tbaa !6
  %89 = trunc nuw i16 %86 to i8
  %90 = or i8 %88, %89
  store i8 %90, ptr %87, align 1, !tbaa !6
  %91 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !22
  %92 = icmp ult i16 %82, %91
  br i1 %92, label %93, label %94

93:                                               ; preds = %80
  store i16 %82, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !22
  br label %94

94:                                               ; preds = %93, %80
  %95 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !23
  %96 = icmp ugt i16 %82, %95
  br i1 %96, label %97, label %98

97:                                               ; preds = %94
  store i16 %82, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !23
  br label %98

98:                                               ; preds = %75, %97, %94
  %99 = icmp eq i16 %77, %2
  %100 = select i1 %99, i1 %123, i1 false
  br i1 %100, label %224, label %101

101:                                              ; preds = %98
  %102 = shl nsw i16 %76, 1
  %103 = icmp sgt i16 %102, %26
  br i1 %103, label %104, label %107

104:                                              ; preds = %101
  %105 = sub nsw i16 %76, %20
  %106 = add nsw i16 %77, %21
  br label %107

107:                                              ; preds = %104, %101
  %108 = phi i16 [ %105, %104 ], [ %76, %101 ]
  %109 = phi i16 [ %106, %104 ], [ %77, %101 ]
  %110 = icmp slt i16 %102, %12
  br i1 %110, label %111, label %75

111:                                              ; preds = %107
  %112 = add nsw i16 %108, %12
  %113 = add nsw i16 %115, %19
  br label %114

114:                                              ; preds = %27, %111
  %115 = phi i16 [ %113, %111 ], [ %1, %27 ]
  %116 = phi i16 [ %112, %111 ], [ %22, %27 ]
  %117 = phi i16 [ %109, %111 ], [ %0, %27 ]
  %118 = icmp ugt i16 %115, 127
  %119 = shl nuw nsw i16 %115, 1
  %120 = and i16 %119, 240
  %121 = and i16 %119, 14
  %122 = getelementptr inbounds i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %121
  %123 = icmp eq i16 %115, %3
  br label %75

124:                                              ; preds = %18
  br i1 %25, label %125, label %214

125:                                              ; preds = %124, %170
  %126 = phi i16 [ %172, %170 ], [ %1, %124 ]
  %127 = phi i16 [ %171, %170 ], [ %22, %124 ]
  %128 = phi i16 [ %168, %170 ], [ %0, %124 ]
  %129 = icmp ugt i16 %126, 127
  %130 = shl nuw nsw i16 %126, 1
  %131 = and i16 %130, 240
  %132 = and i16 %130, 14
  %133 = getelementptr inbounds i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %132
  %134 = icmp eq i16 %126, %3
  br label %135

135:                                              ; preds = %125, %166
  %136 = phi i16 [ %167, %166 ], [ %127, %125 ]
  %137 = phi i16 [ %168, %166 ], [ %128, %125 ]
  %138 = icmp ugt i16 %137, 127
  %139 = select i1 %138, i1 true, i1 %129
  br i1 %139, label %157, label %140

140:                                              ; preds = %135
  %141 = lshr i16 %137, 3
  %142 = or disjoint i16 %141, %131
  %143 = shl nuw nsw i16 %142, 4
  %144 = getelementptr inbounds i8, ptr %133, i16 %143
  %145 = and i16 %137, 7
  %146 = lshr exact i16 128, %145
  %147 = load i8, ptr %144, align 1, !tbaa !6
  %148 = trunc nuw i16 %146 to i8
  %149 = or i8 %147, %148
  store i8 %149, ptr %144, align 1, !tbaa !6
  %150 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !22
  %151 = icmp ult i16 %142, %150
  br i1 %151, label %152, label %153

152:                                              ; preds = %140
  store i16 %142, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !22
  br label %153

153:                                              ; preds = %152, %140
  %154 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !23
  %155 = icmp ugt i16 %142, %154
  br i1 %155, label %156, label %157

156:                                              ; preds = %153
  store i16 %142, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !23
  br label %157

157:                                              ; preds = %135, %156, %153
  %158 = icmp eq i16 %137, %2
  %159 = select i1 %158, i1 %134, i1 false
  br i1 %159, label %224, label %160

160:                                              ; preds = %157
  %161 = shl nsw i16 %136, 1
  %162 = icmp sgt i16 %161, %26
  br i1 %162, label %163, label %166

163:                                              ; preds = %160
  %164 = sub nsw i16 %136, %20
  %165 = add nsw i16 %137, %21
  br label %166

166:                                              ; preds = %163, %160
  %167 = phi i16 [ %164, %163 ], [ %136, %160 ]
  %168 = phi i16 [ %165, %163 ], [ %137, %160 ]
  %169 = icmp slt i16 %161, %12
  br i1 %169, label %170, label %135

170:                                              ; preds = %166
  %171 = add nsw i16 %167, %12
  %172 = add nsw i16 %126, %19
  br label %125

173:                                              ; preds = %214, %207
  %174 = phi i16 [ %208, %207 ], [ %216, %214 ]
  %175 = phi i16 [ %209, %207 ], [ %217, %214 ]
  %176 = icmp ugt i16 %175, 127
  %177 = select i1 %176, i1 true, i1 %218
  br i1 %177, label %198, label %178

178:                                              ; preds = %173
  %179 = lshr i16 %175, 3
  %180 = or disjoint i16 %179, %220
  %181 = shl nuw nsw i16 %180, 4
  %182 = getelementptr inbounds i8, ptr %222, i16 %181
  %183 = and i16 %175, 7
  %184 = lshr exact i16 128, %183
  %185 = load i8, ptr %182, align 1, !tbaa !6
  %186 = trunc nuw i16 %184 to i8
  %187 = or i8 %185, %186
  store i8 %187, ptr %182, align 1, !tbaa !6
  %188 = getelementptr inbounds nuw i8, ptr %182, i16 1
  %189 = load i8, ptr %188, align 1, !tbaa !6
  %190 = or i8 %189, %186
  store i8 %190, ptr %188, align 1, !tbaa !6
  %191 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !22
  %192 = icmp ult i16 %180, %191
  br i1 %192, label %193, label %194

193:                                              ; preds = %178
  store i16 %180, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4295), align 1, !tbaa !22
  br label %194

194:                                              ; preds = %193, %178
  %195 = load i16, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !23
  %196 = icmp ugt i16 %180, %195
  br i1 %196, label %197, label %198

197:                                              ; preds = %194
  store i16 %180, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 4297), align 1, !tbaa !23
  br label %198

198:                                              ; preds = %173, %194, %197
  %199 = icmp eq i16 %175, %2
  %200 = select i1 %199, i1 %223, i1 false
  br i1 %200, label %224, label %201

201:                                              ; preds = %198
  %202 = shl nsw i16 %174, 1
  %203 = icmp sgt i16 %202, %26
  br i1 %203, label %204, label %207

204:                                              ; preds = %201
  %205 = sub nsw i16 %174, %20
  %206 = add nsw i16 %175, %21
  br label %207

207:                                              ; preds = %204, %201
  %208 = phi i16 [ %205, %204 ], [ %174, %201 ]
  %209 = phi i16 [ %206, %204 ], [ %175, %201 ]
  %210 = icmp slt i16 %202, %12
  br i1 %210, label %211, label %173

211:                                              ; preds = %207
  %212 = add nsw i16 %208, %12
  %213 = add nsw i16 %215, %19
  br label %214

214:                                              ; preds = %124, %211
  %215 = phi i16 [ %213, %211 ], [ %1, %124 ]
  %216 = phi i16 [ %212, %211 ], [ %22, %124 ]
  %217 = phi i16 [ %209, %211 ], [ %0, %124 ]
  %218 = icmp ugt i16 %215, 127
  %219 = shl nuw nsw i16 %215, 1
  %220 = and i16 %219, 240
  %221 = and i16 %219, 14
  %222 = getelementptr inbounds i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 199), i16 %221
  %223 = icmp eq i16 %215, %3
  br label %173

224:                                              ; preds = %198, %157, %98, %57
  ret void
}

; Function Attrs: nofree noinline norecurse nounwind memory(readwrite, target_mem: none)
define internal fastcc void @upq_flush() unnamed_addr #7 {
  %1 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 177), align 1, !tbaa !122
  %2 = zext i8 %1 to i16
  %3 = shl nuw nsw i16 %2, 4
  %4 = add nuw nsw i16 %3, 17152
  %5 = inttoptr i16 %4 to ptr
  %6 = shl nuw i16 1, %2
  %7 = trunc i16 %6 to i8
  %8 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %9 = icmp eq i8 %8, 0
  br i1 %9, label %108, label %10

10:                                               ; preds = %0
  %11 = getelementptr inbounds nuw i8, ptr %5, i16 1
  %12 = getelementptr inbounds nuw i8, ptr %5, i16 2
  %13 = getelementptr inbounds nuw i8, ptr %5, i16 3
  %14 = getelementptr inbounds nuw i8, ptr %5, i16 4
  %15 = getelementptr inbounds nuw i8, ptr %5, i16 5
  %16 = getelementptr inbounds nuw i8, ptr %5, i16 6
  br label %17

17:                                               ; preds = %10, %86
  %18 = phi i8 [ %8, %10 ], [ %89, %86 ]
  %19 = phi i16 [ 0, %10 ], [ %87, %86 ]
  %20 = phi i8 [ 0, %10 ], [ %88, %86 ]
  %21 = zext i8 %20 to i16
  %22 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %21
  %23 = getelementptr inbounds nuw i8, ptr %22, i16 10
  %24 = load i8, ptr %23, align 1, !tbaa !44
  switch i8 %24, label %44 [
    i8 3, label %25
    i8 4, label %34
  ]

25:                                               ; preds = %17
  %26 = load i16, ptr %22, align 1, !tbaa !46
  %27 = inttoptr i16 %26 to ptr
  %28 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %29 = load i16, ptr %28, align 1, !tbaa !50
  %30 = trunc i16 %29 to i8
  store volatile i8 %30, ptr %27, align 1, !tbaa !6
  %31 = load i16, ptr %28, align 1, !tbaa !50
  %32 = lshr i16 %31, 8
  %33 = trunc nuw i16 %32 to i8
  store volatile i8 %33, ptr %27, align 1, !tbaa !6
  br label %86

34:                                               ; preds = %17
  %35 = load i16, ptr %22, align 1, !tbaa !46
  %36 = inttoptr i16 %35 to ptr
  %37 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %38 = load i16, ptr %37, align 1, !tbaa !50
  %39 = trunc i16 %38 to i8
  store volatile i8 %39, ptr %36, align 1, !tbaa !6
  %40 = load i16, ptr %37, align 1, !tbaa !50
  %41 = lshr i16 %40, 8
  %42 = trunc nuw i16 %41 to i8
  %43 = getelementptr inbounds nuw i8, ptr %36, i16 1
  store volatile i8 %42, ptr %43, align 1, !tbaa !6
  br label %86

44:                                               ; preds = %17
  %45 = icmp eq i16 %19, 0
  br i1 %45, label %51, label %46

46:                                               ; preds = %44
  %47 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %48 = load i16, ptr %47, align 1, !tbaa !52
  %49 = add i16 %48, %19
  %50 = icmp ugt i16 %49, 5100
  br i1 %50, label %91, label %51

51:                                               ; preds = %46, %44
  switch i8 %24, label %59 [
    i8 0, label %52
    i8 1, label %56
  ]

52:                                               ; preds = %51
  %53 = getelementptr inbounds nuw i8, ptr %22, i16 9
  %54 = load i8, ptr %53, align 1, !tbaa !47
  store volatile i8 %54, ptr inttoptr (i16 8469 to ptr), align 1, !tbaa !6
  %55 = load i16, ptr %22, align 1, !tbaa !46
  store volatile i16 %55, ptr inttoptr (i16 8470 to ptr), align 2, !tbaa !2
  br label %65

56:                                               ; preds = %51
  %57 = load i16, ptr %22, align 1, !tbaa !46
  %58 = trunc i16 %57 to i8
  store volatile i8 %58, ptr inttoptr (i16 8481 to ptr), align 1, !tbaa !6
  br label %65

59:                                               ; preds = %51
  %60 = load i16, ptr %22, align 1, !tbaa !46
  %61 = trunc i16 %60 to i8
  store volatile i8 %61, ptr inttoptr (i16 8450 to ptr), align 2, !tbaa !6
  %62 = load i16, ptr %22, align 1, !tbaa !46
  %63 = lshr i16 %62, 8
  %64 = trunc nuw i16 %63 to i8
  store volatile i8 %64, ptr inttoptr (i16 8451 to ptr), align 1, !tbaa !6
  br label %65

65:                                               ; preds = %56, %59, %52
  %66 = getelementptr inbounds nuw i8, ptr %22, i16 8
  %67 = load i8, ptr %66, align 1, !tbaa !49
  store volatile i8 %67, ptr %5, align 16, !tbaa !6
  %68 = getelementptr inbounds nuw i8, ptr %22, i16 7
  %69 = load i8, ptr %68, align 1, !tbaa !48
  store volatile i8 %69, ptr %11, align 1, !tbaa !6
  %70 = getelementptr inbounds nuw i8, ptr %22, i16 2
  %71 = load i16, ptr %70, align 1, !tbaa !50
  %72 = trunc i16 %71 to i8
  store volatile i8 %72, ptr %12, align 2, !tbaa !6
  %73 = load i16, ptr %70, align 1, !tbaa !50
  %74 = lshr i16 %73, 8
  %75 = trunc nuw i16 %74 to i8
  store volatile i8 %75, ptr %13, align 1, !tbaa !6
  %76 = getelementptr inbounds nuw i8, ptr %22, i16 6
  %77 = load i8, ptr %76, align 1, !tbaa !51
  store volatile i8 %77, ptr %14, align 4, !tbaa !6
  %78 = getelementptr inbounds nuw i8, ptr %22, i16 4
  %79 = load i16, ptr %78, align 1, !tbaa !52
  %80 = trunc i16 %79 to i8
  store volatile i8 %80, ptr %15, align 1, !tbaa !6
  %81 = load i16, ptr %78, align 1, !tbaa !52
  %82 = lshr i16 %81, 8
  %83 = trunc nuw i16 %82 to i8
  store volatile i8 %83, ptr %16, align 2, !tbaa !6
  store volatile i8 %7, ptr inttoptr (i16 16907 to ptr), align 1, !tbaa !6
  %84 = load i16, ptr %78, align 1, !tbaa !52
  %85 = add i16 %84, %19
  br label %86

86:                                               ; preds = %65, %34, %25
  %87 = phi i16 [ %19, %25 ], [ %19, %34 ], [ %85, %65 ]
  %88 = add nuw i8 %20, 1
  %89 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %90 = icmp ult i8 %88, %89
  br i1 %90, label %17, label %91

91:                                               ; preds = %86, %46
  %92 = phi i8 [ %89, %86 ], [ %18, %46 ]
  %93 = phi i8 [ %88, %86 ], [ %20, %46 ]
  %94 = icmp ult i8 %93, %92
  br i1 %94, label %95, label %108

95:                                               ; preds = %91
  %96 = icmp eq i8 %93, 0
  br i1 %96, label %110, label %97

97:                                               ; preds = %95, %97
  %98 = phi i8 [ %101, %97 ], [ 0, %95 ]
  %99 = phi i8 [ %104, %97 ], [ %93, %95 ]
  %100 = zext i8 %99 to i16
  %101 = add i8 %98, 1
  %102 = zext i8 %98 to i16
  %103 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %102
  %104 = add nuw i8 %99, 1
  %105 = getelementptr inbounds nuw [11 x i8], ptr @main.a, i16 %100
  tail call void @llvm.memcpy.p0.p0.i16(ptr noundef nonnull align 1 dereferenceable(11) %103, ptr noundef nonnull align 1 dereferenceable(11) %105, i16 11, i1 false), !tbaa.struct !123
  %106 = load i8, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  %107 = icmp ult i8 %104, %106
  br i1 %107, label %97, label %108, !llvm.loop !124

108:                                              ; preds = %97, %91, %0
  %109 = phi i8 [ 0, %91 ], [ 0, %0 ], [ %101, %97 ]
  store i8 %109, ptr getelementptr inbounds nuw (i8, ptr @main.a, i16 176), align 1, !tbaa !43
  br label %110

110:                                              ; preds = %108, %95
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #8

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #9

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i16(ptr writeonly captures(none), i8, i16, i1 immarg) #9

attributes #0 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree norecurse nounwind memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #3 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #4 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nofree norecurse nosync nounwind memory(write, argmem: readwrite, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #6 = { nofree noinline norecurse nosync nounwind memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #7 = { nofree noinline norecurse nounwind memory(readwrite, target_mem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #8 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #10 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}
!llvm.errno.tbaa = !{!2}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"int", !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!4, !4, i64 0}
!7 = !{!8, !4, i64 194}
!8 = !{!"", !9, i64 0, !10, i64 178, !11, i64 182, !4, i64 191, !4, i64 192, !4, i64 193, !4, i64 194, !4, i64 195}
!9 = !{!"", !4, i64 0, !4, i64 176, !4, i64 177}
!10 = !{!"", !3, i64 0, !3, i64 2}
!11 = !{!"", !4, i64 0, !4, i64 8}
!12 = !{!8, !4, i64 195}
!13 = !{!14, !16, i64 0}
!14 = !{!"", !15, i64 0, !4, i64 3, !3, i64 4099, !3, i64 4101, !3, i64 4103, !3, i64 4105, !4, i64 4107, !4, i64 4108}
!15 = !{!"Drawable", !16, i64 0, !4, i64 2}
!16 = !{!"any pointer", !4, i64 0}
!17 = !{!14, !4, i64 2}
!18 = !{!14, !3, i64 4103}
!19 = !{!14, !3, i64 4105}
!20 = !{!14, !4, i64 4107}
!21 = !{!14, !4, i64 4108}
!22 = !{!14, !3, i64 4099}
!23 = !{!14, !3, i64 4101}
!24 = !{!25, !16, i64 0}
!25 = !{!"", !15, i64 0, !3, i64 3, !4, i64 5, !4, i64 7, !4, i64 135}
!26 = !{!25, !4, i64 2}
!27 = !{!25, !3, i64 3}
!28 = !{!25, !4, i64 135}
!29 = !{!8, !4, i64 192}
!30 = !{!8, !4, i64 193}
!31 = !{!11, !4, i64 8}
!32 = !{!33, !33, i64 0}
!33 = !{!"p1 _ZTS8Drawable", !16, i64 0}
!34 = distinct !{!34, !35}
!35 = !{!"llvm.loop.mustprogress"}
!36 = distinct !{!36, !35}
!37 = !{!8, !4, i64 191}
!38 = !{!15, !4, i64 2}
!39 = !{!15, !16, i64 0}
!40 = !{!41, !16, i64 0}
!41 = !{!"", !16, i64 0, !16, i64 2}
!42 = distinct !{null, null, null}
!43 = !{!9, !4, i64 176}
!44 = !{!45, !4, i64 10}
!45 = !{!"", !3, i64 0, !3, i64 2, !3, i64 4, !4, i64 6, !4, i64 7, !4, i64 8, !4, i64 9, !4, i64 10}
!46 = !{!45, !3, i64 0}
!47 = !{!45, !4, i64 9}
!48 = !{!45, !4, i64 7}
!49 = !{!45, !4, i64 8}
!50 = !{!45, !3, i64 2}
!51 = !{!45, !4, i64 6}
!52 = !{!45, !3, i64 4}
!53 = distinct !{!53, !35}
!54 = distinct !{!54, !35}
!55 = distinct !{!55, !35}
!56 = distinct !{!56, !35}
!57 = !{!58, !4, i64 4953}
!58 = !{!"", !8, i64 0, !14, i64 196, !25, i64 4305, !4, i64 4441, !4, i64 4953}
!59 = !{!60, !16, i64 0}
!60 = !{!"", !15, i64 0, !61, i64 3, !61, i64 5, !61, i64 7, !61, i64 9, !4, i64 11, !4, i64 12, !3, i64 13, !3, i64 15, !3, i64 17, !3, i64 19, !3, i64 21, !3, i64 23, !4, i64 25, !3, i64 26, !4, i64 28, !4, i64 29, !4, i64 30, !4, i64 31, !4, i64 32, !4, i64 33, !3, i64 34, !3, i64 36, !62, i64 38, !62, i64 89}
!61 = !{!"p1 omnipotent char", !16, i64 0}
!62 = !{!"", !4, i64 0, !4, i64 50}
!63 = !{!60, !4, i64 2}
!64 = !{!60, !61, i64 3}
!65 = !{!60, !61, i64 5}
!66 = !{!60, !61, i64 7}
!67 = !{!60, !4, i64 11}
!68 = !{!60, !61, i64 9}
!69 = !{!60, !4, i64 12}
!70 = !{!60, !3, i64 13}
!71 = !{!60, !3, i64 15}
!72 = !{!60, !3, i64 17}
!73 = !{!60, !4, i64 28}
!74 = !{!60, !4, i64 29}
!75 = !{!60, !4, i64 31}
!76 = !{!60, !4, i64 32}
!77 = !{!60, !4, i64 30}
!78 = !{!60, !4, i64 25}
!79 = !{!60, !3, i64 34}
!80 = !{!60, !3, i64 36}
!81 = distinct !{null, null}
!82 = !{!60, !4, i64 33}
!83 = !{!41, !16, i64 2}
!84 = distinct !{null, null, null, null, null}
!85 = distinct !{!85, !35}
!86 = distinct !{!86, !35}
!87 = distinct !{!87, !35}
!88 = distinct !{null, null, null, null}
!89 = distinct !{!89, !35}
!90 = distinct !{null, null, null, null, null}
!91 = distinct !{!91, !35}
!92 = distinct !{!92, !35}
!93 = distinct !{null, null, null, null}
!94 = !{!60, !3, i64 19}
!95 = distinct !{null, null, null, null, null}
!96 = distinct !{!96, !35}
!97 = distinct !{!97, !35}
!98 = distinct !{!98, !35, !99}
!99 = !{!"llvm.loop.peeled.count", i32 2}
!100 = distinct !{!100, !35}
!101 = distinct !{!101, !35}
!102 = distinct !{!102, !35, !99}
!103 = distinct !{null, null, null}
!104 = distinct !{!104, !35}
!105 = distinct !{!105, !35}
!106 = distinct !{!106, !35}
!107 = distinct !{!107, !35}
!108 = distinct !{!108, !35}
!109 = distinct !{!109, !35}
!110 = distinct !{!110, !35}
!111 = !{!60, !3, i64 21}
!112 = !{!60, !3, i64 23}
!113 = distinct !{!113, !35}
!114 = !{!60, !3, i64 26}
!115 = !{!62, !4, i64 50}
!116 = distinct !{!116, !35}
!117 = !{!118, !16, i64 0}
!118 = !{!"", !16, i64 0, !4, i64 2}
!119 = !{!118, !4, i64 2}
!120 = distinct !{!120, !35}
!121 = distinct !{!121, !35}
!122 = !{!9, !4, i64 177}
!123 = !{i64 0, i64 2, !2, i64 2, i64 2, !2, i64 4, i64 2, !2, i64 6, i64 1, !6, i64 7, i64 1, !6, i64 8, i64 1, !6, i64 9, i64 1, !6, i64 10, i64 1, !6}
!124 = distinct !{!124, !35}
