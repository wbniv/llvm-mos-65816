#!/usr/bin/env bash
set -euo pipefail
D=/home/will/llvm-mos-65816-carrypress/build/carry-press/fixed
T=/home/will/llvm-mos-65816-carrypress/docs/defects/evidence/2026-10-01-carry-pressure-contract/tools
A=/home/will/llvm-mos-65816/build/far-review-defects/candidate/llc
X=/home/will/llvm-mos-65816-carrypress/build/carry-press/llc-x4
F="-mos-default-gpr-psets=a -mos-gpr-pset-a-limit=1"
export JOBS=${JOBS:-1}
for L in Os Oz O2 O3; do
  for m in mos6502 mosw65816 a16; do
    case $m in mos6502) M="-mtriple=mos -mcpu=mos6502";; mosw65816) M="-mtriple=mos -mcpu=mosw65816";; a16) M="-mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16";; esac
    $T/llc-sizes.sh $A $D/base.$L.$m.tsv $D/fixed-$L.list $M
    $T/llc-sizes.sh $X $D/up.$L.$m.tsv $D/fixed-$L.list $M
    [ $m = a16 ] && continue
    $T/llc-sizes.sh $X $D/cand.$L.$m.tsv $D/fixed-$L.list $M $F
    [ $L = O3 ] && $T/llc-sizes.sh $X $D/candkeep.$L.$m.tsv $D/fixed-$L.list $M $F -mos-default-gpr-psets-o3
    echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) $L $m done"
  done
done
echo FIXED-rc=0
