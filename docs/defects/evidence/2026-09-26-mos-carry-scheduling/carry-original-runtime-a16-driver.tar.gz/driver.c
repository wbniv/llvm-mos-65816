#include <stdint.h>
extern volatile int32_t i0, i1, i2;
extern volatile uint32_t out;
extern void f(void);
volatile uint32_t corpus_result;
static const int32_t indices[][3] = {{100,50000,90000},{0,32767,32768},{65535,65536,98303},{32768,32767,1},{90000,90001,90002},{65534,65535,65536}};
int main(void) { uint32_t h = 0x93e7a521UL; for (unsigned k=0;k<24;++k) { unsigned j=k%6; i0=indices[j][0]; i1=indices[j][1]; i2=indices[j][2]; f(); h=(h<<1)|(h>>31); h^=out; } corpus_result=h; for (;;) __asm__ volatile("wai"); }
