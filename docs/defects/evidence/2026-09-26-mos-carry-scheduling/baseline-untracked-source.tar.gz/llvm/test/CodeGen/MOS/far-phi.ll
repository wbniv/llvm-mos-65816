; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16 -verify-machineinstrs -stop-after=legalizer -o - < %s | FileCheck %s
; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16 -verify-machineinstrs < %s | FileCheck %s --check-prefix=ASM

; #321: G_PHI is legal only for {s1, s8, p0, p1}, so a far pointer (p2) carried
; across a loop back-edge -- a far-pointer induction variable -- forms a
; G_PHI(p2) that no scalar/widen action covers. It must therefore be custom-
; legalised; without that, legalization of this function fails outright
; ("unable to legalize instruction: G_PHI (p2)").
;
; MOSLegalizerInfo::legalizePhi custom-legalises it through the SAME p2 <-> s32
; bridge that legalizePtrAdd and the far load/store paths use: each incoming
; value is ptrtoint'd at the end of its predecessor block, the phi itself is
; retyped to s32 (which the standard narrowScalar-of-G_PHI path then splits into
; four s8 phis), and the result is inttoptr'd back to p2 immediately after the
; block's phis. The post-legalizer signature below is that bridge.
;
; The stride is loaded volatile each iteration so the loop cannot be strength-
; reduced into a near offset induction variable, which is what keeps the far
; pointer itself on the back-edge.

target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"

@stride = global i32 0

define i8 @far_ptr_induction(i32 %a, i16 %n) {
; CHECK-LABEL: name: far_ptr_induction
;
; Preheader: the incoming far pointer is ptrtoint'd and unmerged to the four
; bytes that feed the phis.
; CHECK: bb.{{[0-9]+}}.entry:
; CHECK: %[[P0:[0-9]+]]:_(p2) = G_INTTOPTR
; CHECK: %[[I0:[0-9]+]]:_(s32) = G_PTRTOINT %[[P0]](p2)
; CHECK: %[[W0:[0-9]+]]:_(s16), %[[W1:[0-9]+]]:_(s16) = G_UNMERGE_VALUES %[[I0]](s32)
; CHECK: %[[A0:[0-9]+]]:_(s8), %[[A1:[0-9]+]]:_(s8) = G_UNMERGE_VALUES %[[W0]](s16)
; CHECK: %[[A2:[0-9]+]]:_(s8), %[[A3:[0-9]+]]:_(s8) = G_UNMERGE_VALUES %[[W1]](s16)
;
; Loop header: four s8 phis -- NOT a p2 phi -- re-merged and inttoptr'd back to
; p2 for the dereference.
; CHECK: bb.{{[0-9]+}}.loop:
; CHECK-NOT: (p2) = G_PHI
; CHECK: %[[Q0:[0-9]+]]:_(s8) = G_PHI %[[A0]](s8), %bb.{{[0-9]+}},
; CHECK: %[[Q1:[0-9]+]]:_(s8) = G_PHI %[[A1]](s8), %bb.{{[0-9]+}},
; CHECK: %[[Q2:[0-9]+]]:_(s8) = G_PHI %[[A2]](s8), %bb.{{[0-9]+}},
; CHECK: %[[Q3:[0-9]+]]:_(s8) = G_PHI %[[A3]](s8), %bb.{{[0-9]+}},
; CHECK: %[[V0:[0-9]+]]:_(s16) = G_MERGE_VALUES %[[Q0]](s8), %[[Q1]](s8)
; CHECK: %[[V1:[0-9]+]]:_(s16) = G_MERGE_VALUES %[[Q2]](s8), %[[Q3]](s8)
; CHECK: %[[J:[0-9]+]]:_(s32) = G_MERGE_VALUES %[[V0]](s16), %[[V1]](s16)
; CHECK: %[[P:[0-9]+]]:_(p2) = G_INTTOPTR %[[J]](s32)
; CHECK: G_LOAD_FAR_INDIR %[[P]](p2)
;
; And it reaches a real indirect-long dereference in the emitted loop.
; ASM-LABEL: far_ptr_induction:
; ASM: lda [__rc{{[0-9]+}}]
entry:
  %p0 = inttoptr i32 %a to ptr addrspace(2)
  br label %loop

loop:
  %p = phi ptr addrspace(2) [ %p0, %entry ], [ %pn, %loop ]
  %i = phi i16 [ 0, %entry ], [ %in, %loop ]
  %acc = phi i8 [ 0, %entry ], [ %accn, %loop ]
  %v = load i8, ptr addrspace(2) %p
  %accn = add i8 %acc, %v
  %s = load volatile i32, ptr @stride
  %pn = getelementptr inbounds i8, ptr addrspace(2) %p, i32 %s
  %in = add i16 %i, 1
  %c = icmp ult i16 %in, %n
  br i1 %c, label %loop, label %exit

exit:
  ret i8 %accn
}
