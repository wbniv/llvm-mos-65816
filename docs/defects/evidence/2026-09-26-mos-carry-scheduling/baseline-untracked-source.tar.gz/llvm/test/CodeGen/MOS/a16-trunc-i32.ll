; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16 -verify-machineinstrs < %s | FileCheck %s

define i16 @trunc_i32_to_i16(i32 %value) {
; CHECK-LABEL: trunc_i32_to_i16:
; CHECK: rts
  %low = trunc i32 %value to i16
  ret i16 %low
}
