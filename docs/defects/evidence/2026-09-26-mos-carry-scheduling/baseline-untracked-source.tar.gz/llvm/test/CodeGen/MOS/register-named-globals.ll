; RUN: llc -mtriple=mos -mcpu=mos6502 -verify-machineinstrs %s -o %t.s
; RUN: FileCheck %s < %t.s
; RUN: llvm-mc -triple=mos -mcpu=mos6502 -filetype=obj %t.s -o %t.o
; RUN: llc -mtriple=mos -mcpu=mos6502 -verify-machineinstrs -filetype=obj %s -o %t.direct.o
; RUN: cmp %t.direct.o %t.o

; Global names that match registers need quotes in both operands and labels.
@s = global i8 0
@x = global i8 0
@y = global i8 0
@a = global i8 0

define i8 @read_x() {
; CHECK-LABEL: read_x:
; CHECK: lda "x"
  %v = load i8, ptr @x
  ret i8 %v
}

define i8 @read_y() {
; CHECK-LABEL: read_y:
; CHECK: lda "y"
  %v = load i8, ptr @y
  ret i8 %v
}

define i8 @read_s() {
; CHECK-LABEL: read_s:
; CHECK: lda "s"
  %v = load i8, ptr @s
  ret i8 %v
}

define void @shift_a() {
; CHECK-LABEL: shift_a:
; CHECK: asl "a"
  %v = load i8, ptr @a
  %shift = shl i8 %v, 1
  store i8 %shift, ptr @a
  ret void
}

; CHECK: "s":
; CHECK: "x":
; CHECK: "y":
; CHECK: "a":
