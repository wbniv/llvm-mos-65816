; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16 -verify-machineinstrs < %s | FileCheck %s
; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16 -verify-machineinstrs -filetype=obj -o %t.o < %s
; RUN: llvm-objdump -d --print-imm-hex %t.o | FileCheck %s --check-prefix=OBJ

; #320 far addressing — the four data opcodes of the AS_Far (addrspace 2) model.
; The emulator ROM gates (dev/run.sh far_indir / far_store / far-bank1 ...) cover
; the runtime behaviour; this test pins the SELECTED OPCODE, which they cannot.
; These are the shapes MOSInstructionSelector::selectAddr / selectGeneric produce:
;
;   * a LINK-TIME far address (an addrspace(2) global -- isFarSymbol) is an
;     absolute-long operand:         lda long / sta long  ($af / $8f)
;   * a RUNTIME far address (inttoptr of a 32-bit value, held in an Imag32 zero-page
;     quad) is direct-indirect-long: lda [dp] / sta [dp]  ($a7 / $87)
;
; The second RUN line disassembles the object so the opcode BYTE is pinned, not
; just the mnemonic -- `lda mos24(x)` and `lda x` print similarly but are $af vs $ad.

target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"

@fardata = addrspace(2) global i8 0
@farbuf = addrspace(2) global i8 0

; A far global's address is a link-time 24-bit constant: absolute long, $af.
define i8 @far_load_abs() {
; CHECK-LABEL: far_load_abs:
; CHECK: lda mos24(fardata)
; CHECK: rts
; OBJ-LABEL: <far_load_abs>:
; OBJ: af {{[0-9a-f]+ [0-9a-f]+ [0-9a-f]+}} {{.*}}lda
  %v = load i8, ptr addrspace(2) @fardata
  ret i8 %v
}

; ... and the store half, $8f.
define void @far_store_abs(i8 %v) {
; CHECK-LABEL: far_store_abs:
; CHECK: sta mos24(farbuf)
; CHECK: rts
; OBJ-LABEL: <far_store_abs>:
; OBJ: 8f {{[0-9a-f]+ [0-9a-f]+ [0-9a-f]+}} {{.*}}sta
  store i8 %v, ptr addrspace(2) @farbuf
  ret void
}

; A runtime far pointer (inttoptr i32) lands in an Imag32 zero-page quad and is
; dereferenced with direct-indirect-long, $a7. This is the far_indir.c shape.
define i8 @far_load_indir(i32 %a) {
; CHECK-LABEL: far_load_indir:
; CHECK: lda [__rc{{[0-9]+}}]
; CHECK: rts
; OBJ-LABEL: <far_load_indir>:
; OBJ: a7 {{[0-9a-f]+}} {{.*}}lda [
  %p = inttoptr i32 %a to ptr addrspace(2)
  %v = load i8, ptr addrspace(2) %p
  ret i8 %v
}

; ... and the store half, $87. This is the far_store.c shape.
define void @far_store_indir(i32 %a, i8 %v) {
; CHECK-LABEL: far_store_indir:
; CHECK: sta [__rc{{[0-9]+}}]
; CHECK: rts
; OBJ-LABEL: <far_store_indir>:
; OBJ: 87 {{[0-9a-f]+}} {{.*}}sta [
  %p = inttoptr i32 %a to ptr addrspace(2)
  store i8 %v, ptr addrspace(2) %p
  ret void
}

; A plain (AS0) global merely PLACED in a .far_* section keeps its NEAR 16-bit
; address -- isFarSymbol restricts the section test to FUNCTIONS on purpose, so
; taking &it must not over-trigger 24-bit materialization into a 16-bit context
; (selectAddrLoHi/buildFarAddrWords require a 24-bit destination). Codegen must
; emit a BARE symbol operand here, not mos24(...); dev/run.sh far_indir is the
; matching runtime gate.
;
; Asm-only: what the ASSEMBLER then does with a bare unresolved symbol operand on
; W65816 is a separate, already-tracked MC-layer question (the failing `addr24`
; bare-symbol line in MC/MOS/addressing-modes-65816.s), so this case deliberately
; carries no OBJ check -- it pins the codegen decision, not the encoding choice.
@near_in_far_section = global i8 -87, section ".far_data"

define i8 @near_symbol_in_far_section() {
; CHECK-LABEL: near_symbol_in_far_section:
; CHECK: lda near_in_far_section
; CHECK-NOT: mos24(near_in_far_section)
; CHECK: rts
  %v = load volatile i8, ptr @near_in_far_section
  ret i8 %v
}
