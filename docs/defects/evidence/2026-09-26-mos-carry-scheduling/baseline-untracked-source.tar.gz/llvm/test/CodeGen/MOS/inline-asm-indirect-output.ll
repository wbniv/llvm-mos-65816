; RUN: llc -mtriple=mos -mcpu=mos6502 -O2 -stop-after=irtranslator < %s | FileCheck %s
; RUN: llc -mtriple=mos -mcpu=mos6502 -O2 -verify-machineinstrs < %s | FileCheck %s --check-prefix=ASM
; RUN: llc -mtriple=mos -mcpu=mos6502 -O0 -verify-machineinstrs < %s | FileCheck %s --check-prefix=ASM

; Clang lowers `asm("" : "+g"(u))` to an indirect register output ("=*imr")
; whose value is also a tied input. The output is written back through the
; pointer after the asm; the input is a plain register operand.

define i16 @barrier(i16 %u) {
; CHECK-LABEL: name: barrier
; CHECK: [[P:%[0-9]+]]:_(p0) = G_FRAME_INDEX %stack.0.u.addr
; CHECK: INLINEASM &"", {{.*}} regdef:Imag16, def [[D:%[0-9]+]], reguse tiedto:$0, %{{[0-9]+}}(tied-def 3)
; CHECK: [[V:%[0-9]+]]:_(s16) = COPY [[D]]
; CHECK: G_STORE [[V]](s16), [[P]](p0) :: (store (s16) into %ir.u.addr
; ASM-LABEL: barrier:
; ASM: rts
  %u.addr = alloca i16, align 1
  store i16 %u, ptr %u.addr, align 1
  %v = load i16, ptr %u.addr, align 1
  call void asm sideeffect "", "=*imr,0"(ptr nonnull elementtype(i16) %u.addr, i16 %v)
  %r = load i16, ptr %u.addr, align 1
  ret i16 %r
}

define void @indirect_only(ptr %p) {
; CHECK-LABEL: name: indirect_only
; CHECK: INLINEASM &"", {{.*}} regdef:Imag8, def [[D:%[0-9]+]]
; CHECK: [[V:%[0-9]+]]:_(s8) = COPY [[D]]
; CHECK: G_STORE [[V]](s8), %{{[0-9]+}}(p0) :: (store (s8) into %ir.p)
; ASM-LABEL: indirect_only:
; ASM: rts
  call void asm sideeffect "", "=*r"(ptr elementtype(i8) %p)
  ret void
}
