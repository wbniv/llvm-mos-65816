; RUN: llc -mtriple=mos -mcpu=mosw65816 -O2 -verify-machineinstrs %s -o /dev/null
; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16 -O2 -verify-machineinstrs %s -o /dev/null
; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16,+mos-xy16 -O2 -verify-machineinstrs %s -o /dev/null

; Legalizing the masked byte store can introduce G_ANYEXT s8 -> s64. The
; extension must lower even when native-width lanes are enabled.
define void @extend_masked(ptr %out, i8 %value) {
  %scaled = mul i8 %value, 7
  %masked = and i8 %scaled, 63
  %extended = zext i8 %masked to i64
  store volatile i64 %extended, ptr %out, align 1
  ret void
}
