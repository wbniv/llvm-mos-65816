; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16 -verify-machineinstrs < %s | FileCheck %s --check-prefixes=CHECK,A16
; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16 -verify-machineinstrs -filetype=obj -o %t.o < %s
; RUN: llvm-objdump -d --print-imm-hex %t.o | FileCheck %s --check-prefix=OBJ
; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16,+mos-xy16 -verify-machineinstrs < %s | FileCheck %s --check-prefixes=CHECK,XY16
; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16,+mos-xy16 -verify-machineinstrs -filetype=obj -o %t.xy.o < %s
; RUN: llvm-objdump -d --print-imm-hex %t.xy.o | FileCheck %s --check-prefix=OBJXY
; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16,+mos-xy16 -verify-machineinstrs -stop-after=instruction-select < %s | FileCheck %s --check-prefix=MIR

; A runtime far pointer plus a constant byte displacement in [1,3] selects
; indirect-long indexed addressing: lda [dp],y ($b7) / sta [dp],y ($97).
; Runtime offsets fold when their range and all users satisfy the gates below.
; Other offsets keep plain indirect-long addressing; a link-time base uses
; absolute-long addressing. Checks cover both accumulator and index modes.

target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"

@fartbl = addrspace(2) global [8 x i8] zeroinitializer

;=== POSITIVE ================================================================

; The real customer: a 16-bit read through a runtime far pointer. Byte 0 keeps
; plain `lda [dp]` ($a7, cheapest for displacement 0); byte 1 folds into
; `lda [dp],y` ($b7) off the SAME quad instead of advancing the pointer.
define i16 @far_load_indir_u16(i32 %a) {
; CHECK-LABEL: far_load_indir_u16:
; CHECK: lda [__rc{{[0-9]+}}]
; CHECK: lda [__rc{{[0-9]+}}],y
; CHECK-NOT: inc __rc
; CHECK: rts
; OBJ-LABEL: <far_load_indir_u16>:
; OBJ: a7 {{[0-9a-f]+}} {{.*}}lda [
; OBJ: b7 {{[0-9a-f]+}} {{.*}}lda [
  %p = inttoptr i32 %a to ptr addrspace(2)
  %v = load i16, ptr addrspace(2) %p
  ret i16 %v
}

; The far ARRAY SUBSCRIPT shape — `tbl[i]` with a runtime i and a 16-bit
; element. The pointer is G_PTR_ADD(G_PTR_ADD(@tbl, i), 1) for the high byte:
; the constant peel must STOP at the variable offset and use the inner node as
; the base, not give up. This is the farindex.c shape and the single most common
; customer because each multi-byte array element uses adjacent byte accesses.
define i16 @far_load_subscript_u16(i32 %i) {
; CHECK-LABEL: far_load_subscript_u16:
; CHECK: lda [__rc{{[0-9]+}}]
; CHECK: lda [__rc{{[0-9]+}}],y
; CHECK: rts
; OBJ-LABEL: <far_load_subscript_u16>:
; OBJ: a7 {{[0-9a-f]+}} {{.*}}lda [
; OBJ: b7 {{[0-9a-f]+}} {{.*}}lda [
  %q = getelementptr inbounds i16, ptr addrspace(2) @fartbl, i32 %i
  %v = load i16, ptr addrspace(2) %q
  ret i16 %v
}

; An explicit constant displacement of 1 folds.
define i8 @far_load_indir_idx1(i32 %a) {
; CHECK-LABEL: far_load_indir_idx1:
; CHECK: ldy #1
; CHECK: lda [__rc{{[0-9]+}}],y
; CHECK: rts
; OBJ-LABEL: <far_load_indir_idx1>:
; OBJ: b7 {{[0-9a-f]+}} {{.*}}lda [
  %p = inttoptr i32 %a to ptr addrspace(2)
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 1
  %v = load i8, ptr addrspace(2) %q
  ret i8 %v
}

; ... as does 3, the top of the window (the 4th byte of a far i32).
define i8 @far_load_indir_idx3(i32 %a) {
; CHECK-LABEL: far_load_indir_idx3:
; CHECK: ldy #3
; CHECK: lda [__rc{{[0-9]+}}],y
; CHECK: rts
; OBJ-LABEL: <far_load_indir_idx3>:
; OBJ: b7 {{[0-9a-f]+}} {{.*}}lda [
  %p = inttoptr i32 %a to ptr addrspace(2)
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 3
  %v = load i8, ptr addrspace(2) %q
  ret i8 %v
}

; The store half: $97.
define void @far_store_indir_idx1(i32 %a, i8 %v) {
; CHECK-LABEL: far_store_indir_idx1:
; CHECK: sta [__rc{{[0-9]+}}],y
; CHECK: rts
; OBJ-LABEL: <far_store_indir_idx1>:
; OBJ: 97 {{[0-9a-f]+}} {{.*}}sta [
  %p = inttoptr i32 %a to ptr addrspace(2)
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 1
  store i8 %v, ptr addrspace(2) %q
  ret void
}

;=== NEGATIVE — use unindexed or absolute-long addressing ===================

; Displacement 0 is NOT folded: plain `lda [dp]` already encodes it in fewer
; bytes with no Y at all.
define i8 @far_load_indir_idx0(i32 %a) {
; CHECK-LABEL: far_load_indir_idx0:
; CHECK: lda [__rc{{[0-9]+}}]
; CHECK-NOT: lda [__rc{{[0-9]+}}],y
; CHECK: rts
  %p = inttoptr i32 %a to ptr addrspace(2)
  %v = load i8, ptr addrspace(2) %p
  ret i8 %v
}

; Displacement 4 is past kMaxFarIndirIdxDisp: falls back to the pointer add.
define i8 @far_load_indir_idx4(i32 %a) {
; CHECK-LABEL: far_load_indir_idx4:
; CHECK-NOT: lda [__rc{{[0-9]+}}],y
; CHECK: lda [__rc{{[0-9]+}}]
; CHECK-NOT: lda [__rc{{[0-9]+}}],y
; CHECK: rts
  %p = inttoptr i32 %a to ptr addrspace(2)
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 4
  %v = load i8, ptr addrspace(2) %q
  ret i8 %v
}

; A full-width 32-bit RUNTIME index has no known-bits bound, so increment 2's
; range proof rejects it in every mode and the pointer add stays.
define i8 @far_load_indir_var(i32 %a, i32 %i) {
; CHECK-LABEL: far_load_indir_var:
; CHECK-NOT: lda [__rc{{[0-9]+}}],y
; CHECK: lda [__rc{{[0-9]+}}]
; CHECK-NOT: lda [__rc{{[0-9]+}}],y
; CHECK: rts
  %p = inttoptr i32 %a to ptr addrspace(2)
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 %i
  %v = load i8, ptr addrspace(2) %q
  ret i8 %v
}

; A LINK-TIME far address keeps absolute-long addressing ($af) — the indexed
; indirect form must not steal a base that `lda long` addresses in one
; instruction with no ZP quad at all.
define i8 @far_load_abs_idx1() {
; CHECK-LABEL: far_load_abs_idx1:
; CHECK: lda mos24(fartbl+1)
; CHECK-NOT: lda [__rc{{[0-9]+}}],y
; CHECK: rts
; OBJ-LABEL: <far_load_abs_idx1>:
; OBJ: af {{[0-9a-f]+ [0-9a-f]+ [0-9a-f]+}} {{.*}}lda
  %q = getelementptr inbounds [8 x i8], ptr addrspace(2) @fartbl, i32 0, i32 1
  %v = load volatile i8, ptr addrspace(2) %q
  ret i8 %v
}

;=============================================================================
; #321 Phase 2 increment 2 — a RUNTIME index proven to fit Y.
; docs/plans/2026-09-25-dpy-indexed-phase2-increment2.md. The gate is
; known-bits max(scaled offset) + furthest displacement <= 255 (8-bit Y), or
; <= 65535 under +mos-xy16 only (Y's width is the X flag), AND every user of
; the variable G_PTR_ADD must fold so its 32-bit add disappears outright.
;=============================================================================

;=== POSITIVE (both modes, 8-bit Y) ==========================================

; A u8 element at a zext'd u8 index off a runtime far pointer: Y = the index,
; no pointer add, no rep #$10 even under +mos-xy16 (8-bit Y is preferred).
define i8 @far_rt_load_u8(i32 %a, i8 %i) {
; CHECK-LABEL: far_rt_load_u8:
; CHECK-NOT: adc
; CHECK-NOT: rep #16
; CHECK: ldy __rc{{[0-9]+}}
; CHECK-NEXT: lda [__rc{{[0-9]+}}],y
; CHECK-NEXT: rts
; OBJ-LABEL: <far_rt_load_u8>:
; OBJ: b7 {{[0-9a-f]+}} {{.*}}lda [
  %p = inttoptr i32 %a to ptr addrspace(2)
  %x = zext i8 %i to i32
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 %x
  %v = load i8, ptr addrspace(2) %q
  ret i8 %v
}

; The store half: $97.
define void @far_rt_store_u8(i32 %a, i8 %i, i8 %v) {
; CHECK-LABEL: far_rt_store_u8:
; CHECK-NOT: adc
; CHECK: sta [__rc{{[0-9]+}}],y
; CHECK-NEXT: rts
; OBJ-LABEL: <far_rt_store_u8>:
; OBJ: 97 {{[0-9a-f]+}} {{.*}}sta [
  %p = inttoptr i32 %a to ptr addrspace(2)
  %x = zext i8 %i to i32
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 %x
  store i8 %v, ptr addrspace(2) %q
  ret void
}

; The customer (dev/dpy-shapes loop, pointer form): the loop counter IS the
; index, so it lives in Y and the whole body is lda [dp],y / sta abs,y / iny /
; cpy / bne — no per-iteration 32-bit add.
define void @far_rt_blit(i32 %a, ptr %dst) {
; CHECK-LABEL: far_rt_blit:
; CHECK: .LBB{{[0-9_]+}}:
; CHECK: lda [__rc{{[0-9]+}}],y
; CHECK-NEXT: sta (__rc{{[0-9]+}}),y
; CHECK-NEXT: iny
; CHECK-NEXT: cpy #64
; CHECK-NEXT: bne
entry:
  %p = inttoptr i32 %a to ptr addrspace(2)
  br label %loop
loop:
  %j = phi i8 [ 0, %entry ], [ %j1, %loop ]
  %x = zext i8 %j to i32
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 %x
  %v = load i8, ptr addrspace(2) %q
  %d = getelementptr inbounds i8, ptr %dst, i8 %j
  store i8 %v, ptr %d
  %j1 = add nuw nsw i8 %j, 1
  %c = icmp eq i8 %j1, 64
  br i1 %c, label %exit, label %loop
exit:
  ret void
}

; A u16 element whose index is masked to 7 bits: scaled offsets 2i and 2i+1
; are <= 255, so BOTH bytes fold off the same base with an 8-bit Y; the +1 is
; an `iny`, not a second pointer.
define i16 @far_rt_load_u16_masked(i32 %a, i8 %i) {
; CHECK-LABEL: far_rt_load_u16_masked:
; CHECK-NOT: adc
; CHECK: and #127
; CHECK: lda [__rc[[P:[0-9]+]]],y
; CHECK: iny
; CHECK-NEXT: lda [__rc[[P]]],y
; CHECK: rts
  %p = inttoptr i32 %a to ptr addrspace(2)
  %m = and i8 %i, 127
  %x = zext i8 %m to i32
  %q = getelementptr inbounds i16, ptr addrspace(2) %p, i32 %x
  %v = load i16, ptr addrspace(2) %q
  ret i16 %v
}


; Y CONTENDED: inside the loop Y is wanted both for the loop counter (the near
; `nearbuf[j]` store) and for the loop-invariant far index %m. Register
; allocation has to shuffle the two, but the fold still removes the 32-bit add
; from the loop, and the code must verify (-verify-machineinstrs above).
@nearbuf = global [64 x i8] zeroinitializer
define void @far_rt_y_contended(i32 %a, i8 %m) {
; CHECK-LABEL: far_rt_y_contended:
; CHECK-NOT: adc
; CHECK: .LBB{{[0-9_]+}}:
; CHECK-NOT: adc
; CHECK: lda [__rc{{[0-9]+}}],y
; CHECK-NOT: adc
; CHECK: rts
entry:
  %p = inttoptr i32 %a to ptr addrspace(2)
  %x = zext i8 %m to i32
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 %x
  br label %loop
loop:
  %j = phi i8 [ 0, %entry ], [ %j1, %loop ]
  %v = load volatile i8, ptr addrspace(2) %q
  %w = xor i8 %v, %j
  %d = getelementptr inbounds [64 x i8], ptr @nearbuf, i8 0, i8 %j
  store i8 %w, ptr %d
  %j1 = add nuw nsw i8 %j, 1
  %c = icmp eq i8 %j1, 64
  br i1 %c, label %exit, label %loop
exit:
  ret void
}

;=== MODE-DEPENDENT: only +mos-xy16 has a 16-bit Y ===========================

; A zext'd 16-bit index: <= 65535. +mos-a16 (8-bit Y) must NOT fold — the
; pointer add stays and the load is plain `lda [dp]`. +mos-xy16 folds with a
; 16-bit Y, bracketed rep #$10 / sep #$10 (rep #16 / sep #16).
define i8 @far_rt_load_idx16(i32 %a, i16 %i) {
; MIR-LABEL: name: far_rt_load_idx16
; MIR: LDIndirLongYIdx {{.*}}implicit-def $y16
; CHECK-LABEL: far_rt_load_idx16:
; A16: adc
; A16: lda [__rc{{[0-9]+}}]{{$}}
; A16-NOT: ],y
; XY16-NOT: adc
; XY16: rep #16
; XY16-NEXT: ldy __rc{{[0-9]+}}
; XY16-NEXT: lda [__rc{{[0-9]+}}],y
; XY16-NEXT: sep #16
; CHECK: rts
; OBJXY-LABEL: <far_rt_load_idx16>:
; OBJXY: c2 10 {{.*}}rep
; OBJXY: b7 {{[0-9a-f]+}} {{.*}}lda [
; OBJXY: e2 10 {{.*}}sep
  %p = inttoptr i32 %a to ptr addrspace(2)
  %x = zext i16 %i to i32
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 %x
  %v = load i8, ptr addrspace(2) %q
  ret i8 %v
}

; The 16-bit-Y store: $97 inside the rep/sep #$10 bracket.
define void @far_rt_store_idx16(i32 %a, i16 %i, i8 %v) {
; MIR-LABEL: name: far_rt_store_idx16
; MIR: STIndirLongYIdx {{.*}}implicit-def $y16
; CHECK-LABEL: far_rt_store_idx16:
; A16: sta [__rc{{[0-9]+}}]{{$}}
; XY16-NOT: adc
; XY16: rep #16
; XY16: sta [__rc{{[0-9]+}}],y
; XY16-NEXT: sep #16
; CHECK: rts
; OBJXY-LABEL: <far_rt_store_idx16>:
; OBJXY: 97 {{[0-9a-f]+}} {{.*}}sta [
  %p = inttoptr i32 %a to ptr addrspace(2)
  %x = zext i16 %i to i32
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 %x
  store i8 %v, ptr addrspace(2) %q
  ret void
}

; A u16 element at an UNMASKED u8 index: the scaled offsets reach 511, past an
; 8-bit Y. +mos-a16: no runtime fold — byte 0 is plain `lda [dp]` off the
; materialised pointer and byte 1 is increment 1's `ldy #1`. +mos-xy16: both
; bytes fold with a 16-bit Y off the ORIGINAL pointer.
define i16 @far_rt_load_u16_idx8(i32 %a, i8 %i) {
; CHECK-LABEL: far_rt_load_u16_idx8:
; A16: lda [__rc{{[0-9]+}}]{{$}}
; A16: ldy #1
; A16-NEXT: lda [__rc{{[0-9]+}}],y
; XY16-NOT: adc
; XY16: rep #16
; XY16: lda [__rc[[P:[0-9]+]]],y
; XY16: lda [__rc[[P]]],y
; XY16: sep #16
; CHECK: rts
  %p = inttoptr i32 %a to ptr addrspace(2)
  %x = zext i8 %i to i32
  %q = getelementptr inbounds i16, ptr addrspace(2) %p, i32 %x
  %v = load i16, ptr addrspace(2) %q
  ret i16 %v
}

;=== NEGATIVE — must still take the old path in every mode ===================

; A SIGN-extended index can be negative: unknown high bits, no bound.
define i8 @far_rt_load_sext(i32 %a, i8 %i) {
; CHECK-LABEL: far_rt_load_sext:
; CHECK-NOT: ],y
; CHECK: lda [__rc{{[0-9]+}}]{{$}}
; CHECK-NOT: ],y
; CHECK: rts
  %p = inttoptr i32 %a to ptr addrspace(2)
  %x = sext i8 %i to i32
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 %x
  %v = load i8, ptr addrspace(2) %q
  ret i8 %v
}

; The indexed pointer ESCAPES (stored as a value): its 32-bit add is needed
; anyway, so folding the load would only add a Y load — the user walk rejects.
define i8 @far_rt_load_escape(i32 %a, i8 %i, ptr %out) {
; CHECK-LABEL: far_rt_load_escape:
; CHECK-NOT: ],y
; CHECK: lda [__rc{{[0-9]+}}]{{$}}
; CHECK-NOT: ],y
; CHECK: rts
  %p = inttoptr i32 %a to ptr addrspace(2)
  %x = zext i8 %i to i32
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 %x
  store ptr addrspace(2) %q, ptr %out
  %v = load i8, ptr addrspace(2) %q
  ret i8 %v
}

; A GLOBAL (absolute) far base plus a runtime u8 index is DECLINED (gate (d)):
; today's add folds the address in as immediates and needs no quad, while the
; fold would materialise a constant quad that a hot loop can hoist and spill
; (measured +57 B on k_blossom_far under +mos-xy16). `lda long,X` is that
; shape's mode, not `[dp],Y`.
define i8 @far_rt_load_global(i8 %i) {
; CHECK-LABEL: far_rt_load_global:
; CHECK-NOT: ],y
; CHECK-NOT: ],y
; CHECK: rts
  %x = zext i8 %i to i32
  %q = getelementptr inbounds [8 x i8], ptr addrspace(2) @fartbl, i32 0, i32 %x
  %v = load i8, ptr addrspace(2) %q
  ret i8 %v
}

; A CALL between V and one of its accesses is DECLINED (gate (e)): the index
; would have to survive the call as well as the base — measured +40 B (an
; extra callee-saved byte drags in a soft-stack frame).
declare i8 @far_rt_callee(i8)
define i8 @far_rt_across_call(i32 %a, i8 %i) {
; CHECK-LABEL: far_rt_across_call:
; CHECK-NOT: ],y
; CHECK: jsr far_rt_callee
; CHECK-NOT: ],y
; CHECK: rts
  %p = inttoptr i32 %a to ptr addrspace(2)
  %x = zext i8 %i to i32
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 %x
  %v1 = load volatile i8, ptr addrspace(2) %q
  %c = call i8 @far_rt_callee(i8 %v1)
  %v2 = load volatile i8, ptr addrspace(2) %q
  %r = add i8 %c, %v2
  ret i8 %r
}

; SEVERAL accesses off V in a function that contains a call are DECLINED
; (gate (f)): under call pressure the base quad is spilled and every folded
; access would reload it. Here: the u16 element masked to <= 127 (which folds
; in far_rt_load_u16_masked above) after an unrelated call.
define i16 @far_rt_multi_with_call(i32 %a, i8 %i) {
; CHECK-LABEL: far_rt_multi_with_call:
; CHECK: jsr far_rt_callee
; CHECK: lda [__rc{{[0-9]+}}]{{$}}
; CHECK: rts
  %p = inttoptr i32 %a to ptr addrspace(2)
  %m = and i8 %i, 127
  %c = call i8 @far_rt_callee(i8 %m)
  %x = zext i8 %m to i32
  %q = getelementptr inbounds i16, ptr addrspace(2) %p, i32 %x
  %v = load i16, ptr addrspace(2) %q
  ret i16 %v
}

; ... but ONE access per iteration with a call elsewhere in the loop still
; folds: the base and the IV are live across the call today anyway.
define void @far_rt_single_with_call(i32 %a, ptr %dst) {
; CHECK-LABEL: far_rt_single_with_call:
; CHECK: jsr far_rt_callee
; CHECK: lda [__rc{{[0-9]+}}],y
; CHECK: rts
entry:
  %p = inttoptr i32 %a to ptr addrspace(2)
  br label %loop
loop:
  %j = phi i8 [ 0, %entry ], [ %j1, %loop ]
  %c = call i8 @far_rt_callee(i8 %j)
  %x = zext i8 %j to i32
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 %x
  %v = load i8, ptr addrspace(2) %q
  %d = getelementptr inbounds i8, ptr %dst, i8 %j
  %w = xor i8 %v, %c
  store i8 %w, ptr %d
  %j1 = add nuw nsw i8 %j, 1
  %e = icmp eq i8 %j1, 64
  br i1 %e, label %exit, label %loop
exit:
  ret void
}

; A SIBLING access out of the 8-bit range: bytes at q and q+1 with a u8 index
; reach 255 and 256. Folding only byte 0 would leave q's add alive for byte 1
; — a regression — so under +mos-a16 NEITHER folds on the runtime index (byte
; 1 still gets increment 1's constant `ldy #1`). +mos-xy16 folds both, 16-bit Y.
define i16 @far_rt_load_sibling_oob(i32 %a, i8 %i) {
; CHECK-LABEL: far_rt_load_sibling_oob:
; A16: lda [__rc{{[0-9]+}}]{{$}}
; A16: ldy #1
; XY16-NOT: adc
; XY16: rep #16
; CHECK: rts
  %p = inttoptr i32 %a to ptr addrspace(2)
  %x = zext i8 %i to i32
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 %x
  %v = load i16, ptr addrspace(2) %q, align 1
  ret i16 %v
}

;=== The 16-bit WRAP trap (docs/investigations/2026-09-25-farptr-hoist-measurement.md §5.2)

; dev/dpy-shapes/loop.c's `tab[o + j]` offset, off a RUNTIME base: the offset
; is the 16-bit sum `o + j` WITHOUT nuw (MOS int is 16 bits), so it wraps
; modulo 2^16 before the zext. A fold must put the WRAPPED sum in Y;
; re-associating it into (p + o) + j would carry into the bank byte for
; o + j >= 0x10000 and read one bank too high. +mos-xy16: Y = the 16-bit `adc`
; result itself (no bank-byte carry chain anywhere). +mos-a16: the sum is not
; provably < 256 — no fold.
define i8 @far_rt_wrap16(i32 %a, i16 %o, i16 %j) {
; CHECK-LABEL: far_rt_wrap16:
; A16-NOT: ],y
; XY16: rep #32
; XY16: adc __rc{{[0-9]+}}
; XY16: sta __rc[[K:[0-9]+]]
; XY16-NOT: adc
; XY16: rep #16
; XY16-NEXT: ldy __rc[[K]]
; XY16-NEXT: lda [__rc{{[0-9]+}}],y
; XY16-NEXT: sep #16
; CHECK: rts
  %p = inttoptr i32 %a to ptr addrspace(2)
  %k = add i16 %o, %j
  %x = zext i16 %k to i32
  %q = getelementptr inbounds i8, ptr addrspace(2) %p, i32 %x
  %v = load i8, ptr addrspace(2) %q
  ret i8 %v
}

; Arithmetic consumes and produces a word at the indexed address. The runtime
; byte pseudo must not be used for a native word operand when that path exists.
define void @far_rt_word_arithmetic(i32 %a, i8 %i) {
; CHECK-LABEL: far_rt_word_arithmetic:
; CHECK: rts
  %p = inttoptr i32 %a to ptr addrspace(2)
  %off = zext i8 %i to i32
  %q = getelementptr i8, ptr addrspace(2) %p, i32 %off
  %v = load volatile i16, ptr addrspace(2) %q, align 1
  %n = add i16 %v, 1
  store volatile i16 %n, ptr addrspace(2) %q, align 1
  ret void
}
