; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16 -verify-machineinstrs -stop-after=legalizer -o - < %s | FileCheck %s
; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16 -verify-machineinstrs < %s | FileCheck %s --check-prefix=ASM

; #320/#321 far-pointer legalizer BRIDGES (MOSLegalizerInfo.cpp). Neither far
; pointer type is a legal register type, so every far value crosses into and out
; of byte-sized pieces through one of two bridges:
;
;   p2 (AS_Far, datalayout p2:32:8) <-> s32
;     A 32-bit far pointer is ptrtoint'd to s32, which the standard narrowScalar
;     path splits into 2x s16 -> 4x s8, and inttoptr'd back. Used by
;     legalizePtrAdd, the far load/store paths and legalizePhi alike.
;
;   p3 (AS_FarPacked, datalayout p3:24:8) <-> 3x s8
;     The PACKED 3-byte STORAGE form of a far pointer. It is memory-only: there is
;     no 24-bit scalar (no MVT::i24), so a p3 is built/destructured purely as three
;     bytes, and the addrspacecast to/from p2 zero-extends/drops the unused pad
;     byte. THREE bytes, never four -- a four-byte access would read or clobber a
;     neighbouring table entry (this is the packed24_table.c shape).
;
; Checking post-legalizer MIR (rather than final asm) is the point: it pins the
; merge/unmerge shape the bridges produce, which later passes then fold away.

target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"

; A packed (p3) far pointer in far storage. p3:24:8 -> exactly 3 bytes.
@slot = addrspace(2) global ptr addrspace(3) null

; p3 -> p2: load the 3 stored bytes, merge them with a ZERO pad byte into the
; s32, then inttoptr to p2 and dereference. Exactly three loads -- not four.
define i8 @packed_to_far_deref() {
; CHECK-LABEL: name: packed_to_far_deref
; CHECK: %[[B0:[0-9]+]]:_(s8) = G_LOAD_FAR_ABS @slot ::
; CHECK: %[[B1:[0-9]+]]:_(s8) = G_LOAD_FAR_ABS @slot + 1 ::
; CHECK: %[[B2:[0-9]+]]:_(s8) = G_LOAD_FAR_ABS @slot + 2 ::
; CHECK-NOT: G_LOAD_FAR_ABS @slot + 3
; CHECK: %[[Z:[0-9]+]]:_(s8) = G_CONSTANT i8 0
; CHECK: %[[LO:[0-9]+]]:_(s16) = G_MERGE_VALUES %[[B0]](s8), %[[B1]](s8)
; CHECK: %[[HI:[0-9]+]]:_(s16) = G_MERGE_VALUES %[[B2]](s8), %[[Z]](s8)
; CHECK: %[[I:[0-9]+]]:_(s32) = G_MERGE_VALUES %[[LO]](s16), %[[HI]](s16)
; CHECK: %[[P:[0-9]+]]:_(p2) = G_INTTOPTR %[[I]](s32)
; CHECK: G_LOAD_FAR_INDIR %[[P]](p2)
  %packed = load ptr addrspace(3), ptr addrspace(2) @slot
  %far = addrspacecast ptr addrspace(3) %packed to ptr addrspace(2)
  %v = load i8, ptr addrspace(2) %far
  ret i8 %v
}

; p2 -> p3: ptrtoint to s32, unmerge to bytes, keep the low THREE and store them.
; The pad byte is dropped, so the store must not touch @slot + 3.
define void @far_to_packed_store(i32 %a) {
; CHECK-LABEL: name: far_to_packed_store
; CHECK: %[[P:[0-9]+]]:_(p2) = G_INTTOPTR
; CHECK: %[[I:[0-9]+]]:_(s32) = G_PTRTOINT %[[P]](p2)
; CHECK: %[[LO:[0-9]+]]:_(s16), %[[HI:[0-9]+]]:_(s16) = G_UNMERGE_VALUES %[[I]](s32)
; CHECK: %[[B0:[0-9]+]]:_(s8), %[[B1:[0-9]+]]:_(s8) = G_UNMERGE_VALUES %[[LO]](s16)
; CHECK: %[[B2:[0-9]+]]:_(s8), %{{[0-9]+}}:_(s8) = G_UNMERGE_VALUES %[[HI]](s16)
; CHECK: G_STORE_FAR_ABS %[[B0]](s8), @slot ::
; CHECK: G_STORE_FAR_ABS %[[B1]](s8), @slot + 1 ::
; CHECK: G_STORE_FAR_ABS %[[B2]](s8), @slot + 2 ::
; CHECK-NOT: G_STORE_FAR_ABS {{.*}}@slot + 3
;
; ASM-LABEL: far_to_packed_store:
; ASM: sta mos24(slot)
; ASM: sta mos24(slot+1)
; ASM: sta mos24(slot+2)
; ASM-NOT: mos24(slot+3)
; ASM: rts
  %far = inttoptr i32 %a to ptr addrspace(2)
  %packed = addrspacecast ptr addrspace(2) %far to ptr addrspace(3)
  store ptr addrspace(3) %packed, ptr addrspace(2) @slot
  ret void
}

; The p2 <-> s32 bridge on a LINK-TIME far address: taking &far_global as an
; integer materialises the segment word plus the bank byte and a zero pad byte
; (buildFarAddrWords), i.e. the same 24-bits-in-32 representation.
@far_global = addrspace(2) global i8 0

define i32 @far_addr_to_int() {
; ASM-LABEL: far_addr_to_int:
; ASM-DAG: lda #mos24segmentlo(far_global)
; ASM-DAG: ldx #mos24segmenthi(far_global)
; ASM-DAG: ldy #mos24bank(far_global)
; ASM: rts
; CHECK-LABEL: name: far_addr_to_int
  %i = ptrtoint ptr addrspace(2) @far_global to i32
  ret i32 %i
}

; The packed slot itself occupies exactly three bytes (p3:24:8).
; ASM: slot:
; ASM: .size slot, 3
