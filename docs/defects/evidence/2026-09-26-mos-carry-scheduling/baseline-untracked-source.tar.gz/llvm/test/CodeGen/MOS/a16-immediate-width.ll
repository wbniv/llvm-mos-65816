; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16 -verify-machineinstrs < %s | FileCheck %s

; Under +mos-a16 the accumulator is 16 bits, so these immediates are three-byte
; Immediate16 forms. The assembler has no notion of the M flag, so a bare
; `adc #66` re-parses as the two-byte 8-bit form -- and with M=0 the processor
; then eats the next opcode as the immediate's high byte, desynchronising the
; instruction stream. Anything that could fit an 8-bit immediate therefore has
; to be printed with an explicit mos16() width.
;
; This has to be checked here rather than in an MC round-trip test: the
; assembler cannot build an Immediate16 MCInst holding a plain small immediate
; (its text always matches Imm8 first), and the disassembler wraps the operand
; itself, so codegen is the only producer of the unmarked form.

@g16 = global i16 48879

define void @add_small(ptr %p) {
; CHECK-LABEL: add_small:
; CHECK:      rep #32
; CHECK:      adc #mos16(66)
; CHECK:      sep #32
  %v = load i16, ptr @g16
  %r = add i16 %v, 66
  store i16 %r, ptr %p
  ret void
}

; A value that cannot fit an 8-bit immediate already states its own width, so
; it stays bare and ordinary 16-bit assembly does not grow a wrapper.
define void @add_wide(ptr %p) {
; CHECK-LABEL: add_wide:
; CHECK:      adc #43981
; CHECK-NOT:  mos16
  %v = load i16, ptr @g16
  %r = add i16 %v, 43981
  store i16 %r, ptr %p
  ret void
}

; The boundary: 255 is the largest value an 8-bit immediate can hold, so it is
; still ambiguous and still has to be marked.
define void @eor_boundary(ptr %p) {
; CHECK-LABEL: eor_boundary:
; CHECK:      eor #mos16(255)
  %v = load i16, ptr @g16
  %r = xor i16 %v, 255
  store i16 %r, ptr %p
  ret void
}

; A 16-bit compare is the same shape; and the 8-bit immediates the same
; function emits once M is back to 1 must NOT be marked -- they are genuine
; two-byte operands, not narrowed 16-bit ones.
define i8 @cmp_small() {
; CHECK-LABEL: cmp_small:
; CHECK:      cmp #mos16(5)
; CHECK:      sep #32
; CHECK-NEXT: lda #0
; CHECK:      sep #32
; CHECK-NEXT: lda #1
  %v = load i16, ptr @g16
  %c = icmp ult i16 %v, 5
  %r = zext i1 %c to i8
  ret i8 %r
}
