; RUN: llc -mtriple=mos -mcpu=mos6502 -O2 -stop-after=irtranslator < %s | FileCheck %s
; RUN: llc -mtriple=mos -mcpu=mos6502 -O2 -verify-machineinstrs < %s | FileCheck %s --check-prefix=ASM
; RUN: llc -mtriple=mos -mcpu=mos6502 -O0 -verify-machineinstrs < %s | FileCheck %s --check-prefix=ASM

; MOS maps "r" to one 16-bit Imag16 register for i16 and to 8-bit Imag8
; registers for everything else, so any operand wider than an int occupies
; several registers. Such an operand is laid out least significant piece
; first, the same way SelectionDAG's RegsForValue does it.

define i32 @tied_i32(i32 %x) {
; The tied input is split across as many registers as the def has, in the same
; order, and each use is tied to the def it matches.
; CHECK-LABEL: name: tied_i32
; CHECK: [[X:%[0-9]+]]:_(s32) = G_MERGE_VALUES
; CHECK: [[P0:%[0-9]+]]:_(s8) = G_TRUNC [[X]](s32)
; CHECK: [[R0:%[0-9]+]]:imag8 = COPY [[P0]](s8)
; CHECK: [[C8:%[0-9]+]]:_(s32) = G_CONSTANT i32 8
; CHECK: [[S8:%[0-9]+]]:_(s32) = G_LSHR [[X]], [[C8]](s32)
; CHECK: [[P1:%[0-9]+]]:_(s8) = G_TRUNC [[S8]](s32)
; CHECK: [[R1:%[0-9]+]]:imag8 = COPY [[P1]](s8)
; CHECK: INLINEASM &"", {{.*}} regdef:Imag8, def [[D0:%[0-9]+]], def [[D1:%[0-9]+]], def %{{[0-9]+}}, def %{{[0-9]+}}, reguse tiedto:$0, [[R0]](tied-def 3), [[R1]](tied-def 4), %{{[0-9]+}}(tied-def 5), %{{[0-9]+}}(tied-def 6)
; CHECK: [[L0:%[0-9]+]]:_(s8) = COPY [[D0]]
; CHECK: [[L1:%[0-9]+]]:_(s8) = COPY [[D1]]
; CHECK: %{{[0-9]+}}:_(s32) = G_MERGE_VALUES [[L0]](s8), [[L1]](s8), %{{[0-9]+}}(s8), %{{[0-9]+}}(s8)
; ASM-LABEL: tied_i32:
; ASM: rts
  %r = call i32 asm "", "=r,0"(i32 %x)
  ret i32 %r
}

define i32 @out_i32() {
; A multi-register result is reassembled from the defs, least significant first.
; CHECK-LABEL: name: out_i32
; CHECK: INLINEASM &"", {{.*}} regdef:Imag8, def [[D0:%[0-9]+]], def [[D1:%[0-9]+]], def [[D2:%[0-9]+]], def [[D3:%[0-9]+]]
; CHECK: [[L0:%[0-9]+]]:_(s8) = COPY [[D0]]
; CHECK: [[L1:%[0-9]+]]:_(s8) = COPY [[D1]]
; CHECK: [[L2:%[0-9]+]]:_(s8) = COPY [[D2]]
; CHECK: [[L3:%[0-9]+]]:_(s8) = COPY [[D3]]
; CHECK: %{{[0-9]+}}:_(s32) = G_MERGE_VALUES [[L0]](s8), [[L1]](s8), [[L2]](s8), [[L3]](s8)
; ASM-LABEL: out_i32:
; ASM: rts
  %r = call i32 asm "", "=r"()
  ret i32 %r
}

define void @in_i32(i32 %x) {
; A plain (untied) multi-register input is split the same way.
; CHECK-LABEL: name: in_i32
; CHECK: [[X:%[0-9]+]]:_(s32) = G_MERGE_VALUES
; CHECK: [[P0:%[0-9]+]]:_(s8) = G_TRUNC [[X]](s32)
; CHECK: [[R0:%[0-9]+]]:imag8 = COPY [[P0]](s8)
; CHECK: INLINEASM &"", {{.*}} reguse:Imag8, [[R0]], %{{[0-9]+}}, %{{[0-9]+}}, %{{[0-9]+}}
; ASM-LABEL: in_i32:
; ASM: rts
  call void asm sideeffect "", "r"(i32 %x)
  ret void
}

define void @ll_to_int(i64 %x, ptr %p) {
; gcc torture 20030222-1.c: the asm is a no-op, the tied group is eight
; registers wide, and the int that comes back out must be the LOW half of the
; long long -- the asymmetric case that a reversed piece order would break.
; CHECK-LABEL: name: ll_to_int
; CHECK: INLINEASM &"", {{.*}} regdef:Imag8, def [[D0:%[0-9]+]], def [[D1:%[0-9]+]], def %{{[0-9]+}}, def %{{[0-9]+}}, def %{{[0-9]+}}, def %{{[0-9]+}}, def %{{[0-9]+}}, def %{{[0-9]+}}, reguse tiedto:$0, %{{[0-9]+}}(tied-def 3), %{{[0-9]+}}(tied-def 4), %{{[0-9]+}}(tied-def 5), %{{[0-9]+}}(tied-def 6), %{{[0-9]+}}(tied-def 7), %{{[0-9]+}}(tied-def 8), %{{[0-9]+}}(tied-def 9), %{{[0-9]+}}(tied-def 10)
; CHECK: [[L0:%[0-9]+]]:_(s8) = COPY [[D0]]
; CHECK: [[L1:%[0-9]+]]:_(s8) = COPY [[D1]]
; CHECK: [[M:%[0-9]+]]:_(s64) = G_MERGE_VALUES [[L0]](s8), [[L1]](s8),
; CHECK: [[C:%[0-9]+]]:_(s64) = COPY [[M]](s64)
; CHECK: [[T:%[0-9]+]]:_(s16) = G_TRUNC [[C]](s64)
; CHECK: G_STORE [[T]](s16)
; ASM-LABEL: ll_to_int:
; ASM: rts
  %c = call i64 asm "", "=r,0"(i64 %x)
  %t = trunc i64 %c to i16
  store volatile i16 %t, ptr %p, align 1
  ret void
}
