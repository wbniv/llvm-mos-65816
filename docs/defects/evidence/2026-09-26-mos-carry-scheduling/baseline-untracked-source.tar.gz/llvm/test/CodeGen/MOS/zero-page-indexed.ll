; RUN: llc -mtriple=mos -mcpu=mos6502 -verify-machineinstrs %s -o %t.s
; RUN: FileCheck %s < %t.s
; RUN: llvm-mc -triple=mos -mcpu=mos6502 -filetype=obj %t.s -o %t.asm.o
; RUN: llc -mtriple=mos -mcpu=mos6502 -verify-machineinstrs -filetype=obj %s -o %t.direct.o
; RUN: cmp %t.direct.o %t.asm.o
; RUN: llvm-objdump -dr %t.direct.o | FileCheck %s --check-prefix=OBJ

; A section-placed array fits wholly in zero page. In-bounds accesses may use
; zero-page indexing even though its pointers have the default address space.
@samples = global [16 x i8] zeroinitializer, section ".zp.bss"

define i8 @read_sample(i8 %index) {
; CHECK-LABEL: read_sample:
; CHECK: lda mos8(samples),x
; OBJ-LABEL: <read_sample>:
; OBJ: b5 00
  %offset = zext i8 %index to i16
  %address = getelementptr inbounds [16 x i8], ptr @samples, i16 0, i16 %offset
  %value = load i8, ptr %address
  ret i8 %value
}

define void @write_sample(i8 %value, i8 %index) {
; CHECK-LABEL: write_sample:
; CHECK: sta mos8(samples),x
; OBJ-LABEL: <write_sample>:
; OBJ: 95 00
  %offset = zext i8 %index to i16
  %address = getelementptr inbounds [16 x i8], ptr @samples, i16 0, i16 %offset
  store i8 %value, ptr %address
  ret void
}
