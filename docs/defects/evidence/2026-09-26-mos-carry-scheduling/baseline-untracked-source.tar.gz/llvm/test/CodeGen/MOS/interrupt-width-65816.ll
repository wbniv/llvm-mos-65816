; RUN: llc -mtriple=mos -mcpu=mosw65816 -O2 < %s | FileCheck %s

; A 65816 interrupt inherits M/X from the interrupted instruction, and D and
; DBR from the interrupted code (which may legally have moved them via inline
; asm). Save full A/X/Y in a known 16-bit mode, save D and DBR, and establish
; the complete C ABI state (M8/X8, D=0, DBR=0 — the latter derived from the
; hardware-forced PBR=0 via phk/plb) before any compiled code runs; restore
; everything in reverse before RTI, which restores the stacked P.
; Runnable end-to-end reproducers and explanation:
; https://biohack.net/snes/nmitally/ (M/X) and the #141 dpbank demo (D/DBR).

define void @isr() "interrupt" {
; CHECK-LABEL: isr:
; CHECK:       rep #48
; CHECK-NEXT:  pha
; CHECK-NEXT:  phx
; CHECK-NEXT:  phy
; CHECK-NEXT:  phb
; CHECK-NEXT:  phd
; CHECK-NEXT:  pea 0
; CHECK-NEXT:  pld
; CHECK-NEXT:  phk
; CHECK-NEXT:  plb
; CHECK-NEXT:  sep #48
; CHECK:       cld
; CHECK:       rep #48
; CHECK-NEXT:  pld
; CHECK-NEXT:  plb
; CHECK-NEXT:  ply
; CHECK-NEXT:  plx
; CHECK-NEXT:  pla
; CHECK-NEXT:  rti
  ret void
}
