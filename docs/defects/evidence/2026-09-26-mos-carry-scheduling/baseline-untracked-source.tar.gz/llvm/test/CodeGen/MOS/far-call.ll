; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16 -verify-machineinstrs < %s | FileCheck %s
; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16 -verify-machineinstrs -filetype=obj -o %t.o < %s
; RUN: llvm-objdump -d --print-imm-hex %t.o | FileCheck %s --check-prefix=OBJ
; RUN: llc -mtriple=mos -verify-machineinstrs < %s | FileCheck %s --check-prefix=NEAR

; #320 far calls -- the cross-BANK half of the far model (MOSCallLowering::lowerCall
; / lowerReturn, MOSLateOptimization::tailJMP). A function the linker places in
; another 64 KB bank is marked by its .far_* section:
;
;   * a direct call to it is JSL ($22, pushes a 3-byte PBR:PC return) so the
;     program bank follows;                              -- far_call.c
;   * it returns with RTL ($6b, pops those 3 bytes);     -- far_call.c
;   * a far block tail `JSL <far target>; RTL` folds to TailJML, which encodes as
;     the long jump $5c -- the callee's own RTL then pops the ORIGINAL caller's
;     return, tail-call style.                           -- far_tail.c
;
; All three are W65816-only: the NEAR prefix checks that the default (6502) target
; is untouched -- no $22/$6b/$5c, just the ordinary near call/return shapes.
;
; The OBJ checks live together here because the disassembly is emitted per SECTION
; (.text before .far_text), not in source order.
;
; OBJ-LABEL: <near_calls_far>:
; OBJ: 22 {{[0-9a-f]+ [0-9a-f]+ [0-9a-f]+}} {{.*}}jsl
; OBJ-LABEL: <far_leaf>:
; OBJ: 6b {{.*}}rtl
; OBJ-LABEL: <far_tails_far>:
; OBJ: 5c {{[0-9a-f]+ [0-9a-f]+ [0-9a-f]+}} {{.*}}jmp

target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"

; The far callee: placed in .far_text, so it must return with RTL, not RTS.
define i8 @far_leaf(i8 %x) noinline section ".far_text" {
; CHECK-LABEL: far_leaf:
; CHECK: rtl
; CHECK-NOT: rts
; NEAR-LABEL: far_leaf:
; NEAR: rts
  %r = xor i8 %x, 90
  ret i8 %r
}

; A near caller reaching a far callee goes long: JSL ($22). (It is a plain call,
; not a tail call -- the near tail-call fold must not swallow a far callee.)
define i8 @near_calls_far(i8 %x) {
; CHECK-LABEL: near_calls_far:
; CHECK: jsl mos24(far_leaf)
; CHECK: rts
  %r = call i8 @far_leaf(i8 %x)
  ret i8 %r
}

; A far function tail-calling a far function: the `JSL far_leaf; RTL` tail folds
; to TailJML -- printed as a long `jmp`, encoded $5c.
define i8 @far_tails_far(i8 %x) section ".far_text" {
; CHECK-LABEL: far_tails_far:
; CHECK: jmp mos24(far_leaf)
; CHECK-NOT: rtl
;
; On the default 6502 target there is no banking at all: neither the long call,
; the long return, nor the long jump may appear anywhere in the module.
; NEAR-NOT: jsl
; NEAR-NOT: rtl
; NEAR-NOT: mos24(
  %r = tail call i8 @far_leaf(i8 %x)
  ret i8 %r
}
