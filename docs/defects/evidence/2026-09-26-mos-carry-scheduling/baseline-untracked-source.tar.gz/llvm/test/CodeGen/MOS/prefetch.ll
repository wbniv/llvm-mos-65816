; RUN: llc -mtriple=mos -mcpu=mos6502 -O0 -verify-machineinstrs < %s | FileCheck %s
; RUN: llc -mtriple=mos -mcpu=mos6502 -O2 -verify-machineinstrs < %s | FileCheck %s

; __builtin_prefetch lowers to llvm.prefetch; the 6502 has no prefetch, so the
; hint is dropped and the function is empty.

define void @hint_read(ptr %p) {
; CHECK-LABEL: hint_read:
; CHECK-NEXT: ; %bb.0:
; CHECK-NEXT: rts
  call void @llvm.prefetch.p0(ptr %p, i32 0, i32 3, i32 1)
  ret void
}

define void @hint_write_all_localities(ptr %p) {
; CHECK-LABEL: hint_write_all_localities:
; CHECK-NEXT: ; %bb.0:
; CHECK-NEXT: rts
  call void @llvm.prefetch.p0(ptr %p, i32 1, i32 0, i32 1)
  call void @llvm.prefetch.p0(ptr %p, i32 1, i32 1, i32 1)
  call void @llvm.prefetch.p0(ptr %p, i32 1, i32 2, i32 1)
  call void @llvm.prefetch.p0(ptr %p, i32 1, i32 3, i32 1)
  ret void
}

declare void @llvm.prefetch.p0(ptr, i32 immarg, i32 immarg, i32 immarg)
