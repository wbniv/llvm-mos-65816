; RUN: llc -mtriple=mos -mcpu=mos6502 -O2 -verify-machineinstrs < %s | FileCheck %s
; RUN: llc -mtriple=mos -mcpu=mos6502 -O2 -verify-machineinstrs -disable-spill-hoist < %s | FileCheck %s

; This function's soft-stack spills use STStk pseudos with a scratch Imag16
; frame-address register. Frame-index elimination materialises the address
; later. Greedy's global spill hoisting runs after the allocation queue has
; drained and re-emits merged spills through storeRegToStackSlot. A hook that
; needs a scratch register cannot use that path because no allocation follows.
; The hoister must keep the original spills in that case. Hooks needing no
; additional virtual registers remain eligible.
;
; CHECK-LABEL: main:
; CHECK: rts

; ModuleID = '<bc file>'
target datalayout = "e-m:e-p:16:8-p1:8:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

define i16 @main(ptr %array, ptr %0, ptr %1, i16 %2, ptr %3, ptr %4, ptr %array1, i16 %5, i16 %6, i16 %7, i16 %8, i16 %9, i16 %10) {
  %12 = load i16, ptr %array, align 1
  br label %13

13:                                               ; preds = %28, %11
  %14 = phi i16 [ 0, %11 ], [ %29, %28 ]
  %15 = icmp eq i16 %5, %14
  br i1 %15, label %31, label %16

16:                                               ; preds = %13
  %17 = icmp eq i16 %6, 0
  br i1 %17, label %31, label %18

18:                                               ; preds = %16
  %19 = icmp eq i16 %2, %7
  br i1 %19, label %31, label %20

20:                                               ; preds = %18
  %21 = icmp eq i16 %12, %14
  br i1 %21, label %31, label %22

22:                                               ; preds = %20
  %23 = icmp eq i16 %7, %14
  br i1 %23, label %31, label %24

24:                                               ; preds = %22
  %25 = icmp eq i16 %8, %14
  %26 = icmp eq i16 %9, %14
  %or.cond = select i1 %25, i1 false, i1 %26
  %27 = icmp eq i16 %10, %14
  %or.cond1 = select i1 %or.cond, i1 false, i1 %27
  br i1 %or.cond1, label %31, label %28

28:                                               ; preds = %24
  %29 = add i16 %14, 1
  %30 = icmp eq i16 %29, 0
  br i1 false, label %32, label %13

31:                                               ; preds = %24, %22, %20, %18, %16, %13
  ret i16 0

32:                                               ; preds = %28
  tail call void null()
  unreachable
}
