; RUN: llvm-mc -triple=mos -mcpu=mos6502 -show-encoding %s -o %t.s
; RUN: FileCheck %s < %t.s
; RUN: llvm-mc -triple=mos -mcpu=mos6502 -filetype=obj %s -o %t.direct.o
; RUN: llvm-mc -triple=mos -mcpu=mos6502 -filetype=obj %t.s -o %t.roundtrip.o
; RUN: cmp %t.direct.o %t.roundtrip.o
; RUN: llvm-mc -triple=mos -mcpu=mosw65816 -show-encoding %s -o %t.65816.s
; RUN: FileCheck %s < %t.65816.s
; RUN: llvm-mc -triple=mos -mcpu=mosw65816 -filetype=obj %s -o %t.65816.direct.o
; RUN: llvm-mc -triple=mos -mcpu=mosw65816 -filetype=obj %t.65816.s -o %t.65816.roundtrip.o
; RUN: cmp %t.65816.direct.o %t.65816.roundtrip.o

; Quotes distinguish memory symbols from register operands. Both instructions
; must retain their addressing mode when printed and assembled again.
asl a
; CHECK: asl ; encoding: [0x0a]
asl "a"
; CHECK: asl "a" ; encoding: [0x06,A]
lda "s"
; CHECK: lda "s"
lda "x"+1
; CHECK: lda "x"+1
lda "y",x
; CHECK: lda "y",x
lda ("s"),y
; CHECK: lda ("s"),y

; Register recognition is case insensitive, including prefixed and imaginary
; names. The symbol's spelling and addend must survive printing unchanged.
lda "A"
; CHECK: lda "A"
lda "X"
; CHECK: lda "X"
lda "LlVm_MoS_x"
; CHECK: lda "LlVm_MoS_x"
lda "rc0"
; CHECK: lda "rc0"
lda "RS1"+2
; CHECK: lda "RS1"+2
lda "llvm_mos_rc255"
; CHECK: lda "llvm_mos_rc255"

; The parser also recognizes register tokens used by other MOS CPUs.
lda "z"
; CHECK: lda "z"
lda "sp"
; CHECK: lda "sp"
lda "r"
; CHECK: lda "r"
lda "rp"
; CHECK: lda "rp"
lda "ya"
; CHECK: lda "ya"
lda "c"
; CHECK: lda "c"
lda "PSW"
; CHECK: lda "PSW"

; Ordinary identifiers stay unquoted, and quoted definitions denote the same
; symbols as their uses and as unquoted references in directives.
lda value
; CHECK: lda value
"s":
; CHECK: "s":
.byte 0
.word s
; CHECK: .short "s"
