# RUN: llvm-mc -triple=mos -mcpu=mosw65816 -filetype=obj %s -o %t
# RUN: llvm-objdump -dr %t | FileCheck %s

# A section-relative offset contributes to the required address width even
# though the linker supplies the section's final address. Explicit modifiers
# retain their requested width; small ordinary-section offsets stay near.
.data
base:
.space 65535
last16:
.byte 0
first24:
.byte 0

.text
lda base
# CHECK: ad 00 00
# CHECK: R_MOS_ADDR16
lda last16
# CHECK: ad 00 00
# CHECK: R_MOS_ADDR16
lda first24
# CHECK: af 00 00 00
# CHECK: R_MOS_ADDR24
lda base+65536
# CHECK: af 00 00 00
# CHECK: R_MOS_ADDR24
lda first24-1
# CHECK: ad 00 00
# CHECK: R_MOS_ADDR16
lda mos16(first24)
# CHECK: ad 00 00
# CHECK: R_MOS_ADDR16
lda first24,x
# CHECK: bf 00 00 00
# CHECK: R_MOS_ADDR24
sta first24
# CHECK: 8f 00 00 00
# CHECK: R_MOS_ADDR24
lda external
# CHECK: af 00 00 00
# CHECK: R_MOS_ADDR24
