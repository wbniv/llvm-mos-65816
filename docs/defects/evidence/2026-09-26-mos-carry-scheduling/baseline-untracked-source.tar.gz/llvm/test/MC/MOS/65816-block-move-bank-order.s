; RUN: llvm-mc -assemble --print-imm-hex --show-encoding -triple mos -motorola-integers --mcpu=mosw65816 < %s | FileCheck %s

	mvn	#$7f, #$00 ; CHECK: encoding: [0x54,0x00,0x7f]
	mvp	#$12, #$34 ; CHECK: encoding: [0x44,0x34,0x12]
