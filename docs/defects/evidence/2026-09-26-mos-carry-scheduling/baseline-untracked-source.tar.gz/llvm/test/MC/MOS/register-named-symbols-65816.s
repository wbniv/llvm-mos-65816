; RUN: llvm-mc -triple=mos -mcpu=mosw65816 -show-encoding %s -o %t.s
; RUN: FileCheck %s < %t.s
; RUN: llvm-mc -triple=mos -mcpu=mosw65816 -filetype=obj %s -o %t.direct.o
; RUN: llvm-mc -triple=mos -mcpu=mosw65816 -filetype=obj %t.s -o %t.roundtrip.o
; RUN: cmp %t.direct.o %t.roundtrip.o

; A stack-relative symbol operand needs quotes while the stack register token
; remains unquoted. Parenthesized and long-indirect operands retain the same
; symbol identity and addressing mode through printing and reassembly.
lda "s",s
; CHECK: lda "s",s ; encoding: [0xa3,A]
lda ("s",s),y
; CHECK: lda ("s",s),y ; encoding: [0xb3,A]
lda ["x"],y
; CHECK: lda ["x"],y ; encoding: [0xb7,A]
