	.zeropage	__rc0
	.zeropage	__rc1
	.zeropage	__rc2
	.zeropage	__rc3
	.zeropage	__rc4
	.zeropage	__rc5
	.zeropage	__rc6
	.zeropage	__rc7
	.zeropage	__rc8
	.zeropage	__rc9
	.zeropage	__rc10
	.zeropage	__rc11
	.zeropage	__rc12
	.zeropage	__rc13
	.zeropage	__rc14
	.zeropage	__rc15
	.zeropage	__rc16
	.zeropage	__rc17
	.zeropage	__rc18
	.zeropage	__rc19
	.zeropage	__rc20
	.zeropage	__rc21
	.zeropage	__rc22
	.zeropage	__rc23
	.zeropage	__rc24
	.zeropage	__rc25
	.zeropage	__rc26
	.zeropage	__rc27
	.zeropage	__rc28
	.zeropage	__rc29
	.zeropage	__rc30
	.zeropage	__rc31
	.file	"farblit.c"
	.section	.text.main,"ax",@progbits
	.globl	main                            ; -- Begin function main
	.type	main,@function
main:                                   ; @main
.Lfunc_begin0:
	.file	0 "/home/will/llvm-mos-65816" "/home/will/llvm-mos-65816/.scratch/far-word-policy/source/farblit.c" md5 0x07b076447efbbb883855b4932d02de6c
	.file	1 ".scratch/far-word-policy/source" "farblit.c" md5 0x07b076447efbbb883855b4932d02de6c
	.loc	1 225 0                         ; .scratch/far-word-policy/source/farblit.c:225:0
; %bb.0:
	clc
	lda	__rc0
	adc	#241
	sta	__rc0
	lda	__rc1
	adc	#255
	sta	__rc1
	stz	__rc7
.Ltmp0:
	.loc	1 49 35 prologue_end            ; .scratch/far-word-policy/source/farblit.c:49:35 @[ .scratch/far-word-policy/source/farblit.c:186:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldx	rbase8
	stx	__rc2
	ldx	rbase8+1
	stx	__rc3
	ldx	rbase8+2
	stx	__rc4
	ldx	rbase8+3
	stx	__rc5
	.loc	1 49 33 is_stmt 0               ; .scratch/far-word-policy/source/farblit.c:49:33 @[ .scratch/far-word-policy/source/farblit.c:186:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc2
	sta	__rc8
	lda	#mos24segmenthi(tbl)
	adc	__rc3
	sta	__rc9
	lda	#mos24bank(tbl)
	adc	__rc4
	sta	__rc10
	lda	#0
	adc	__rc5
	sta	__rc11
	stz	__rc4
	stz	__rc5
	stz	__rc2
	lda	#0
	tay
	bra	.LBB0_2
.LBB0_1:                                ;   in Loop: Header=BB0_2 Depth=1
	.loc	1 52 21                         ; .scratch/far-word-policy/source/farblit.c:52:21 @[ .scratch/far-word-policy/source/farblit.c:186:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	[__rc8],y
.Ltmp1:
	.loc	1 40 14 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:52:11 @[ .scratch/far-word-policy/source/farblit.c:186:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ] ]
	sta	__rc6
	rep	#32
	lda	__rc4
	eor	__rc6
	sta	__rc4
	lda	__rc2
	eor	#mos16(0)
	sta	__rc2
	sep	#32
.Ltmp2:
	.loc	1 51 32                         ; .scratch/far-word-policy/source/farblit.c:51:32 @[ .scratch/far-word-policy/source/farblit.c:186:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	iny
	lda	__rc3
.LBB0_2:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 51 3                          ; .scratch/far-word-policy/source/farblit.c:51:3 @[ .scratch/far-word-policy/source/farblit.c:186:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc2
	rol
	sta	__rc3
	cpy	#64
	bne	.LBB0_1
.Ltmp3:
; %bb.3:
	.loc	1 0 3 is_stmt 0                 ; .scratch/far-word-policy/source/farblit.c:0:3
	ldy	#11
	sta	(__rc0),y                       ; 1-byte Folded Spill
	stz	__rc9
	stz	__rc10
	stz	__rc11
	stz	__rc6
	ldx	#0
	txa
	ldy	#14
	bra	.LBB0_5
.LBB0_4:                                ;   in Loop: Header=BB0_5 Depth=1
.Ltmp4:
	.loc	1 58 21                         ; .scratch/far-word-policy/source/farblit.c:58:21 @[ .scratch/far-word-policy/source/farblit.c:187:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	mos24(tbl),x
	sta	__rc8
	ldy	#14
	lda	(__rc0),y                       ; 1-byte Folded Reload
.Ltmp5:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:58:11 @[ .scratch/far-word-policy/source/farblit.c:187:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ] ]
	cmp	#128
	rol	__rc10
	rol	__rc11
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:58:11 @[ .scratch/far-word-policy/source/farblit.c:187:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ] ]
	sta	__rc7
	rep	#32
	lda	__rc10
	eor	__rc8
	sta	__rc10
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp6:
	.loc	1 57 32                         ; .scratch/far-word-policy/source/farblit.c:57:32 @[ .scratch/far-word-policy/source/farblit.c:187:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	inx
	lda	__rc7
.Ltmp7:
.LBB0_5:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 0 32 is_stmt 0                ; .scratch/far-word-policy/source/farblit.c:0:32
	sta	(__rc0),y                       ; 1-byte Folded Spill
	cpx	#64
	bne	.LBB0_4
; %bb.6:
                                        ; kill: def $rs3 killed $rs3
	lda	__rc6
	ldy	#9
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc7
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
.Ltmp8:
	.loc	1 62 35 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:62:35 @[ .scratch/far-word-policy/source/farblit.c:188:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldx	rbase16
	stx	__rc3
	ldx	rbase16+1
	stx	__rc6
	ldx	rbase16+2
	stx	__rc7
	ldx	rbase16+3
	stx	__rc8
	.loc	1 62 33 is_stmt 0               ; .scratch/far-word-policy/source/farblit.c:62:33 @[ .scratch/far-word-policy/source/farblit.c:188:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc3
	sta	__rc20
	lda	#mos24segmenthi(tbl)
	adc	__rc6
	sta	__rc21
	lda	#mos24bank(tbl)
	adc	__rc7
	sta	__rc22
	lda	#0
	adc	__rc8
	sta	__rc23
	stz	__rc13
	ldx	#0
	stz	__rc14
	stz	__rc15
	stz	__rc8
	txy
	tya
; %bb.32:
	.loc	1 0 33                          ; .scratch/far-word-policy/source/farblit.c:0:33
	jmp	.LBB0_8
.LBB0_7:                                ;   in Loop: Header=BB0_8 Depth=1
	.loc	1 65 25                         ; .scratch/far-word-policy/source/farblit.c:65:25 @[ .scratch/far-word-policy/source/farblit.c:188:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	stx	__rc12
	ldy	#mos16lo(offs16)
	sty	__rc6
	ldy	#mos16hi(offs16)
	sty	__rc7
	rep	#32
	lda	__rc6
	clc
	adc	__rc12
	sta	__rc6
	lda	(__rc6)
	sta	__rc6
	sep	#32
	ldy	#13
	lda	(__rc0),y                       ; 1-byte Folded Reload
.Ltmp9:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:65:11 @[ .scratch/far-word-policy/source/farblit.c:188:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ] ]
	cmp	#128
	sta	__rc9
	rol	__rc14
	rol	__rc15
	rol	__rc8
	rol	__rc9
	rep	#16
.Ltmp10:
	.loc	1 65 21 is_stmt 0               ; .scratch/far-word-policy/source/farblit.c:65:21 @[ .scratch/far-word-policy/source/farblit.c:188:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldy	__rc6
	lda	[__rc20],y
.Ltmp11:
	.loc	1 40 14 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:65:11 @[ .scratch/far-word-policy/source/farblit.c:188:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ] ]
	sta	__rc12
	rep	#32
	lda	__rc14
	eor	__rc12
	sta	__rc14
	lda	__rc8
	eor	#mos16(0)
	sta	__rc8
	sep	#48
.Ltmp12:
	.loc	1 64 3 is_stmt 0                ; .scratch/far-word-policy/source/farblit.c:64:3 @[ .scratch/far-word-policy/source/farblit.c:188:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	inx
	inx
	lda	__rc9
.Ltmp13:
.LBB0_8:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 0 3                           ; .scratch/far-word-policy/source/farblit.c:0:3
	ldy	#13
	sta	(__rc0),y                       ; 1-byte Folded Spill
	cpx	#16
	beq	.LBB0_9
; %bb.36:                               ;   in Loop: Header=BB0_8 Depth=1
	jmp	.LBB0_7
.LBB0_9:
                                        ; kill: def $rs7 killed $rs7
	lda	__rc14
	ldy	#3
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc15
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
                                        ; kill: def $rs4 killed $rs4
	lda	__rc8
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc9
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
.Ltmp14:
	.loc	1 69 35 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:69:35 @[ .scratch/far-word-policy/source/farblit.c:189:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	rbasew
	ldx	rbasew+1
	.loc	1 69 33 is_stmt 0               ; .scratch/far-word-policy/source/farblit.c:69:33 @[ .scratch/far-word-policy/source/farblit.c:189:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	asl
	sta	__rc3
	.loc	1 69 35                         ; .scratch/far-word-policy/source/farblit.c:69:35 @[ .scratch/far-word-policy/source/farblit.c:189:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldy	rbasew+2
	sty	__rc7
	stx	__rc6
	.loc	1 69 33                         ; .scratch/far-word-policy/source/farblit.c:69:33 @[ .scratch/far-word-policy/source/farblit.c:189:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	rol	__rc6
	.loc	1 69 35                         ; .scratch/far-word-policy/source/farblit.c:69:35 @[ .scratch/far-word-policy/source/farblit.c:189:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	rbasew+3
	.loc	1 69 33                         ; .scratch/far-word-policy/source/farblit.c:69:33 @[ .scratch/far-word-policy/source/farblit.c:189:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	rol	__rc7
	rol
	sta	__rc8
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc3
	tay
	lda	#mos24segmenthi(tbl)
	adc	__rc6
	sta	__rc21
	lda	#mos24bank(tbl)
	adc	__rc7
	sta	__rc22
	lda	#0
	adc	__rc8
	sta	__rc23
	stz	__rc19
	stz	__rc20
	stz	__rc18
	ldx	#0
	stz	__rc3
	txa
	phy
	ldy	#12
; %bb.34:
	.loc	1 0 33                          ; .scratch/far-word-policy/source/farblit.c:0:33
	jmp	.LBB0_11
.LBB0_10:                               ;   in Loop: Header=BB0_11 Depth=1
	.loc	1 72 21                         ; .scratch/far-word-policy/source/farblit.c:72:21 @[ .scratch/far-word-policy/source/farblit.c:189:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	txa
	asl
	sta	__rc3
	lda	#0
	rol
	sta	__rc6
	stz	__rc7
	rol	__rc7
	stz	__rc8
	rol	__rc8
	tya
	clc
	adc	__rc3
	sta	__rc12
	lda	__rc21
	adc	__rc6
	sta	__rc13
	lda	__rc22
	adc	__rc7
	sta	__rc14
	lda	__rc23
	adc	__rc8
	sta	__rc15
	rep	#32
	lda	[__rc12]
	sta	__rc6
	sep	#32
	phy
	ldy	#12
	lda	(__rc0),y                       ; 1-byte Folded Reload
.Ltmp15:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:72:11 @[ .scratch/far-word-policy/source/farblit.c:189:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ] ]
	cmp	#128
	rol	__rc19
	rol	__rc20
	rol	__rc18
	rol
	phy
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:72:11 @[ .scratch/far-word-policy/source/farblit.c:189:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ] ]
	ldy	__rc19
	sty	__rc8
	ldy	__rc20
	sty	__rc9
	ldy	__rc18
	sty	__rc12
	ply
	sta	__rc13
	rep	#32
	lda	__rc8
	eor	__rc6
	sta	__rc6
	lda	__rc12
	eor	#mos16(0)
	sta	__rc8
	sep	#32
.Ltmp16:
	.loc	1 71 32                         ; .scratch/far-word-policy/source/farblit.c:71:32 @[ .scratch/far-word-policy/source/farblit.c:189:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	inx
	lda	__rc6
	sta	__rc19
	lda	__rc7
	sta	__rc20
	lda	__rc8
	sta	__rc18
	lda	__rc9
.Ltmp17:
.LBB0_11:                               ; =>This Inner Loop Header: Depth=1
	.loc	1 0 32 is_stmt 0                ; .scratch/far-word-policy/source/farblit.c:0:32
	sta	(__rc0),y                       ; 1-byte Folded Spill
	ply
	cpx	#64
	beq	.LBB0_12
; %bb.38:                               ;   in Loop: Header=BB0_11 Depth=1
	jmp	.LBB0_10
.LBB0_12:
	lda	__rc19
	ldy	#1
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc18
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
.Ltmp18:
	.loc	1 76 35 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:76:35 @[ .scratch/far-word-policy/source/farblit.c:190:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldx	rbasew16
	stx	__rc3
	ldx	rbasew16+1
	stx	__rc6
	ldx	rbasew16+2
	stx	__rc7
	ldx	rbasew16+3
	stx	__rc8
	.loc	1 76 33 is_stmt 0               ; .scratch/far-word-policy/source/farblit.c:76:33 @[ .scratch/far-word-policy/source/farblit.c:190:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc3
	sta	__rc24
	lda	#mos24segmenthi(tbl)
	adc	__rc6
	sta	__rc25
	lda	#mos24bank(tbl)
	adc	__rc7
	sta	__rc26
	lda	#0
	adc	__rc8
	sta	__rc27
	.loc	1 77 16 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:77:16 @[ .scratch/far-word-policy/source/farblit.c:190:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldy	obase
	lda	obase+1
	ldx	#32
	stz	__rc13
	sty	__rc14
	sta	__rc15
	stz	__rc18
	stz	__rc19
	stz	__rc6
	stz	__rc7
	bra	.LBB0_14
.LBB0_13:                               ;   in Loop: Header=BB0_14 Depth=1
	.loc	1 0 16 is_stmt 0                ; .scratch/far-word-policy/source/farblit.c:0:16
	rep	#16
	.loc	1 80 21                         ; .scratch/far-word-policy/source/farblit.c:80:21 @[ .scratch/far-word-policy/source/farblit.c:190:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldy	__rc14
	lda	[__rc24],y
	sta	__rc12
	lda	__rc7
.Ltmp19:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:80:11 @[ .scratch/far-word-policy/source/farblit.c:190:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ] ]
	cmp	#128
	rol	__rc18
	rol	__rc19
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:80:11 @[ .scratch/far-word-policy/source/farblit.c:190:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ] ]
	sta	__rc7
	rep	#32
	lda	__rc18
	eor	__rc12
	sta	__rc18
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
.Ltmp20:
	.loc	1 79 3 is_stmt 0                ; .scratch/far-word-policy/source/farblit.c:79:3 @[ .scratch/far-word-policy/source/farblit.c:190:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc14
	inc
	sta	__rc14
	sep	#48
	dex
.Ltmp21:
.LBB0_14:                               ; =>This Inner Loop Header: Depth=1
	.loc	1 0 3                           ; .scratch/far-word-policy/source/farblit.c:0:3
	txa
	bne	.LBB0_13
; %bb.15:
.Ltmp22:
	.loc	1 84 16 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:84:16 @[ .scratch/far-word-policy/source/farblit.c:191:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldx	obase
	lda	obase+1
	ldy	#32
	stz	__rc13
	stx	__rc14
	sta	__rc15
	stz	__rc26
	stz	__rc27
	stz	__rc24
	stz	__rc25
	bra	.LBB0_17
.LBB0_16:                               ;   in Loop: Header=BB0_17 Depth=1
	.loc	1 0 16 is_stmt 0                ; .scratch/far-word-policy/source/farblit.c:0:16
	rep	#16
	.loc	1 87 21                         ; .scratch/far-word-policy/source/farblit.c:87:21 @[ .scratch/far-word-policy/source/farblit.c:191:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldx	__rc14
	lda	mos24(tbl),x
	sta	__rc12
	lda	__rc25
.Ltmp23:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:87:11 @[ .scratch/far-word-policy/source/farblit.c:191:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ] ]
	cmp	#128
	rol	__rc26
	rol	__rc27
	rol	__rc24
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:87:11 @[ .scratch/far-word-policy/source/farblit.c:191:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ] ]
	sta	__rc25
	rep	#32
	lda	__rc26
	eor	__rc12
	sta	__rc26
	lda	__rc24
	eor	#mos16(0)
	sta	__rc24
.Ltmp24:
	.loc	1 86 3 is_stmt 0                ; .scratch/far-word-policy/source/farblit.c:86:3 @[ .scratch/far-word-policy/source/farblit.c:191:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc14
	inc
	sta	__rc14
	sep	#48
	dey
.Ltmp25:
.LBB0_17:                               ; =>This Inner Loop Header: Depth=1
	.loc	1 0 3                           ; .scratch/far-word-policy/source/farblit.c:0:3
	tya
	bne	.LBB0_16
; %bb.18:
.Ltmp26:
	.loc	1 91 35 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:91:35 @[ .scratch/far-word-policy/source/farblit.c:192:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldx	rbase8
	stx	__rc3
	ldx	rbase8+1
	stx	__rc13
	ldx	rbase8+2
	stx	__rc8
	ldx	rbase8+3
	stx	__rc9
	.loc	1 91 33 is_stmt 0               ; .scratch/far-word-policy/source/farblit.c:91:33 @[ .scratch/far-word-policy/source/farblit.c:192:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc3
	sta	__rc12
	lda	#mos24segmenthi(tbl)
	adc	__rc13
	sta	__rc13
	lda	#mos24bank(tbl)
	adc	__rc8
	sta	__rc14
	lda	#0
	adc	__rc9
	sta	__rc15
	.loc	1 92 15 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:92:15 @[ .scratch/far-word-policy/source/farblit.c:192:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldy	k8
	ldx	#32
	stz	__rc31
	stz	__rc8
	stz	__rc9
	stz	__rc28
	stz	__rc29
	bra	.LBB0_20
.LBB0_19:                               ;   in Loop: Header=BB0_20 Depth=1
	.loc	1 95 21 is_stmt 0               ; .scratch/far-word-policy/source/farblit.c:95:21 @[ .scratch/far-word-policy/source/farblit.c:192:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	[__rc12],y
	sta	__rc30
	lda	__rc29
.Ltmp27:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:95:11 @[ .scratch/far-word-policy/source/farblit.c:192:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ] ]
	cmp	#128
	rol	__rc8
	rol	__rc9
	rol	__rc28
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:95:11 @[ .scratch/far-word-policy/source/farblit.c:192:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ] ]
	sta	__rc29
	rep	#32
	lda	__rc8
	eor	__rc30
	sta	__rc8
	lda	__rc28
	eor	#mos16(0)
	sta	__rc28
	sep	#32
.Ltmp28:
	.loc	1 94 3 is_stmt 0                ; .scratch/far-word-policy/source/farblit.c:94:3 @[ .scratch/far-word-policy/source/farblit.c:192:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	iny
	dex
.Ltmp29:
.LBB0_20:                               ; =>This Inner Loop Header: Depth=1
	.loc	1 0 3                           ; .scratch/far-word-policy/source/farblit.c:0:3
	txa
	bne	.LBB0_19
; %bb.21:
.Ltmp30:
	.loc	1 99 35 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:99:35 @[ .scratch/far-word-policy/source/farblit.c:193:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldx	wbase8
	stx	__rc12
	ldy	wbase8+1
	lda	wbase8+2
	ldx	wbase8+3
	sty	__rc13
	sta	__rc14
	stx	__rc15
	lda	#11
	ldy	#0
	bra	.LBB0_23
.LBB0_22:                               ;   in Loop: Header=BB0_23 Depth=1
	.loc	1 101 10                        ; .scratch/far-word-policy/source/farblit.c:101:10 @[ .scratch/far-word-policy/source/farblit.c:193:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	[__rc12],y
	.loc	1 100 32                        ; .scratch/far-word-policy/source/farblit.c:100:32 @[ .scratch/far-word-policy/source/farblit.c:193:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	iny
	.loc	1 100 3 is_stmt 0               ; .scratch/far-word-policy/source/farblit.c:100:3 @[ .scratch/far-word-policy/source/farblit.c:193:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	clc
	adc	#37
.Ltmp31:
.LBB0_23:                               ; =>This Inner Loop Header: Depth=1
	.loc	1 0 3                           ; .scratch/far-word-policy/source/farblit.c:0:3
	cpy	#64
	bne	.LBB0_22
; %bb.24:
	lda	__rc20
	ldy	#0
	sta	(__rc0),y                       ; 1-byte Folded Spill
.Ltmp32:
	.loc	1 110 35 is_stmt 1              ; .scratch/far-word-policy/source/farblit.c:110:35 @[ .scratch/far-word-policy/source/farblit.c:194:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldx	wbase16
	stx	__rc12
	ldy	wbase16+1
	lda	wbase16+2
	ldx	wbase16+3
	sty	__rc13
	sta	__rc14
	stx	__rc15
	stz	__rc31
	stz	__rc3
	ldx	#0
	bra	.LBB0_26
.LBB0_25:                               ;   in Loop: Header=BB0_26 Depth=1
	.loc	1 112 7                         ; .scratch/far-word-policy/source/farblit.c:112:7 @[ .scratch/far-word-policy/source/farblit.c:194:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	stx	__rc30
	ldy	#mos16lo(offs16)
	sty	__rc20
	ldy	#mos16hi(offs16)
	sty	__rc21
	rep	#32
	lda	__rc20
	clc
	adc	__rc30
	sta	__rc20
	lda	(__rc20)
	sta	__rc20
	sep	#32
	.loc	1 112 36 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:112:36 @[ .scratch/far-word-policy/source/farblit.c:194:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc3
	eor	#165
	rep	#16
	.loc	1 112 18                        ; .scratch/far-word-policy/source/farblit.c:112:18 @[ .scratch/far-word-policy/source/farblit.c:194:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldy	__rc20
	sta	[__rc12],y
	sep	#16
	.loc	1 111 3                         ; .scratch/far-word-policy/source/farblit.c:111:3 @[ .scratch/far-word-policy/source/farblit.c:194:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	inx
	inx
	clc
	lda	__rc3
	adc	#29
	sta	__rc3
.Ltmp33:
.LBB0_26:                               ; =>This Inner Loop Header: Depth=1
	.loc	1 0 3                           ; .scratch/far-word-policy/source/farblit.c:0:3
	cpx	#16
	bne	.LBB0_25
; %bb.27:
                                        ; kill: def $rs5 killed $rs5
	lda	__rc10
	ldy	#7
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc11
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
.Ltmp34:
	.loc	1 104 35 is_stmt 1              ; .scratch/far-word-policy/source/farblit.c:104:35 @[ .scratch/far-word-policy/source/farblit.c:195:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldx	wbasec
	ldy	wbasec+1
	lda	wbasec+2
	sta	__rc22
	lda	wbasec+3
	sta	__rc23
	.loc	1 105 35 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:105:35 @[ .scratch/far-word-policy/source/farblit.c:195:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	rbase8
	sta	__rc3
	lda	rbase8+1
	sta	__rc10
	lda	rbase8+2
	sta	__rc11
	lda	rbase8+3
	sta	__rc15
	.loc	1 105 33                        ; .scratch/far-word-policy/source/farblit.c:105:33 @[ .scratch/far-word-policy/source/farblit.c:195:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc3
	sta	__rc12
	lda	#mos24segmenthi(tbl)
	adc	__rc10
	sta	__rc13
	lda	#mos24bank(tbl)
	adc	__rc11
	sta	__rc14
	lda	#0
	adc	__rc15
	sta	__rc15
	.loc	1 104 35 is_stmt 1              ; .scratch/far-word-policy/source/farblit.c:104:35 @[ .scratch/far-word-policy/source/farblit.c:195:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	stx	__rc20
	sty	__rc21
	stz	__rc31
	ldy	#0
	bra	.LBB0_29
.Ltmp35:
.LBB0_28:                               ;   in Loop: Header=BB0_29 Depth=1
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:213:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sty	__rc30
	rep	#32
.Ltmp36:
	.loc	1 107 12                        ; .scratch/far-word-policy/source/farblit.c:107:12 @[ .scratch/far-word-policy/source/farblit.c:195:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc30
	clc
	adc	#mos16(8)
	sta	__rc10
	sep	#32
	tyx
	rep	#16
	ldy	__rc10
	lda	[__rc12],y
	sep	#16
	txy
	.loc	1 107 10 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:107:10 @[ .scratch/far-word-policy/source/farblit.c:195:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	[__rc20],y
	.loc	1 106 32 is_stmt 1              ; .scratch/far-word-policy/source/farblit.c:106:32 @[ .scratch/far-word-policy/source/farblit.c:195:3 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	iny
.Ltmp37:
.LBB0_29:                               ; =>This Inner Loop Header: Depth=1
	.loc	1 0 32 is_stmt 0                ; .scratch/far-word-policy/source/farblit.c:0:32
	cpy	#48
	bne	.LBB0_28
; %bb.30:
	ldy	#9
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc10
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	ldx	__rc10
	stx	__rc14
	ldy	#14
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc15
	ldy	#11
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc3
	ldy	#5
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc20
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	ldy	#13
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc21
	ldy	#7
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc10
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc11
	rep	#32
.Ltmp38:
	.loc	1 40 14 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:187:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc10
	eor	__rc4
	sta	__rc12
	lda	__rc14
	eor	__rc2
	sta	__rc4
	sep	#32
.Ltmp39:
	.loc	1 39 20                         ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:188:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldx	__rc5
	cpx	#128
	rol	__rc12
	rol	__rc13
	ldy	#3
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc2
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc3
	rep	#32
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:188:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc2
	eor	__rc12
	sta	__rc2
	sep	#32
	.loc	1 39 20                         ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:188:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	rol	__rc4
	lda	__rc5
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:188:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc5
	rep	#32
	lda	__rc20
	eor	__rc4
	sta	__rc4
	sep	#32
.Ltmp40:
	.loc	1 39 20                         ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:189:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldx	__rc5
	cpx	#128
	rol	__rc2
	rol	__rc3
	ldy	#1
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc10
	dey
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc11
	rep	#32
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:189:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc10
	eor	__rc2
	sta	__rc2
	sep	#32
	ldy	#2
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc10
	ldy	#12
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc11
	.loc	1 39 20                         ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:189:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	rol	__rc4
	lda	__rc5
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:189:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc5
	rep	#32
	lda	__rc10
	eor	__rc4
	sta	__rc4
	sep	#32
.Ltmp41:
	.loc	1 39 20                         ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:190:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldx	__rc5
	cpx	#128
	rol	__rc2
	rol	__rc3
	rep	#32
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:190:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc18
	eor	__rc2
	sta	__rc2
	sep	#32
	.loc	1 39 20                         ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:190:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	rol	__rc4
	lda	__rc5
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:190:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc5
	rep	#32
	lda	__rc6
	eor	__rc4
	sta	__rc4
	sep	#32
.Ltmp42:
	.loc	1 39 20                         ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:191:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	ldx	__rc5
	cpx	#128
	rol	__rc2
	rol	__rc3
	rep	#32
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:191:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc26
	eor	__rc2
	sta	__rc2
	sep	#32
	.loc	1 39 20                         ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:191:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	rol	__rc4
	lda	__rc5
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:191:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc5
	rep	#32
	lda	__rc24
	eor	__rc4
	sta	__rc4
	sep	#32
.Ltmp43:
	.loc	1 39 20                         ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:192:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc5
	cmp	#128
	rol	__rc2
	rol	__rc3
	rol	__rc4
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:192:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc5
	rep	#32
	lda	__rc8
	eor	__rc2
	sta	__rc6
	lda	__rc28
	eor	__rc4
	sta	__rc4
	sep	#32
.Ltmp44:
	.loc	1 198 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:198:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8323040
	sta	__rc2
	stz	__rc3
.Ltmp45:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:198:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc5
	cmp	#128
	rol	__rc6
	rol	__rc7
	rol	__rc4
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:198:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc5
	rep	#32
	lda	__rc6
	eor	__rc2
	sta	__rc6
	lda	__rc4
	eor	#mos16(0)
	sta	__rc8
	sep	#32
.Ltmp46:
	.loc	1 199 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:199:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8323071
	sta	__rc2
.Ltmp47:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:199:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc9
	cmp	#128
	rol	__rc6
	rol	__rc7
	rol	__rc8
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:199:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc9
	rep	#32
	lda	__rc6
	eor	__rc2
	sta	__rc4
	lda	__rc8
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp48:
	.loc	1 200 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:200:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8323072
	sta	__rc2
.Ltmp49:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:200:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:200:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp50:
	.loc	1 201 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:201:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8323103
	sta	__rc2
.Ltmp51:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:201:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:201:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp52:
	.loc	1 202 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:202:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8273920
	sta	__rc2
.Ltmp53:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:202:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:202:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp54:
	.loc	1 203 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:203:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8274175
	sta	__rc2
.Ltmp55:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:203:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:203:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp56:
	.loc	1 204 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:204:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8274176
	sta	__rc2
.Ltmp57:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:204:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:204:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp58:
	.loc	1 205 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:205:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8278580
	sta	__rc2
.Ltmp59:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:205:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:205:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp60:
	.loc	1 206 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:206:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8306687
	sta	__rc2
.Ltmp61:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:206:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:206:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp62:
	.loc	1 207 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:207:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8306688
	sta	__rc2
.Ltmp63:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:207:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:207:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp64:
	.loc	1 208 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:208:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8323073
	sta	__rc2
.Ltmp65:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:208:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:208:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp66:
	.loc	1 209 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:209:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8339455
	sta	__rc2
.Ltmp67:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:209:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:209:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp68:
	.loc	1 210 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:210:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8355824
	sta	__rc2
.Ltmp69:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:210:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:210:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp70:
	.loc	1 211 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:211:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8355847
	sta	__rc2
.Ltmp71:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:211:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:211:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp72:
	.loc	1 212 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:212:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8355848
	sta	__rc2
.Ltmp73:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:212:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:212:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp74:
	.loc	1 213 19 is_stmt 0              ; .scratch/far-word-policy/source/farblit.c:213:19 @[ .scratch/far-word-policy/source/farblit.c:226:19 ]
	lda	8355871
	sta	__rc2
.Ltmp75:
	.loc	1 39 20 is_stmt 1               ; .scratch/far-word-policy/source/farblit.c:39:20 @[ .scratch/far-word-policy/source/farblit.c:213:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	1 40 14                         ; .scratch/far-word-policy/source/farblit.c:40:14 @[ .scratch/far-word-policy/source/farblit.c:213:9 @[ .scratch/far-word-policy/source/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc2
	lda	__rc6
	eor	#mos16(0)
	sta	__rc4
	sep	#32
.Ltmp76:
	.loc	1 226 17                        ; .scratch/far-word-policy/source/farblit.c:226:17
	ldx	__rc2
	ldy	__rc3
	lda	__rc4
	stx	corpus_result
	sty	corpus_result+1
	sta	corpus_result+2
	ldx	__rc5
	stx	corpus_result+3
.LBB0_31:                               ; =>This Inner Loop Header: Depth=1
	.loc	1 227 12                        ; .scratch/far-word-policy/source/farblit.c:227:12
	;APP
	wai
	;NO_APP
	.loc	1 227 3                         ; .scratch/far-word-policy/source/farblit.c:227:3
	bra	.LBB0_31
.Ltmp77:
.Lfunc_end0:
	.size	main, .Lfunc_end0-main
                                        ; -- End function
	.type	rbase8,@object                  ; @rbase8
	.section	.data.rbase8,"aw",@progbits
	.globl	rbase8
rbase8:
	.long	65504                           ; 0xffe0
	.size	rbase8, 4

	.type	rbase16,@object                 ; @rbase16
	.section	.data.rbase16,"aw",@progbits
	.globl	rbase16
rbase16:
	.long	32768                           ; 0x8000
	.size	rbase16, 4

	.type	rbasew,@object                  ; @rbasew
	.section	.data.rbasew,"aw",@progbits
	.globl	rbasew
rbasew:
	.long	32736                           ; 0x7fe0
	.size	rbasew, 4

	.type	wbase8,@object                  ; @wbase8
	.section	.data.wbase8,"aw",@progbits
	.globl	wbase8
wbase8:
	.long	8323040                         ; 0x7effe0
	.size	wbase8, 4

	.type	wbase16,@object                 ; @wbase16
	.section	.data.wbase16,"aw",@progbits
	.globl	wbase16
wbase16:
	.long	8273920                         ; 0x7e4000
	.size	wbase16, 4

	.type	wbasec,@object                  ; @wbasec
	.section	.data.wbasec,"aw",@progbits
	.globl	wbasec
wbasec:
	.long	8355824                         ; 0x7f7ff0
	.size	wbasec, 4

	.type	rbasew16,@object                ; @rbasew16
	.section	.data.rbasew16,"aw",@progbits
	.globl	rbasew16
rbasew16:
	.long	65536                           ; 0x10000
	.size	rbasew16, 4

	.type	obase,@object                   ; @obase
	.section	.data.obase,"aw",@progbits
	.globl	obase
obase:
	.short	65520                           ; 0xfff0
	.size	obase, 2

	.type	k8,@object                      ; @k8
	.section	.data.k8,"aw",@progbits
	.globl	k8
k8:
	.byte	240                             ; 0xf0
	.size	k8, 1

	.type	corpus_result,@object           ; @corpus_result
	.section	.bss.corpus_result,"aw",@nobits
	.globl	corpus_result
corpus_result:
	.long	0                               ; 0x0
	.size	corpus_result, 4

	.type	offs16,@object                  ; @offs16
	.section	.rodata.cst16,"aM",@progbits,16
offs16:
	.short	0                               ; 0x0
	.short	255                             ; 0xff
	.short	256                             ; 0x100
	.short	4660                            ; 0x1234
	.short	32767                           ; 0x7fff
	.short	32768                           ; 0x8000
	.short	49153                           ; 0xc001
	.short	65535                           ; 0xffff
	.size	offs16, 16

	.section	.debug_abbrev,"",@progbits
	.byte	1                               ; Abbreviation Code
	.byte	17                              ; DW_TAG_compile_unit
	.byte	1                               ; DW_CHILDREN_yes
	.byte	37                              ; DW_AT_producer
	.byte	37                              ; DW_FORM_strx1
	.byte	19                              ; DW_AT_language
	.byte	5                               ; DW_FORM_data2
	.byte	3                               ; DW_AT_name
	.byte	37                              ; DW_FORM_strx1
	.byte	114                             ; DW_AT_str_offsets_base
	.byte	23                              ; DW_FORM_sec_offset
	.byte	16                              ; DW_AT_stmt_list
	.byte	23                              ; DW_FORM_sec_offset
	.byte	27                              ; DW_AT_comp_dir
	.byte	37                              ; DW_FORM_strx1
	.byte	17                              ; DW_AT_low_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.byte	115                             ; DW_AT_addr_base
	.byte	23                              ; DW_FORM_sec_offset
	.byte	116                             ; DW_AT_rnglists_base
	.byte	23                              ; DW_FORM_sec_offset
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	2                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	0                               ; DW_CHILDREN_no
	.byte	3                               ; DW_AT_name
	.byte	37                              ; DW_FORM_strx1
	.byte	32                              ; DW_AT_inline
	.byte	33                              ; DW_FORM_implicit_const
	.byte	1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	3                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	1                               ; DW_CHILDREN_yes
	.byte	17                              ; DW_AT_low_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.byte	122                             ; DW_AT_call_all_calls
	.byte	25                              ; DW_FORM_flag_present
	.byte	3                               ; DW_AT_name
	.byte	37                              ; DW_FORM_strx1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	4                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	1                               ; DW_CHILDREN_yes
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	17                              ; DW_AT_low_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	5                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	17                              ; DW_AT_low_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	6                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	35                              ; DW_FORM_rnglistx
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	0                               ; EOM(3)
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.long	.Ldebug_info_end0-.Ldebug_info_start0 ; Length of Unit
.Ldebug_info_start0:
	.short	5                               ; DWARF version number
	.byte	1                               ; DWARF Unit Type
	.byte	4                               ; Address Size (in bytes)
	.long	.debug_abbrev                   ; Offset Into Abbrev. Section
	.byte	1                               ; Abbrev [1] 0xc:0x240 DW_TAG_compile_unit
	.byte	0                               ; DW_AT_producer
	.short	29                              ; DW_AT_language
	.byte	1                               ; DW_AT_name
	.long	.Lstr_offsets_base0             ; DW_AT_str_offsets_base
	.long	.Lline_table_start0             ; DW_AT_stmt_list
	.byte	2                               ; DW_AT_comp_dir
	.byte	0                               ; DW_AT_low_pc
	.long	.Lfunc_end0-.Lfunc_begin0       ; DW_AT_high_pc
	.long	.Laddr_table_base0              ; DW_AT_addr_base
	.long	.Lrnglists_table_base0          ; DW_AT_rnglists_base
	.byte	2                               ; Abbrev [2] 0x27:0x2 DW_TAG_subprogram
	.byte	3                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x29:0x2 DW_TAG_subprogram
	.byte	4                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x2b:0x2 DW_TAG_subprogram
	.byte	5                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x2d:0x2 DW_TAG_subprogram
	.byte	6                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x2f:0x2 DW_TAG_subprogram
	.byte	7                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x31:0x2 DW_TAG_subprogram
	.byte	8                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x33:0x2 DW_TAG_subprogram
	.byte	9                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x35:0x2 DW_TAG_subprogram
	.byte	10                              ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x37:0x2 DW_TAG_subprogram
	.byte	11                              ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x39:0x2 DW_TAG_subprogram
	.byte	12                              ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x3b:0x2 DW_TAG_subprogram
	.byte	13                              ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x3d:0x2 DW_TAG_subprogram
	.byte	14                              ; DW_AT_name
                                        ; DW_AT_inline
	.byte	3                               ; Abbrev [3] 0x3f:0x20c DW_TAG_subprogram
	.byte	0                               ; DW_AT_low_pc
	.long	.Lfunc_end0-.Lfunc_begin0       ; DW_AT_high_pc
                                        ; DW_AT_call_all_calls
	.byte	15                              ; DW_AT_name
	.byte	4                               ; Abbrev [4] 0x46:0x204 DW_TAG_inlined_subroutine
	.long	41                              ; DW_AT_abstract_origin
	.byte	1                               ; DW_AT_low_pc
	.long	.Ltmp76-.Ltmp0                  ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	226                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x53:0x1b DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	1                               ; DW_AT_low_pc
	.long	.Ltmp3-.Ltmp0                   ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	186                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x60:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	2                               ; DW_AT_low_pc
	.long	.Ltmp2-.Ltmp1                   ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	52                              ; DW_AT_call_line
	.byte	11                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	4                               ; Abbrev [4] 0x6e:0x1b DW_TAG_inlined_subroutine
	.long	45                              ; DW_AT_abstract_origin
	.byte	3                               ; DW_AT_low_pc
	.long	.Ltmp7-.Ltmp4                   ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	187                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x7b:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	4                               ; DW_AT_low_pc
	.long	.Ltmp6-.Ltmp5                   ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	58                              ; DW_AT_call_line
	.byte	11                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	4                               ; Abbrev [4] 0x89:0x17 DW_TAG_inlined_subroutine
	.long	47                              ; DW_AT_abstract_origin
	.byte	5                               ; DW_AT_low_pc
	.long	.Ltmp13-.Ltmp8                  ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	188                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0x96:0x9 DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	0                               ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	65                              ; DW_AT_call_line
	.byte	11                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	4                               ; Abbrev [4] 0xa0:0x1b DW_TAG_inlined_subroutine
	.long	49                              ; DW_AT_abstract_origin
	.byte	6                               ; DW_AT_low_pc
	.long	.Ltmp17-.Ltmp14                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	189                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0xad:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	7                               ; DW_AT_low_pc
	.long	.Ltmp16-.Ltmp15                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	72                              ; DW_AT_call_line
	.byte	11                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	4                               ; Abbrev [4] 0xbb:0x1b DW_TAG_inlined_subroutine
	.long	51                              ; DW_AT_abstract_origin
	.byte	8                               ; DW_AT_low_pc
	.long	.Ltmp21-.Ltmp18                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	190                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0xc8:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	9                               ; DW_AT_low_pc
	.long	.Ltmp20-.Ltmp19                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	80                              ; DW_AT_call_line
	.byte	11                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	4                               ; Abbrev [4] 0xd6:0x1b DW_TAG_inlined_subroutine
	.long	53                              ; DW_AT_abstract_origin
	.byte	10                              ; DW_AT_low_pc
	.long	.Ltmp25-.Ltmp22                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	191                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0xe3:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	11                              ; DW_AT_low_pc
	.long	.Ltmp24-.Ltmp23                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	87                              ; DW_AT_call_line
	.byte	11                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	4                               ; Abbrev [4] 0xf1:0x1b DW_TAG_inlined_subroutine
	.long	55                              ; DW_AT_abstract_origin
	.byte	12                              ; DW_AT_low_pc
	.long	.Ltmp29-.Ltmp26                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	192                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0xfe:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	13                              ; DW_AT_low_pc
	.long	.Ltmp28-.Ltmp27                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	95                              ; DW_AT_call_line
	.byte	11                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0x10c:0xd DW_TAG_inlined_subroutine
	.long	57                              ; DW_AT_abstract_origin
	.byte	14                              ; DW_AT_low_pc
	.long	.Ltmp31-.Ltmp30                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	193                             ; DW_AT_call_line
	.byte	3                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x119:0xd DW_TAG_inlined_subroutine
	.long	59                              ; DW_AT_abstract_origin
	.byte	15                              ; DW_AT_low_pc
	.long	.Ltmp33-.Ltmp32                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	194                             ; DW_AT_call_line
	.byte	3                               ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0x126:0x9 DW_TAG_inlined_subroutine
	.long	61                              ; DW_AT_abstract_origin
	.byte	1                               ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	195                             ; DW_AT_call_line
	.byte	3                               ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0x12f:0x9 DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	2                               ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	213                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x138:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	16                              ; DW_AT_low_pc
	.long	.Ltmp39-.Ltmp38                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	187                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x145:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	17                              ; DW_AT_low_pc
	.long	.Ltmp40-.Ltmp39                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	188                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x152:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	18                              ; DW_AT_low_pc
	.long	.Ltmp41-.Ltmp40                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	189                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x15f:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_AT_low_pc
	.long	.Ltmp42-.Ltmp41                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	190                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x16c:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	20                              ; DW_AT_low_pc
	.long	.Ltmp43-.Ltmp42                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	191                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x179:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	21                              ; DW_AT_low_pc
	.long	.Ltmp44-.Ltmp43                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	192                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x186:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	22                              ; DW_AT_low_pc
	.long	.Ltmp46-.Ltmp45                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	198                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x193:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	23                              ; DW_AT_low_pc
	.long	.Ltmp48-.Ltmp47                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	199                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1a0:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	24                              ; DW_AT_low_pc
	.long	.Ltmp50-.Ltmp49                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	200                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1ad:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	25                              ; DW_AT_low_pc
	.long	.Ltmp52-.Ltmp51                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	201                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1ba:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	26                              ; DW_AT_low_pc
	.long	.Ltmp54-.Ltmp53                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	202                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1c7:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	27                              ; DW_AT_low_pc
	.long	.Ltmp56-.Ltmp55                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	203                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1d4:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	28                              ; DW_AT_low_pc
	.long	.Ltmp58-.Ltmp57                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	204                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1e1:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	29                              ; DW_AT_low_pc
	.long	.Ltmp60-.Ltmp59                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	205                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1ee:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	30                              ; DW_AT_low_pc
	.long	.Ltmp62-.Ltmp61                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	206                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1fb:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	31                              ; DW_AT_low_pc
	.long	.Ltmp64-.Ltmp63                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	207                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x208:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	32                              ; DW_AT_low_pc
	.long	.Ltmp66-.Ltmp65                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	208                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x215:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	33                              ; DW_AT_low_pc
	.long	.Ltmp68-.Ltmp67                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	209                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x222:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	34                              ; DW_AT_low_pc
	.long	.Ltmp70-.Ltmp69                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	210                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x22f:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	35                              ; DW_AT_low_pc
	.long	.Ltmp72-.Ltmp71                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	211                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x23c:0xd DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	36                              ; DW_AT_low_pc
	.long	.Ltmp74-.Ltmp73                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	212                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
.Ldebug_info_end0:
	.section	.debug_rnglists,"",@progbits
	.long	.Ldebug_list_header_end0-.Ldebug_list_header_start0 ; Length
.Ldebug_list_header_start0:
	.short	5                               ; Version
	.byte	4                               ; Address size
	.byte	0                               ; Segment selector size
	.long	3                               ; Offset entry count
.Lrnglists_table_base0:
	.long	.Ldebug_ranges0-.Lrnglists_table_base0
	.long	.Ldebug_ranges1-.Lrnglists_table_base0
	.long	.Ldebug_ranges2-.Lrnglists_table_base0
.Ldebug_ranges0:
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp9-.Lfunc_begin0           ;   starting offset
	.uleb128 .Ltmp10-.Lfunc_begin0          ;   ending offset
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp11-.Lfunc_begin0          ;   starting offset
	.uleb128 .Ltmp12-.Lfunc_begin0          ;   ending offset
	.byte	0                               ; DW_RLE_end_of_list
.Ldebug_ranges1:
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp34-.Lfunc_begin0          ;   starting offset
	.uleb128 .Ltmp35-.Lfunc_begin0          ;   ending offset
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp36-.Lfunc_begin0          ;   starting offset
	.uleb128 .Ltmp37-.Lfunc_begin0          ;   ending offset
	.byte	0                               ; DW_RLE_end_of_list
.Ldebug_ranges2:
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp35-.Lfunc_begin0          ;   starting offset
	.uleb128 .Ltmp36-.Lfunc_begin0          ;   ending offset
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp75-.Lfunc_begin0          ;   starting offset
	.uleb128 .Ltmp76-.Lfunc_begin0          ;   ending offset
	.byte	0                               ; DW_RLE_end_of_list
.Ldebug_list_header_end0:
	.section	.debug_str_offsets,"",@progbits
	.long	68                              ; Length of String Offsets Set
	.short	5
	.short	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)" ; string offset=0 ; clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)
.Linfo_string1:
	.asciz	"/home/will/llvm-mos-65816/.scratch/far-word-policy/source/farblit.c" ; string offset=108 ; /home/will/llvm-mos-65816/.scratch/far-word-policy/source/farblit.c
.Linfo_string2:
	.asciz	"/home/will/llvm-mos-65816"     ; string offset=176 ; /home/will/llvm-mos-65816
.Linfo_string3:
	.asciz	"rd8"                           ; string offset=202 ; rd8
.Linfo_string4:
	.asciz	"run"                           ; string offset=206 ; run
.Linfo_string5:
	.asciz	"fold"                          ; string offset=210 ; fold
.Linfo_string6:
	.asciz	"rdg"                           ; string offset=215 ; rdg
.Linfo_string7:
	.asciz	"rd16"                          ; string offset=219 ; rd16
.Linfo_string8:
	.asciz	"rdw"                           ; string offset=224 ; rdw
.Linfo_string9:
	.asciz	"rdw16"                         ; string offset=228 ; rdw16
.Linfo_string10:
	.asciz	"rdw16g"                        ; string offset=234 ; rdw16g
.Linfo_string11:
	.asciz	"rdw8"                          ; string offset=241 ; rdw8
.Linfo_string12:
	.asciz	"wr8"                           ; string offset=246 ; wr8
.Linfo_string13:
	.asciz	"wr16"                          ; string offset=250 ; wr16
.Linfo_string14:
	.asciz	"cp8"                           ; string offset=255 ; cp8
.Linfo_string15:
	.asciz	"main"                          ; string offset=259 ; main
	.section	.debug_str_offsets,"",@progbits
	.long	.Linfo_string0
	.long	.Linfo_string1
	.long	.Linfo_string2
	.long	.Linfo_string3
	.long	.Linfo_string4
	.long	.Linfo_string5
	.long	.Linfo_string6
	.long	.Linfo_string7
	.long	.Linfo_string8
	.long	.Linfo_string9
	.long	.Linfo_string10
	.long	.Linfo_string11
	.long	.Linfo_string12
	.long	.Linfo_string13
	.long	.Linfo_string14
	.long	.Linfo_string15
	.section	.debug_addr,"",@progbits
	.long	.Ldebug_addr_end0-.Ldebug_addr_start0 ; Length of contribution
.Ldebug_addr_start0:
	.short	5                               ; DWARF version number
	.byte	4                               ; Address size
	.byte	0                               ; Segment selector size
.Laddr_table_base0:
	.long	.Lfunc_begin0
	.long	.Ltmp0
	.long	.Ltmp1
	.long	.Ltmp4
	.long	.Ltmp5
	.long	.Ltmp8
	.long	.Ltmp14
	.long	.Ltmp15
	.long	.Ltmp18
	.long	.Ltmp19
	.long	.Ltmp22
	.long	.Ltmp23
	.long	.Ltmp26
	.long	.Ltmp27
	.long	.Ltmp30
	.long	.Ltmp32
	.long	.Ltmp38
	.long	.Ltmp39
	.long	.Ltmp40
	.long	.Ltmp41
	.long	.Ltmp42
	.long	.Ltmp43
	.long	.Ltmp45
	.long	.Ltmp47
	.long	.Ltmp49
	.long	.Ltmp51
	.long	.Ltmp53
	.long	.Ltmp55
	.long	.Ltmp57
	.long	.Ltmp59
	.long	.Ltmp61
	.long	.Ltmp63
	.long	.Ltmp65
	.long	.Ltmp67
	.long	.Ltmp69
	.long	.Ltmp71
	.long	.Ltmp73
.Ldebug_addr_end0:
	.ident	"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym rbase8
	.addrsig_sym rbase16
	.addrsig_sym rbasew
	.addrsig_sym wbase8
	.addrsig_sym wbase16
	.addrsig_sym wbasec
	.addrsig_sym rbasew16
	.addrsig_sym obase
	.addrsig_sym k8
	.addrsig_sym corpus_result
	;Declaring this symbol tells the CRT that there is something in .bss, so it may need to be zeroed.
	.globl	__do_zero_bss
	;Declaring this symbol tells the CRT that there is something in .data, so it may need to be copied from LMA to VMA.
	.globl	__do_copy_data
	;Declaring this symbol tells the CRT that the stack pointer needs to be initialized.
	.globl	__do_init_stack
	.section	.debug_line,"",@progbits
.Lline_table_start0:
