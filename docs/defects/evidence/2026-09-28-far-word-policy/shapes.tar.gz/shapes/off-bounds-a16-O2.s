	.zeropage	__rc0
	.zeropage	__rc1
	.zeropage	__rc2
	.zeropage	__rc3
	.zeropage	__rc4
	.zeropage	__rc5
	.zeropage	__rc6
	.zeropage	__rc7
	.zeropage	__rc8
	.zeropage	__rc9
	.zeropage	__rc10
	.zeropage	__rc11
	.zeropage	__rc12
	.zeropage	__rc13
	.zeropage	__rc14
	.zeropage	__rc15
	.zeropage	__rc16
	.zeropage	__rc17
	.zeropage	__rc18
	.zeropage	__rc19
	.zeropage	__rc20
	.zeropage	__rc21
	.zeropage	__rc22
	.zeropage	__rc23
	.zeropage	__rc24
	.zeropage	__rc25
	.zeropage	__rc26
	.zeropage	__rc27
	.zeropage	__rc28
	.zeropage	__rc29
	.zeropage	__rc30
	.zeropage	__rc31
	.file	"bounds.c"
	.section	.text.word128,"ax",@progbits
	.globl	word128                         ; -- Begin function word128
	.type	word128,@function
word128:                                ; @word128
.Lfunc_begin0:
	.file	0 "/home/will/llvm-mos-65816" "/home/will/llvm-mos-65816/.scratch/far-word-policy/source/bounds.c" md5 0x3e2ce56bd1f182c07574ad0001746fae
; %bb.0:
	.file	1 ".scratch/far-word-policy/source" "bounds.c" md5 0x3e2ce56bd1f182c07574ad0001746fae
	.loc	1 42 3 prologue_end             ; .scratch/far-word-policy/source/bounds.c:42:3
	ldx	rbase
	stx	__rc2
	ldx	rbase+1
	stx	__rc3
	ldx	rbase+2
	stx	__rc4
	ldx	rbase+3
	stx	__rc5
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc2
	tay
	lda	#mos24segmenthi(tbl)
	adc	__rc3
	sta	__rc8
	lda	#mos24bank(tbl)
	adc	__rc4
	sta	__rc9
	lda	#0
	adc	__rc5
	sta	__rc10
	ldx	#0
	stz	__rc2
	txa
.LBB0_1:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 0 3 is_stmt 0                 ; .scratch/far-word-policy/source/bounds.c:0:3
	sta	__rc11
	.loc	1 43 50                         ; .scratch/far-word-policy/source/bounds.c:43:50
	txa
	asl
	sta	__rc3
	lda	#0
	rol
	sta	__rc5
	stz	__rc6
	rol	__rc6
	stz	__rc7
	rol	__rc7
	tya
	.loc	1 42 3 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:42:3
	clc
	.loc	1 43 50 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:43:50
	adc	__rc3
	sta	__rc4
	lda	__rc8
	adc	__rc5
	sta	__rc5
	lda	__rc9
	adc	__rc6
	sta	__rc6
	lda	__rc10
	adc	__rc7
	sta	__rc7
	rep	#32
	lda	[__rc4]
	sta	__rc4
	sep	#32
	lda	__rc11
.Ltmp0:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:43:41 ]
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	sta	__rc3
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:43:41 ]
	lda	__rc4
	eor	__rc2
	sta	__rc4
	sep	#32
.Ltmp1:
	.loc	1 43 32 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:43:32
	inx
	lda	__rc4
	sta	__rc2
	lda	__rc5
	cpx	#128
	beq	.LBB0_2
; %bb.3:                                ;   in Loop: Header=BB0_1 Depth=1
	.loc	1 0 32 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:0:32
	jmp	.LBB0_1
.LBB0_2:
	.loc	1 44 3 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:44:3
	ldx	__rc5
	lda	__rc4
	rts
.Ltmp2:
.Lfunc_end0:
	.size	word128, .Lfunc_end0-word128
                                        ; -- End function
	.section	.text.word129,"ax",@progbits
	.globl	word129                         ; -- Begin function word129
	.type	word129,@function
word129:                                ; @word129
.Lfunc_begin1:
; %bb.0:
	.loc	1 48 3 prologue_end             ; .scratch/far-word-policy/source/bounds.c:48:3
	ldx	rbase
	stx	__rc2
	ldx	rbase+1
	stx	__rc3
	ldx	rbase+2
	stx	__rc4
	ldx	rbase+3
	stx	__rc5
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc2
	tay
	lda	#mos24segmenthi(tbl)
	adc	__rc3
	sta	__rc8
	lda	#mos24bank(tbl)
	adc	__rc4
	sta	__rc9
	lda	#0
	adc	__rc5
	sta	__rc10
	ldx	#0
	stz	__rc2
	txa
.LBB1_1:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 0 3 is_stmt 0                 ; .scratch/far-word-policy/source/bounds.c:0:3
	sta	__rc11
	.loc	1 49 50                         ; .scratch/far-word-policy/source/bounds.c:49:50
	txa
	asl
	sta	__rc3
	lda	#0
	rol
	sta	__rc5
	stz	__rc6
	rol	__rc6
	stz	__rc7
	rol	__rc7
	tya
	.loc	1 48 3 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:48:3
	clc
	.loc	1 49 50 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:49:50
	adc	__rc3
	sta	__rc4
	lda	__rc8
	adc	__rc5
	sta	__rc5
	lda	__rc9
	adc	__rc6
	sta	__rc6
	lda	__rc10
	adc	__rc7
	sta	__rc7
	rep	#32
	lda	[__rc4]
	sta	__rc4
	sep	#32
	lda	__rc11
.Ltmp3:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:49:41 ]
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	sta	__rc3
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:49:41 ]
	lda	__rc4
	eor	__rc2
	sta	__rc4
	sep	#32
.Ltmp4:
	.loc	1 49 32 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:49:32
	inx
	lda	__rc4
	sta	__rc2
	lda	__rc5
	cpx	#129
	beq	.LBB1_2
; %bb.3:                                ;   in Loop: Header=BB1_1 Depth=1
	.loc	1 0 32 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:0:32
	jmp	.LBB1_1
.LBB1_2:
	.loc	1 50 3 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:50:3
	ldx	__rc5
	lda	__rc4
	rts
.Ltmp5:
.Lfunc_end1:
	.size	word129, .Lfunc_end1-word129
                                        ; -- End function
	.section	.text.word_wrap,"ax",@progbits
	.globl	word_wrap                       ; -- Begin function word_wrap
	.type	word_wrap,@function
word_wrap:                              ; @word_wrap
.Lfunc_begin2:
; %bb.0:
	.loc	1 54 3 prologue_end             ; .scratch/far-word-policy/source/bounds.c:54:3
	ldx	rbase
	stx	__rc2
	ldx	rbase+1
	stx	__rc3
	ldx	rbase+2
	stx	__rc4
	ldx	rbase+3
	stx	__rc5
	clc
	lda	#mos24segmentlo(tbl)
	adc	__rc2
	sta	__rc12
	lda	#mos24segmenthi(tbl)
	adc	__rc3
	tax
	lda	#mos24bank(tbl)
	adc	__rc4
	sta	__rc13
	lda	#0
	adc	__rc5
	sta	__rc14
	.loc	1 55 21 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:55:21
	clc
	lda	__rc12
	adc	#246
	sta	__rc4
	txa
	adc	#1
	sta	__rc5
	lda	__rc13
	adc	#0
	sta	__rc6
	lda	__rc14
	adc	#0
	sta	__rc7
	clc
	lda	__rc12
	adc	#244
	sta	__rc2
	txa
	adc	#1
	sta	__rc15
	lda	__rc13
	adc	#0
	sta	__rc3
	lda	__rc14
	adc	#0
	sta	__rc19
	ldy	__rc2
	sty	__rc8
	lda	__rc15
	sta	__rc9
	lda	__rc3
	sta	__rc10
	sta	__rc18
	lda	__rc19
	sta	__rc11
	lda	[__rc8]
	sta	__rc8
	iny
	bne	.LBB2_6
; %bb.1:
	inc	__rc15
	bne	.LBB2_5
; %bb.2:
	inc	__rc18
	bne	.LBB2_4
; %bb.3:
	inc	__rc19
.LBB2_4:
.LBB2_5:
.LBB2_6:
	.loc	1 0 21                          ; .scratch/far-word-policy/source/bounds.c:0:21
	rep	#32
	.loc	1 55 21                         ; .scratch/far-word-policy/source/bounds.c:55:21
	lda	[__rc4]
	sta	__rc2
	sep	#32
	sty	__rc4
	ldy	__rc15
	sty	__rc5
	ldy	__rc18
	sty	__rc6
	ldy	__rc19
	sty	__rc7
	lda	[__rc4]
.Ltmp6:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	cmp	#128
	ldy	__rc8
	sty	__rc4
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	sta	__rc5
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc2
	eor	__rc4
	sta	__rc2
.Ltmp7:
	.loc	1 55 21                         ; .scratch/far-word-policy/source/bounds.c:55:21
	clc
	sep	#32
	lda	__rc12
	adc	#248
	sta	__rc4
	txa
	adc	#1
	sta	__rc5
	lda	__rc13
	adc	#0
	sta	__rc6
	lda	__rc14
	adc	#0
	sta	__rc7
	rep	#32
	lda	[__rc4]
	sta	__rc4
	sep	#32
.Ltmp8:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc3
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	sta	__rc3
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc4
	eor	__rc2
	sta	__rc4
.Ltmp9:
	.loc	1 55 21                         ; .scratch/far-word-policy/source/bounds.c:55:21
	clc
	sep	#32
	lda	__rc12
	adc	#250
	sta	__rc8
	txa
	adc	#1
	sta	__rc9
	lda	__rc13
	adc	#0
	sta	__rc10
	lda	__rc14
	adc	#0
	sta	__rc11
	rep	#32
	lda	[__rc8]
	sta	__rc2
	sep	#32
.Ltmp10:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc5
	cmp	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	sta	__rc5
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc2
	eor	__rc4
	sta	__rc4
.Ltmp11:
	.loc	1 55 21                         ; .scratch/far-word-policy/source/bounds.c:55:21
	clc
	sep	#32
	lda	__rc12
	adc	#252
	sta	__rc8
	txa
	adc	#1
	sta	__rc9
	lda	__rc13
	adc	#0
	sta	__rc10
	lda	__rc14
	adc	#0
	sta	__rc11
	rep	#32
	lda	[__rc8]
	sta	__rc2
	sep	#32
.Ltmp12:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc5
	cmp	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	sta	__rc5
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc2
	eor	__rc4
	sta	__rc4
.Ltmp13:
	.loc	1 55 21                         ; .scratch/far-word-policy/source/bounds.c:55:21
	clc
	sep	#32
	lda	__rc12
	adc	#254
	sta	__rc8
	txa
	adc	#1
	sta	__rc9
	lda	__rc13
	adc	#0
	sta	__rc10
	lda	__rc14
	adc	#0
	sta	__rc11
	rep	#32
	lda	[__rc8]
	sta	__rc2
	sep	#32
.Ltmp14:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc5
	cmp	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	sta	__rc5
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc2
	eor	__rc4
	sta	__rc8
	sep	#32
.Ltmp15:
	.loc	1 54 3 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:54:3
	ldy	__rc12
	sty	__rc4
	stx	__rc5
	ldy	__rc13
	sty	__rc6
	ldy	__rc14
	sty	__rc7
	rep	#32
	.loc	1 55 21 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:55:21
	lda	[__rc4]
	sta	__rc2
	sep	#32
.Ltmp16:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc9
	cmp	#128
	rol	__rc8
	rol
	cmp	#128
	rol	__rc8
	rol
	cmp	#128
	rol	__rc8
	rol
	sta	__rc9
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc2
	eor	__rc8
	sta	__rc8
	sep	#32
.Ltmp17:
	.loc	1 55 21                         ; .scratch/far-word-policy/source/bounds.c:55:21
	ldy	#2
	rep	#32
	lda	[__rc4],y
	sta	__rc2
	sep	#32
.Ltmp18:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc9
	cmp	#128
	rol	__rc8
	rol
	cmp	#128
	rol	__rc8
	rol
	cmp	#128
	rol	__rc8
	rol
	sta	__rc9
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc2
	eor	__rc8
	sta	__rc2
.Ltmp19:
	.loc	1 55 21                         ; .scratch/far-word-policy/source/bounds.c:55:21
	clc
	sep	#32
	lda	__rc12
	adc	#4
	sta	__rc4
	txa
	adc	#0
	sta	__rc5
	lda	__rc13
	adc	#0
	sta	__rc6
	lda	__rc14
	adc	#0
	sta	__rc7
	rep	#32
	lda	[__rc4]
	sta	__rc4
	sep	#32
.Ltmp20:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc3
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	sta	__rc3
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc4
	eor	__rc2
	sta	__rc4
.Ltmp21:
	.loc	1 55 21                         ; .scratch/far-word-policy/source/bounds.c:55:21
	clc
	sep	#32
	lda	__rc12
	adc	#6
	sta	__rc8
	txa
	adc	#0
	sta	__rc9
	lda	__rc13
	adc	#0
	sta	__rc10
	lda	__rc14
	adc	#0
	sta	__rc11
	rep	#32
	lda	[__rc8]
	sta	__rc2
	sep	#32
.Ltmp22:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc5
	cmp	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	sta	__rc5
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc2
	eor	__rc4
	sta	__rc4
.Ltmp23:
	.loc	1 55 21                         ; .scratch/far-word-policy/source/bounds.c:55:21
	clc
	sep	#32
	lda	__rc12
	adc	#8
	sta	__rc8
	txa
	adc	#0
	sta	__rc9
	lda	__rc13
	adc	#0
	sta	__rc10
	lda	__rc14
	adc	#0
	sta	__rc11
	rep	#32
	lda	[__rc8]
	sta	__rc2
	sep	#32
.Ltmp24:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc5
	cmp	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	sta	__rc5
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc2
	eor	__rc4
	sta	__rc4
	sep	#32
	lda	__rc12
	clc
.Ltmp25:
	.loc	1 55 21                         ; .scratch/far-word-policy/source/bounds.c:55:21
	adc	#10
	sta	__rc8
	txa
	adc	#0
	sta	__rc9
	lda	__rc13
	adc	#0
	sta	__rc10
	lda	__rc14
	adc	#0
	sta	__rc11
	rep	#32
	lda	[__rc8]
	sta	__rc2
	sep	#32
.Ltmp26:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc5
	cmp	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	sta	__rc5
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:55:12 ]
	lda	__rc2
	eor	__rc4
	sta	__rc2
	sep	#32
.Ltmp27:
	.loc	1 56 3 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:56:3
	ldx	__rc3
	lda	__rc2
	rts
.Ltmp28:
.Lfunc_end2:
	.size	word_wrap, .Lfunc_end2-word_wrap
                                        ; -- End function
	.section	.text.word256,"ax",@progbits
	.globl	word256                         ; -- Begin function word256
	.type	word256,@function
word256:                                ; @word256
.Lfunc_begin3:
; %bb.0:
	.loc	1 59 3 prologue_end             ; .scratch/far-word-policy/source/bounds.c:59:3
	ldx	rbase
	stx	__rc2
	ldx	rbase+1
	stx	__rc3
	ldx	rbase+2
	stx	__rc4
	ldx	rbase+3
	stx	__rc5
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc2
	tay
	lda	#mos24segmenthi(tbl)
	adc	__rc3
	sta	__rc8
	lda	#mos24bank(tbl)
	adc	__rc4
	sta	__rc9
	lda	#0
	adc	__rc5
	sta	__rc10
	stz	__rc2
	ldx	#0
	txa
.LBB3_1:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 0 3 is_stmt 0                 ; .scratch/far-word-policy/source/bounds.c:0:3
	sta	__rc11
	.loc	1 60 21                         ; .scratch/far-word-policy/source/bounds.c:60:21
	txa
	asl
	sta	__rc3
	lda	#0
	rol
	sta	__rc5
	stz	__rc6
	rol	__rc6
	stz	__rc7
	rol	__rc7
	tya
	.loc	1 59 3 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:59:3
	clc
	.loc	1 60 21 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:60:21
	adc	__rc3
	sta	__rc4
	lda	__rc8
	adc	__rc5
	sta	__rc5
	lda	__rc9
	adc	__rc6
	sta	__rc6
	lda	__rc10
	adc	__rc7
	sta	__rc7
	rep	#32
	lda	[__rc4]
	sta	__rc4
	sep	#32
	lda	__rc11
.Ltmp29:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:60:12 ]
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	sta	__rc3
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:60:12 ]
	lda	__rc4
	eor	__rc2
	sta	__rc4
	sep	#32
.Ltmp30:
	.loc	1 60 45 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:60:45
	inx
	lda	__rc4
	sta	__rc2
	lda	__rc5
	cpx	#0
	beq	.LBB3_2
; %bb.3:                                ;   in Loop: Header=BB3_1 Depth=1
	.loc	1 0 45 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:0:45
	jmp	.LBB3_1
.LBB3_2:
	.loc	1 61 3 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:61:3
	ldx	__rc5
	lda	__rc4
	rts
.Ltmp31:
.Lfunc_end3:
	.size	word256, .Lfunc_end3-word256
                                        ; -- End function
	.section	.text.word_wrapped_index,"ax",@progbits
	.globl	word_wrapped_index              ; -- Begin function word_wrapped_index
	.type	word_wrapped_index,@function
word_wrapped_index:                     ; @word_wrapped_index
.Lfunc_begin4:
; %bb.0:
	.loc	1 65 3 prologue_end             ; .scratch/far-word-policy/source/bounds.c:65:3
	ldx	rbase
	stx	__rc2
	ldx	rbase+1
	stx	__rc3
	ldx	rbase+2
	stx	__rc4
	ldx	rbase+3
	stx	__rc5
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc2
	tay
	lda	#mos24segmenthi(tbl)
	adc	__rc3
	sta	__rc8
	lda	#mos24bank(tbl)
	adc	__rc4
	sta	__rc9
	lda	#0
	adc	__rc5
	sta	__rc10
	stz	__rc2
	ldx	#248
	lda	#0
.LBB4_1:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 0 3 is_stmt 0                 ; .scratch/far-word-policy/source/bounds.c:0:3
	sta	__rc11
	.loc	1 66 49                         ; .scratch/far-word-policy/source/bounds.c:66:49
	txa
	asl
	sta	__rc3
	lda	#0
	rol
	sta	__rc5
	stz	__rc6
	rol	__rc6
	stz	__rc7
	rol	__rc7
	tya
	.loc	1 65 3 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:65:3
	clc
	.loc	1 66 49 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:66:49
	adc	__rc3
	sta	__rc4
	lda	__rc8
	adc	__rc5
	sta	__rc5
	lda	__rc9
	adc	__rc6
	sta	__rc6
	lda	__rc10
	adc	__rc7
	sta	__rc7
	rep	#32
	lda	[__rc4]
	sta	__rc4
	sep	#32
	lda	__rc11
.Ltmp32:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:66:40 ]
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	sta	__rc3
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:66:40 ]
	lda	__rc4
	eor	__rc2
	sta	__rc4
	sep	#32
.Ltmp33:
	.loc	1 66 25 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:66:25
	inx
	lda	__rc4
	sta	__rc2
	lda	__rc5
	cpx	#56
	beq	.LBB4_2
; %bb.3:                                ;   in Loop: Header=BB4_1 Depth=1
	.loc	1 0 25 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:0:25
	jmp	.LBB4_1
.LBB4_2:
	.loc	1 67 3 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:67:3
	ldx	__rc5
	lda	__rc4
	rts
.Ltmp34:
.Lfunc_end4:
	.size	word_wrapped_index, .Lfunc_end4-word_wrapped_index
                                        ; -- End function
	.section	.text.word_step2,"ax",@progbits
	.globl	word_step2                      ; -- Begin function word_step2
	.type	word_step2,@function
word_step2:                             ; @word_step2
.Lfunc_begin5:
; %bb.0:
	.loc	1 71 3 prologue_end             ; .scratch/far-word-policy/source/bounds.c:71:3
	ldx	rbase
	stx	__rc2
	ldx	rbase+1
	stx	__rc3
	ldx	rbase+2
	stx	__rc4
	ldx	rbase+3
	stx	__rc5
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc2
	tay
	lda	#mos24segmenthi(tbl)
	adc	__rc3
	sta	__rc8
	lda	#mos24bank(tbl)
	adc	__rc4
	sta	__rc9
	lda	#0
	adc	__rc5
	sta	__rc10
	ldx	#0
	stz	__rc2
	txa
.LBB5_1:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 0 3 is_stmt 0                 ; .scratch/far-word-policy/source/bounds.c:0:3
	sta	__rc11
	.loc	1 72 53                         ; .scratch/far-word-policy/source/bounds.c:72:53
	txa
	asl
	sta	__rc3
	lda	#0
	rol
	sta	__rc5
	stz	__rc6
	rol	__rc6
	stz	__rc7
	rol	__rc7
	tya
	.loc	1 71 3 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:71:3
	clc
	.loc	1 72 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:72:53
	adc	__rc3
	sta	__rc4
	lda	__rc8
	adc	__rc5
	sta	__rc5
	lda	__rc9
	adc	__rc6
	sta	__rc6
	lda	__rc10
	adc	__rc7
	sta	__rc7
	rep	#32
	lda	[__rc4]
	sta	__rc4
	sep	#32
	lda	__rc11
.Ltmp35:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:72:44 ]
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	sta	__rc3
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:72:44 ]
	lda	__rc4
	eor	__rc2
	sta	__rc4
	sep	#32
.Ltmp36:
	.loc	1 72 34 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:72:34
	inx
	inx
	lda	__rc4
	sta	__rc2
	lda	__rc5
	cpx	#64
	beq	.LBB5_2
; %bb.3:                                ;   in Loop: Header=BB5_1 Depth=1
	.loc	1 0 34 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:0:34
	jmp	.LBB5_1
.LBB5_2:
	.loc	1 73 3 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:73:3
	ldx	__rc5
	lda	__rc4
	rts
.Ltmp37:
.Lfunc_end5:
	.size	word_step2, .Lfunc_end5-word_step2
                                        ; -- End function
	.section	.text.copy248,"ax",@progbits
	.globl	copy248                         ; -- Begin function copy248
	.type	copy248,@function
copy248:                                ; @copy248
.Lfunc_begin6:
; %bb.0:
	.loc	1 76 3 prologue_end             ; .scratch/far-word-policy/source/bounds.c:76:3
	ldx	rbase
	stx	__rc2
	ldx	rbase+1
	stx	__rc3
	ldx	rbase+2
	stx	__rc6
	ldx	rbase+3
	stx	__rc7
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc2
	sta	__rc4
	lda	#mos24segmenthi(tbl)
	adc	__rc3
	sta	__rc5
	lda	#mos24bank(tbl)
	adc	__rc6
	sta	__rc6
	lda	#0
	adc	__rc7
	sta	__rc7
	.loc	1 76 14                         ; .scratch/far-word-policy/source/bounds.c:76:14
	ldx	wbase
	stx	__rc8
	ldy	wbase+1
	lda	wbase+2
	ldx	wbase+3
	sty	__rc9
	sta	__rc10
	stx	__rc11
	ldy	#0
.LBB6_1:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 77 51                         ; .scratch/far-word-policy/source/bounds.c:77:51
	tya
	clc
	adc	#8
	tyx
	tay
	lda	[__rc4],y
	txy
	.loc	1 77 37 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:77:37
	sta	[__rc8],y
	.loc	1 77 32 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:77:32
	iny
	cpy	#248
	bne	.LBB6_1
; %bb.2:
	.loc	1 78 1                          ; .scratch/far-word-policy/source/bounds.c:78:1
	rts
.Ltmp38:
.Lfunc_end6:
	.size	copy248, .Lfunc_end6-copy248
                                        ; -- End function
	.section	.text.copy249,"ax",@progbits
	.globl	copy249                         ; -- Begin function copy249
	.type	copy249,@function
copy249:                                ; @copy249
.Lfunc_begin7:
; %bb.0:
	.loc	1 80 3 prologue_end             ; .scratch/far-word-policy/source/bounds.c:80:3
	ldx	rbase
	stx	__rc2
	ldx	rbase+1
	stx	__rc3
	ldx	rbase+2
	stx	__rc4
	ldx	rbase+3
	stx	__rc5
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc2
	sta	__rc12
	lda	#mos24segmenthi(tbl)
	adc	__rc3
	sta	__rc3
	lda	#mos24bank(tbl)
	adc	__rc4
	sta	__rc13
	lda	#0
	adc	__rc5
	sta	__rc14
	.loc	1 80 14                         ; .scratch/far-word-policy/source/bounds.c:80:14
	ldx	wbase
	stx	__rc4
	ldx	wbase+1
	stx	__rc5
	ldx	wbase+2
	stx	__rc6
	ldx	wbase+3
	stx	__rc7
	ldy	#0
.LBB7_1:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 81 51 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:81:51
	sty	__rc2
	lda	__rc12
	.loc	1 80 3 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:80:3
	clc
	.loc	1 81 51                         ; .scratch/far-word-policy/source/bounds.c:81:51
	adc	__rc2
	sta	__rc2
	lda	__rc3
	adc	#0
	sta	__rc9
	lda	__rc13
	adc	#0
	tax
	lda	__rc14
	adc	#0
	sta	__rc11
	clc
	lda	__rc2
	adc	#8
	sta	__rc8
	lda	__rc9
	adc	#0
	sta	__rc9
	txa
	adc	#0
	sta	__rc10
	lda	__rc11
	adc	#0
	sta	__rc11
	lda	[__rc8]
	.loc	1 81 37 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:81:37
	sta	[__rc4],y
	.loc	1 81 32 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:81:32
	iny
	cpy	#249
	bne	.LBB7_1
; %bb.2:
	.loc	1 82 1                          ; .scratch/far-word-policy/source/bounds.c:82:1
	rts
.Ltmp39:
.Lfunc_end7:
	.size	copy249, .Lfunc_end7-copy249
                                        ; -- End function
	.section	.text.copy_wrap,"ax",@progbits
	.globl	copy_wrap                       ; -- Begin function copy_wrap
	.type	copy_wrap,@function
copy_wrap:                              ; @copy_wrap
.Lfunc_begin8:
; %bb.0:
	.loc	1 84 3 prologue_end             ; .scratch/far-word-policy/source/bounds.c:84:3
	ldx	rbase
	stx	__rc2
	ldx	rbase+1
	stx	__rc3
	ldx	rbase+2
	stx	__rc4
	ldx	rbase+3
	stx	__rc5
	clc
	lda	#mos24segmentlo(tbl)
	adc	__rc2
	sta	__rc2
	lda	#mos24segmenthi(tbl)
	adc	__rc3
	tax
	lda	#mos24bank(tbl)
	adc	__rc4
	sta	__rc3
	lda	#0
	adc	__rc5
	sta	__rc12
	.loc	1 85 22 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:85:22
	clc
	lda	__rc2
	adc	#2
	sta	__rc4
	txa
	adc	#1
	sta	__rc5
	lda	__rc3
	adc	#0
	sta	__rc6
	lda	__rc12
	adc	#0
	sta	__rc7
	.loc	1 85 8                          ; .scratch/far-word-policy/source/bounds.c:85:8
	clc
	.loc	1 84 14 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:84:14
	ldy	wbase
	.loc	1 85 8 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:85:8
	tya
	sty	__rc13
	adc	#250
	sta	__rc8
	.loc	1 84 14 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:84:14
	ldy	wbase+1
	.loc	1 85 8 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:85:8
	tya
	sty	__rc14
	adc	#0
	sta	__rc9
	.loc	1 84 14 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:84:14
	ldy	wbase+2
	.loc	1 85 8 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:85:8
	tya
	sty	__rc15
	adc	#0
	sta	__rc10
	.loc	1 84 14 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:84:14
	ldy	wbase+3
	.loc	1 85 8                          ; .scratch/far-word-policy/source/bounds.c:85:8
	tya
	sty	__rc18
	adc	#0
	sta	__rc11
	.loc	1 85 22 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:85:22
	lda	[__rc4]
	.loc	1 85 8                          ; .scratch/far-word-policy/source/bounds.c:85:8
	sta	[__rc8]
	.loc	1 85 22                         ; .scratch/far-word-policy/source/bounds.c:85:22
	clc
	lda	__rc2
	adc	#3
	sta	__rc4
	txa
	adc	#1
	sta	__rc5
	lda	__rc3
	adc	#0
	sta	__rc6
	lda	__rc12
	adc	#0
	sta	__rc7
	.loc	1 85 8                          ; .scratch/far-word-policy/source/bounds.c:85:8
	clc
	lda	__rc13
	adc	#251
	sta	__rc8
	lda	__rc14
	adc	#0
	sta	__rc9
	lda	__rc15
	adc	#0
	sta	__rc10
	tya
	adc	#0
	sta	__rc11
	.loc	1 85 22 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:85:22
	lda	[__rc4]
	.loc	1 85 8 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:85:8
	sta	[__rc8]
	.loc	1 85 22                         ; .scratch/far-word-policy/source/bounds.c:85:22
	clc
	lda	__rc2
	adc	#4
	sta	__rc4
	txa
	adc	#1
	sta	__rc5
	lda	__rc3
	adc	#0
	sta	__rc6
	lda	__rc12
	adc	#0
	sta	__rc7
	.loc	1 85 8                          ; .scratch/far-word-policy/source/bounds.c:85:8
	clc
	lda	__rc13
	adc	#252
	sta	__rc8
	lda	__rc14
	adc	#0
	sta	__rc9
	lda	__rc15
	adc	#0
	sta	__rc10
	tya
	adc	#0
	sta	__rc11
	.loc	1 85 22 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:85:22
	lda	[__rc4]
	.loc	1 85 8 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:85:8
	sta	[__rc8]
	.loc	1 85 22                         ; .scratch/far-word-policy/source/bounds.c:85:22
	clc
	lda	__rc2
	adc	#5
	sta	__rc4
	txa
	adc	#1
	sta	__rc5
	lda	__rc3
	adc	#0
	sta	__rc6
	lda	__rc12
	adc	#0
	sta	__rc7
	.loc	1 85 8                          ; .scratch/far-word-policy/source/bounds.c:85:8
	clc
	lda	__rc13
	adc	#253
	sta	__rc8
	lda	__rc14
	adc	#0
	sta	__rc9
	lda	__rc15
	adc	#0
	sta	__rc10
	tya
	adc	#0
	sta	__rc11
	.loc	1 85 22 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:85:22
	lda	[__rc4]
	.loc	1 85 8 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:85:8
	sta	[__rc8]
	.loc	1 85 22                         ; .scratch/far-word-policy/source/bounds.c:85:22
	clc
	lda	__rc2
	adc	#6
	sta	__rc4
	txa
	adc	#1
	sta	__rc5
	lda	__rc3
	adc	#0
	sta	__rc6
	lda	__rc12
	adc	#0
	sta	__rc7
	.loc	1 85 8                          ; .scratch/far-word-policy/source/bounds.c:85:8
	clc
	lda	__rc13
	adc	#254
	sta	__rc8
	lda	__rc14
	adc	#0
	sta	__rc9
	lda	__rc15
	adc	#0
	sta	__rc10
	tya
	adc	#0
	sta	__rc11
	.loc	1 85 22 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:85:22
	lda	[__rc4]
	.loc	1 85 8 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:85:8
	sta	[__rc8]
	.loc	1 85 22                         ; .scratch/far-word-policy/source/bounds.c:85:22
	clc
	lda	__rc2
	adc	#7
	sta	__rc4
	txa
	adc	#1
	sta	__rc5
	lda	__rc3
	adc	#0
	sta	__rc6
	lda	__rc12
	adc	#0
	sta	__rc7
	.loc	1 85 8                          ; .scratch/far-word-policy/source/bounds.c:85:8
	clc
	lda	__rc13
	adc	#255
	sta	__rc8
	lda	__rc14
	adc	#0
	sta	__rc9
	lda	__rc15
	adc	#0
	sta	__rc10
	tya
	adc	#0
	sta	__rc11
	.loc	1 85 22 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:85:22
	lda	[__rc4]
	.loc	1 85 8 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:85:8
	sta	[__rc8]
	.loc	1 85 22                         ; .scratch/far-word-policy/source/bounds.c:85:22
	clc
	lda	__rc2
	adc	#8
	sta	__rc8
	txa
	adc	#0
	sta	__rc9
	lda	__rc3
	adc	#0
	sta	__rc10
	lda	__rc12
	adc	#0
	sta	__rc11
	.loc	1 84 14 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:84:14
	lda	__rc13
	sta	__rc4
	lda	__rc14
	sta	__rc5
	lda	__rc15
	sta	__rc6
	sty	__rc7
	.loc	1 85 22                         ; .scratch/far-word-policy/source/bounds.c:85:22
	lda	[__rc8]
	.loc	1 85 8 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:85:8
	sta	[__rc4]
	.loc	1 85 22                         ; .scratch/far-word-policy/source/bounds.c:85:22
	clc
	lda	__rc2
	adc	#9
	sta	__rc8
	txa
	adc	#0
	sta	__rc9
	lda	__rc3
	adc	#0
	sta	__rc10
	lda	__rc12
	adc	#0
	sta	__rc11
	ldy	#1
	.loc	1 85 22 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:85:22
	lda	[__rc8]
	.loc	1 85 8 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:85:8
	sta	[__rc4],y
	.loc	1 85 22                         ; .scratch/far-word-policy/source/bounds.c:85:22
	clc
	lda	__rc2
	adc	#10
	sta	__rc8
	txa
	adc	#0
	sta	__rc9
	lda	__rc3
	adc	#0
	sta	__rc10
	lda	__rc12
	adc	#0
	sta	__rc11
	iny
	.loc	1 85 22 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:85:22
	lda	[__rc8]
	.loc	1 85 8 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:85:8
	sta	[__rc4],y
	.loc	1 85 22                         ; .scratch/far-word-policy/source/bounds.c:85:22
	clc
	lda	__rc2
	adc	#11
	sta	__rc8
	txa
	adc	#0
	sta	__rc9
	lda	__rc3
	adc	#0
	sta	__rc10
	lda	__rc12
	adc	#0
	sta	__rc11
	iny
	.loc	1 85 22 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:85:22
	lda	[__rc8]
	.loc	1 85 8 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:85:8
	sta	[__rc4],y
	.loc	1 85 22                         ; .scratch/far-word-policy/source/bounds.c:85:22
	clc
	lda	__rc2
	adc	#12
	sta	__rc4
	txa
	adc	#0
	sta	__rc5
	lda	__rc3
	adc	#0
	sta	__rc6
	lda	__rc12
	adc	#0
	sta	__rc7
	.loc	1 85 8                          ; .scratch/far-word-policy/source/bounds.c:85:8
	clc
	lda	__rc13
	adc	#4
	sta	__rc8
	lda	__rc14
	adc	#0
	sta	__rc9
	lda	__rc15
	adc	#0
	sta	__rc10
	lda	__rc18
	adc	#0
	sta	__rc11
	.loc	1 85 22 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:85:22
	lda	[__rc4]
	.loc	1 85 8 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:85:8
	sta	[__rc8]
	.loc	1 85 22                         ; .scratch/far-word-policy/source/bounds.c:85:22
	clc
	lda	__rc2
	adc	#13
	sta	__rc4
	txa
	adc	#0
	sta	__rc5
	lda	__rc3
	adc	#0
	sta	__rc6
	lda	__rc12
	adc	#0
	sta	__rc7
	clc
	lda	__rc13
	.loc	1 85 8                          ; .scratch/far-word-policy/source/bounds.c:85:8
	adc	#5
	sta	__rc8
	lda	__rc14
	adc	#0
	sta	__rc9
	lda	__rc15
	adc	#0
	sta	__rc10
	lda	__rc18
	adc	#0
	sta	__rc11
	.loc	1 85 22 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:85:22
	lda	[__rc4]
	.loc	1 85 8 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:85:8
	sta	[__rc8]
	.loc	1 86 1 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:86:1
	rts
.Ltmp40:
.Lfunc_end8:
	.size	copy_wrap, .Lfunc_end8-copy_wrap
                                        ; -- End function
	.section	.text.copy_wrapped_index,"ax",@progbits
	.globl	copy_wrapped_index              ; -- Begin function copy_wrapped_index
	.type	copy_wrapped_index,@function
copy_wrapped_index:                     ; @copy_wrapped_index
.Lfunc_begin9:
; %bb.0:
	.loc	1 88 3 prologue_end             ; .scratch/far-word-policy/source/bounds.c:88:3
	ldx	rbase
	stx	__rc2
	ldx	rbase+1
	stx	__rc3
	ldx	rbase+2
	stx	__rc6
	ldx	rbase+3
	stx	__rc7
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc2
	sta	__rc4
	lda	#mos24segmenthi(tbl)
	adc	__rc3
	sta	__rc5
	lda	#mos24bank(tbl)
	adc	__rc6
	sta	__rc6
	lda	#0
	adc	__rc7
	sta	__rc7
	.loc	1 88 14                         ; .scratch/far-word-policy/source/bounds.c:88:14
	ldx	wbase
	stx	__rc8
	ldy	wbase+1
	lda	wbase+2
	ldx	wbase+3
	sty	__rc9
	sta	__rc10
	stx	__rc11
	ldy	#0
.LBB9_1:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 89 50                         ; .scratch/far-word-policy/source/bounds.c:89:50
	tya
	clc
	adc	#248
	tyx
	tay
	lda	[__rc4],y
	txy
	.loc	1 89 36 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:89:36
	sta	[__rc8],y
	.loc	1 89 31 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:89:31
	iny
	cpy	#64
	bne	.LBB9_1
; %bb.2:
	.loc	1 90 1                          ; .scratch/far-word-policy/source/bounds.c:90:1
	rts
.Ltmp41:
.Lfunc_end9:
	.size	copy_wrapped_index, .Lfunc_end9-copy_wrapped_index
                                        ; -- End function
	.section	.text.bump,"ax",@progbits
	.globl	bump                            ; -- Begin function bump
	.type	bump,@function
bump:                                   ; @bump
.Lfunc_begin10:
	.loc	1 91 0                          ; .scratch/far-word-policy/source/bounds.c:91:0
; %bb.0:
	sta	__rc2
	stx	__rc3
	rep	#32
.Ltmp42:
	.loc	1 91 58 prologue_end            ; .scratch/far-word-policy/source/bounds.c:91:58
	lda	__rc2
	asl
	asl
	clc
	adc	__rc2
	clc
	.loc	1 91 63 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:91:63
	adc	#mos16(7)
	sta	__rc2
	sep	#32
	.loc	1 91 38                         ; .scratch/far-word-policy/source/bounds.c:91:38
	ldx	__rc3
	lda	__rc2
	rts
.Ltmp43:
.Lfunc_end10:
	.size	bump, .Lfunc_end10-bump
                                        ; -- End function
	.section	.text.word_pressure,"ax",@progbits
	.globl	word_pressure                   ; -- Begin function word_pressure
	.type	word_pressure,@function
word_pressure:                          ; @word_pressure
.Lfunc_begin11:
	.loc	1 92 0 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:92:0
; %bb.0:
	ldx	__rc20
	phx
	ldx	__rc21
	phx
	ldx	__rc22
	phx
	ldx	__rc23
	phx
	ldx	__rc24
	stx	.Lword_pressure_sstk+11         ; 1-byte Folded Spill
	ldx	__rc25
	stx	.Lword_pressure_sstk+12         ; 1-byte Folded Spill
	ldx	__rc26
	stx	.Lword_pressure_sstk+13         ; 1-byte Folded Spill
	ldx	__rc27
	stx	.Lword_pressure_sstk+14         ; 1-byte Folded Spill
	ldx	__rc28
	stx	.Lword_pressure_sstk+15         ; 1-byte Folded Spill
	ldx	__rc29
	stx	.Lword_pressure_sstk+16         ; 1-byte Folded Spill
	ldx	__rc30
	stx	.Lword_pressure_sstk+17         ; 1-byte Folded Spill
	ldx	__rc31
	stx	.Lword_pressure_sstk+18         ; 1-byte Folded Spill
.Ltmp44:
	.loc	1 93 3 prologue_end             ; .scratch/far-word-policy/source/bounds.c:93:3
	ldx	rbase
	stx	__rc2
	ldx	rbase+1
	stx	__rc3
	ldx	rbase+2
	stx	__rc4
	ldx	rbase+3
	stx	__rc5
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc2
	sta	.Lword_pressure_sstk+7          ; 1-byte Folded Spill
	lda	#mos24segmenthi(tbl)
	adc	__rc3
	sta	.Lword_pressure_sstk+8          ; 1-byte Folded Spill
	lda	#mos24bank(tbl)
	adc	__rc4
	sta	.Lword_pressure_sstk+9          ; 1-byte Folded Spill
	lda	#0
	adc	__rc5
	sta	.Lword_pressure_sstk+10         ; 1-byte Folded Spill
	ldx	#1
	stx	__rc3
	stz	__rc9
	dex
	ldy	#2
	sty	__rc31
	lda	#4
	sta	__rc29
	inc
	sta	__rc27
	ldy	#6
	sty	.Lword_pressure_sstk+5          ; 1-byte Folded Spill
	iny
	sty	.Lword_pressure_sstk+3          ; 1-byte Folded Spill
	lda	#8
	ldy	#3
	sty	__rc22
	txy
	sty	.Lword_pressure_sstk+2          ; 1-byte Folded Spill
	sty	.Lword_pressure_sstk+4          ; 1-byte Folded Spill
	sty	.Lword_pressure_sstk+6          ; 1-byte Folded Spill
	stz	__rc28
	stz	__rc30
	stz	__rc23
	stz	__rc26
.LBB11_1:                               ; =>This Inner Loop Header: Depth=1
	.loc	1 0 3 is_stmt 0                 ; .scratch/far-word-policy/source/bounds.c:0:3
	stx	__rc20
	.loc	1 96 7 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:96:7
	ldx	__rc9
	sta	__rc24
	lda	__rc3
	jsr	bump
.Ltmp45:
	.loc	1 96 7                          ; .scratch/far-word-policy/source/bounds.c:96:7
	sta	__rc3
	stx	__rc5
                                        ; kill: def $rs2 killed $rs2
	ldx	__rc4
	stx	.Lword_pressure_sstk            ; 1-byte Folded Spill
	ldx	__rc5
	stx	.Lword_pressure_sstk+1          ; 1-byte Folded Spill
	ldx	__rc20
	.loc	1 96 27 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:96:27
	lda	__rc20
	stz	__rc2
	asl
	rol	__rc2
	stz	__rc6
	rol	__rc6
	stz	__rc7
	rol	__rc7
	sta	__rc4
	lda	.Lword_pressure_sstk+7          ; 1-byte Folded Reload
	.loc	1 93 3 is_stmt 1                ; .scratch/far-word-policy/source/bounds.c:93:3
	clc
	.loc	1 96 27                         ; .scratch/far-word-policy/source/bounds.c:96:27
	adc	__rc4
	sta	__rc4
	lda	.Lword_pressure_sstk+8          ; 1-byte Folded Reload
	adc	__rc2
	sta	__rc5
	lda	.Lword_pressure_sstk+9          ; 1-byte Folded Reload
	adc	__rc6
	sta	__rc6
	lda	.Lword_pressure_sstk+10         ; 1-byte Folded Reload
	adc	__rc7
	sta	__rc7
	rep	#32
	lda	[__rc4]
	sta	__rc4
	sep	#32
	lda	__rc26
.Ltmp46:
	.loc	1 35 40                         ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:97:7 ]
	cmp	#128
	rol	__rc31
	rol
	cmp	#128
	rol	__rc31
	rol
	cmp	#128
	rol	__rc31
	ldy	__rc31
	sty	__rc6
	rol
	sta	__rc7
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:97:7 ]
	lda	__rc4
	eor	__rc6
	sta	__rc4
	sep	#32
	lda	__rc23
.Ltmp47:
	.loc	1 35 40                         ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:97:21 ]
	cmp	#128
	rol	__rc22
	rol
	cmp	#128
	rol	__rc22
	rol
	cmp	#128
	rol	__rc22
	ldy	__rc22
	sty	__rc6
	rol
	sta	__rc7
	rep	#32
	.loc	1 35 53                         ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:97:21 ]
	lda	__rc4
	eor	__rc6
	sta	__rc8
	sep	#32
	lda	__rc30
.Ltmp48:
	.loc	1 35 40                         ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:97:35 ]
	cmp	#128
	rol	__rc29
	rol
	cmp	#128
	rol	__rc29
	rol
	cmp	#128
	rol	__rc29
	ldy	__rc29
	sty	__rc10
	rol
	sta	__rc11
	rep	#32
	.loc	1 35 53                         ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:97:35 ]
	lda	__rc8
	eor	__rc10
	sta	__rc10
	sep	#32
	lda	__rc28
.Ltmp49:
	.loc	1 35 40                         ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:97:49 ]
	cmp	#128
	rol	__rc27
	rol
	cmp	#128
	rol	__rc27
	rol
	cmp	#128
	rol	__rc27
	ldy	__rc27
	sty	__rc12
	rol
	sta	__rc13
	rep	#32
	.loc	1 35 53                         ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:97:49 ]
	lda	__rc10
	eor	__rc12
	sta	__rc14
	sep	#32
	lda	.Lword_pressure_sstk+6          ; 1-byte Folded Reload
.Ltmp50:
	.loc	1 35 40                         ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:98:7 ]
	cmp	#128
	ldy	.Lword_pressure_sstk+5          ; 1-byte Folded Reload
	sty	__rc18
	rol	__rc18
	rol
	cmp	#128
	rol	__rc18
	rol
	cmp	#128
	rol	__rc18
	rol
	sta	__rc19
	rep	#32
	.loc	1 35 53                         ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:98:7 ]
	lda	__rc14
	eor	__rc18
	sta	__rc18
	sep	#32
	lda	.Lword_pressure_sstk+4          ; 1-byte Folded Reload
.Ltmp51:
	.loc	1 35 40                         ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:98:21 ]
	cmp	#128
	ldy	.Lword_pressure_sstk+3          ; 1-byte Folded Reload
	sty	__rc20
	rol	__rc20
	rol
	cmp	#128
	rol	__rc20
	rol
	cmp	#128
	rol	__rc20
	rol
	sta	__rc21
	rep	#32
	.loc	1 35 53                         ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:98:21 ]
	lda	__rc18
	eor	__rc20
	sta	__rc22
	sep	#32
	lda	.Lword_pressure_sstk+2          ; 1-byte Folded Reload
.Ltmp52:
	.loc	1 35 40                         ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:98:35 ]
	cmp	#128
	rol	__rc24
	rol
	cmp	#128
	rol	__rc24
	rol
	cmp	#128
	rol	__rc24
	rol
	sta	__rc25
	rep	#32
	.loc	1 35 53                         ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:98:35 ]
	lda	__rc22
	eor	__rc24
	sta	__rc24
	sep	#32
.Ltmp53:
	.loc	1 95 27 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:95:27
	inx
	lda	__rc24
	ldy	__rc25
	sty	.Lword_pressure_sstk+2          ; 1-byte Folded Spill
	ldy	__rc22
	sty	.Lword_pressure_sstk+3          ; 1-byte Folded Spill
	ldy	__rc23
	sty	.Lword_pressure_sstk+4          ; 1-byte Folded Spill
	ldy	__rc18
	sty	.Lword_pressure_sstk+5          ; 1-byte Folded Spill
	ldy	__rc19
	sty	.Lword_pressure_sstk+6          ; 1-byte Folded Spill
	ldy	__rc14
	sty	__rc27
	ldy	__rc15
	sty	__rc28
	ldy	__rc10
	sty	__rc29
	ldy	__rc11
	sty	__rc30
	ldy	__rc8
	sty	__rc22
	ldy	__rc9
	sty	__rc23
	ldy	.Lword_pressure_sstk            ; 1-byte Folded Reload
	ldy	.Lword_pressure_sstk+1          ; 1-byte Folded Reload
	sty	__rc9
	ldy	__rc4
	sty	__rc31
	ldy	__rc5
	sty	__rc26
	cpx	#64
	beq	.LBB11_2
; %bb.3:                                ;   in Loop: Header=BB11_1 Depth=1
	.loc	1 0 27 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:0:27
	jmp	.LBB11_1
.LBB11_2:
	ldx	__rc3
	stx	__rc8
	rep	#32
	.loc	1 100 15 is_stmt 1              ; .scratch/far-word-policy/source/bounds.c:100:15
	lda	__rc6
	eor	__rc12
	.loc	1 100 19 is_stmt 0              ; .scratch/far-word-policy/source/bounds.c:100:19
	eor	__rc20
	.loc	1 100 21                        ; .scratch/far-word-policy/source/bounds.c:100:21
	eor	__rc24
	.loc	1 100 23                        ; .scratch/far-word-policy/source/bounds.c:100:23
	eor	__rc8
	sta	__rc2
	sep	#32
	.loc	1 100 3                         ; .scratch/far-word-policy/source/bounds.c:100:3
	ldx	__rc3
	lda	__rc2
	ldy	.Lword_pressure_sstk+18         ; 1-byte Folded Reload
	sty	__rc31
	ldy	.Lword_pressure_sstk+17         ; 1-byte Folded Reload
	sty	__rc30
	ldy	.Lword_pressure_sstk+16         ; 1-byte Folded Reload
	sty	__rc29
	ldy	.Lword_pressure_sstk+15         ; 1-byte Folded Reload
	sty	__rc28
	ldy	.Lword_pressure_sstk+14         ; 1-byte Folded Reload
	sty	__rc27
	ldy	.Lword_pressure_sstk+13         ; 1-byte Folded Reload
	sty	__rc26
	ldy	.Lword_pressure_sstk+12         ; 1-byte Folded Reload
	sty	__rc25
	ldy	.Lword_pressure_sstk+11         ; 1-byte Folded Reload
	sty	__rc24
	ply
	sty	__rc23
	ply
	sty	__rc22
	ply
	sty	__rc21
	ply
	sty	__rc20
	rts
.Ltmp54:
.Lfunc_end11:
	.size	word_pressure, .Lfunc_end11-word_pressure
                                        ; -- End function
	.section	.text.main,"ax",@progbits
	.globl	main                            ; -- Begin function main
	.type	main,@function
main:                                   ; @main
.Lfunc_begin12:
; %bb.0:
	.loc	1 128 0 prologue_end is_stmt 1  ; .scratch/far-word-policy/source/bounds.c:128:0
	clc
	lda	__rc0
	adc	#243
	sta	__rc0
	lda	__rc1
	adc	#255
	sta	__rc1
	stz	__rc30
	stz	__rc31
	stz	__rc22
	stz	__rc23
	ldx	#0
; %bb.18:
	jmp	.LBB12_13
.LBB12_1:                               ;   in Loop: Header=BB12_13 Depth=1
	txa
	ldy	#12
	sta	(__rc0),y                       ; 1-byte Folded Spill
	ldy	#255
	tyx
	stz	__rc3
	lda	#0
	bra	.LBB12_4
.LBB12_2:                               ;   in Loop: Header=BB12_13 Depth=1
	ldy	#128
	stz	__rc3
	lda	#0
.LBB12_3:                               ;   in Loop: Header=BB12_13 Depth=1
	ldx	__rc4
.LBB12_4:                               ;   in Loop: Header=BB12_13 Depth=1
.Ltmp55:
	.loc	1 110 11                        ; .scratch/far-word-policy/source/bounds.c:110:11 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	sty	rbase
	stx	rbase+1
	ldx	__rc3
	stx	rbase+2
	sta	rbase+3
	.loc	1 111 15                        ; .scratch/far-word-policy/source/bounds.c:111:15 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	jsr	word128
.Ltmp56:
	.loc	1 111 15                        ; .scratch/far-word-policy/source/bounds.c:111:15 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	sta	__rc26
	stx	__rc27
	.loc	1 111 37 is_stmt 0              ; .scratch/far-word-policy/source/bounds.c:111:37 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	jsr	word129
.Ltmp57:
	sta	__rc4
	stx	__rc5
                                        ; kill: def $rs2 killed $rs2
	lda	__rc4
	ldy	#0
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc5
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
	.loc	1 112 15 is_stmt 1              ; .scratch/far-word-policy/source/bounds.c:112:15 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	jsr	word_wrap
.Ltmp58:
	.loc	1 112 15                        ; .scratch/far-word-policy/source/bounds.c:112:15 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	sta	__rc4
	stx	__rc5
                                        ; kill: def $rs2 killed $rs2
	lda	__rc4
	ldy	#2
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc5
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
	.loc	1 112 39 is_stmt 0              ; .scratch/far-word-policy/source/bounds.c:112:39 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	jsr	word256
.Ltmp59:
	sta	__rc4
	stx	__rc5
                                        ; kill: def $rs2 killed $rs2
	lda	__rc4
	ldy	#4
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc5
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
	.loc	1 113 15 is_stmt 1              ; .scratch/far-word-policy/source/bounds.c:113:15 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	jsr	word_wrapped_index
.Ltmp60:
	.loc	1 113 15                        ; .scratch/far-word-policy/source/bounds.c:113:15 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	sta	__rc4
	stx	__rc5
                                        ; kill: def $rs2 killed $rs2
	lda	__rc4
	ldy	#6
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc5
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
	.loc	1 113 48 is_stmt 0              ; .scratch/far-word-policy/source/bounds.c:113:48 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	jsr	word_step2
.Ltmp61:
	sta	__rc4
	stx	__rc5
                                        ; kill: def $rs2 killed $rs2
	lda	__rc4
	ldy	#8
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc5
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
	.loc	1 114 15 is_stmt 1              ; .scratch/far-word-policy/source/bounds.c:114:15 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	jsr	word_pressure
.Ltmp62:
	sta	__rc4
	stx	__rc5
                                        ; kill: def $rs2 killed $rs2
	lda	__rc4
	ldy	#10
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc5
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
	.loc	1 115 5                         ; .scratch/far-word-policy/source/bounds.c:115:5 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	ldx	wbase
	stx	__rc4
	ldy	wbase+1
	lda	wbase+2
	ldx	wbase+3
	sty	__rc5
	sta	__rc6
	stx	__rc7
	stz	__rc20
	.loc	1 116 36                        ; .scratch/far-word-policy/source/bounds.c:116:36 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	ldx	#1
	stx	__rc2
	dex
	txa
	jsr	__memset_far
.Ltmp63:
	.loc	1 117 5                         ; .scratch/far-word-policy/source/bounds.c:117:5 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	jsr	copy248
.Ltmp64:
	.loc	1 0 5 is_stmt 0                 ; .scratch/far-word-policy/source/bounds.c:0:5
	stz	__rc2
	ldx	#0
.LBB12_5:                               ;   Parent Loop BB12_13 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
.Ltmp65:
	.loc	1 104 44                        ; .scratch/far-word-policy/source/bounds.c:104:44 @[ .scratch/far-word-policy/source/bounds.c:117:26 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	clc
	lda	__rc20
	adc	#128
	sta	__rc4
	lda	#0
	adc	#255
	sta	__rc5
	lda	#0
	adc	#126
	sta	__rc6
	lda	#0
	adc	#0
	sta	__rc7
	lda	[__rc4]
	sta	__rc4
	stz	__rc5
	txa
.Ltmp66:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:104:36 @[ .scratch/far-word-policy/source/bounds.c:117:26 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ] ]
	cpx	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	sta	__rc3
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:104:36 @[ .scratch/far-word-policy/source/bounds.c:117:26 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ] ]
	lda	__rc2
	eor	__rc4
	sta	__rc24
	sep	#32
.Ltmp67:
	.loc	1 104 23 is_stmt 1              ; .scratch/far-word-policy/source/bounds.c:104:23 @[ .scratch/far-word-policy/source/bounds.c:117:26 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	inc	__rc20
	ldx	__rc24
	stx	__rc2
	ldx	__rc25
	lda	__rc20
	beq	.LBB12_6
.Ltmp68:
; %bb.22:                               ;   in Loop: Header=BB12_5 Depth=2
	.loc	1 0 23 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:0:23
	jmp	.LBB12_5
.LBB12_6:                               ;   in Loop: Header=BB12_13 Depth=1
	.loc	1 118 5 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:118:5 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	jsr	copy249
.Ltmp69:
	.loc	1 0 5 is_stmt 0                 ; .scratch/far-word-policy/source/bounds.c:0:5
	ldx	#0
	stz	__rc2
	txy
.LBB12_7:                               ;   Parent Loop BB12_13 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
.Ltmp70:
	.loc	1 104 44                        ; .scratch/far-word-policy/source/bounds.c:104:44 @[ .scratch/far-word-policy/source/bounds.c:118:26 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	txa
	clc
	adc	#128
	sta	__rc4
	lda	#0
	adc	#255
	sta	__rc5
	lda	#0
	adc	#126
	sta	__rc6
	lda	#0
	adc	#0
	sta	__rc7
	lda	[__rc4]
	sta	__rc4
	stz	__rc5
	tya
.Ltmp71:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:104:36 @[ .scratch/far-word-policy/source/bounds.c:118:26 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ] ]
	cpy	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	sta	__rc3
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:104:36 @[ .scratch/far-word-policy/source/bounds.c:118:26 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ] ]
	lda	__rc2
	eor	__rc4
	sta	__rc20
	sep	#32
.Ltmp72:
	.loc	1 104 23 is_stmt 1              ; .scratch/far-word-policy/source/bounds.c:104:23 @[ .scratch/far-word-policy/source/bounds.c:118:26 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	inx
	ldy	__rc20
	sty	__rc2
	ldy	__rc21
	txa
	beq	.LBB12_8
.Ltmp73:
; %bb.24:                               ;   in Loop: Header=BB12_7 Depth=2
	.loc	1 0 23 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:0:23
	jmp	.LBB12_7
.LBB12_8:                               ;   in Loop: Header=BB12_13 Depth=1
	.loc	1 119 5 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:119:5 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	jsr	copy_wrap
.Ltmp74:
	.loc	1 0 5 is_stmt 0                 ; .scratch/far-word-policy/source/bounds.c:0:5
	ldx	#0
	stz	__rc2
	txy
.LBB12_9:                               ;   Parent Loop BB12_13 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
.Ltmp75:
	.loc	1 104 44                        ; .scratch/far-word-policy/source/bounds.c:104:44 @[ .scratch/far-word-policy/source/bounds.c:119:28 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	clc
	txa
	adc	#128
	sta	__rc4
	lda	#0
	adc	#255
	sta	__rc5
	lda	#0
	adc	#126
	sta	__rc6
	lda	#0
	adc	#0
	sta	__rc7
	lda	[__rc4]
	sta	__rc4
	stz	__rc5
	tya
.Ltmp76:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:104:36 @[ .scratch/far-word-policy/source/bounds.c:119:28 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ] ]
	cpy	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	cmp	#128
	rol	__rc2
	rol
	sta	__rc3
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:104:36 @[ .scratch/far-word-policy/source/bounds.c:119:28 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ] ]
	lda	__rc2
	eor	__rc4
	sta	__rc28
	sep	#32
.Ltmp77:
	.loc	1 104 23 is_stmt 1              ; .scratch/far-word-policy/source/bounds.c:104:23 @[ .scratch/far-word-policy/source/bounds.c:119:28 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	inx
	ldy	__rc28
	sty	__rc2
	ldy	__rc29
	txa
	beq	.LBB12_10
.Ltmp78:
; %bb.26:                               ;   in Loop: Header=BB12_9 Depth=2
	.loc	1 0 23 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:0:23
	jmp	.LBB12_9
.LBB12_10:                              ;   in Loop: Header=BB12_13 Depth=1
	.loc	1 120 5 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:120:5 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	jsr	copy_wrapped_index
.Ltmp79:
	.loc	1 0 5 is_stmt 0                 ; .scratch/far-word-policy/source/bounds.c:0:5
	ldx	#0
	stz	__rc4
	txy
.LBB12_11:                              ;   Parent Loop BB12_13 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
.Ltmp80:
	.loc	1 104 44                        ; .scratch/far-word-policy/source/bounds.c:104:44 @[ .scratch/far-word-policy/source/bounds.c:120:37 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	txa
	clc
	adc	#128
	sta	__rc8
	lda	#0
	adc	#255
	sta	__rc9
	lda	#0
	adc	#126
	sta	__rc10
	lda	#0
	adc	#0
	sta	__rc11
	lda	[__rc8]
	sta	__rc2
	stz	__rc3
	tya
.Ltmp81:
	.loc	1 35 40 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:35:40 @[ .scratch/far-word-policy/source/bounds.c:104:36 @[ .scratch/far-word-policy/source/bounds.c:120:37 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ] ]
	cpy	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	cmp	#128
	rol	__rc4
	rol
	sta	__rc5
	rep	#32
	.loc	1 35 53 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:35:53 @[ .scratch/far-word-policy/source/bounds.c:104:36 @[ .scratch/far-word-policy/source/bounds.c:120:37 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ] ]
	lda	__rc4
	eor	__rc2
	sta	__rc2
	sep	#32
.Ltmp82:
	.loc	1 104 23 is_stmt 1              ; .scratch/far-word-policy/source/bounds.c:104:23 @[ .scratch/far-word-policy/source/bounds.c:120:37 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	inx
	ldy	__rc2
	sty	__rc4
	ldy	__rc3
	txa
	beq	.LBB12_12
.Ltmp83:
; %bb.28:                               ;   in Loop: Header=BB12_11 Depth=2
	.loc	1 0 23 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:0:23
	jmp	.LBB12_11
.LBB12_12:                              ;   in Loop: Header=BB12_13 Depth=1
.Ltmp84:
	.loc	1 38 20 is_stmt 1               ; .scratch/far-word-policy/source/bounds.c:38:20 @[ .scratch/far-word-policy/source/bounds.c:111:7 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	lda	__rc23
	lsr
	ror	__rc22
	ror	__rc31
	ror	__rc30
	ror	__rc23
	lda	__rc23
	lsr
	ror	__rc22
	ror	__rc31
	ror	__rc30
	ror	__rc23
	lda	__rc23
	lsr
	ror	__rc22
	ror	__rc31
	ror	__rc30
	ror	__rc23
	.loc	1 38 33 is_stmt 0               ; .scratch/far-word-policy/source/bounds.c:38:33 @[ .scratch/far-word-policy/source/bounds.c:111:7 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	ldx	__rc23
	stx	__rc4
	ldx	__rc30
	stx	__rc5
	ldx	__rc31
	stx	__rc6
	ldx	__rc22
	stx	__rc7
	rep	#32
	lda	__rc4
	eor	__rc26
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp85:
	.loc	1 38 20                         ; .scratch/far-word-policy/source/bounds.c:38:20 @[ .scratch/far-word-policy/source/bounds.c:111:29 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	lda	__rc7
	lsr
	lda	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	ldx	__rc7
	stx	__rc6
	lsr	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	ldx	__rc7
	stx	__rc6
	lsr	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	.loc	1 38 33                         ; .scratch/far-word-policy/source/bounds.c:38:33 @[ .scratch/far-word-policy/source/bounds.c:111:29 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	ldx	__rc7
	stx	__rc6
	ldx	__rc4
	stx	__rc7
	ldx	__rc5
	stx	__rc4
	sta	__rc5
	rep	#32
	lda	__rc6
	sep	#32
	pha
	ldy	#0
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc6
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc7
	pla
	rep	#32
	eor	__rc6
	sta	__rc6
	lda	__rc4
	eor	#mos16(0)
	sta	__rc4
	sep	#32
.Ltmp86:
	.loc	1 38 20                         ; .scratch/far-word-policy/source/bounds.c:38:20 @[ .scratch/far-word-policy/source/bounds.c:112:7 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	lda	__rc5
	lsr
	lda	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	ldx	__rc5
	stx	__rc4
	lsr	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	ldx	__rc5
	stx	__rc4
	lsr	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	.loc	1 38 33                         ; .scratch/far-word-policy/source/bounds.c:38:33 @[ .scratch/far-word-policy/source/bounds.c:112:7 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	ldx	__rc5
	stx	__rc4
	ldx	__rc6
	stx	__rc5
	ldx	__rc7
	stx	__rc6
	sta	__rc7
	rep	#32
	lda	__rc4
	sep	#32
	pha
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc4
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc5
	pla
	rep	#32
	eor	__rc4
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp87:
	.loc	1 38 20                         ; .scratch/far-word-policy/source/bounds.c:38:20 @[ .scratch/far-word-policy/source/bounds.c:112:31 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	lda	__rc7
	lsr
	lda	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	ldx	__rc7
	stx	__rc6
	lsr	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	ldx	__rc7
	stx	__rc6
	lsr	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	.loc	1 38 33                         ; .scratch/far-word-policy/source/bounds.c:38:33 @[ .scratch/far-word-policy/source/bounds.c:112:31 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	ldx	__rc7
	stx	__rc6
	ldx	__rc4
	stx	__rc7
	ldx	__rc5
	stx	__rc4
	sta	__rc5
	rep	#32
	lda	__rc6
	sep	#32
	pha
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc6
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc7
	pla
	rep	#32
	eor	__rc6
	sta	__rc6
	lda	__rc4
	eor	#mos16(0)
	sta	__rc4
	sep	#32
.Ltmp88:
	.loc	1 38 20                         ; .scratch/far-word-policy/source/bounds.c:38:20 @[ .scratch/far-word-policy/source/bounds.c:113:7 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	lda	__rc5
	lsr
	lda	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	ldx	__rc5
	stx	__rc4
	lsr	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	ldx	__rc5
	stx	__rc4
	lsr	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	.loc	1 38 33                         ; .scratch/far-word-policy/source/bounds.c:38:33 @[ .scratch/far-word-policy/source/bounds.c:113:7 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	ldx	__rc5
	stx	__rc4
	ldx	__rc6
	stx	__rc5
	ldx	__rc7
	stx	__rc6
	sta	__rc7
	rep	#32
	lda	__rc4
	sep	#32
	pha
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc4
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc5
	pla
	rep	#32
	eor	__rc4
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp89:
	.loc	1 38 20                         ; .scratch/far-word-policy/source/bounds.c:38:20 @[ .scratch/far-word-policy/source/bounds.c:113:40 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	lda	__rc7
	lsr
	lda	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	ldx	__rc7
	stx	__rc6
	lsr	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	ldx	__rc7
	stx	__rc6
	lsr	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	.loc	1 38 33                         ; .scratch/far-word-policy/source/bounds.c:38:33 @[ .scratch/far-word-policy/source/bounds.c:113:40 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	ldx	__rc7
	stx	__rc6
	ldx	__rc4
	stx	__rc7
	ldx	__rc5
	stx	__rc4
	sta	__rc5
	rep	#32
	lda	__rc6
	sep	#32
	pha
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc6
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc7
	pla
	rep	#32
	eor	__rc6
	sta	__rc6
	lda	__rc4
	eor	#mos16(0)
	sta	__rc4
	sep	#32
.Ltmp90:
	.loc	1 38 20                         ; .scratch/far-word-policy/source/bounds.c:38:20 @[ .scratch/far-word-policy/source/bounds.c:114:7 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	lda	__rc5
	lsr
	lda	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	ldx	__rc5
	stx	__rc4
	lsr	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	ldx	__rc5
	stx	__rc4
	lsr	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	.loc	1 38 33                         ; .scratch/far-word-policy/source/bounds.c:38:33 @[ .scratch/far-word-policy/source/bounds.c:114:7 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	ldx	__rc5
	stx	__rc4
	ldx	__rc6
	stx	__rc5
	ldx	__rc7
	stx	__rc6
	sta	__rc7
	rep	#32
	lda	__rc4
	sep	#32
	pha
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc4
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc5
	pla
	rep	#32
	eor	__rc4
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp91:
	.loc	1 38 20                         ; .scratch/far-word-policy/source/bounds.c:38:20 @[ .scratch/far-word-policy/source/bounds.c:117:18 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	lda	__rc7
	lsr
	lda	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	ldx	__rc7
	stx	__rc6
	lsr	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	ldx	__rc7
	stx	__rc6
	lsr	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	.loc	1 38 33                         ; .scratch/far-word-policy/source/bounds.c:38:33 @[ .scratch/far-word-policy/source/bounds.c:117:18 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	ldx	__rc7
	stx	__rc6
	ldx	__rc4
	stx	__rc7
	ldx	__rc5
	stx	__rc4
	sta	__rc5
	rep	#32
	lda	__rc6
	eor	__rc24
	sta	__rc6
	lda	__rc4
	eor	#mos16(0)
	sta	__rc4
	sep	#32
.Ltmp92:
	.loc	1 38 20                         ; .scratch/far-word-policy/source/bounds.c:38:20 @[ .scratch/far-word-policy/source/bounds.c:118:18 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	lda	__rc5
	lsr
	lda	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	ldx	__rc5
	stx	__rc4
	lsr	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	ldx	__rc5
	stx	__rc4
	lsr	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	.loc	1 38 33                         ; .scratch/far-word-policy/source/bounds.c:38:33 @[ .scratch/far-word-policy/source/bounds.c:118:18 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	ldx	__rc5
	stx	__rc4
	ldx	__rc6
	stx	__rc5
	ldx	__rc7
	stx	__rc6
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc20
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp93:
	.loc	1 38 20                         ; .scratch/far-word-policy/source/bounds.c:38:20 @[ .scratch/far-word-policy/source/bounds.c:119:20 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	lda	__rc7
	lsr
	lda	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	ldx	__rc7
	stx	__rc6
	lsr	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	ldx	__rc7
	stx	__rc6
	lsr	__rc6
	ror
	ror	__rc5
	ror	__rc4
	ror	__rc7
	.loc	1 38 33                         ; .scratch/far-word-policy/source/bounds.c:38:33 @[ .scratch/far-word-policy/source/bounds.c:119:20 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	ldx	__rc7
	stx	__rc6
	ldx	__rc4
	stx	__rc7
	ldx	__rc5
	stx	__rc4
	sta	__rc5
	rep	#32
	lda	__rc6
	eor	__rc28
	sta	__rc6
	lda	__rc4
	eor	#mos16(0)
	sta	__rc4
	sep	#32
.Ltmp94:
	.loc	1 38 20                         ; .scratch/far-word-policy/source/bounds.c:38:20 @[ .scratch/far-word-policy/source/bounds.c:120:29 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	lda	__rc5
	lsr
	lda	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	ldx	__rc5
	stx	__rc4
	lsr	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	ldx	__rc5
	stx	__rc4
	lsr	__rc4
	ror
	ror	__rc7
	ror	__rc6
	ror	__rc5
	.loc	1 38 33                         ; .scratch/far-word-policy/source/bounds.c:38:33 @[ .scratch/far-word-policy/source/bounds.c:120:29 @[ .scratch/far-word-policy/source/bounds.c:128:32 ] ]
	ldx	__rc5
	stx	__rc4
	ldx	__rc6
	stx	__rc5
	ldx	__rc7
	stx	__rc6
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc2
	lda	__rc6
	eor	#mos16(0)
	sta	__rc4
	sep	#32
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	tax
.Ltmp95:
	.loc	1 109 26 is_stmt 1              ; .scratch/far-word-policy/source/bounds.c:109:26 @[ .scratch/far-word-policy/source/bounds.c:128:32 ]
	inx
	ldy	__rc2
	sty	__rc30
	ldy	__rc3
	sty	__rc31
	ldy	__rc4
	sty	__rc22
	ldy	__rc5
	sty	__rc23
	cpx	#3
	beq	.LBB12_16
.Ltmp96:
.LBB12_13:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB12_5 Depth 2
                                        ;     Child Loop BB12_7 Depth 2
                                        ;     Child Loop BB12_9 Depth 2
                                        ;     Child Loop BB12_11 Depth 2
	.loc	1 0 26 is_stmt 0                ; .scratch/far-word-policy/source/bounds.c:0:26
	txa
	bne	.LBB12_14
; %bb.30:                               ;   in Loop: Header=BB12_13 Depth=1
	jmp	.LBB12_1
.LBB12_14:                              ;   in Loop: Header=BB12_13 Depth=1
	ldy	#255
	sty	__rc4
	txa
	ldy	#12
	sta	(__rc0),y                       ; 1-byte Folded Spill
	cpx	#1
	beq	.LBB12_15
; %bb.32:                               ;   in Loop: Header=BB12_13 Depth=1
	jmp	.LBB12_2
.LBB12_15:                              ;   in Loop: Header=BB12_13 Depth=1
	ldx	#1
	stx	__rc3
	lda	#0
	ldy	#255
; %bb.20:                               ;   in Loop: Header=BB12_13 Depth=1
	jmp	.LBB12_3
.LBB12_16:
	.loc	1 128 31 is_stmt 1              ; .scratch/far-word-policy/source/bounds.c:128:31
	ldx	__rc2
	ldy	__rc3
	lda	__rc4
	stx	corpus_result
	sty	corpus_result+1
	sta	corpus_result+2
	ldx	__rc5
	stx	corpus_result+3
.LBB12_17:                              ; =>This Inner Loop Header: Depth=1
	.loc	1 128 48                        ; .scratch/far-word-policy/source/bounds.c:128:48
	;APP
	wai
	;NO_APP
	.loc	1 128 39                        ; .scratch/far-word-policy/source/bounds.c:128:39
	bra	.LBB12_17
.Ltmp97:
.Lfunc_end12:
	.size	main, .Lfunc_end12-main
                                        ; -- End function
	.type	rbase,@object                   ; @rbase
	.section	.data.rbase,"aw",@progbits
	.globl	rbase
rbase:
	.long	65535                           ; 0xffff
	.size	rbase, 4

	.type	wbase,@object                   ; @wbase
	.section	.data.wbase,"aw",@progbits
	.globl	wbase
wbase:
	.long	8322944                         ; 0x7eff80
	.size	wbase, 4

	.type	corpus_result,@object           ; @corpus_result
	.section	.bss.corpus_result,"aw",@nobits
	.globl	corpus_result
corpus_result:
	.long	0                               ; 0x0
	.size	corpus_result, 4

	.type	.Lstatic_stack,@object          ; @static_stack
	.section	.noinit..Lstatic_stack,"aw",@nobits
.Lstatic_stack:
	.zero	19
	.size	.Lstatic_stack, 19

.Lword_pressure_sstk = .Lstatic_stack
	.size	.Lword_pressure_sstk, 19
	.section	.debug_abbrev,"",@progbits
	.byte	1                               ; Abbreviation Code
	.byte	17                              ; DW_TAG_compile_unit
	.byte	1                               ; DW_CHILDREN_yes
	.byte	37                              ; DW_AT_producer
	.byte	37                              ; DW_FORM_strx1
	.byte	19                              ; DW_AT_language
	.byte	5                               ; DW_FORM_data2
	.byte	3                               ; DW_AT_name
	.byte	37                              ; DW_FORM_strx1
	.byte	114                             ; DW_AT_str_offsets_base
	.byte	23                              ; DW_FORM_sec_offset
	.byte	16                              ; DW_AT_stmt_list
	.byte	23                              ; DW_FORM_sec_offset
	.byte	27                              ; DW_AT_comp_dir
	.byte	37                              ; DW_FORM_strx1
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	85                              ; DW_AT_ranges
	.byte	35                              ; DW_FORM_rnglistx
	.byte	115                             ; DW_AT_addr_base
	.byte	23                              ; DW_FORM_sec_offset
	.byte	116                             ; DW_AT_rnglists_base
	.byte	23                              ; DW_FORM_sec_offset
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	2                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	0                               ; DW_CHILDREN_no
	.byte	3                               ; DW_AT_name
	.byte	37                              ; DW_FORM_strx1
	.byte	32                              ; DW_AT_inline
	.byte	33                              ; DW_FORM_implicit_const
	.byte	1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	3                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	1                               ; DW_CHILDREN_yes
	.byte	17                              ; DW_AT_low_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.byte	122                             ; DW_AT_call_all_calls
	.byte	25                              ; DW_FORM_flag_present
	.byte	3                               ; DW_AT_name
	.byte	37                              ; DW_FORM_strx1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	4                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	17                              ; DW_AT_low_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	5                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	35                              ; DW_FORM_rnglistx
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	6                               ; Abbreviation Code
	.byte	72                              ; DW_TAG_call_site
	.byte	0                               ; DW_CHILDREN_no
	.byte	127                             ; DW_AT_call_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	125                             ; DW_AT_call_return_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	7                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	0                               ; DW_CHILDREN_no
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	8                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	1                               ; DW_CHILDREN_yes
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	17                              ; DW_AT_low_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	0                               ; EOM(3)
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.long	.Ldebug_info_end0-.Ldebug_info_start0 ; Length of Unit
.Ldebug_info_start0:
	.short	5                               ; DWARF version number
	.byte	1                               ; DWARF Unit Type
	.byte	4                               ; Address Size (in bytes)
	.long	.debug_abbrev                   ; Offset Into Abbrev. Section
	.byte	1                               ; Abbrev [1] 0xc:0x25f DW_TAG_compile_unit
	.byte	0                               ; DW_AT_producer
	.short	29                              ; DW_AT_language
	.byte	1                               ; DW_AT_name
	.long	.Lstr_offsets_base0             ; DW_AT_str_offsets_base
	.long	.Lline_table_start0             ; DW_AT_stmt_list
	.byte	2                               ; DW_AT_comp_dir
	.long	0                               ; DW_AT_low_pc
	.byte	1                               ; DW_AT_ranges
	.long	.Laddr_table_base0              ; DW_AT_addr_base
	.long	.Lrnglists_table_base0          ; DW_AT_rnglists_base
	.byte	2                               ; Abbrev [2] 0x27:0x2 DW_TAG_subprogram
	.byte	3                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	3                               ; Abbrev [3] 0x29:0x15 DW_TAG_subprogram
	.byte	0                               ; DW_AT_low_pc
	.long	.Lfunc_end0-.Lfunc_begin0       ; DW_AT_high_pc
                                        ; DW_AT_call_all_calls
	.byte	7                               ; DW_AT_name
	.byte	4                               ; Abbrev [4] 0x30:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	1                               ; DW_AT_low_pc
	.long	.Ltmp1-.Ltmp0                   ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	43                              ; DW_AT_call_line
	.byte	41                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	3                               ; Abbrev [3] 0x3e:0x15 DW_TAG_subprogram
	.byte	2                               ; DW_AT_low_pc
	.long	.Lfunc_end1-.Lfunc_begin1       ; DW_AT_high_pc
                                        ; DW_AT_call_all_calls
	.byte	8                               ; DW_AT_name
	.byte	4                               ; Abbrev [4] 0x45:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	3                               ; DW_AT_low_pc
	.long	.Ltmp4-.Ltmp3                   ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	49                              ; DW_AT_call_line
	.byte	41                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	3                               ; Abbrev [3] 0x53:0x11 DW_TAG_subprogram
	.byte	4                               ; DW_AT_low_pc
	.long	.Lfunc_end2-.Lfunc_begin2       ; DW_AT_high_pc
                                        ; DW_AT_call_all_calls
	.byte	9                               ; DW_AT_name
	.byte	5                               ; Abbrev [5] 0x5a:0x9 DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	0                               ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	55                              ; DW_AT_call_line
	.byte	12                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	3                               ; Abbrev [3] 0x64:0x15 DW_TAG_subprogram
	.byte	5                               ; DW_AT_low_pc
	.long	.Lfunc_end3-.Lfunc_begin3       ; DW_AT_high_pc
                                        ; DW_AT_call_all_calls
	.byte	10                              ; DW_AT_name
	.byte	4                               ; Abbrev [4] 0x6b:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	6                               ; DW_AT_low_pc
	.long	.Ltmp30-.Ltmp29                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	60                              ; DW_AT_call_line
	.byte	12                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	3                               ; Abbrev [3] 0x79:0x15 DW_TAG_subprogram
	.byte	7                               ; DW_AT_low_pc
	.long	.Lfunc_end4-.Lfunc_begin4       ; DW_AT_high_pc
                                        ; DW_AT_call_all_calls
	.byte	11                              ; DW_AT_name
	.byte	4                               ; Abbrev [4] 0x80:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	8                               ; DW_AT_low_pc
	.long	.Ltmp33-.Ltmp32                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	66                              ; DW_AT_call_line
	.byte	40                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	3                               ; Abbrev [3] 0x8e:0x15 DW_TAG_subprogram
	.byte	9                               ; DW_AT_low_pc
	.long	.Lfunc_end5-.Lfunc_begin5       ; DW_AT_high_pc
                                        ; DW_AT_call_all_calls
	.byte	12                              ; DW_AT_name
	.byte	4                               ; Abbrev [4] 0x95:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	10                              ; DW_AT_low_pc
	.long	.Ltmp36-.Ltmp35                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	72                              ; DW_AT_call_line
	.byte	44                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	3                               ; Abbrev [3] 0xa3:0x69 DW_TAG_subprogram
	.byte	16                              ; DW_AT_low_pc
	.long	.Lfunc_end11-.Lfunc_begin11     ; DW_AT_high_pc
                                        ; DW_AT_call_all_calls
	.byte	13                              ; DW_AT_name
	.byte	4                               ; Abbrev [4] 0xaa:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	17                              ; DW_AT_low_pc
	.long	.Ltmp47-.Ltmp46                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	97                              ; DW_AT_call_line
	.byte	7                               ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0xb7:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	18                              ; DW_AT_low_pc
	.long	.Ltmp48-.Ltmp47                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	97                              ; DW_AT_call_line
	.byte	21                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0xc4:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_AT_low_pc
	.long	.Ltmp49-.Ltmp48                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	97                              ; DW_AT_call_line
	.byte	35                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0xd1:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	20                              ; DW_AT_low_pc
	.long	.Ltmp50-.Ltmp49                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	97                              ; DW_AT_call_line
	.byte	49                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0xde:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	21                              ; DW_AT_low_pc
	.long	.Ltmp51-.Ltmp50                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	98                              ; DW_AT_call_line
	.byte	7                               ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0xeb:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	22                              ; DW_AT_low_pc
	.long	.Ltmp52-.Ltmp51                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	98                              ; DW_AT_call_line
	.byte	21                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0xf8:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	23                              ; DW_AT_low_pc
	.long	.Ltmp53-.Ltmp52                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	98                              ; DW_AT_call_line
	.byte	35                              ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0x105:0x6 DW_TAG_call_site
	.long	268                             ; DW_AT_call_origin
	.byte	24                              ; DW_AT_call_return_pc
	.byte	0                               ; End Of Children Mark
	.byte	7                               ; Abbrev [7] 0x10c:0x1 DW_TAG_subprogram
	.byte	2                               ; Abbrev [2] 0x10d:0x2 DW_TAG_subprogram
	.byte	4                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x10f:0x2 DW_TAG_subprogram
	.byte	5                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x111:0x2 DW_TAG_subprogram
	.byte	6                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	3                               ; Abbrev [3] 0x113:0x153 DW_TAG_subprogram
	.byte	25                              ; DW_AT_low_pc
	.long	.Lfunc_end12-.Lfunc_begin12     ; DW_AT_high_pc
                                        ; DW_AT_call_all_calls
	.byte	14                              ; DW_AT_name
	.byte	8                               ; Abbrev [8] 0x11a:0x109 DW_TAG_inlined_subroutine
	.long	269                             ; DW_AT_abstract_origin
	.byte	26                              ; DW_AT_low_pc
	.long	.Ltmp96-.Ltmp55                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	128                             ; DW_AT_call_line
	.byte	32                              ; DW_AT_call_column
	.byte	8                               ; Abbrev [8] 0x127:0x1b DW_TAG_inlined_subroutine
	.long	271                             ; DW_AT_abstract_origin
	.byte	27                              ; DW_AT_low_pc
	.long	.Ltmp68-.Ltmp65                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	117                             ; DW_AT_call_line
	.byte	26                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x134:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	28                              ; DW_AT_low_pc
	.long	.Ltmp67-.Ltmp66                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	104                             ; DW_AT_call_line
	.byte	36                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	8                               ; Abbrev [8] 0x142:0x1b DW_TAG_inlined_subroutine
	.long	271                             ; DW_AT_abstract_origin
	.byte	29                              ; DW_AT_low_pc
	.long	.Ltmp73-.Ltmp70                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	118                             ; DW_AT_call_line
	.byte	26                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x14f:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	30                              ; DW_AT_low_pc
	.long	.Ltmp72-.Ltmp71                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	104                             ; DW_AT_call_line
	.byte	36                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	8                               ; Abbrev [8] 0x15d:0x1b DW_TAG_inlined_subroutine
	.long	271                             ; DW_AT_abstract_origin
	.byte	31                              ; DW_AT_low_pc
	.long	.Ltmp78-.Ltmp75                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	119                             ; DW_AT_call_line
	.byte	28                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x16a:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	32                              ; DW_AT_low_pc
	.long	.Ltmp77-.Ltmp76                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	104                             ; DW_AT_call_line
	.byte	36                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	8                               ; Abbrev [8] 0x178:0x1b DW_TAG_inlined_subroutine
	.long	271                             ; DW_AT_abstract_origin
	.byte	33                              ; DW_AT_low_pc
	.long	.Ltmp83-.Ltmp80                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	120                             ; DW_AT_call_line
	.byte	37                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x185:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	34                              ; DW_AT_low_pc
	.long	.Ltmp82-.Ltmp81                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	104                             ; DW_AT_call_line
	.byte	36                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	4                               ; Abbrev [4] 0x193:0xd DW_TAG_inlined_subroutine
	.long	273                             ; DW_AT_abstract_origin
	.byte	35                              ; DW_AT_low_pc
	.long	.Ltmp85-.Ltmp84                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	111                             ; DW_AT_call_line
	.byte	7                               ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x1a0:0xd DW_TAG_inlined_subroutine
	.long	273                             ; DW_AT_abstract_origin
	.byte	36                              ; DW_AT_low_pc
	.long	.Ltmp86-.Ltmp85                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	111                             ; DW_AT_call_line
	.byte	29                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x1ad:0xd DW_TAG_inlined_subroutine
	.long	273                             ; DW_AT_abstract_origin
	.byte	37                              ; DW_AT_low_pc
	.long	.Ltmp87-.Ltmp86                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	112                             ; DW_AT_call_line
	.byte	7                               ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x1ba:0xd DW_TAG_inlined_subroutine
	.long	273                             ; DW_AT_abstract_origin
	.byte	38                              ; DW_AT_low_pc
	.long	.Ltmp88-.Ltmp87                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	112                             ; DW_AT_call_line
	.byte	31                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x1c7:0xd DW_TAG_inlined_subroutine
	.long	273                             ; DW_AT_abstract_origin
	.byte	39                              ; DW_AT_low_pc
	.long	.Ltmp89-.Ltmp88                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	113                             ; DW_AT_call_line
	.byte	7                               ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x1d4:0xd DW_TAG_inlined_subroutine
	.long	273                             ; DW_AT_abstract_origin
	.byte	40                              ; DW_AT_low_pc
	.long	.Ltmp90-.Ltmp89                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	113                             ; DW_AT_call_line
	.byte	40                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x1e1:0xd DW_TAG_inlined_subroutine
	.long	273                             ; DW_AT_abstract_origin
	.byte	41                              ; DW_AT_low_pc
	.long	.Ltmp91-.Ltmp90                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	114                             ; DW_AT_call_line
	.byte	7                               ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x1ee:0xd DW_TAG_inlined_subroutine
	.long	273                             ; DW_AT_abstract_origin
	.byte	42                              ; DW_AT_low_pc
	.long	.Ltmp92-.Ltmp91                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	117                             ; DW_AT_call_line
	.byte	18                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x1fb:0xd DW_TAG_inlined_subroutine
	.long	273                             ; DW_AT_abstract_origin
	.byte	43                              ; DW_AT_low_pc
	.long	.Ltmp93-.Ltmp92                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	118                             ; DW_AT_call_line
	.byte	18                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x208:0xd DW_TAG_inlined_subroutine
	.long	273                             ; DW_AT_abstract_origin
	.byte	44                              ; DW_AT_low_pc
	.long	.Ltmp94-.Ltmp93                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	119                             ; DW_AT_call_line
	.byte	20                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x215:0xd DW_TAG_inlined_subroutine
	.long	273                             ; DW_AT_abstract_origin
	.byte	45                              ; DW_AT_low_pc
	.long	.Ltmp95-.Ltmp94                 ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	120                             ; DW_AT_call_line
	.byte	29                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	6                               ; Abbrev [6] 0x223:0x6 DW_TAG_call_site
	.long	41                              ; DW_AT_call_origin
	.byte	46                              ; DW_AT_call_return_pc
	.byte	6                               ; Abbrev [6] 0x229:0x6 DW_TAG_call_site
	.long	62                              ; DW_AT_call_origin
	.byte	47                              ; DW_AT_call_return_pc
	.byte	6                               ; Abbrev [6] 0x22f:0x6 DW_TAG_call_site
	.long	83                              ; DW_AT_call_origin
	.byte	48                              ; DW_AT_call_return_pc
	.byte	6                               ; Abbrev [6] 0x235:0x6 DW_TAG_call_site
	.long	100                             ; DW_AT_call_origin
	.byte	49                              ; DW_AT_call_return_pc
	.byte	6                               ; Abbrev [6] 0x23b:0x6 DW_TAG_call_site
	.long	121                             ; DW_AT_call_origin
	.byte	50                              ; DW_AT_call_return_pc
	.byte	6                               ; Abbrev [6] 0x241:0x6 DW_TAG_call_site
	.long	142                             ; DW_AT_call_origin
	.byte	51                              ; DW_AT_call_return_pc
	.byte	6                               ; Abbrev [6] 0x247:0x6 DW_TAG_call_site
	.long	163                             ; DW_AT_call_origin
	.byte	52                              ; DW_AT_call_return_pc
	.byte	6                               ; Abbrev [6] 0x24d:0x6 DW_TAG_call_site
	.long	614                             ; DW_AT_call_origin
	.byte	53                              ; DW_AT_call_return_pc
	.byte	6                               ; Abbrev [6] 0x253:0x6 DW_TAG_call_site
	.long	615                             ; DW_AT_call_origin
	.byte	54                              ; DW_AT_call_return_pc
	.byte	6                               ; Abbrev [6] 0x259:0x6 DW_TAG_call_site
	.long	616                             ; DW_AT_call_origin
	.byte	55                              ; DW_AT_call_return_pc
	.byte	6                               ; Abbrev [6] 0x25f:0x6 DW_TAG_call_site
	.long	617                             ; DW_AT_call_origin
	.byte	56                              ; DW_AT_call_return_pc
	.byte	0                               ; End Of Children Mark
	.byte	7                               ; Abbrev [7] 0x266:0x1 DW_TAG_subprogram
	.byte	7                               ; Abbrev [7] 0x267:0x1 DW_TAG_subprogram
	.byte	7                               ; Abbrev [7] 0x268:0x1 DW_TAG_subprogram
	.byte	7                               ; Abbrev [7] 0x269:0x1 DW_TAG_subprogram
	.byte	0                               ; End Of Children Mark
.Ldebug_info_end0:
	.section	.debug_rnglists,"",@progbits
	.long	.Ldebug_list_header_end0-.Ldebug_list_header_start0 ; Length
.Ldebug_list_header_start0:
	.short	5                               ; Version
	.byte	4                               ; Address size
	.byte	0                               ; Segment selector size
	.long	2                               ; Offset entry count
.Lrnglists_table_base0:
	.long	.Ldebug_ranges0-.Lrnglists_table_base0
	.long	.Ldebug_ranges1-.Lrnglists_table_base0
.Ldebug_ranges0:
	.byte	1                               ; DW_RLE_base_addressx
	.byte	4                               ;   base address index
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp6-.Lfunc_begin2           ;   starting offset
	.uleb128 .Ltmp7-.Lfunc_begin2           ;   ending offset
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp8-.Lfunc_begin2           ;   starting offset
	.uleb128 .Ltmp9-.Lfunc_begin2           ;   ending offset
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp10-.Lfunc_begin2          ;   starting offset
	.uleb128 .Ltmp11-.Lfunc_begin2          ;   ending offset
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp12-.Lfunc_begin2          ;   starting offset
	.uleb128 .Ltmp13-.Lfunc_begin2          ;   ending offset
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp14-.Lfunc_begin2          ;   starting offset
	.uleb128 .Ltmp15-.Lfunc_begin2          ;   ending offset
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp16-.Lfunc_begin2          ;   starting offset
	.uleb128 .Ltmp17-.Lfunc_begin2          ;   ending offset
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp18-.Lfunc_begin2          ;   starting offset
	.uleb128 .Ltmp19-.Lfunc_begin2          ;   ending offset
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp20-.Lfunc_begin2          ;   starting offset
	.uleb128 .Ltmp21-.Lfunc_begin2          ;   ending offset
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp22-.Lfunc_begin2          ;   starting offset
	.uleb128 .Ltmp23-.Lfunc_begin2          ;   ending offset
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp24-.Lfunc_begin2          ;   starting offset
	.uleb128 .Ltmp25-.Lfunc_begin2          ;   ending offset
	.byte	4                               ; DW_RLE_offset_pair
	.uleb128 .Ltmp26-.Lfunc_begin2          ;   starting offset
	.uleb128 .Ltmp27-.Lfunc_begin2          ;   ending offset
	.byte	0                               ; DW_RLE_end_of_list
.Ldebug_ranges1:
	.byte	3                               ; DW_RLE_startx_length
	.byte	0                               ;   start index
	.uleb128 .Lfunc_end0-.Lfunc_begin0      ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	2                               ;   start index
	.uleb128 .Lfunc_end1-.Lfunc_begin1      ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	4                               ;   start index
	.uleb128 .Lfunc_end2-.Lfunc_begin2      ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	5                               ;   start index
	.uleb128 .Lfunc_end3-.Lfunc_begin3      ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	7                               ;   start index
	.uleb128 .Lfunc_end4-.Lfunc_begin4      ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	9                               ;   start index
	.uleb128 .Lfunc_end5-.Lfunc_begin5      ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	11                              ;   start index
	.uleb128 .Lfunc_end6-.Lfunc_begin6      ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	12                              ;   start index
	.uleb128 .Lfunc_end7-.Lfunc_begin7      ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	13                              ;   start index
	.uleb128 .Lfunc_end8-.Lfunc_begin8      ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	14                              ;   start index
	.uleb128 .Lfunc_end9-.Lfunc_begin9      ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	15                              ;   start index
	.uleb128 .Lfunc_end10-.Lfunc_begin10    ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	16                              ;   start index
	.uleb128 .Lfunc_end11-.Lfunc_begin11    ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	25                              ;   start index
	.uleb128 .Lfunc_end12-.Lfunc_begin12    ;   length
	.byte	0                               ; DW_RLE_end_of_list
.Ldebug_list_header_end0:
	.section	.debug_str_offsets,"",@progbits
	.long	64                              ; Length of String Offsets Set
	.short	5
	.short	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)" ; string offset=0 ; clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)
.Linfo_string1:
	.asciz	"/home/will/llvm-mos-65816/.scratch/far-word-policy/source/bounds.c" ; string offset=108 ; /home/will/llvm-mos-65816/.scratch/far-word-policy/source/bounds.c
.Linfo_string2:
	.asciz	"/home/will/llvm-mos-65816"     ; string offset=175 ; /home/will/llvm-mos-65816
.Linfo_string3:
	.asciz	"mix16"                         ; string offset=201 ; mix16
.Linfo_string4:
	.asciz	"run"                           ; string offset=207 ; run
.Linfo_string5:
	.asciz	"readback"                      ; string offset=211 ; readback
.Linfo_string6:
	.asciz	"mix32"                         ; string offset=220 ; mix32
.Linfo_string7:
	.asciz	"word128"                       ; string offset=226 ; word128
.Linfo_string8:
	.asciz	"word129"                       ; string offset=234 ; word129
.Linfo_string9:
	.asciz	"word_wrap"                     ; string offset=242 ; word_wrap
.Linfo_string10:
	.asciz	"word256"                       ; string offset=252 ; word256
.Linfo_string11:
	.asciz	"word_wrapped_index"            ; string offset=260 ; word_wrapped_index
.Linfo_string12:
	.asciz	"word_step2"                    ; string offset=279 ; word_step2
.Linfo_string13:
	.asciz	"word_pressure"                 ; string offset=290 ; word_pressure
.Linfo_string14:
	.asciz	"main"                          ; string offset=304 ; main
	.section	.debug_str_offsets,"",@progbits
	.long	.Linfo_string0
	.long	.Linfo_string1
	.long	.Linfo_string2
	.long	.Linfo_string3
	.long	.Linfo_string4
	.long	.Linfo_string5
	.long	.Linfo_string6
	.long	.Linfo_string7
	.long	.Linfo_string8
	.long	.Linfo_string9
	.long	.Linfo_string10
	.long	.Linfo_string11
	.long	.Linfo_string12
	.long	.Linfo_string13
	.long	.Linfo_string14
	.section	.debug_addr,"",@progbits
	.long	.Ldebug_addr_end0-.Ldebug_addr_start0 ; Length of contribution
.Ldebug_addr_start0:
	.short	5                               ; DWARF version number
	.byte	4                               ; Address size
	.byte	0                               ; Segment selector size
.Laddr_table_base0:
	.long	.Lfunc_begin0
	.long	.Ltmp0
	.long	.Lfunc_begin1
	.long	.Ltmp3
	.long	.Lfunc_begin2
	.long	.Lfunc_begin3
	.long	.Ltmp29
	.long	.Lfunc_begin4
	.long	.Ltmp32
	.long	.Lfunc_begin5
	.long	.Ltmp35
	.long	.Lfunc_begin6
	.long	.Lfunc_begin7
	.long	.Lfunc_begin8
	.long	.Lfunc_begin9
	.long	.Lfunc_begin10
	.long	.Lfunc_begin11
	.long	.Ltmp46
	.long	.Ltmp47
	.long	.Ltmp48
	.long	.Ltmp49
	.long	.Ltmp50
	.long	.Ltmp51
	.long	.Ltmp52
	.long	.Ltmp45
	.long	.Lfunc_begin12
	.long	.Ltmp55
	.long	.Ltmp65
	.long	.Ltmp66
	.long	.Ltmp70
	.long	.Ltmp71
	.long	.Ltmp75
	.long	.Ltmp76
	.long	.Ltmp80
	.long	.Ltmp81
	.long	.Ltmp84
	.long	.Ltmp85
	.long	.Ltmp86
	.long	.Ltmp87
	.long	.Ltmp88
	.long	.Ltmp89
	.long	.Ltmp90
	.long	.Ltmp91
	.long	.Ltmp92
	.long	.Ltmp93
	.long	.Ltmp94
	.long	.Ltmp56
	.long	.Ltmp57
	.long	.Ltmp58
	.long	.Ltmp59
	.long	.Ltmp60
	.long	.Ltmp61
	.long	.Ltmp62
	.long	.Ltmp64
	.long	.Ltmp69
	.long	.Ltmp74
	.long	.Ltmp79
.Ldebug_addr_end0:
	.ident	"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym rbase
	.addrsig_sym wbase
	.addrsig_sym corpus_result
	.addrsig_sym .Lstatic_stack
	;Declaring this symbol tells the CRT that there is something in .bss, so it may need to be zeroed.
	.globl	__do_zero_bss
	;Declaring this symbol tells the CRT that there is something in .data, so it may need to be copied from LMA to VMA.
	.globl	__do_copy_data
	;Declaring this symbol tells the CRT that the stack pointer needs to be initialized.
	.globl	__do_init_stack
	.section	.debug_line,"",@progbits
.Lline_table_start0:
