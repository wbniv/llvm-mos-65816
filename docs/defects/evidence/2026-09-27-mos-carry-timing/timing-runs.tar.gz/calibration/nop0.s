.text
.global calibration
.type calibration,@function
calibration:
  rts
.size calibration,.-calibration
