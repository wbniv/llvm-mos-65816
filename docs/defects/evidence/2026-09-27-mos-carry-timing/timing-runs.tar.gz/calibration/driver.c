#include <stdint.h>
extern void calibration(void);
volatile uint16_t corpus_result;
int main(void) { calibration(); corpus_result=0x600d; for (;;) __asm__ volatile("wai"); }
