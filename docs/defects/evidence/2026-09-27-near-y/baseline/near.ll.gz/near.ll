; ModuleID = '/work/build/near-y-fix/near-decode.c'
source_filename = "/work/build/near-y-fix/near-decode.c"
target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"
target triple = "mos"

@source = internal global ptr @compressed, align 1
@destination = internal global ptr @output, align 1
@output = internal global [672 x i8] zeroinitializer, align 1
@expected = internal unnamed_addr constant [672 x i8] c"\00\0D\1A'4AN[hu\82\8F\9C\A9\B6\C3\D0\DD\EA\F7\04\11\1E+8ER_ly\86\93\A0\AD\BA\C7\D4\E1\EE\FB\08\15\22/<IVcp}\8A\97\A4\B1\BE\CB\D8\E5\F2\FF\0C\19&3@MZgt\81\8E\9B\A8\B5\C2\CF\DC\E9\F6\03\10\1D*7DQ^kx\85\92\9F\AC\B9\C6\D3\E0\ED\FA\07\14!.;HUbo|\89\96\A3\B0\BD\CA\D7\E4\F1\FE\0B\18%2?LYfs\80\8D\9A\A7\B4\C1\CE\DB\E8\F5\02\0F\1C)6CP]jw\84\91\9E\AB\B8\C5\D2\DF\EC\F9\06\13 -:GTan{\88\95\A2\AF\BC\C9\D6\E3\F0\FD\0A\17$1>KXer\7F\8C\99\A6\B3\C0\CD\DA\E7\F4\01\0E\1B(5BO\\iv\83\90\9D\AA\B7\C4\D1\DE\EB\F8\05\12\1F,9FS`mz\87\94\A1\AE\BB\C8\D5\E2\EF\FC\09\16#0=JWdq~\8B\98\A5\B2\BF\CC\D9\E6\F3+8ER_ly\86\93\A0\AD\BA\C7\D4\E1\EE\FB\08\15\22/<IVcp}\8A\97\A4\B1\BE\CB\D8\E5\F2\FF\0C\19&3@MZgt\81\8E\9B\A8\B5\C2\CF\DC\E9\F6\03\10\1D*7DQ^kx\85\92\9F\AC\B9\C6\D3\E0\ED\FA\07\14!.;HUbo|\89\96\A3\B0\BD\CA\D7\E4\F1\FE\0B\18%2?LYfs\80\8D\9A\A7\B4\C1\CE\DB\E8\F5\02\0F\1C)6CP]jw\84\91\9Es\80\8D\9A\A7\B4\C1\CE\DB\E8\F5\02\0F\1C)6CP]jw\84\91\9E\AB\B8\C5\D2\DF\EC\F9\06\13 -:GTan{\88\95\A2\AF\BC\C9\D6\E3\F0\FD\0A\17$1>KXer\7F\8C\99\A6\B3\C0\CD\DA\E7\F4\01\0E\1B(5BO\\iv\83\90\9D\AA\B7\C4\D1\DE\EB\F8\05\12\1F,9FS`mz\87\94\A1\AE\BB\C8\D5\E2\EF\FC\09\16#0=JWdq~\8B\98\A5\B2\BF\CC\D9\E6\F3+8ER_ly\86\93\A0\AD\BA\C7\D4\E1\EE\FB\08\15\22/<IVcp}\8A\97\A4\B1\BE\CB\D8\E5\F2\FF\0C\19&3@MZgt\81\8E\9B\A8\B5\C2\CF\DC\E9\F6\03\10\1D*7DQ^kx\85\92\9F\AC\B9\C6\D3\E0\ED\FA\07\14!.;HUbo|\89\96\A3\B0\BD\CA\D7\E4\F1\FE\0B\18%2?LYfs\80\8D\9A\A7\B4\C1\CE\DB\E8\F5\02\0F\1C)6CP]jw\84\91\9Es\80\8D\9A\A7\B4\C1\CE\DB\E8\F5\02\0F\1C)6CP]jw\84\91\9E\AB\B8\C5\D2\DF\EC\F9", align 1
@corpus_result = dso_local global i16 0, align 1
@compressed = internal constant [466 x i8] c"\00\00\0D\1A'4AN[\00hu\82\8F\9C\A9\B6\C3\00\D0\DD\EA\F7\04\11\1E+\008ER_ly\86\93\00\A0\AD\BA\C7\D4\E1\EE\FB\00\08\15\22/<IVc\00p}\8A\97\A4\B1\BE\CB\00\D8\E5\F2\FF\0C\19&3\00@MZgt\81\8E\9B\00\A8\B5\C2\CF\DC\E9\F6\03\00\10\1D*7DQ^k\00x\85\92\9F\AC\B9\C6\D3\00\E0\ED\FA\07\14!.;\00HUbo|\89\96\A3\00\B0\BD\CA\D7\E4\F1\FE\0B\00\18%2?LYfs\00\80\8D\9A\A7\B4\C1\CE\DB\00\E8\F5\02\0F\1C)6C\00P]jw\84\91\9E\AB\00\B8\C5\D2\DF\EC\F9\06\13\00 -:GTan{\00\88\95\A2\AF\BC\C9\D6\E3\00\F0\FD\0A\17$1>K\00Xer\7F\8C\99\A6\B3\00\C0\CD\DA\E7\F4\01\0E\1B\00(5BO\\iv\83\00\90\9D\AA\B7\C4\D1\DE\EB\00\F8\05\12\1F,9FS\00`mz\87\94\A1\AE\BB\00\C8\D5\E2\EF\FC\09\16#\000=JWdq~\8B\00\98\A5\B2\BF\CC\D9\E6\F3\00+8ER_ly\86\00\93\A0\AD\BA\C7\D4\E1\EE\00\FB\08\15\22/<IV\00cp}\8A\97\A4\B1\BE\00\CB\D8\E5\F2\FF\0C\19&\003@MZgt\81\8E\00\9B\A8\B5\C2\CF\DC\E9\F6\00\03\10\1D*7DQ^\00kx\85\92\9F\AC\B9\C6\00\D3\E0\ED\FA\07\14!.\00;HUbo|\89\96\00\A3\B0\BD\CA\D7\E4\F1\FE\00\0B\18%2?LYf\00s\80\8D\9A\A7\B4\C1\CE\00\DB\E8\F5\02\0F\1C)6\00CP]jw\84\91\9E\FF\01\1F\01\1F\01\1F\01\1F\01\1F\01\1F\01\1F\01\1F\FF\01\1F\01\1F\01\1F\01\1F\01\1F\01\1F\01\1F\01\1F", align 1
@llvm.compiler.used = appending global [1 x ptr] [ptr @decode_near], section "llvm.metadata"

; Function Attrs: minsize nofree noinline norecurse nosync nounwind optsize memory(argmem: readwrite)
define dso_local noundef i16 @decode_near(ptr noundef readonly captures(none) %0, i16 noundef %1, ptr noundef captures(none) %2, i16 noundef %3) #0 {
  br label %6

5:                                                ; preds = %23, %17
  br label %6

6:                                                ; preds = %5, %4
  %7 = phi i16 [ 0, %4 ], [ %19, %5 ]
  %8 = phi i16 [ 0, %4 ], [ %20, %5 ]
  %9 = icmp ult i16 %8, %1
  br i1 %9, label %10, label %79

10:                                               ; preds = %6
  %11 = icmp ult i16 %7, %3
  br i1 %11, label %12, label %79

12:                                               ; preds = %10
  %13 = add nuw i16 %8, 1
  %14 = getelementptr inbounds nuw i8, ptr %0, i16 %8
  %15 = load i8, ptr %14, align 1, !tbaa !8
  %16 = zext i8 %15 to i16
  br label %17

17:                                               ; preds = %75, %12
  %18 = phi i8 [ 0, %12 ], [ %78, %75 ]
  %19 = phi i16 [ %7, %12 ], [ %76, %75 ]
  %20 = phi i16 [ %13, %12 ], [ %77, %75 ]
  %21 = zext nneg i8 %18 to i16
  %22 = icmp eq i8 %18, 8
  br i1 %22, label %5, label %23, !llvm.loop !9

23:                                               ; preds = %17
  %24 = icmp ult i16 %19, %3
  br i1 %24, label %25, label %5, !llvm.loop !9

25:                                               ; preds = %23
  %26 = shl nuw nsw i16 1, %21
  %27 = and i16 %26, %16
  %28 = icmp eq i16 %27, 0
  br i1 %28, label %67, label %29

29:                                               ; preds = %25
  %30 = add i16 %20, 2
  %31 = icmp ugt i16 %30, %1
  br i1 %31, label %82, label %32

32:                                               ; preds = %29
  %33 = getelementptr inbounds nuw i8, ptr %0, i16 %20
  %34 = load i8, ptr %33, align 1, !tbaa !8
  %35 = getelementptr i8, ptr %33, i16 1
  %36 = load i8, ptr %35, align 1, !tbaa !8
  %37 = zext i8 %34 to i16
  %38 = zext i8 %36 to i16
  %39 = shl nuw nsw i16 %38, 4
  %40 = and i16 %39, 3840
  %41 = or disjoint i16 %40, %37
  %42 = icmp eq i16 %41, 0
  br i1 %42, label %82, label %43

43:                                               ; preds = %32
  %44 = icmp ugt i16 %41, %19
  br i1 %44, label %82, label %45

45:                                               ; preds = %43
  %46 = and i8 %36, 15
  %47 = add nuw nsw i8 %46, 3
  %48 = or disjoint i16 %40, %37
  %49 = sub i16 %19, %48
  %50 = getelementptr i8, ptr %2, i16 %49
  %51 = getelementptr i8, ptr %2, i16 %19
  br label %52

52:                                               ; preds = %45, %59
  %53 = phi i8 [ 0, %45 ], [ %66, %59 ]
  %54 = phi i16 [ %19, %45 ], [ %65, %59 ]
  %55 = phi i8 [ %47, %45 ], [ %60, %59 ]
  %56 = icmp ne i8 %55, 0
  %57 = icmp ult i16 %54, %3
  %58 = select i1 %56, i1 %57, i1 false
  br i1 %58, label %59, label %75

59:                                               ; preds = %52
  %60 = add nsw i8 %55, -1
  %61 = zext nneg i8 %53 to i16
  %62 = getelementptr i8, ptr %50, i16 %61
  %63 = load i8, ptr %62, align 1, !tbaa !8
  %64 = getelementptr i8, ptr %51, i16 %61
  store i8 %63, ptr %64, align 1, !tbaa !8
  %65 = add nuw i16 %54, 1
  %66 = add nuw nsw i8 %53, 1
  br label %52, !llvm.loop !11

67:                                               ; preds = %25
  %68 = icmp ult i16 %20, %1
  br i1 %68, label %69, label %82

69:                                               ; preds = %67
  %70 = add nuw i16 %20, 1
  %71 = getelementptr inbounds nuw i8, ptr %0, i16 %20
  %72 = load i8, ptr %71, align 1, !tbaa !8
  %73 = add nuw i16 %19, 1
  %74 = getelementptr inbounds nuw i8, ptr %2, i16 %19
  store i8 %72, ptr %74, align 1, !tbaa !8
  br label %75

75:                                               ; preds = %52, %69
  %76 = phi i16 [ %73, %69 ], [ %54, %52 ]
  %77 = phi i16 [ %70, %69 ], [ %30, %52 ]
  %78 = add nuw nsw i8 %18, 1
  br label %17, !llvm.loop !12

79:                                               ; preds = %6, %10
  %80 = icmp eq i16 %7, %3
  br i1 %80, label %81, label %82

81:                                               ; preds = %79
  br label %82

82:                                               ; preds = %43, %32, %29, %67, %81, %79
  %83 = phi i16 [ 0, %79 ], [ %3, %81 ], [ 0, %67 ], [ 0, %29 ], [ 0, %32 ], [ 0, %43 ]
  ret i16 %83
}

; Function Attrs: minsize noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr #1 {
  %1 = load volatile ptr, ptr @source, align 1, !tbaa !13
  %2 = load volatile ptr, ptr @destination, align 1, !tbaa !13
  %3 = tail call i16 @decode_near(ptr noundef %1, i16 noundef 466, ptr noundef %2, i16 noundef 672) #2
  %4 = icmp eq i16 %3, 672
  %5 = zext i1 %4 to i16
  br label %6

6:                                                ; preds = %20, %0
  %7 = phi i16 [ %5, %0 ], [ %21, %20 ]
  %8 = phi i16 [ 0, %0 ], [ %22, %20 ]
  %9 = icmp eq i16 %8, 672
  br i1 %9, label %10, label %13

10:                                               ; preds = %6
  %11 = icmp eq i16 %7, 0
  %12 = select i1 %11, i16 -23281, i16 23792
  store volatile i16 %12, ptr @corpus_result, align 1, !tbaa !4
  br label %23

13:                                               ; preds = %6
  %14 = getelementptr inbounds nuw i8, ptr @output, i16 %8
  %15 = load i8, ptr %14, align 1, !tbaa !8
  %16 = getelementptr inbounds nuw i8, ptr @expected, i16 %8
  %17 = load i8, ptr %16, align 1, !tbaa !8
  %18 = icmp eq i8 %15, %17
  br i1 %18, label %20, label %19

19:                                               ; preds = %13
  br label %20

20:                                               ; preds = %13, %19
  %21 = phi i16 [ 0, %19 ], [ %7, %13 ]
  %22 = add nuw nsw i16 %8, 1
  br label %6, !llvm.loop !16

23:                                               ; preds = %23, %10
  tail call void asm sideeffect "wai", ""() #3, !srcloc !17
  br label %23
}

attributes #0 = { minsize nofree noinline norecurse nosync nounwind optsize memory(argmem: readwrite) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #1 = { minsize noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mosw65816" "target-features"="+mos-a16,+mos-xy16" }
attributes #2 = { minsize optsize }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}
!llvm.errno.tbaa = !{!4}

!0 = !{i32 7, !"frame-pointer", i32 2}
!1 = !{i32 1, !"ThinLTO", i32 0}
!2 = !{i32 1, !"EnableSplitLTOUnit", i32 1}
!3 = !{!"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"}
!4 = !{!5, !5, i64 0}
!5 = !{!"int", !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C/C++ TBAA"}
!8 = !{!6, !6, i64 0}
!9 = distinct !{!9, !10}
!10 = !{!"llvm.loop.mustprogress"}
!11 = distinct !{!11, !10}
!12 = distinct !{!12, !10}
!13 = !{!14, !14, i64 0}
!14 = !{!"p1 omnipotent char", !15, i64 0}
!15 = !{!"any pointer", !6, i64 0}
!16 = distinct !{!16, !10}
!17 = !{i64 5411}

^0 = module: (path: "[Regular LTO]", hash: (0, 0, 0, 0, 0))
^1 = gv: (name: "destination", summaries: (variable: (module: ^0, flags: (linkage: internal, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0), refs: (^4)))) ; guid = 686235966769669414
^2 = gv: (name: "compressed", summaries: (variable: (module: ^0, flags: (linkage: internal, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 0, constant: 1)))) ; guid = 9027414149724893805
^3 = gv: (name: "llvm.compiler.used", summaries: (variable: (module: ^0, flags: (linkage: appending, visibility: default, notEligibleToImport: 1, live: 1, dsoLocal: 0, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 0, writeonly: 0, constant: 0), refs: (^7)))) ; guid = 9610627770985738006
^4 = gv: (name: "output", summaries: (variable: (module: ^0, flags: (linkage: internal, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 11447603223041879490
^5 = gv: (name: "source", summaries: (variable: (module: ^0, flags: (linkage: internal, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0), refs: (^2)))) ; guid = 12004430296756864279
^6 = gv: (name: "expected", summaries: (variable: (module: ^0, flags: (linkage: internal, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 0, constant: 1)))) ; guid = 13476447377893537726
^7 = gv: (name: "decode_near", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 82, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 1, returnDoesNotAlias: 0, noInline: 1, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0)))) ; guid = 14156669552926387294
^8 = gv: (name: "corpus_result", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 15048766475834254559
^9 = gv: (name: "main", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 26, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 0, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 1, mustBeUnreachable: 0), calls: ((callee: ^7, tail: 1)), refs: (^5, ^1, ^8, ^4, ^6)))) ; guid = 15822663052811949562
^10 = flags: 8
^11 = blockcount: 0
