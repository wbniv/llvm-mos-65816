	.zeropage	__rc0
	.zeropage	__rc1
	.zeropage	__rc2
	.zeropage	__rc3
	.zeropage	__rc4
	.zeropage	__rc5
	.zeropage	__rc6
	.zeropage	__rc7
	.zeropage	__rc8
	.zeropage	__rc9
	.zeropage	__rc10
	.zeropage	__rc11
	.zeropage	__rc12
	.zeropage	__rc13
	.zeropage	__rc14
	.zeropage	__rc15
	.zeropage	__rc16
	.zeropage	__rc17
	.zeropage	__rc18
	.zeropage	__rc19
	.zeropage	__rc20
	.zeropage	__rc21
	.zeropage	__rc22
	.zeropage	__rc23
	.zeropage	__rc24
	.zeropage	__rc25
	.zeropage	__rc26
	.zeropage	__rc27
	.zeropage	__rc28
	.zeropage	__rc29
	.zeropage	__rc30
	.zeropage	__rc31
	.file	"farblit_press.c"
	.section	.text.main,"ax",@progbits
	.globl	main                            ; -- Begin function main
	.type	main,@function
main:                                   ; @main
.Lfunc_begin0:
	.file	0 "/work" "/work/examples/65816/farblit_press.c" md5 0x8cf258f723cfcdb4554748603c94d0af
; %bb.0:
	.file	1 "examples/65816" "farblit_press.c" md5 0x8cf258f723cfcdb4554748603c94d0af
	.loc	1 67 33 prologue_end            ; examples/65816/farblit_press.c:67:33
	ldx	gbase
	stx	__rc20
	ldy	gbase+1
	lda	gbase+2
	ldx	gbase+3
	sty	__rc21
	sta	__rc22
	stx	__rc23
	phy
	.loc	1 68 3                          ; examples/65816/farblit_press.c:68:3
	ldy	__rc20
	sty	__rc4
	ply
	sty	__rc5
	sta	__rc6
	stx	__rc7
	jsr	fill
.Ltmp0:
	.loc	1 69 29                         ; examples/65816/farblit_press.c:69:29
	ldx	pa
	stx	__rc10
	ldx	pa+1
	stx	__rc11
	.loc	1 69 33 is_stmt 0               ; examples/65816/farblit_press.c:69:33
	lda	pb
	ldx	pb+1
	stx	__rc3
	.loc	1 69 37                         ; examples/65816/farblit_press.c:69:37
	ldy	pc
	ldx	pc+1
	pha
	.loc	1 69 19                         ; examples/65816/farblit_press.c:69:19
	lda	__rc20
	sta	__rc4
	lda	__rc21
	sta	__rc5
	lda	__rc22
	sta	__rc6
	lda	__rc23
	sta	__rc7
	pla
	sta	__rc2
	sty	__rc8
	stx	__rc9
	ldx	__rc11
	lda	__rc10
	jsr	sample
.Ltmp1:
	.loc	1 69 17 is_stmt 1               ; examples/65816/farblit_press.c:69:17
	sta	corpus_result
	stx	corpus_result+1
.LBB0_1:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 70 12                         ; examples/65816/farblit_press.c:70:12
	;APP
	wai
	;NO_APP
	.loc	1 70 3                          ; examples/65816/farblit_press.c:70:3
	bra	.LBB0_1
.Ltmp2:
.Lfunc_end0:
	.size	main, .Lfunc_end0-main
                                        ; -- End function
	.section	.text.fill,"ax",@progbits
	.type	fill,@function                  ; -- Begin function fill
fill:                                   ; @fill
.Lfunc_begin1:
	.loc	1 35 0                          ; examples/65816/farblit_press.c:35:0
; %bb.0:
	ldx	#0
	txy
.LBB1_1:                                ; =>This Inner Loop Header: Depth=1
	sep	#32
.Ltmp3:
	.loc	1 0 0 is_stmt 0                 ; examples/65816/farblit_press.c:0
	stx	__rc2
	sty	__rc3
	rep	#32
	.loc	1 38 29 prologue_end is_stmt 1  ; examples/65816/farblit_press.c:38:29
	lda	__rc2
	lsr
	lsr
	lsr
	lsr
	lsr
	lsr
	lsr
	.loc	1 38 24 is_stmt 0               ; examples/65816/farblit_press.c:38:24
	eor	__rc2
	sta	__rc8
	clc
	sep	#32
	txa
	.loc	1 38 5                          ; examples/65816/farblit_press.c:38:5
	adc	__rc4
	sta	__rc12
	tya
	adc	__rc5
	sta	__rc13
	lda	__rc6
	adc	#0
	sta	__rc14
	lda	__rc7
	adc	#0
	sta	__rc15
	lda	__rc8
	.loc	1 38 10                         ; examples/65816/farblit_press.c:38:10
	sta	[__rc12]
	rep	#32
	.loc	1 39 12 is_stmt 1               ; examples/65816/farblit_press.c:39:12
	lda	__rc2
	inc
	sta	__rc2
	sep	#32
	ldx	__rc2
	ldy	__rc3
	rep	#32
	cmp	#16384
	beq	.LBB1_2
; %bb.3:                                ;   in Loop: Header=BB1_1 Depth=1
	.loc	1 0 12 is_stmt 0                ; examples/65816/farblit_press.c:0:12
	jmp	.LBB1_1
.LBB1_2:
	sep	#32
	.loc	1 40 1 is_stmt 1                ; examples/65816/farblit_press.c:40:1
	rts
.Ltmp4:
.Lfunc_end1:
	.size	fill, .Lfunc_end1-fill
                                        ; -- End function
	.section	.text.sample,"ax",@progbits
	.type	sample,@function                ; -- Begin function sample
sample:                                 ; @sample
.Lfunc_begin2:
	.loc	1 42 0                          ; examples/65816/farblit_press.c:42:0
; %bb.0:
	ldy	__rc20
	phy
	ldy	__rc21
	phy
	ldy	__rc22
	phy
	ldy	__rc23
	phy
	ldy	__rc24
	sty	.Lsample_sstk+12                ; 1-byte Folded Spill
	ldy	__rc25
	sty	.Lsample_sstk+13                ; 1-byte Folded Spill
	ldy	__rc26
	sty	.Lsample_sstk+14                ; 1-byte Folded Spill
	ldy	__rc27
	sty	.Lsample_sstk+15                ; 1-byte Folded Spill
	ldy	__rc28
	sty	.Lsample_sstk+16                ; 1-byte Folded Spill
	ldy	__rc29
	sty	.Lsample_sstk+17                ; 1-byte Folded Spill
	ldy	__rc30
	sty	.Lsample_sstk+18                ; 1-byte Folded Spill
	ldy	__rc31
	sty	.Lsample_sstk+19                ; 1-byte Folded Spill
	sta	.Lsample_sstk+8                 ; 1-byte Folded Spill
	stx	.Lsample_sstk+9                 ; 1-byte Folded Spill
	ldx	__rc2
	stx	__rc21
	ldx	__rc3
	stx	.Lsample_sstk+10                ; 1-byte Folded Spill
	ldx	__rc8
	stx	__rc24
	ldx	__rc9
	stx	__rc25
	ldx	__rc4
	stx	__rc28
	ldx	__rc5
	stx	__rc29
	ldx	__rc6
	stx	__rc30
	ldx	__rc7
	stx	__rc31
	stz	__rc5
.Ltmp5:
	.loc	1 43 10 prologue_end            ; examples/65816/farblit_press.c:43:10
	rep	#32
	stz	.Lsample_sstk
	sep	#32
	rep	#32
	stz	.Lsample_sstk+2
	sep	#32
	ldy	#220
	lda	#mos16lo(.Lsample_sstk)
	ldx	#mos16hi(.Lsample_sstk)
	sta	__rc26
	stx	__rc27
	sty	__rc22
	ldx	#5
	stx	__rc23
	stz	__rc20
	stz	__rc3
                                        ; kill: def $rs1 killed $rs1
	ldx	__rc2
	stx	.Lsample_sstk+6                 ; 1-byte Folded Spill
	ldx	__rc3
	stx	.Lsample_sstk+7                 ; 1-byte Folded Spill
	ldx	#0
	stx	.Lsample_sstk+11                ; 1-byte Folded Spill
.LBB2_1:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 46 5                          ; examples/65816/farblit_press.c:46:5
	ldx	__rc26
	stx	__rc2
	ldx	__rc27
	stx	__rc3
	ldx	__rc21
	stx	__rc4
	ldx	.Lsample_sstk+10                ; 1-byte Folded Reload
	stx	__rc5
	ldx	__rc24
	stx	__rc6
	ldx	__rc25
	stx	__rc7
	ldx	.Lsample_sstk+9                 ; 1-byte Folded Reload
	lda	.Lsample_sstk+8                 ; 1-byte Folded Reload
	jsr	hop_step
.Ltmp6:
	.loc	1 0 5 is_stmt 0                 ; examples/65816/farblit_press.c:0:5
	rep	#32
	.loc	1 47 28                         ; examples/65816/farblit_press.c:47:28
	lda	.Lsample_sstk
.Ltmp7:
	.file	2 "examples/65816" "hopalong.h" md5 0xa5d31499f10ba0d009856fa4b00cffdd
	.loc	2 146 32                        ; examples/65816/hopalong.h:146:32 @[ examples/65816/farblit_press.c:47:18 ]
	cmp	#32768
	ror
	cmp	#32768
	ror
	cmp	#32768
	ror
	cmp	#32768
	ror
	cmp	#32768
	ror
	cmp	#32768
	ror
	cmp	#32768
	ror
	clc
	sep	#32
	ldx	#1
	bcs	.LBB2_3
; %bb.2:                                ;   in Loop: Header=BB2_1 Depth=1
	.loc	2 0 32                          ; examples/65816/hopalong.h:0:32
	ldx	#0
.LBB2_3:                                ;   in Loop: Header=BB2_1 Depth=1
	stx	__rc6
	rep	#32
	.loc	2 146 46 is_stmt 1              ; examples/65816/hopalong.h:146:46 @[ examples/65816/farblit_press.c:47:18 ]
	adc	#mos16(64)
	sta	__rc2
.Ltmp8:
	.loc	1 47 47 is_stmt 0               ; examples/65816/farblit_press.c:47:47
	lda	.Lsample_sstk+2
.Ltmp9:
	.loc	2 146 32                        ; examples/65816/hopalong.h:146:32 @[ examples/65816/farblit_press.c:47:37 ]
	cmp	#32768
	ror
	cmp	#32768
	ror
	cmp	#32768
	ror
	cmp	#32768
	ror
	cmp	#32768
	ror
	cmp	#32768
	ror
	cmp	#32768
	ror
	sta	.Lsample_sstk+4                 ; 2-byte Folded Spill
.Ltmp10:
	.loc	1 48 22 is_stmt 1               ; examples/65816/farblit_press.c:48:22
	lda	__rc2
	cmp	#mos16(128)
	bcc	.LBB2_4
; %bb.9:                                ;   in Loop: Header=BB2_1 Depth=1
	.loc	1 0 22 is_stmt 0                ; examples/65816/farblit_press.c:0:22
	jmp	.LBB2_6
.LBB2_4:                                ;   in Loop: Header=BB2_1 Depth=1
	sep	#32
	ldx	__rc6
	cpx	#1
	rep	#32
	lda	.Lsample_sstk+4                 ; 2-byte Folded Reload
	adc	#mos16(64)
	sta	__rc4
	.loc	1 48 59 is_stmt 1               ; examples/65816/farblit_press.c:48:59
	cmp	#mos16(128)
	bcc	.LBB2_5
; %bb.11:                               ;   in Loop: Header=BB2_1 Depth=1
	.loc	1 0 59 is_stmt 0                ; examples/65816/farblit_press.c:0:59
	jmp	.LBB2_6
.LBB2_5:                                ;   in Loop: Header=BB2_1 Depth=1
	.loc	1 49 46 is_stmt 1               ; examples/65816/farblit_press.c:49:46
	lda	__rc4
	asl
	asl
	asl
	asl
	asl
	asl
	asl
	.loc	1 49 57 is_stmt 0               ; examples/65816/farblit_press.c:49:57
	ora	__rc2
	sta	__rc4
	sep	#32
	lda	.Lsample_sstk+11                ; 1-byte Folded Reload
	.loc	1 50 42 is_stmt 1               ; examples/65816/farblit_press.c:50:42
	cmp	#128
	rol	__rc20
	rol
	ldx	__rc20
	stx	__rc2
	sta	__rc3
	.loc	1 50 77 is_stmt 0               ; examples/65816/farblit_press.c:50:77
	lda	__rc28
	ldx	__rc6
	cpx	#1
	adc	__rc4
	sta	__rc4
	lda	__rc5
	adc	__rc29
	sta	__rc5
	lda	__rc30
	adc	#0
	sta	__rc6
	lda	__rc31
	adc	#0
	sta	__rc7
	lda	[__rc4]
	ldx	.Lsample_sstk+6                 ; 1-byte Folded Reload
	ldx	.Lsample_sstk+7                 ; 1-byte Folded Reload
	stx	__rc5
	sta	__rc4
	rep	#32
	.loc	1 50 65                         ; examples/65816/farblit_press.c:50:65
	lda	__rc2
	sep	#32
	stx	__rc3
                                        ; kill: def $rs1 killed $rs1
	ldx	__rc2
	stx	.Lsample_sstk+6                 ; 1-byte Folded Spill
	ldx	__rc3
	stx	.Lsample_sstk+7                 ; 1-byte Folded Spill
	rep	#32
	eor	__rc4
	sta	__rc2
	sep	#32
	ldx	__rc2
	stx	__rc20
	ldx	__rc3
	stx	.Lsample_sstk+11                ; 1-byte Folded Spill
	rep	#32
.LBB2_6:                                ;   in Loop: Header=BB2_1 Depth=1
	.loc	1 45 26 is_stmt 1               ; examples/65816/farblit_press.c:45:26
	lda	__rc22
	dec
	sta	__rc22
	sep	#32
	lda	__rc23
	beq	.LBB2_7
; %bb.13:                               ;   in Loop: Header=BB2_1 Depth=1
	.loc	1 0 26 is_stmt 0                ; examples/65816/farblit_press.c:0:26
	jmp	.LBB2_1
.LBB2_7:                                ;   in Loop: Header=BB2_1 Depth=1
	lda	__rc22
	beq	.LBB2_8
; %bb.15:                               ;   in Loop: Header=BB2_1 Depth=1
	jmp	.LBB2_1
.LBB2_8:
	ldx	.Lsample_sstk+11                ; 1-byte Folded Reload
	.loc	1 53 3 is_stmt 1                ; examples/65816/farblit_press.c:53:3
	lda	__rc20
	ldy	.Lsample_sstk+19                ; 1-byte Folded Reload
	sty	__rc31
	ldy	.Lsample_sstk+18                ; 1-byte Folded Reload
	sty	__rc30
	ldy	.Lsample_sstk+17                ; 1-byte Folded Reload
	sty	__rc29
	ldy	.Lsample_sstk+16                ; 1-byte Folded Reload
	sty	__rc28
	ldy	.Lsample_sstk+15                ; 1-byte Folded Reload
	sty	__rc27
	ldy	.Lsample_sstk+14                ; 1-byte Folded Reload
	sty	__rc26
	ldy	.Lsample_sstk+13                ; 1-byte Folded Reload
	sty	__rc25
	ldy	.Lsample_sstk+12                ; 1-byte Folded Reload
	sty	__rc24
	ply
	sty	__rc23
	ply
	sty	__rc22
	ply
	sty	__rc21
	ply
	sty	__rc20
	rts
.Ltmp11:
.Lfunc_end2:
	.size	sample, .Lfunc_end2-sample
                                        ; -- End function
	.section	.text.hop_step,"ax",@progbits
	.type	hop_step,@function              ; -- Begin function hop_step
hop_step:                               ; @hop_step
.Lfunc_begin3:
	.loc	2 96 0                          ; examples/65816/hopalong.h:96:0
; %bb.0:
	ldy	__rc20
	phy
	ldy	__rc21
	phy
	ldy	__rc22
	phy
	ldy	__rc23
	phy
	ldy	__rc24
	sty	.Lhop_step_sstk+2               ; 1-byte Folded Spill
	ldy	__rc25
	sty	.Lhop_step_sstk+3               ; 1-byte Folded Spill
	ldy	__rc26
	sty	.Lhop_step_sstk+4               ; 1-byte Folded Spill
	ldy	__rc27
	sty	.Lhop_step_sstk+5               ; 1-byte Folded Spill
	ldy	__rc28
	sty	.Lhop_step_sstk+6               ; 1-byte Folded Spill
	ldy	__rc29
	sty	.Lhop_step_sstk+7               ; 1-byte Folded Spill
	sta	__rc24
	stx	__rc25
	ldx	__rc6
	stx	__rc23
	ldx	__rc7
	stx	__rc22
	ldx	__rc2
	stx	__rc20
	ldx	__rc3
	stx	__rc21
	rep	#32
.Ltmp12:
	.loc	2 97 16 prologue_end            ; examples/65816/hopalong.h:97:16
	lda	(__rc2)
	sta	__rc26
	eor	#32768
	cmp	#32768
	bcc	.LBB3_2
; %bb.1:
	.loc	2 0 16 is_stmt 0                ; examples/65816/hopalong.h:0:16
	sep	#32
	ldx	#0
	bra	.LBB3_3
.LBB3_2:
	sep	#32
	ldx	#255
.LBB3_3:
	ldy	#2
	rep	#32
	.loc	2 97 26 is_stmt 1               ; examples/65816/hopalong.h:97:26
	lda	(__rc20),y
	sta	.Lhop_step_sstk                 ; 2-byte Folded Spill
	.loc	2 98 19 is_stmt 0               ; examples/65816/hopalong.h:98:19
	lda	__rc4
	eor	#32768
	cmp	#32768
	bcc	.LBB3_5
; %bb.4:
	.loc	2 0 19                          ; examples/65816/hopalong.h:0:19
	sep	#32
	ldy	#0
	bra	.LBB3_6
.LBB3_5:
	sep	#32
	ldy	#255
.LBB3_6:
	lda	__rc6
	sta	__rc28
	lda	__rc7
	sta	__rc29
	.loc	2 98 30 is_stmt 1               ; examples/65816/hopalong.h:98:30
	stx	__rc2
	stx	__rc3
	sty	__rc6
	sty	__rc7
	ldx	__rc27
	lda	__rc26
	jsr	__mulsi3
.Ltmp13:
	lda	__rc3
	bpl	.LBB3_8
; %bb.7:
	.loc	2 0 30 is_stmt 0                ; examples/65816/hopalong.h:0:30
	txy
	ldx	#255
	stx	__rc5
	bra	.LBB3_9
.LBB3_8:
	txy
	stz	__rc5
.LBB3_9:
	sta	__rc6
	.loc	2 98 44 is_stmt 1               ; examples/65816/hopalong.h:98:44
	sta	__rc4
	rep	#32
	lda	__rc4
	asl
	sta	__rc8
	.loc	2 99 23 is_stmt 0               ; examples/65816/hopalong.h:99:23
	lda	__rc28
	eor	#32768
	cmp	#32768
	bcc	.LBB3_11
; %bb.10:
	.loc	2 0 23                          ; examples/65816/hopalong.h:0:23
	sep	#32
	stz	__rc3
	bra	.LBB3_12
.LBB3_11:
	sep	#32
	ldx	#255
	stx	__rc3
.LBB3_12:
	tya
	sec
	.loc	2 99 21 is_stmt 1               ; examples/65816/hopalong.h:99:21
	sbc	__rc23
	tax
	lda	__rc2
	sbc	__rc22
	sta	__rc4
	lda	__rc6
	sbc	__rc3
	sta	__rc5
	lda	__rc9
	sbc	__rc3
	bpl	.LBB3_14
; %bb.13:
	.loc	2 0 21 is_stmt 0                ; examples/65816/hopalong.h:0:21
	stx	__rc2
	ldx	#0
	.loc	2 100 28                        ; examples/65816/hopalong.h:100:28
	cpx	__rc2
	txa
	sbc	__rc4
	sta	__rc4
	txa
	sbc	__rc5
	sta	__rc5
.LBB3_14:
	.loc	2 0 28                          ; examples/65816/hopalong.h:0:28
	rep	#32
	.loc	2 102 11 is_stmt 1              ; examples/65816/hopalong.h:102:11
	lda	__rc4
	cmp	#256
	bcc	.LBB3_16
; %bb.15:
	.loc	2 0 11 is_stmt 0                ; examples/65816/hopalong.h:0:11
	sep	#32
	ldx	#255
	stz	__rc5
	stx	__rc4
	rep	#32
.LBB3_16:
	lda	.Lhop_step_sstk                 ; 2-byte Folded Reload
	sta	__rc2
	.loc	2 108 20 is_stmt 1              ; examples/65816/hopalong.h:108:20
	lda	__rc4
	asl
	sta	__rc4
	sep	#32
	ldx	#mos16lo(HOP_SQRT_LUT)
	stx	__rc6
	ldx	#mos16hi(HOP_SQRT_LUT)
	stx	__rc7
	rep	#32
	lda	__rc6
	clc
	adc	__rc4
	sta	__rc4
	lda	(__rc4)
	sta	__rc4
	.loc	2 110 18                        ; examples/65816/hopalong.h:110:18
	lda	__rc26
	eor	#32768
	cmp	#32769
	bcc	.LBB3_18
; %bb.17:
	.loc	2 0 18 is_stmt 0                ; examples/65816/hopalong.h:0:18
	sep	#32
	ldx	__rc4
	stx	__rc6
	ldx	__rc5
	stx	__rc7
	bra	.LBB3_20
.LBB3_18:
	.loc	2 110 31 is_stmt 1              ; examples/65816/hopalong.h:110:31
	lda	__rc26
	eor	#32768
	cmp	#32768
	sep	#32
	stz	__rc6
	stz	__rc7
	bcs	.LBB3_20
; %bb.19:
	.loc	2 0 31 is_stmt 0                ; examples/65816/hopalong.h:0:31
	ldx	#0
	stx	__rc6
	ldx	#0
	stx	__rc7
	rep	#32
	.loc	2 110 44                        ; examples/65816/hopalong.h:110:44
	lda	__rc6
	sec
	sbc	__rc4
	sta	__rc6
.LBB3_20:
	.loc	2 0 44                          ; examples/65816/hopalong.h:0:44
	rep	#32
	.loc	2 111 20 is_stmt 1              ; examples/65816/hopalong.h:111:20
	lda	__rc2
	sec
	sbc	__rc6
	.loc	2 111 8 is_stmt 0               ; examples/65816/hopalong.h:111:8
	sta	(__rc20)
	.loc	2 112 20                        ; examples/65816/hopalong.h:112:20
	lda	__rc24
	.loc	2 111 20                        ; examples/65816/hopalong.h:111:20
	sec
	.loc	2 112 20 is_stmt 1              ; examples/65816/hopalong.h:112:20
	sbc	__rc26
	sep	#32
	ldy	#2
	rep	#32
	.loc	2 112 8 is_stmt 0               ; examples/65816/hopalong.h:112:8
	sta	(__rc20),y
	sep	#32
	ldx	.Lhop_step_sstk+7               ; 1-byte Folded Reload
	stx	__rc29
	ldx	.Lhop_step_sstk+6               ; 1-byte Folded Reload
	stx	__rc28
	ldx	.Lhop_step_sstk+5               ; 1-byte Folded Reload
	stx	__rc27
	ldx	.Lhop_step_sstk+4               ; 1-byte Folded Reload
	stx	__rc26
	ldx	.Lhop_step_sstk+3               ; 1-byte Folded Reload
	stx	__rc25
	ldx	.Lhop_step_sstk+2               ; 1-byte Folded Reload
	stx	__rc24
	plx
	stx	__rc23
	plx
	stx	__rc22
	plx
	stx	__rc21
	plx
	stx	__rc20
	.loc	2 121 1 is_stmt 1               ; examples/65816/hopalong.h:121:1
	rts
.Ltmp14:
.Lfunc_end3:
	.size	hop_step, .Lfunc_end3-hop_step
                                        ; -- End function
	.type	pa,@object                      ; @pa
	.section	.data.pa,"aw",@progbits
	.globl	pa
pa:
	.short	1836                            ; 0x72c
	.size	pa, 2

	.type	pb,@object                      ; @pb
	.section	.data.pb,"aw",@progbits
	.globl	pb
pb:
	.short	2161                            ; 0x871
	.size	pb, 2

	.type	pc,@object                      ; @pc
	.section	.data.pc,"aw",@progbits
	.globl	pc
pc:
	.short	655                             ; 0x28f
	.size	pc, 2

	.type	gbase,@object                   ; @gbase
	.section	.data.gbase,"aw",@progbits
	.globl	gbase
gbase:
	.long	8265728                         ; 0x7e2000
	.size	gbase, 4

	.type	corpus_result,@object           ; @corpus_result
	.section	.bss.corpus_result,"aw",@nobits
	.globl	corpus_result
corpus_result:
	.short	0                               ; 0x0
	.size	corpus_result, 2

	.type	HOP_SQRT_LUT,@object            ; @HOP_SQRT_LUT
	.section	.rodata.HOP_SQRT_LUT,"a",@progbits
HOP_SQRT_LUT:
	.short	0                               ; 0x0
	.short	256                             ; 0x100
	.short	362                             ; 0x16a
	.short	443                             ; 0x1bb
	.short	512                             ; 0x200
	.short	572                             ; 0x23c
	.short	627                             ; 0x273
	.short	677                             ; 0x2a5
	.short	724                             ; 0x2d4
	.short	768                             ; 0x300
	.short	810                             ; 0x32a
	.short	849                             ; 0x351
	.short	887                             ; 0x377
	.short	923                             ; 0x39b
	.short	958                             ; 0x3be
	.short	991                             ; 0x3df
	.short	1024                            ; 0x400
	.short	1056                            ; 0x420
	.short	1086                            ; 0x43e
	.short	1116                            ; 0x45c
	.short	1145                            ; 0x479
	.short	1173                            ; 0x495
	.short	1201                            ; 0x4b1
	.short	1228                            ; 0x4cc
	.short	1254                            ; 0x4e6
	.short	1280                            ; 0x500
	.short	1305                            ; 0x519
	.short	1330                            ; 0x532
	.short	1355                            ; 0x54b
	.short	1379                            ; 0x563
	.short	1402                            ; 0x57a
	.short	1425                            ; 0x591
	.short	1448                            ; 0x5a8
	.short	1471                            ; 0x5bf
	.short	1493                            ; 0x5d5
	.short	1515                            ; 0x5eb
	.short	1536                            ; 0x600
	.short	1557                            ; 0x615
	.short	1578                            ; 0x62a
	.short	1599                            ; 0x63f
	.short	1619                            ; 0x653
	.short	1639                            ; 0x667
	.short	1659                            ; 0x67b
	.short	1679                            ; 0x68f
	.short	1698                            ; 0x6a2
	.short	1717                            ; 0x6b5
	.short	1736                            ; 0x6c8
	.short	1755                            ; 0x6db
	.short	1774                            ; 0x6ee
	.short	1792                            ; 0x700
	.short	1810                            ; 0x712
	.short	1828                            ; 0x724
	.short	1846                            ; 0x736
	.short	1864                            ; 0x748
	.short	1881                            ; 0x759
	.short	1899                            ; 0x76b
	.short	1916                            ; 0x77c
	.short	1933                            ; 0x78d
	.short	1950                            ; 0x79e
	.short	1966                            ; 0x7ae
	.short	1983                            ; 0x7bf
	.short	1999                            ; 0x7cf
	.short	2016                            ; 0x7e0
	.short	2032                            ; 0x7f0
	.short	2048                            ; 0x800
	.short	2064                            ; 0x810
	.short	2080                            ; 0x820
	.short	2095                            ; 0x82f
	.short	2111                            ; 0x83f
	.short	2126                            ; 0x84e
	.short	2142                            ; 0x85e
	.short	2157                            ; 0x86d
	.short	2172                            ; 0x87c
	.short	2187                            ; 0x88b
	.short	2202                            ; 0x89a
	.short	2217                            ; 0x8a9
	.short	2232                            ; 0x8b8
	.short	2246                            ; 0x8c6
	.short	2261                            ; 0x8d5
	.short	2275                            ; 0x8e3
	.short	2290                            ; 0x8f2
	.short	2304                            ; 0x900
	.short	2318                            ; 0x90e
	.short	2332                            ; 0x91c
	.short	2346                            ; 0x92a
	.short	2360                            ; 0x938
	.short	2374                            ; 0x946
	.short	2388                            ; 0x954
	.short	2401                            ; 0x961
	.short	2415                            ; 0x96f
	.short	2429                            ; 0x97d
	.short	2442                            ; 0x98a
	.short	2455                            ; 0x997
	.short	2469                            ; 0x9a5
	.short	2482                            ; 0x9b2
	.short	2495                            ; 0x9bf
	.short	2508                            ; 0x9cc
	.short	2521                            ; 0x9d9
	.short	2534                            ; 0x9e6
	.short	2547                            ; 0x9f3
	.short	2560                            ; 0xa00
	.short	2573                            ; 0xa0d
	.short	2585                            ; 0xa19
	.short	2598                            ; 0xa26
	.short	2611                            ; 0xa33
	.short	2623                            ; 0xa3f
	.short	2636                            ; 0xa4c
	.short	2648                            ; 0xa58
	.short	2660                            ; 0xa64
	.short	2673                            ; 0xa71
	.short	2685                            ; 0xa7d
	.short	2697                            ; 0xa89
	.short	2709                            ; 0xa95
	.short	2721                            ; 0xaa1
	.short	2733                            ; 0xaad
	.short	2745                            ; 0xab9
	.short	2757                            ; 0xac5
	.short	2769                            ; 0xad1
	.short	2781                            ; 0xadd
	.short	2793                            ; 0xae9
	.short	2804                            ; 0xaf4
	.short	2816                            ; 0xb00
	.short	2828                            ; 0xb0c
	.short	2839                            ; 0xb17
	.short	2851                            ; 0xb23
	.short	2862                            ; 0xb2e
	.short	2874                            ; 0xb3a
	.short	2885                            ; 0xb45
	.short	2896                            ; 0xb50
	.short	2908                            ; 0xb5c
	.short	2919                            ; 0xb67
	.short	2930                            ; 0xb72
	.short	2941                            ; 0xb7d
	.short	2952                            ; 0xb88
	.short	2963                            ; 0xb93
	.short	2974                            ; 0xb9e
	.short	2985                            ; 0xba9
	.short	2996                            ; 0xbb4
	.short	3007                            ; 0xbbf
	.short	3018                            ; 0xbca
	.short	3029                            ; 0xbd5
	.short	3040                            ; 0xbe0
	.short	3051                            ; 0xbeb
	.short	3061                            ; 0xbf5
	.short	3072                            ; 0xc00
	.short	3083                            ; 0xc0b
	.short	3093                            ; 0xc15
	.short	3104                            ; 0xc20
	.short	3114                            ; 0xc2a
	.short	3125                            ; 0xc35
	.short	3135                            ; 0xc3f
	.short	3146                            ; 0xc4a
	.short	3156                            ; 0xc54
	.short	3167                            ; 0xc5f
	.short	3177                            ; 0xc69
	.short	3187                            ; 0xc73
	.short	3197                            ; 0xc7d
	.short	3208                            ; 0xc88
	.short	3218                            ; 0xc92
	.short	3228                            ; 0xc9c
	.short	3238                            ; 0xca6
	.short	3248                            ; 0xcb0
	.short	3258                            ; 0xcba
	.short	3268                            ; 0xcc4
	.short	3278                            ; 0xcce
	.short	3288                            ; 0xcd8
	.short	3298                            ; 0xce2
	.short	3308                            ; 0xcec
	.short	3318                            ; 0xcf6
	.short	3328                            ; 0xd00
	.short	3338                            ; 0xd0a
	.short	3348                            ; 0xd14
	.short	3357                            ; 0xd1d
	.short	3367                            ; 0xd27
	.short	3377                            ; 0xd31
	.short	3387                            ; 0xd3b
	.short	3396                            ; 0xd44
	.short	3406                            ; 0xd4e
	.short	3415                            ; 0xd57
	.short	3425                            ; 0xd61
	.short	3435                            ; 0xd6b
	.short	3444                            ; 0xd74
	.short	3454                            ; 0xd7e
	.short	3463                            ; 0xd87
	.short	3473                            ; 0xd91
	.short	3482                            ; 0xd9a
	.short	3491                            ; 0xda3
	.short	3501                            ; 0xdad
	.short	3510                            ; 0xdb6
	.short	3519                            ; 0xdbf
	.short	3529                            ; 0xdc9
	.short	3538                            ; 0xdd2
	.short	3547                            ; 0xddb
	.short	3556                            ; 0xde4
	.short	3566                            ; 0xdee
	.short	3575                            ; 0xdf7
	.short	3584                            ; 0xe00
	.short	3593                            ; 0xe09
	.short	3602                            ; 0xe12
	.short	3611                            ; 0xe1b
	.short	3620                            ; 0xe24
	.short	3629                            ; 0xe2d
	.short	3638                            ; 0xe36
	.short	3647                            ; 0xe3f
	.short	3656                            ; 0xe48
	.short	3665                            ; 0xe51
	.short	3674                            ; 0xe5a
	.short	3683                            ; 0xe63
	.short	3692                            ; 0xe6c
	.short	3701                            ; 0xe75
	.short	3710                            ; 0xe7e
	.short	3719                            ; 0xe87
	.short	3727                            ; 0xe8f
	.short	3736                            ; 0xe98
	.short	3745                            ; 0xea1
	.short	3754                            ; 0xeaa
	.short	3762                            ; 0xeb2
	.short	3771                            ; 0xebb
	.short	3780                            ; 0xec4
	.short	3788                            ; 0xecc
	.short	3797                            ; 0xed5
	.short	3806                            ; 0xede
	.short	3814                            ; 0xee6
	.short	3823                            ; 0xeef
	.short	3831                            ; 0xef7
	.short	3840                            ; 0xf00
	.short	3849                            ; 0xf09
	.short	3857                            ; 0xf11
	.short	3866                            ; 0xf1a
	.short	3874                            ; 0xf22
	.short	3882                            ; 0xf2a
	.short	3891                            ; 0xf33
	.short	3899                            ; 0xf3b
	.short	3908                            ; 0xf44
	.short	3916                            ; 0xf4c
	.short	3924                            ; 0xf54
	.short	3933                            ; 0xf5d
	.short	3941                            ; 0xf65
	.short	3949                            ; 0xf6d
	.short	3958                            ; 0xf76
	.short	3966                            ; 0xf7e
	.short	3974                            ; 0xf86
	.short	3982                            ; 0xf8e
	.short	3991                            ; 0xf97
	.short	3999                            ; 0xf9f
	.short	4007                            ; 0xfa7
	.short	4015                            ; 0xfaf
	.short	4023                            ; 0xfb7
	.short	4031                            ; 0xfbf
	.short	4040                            ; 0xfc8
	.short	4048                            ; 0xfd0
	.short	4056                            ; 0xfd8
	.short	4064                            ; 0xfe0
	.short	4072                            ; 0xfe8
	.short	4080                            ; 0xff0
	.short	4088                            ; 0xff8
	.size	HOP_SQRT_LUT, 512

	.type	.Lstatic_stack,@object          ; @static_stack
	.section	.noinit..Lstatic_stack,"aw",@nobits
.Lstatic_stack:
	.zero	28
	.size	.Lstatic_stack, 28

.Lhop_step_sstk = .Lstatic_stack+20
	.size	.Lhop_step_sstk, 8
.Lsample_sstk = .Lstatic_stack
	.size	.Lsample_sstk, 20
	.section	.debug_abbrev,"",@progbits
	.byte	1                               ; Abbreviation Code
	.byte	17                              ; DW_TAG_compile_unit
	.byte	1                               ; DW_CHILDREN_yes
	.byte	37                              ; DW_AT_producer
	.byte	37                              ; DW_FORM_strx1
	.byte	19                              ; DW_AT_language
	.byte	5                               ; DW_FORM_data2
	.byte	3                               ; DW_AT_name
	.byte	37                              ; DW_FORM_strx1
	.byte	114                             ; DW_AT_str_offsets_base
	.byte	23                              ; DW_FORM_sec_offset
	.byte	16                              ; DW_AT_stmt_list
	.byte	23                              ; DW_FORM_sec_offset
	.byte	27                              ; DW_AT_comp_dir
	.byte	37                              ; DW_FORM_strx1
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	85                              ; DW_AT_ranges
	.byte	35                              ; DW_FORM_rnglistx
	.byte	115                             ; DW_AT_addr_base
	.byte	23                              ; DW_FORM_sec_offset
	.byte	116                             ; DW_AT_rnglists_base
	.byte	23                              ; DW_FORM_sec_offset
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	2                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	0                               ; DW_CHILDREN_no
	.byte	3                               ; DW_AT_name
	.byte	37                              ; DW_FORM_strx1
	.byte	32                              ; DW_AT_inline
	.byte	33                              ; DW_FORM_implicit_const
	.byte	1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	3                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	1                               ; DW_CHILDREN_yes
	.byte	17                              ; DW_AT_low_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.byte	122                             ; DW_AT_call_all_calls
	.byte	25                              ; DW_FORM_flag_present
	.byte	3                               ; DW_AT_name
	.byte	37                              ; DW_FORM_strx1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	4                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	17                              ; DW_AT_low_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	5                               ; Abbreviation Code
	.byte	72                              ; DW_TAG_call_site
	.byte	0                               ; DW_CHILDREN_no
	.byte	127                             ; DW_AT_call_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	125                             ; DW_AT_call_return_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	6                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	0                               ; DW_CHILDREN_no
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	0                               ; EOM(3)
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.long	.Ldebug_info_end0-.Ldebug_info_start0 ; Length of Unit
.Ldebug_info_start0:
	.short	5                               ; DWARF version number
	.byte	1                               ; DWARF Unit Type
	.byte	4                               ; Address Size (in bytes)
	.long	.debug_abbrev                   ; Offset Into Abbrev. Section
	.byte	1                               ; Abbrev [1] 0xc:0x47 DW_TAG_compile_unit
	.byte	0                               ; DW_AT_producer
	.short	29                              ; DW_AT_language
	.byte	1                               ; DW_AT_name
	.long	.Lstr_offsets_base0             ; DW_AT_str_offsets_base
	.long	.Lline_table_start0             ; DW_AT_stmt_list
	.byte	2                               ; DW_AT_comp_dir
	.long	0                               ; DW_AT_low_pc
	.byte	0                               ; DW_AT_ranges
	.long	.Laddr_table_base0              ; DW_AT_addr_base
	.long	.Lrnglists_table_base0          ; DW_AT_rnglists_base
	.byte	2                               ; Abbrev [2] 0x27:0x2 DW_TAG_subprogram
	.byte	3                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	3                               ; Abbrev [3] 0x29:0x28 DW_TAG_subprogram
	.byte	2                               ; DW_AT_low_pc
	.long	.Lfunc_end2-.Lfunc_begin2       ; DW_AT_high_pc
                                        ; DW_AT_call_all_calls
	.byte	4                               ; DW_AT_name
	.byte	4                               ; Abbrev [4] 0x30:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	3                               ; DW_AT_low_pc
	.long	.Ltmp8-.Ltmp7                   ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	47                              ; DW_AT_call_line
	.byte	18                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x3d:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	4                               ; DW_AT_low_pc
	.long	.Ltmp10-.Ltmp9                  ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	47                              ; DW_AT_call_line
	.byte	37                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x4a:0x6 DW_TAG_call_site
	.long	81                              ; DW_AT_call_origin
	.byte	5                               ; DW_AT_call_return_pc
	.byte	0                               ; End Of Children Mark
	.byte	6                               ; Abbrev [6] 0x51:0x1 DW_TAG_subprogram
	.byte	0                               ; End Of Children Mark
.Ldebug_info_end0:
	.section	.debug_rnglists,"",@progbits
	.long	.Ldebug_list_header_end0-.Ldebug_list_header_start0 ; Length
.Ldebug_list_header_start0:
	.short	5                               ; Version
	.byte	4                               ; Address size
	.byte	0                               ; Segment selector size
	.long	1                               ; Offset entry count
.Lrnglists_table_base0:
	.long	.Ldebug_ranges0-.Lrnglists_table_base0
.Ldebug_ranges0:
	.byte	3                               ; DW_RLE_startx_length
	.byte	0                               ;   start index
	.uleb128 .Lfunc_end0-.Lfunc_begin0      ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	1                               ;   start index
	.uleb128 .Lfunc_end1-.Lfunc_begin1      ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	2                               ;   start index
	.uleb128 .Lfunc_end2-.Lfunc_begin2      ;   length
	.byte	3                               ; DW_RLE_startx_length
	.byte	6                               ;   start index
	.uleb128 .Lfunc_end3-.Lfunc_begin3      ;   length
	.byte	0                               ; DW_RLE_end_of_list
.Ldebug_list_header_end0:
	.section	.debug_str_offsets,"",@progbits
	.long	24                              ; Length of String Offsets Set
	.short	5
	.short	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)" ; string offset=0 ; clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)
.Linfo_string1:
	.asciz	"/work/examples/65816/farblit_press.c" ; string offset=108 ; /work/examples/65816/farblit_press.c
.Linfo_string2:
	.asciz	"/work"                         ; string offset=145 ; /work
.Linfo_string3:
	.asciz	"hop_map"                       ; string offset=151 ; hop_map
.Linfo_string4:
	.asciz	"sample"                        ; string offset=159 ; sample
	.section	.debug_str_offsets,"",@progbits
	.long	.Linfo_string0
	.long	.Linfo_string1
	.long	.Linfo_string2
	.long	.Linfo_string3
	.long	.Linfo_string4
	.section	.debug_addr,"",@progbits
	.long	.Ldebug_addr_end0-.Ldebug_addr_start0 ; Length of contribution
.Ldebug_addr_start0:
	.short	5                               ; DWARF version number
	.byte	4                               ; Address size
	.byte	0                               ; Segment selector size
.Laddr_table_base0:
	.long	.Lfunc_begin0
	.long	.Lfunc_begin1
	.long	.Lfunc_begin2
	.long	.Ltmp7
	.long	.Ltmp9
	.long	.Ltmp6
	.long	.Lfunc_begin3
.Ldebug_addr_end0:
	.ident	"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym pa
	.addrsig_sym pb
	.addrsig_sym pc
	.addrsig_sym gbase
	.addrsig_sym corpus_result
	.addrsig_sym .Lstatic_stack
	;Declaring this symbol tells the CRT that there is something in .bss, so it may need to be zeroed.
	.globl	__do_zero_bss
	;Declaring this symbol tells the CRT that there is something in .data, so it may need to be copied from LMA to VMA.
	.globl	__do_copy_data
	;Declaring this symbol tells the CRT that the stack pointer needs to be initialized.
	.globl	__do_init_stack
	.section	.debug_line,"",@progbits
.Lline_table_start0:
