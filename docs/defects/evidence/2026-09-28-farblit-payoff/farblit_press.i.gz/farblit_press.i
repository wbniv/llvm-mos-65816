# 1 "/home/will/llvm-mos-65816/examples/65816/farblit_press.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 365 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/will/llvm-mos-65816/examples/65816/farblit_press.c" 2
# 20 "/home/will/llvm-mos-65816/examples/65816/farblit_press.c"
# 1 "/home/will/llvm-mos-65816/examples/65816/hopalong.h" 1
# 21 "/home/will/llvm-mos-65816/examples/65816/hopalong.h"
# 1 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 1 3
# 100 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 3
typedef long long int int64_t;

typedef long long unsigned int uint64_t;
# 122 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 3
typedef int64_t int_least64_t;
typedef uint64_t uint_least64_t;
typedef int64_t int_fast64_t;
typedef uint64_t uint_fast64_t;
# 197 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 3
typedef long int int32_t;




typedef long unsigned int uint32_t;
# 220 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 3
typedef int32_t int_least32_t;
typedef uint32_t uint_least32_t;
typedef int32_t int_fast32_t;
typedef uint32_t uint_fast32_t;
# 245 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 3
typedef int int16_t;

typedef unsigned int uint16_t;
# 259 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 3
typedef int16_t int_least16_t;
typedef uint16_t uint_least16_t;
typedef int16_t int_fast16_t;
typedef uint16_t uint_fast16_t;





typedef signed char int8_t;

typedef unsigned char uint8_t;







typedef int8_t int_least8_t;
typedef uint8_t uint_least8_t;
typedef int8_t int_fast8_t;
typedef uint8_t uint_fast8_t;
# 295 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 3
typedef int intptr_t;






typedef unsigned int uintptr_t;





typedef long long int intmax_t;
typedef long long unsigned int uintmax_t;
# 22 "/home/will/llvm-mos-65816/examples/65816/hopalong.h" 2
# 48 "/home/will/llvm-mos-65816/examples/65816/hopalong.h"
static const unsigned short HOP_SQRT_LUT[256] = {
  0x0000, 0x0100, 0x016A, 0x01BB, 0x0200, 0x023C, 0x0273, 0x02A5,
  0x02D4, 0x0300, 0x032A, 0x0351, 0x0377, 0x039B, 0x03BE, 0x03DF,
  0x0400, 0x0420, 0x043E, 0x045C, 0x0479, 0x0495, 0x04B1, 0x04CC,
  0x04E6, 0x0500, 0x0519, 0x0532, 0x054B, 0x0563, 0x057A, 0x0591,
  0x05A8, 0x05BF, 0x05D5, 0x05EB, 0x0600, 0x0615, 0x062A, 0x063F,
  0x0653, 0x0667, 0x067B, 0x068F, 0x06A2, 0x06B5, 0x06C8, 0x06DB,
  0x06EE, 0x0700, 0x0712, 0x0724, 0x0736, 0x0748, 0x0759, 0x076B,
  0x077C, 0x078D, 0x079E, 0x07AE, 0x07BF, 0x07CF, 0x07E0, 0x07F0,
  0x0800, 0x0810, 0x0820, 0x082F, 0x083F, 0x084E, 0x085E, 0x086D,
  0x087C, 0x088B, 0x089A, 0x08A9, 0x08B8, 0x08C6, 0x08D5, 0x08E3,
  0x08F2, 0x0900, 0x090E, 0x091C, 0x092A, 0x0938, 0x0946, 0x0954,
  0x0961, 0x096F, 0x097D, 0x098A, 0x0997, 0x09A5, 0x09B2, 0x09BF,
  0x09CC, 0x09D9, 0x09E6, 0x09F3, 0x0A00, 0x0A0D, 0x0A19, 0x0A26,
  0x0A33, 0x0A3F, 0x0A4C, 0x0A58, 0x0A64, 0x0A71, 0x0A7D, 0x0A89,
  0x0A95, 0x0AA1, 0x0AAD, 0x0AB9, 0x0AC5, 0x0AD1, 0x0ADD, 0x0AE9,
  0x0AF4, 0x0B00, 0x0B0C, 0x0B17, 0x0B23, 0x0B2E, 0x0B3A, 0x0B45,
  0x0B50, 0x0B5C, 0x0B67, 0x0B72, 0x0B7D, 0x0B88, 0x0B93, 0x0B9E,
  0x0BA9, 0x0BB4, 0x0BBF, 0x0BCA, 0x0BD5, 0x0BE0, 0x0BEB, 0x0BF5,
  0x0C00, 0x0C0B, 0x0C15, 0x0C20, 0x0C2A, 0x0C35, 0x0C3F, 0x0C4A,
  0x0C54, 0x0C5F, 0x0C69, 0x0C73, 0x0C7D, 0x0C88, 0x0C92, 0x0C9C,
  0x0CA6, 0x0CB0, 0x0CBA, 0x0CC4, 0x0CCE, 0x0CD8, 0x0CE2, 0x0CEC,
  0x0CF6, 0x0D00, 0x0D0A, 0x0D14, 0x0D1D, 0x0D27, 0x0D31, 0x0D3B,
  0x0D44, 0x0D4E, 0x0D57, 0x0D61, 0x0D6B, 0x0D74, 0x0D7E, 0x0D87,
  0x0D91, 0x0D9A, 0x0DA3, 0x0DAD, 0x0DB6, 0x0DBF, 0x0DC9, 0x0DD2,
  0x0DDB, 0x0DE4, 0x0DEE, 0x0DF7, 0x0E00, 0x0E09, 0x0E12, 0x0E1B,
  0x0E24, 0x0E2D, 0x0E36, 0x0E3F, 0x0E48, 0x0E51, 0x0E5A, 0x0E63,
  0x0E6C, 0x0E75, 0x0E7E, 0x0E87, 0x0E8F, 0x0E98, 0x0EA1, 0x0EAA,
  0x0EB2, 0x0EBB, 0x0EC4, 0x0ECC, 0x0ED5, 0x0EDE, 0x0EE6, 0x0EEF,
  0x0EF7, 0x0F00, 0x0F09, 0x0F11, 0x0F1A, 0x0F22, 0x0F2A, 0x0F33,
  0x0F3B, 0x0F44, 0x0F4C, 0x0F54, 0x0F5D, 0x0F65, 0x0F6D, 0x0F76,
  0x0F7E, 0x0F86, 0x0F8E, 0x0F97, 0x0F9F, 0x0FA7, 0x0FAF, 0x0FB7,
  0x0FBF, 0x0FC8, 0x0FD0, 0x0FD8, 0x0FE0, 0x0FE8, 0x0FF0, 0x0FF8,
};



typedef struct { short x, y; } hop_pt;
# 96 "/home/will/llvm-mos-65816/examples/65816/hopalong.h"
__attribute__((noinline)) static void hop_step(hop_pt *p, short a, short b, short c) {
  short x = p->x, y = p->y;
  int32_t bx = ((int32_t)b * (int32_t)x) >> 8;
  int32_t arg = bx - (int32_t)c;
  int32_t aarg = arg < 0 ? -arg : arg;
  unsigned short idx = (unsigned short)(aarg >> 8);
  if (idx > 255) {
    idx = 255;



  }
  short s = (short)HOP_SQRT_LUT[idx];

  short term = x > 0 ? s : (x < 0 ? (short)-s : (short)0);
  p->x = (short)(y - term);
  p->y = (short)(a - x);
# 121 "/home/will/llvm-mos-65816/examples/65816/hopalong.h"
}
# 145 "/home/will/llvm-mos-65816/examples/65816/hopalong.h"
static inline int16_t hop_map(short v) {
  return (int16_t)((int16_t)(v >> 7) + (128 / 2));
}
# 21 "/home/will/llvm-mos-65816/examples/65816/farblit_press.c" 2



volatile short pa = 0x072C, pb = 0x0871, pc = 0x028F;
volatile uint32_t gbase = 0x7E2000u;
# 35 "/home/will/llvm-mos-65816/examples/65816/farblit_press.c"
__attribute__((noinline)) static void fill(__attribute__((address_space(2))) uint8_t *g) {
  uint16_t i = 0;
  do {
    g[i] = (uint8_t)(i ^ (i >> 7));
  } while (++i != ((uint16_t)((uint32_t)128 * (uint32_t)128)));
}

__attribute__((noinline)) static uint16_t sample(__attribute__((address_space(2))) uint8_t *g, short a, short b, short c) {
  hop_pt p = {0, 0};
  uint16_t h = 0;
  for (uint16_t n = 0; n < 1500; n++) {
    hop_step(&p, a, b, c);
    int16_t px = hop_map(p.x), py = hop_map(p.y);
    if ((uint16_t)px < (uint16_t)128 && (uint16_t)py < (uint16_t)128) {
      uint16_t idx = (uint16_t)((unsigned)py * 128 + (unsigned)px);
      h = (uint16_t)((((unsigned)h << 1) | ((unsigned)h >> 15)) ^ (unsigned)g[idx]);
    }
  }
  return h;
}
# 65 "/home/will/llvm-mos-65816/examples/65816/farblit_press.c"
volatile uint16_t corpus_result;
int main(void) {
  __attribute__((address_space(2))) uint8_t *g = (__attribute__((address_space(2))) uint8_t *)gbase;
  fill(g);
  corpus_result = sample(g, pa, pb, pc);
  for (;;) __asm__ volatile("wai");
}
