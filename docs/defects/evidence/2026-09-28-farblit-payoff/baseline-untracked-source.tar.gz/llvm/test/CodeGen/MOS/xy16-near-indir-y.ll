; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16,+mos-xy16 -verify-machineinstrs < %s | FileCheck %s
; RUN: llc -mtriple=mos -mcpu=mosw65816 -mattr=+mos-a16,+mos-xy16 -stop-after=instruction-select -verify-machineinstrs -o - %s | FileCheck %s --check-prefix=MIR

; A 16-bit runtime index in an Imag16 pair must become one fused operation.
; The fusion keeps an X8 spill or reload from clearing the high byte of Y
; between its load and the near (zp),Y access.

target datalayout = "e-m:e-p:16:8-p1:8:8-p2:32:8-p3:24:8-i16:8-i32:8-i64:8-f32:8-f64:8-a:8-Fi8-n8"

define i8 @near_load(ptr %p, i16 %i) {
; MIR-LABEL: name: near_load
; MIR: LDIndirYIdxFused {{.*}}implicit-def $y16 :: (load (s8)
; CHECK-LABEL: near_load:
; CHECK: rep #16
; CHECK-NEXT: ldy __rc{{[0-9]+}}
; CHECK-NEXT: lda (__rc{{[0-9]+}}),y
; CHECK-NEXT: sep #16
; CHECK: rts
  %q = getelementptr nuw i8, ptr %p, i16 %i
  %v = load i8, ptr %q
  ret i8 %v
}

define void @near_store(ptr %p, i16 %i, i8 %v) {
; MIR-LABEL: name: near_store
; MIR: STIndirYIdxFused {{.*}}implicit-def $y16 :: (store (s8)
; CHECK-LABEL: near_store:
; CHECK: rep #16
; CHECK-NEXT: ldy __rc{{[0-9]+}}
; CHECK-NEXT: sta (__rc{{[0-9]+}}),y
; CHECK-NEXT: sep #16
; CHECK: rts
  %q = getelementptr nuw i8, ptr %p, i16 %i
  store i8 %v, ptr %q
  ret void
}

; Word accesses require M=16 as well as X=16. The Y load must remain adjacent
; to the access while the value enters or leaves the accumulator separately.
define i16 @near_load_word(ptr %p, i16 %i) {
; MIR-LABEL: name: near_load_word
; MIR: LDIndirYIdx16Fused {{.*}}implicit-def $y16 :: (volatile load (s16)
; CHECK-LABEL: near_load_word:
; CHECK: rep #48
; CHECK-NEXT: ldy __rc{{[0-9]+}}
; CHECK-NEXT: lda (__rc{{[0-9]+}}),y
; CHECK: sep #48
; CHECK: rts
  %q = getelementptr nuw i8, ptr %p, i16 %i
  %v = load volatile i16, ptr %q, align 1
  ret i16 %v
}

define void @near_store_word(ptr %p, i16 %i, i16 %v) {
; MIR-LABEL: name: near_store_word
; MIR: STIndirYIdx16Fused {{.*}}implicit-def $y16 :: (volatile store (s16)
; CHECK-LABEL: near_store_word:
; CHECK: ldy __rc{{[0-9]+}}
; CHECK-NEXT: sta (__rc{{[0-9]+}}),y
; CHECK: sep #48
; CHECK: rts
  %q = getelementptr nuw i8, ptr %p, i16 %i
  store volatile i16 %v, ptr %q, align 1
  ret void
}

; Near pointer arithmetic truncates the address to 16 bits. Inbounds permits a
; negative offset, while native (dp),Y carries an unsigned sum into DBR.
; Form the full near address before the access when unsigned wrap is possible.
define i8 @near_load_wrapping(ptr %p, i16 %i) {
; MIR-LABEL: name: near_load_wrapping
; MIR-NOT: LDIndirYIdx
; MIR: LDIndir {{.*}} :: (load (s8)
; CHECK-LABEL: near_load_wrapping:
; CHECK-NOT: ),y
; CHECK: lda (__rc{{[0-9]+}})
; CHECK: rts
  %q = getelementptr inbounds i8, ptr %p, i16 %i
  %v = load i8, ptr %q
  ret i8 %v
}

define void @near_store_wrapping(ptr %p, i16 %i, i8 %v) {
; MIR-LABEL: name: near_store_wrapping
; MIR-NOT: STIndirYIdx
; MIR: STIndir {{.*}} :: (store (s8)
; CHECK-LABEL: near_store_wrapping:
; CHECK-NOT: ),y
; CHECK: sta (__rc{{[0-9]+}})
; CHECK: rts
  %q = getelementptr i8, ptr %p, i16 %i
  store i8 %v, ptr %q
  ret void
}

define i16 @near_load_word_wrapping(ptr %p, i16 %i) {
; MIR-LABEL: name: near_load_word_wrapping
; MIR-NOT: LDIndirYIdx
; MIR: LDAIndir16 {{.*}} :: (volatile load (s16)
; CHECK-LABEL: near_load_word_wrapping:
; CHECK-NOT: ),y
; CHECK: lda (__rc{{[0-9]+}})
; CHECK: rts
  %q = getelementptr inbounds i8, ptr %p, i16 %i
  %v = load volatile i16, ptr %q, align 1
  ret i16 %v
}

define void @near_store_word_wrapping(ptr %p, i16 %i, i16 %v) {
; MIR-LABEL: name: near_store_word_wrapping
; MIR-NOT: STIndirYIdx
; MIR: STAIndir16 {{.*}} :: (volatile store (s16)
; CHECK-LABEL: near_store_word_wrapping:
; CHECK-NOT: ),y
; CHECK: sta (__rc{{[0-9]+}})
; CHECK: rts
  %q = getelementptr i8, ptr %p, i16 %i
  store volatile i16 %v, ptr %q, align 1
  ret void
}
