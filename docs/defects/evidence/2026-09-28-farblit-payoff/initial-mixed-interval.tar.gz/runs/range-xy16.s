	.zeropage	__rc0
	.zeropage	__rc1
	.zeropage	__rc2
	.zeropage	__rc3
	.zeropage	__rc4
	.zeropage	__rc5
	.zeropage	__rc6
	.zeropage	__rc7
	.zeropage	__rc8
	.zeropage	__rc9
	.zeropage	__rc10
	.zeropage	__rc11
	.zeropage	__rc12
	.zeropage	__rc13
	.zeropage	__rc14
	.zeropage	__rc15
	.zeropage	__rc16
	.zeropage	__rc17
	.zeropage	__rc18
	.zeropage	__rc19
	.zeropage	__rc20
	.zeropage	__rc21
	.zeropage	__rc22
	.zeropage	__rc23
	.zeropage	__rc24
	.zeropage	__rc25
	.zeropage	__rc26
	.zeropage	__rc27
	.zeropage	__rc28
	.zeropage	__rc29
	.zeropage	__rc30
	.zeropage	__rc31
	.file	"farblit.c"
	.text
	.globl	main                            ; -- Begin function main
	.type	main,@function
main:                                   ; @main
.Lfunc_begin0:
	.file	0 "/home/will/llvm-mos-65816" "examples/65816/farblit.c" md5 0x07b076447efbbb883855b4932d02de6c
	.loc	0 225 0                         ; examples/65816/farblit.c:225:0
; %bb.0:
	clc
	lda	__rc0
	adc	#240
	sta	__rc0
	lda	__rc1
	adc	#255
	sta	__rc1
	stz	__rc7
.Ltmp0:
	.loc	0 49 35 prologue_end            ; examples/65816/farblit.c:49:35 @[ examples/65816/farblit.c:186:19 @[ examples/65816/farblit.c:226:19 ] ]
	ldx	rbase8
	stx	__rc2
	ldx	rbase8+1
	stx	__rc3
	ldx	rbase8+2
	stx	__rc4
	ldx	rbase8+3
	stx	__rc5
	.loc	0 49 33 is_stmt 0               ; examples/65816/farblit.c:49:33 @[ examples/65816/farblit.c:186:19 @[ examples/65816/farblit.c:226:19 ] ]
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc2
	sta	__rc8
	lda	#mos24segmenthi(tbl)
	adc	__rc3
	sta	__rc9
	lda	#mos24bank(tbl)
	adc	__rc4
	sta	__rc10
	lda	#0
	adc	__rc5
	sta	__rc11
	ldy	#0
	stz	__rc4
	stz	__rc5
	stz	__rc2
	tyx
.LBB0_1:                                ; =>This Inner Loop Header: Depth=1
	.loc	0 52 21                         ; examples/65816/farblit.c:52:21 @[ examples/65816/farblit.c:186:19 @[ examples/65816/farblit.c:226:19 ] ]
	lda	[__rc8],y
	sta	__rc6
	txa
.Ltmp1:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:52:11 @[ examples/65816/farblit.c:186:19 @[ examples/65816/farblit.c:226:19 ] ] ]
	cpx	#128
	rol	__rc4
	rol	__rc5
	rol	__rc2
	rol
	sta	__rc3
	rep	#32
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:52:11 @[ examples/65816/farblit.c:186:19 @[ examples/65816/farblit.c:226:19 ] ] ]
	lda	__rc4
	eor	__rc6
	sta	__rc4
	lda	__rc2
	eor	#mos16(0)
	sta	__rc2
	sep	#32
.Ltmp2:
	.loc	0 51 32                         ; examples/65816/farblit.c:51:32 @[ examples/65816/farblit.c:186:19 @[ examples/65816/farblit.c:226:19 ] ]
	iny
	ldx	__rc3
	cpy	#64
	bne	.LBB0_1
.Ltmp3:
; %bb.2:
                                        ; kill: def $rs2 killed $rs2
	.loc	0 0 32 is_stmt 0                ; examples/65816/farblit.c:0:32
	lda	__rc4
	ldy	#4
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc5
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
                                        ; kill: def $rs1 killed $rs1
	lda	__rc2
	ldy	#10
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc3
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
	stz	__rc11
	ldx	#0
	stz	__rc4
	stz	__rc5
	stz	__rc2
	txy
.LBB0_3:                                ; =>This Inner Loop Header: Depth=1
.Ltmp4:
	.loc	0 58 21                         ; examples/65816/farblit.c:58:21 @[ examples/65816/farblit.c:187:19 @[ examples/65816/farblit.c:226:19 ] ]
	lda	mos24(tbl),x
	sta	__rc10
	tya
.Ltmp5:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:58:11 @[ examples/65816/farblit.c:187:19 @[ examples/65816/farblit.c:226:19 ] ] ]
	cpy	#128
	rol	__rc4
	rol	__rc5
	rol	__rc2
	rol
	sta	__rc3
	rep	#32
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:58:11 @[ examples/65816/farblit.c:187:19 @[ examples/65816/farblit.c:226:19 ] ] ]
	lda	__rc4
	eor	__rc10
	sta	__rc4
	lda	__rc2
	eor	#mos16(0)
	sta	__rc2
	sep	#32
.Ltmp6:
	.loc	0 57 32                         ; examples/65816/farblit.c:57:32 @[ examples/65816/farblit.c:187:19 @[ examples/65816/farblit.c:226:19 ] ]
	inx
	ldy	__rc3
	cpx	#64
	bne	.LBB0_3
.Ltmp7:
; %bb.4:
                                        ; kill: def $rs2 killed $rs2
	.loc	0 0 32 is_stmt 0                ; examples/65816/farblit.c:0:32
	lda	__rc4
	ldy	#0
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc5
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
                                        ; kill: def $rs1 killed $rs1
	lda	__rc2
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc3
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
.Ltmp8:
	.loc	0 62 35 is_stmt 1               ; examples/65816/farblit.c:62:35 @[ examples/65816/farblit.c:188:19 @[ examples/65816/farblit.c:226:19 ] ]
	ldx	rbase16
	stx	__rc4
	ldx	rbase16+1
	stx	__rc5
	ldx	rbase16+2
	stx	__rc6
	ldx	rbase16+3
	stx	__rc7
	.loc	0 62 33 is_stmt 0               ; examples/65816/farblit.c:62:33 @[ examples/65816/farblit.c:188:19 @[ examples/65816/farblit.c:226:19 ] ]
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc4
	sta	__rc20
	lda	#mos24segmenthi(tbl)
	adc	__rc5
	sta	__rc21
	lda	#mos24bank(tbl)
	adc	__rc6
	sta	__rc22
	lda	#0
	adc	__rc7
	sta	__rc23
	stz	__rc15
	stz	__rc14
	stz	__rc12
	stz	__rc13
	stz	__rc2
	ldy	#0
.LBB0_5:                                ; =>This Inner Loop Header: Depth=1
	.loc	0 65 25                         ; examples/65816/farblit.c:65:25 @[ examples/65816/farblit.c:188:19 @[ examples/65816/farblit.c:226:19 ] ]
	ldx	#mos16lo(offs16)
	stx	__rc4
	ldx	#mos16hi(offs16)
	stx	__rc5
	tyx
	rep	#32
	lda	__rc4
	clc
	adc	__rc14
	sta	__rc4
	lda	(__rc4)
	sta	__rc4
	sep	#32
	rep	#16
	.loc	0 65 21                         ; examples/65816/farblit.c:65:21 @[ examples/65816/farblit.c:188:19 @[ examples/65816/farblit.c:226:19 ] ]
	ldy	__rc4
	lda	[__rc20],y
	sta	__rc4
	txa
	sep	#16
.Ltmp9:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:65:11 @[ examples/65816/farblit.c:188:19 @[ examples/65816/farblit.c:226:19 ] ] ]
	cpx	#128
	rol	__rc12
	rol	__rc13
	rol	__rc2
	rol
	sta	__rc3
	stz	__rc5
	rep	#32
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:65:11 @[ examples/65816/farblit.c:188:19 @[ examples/65816/farblit.c:226:19 ] ] ]
	lda	__rc12
	eor	__rc4
	sta	__rc12
	lda	__rc2
	eor	#mos16(0)
	sta	__rc2
	sep	#32
.Ltmp10:
	.loc	0 64 3                          ; examples/65816/farblit.c:64:3 @[ examples/65816/farblit.c:188:19 @[ examples/65816/farblit.c:226:19 ] ]
	ldx	__rc14
	inx
	inx
	stx	__rc14
	ldy	__rc3
	cpx	#16
	beq	.LBB0_6
.Ltmp11:
; %bb.22:                               ;   in Loop: Header=BB0_5 Depth=1
	.loc	0 0 3 is_stmt 0                 ; examples/65816/farblit.c:0:3
	jmp	.LBB0_5
.LBB0_6:
.Ltmp12:
	.loc	0 69 35 is_stmt 1               ; examples/65816/farblit.c:69:35 @[ examples/65816/farblit.c:189:19 @[ examples/65816/farblit.c:226:19 ] ]
	lda	rbasew
	ldx	rbasew+1
	.loc	0 69 33 is_stmt 0               ; examples/65816/farblit.c:69:33 @[ examples/65816/farblit.c:189:19 @[ examples/65816/farblit.c:226:19 ] ]
	asl
	sta	__rc4
	.loc	0 69 35                         ; examples/65816/farblit.c:69:35 @[ examples/65816/farblit.c:189:19 @[ examples/65816/farblit.c:226:19 ] ]
	ldy	rbasew+2
	sty	__rc6
	stx	__rc5
	.loc	0 69 33                         ; examples/65816/farblit.c:69:33 @[ examples/65816/farblit.c:189:19 @[ examples/65816/farblit.c:226:19 ] ]
	rol	__rc5
	.loc	0 69 35                         ; examples/65816/farblit.c:69:35 @[ examples/65816/farblit.c:189:19 @[ examples/65816/farblit.c:226:19 ] ]
	lda	rbasew+3
	.loc	0 69 33                         ; examples/65816/farblit.c:69:33 @[ examples/65816/farblit.c:189:19 @[ examples/65816/farblit.c:226:19 ] ]
	rol	__rc6
	rol
	sta	__rc7
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc4
	tay
	lda	#mos24segmenthi(tbl)
	adc	__rc5
	sta	__rc14
	lda	#mos24bank(tbl)
	adc	__rc6
	sta	__rc15
	lda	#0
	adc	__rc7
	sta	__rc24
	ldx	#0
	stz	__rc20
	stz	__rc21
	stz	__rc22
	txa
.LBB0_7:                                ; =>This Inner Loop Header: Depth=1
	.loc	0 0 33                          ; examples/65816/farblit.c:0:33
	sta	__rc23
	.loc	0 72 21                         ; examples/65816/farblit.c:72:21 @[ examples/65816/farblit.c:189:19 @[ examples/65816/farblit.c:226:19 ] ]
	txa
	asl
	sta	__rc4
	lda	#0
	rol
	sta	__rc5
	stz	__rc6
	rol	__rc6
	stz	__rc7
	rol	__rc7
	tya
	clc
	adc	__rc4
	sta	__rc4
	lda	__rc14
	adc	__rc5
	sta	__rc5
	lda	__rc15
	adc	__rc6
	sta	__rc6
	lda	__rc24
	adc	__rc7
	sta	__rc7
	rep	#32
	lda	[__rc4]
	sta	__rc4
	sep	#32
	lda	__rc23
.Ltmp13:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:72:11 @[ examples/65816/farblit.c:189:19 @[ examples/65816/farblit.c:226:19 ] ] ]
	cmp	#128
	rol	__rc20
	rol	__rc21
	rol	__rc22
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:72:11 @[ examples/65816/farblit.c:189:19 @[ examples/65816/farblit.c:226:19 ] ] ]
	sta	__rc23
	rep	#32
	lda	__rc20
	eor	__rc4
	sta	__rc4
	lda	__rc22
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp14:
	.loc	0 71 32                         ; examples/65816/farblit.c:71:32 @[ examples/65816/farblit.c:189:19 @[ examples/65816/farblit.c:226:19 ] ]
	inx
	lda	__rc4
	sta	__rc20
	lda	__rc5
	sta	__rc21
	lda	__rc6
	sta	__rc22
	lda	__rc7
	cpx	#64
	beq	.LBB0_8
.Ltmp15:
; %bb.24:                               ;   in Loop: Header=BB0_7 Depth=1
	.loc	0 0 32 is_stmt 0                ; examples/65816/farblit.c:0:32
	jmp	.LBB0_7
.LBB0_8:
                                        ; kill: def $rs3 killed $rs3
	lda	__rc6
	ldy	#6
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc7
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
                                        ; kill: def $rs2 killed $rs2
	lda	__rc4
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc5
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
.Ltmp16:
	.loc	0 76 35 is_stmt 1               ; examples/65816/farblit.c:76:35 @[ examples/65816/farblit.c:190:19 @[ examples/65816/farblit.c:226:19 ] ]
	ldx	rbasew16
	stx	__rc4
	ldx	rbasew16+1
	stx	__rc5
	ldx	rbasew16+2
	stx	__rc6
	ldx	rbasew16+3
	stx	__rc7
	.loc	0 76 33 is_stmt 0               ; examples/65816/farblit.c:76:33 @[ examples/65816/farblit.c:190:19 @[ examples/65816/farblit.c:226:19 ] ]
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc4
	sta	__rc24
	lda	#mos24segmenthi(tbl)
	adc	__rc5
	sta	__rc25
	lda	#mos24bank(tbl)
	adc	__rc6
	sta	__rc26
	lda	#0
	adc	__rc7
	sta	__rc27
	.loc	0 77 16 is_stmt 1               ; examples/65816/farblit.c:77:16 @[ examples/65816/farblit.c:190:19 @[ examples/65816/farblit.c:226:19 ] ]
	ldy	obase
	lda	obase+1
	ldx	#32
	stz	__rc29
	sty	__rc30
	sta	__rc31
	stz	__rc22
	stz	__rc23
	stz	__rc20
	ldy	#0
.LBB0_9:                                ; =>This Inner Loop Header: Depth=1
	.loc	0 0 16 is_stmt 0                ; examples/65816/farblit.c:0:16
	sty	__rc4
	rep	#16
	.loc	0 80 21                         ; examples/65816/farblit.c:80:21 @[ examples/65816/farblit.c:190:19 @[ examples/65816/farblit.c:226:19 ] ]
	ldy	__rc30
	lda	[__rc24],y
	sta	__rc28
	lda	__rc4
.Ltmp17:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:80:11 @[ examples/65816/farblit.c:190:19 @[ examples/65816/farblit.c:226:19 ] ] ]
	cmp	#128
	rol	__rc22
	rol	__rc23
	rol	__rc20
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:80:11 @[ examples/65816/farblit.c:190:19 @[ examples/65816/farblit.c:226:19 ] ] ]
	sta	__rc21
	rep	#32
	lda	__rc22
	eor	__rc28
	sta	__rc22
	lda	__rc20
	eor	#mos16(0)
	sta	__rc20
	sep	#48
.Ltmp18:
	.loc	0 79 25                         ; examples/65816/farblit.c:79:25 @[ examples/65816/farblit.c:190:19 @[ examples/65816/farblit.c:226:19 ] ]
	dex
	rep	#32
	lda	__rc30
	inc
	sta	__rc30
	sep	#32
	ldy	__rc21
	txa
	bne	.LBB0_9
.Ltmp19:
; %bb.10:
	.loc	0 84 16                         ; examples/65816/farblit.c:84:16 @[ examples/65816/farblit.c:191:19 @[ examples/65816/farblit.c:226:19 ] ]
	ldx	obase
	lda	obase+1
	ldy	#32
	stz	__rc29
	stx	__rc30
	sta	__rc31
	stz	__rc26
	stz	__rc27
	stz	__rc24
	lda	#0
.LBB0_11:                               ; =>This Inner Loop Header: Depth=1
	.loc	0 0 16 is_stmt 0                ; examples/65816/farblit.c:0:16
	rep	#16
	.loc	0 87 21                         ; examples/65816/farblit.c:87:21 @[ examples/65816/farblit.c:191:19 @[ examples/65816/farblit.c:226:19 ] ]
	ldx	__rc30
	sta	__rc4
	lda	mos24(tbl),x
	sta	__rc28
	lda	__rc4
.Ltmp20:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:87:11 @[ examples/65816/farblit.c:191:19 @[ examples/65816/farblit.c:226:19 ] ] ]
	cmp	#128
	rol	__rc26
	rol	__rc27
	rol	__rc24
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:87:11 @[ examples/65816/farblit.c:191:19 @[ examples/65816/farblit.c:226:19 ] ] ]
	sta	__rc25
	rep	#32
	lda	__rc26
	eor	__rc28
	sta	__rc26
	lda	__rc24
	eor	#mos16(0)
	sta	__rc24
	sep	#48
.Ltmp21:
	.loc	0 86 25                         ; examples/65816/farblit.c:86:25 @[ examples/65816/farblit.c:191:19 @[ examples/65816/farblit.c:226:19 ] ]
	dey
	rep	#32
	lda	__rc30
	inc
	sta	__rc30
	sep	#32
	lda	__rc25
	tyx
	bne	.LBB0_11
.Ltmp22:
; %bb.12:
	.loc	0 91 35                         ; examples/65816/farblit.c:91:35 @[ examples/65816/farblit.c:192:19 @[ examples/65816/farblit.c:226:19 ] ]
	ldx	rbase8
	stx	__rc4
	ldx	rbase8+1
	stx	__rc5
	ldx	rbase8+2
	stx	__rc6
	ldx	rbase8+3
	stx	__rc7
	.loc	0 91 33 is_stmt 0               ; examples/65816/farblit.c:91:33 @[ examples/65816/farblit.c:192:19 @[ examples/65816/farblit.c:226:19 ] ]
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc4
	sta	__rc4
	lda	#mos24segmenthi(tbl)
	adc	__rc5
	sta	__rc5
	lda	#mos24bank(tbl)
	adc	__rc6
	sta	__rc6
	lda	#0
	adc	__rc7
	sta	__rc7
	.loc	0 92 15 is_stmt 1               ; examples/65816/farblit.c:92:15 @[ examples/65816/farblit.c:192:19 @[ examples/65816/farblit.c:226:19 ] ]
	ldy	k8
	ldx	#32
	stz	__rc31
	stz	__rc14
	stz	__rc15
	stz	__rc28
	lda	#0
.LBB0_13:                               ; =>This Inner Loop Header: Depth=1
	.loc	0 0 15 is_stmt 0                ; examples/65816/farblit.c:0:15
	sta	__rc8
	.loc	0 95 21                         ; examples/65816/farblit.c:95:21 @[ examples/65816/farblit.c:192:19 @[ examples/65816/farblit.c:226:19 ] ]
	lda	[__rc4],y
	sta	__rc30
	lda	__rc8
.Ltmp23:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:95:11 @[ examples/65816/farblit.c:192:19 @[ examples/65816/farblit.c:226:19 ] ] ]
	cmp	#128
	rol	__rc14
	rol	__rc15
	rol	__rc28
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:95:11 @[ examples/65816/farblit.c:192:19 @[ examples/65816/farblit.c:226:19 ] ] ]
	sta	__rc29
	rep	#32
	lda	__rc14
	eor	__rc30
	sta	__rc14
	lda	__rc28
	eor	#mos16(0)
	sta	__rc28
	sep	#32
.Ltmp24:
	.loc	0 94 25                         ; examples/65816/farblit.c:94:25 @[ examples/65816/farblit.c:192:19 @[ examples/65816/farblit.c:226:19 ] ]
	dex
	iny
	lda	__rc29
	cpx	#0
	bne	.LBB0_13
.Ltmp25:
; %bb.14:
	.loc	0 99 35                         ; examples/65816/farblit.c:99:35 @[ examples/65816/farblit.c:193:3 @[ examples/65816/farblit.c:226:19 ] ]
	ldx	wbase8
	stx	__rc4
	ldy	wbase8+1
	lda	wbase8+2
	ldx	wbase8+3
	sty	__rc5
	sta	__rc6
	stx	__rc7
	lda	#11
	ldy	#0
.LBB0_15:                               ; =>This Inner Loop Header: Depth=1
	.loc	0 101 10                        ; examples/65816/farblit.c:101:10 @[ examples/65816/farblit.c:193:3 @[ examples/65816/farblit.c:226:19 ] ]
	sta	[__rc4],y
	.loc	0 100 32                        ; examples/65816/farblit.c:100:32 @[ examples/65816/farblit.c:193:3 @[ examples/65816/farblit.c:226:19 ] ]
	iny
	.loc	0 100 25                        ; examples/65816/farblit.c:100:25 @[ examples/65816/farblit.c:193:3 @[ examples/65816/farblit.c:226:19 ] ]
	clc
	adc	#37
	cpy	#64
	bne	.LBB0_15
.Ltmp26:
; %bb.16:
	.loc	0 110 35                        ; examples/65816/farblit.c:110:35 @[ examples/65816/farblit.c:194:3 @[ examples/65816/farblit.c:226:19 ] ]
	ldx	wbase16
	stx	__rc8
	ldy	wbase16+1
	lda	wbase16+2
	ldx	wbase16+3
	sty	__rc9
	sta	__rc10
	stx	__rc11
                                        ; kill: def $rl2 killed $rl2
                                        ; kill: def $rs4 killed $rs4
	lda	__rc8
	ldy	#12
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc9
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
                                        ; kill: def $rs5 killed $rs5
	lda	__rc10
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
	lda	__rc11
	iny
	sta	(__rc0),y                       ; 1-byte Folded Spill
	stz	__rc31
	stz	__rc18
	stz	__rc30
	ldy	#12
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc8
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc9
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc10
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc11
.LBB0_17:                               ; =>This Inner Loop Header: Depth=1
	.loc	0 112 7                         ; examples/65816/farblit.c:112:7 @[ examples/65816/farblit.c:194:3 @[ examples/65816/farblit.c:226:19 ] ]
	ldx	#mos16lo(offs16)
	stx	__rc4
	ldx	#mos16hi(offs16)
	stx	__rc5
	rep	#32
	lda	__rc4
	clc
	adc	__rc30
	sta	__rc4
	lda	(__rc4)
	sta	__rc4
	sep	#32
	.loc	0 112 36 is_stmt 0              ; examples/65816/farblit.c:112:36 @[ examples/65816/farblit.c:194:3 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc18
	eor	#165
	rep	#16
	.loc	0 112 18                        ; examples/65816/farblit.c:112:18 @[ examples/65816/farblit.c:194:3 @[ examples/65816/farblit.c:226:19 ] ]
	ldy	__rc4
	sta	[__rc8],y
	sep	#16
	.loc	0 111 3 is_stmt 1               ; examples/65816/farblit.c:111:3 @[ examples/65816/farblit.c:194:3 @[ examples/65816/farblit.c:226:19 ] ]
	ldx	__rc30
	inx
	inx
	.loc	0 111 25                        ; examples/65816/farblit.c:111:25 @[ examples/65816/farblit.c:194:3 @[ examples/65816/farblit.c:226:19 ] ]
	clc
	lda	__rc18
	adc	#29
	sta	__rc18
	stx	__rc30
	cpx	#16
	bne	.LBB0_17
.Ltmp27:
; %bb.18:
	.loc	0 104 35                        ; examples/65816/farblit.c:104:35 @[ examples/65816/farblit.c:195:3 @[ examples/65816/farblit.c:226:19 ] ]
	ldx	wbasec
	ldy	wbasec+1
	lda	wbasec+2
	sta	__rc30
	lda	wbasec+3
	sta	__rc31
	.loc	0 105 35 is_stmt 0              ; examples/65816/farblit.c:105:35 @[ examples/65816/farblit.c:195:3 @[ examples/65816/farblit.c:226:19 ] ]
	lda	rbase8
	sta	__rc4
	lda	rbase8+1
	sta	__rc5
	lda	rbase8+2
	sta	__rc6
	lda	rbase8+3
	sta	__rc7
	.loc	0 105 33                        ; examples/65816/farblit.c:105:33 @[ examples/65816/farblit.c:195:3 @[ examples/65816/farblit.c:226:19 ] ]
	lda	#mos24segmentlo(tbl)
	clc
	adc	__rc4
	sta	__rc8
	lda	#mos24segmenthi(tbl)
	adc	__rc5
	sta	__rc9
	lda	#mos24bank(tbl)
	adc	__rc6
	sta	__rc10
	lda	#0
	adc	__rc7
	sta	__rc11
	.loc	0 104 35 is_stmt 1              ; examples/65816/farblit.c:104:35 @[ examples/65816/farblit.c:195:3 @[ examples/65816/farblit.c:226:19 ] ]
	stx	__rc4
	sty	__rc5
	ldx	__rc30
	stx	__rc6
	ldx	__rc31
	stx	__rc7
	ldy	#0
.LBB0_19:                               ; =>This Inner Loop Header: Depth=1
	.loc	0 107 12                        ; examples/65816/farblit.c:107:12 @[ examples/65816/farblit.c:195:3 @[ examples/65816/farblit.c:226:19 ] ]
	tya
	clc
	adc	#8
	tyx
	tay
	lda	[__rc8],y
	txy
	.loc	0 107 10 is_stmt 0              ; examples/65816/farblit.c:107:10 @[ examples/65816/farblit.c:195:3 @[ examples/65816/farblit.c:226:19 ] ]
	sta	[__rc4],y
	.loc	0 106 32 is_stmt 1              ; examples/65816/farblit.c:106:32 @[ examples/65816/farblit.c:195:3 @[ examples/65816/farblit.c:226:19 ] ]
	iny
	cpy	#48
	bne	.LBB0_19
.Ltmp28:
; %bb.20:
	.loc	0 0 32 is_stmt 0                ; examples/65816/farblit.c:0:32
	ldy	#10
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc6
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
.Ltmp29:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:187:9 @[ examples/65816/farblit.c:226:19 ] ]
	cmp	#128
	pha
	ldy	#4
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc8
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc9
	pla
	rol	__rc8
	rol	__rc9
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:187:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	ldy	#0
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc4
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc5
	rep	#32
	lda	__rc4
	eor	__rc8
	sta	__rc4
	sep	#32
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc8
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc9
	rep	#32
	lda	__rc8
	eor	__rc6
	sta	__rc6
	sep	#32
.Ltmp30:
	.loc	0 39 20                         ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:188:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:188:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc12
	eor	__rc4
	sta	__rc10
	lda	__rc2
	eor	__rc6
	sta	__rc4
	sep	#32
.Ltmp31:
	.loc	0 39 20                         ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:189:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc5
	cmp	#128
	rol	__rc10
	rol	__rc11
	rol	__rc4
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:189:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc5
	ldy	#8
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc6
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc7
	rep	#32
	lda	__rc6
	eor	__rc10
	sta	__rc2
	sep	#32
	ldy	#6
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc6
	iny
	lda	(__rc0),y                       ; 1-byte Folded Reload
	sta	__rc7
	rep	#32
	lda	__rc6
	eor	__rc4
	sta	__rc4
	sep	#32
.Ltmp32:
	.loc	0 39 20                         ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:190:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc5
	cmp	#128
	rol	__rc2
	rol	__rc3
	rol	__rc4
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:190:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc5
	rep	#32
	lda	__rc22
	eor	__rc2
	sta	__rc2
	lda	__rc20
	eor	__rc4
	sta	__rc4
	sep	#32
.Ltmp33:
	.loc	0 39 20                         ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:191:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc5
	cmp	#128
	rol	__rc2
	rol	__rc3
	rol	__rc4
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:191:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc5
	rep	#32
	lda	__rc26
	eor	__rc2
	sta	__rc2
	lda	__rc24
	eor	__rc4
	sta	__rc6
	sep	#32
.Ltmp34:
	.loc	0 39 20                         ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:192:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc2
	rol	__rc3
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:192:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc14
	eor	__rc2
	sta	__rc4
	lda	__rc28
	eor	__rc6
	sta	__rc6
	sep	#32
.Ltmp35:
	.loc	0 198 19 is_stmt 0              ; examples/65816/farblit.c:198:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8323040
	sta	__rc2
	stz	__rc3
.Ltmp36:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:198:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:198:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp37:
	.loc	0 199 19 is_stmt 0              ; examples/65816/farblit.c:199:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8323071
	sta	__rc2
.Ltmp38:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:199:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:199:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp39:
	.loc	0 200 19 is_stmt 0              ; examples/65816/farblit.c:200:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8323072
	sta	__rc2
.Ltmp40:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:200:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:200:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp41:
	.loc	0 201 19 is_stmt 0              ; examples/65816/farblit.c:201:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8323103
	sta	__rc2
.Ltmp42:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:201:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:201:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp43:
	.loc	0 202 19 is_stmt 0              ; examples/65816/farblit.c:202:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8273920
	sta	__rc2
.Ltmp44:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:202:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:202:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp45:
	.loc	0 203 19 is_stmt 0              ; examples/65816/farblit.c:203:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8274175
	sta	__rc2
.Ltmp46:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:203:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:203:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp47:
	.loc	0 204 19 is_stmt 0              ; examples/65816/farblit.c:204:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8274176
	sta	__rc2
.Ltmp48:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:204:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:204:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp49:
	.loc	0 205 19 is_stmt 0              ; examples/65816/farblit.c:205:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8278580
	sta	__rc2
.Ltmp50:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:205:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:205:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp51:
	.loc	0 206 19 is_stmt 0              ; examples/65816/farblit.c:206:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8306687
	sta	__rc2
.Ltmp52:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:206:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:206:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp53:
	.loc	0 207 19 is_stmt 0              ; examples/65816/farblit.c:207:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8306688
	sta	__rc2
.Ltmp54:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:207:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:207:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp55:
	.loc	0 208 19 is_stmt 0              ; examples/65816/farblit.c:208:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8323073
	sta	__rc2
.Ltmp56:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:208:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:208:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp57:
	.loc	0 209 19 is_stmt 0              ; examples/65816/farblit.c:209:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8339455
	sta	__rc2
.Ltmp58:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:209:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:209:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp59:
	.loc	0 210 19 is_stmt 0              ; examples/65816/farblit.c:210:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8355824
	sta	__rc2
.Ltmp60:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:210:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:210:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp61:
	.loc	0 211 19 is_stmt 0              ; examples/65816/farblit.c:211:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8355847
	sta	__rc2
.Ltmp62:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:211:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:211:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp63:
	.loc	0 212 19 is_stmt 0              ; examples/65816/farblit.c:212:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8355848
	sta	__rc2
.Ltmp64:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:212:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:212:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc4
	lda	__rc6
	eor	#mos16(0)
	sta	__rc6
	sep	#32
.Ltmp65:
	.loc	0 213 19 is_stmt 0              ; examples/65816/farblit.c:213:19 @[ examples/65816/farblit.c:226:19 ]
	lda	8355871
	sta	__rc2
.Ltmp66:
	.loc	0 39 20 is_stmt 1               ; examples/65816/farblit.c:39:20 @[ examples/65816/farblit.c:213:9 @[ examples/65816/farblit.c:226:19 ] ]
	lda	__rc7
	cmp	#128
	rol	__rc4
	rol	__rc5
	rol	__rc6
	rol
	.loc	0 40 14                         ; examples/65816/farblit.c:40:14 @[ examples/65816/farblit.c:213:9 @[ examples/65816/farblit.c:226:19 ] ]
	sta	__rc7
	rep	#32
	lda	__rc4
	eor	__rc2
	sta	__rc2
	lda	__rc6
	eor	#mos16(0)
	sta	__rc4
	sep	#32
.Ltmp67:
	.loc	0 226 17                        ; examples/65816/farblit.c:226:17
	ldx	__rc2
	ldy	__rc3
	lda	__rc4
	stx	corpus_result
	sty	corpus_result+1
	sta	corpus_result+2
	ldx	__rc5
	stx	corpus_result+3
.LBB0_21:                               ; =>This Inner Loop Header: Depth=1
	.loc	0 227 12                        ; examples/65816/farblit.c:227:12
	;APP
	wai
	;NO_APP
	.loc	0 227 3                         ; examples/65816/farblit.c:227:3
	bra	.LBB0_21
.Ltmp68:
.Lfunc_end0:
	.size	main, .Lfunc_end0-main
                                        ; -- End function
	.type	rbase8,@object                  ; @rbase8
	.data
	.globl	rbase8
rbase8:
	.long	65504                           ; 0xffe0
	.size	rbase8, 4

	.type	rbase16,@object                 ; @rbase16
	.globl	rbase16
rbase16:
	.long	32768                           ; 0x8000
	.size	rbase16, 4

	.type	rbasew,@object                  ; @rbasew
	.globl	rbasew
rbasew:
	.long	32736                           ; 0x7fe0
	.size	rbasew, 4

	.type	wbase8,@object                  ; @wbase8
	.globl	wbase8
wbase8:
	.long	8323040                         ; 0x7effe0
	.size	wbase8, 4

	.type	wbase16,@object                 ; @wbase16
	.globl	wbase16
wbase16:
	.long	8273920                         ; 0x7e4000
	.size	wbase16, 4

	.type	wbasec,@object                  ; @wbasec
	.globl	wbasec
wbasec:
	.long	8355824                         ; 0x7f7ff0
	.size	wbasec, 4

	.type	rbasew16,@object                ; @rbasew16
	.globl	rbasew16
rbasew16:
	.long	65536                           ; 0x10000
	.size	rbasew16, 4

	.type	obase,@object                   ; @obase
	.globl	obase
obase:
	.short	65520                           ; 0xfff0
	.size	obase, 2

	.type	k8,@object                      ; @k8
	.globl	k8
k8:
	.byte	240                             ; 0xf0
	.size	k8, 1

	.type	corpus_result,@object           ; @corpus_result
	.bss
	.globl	corpus_result
corpus_result:
	.long	0                               ; 0x0
	.size	corpus_result, 4

	.type	offs16,@object                  ; @offs16
	.section	.rodata.cst16,"aM",@progbits,16
offs16:
	.short	0                               ; 0x0
	.short	255                             ; 0xff
	.short	256                             ; 0x100
	.short	4660                            ; 0x1234
	.short	32767                           ; 0x7fff
	.short	32768                           ; 0x8000
	.short	49153                           ; 0xc001
	.short	65535                           ; 0xffff
	.size	offs16, 16

	.section	.debug_abbrev,"",@progbits
	.byte	1                               ; Abbreviation Code
	.byte	17                              ; DW_TAG_compile_unit
	.byte	1                               ; DW_CHILDREN_yes
	.byte	37                              ; DW_AT_producer
	.byte	37                              ; DW_FORM_strx1
	.byte	19                              ; DW_AT_language
	.byte	5                               ; DW_FORM_data2
	.byte	3                               ; DW_AT_name
	.byte	37                              ; DW_FORM_strx1
	.byte	114                             ; DW_AT_str_offsets_base
	.byte	23                              ; DW_FORM_sec_offset
	.byte	16                              ; DW_AT_stmt_list
	.byte	23                              ; DW_FORM_sec_offset
	.byte	27                              ; DW_AT_comp_dir
	.byte	37                              ; DW_FORM_strx1
	.byte	17                              ; DW_AT_low_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.byte	115                             ; DW_AT_addr_base
	.byte	23                              ; DW_FORM_sec_offset
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	2                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	0                               ; DW_CHILDREN_no
	.byte	3                               ; DW_AT_name
	.byte	37                              ; DW_FORM_strx1
	.byte	32                              ; DW_AT_inline
	.byte	33                              ; DW_FORM_implicit_const
	.byte	1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	3                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	1                               ; DW_CHILDREN_yes
	.byte	17                              ; DW_AT_low_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.byte	122                             ; DW_AT_call_all_calls
	.byte	25                              ; DW_FORM_flag_present
	.byte	3                               ; DW_AT_name
	.byte	37                              ; DW_FORM_strx1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	4                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	1                               ; DW_CHILDREN_yes
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	17                              ; DW_AT_low_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	5                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	17                              ; DW_AT_low_pc
	.byte	27                              ; DW_FORM_addrx
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	0                               ; EOM(3)
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.long	.Ldebug_info_end0-.Ldebug_info_start0 ; Length of Unit
.Ldebug_info_start0:
	.short	5                               ; DWARF version number
	.byte	1                               ; DWARF Unit Type
	.byte	4                               ; Address Size (in bytes)
	.long	.debug_abbrev                   ; Offset Into Abbrev. Section
	.byte	1                               ; Abbrev [1] 0xc:0x248 DW_TAG_compile_unit
	.byte	0                               ; DW_AT_producer
	.short	29                              ; DW_AT_language
	.byte	1                               ; DW_AT_name
	.long	.Lstr_offsets_base0             ; DW_AT_str_offsets_base
	.long	.Lline_table_start0             ; DW_AT_stmt_list
	.byte	2                               ; DW_AT_comp_dir
	.byte	0                               ; DW_AT_low_pc
	.long	.Lfunc_end0-.Lfunc_begin0       ; DW_AT_high_pc
	.long	.Laddr_table_base0              ; DW_AT_addr_base
	.byte	2                               ; Abbrev [2] 0x23:0x2 DW_TAG_subprogram
	.byte	3                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x25:0x2 DW_TAG_subprogram
	.byte	4                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x27:0x2 DW_TAG_subprogram
	.byte	5                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x29:0x2 DW_TAG_subprogram
	.byte	6                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x2b:0x2 DW_TAG_subprogram
	.byte	7                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x2d:0x2 DW_TAG_subprogram
	.byte	8                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x2f:0x2 DW_TAG_subprogram
	.byte	9                               ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x31:0x2 DW_TAG_subprogram
	.byte	10                              ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x33:0x2 DW_TAG_subprogram
	.byte	11                              ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x35:0x2 DW_TAG_subprogram
	.byte	12                              ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x37:0x2 DW_TAG_subprogram
	.byte	13                              ; DW_AT_name
                                        ; DW_AT_inline
	.byte	2                               ; Abbrev [2] 0x39:0x2 DW_TAG_subprogram
	.byte	14                              ; DW_AT_name
                                        ; DW_AT_inline
	.byte	3                               ; Abbrev [3] 0x3b:0x218 DW_TAG_subprogram
	.byte	0                               ; DW_AT_low_pc
	.long	.Lfunc_end0-.Lfunc_begin0       ; DW_AT_high_pc
                                        ; DW_AT_call_all_calls
	.byte	15                              ; DW_AT_name
	.byte	4                               ; Abbrev [4] 0x42:0x210 DW_TAG_inlined_subroutine
	.long	37                              ; DW_AT_abstract_origin
	.byte	1                               ; DW_AT_low_pc
	.long	.Ltmp67-.Ltmp0                  ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	226                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	4                               ; Abbrev [4] 0x4f:0x1b DW_TAG_inlined_subroutine
	.long	35                              ; DW_AT_abstract_origin
	.byte	1                               ; DW_AT_low_pc
	.long	.Ltmp3-.Ltmp0                   ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	186                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x5c:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	2                               ; DW_AT_low_pc
	.long	.Ltmp2-.Ltmp1                   ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	52                              ; DW_AT_call_line
	.byte	11                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	4                               ; Abbrev [4] 0x6a:0x1b DW_TAG_inlined_subroutine
	.long	41                              ; DW_AT_abstract_origin
	.byte	3                               ; DW_AT_low_pc
	.long	.Ltmp7-.Ltmp4                   ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	187                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x77:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	4                               ; DW_AT_low_pc
	.long	.Ltmp6-.Ltmp5                   ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	58                              ; DW_AT_call_line
	.byte	11                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	4                               ; Abbrev [4] 0x85:0x1b DW_TAG_inlined_subroutine
	.long	43                              ; DW_AT_abstract_origin
	.byte	5                               ; DW_AT_low_pc
	.long	.Ltmp11-.Ltmp8                  ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	188                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x92:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	6                               ; DW_AT_low_pc
	.long	.Ltmp10-.Ltmp9                  ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	65                              ; DW_AT_call_line
	.byte	11                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	4                               ; Abbrev [4] 0xa0:0x1b DW_TAG_inlined_subroutine
	.long	45                              ; DW_AT_abstract_origin
	.byte	7                               ; DW_AT_low_pc
	.long	.Ltmp15-.Ltmp12                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	189                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0xad:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	8                               ; DW_AT_low_pc
	.long	.Ltmp14-.Ltmp13                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	72                              ; DW_AT_call_line
	.byte	11                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	4                               ; Abbrev [4] 0xbb:0x1b DW_TAG_inlined_subroutine
	.long	47                              ; DW_AT_abstract_origin
	.byte	9                               ; DW_AT_low_pc
	.long	.Ltmp19-.Ltmp16                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	190                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0xc8:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	10                              ; DW_AT_low_pc
	.long	.Ltmp18-.Ltmp17                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	80                              ; DW_AT_call_line
	.byte	11                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	4                               ; Abbrev [4] 0xd6:0x1b DW_TAG_inlined_subroutine
	.long	49                              ; DW_AT_abstract_origin
	.byte	11                              ; DW_AT_low_pc
	.long	.Ltmp22-.Ltmp19                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	191                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0xe3:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	12                              ; DW_AT_low_pc
	.long	.Ltmp21-.Ltmp20                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	87                              ; DW_AT_call_line
	.byte	11                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	4                               ; Abbrev [4] 0xf1:0x1b DW_TAG_inlined_subroutine
	.long	51                              ; DW_AT_abstract_origin
	.byte	13                              ; DW_AT_low_pc
	.long	.Ltmp25-.Ltmp22                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	192                             ; DW_AT_call_line
	.byte	19                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0xfe:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	14                              ; DW_AT_low_pc
	.long	.Ltmp24-.Ltmp23                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	95                              ; DW_AT_call_line
	.byte	11                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0x10c:0xd DW_TAG_inlined_subroutine
	.long	53                              ; DW_AT_abstract_origin
	.byte	15                              ; DW_AT_low_pc
	.long	.Ltmp26-.Ltmp25                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	193                             ; DW_AT_call_line
	.byte	3                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x119:0xd DW_TAG_inlined_subroutine
	.long	55                              ; DW_AT_abstract_origin
	.byte	16                              ; DW_AT_low_pc
	.long	.Ltmp27-.Ltmp26                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	194                             ; DW_AT_call_line
	.byte	3                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x126:0xd DW_TAG_inlined_subroutine
	.long	57                              ; DW_AT_abstract_origin
	.byte	17                              ; DW_AT_low_pc
	.long	.Ltmp28-.Ltmp27                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	195                             ; DW_AT_call_line
	.byte	3                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x133:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	18                              ; DW_AT_low_pc
	.long	.Ltmp30-.Ltmp29                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	187                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x140:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_AT_low_pc
	.long	.Ltmp31-.Ltmp30                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	188                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x14d:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	20                              ; DW_AT_low_pc
	.long	.Ltmp32-.Ltmp31                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	189                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x15a:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	21                              ; DW_AT_low_pc
	.long	.Ltmp33-.Ltmp32                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	190                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x167:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	22                              ; DW_AT_low_pc
	.long	.Ltmp34-.Ltmp33                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	191                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x174:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	23                              ; DW_AT_low_pc
	.long	.Ltmp35-.Ltmp34                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	192                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x181:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	24                              ; DW_AT_low_pc
	.long	.Ltmp37-.Ltmp36                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	198                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x18e:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	25                              ; DW_AT_low_pc
	.long	.Ltmp39-.Ltmp38                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	199                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x19b:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	26                              ; DW_AT_low_pc
	.long	.Ltmp41-.Ltmp40                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	200                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1a8:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	27                              ; DW_AT_low_pc
	.long	.Ltmp43-.Ltmp42                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	201                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1b5:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	28                              ; DW_AT_low_pc
	.long	.Ltmp45-.Ltmp44                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	202                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1c2:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	29                              ; DW_AT_low_pc
	.long	.Ltmp47-.Ltmp46                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	203                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1cf:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	30                              ; DW_AT_low_pc
	.long	.Ltmp49-.Ltmp48                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	204                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1dc:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	31                              ; DW_AT_low_pc
	.long	.Ltmp51-.Ltmp50                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	205                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1e9:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	32                              ; DW_AT_low_pc
	.long	.Ltmp53-.Ltmp52                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	206                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x1f6:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	33                              ; DW_AT_low_pc
	.long	.Ltmp55-.Ltmp54                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	207                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x203:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	34                              ; DW_AT_low_pc
	.long	.Ltmp57-.Ltmp56                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	208                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x210:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	35                              ; DW_AT_low_pc
	.long	.Ltmp59-.Ltmp58                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	209                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x21d:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	36                              ; DW_AT_low_pc
	.long	.Ltmp61-.Ltmp60                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	210                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x22a:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	37                              ; DW_AT_low_pc
	.long	.Ltmp63-.Ltmp62                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	211                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x237:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	38                              ; DW_AT_low_pc
	.long	.Ltmp65-.Ltmp64                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	212                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x244:0xd DW_TAG_inlined_subroutine
	.long	39                              ; DW_AT_abstract_origin
	.byte	39                              ; DW_AT_low_pc
	.long	.Ltmp67-.Ltmp66                 ; DW_AT_high_pc
	.byte	0                               ; DW_AT_call_file
	.byte	213                             ; DW_AT_call_line
	.byte	9                               ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
.Ldebug_info_end0:
	.section	.debug_str_offsets,"",@progbits
	.long	68                              ; Length of String Offsets Set
	.short	5
	.short	0
.Lstr_offsets_base0:
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)" ; string offset=0 ; clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)
.Linfo_string1:
	.asciz	"examples/65816/farblit.c"      ; string offset=108 ; examples/65816/farblit.c
.Linfo_string2:
	.asciz	"/home/will/llvm-mos-65816"     ; string offset=133 ; /home/will/llvm-mos-65816
.Linfo_string3:
	.asciz	"rd8"                           ; string offset=159 ; rd8
.Linfo_string4:
	.asciz	"run"                           ; string offset=163 ; run
.Linfo_string5:
	.asciz	"fold"                          ; string offset=167 ; fold
.Linfo_string6:
	.asciz	"rdg"                           ; string offset=172 ; rdg
.Linfo_string7:
	.asciz	"rd16"                          ; string offset=176 ; rd16
.Linfo_string8:
	.asciz	"rdw"                           ; string offset=181 ; rdw
.Linfo_string9:
	.asciz	"rdw16"                         ; string offset=185 ; rdw16
.Linfo_string10:
	.asciz	"rdw16g"                        ; string offset=191 ; rdw16g
.Linfo_string11:
	.asciz	"rdw8"                          ; string offset=198 ; rdw8
.Linfo_string12:
	.asciz	"wr8"                           ; string offset=203 ; wr8
.Linfo_string13:
	.asciz	"wr16"                          ; string offset=207 ; wr16
.Linfo_string14:
	.asciz	"cp8"                           ; string offset=212 ; cp8
.Linfo_string15:
	.asciz	"main"                          ; string offset=216 ; main
	.section	.debug_str_offsets,"",@progbits
	.long	.Linfo_string0
	.long	.Linfo_string1
	.long	.Linfo_string2
	.long	.Linfo_string3
	.long	.Linfo_string4
	.long	.Linfo_string5
	.long	.Linfo_string6
	.long	.Linfo_string7
	.long	.Linfo_string8
	.long	.Linfo_string9
	.long	.Linfo_string10
	.long	.Linfo_string11
	.long	.Linfo_string12
	.long	.Linfo_string13
	.long	.Linfo_string14
	.long	.Linfo_string15
	.section	.debug_addr,"",@progbits
	.long	.Ldebug_addr_end0-.Ldebug_addr_start0 ; Length of contribution
.Ldebug_addr_start0:
	.short	5                               ; DWARF version number
	.byte	4                               ; Address size
	.byte	0                               ; Segment selector size
.Laddr_table_base0:
	.long	.Lfunc_begin0
	.long	.Ltmp0
	.long	.Ltmp1
	.long	.Ltmp4
	.long	.Ltmp5
	.long	.Ltmp8
	.long	.Ltmp9
	.long	.Ltmp12
	.long	.Ltmp13
	.long	.Ltmp16
	.long	.Ltmp17
	.long	.Ltmp19
	.long	.Ltmp20
	.long	.Ltmp22
	.long	.Ltmp23
	.long	.Ltmp25
	.long	.Ltmp26
	.long	.Ltmp27
	.long	.Ltmp29
	.long	.Ltmp30
	.long	.Ltmp31
	.long	.Ltmp32
	.long	.Ltmp33
	.long	.Ltmp34
	.long	.Ltmp36
	.long	.Ltmp38
	.long	.Ltmp40
	.long	.Ltmp42
	.long	.Ltmp44
	.long	.Ltmp46
	.long	.Ltmp48
	.long	.Ltmp50
	.long	.Ltmp52
	.long	.Ltmp54
	.long	.Ltmp56
	.long	.Ltmp58
	.long	.Ltmp60
	.long	.Ltmp62
	.long	.Ltmp64
	.long	.Ltmp66
.Ldebug_addr_end0:
	.ident	"clang version 23.0.0git (https://github.com/llvm-mos/llvm-mos.git 8be0546128a55e78c63ca571d466aa72a782cd36)"
	.section	".note.GNU-stack","",@progbits
	;Declaring this symbol tells the CRT that there is something in .bss, so it may need to be zeroed.
	.globl	__do_zero_bss
	;Declaring this symbol tells the CRT that there is something in .data, so it may need to be copied from LMA to VMA.
	.globl	__do_copy_data
	;Declaring this symbol tells the CRT that the stack pointer needs to be initialized.
	.globl	__do_init_stack
	.section	.debug_line,"",@progbits
.Lline_table_start0:
