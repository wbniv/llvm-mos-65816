# 1 "/home/will/llvm-mos-65816/.scratch/farblit-payoff/source/bounds.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 365 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/will/llvm-mos-65816/.scratch/farblit-payoff/source/bounds.c" 2
# 1 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 1 3
# 100 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 3
typedef long long int int64_t;

typedef long long unsigned int uint64_t;
# 122 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 3
typedef int64_t int_least64_t;
typedef uint64_t uint_least64_t;
typedef int64_t int_fast64_t;
typedef uint64_t uint_fast64_t;
# 197 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 3
typedef long int int32_t;




typedef long unsigned int uint32_t;
# 220 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 3
typedef int32_t int_least32_t;
typedef uint32_t uint_least32_t;
typedef int32_t int_fast32_t;
typedef uint32_t uint_fast32_t;
# 245 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 3
typedef int int16_t;

typedef unsigned int uint16_t;
# 259 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 3
typedef int16_t int_least16_t;
typedef uint16_t uint_least16_t;
typedef int16_t int_fast16_t;
typedef uint16_t uint_fast16_t;





typedef signed char int8_t;

typedef unsigned char uint8_t;







typedef int8_t int_least8_t;
typedef uint8_t uint_least8_t;
typedef int8_t int_fast8_t;
typedef uint8_t uint_fast8_t;
# 295 "/home/will/llvm-mos-65816/build/llvm-mos-install/lib/clang/23/include/stdint.h" 3
typedef int intptr_t;






typedef unsigned int uintptr_t;





typedef long long int intmax_t;
typedef long long unsigned int uintmax_t;
# 2 "/home/will/llvm-mos-65816/.scratch/farblit-payoff/source/bounds.c" 2


volatile uint32_t rbase = 0xFFFFu;
volatile uint32_t wbase = 0x7EFF80u;
# 25 "/home/will/llvm-mos-65816/.scratch/farblit-payoff/source/bounds.c"
extern const __attribute__((address_space(2))) uint16_t tbl[];
# 34 "/home/will/llvm-mos-65816/.scratch/farblit-payoff/source/bounds.c"
static uint16_t mix16(uint16_t h, uint16_t v) {
  return (uint16_t)((uint16_t)(h << 3) | (h >> 13)) ^ v;
}
static uint32_t mix32(uint32_t h, uint16_t v) {
  return ((h << 5) | (h >> 27)) ^ v;
}

__attribute__((noinline)) uint16_t word128(void) {
  const __attribute__((address_space(2))) uint16_t *src = (const __attribute__((address_space(2))) uint16_t *)((const __attribute__((address_space(2))) uint8_t *)tbl + rbase); uint16_t h = 0;
  for (uint8_t j = 0; j < 128; ++j) h = mix16(h, src[j]);
  return h;
}

__attribute__((noinline)) uint16_t word129(void) {
  const __attribute__((address_space(2))) uint16_t *src = (const __attribute__((address_space(2))) uint16_t *)((const __attribute__((address_space(2))) uint8_t *)tbl + rbase); uint16_t h = 0;
  for (uint8_t j = 0; j < 129; ++j) h = mix16(h, src[j]);
  return h;
}

__attribute__((noinline)) uint16_t word_wrap(void) {
  const __attribute__((address_space(2))) uint16_t *src = (const __attribute__((address_space(2))) uint16_t *)((const __attribute__((address_space(2))) uint8_t *)tbl + rbase); uint16_t h = 0; uint8_t j = 250;
  do { h = mix16(h, src[j]); } while (++j != 6);
  return h;
}
__attribute__((noinline)) uint16_t word256(void) {
  const __attribute__((address_space(2))) uint16_t *src = (const __attribute__((address_space(2))) uint16_t *)((const __attribute__((address_space(2))) uint8_t *)tbl + rbase); uint16_t h = 0; uint8_t j = 0;
  do { h = mix16(h, src[j]); } while (++j != 0);
  return h;
}

__attribute__((noinline)) uint16_t word_wrapped_index(void) {
  const __attribute__((address_space(2))) uint16_t *src = (const __attribute__((address_space(2))) uint16_t *)((const __attribute__((address_space(2))) uint8_t *)tbl + rbase); uint16_t h = 0;
  for (uint8_t j = 0; j < 64; ++j) h = mix16(h, src[(uint8_t)(j + 248)]);
  return h;
}

__attribute__((noinline)) uint16_t word_step2(void) {
  const __attribute__((address_space(2))) uint16_t *src = (const __attribute__((address_space(2))) uint16_t *)((const __attribute__((address_space(2))) uint8_t *)tbl + rbase); uint16_t h = 0;
  for (uint8_t j = 0; j != 64; j += 2) h = mix16(h, src[j]);
  return h;
}
__attribute__((noinline)) void copy248(void) {
  const __attribute__((address_space(2))) uint8_t *src = (const __attribute__((address_space(2))) uint8_t *)tbl + rbase; __attribute__((address_space(2))) uint8_t *dst = (__attribute__((address_space(2))) uint8_t *)wbase;
  for (uint8_t j = 0; j < 248; ++j) (dst[j] = (src[(uint16_t)j + 8]));
}
__attribute__((noinline)) void copy249(void) {
  const __attribute__((address_space(2))) uint8_t *src = (const __attribute__((address_space(2))) uint8_t *)tbl + rbase; __attribute__((address_space(2))) uint8_t *dst = (__attribute__((address_space(2))) uint8_t *)wbase;
  for (uint8_t j = 0; j < 249; ++j) (dst[j] = (src[(uint16_t)j + 8]));
}
__attribute__((noinline)) void copy_wrap(void) {
  const __attribute__((address_space(2))) uint8_t *src = (const __attribute__((address_space(2))) uint8_t *)tbl + rbase; __attribute__((address_space(2))) uint8_t *dst = (__attribute__((address_space(2))) uint8_t *)wbase; uint8_t j = 250;
  do { (dst[j] = (src[(uint16_t)j + 8])); } while (++j != 6);
}
__attribute__((noinline)) void copy_wrapped_index(void) {
  const __attribute__((address_space(2))) uint8_t *src = (const __attribute__((address_space(2))) uint8_t *)tbl + rbase; __attribute__((address_space(2))) uint8_t *dst = (__attribute__((address_space(2))) uint8_t *)wbase;
  for (uint8_t j = 0; j < 64; ++j) (dst[j] = (src[(uint8_t)(j + 248)]));
}
__attribute__((noinline)) uint16_t bump(uint16_t x) { return (uint16_t)(x * 5u + 7u); }
__attribute__((noinline)) uint16_t word_pressure(void) {
  const __attribute__((address_space(2))) uint16_t *src = (const __attribute__((address_space(2))) uint16_t *)((const __attribute__((address_space(2))) uint8_t *)tbl + rbase);
  uint16_t a=1,b=2,c=3,d=4,e=5,f=6,g=7,h=8;
  for (uint8_t j=0; j<64; ++j) {
    a=bump(a); uint16_t v=src[j];
    b=mix16(b,v); c=mix16(c,b); d=mix16(d,c); e=mix16(e,d);
    f=mix16(f,e); g=mix16(g,f); h=mix16(h,g);
  }
  return a^b^c^d^e^f^g^h;
}
static uint16_t readback(void) {
  uint16_t h=0;
  for (uint16_t j=0; j<256; ++j) h=mix16(h,(*(volatile __attribute__((address_space(2))) uint8_t *)(0x7EFF80u + (uint32_t)(j))));
  return h;
}
static uint32_t run(void) {
  uint32_t h=0;
  for (uint8_t k=0; k<3; ++k) {
    rbase = k==0 ? 0xFFFFu : k==1 ? 0x1FFFFu : 0xFF80u;
    h=mix32(h,word128()); h=mix32(h,word129());
    h=mix32(h,word_wrap()); h=mix32(h,word256());
    h=mix32(h,word_wrapped_index()); h=mix32(h,word_step2());
    h=mix32(h,word_pressure());
    __attribute__((address_space(2))) uint8_t *dst = (__attribute__((address_space(2))) uint8_t *)wbase;
    for (uint16_t j=0; j<256; ++j) (dst[j] = (0));
    copy248(); h=mix32(h,readback());
    copy249(); h=mix32(h,readback());
    copy_wrap(); h=mix32(h,readback());
    copy_wrapped_index(); h=mix32(h,readback());
  }
  return h;
}



volatile uint32_t corpus_result;
int main(void) { corpus_result=run(); for (;;) __asm__ volatile("wai"); }
